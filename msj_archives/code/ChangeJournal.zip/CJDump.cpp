/******************************************************************************
Module name: CJDump.cpp
Written by: Jeffrey Cooperstein & Jeffrey Richter
******************************************************************************/


#define _WIN32_WINNT 0x0500
#define _UNICODE
#define UNICODE

#include <windows.h>
#include <winioctl.h>
#include <tchar.h>
#include <stdio.h>
#include <conio.h>


// This program dumps the current drive's change journal records
void main() {

   HANDLE hCJ = INVALID_HANDLE_VALUE; // Handle to the volume
   PBYTE pbCJData = NULL;             // Buffer for reading records
   BOOL fOk = FALSE;

   __try {
      // Allocate 16 KB buffer for reading journal records
      pbCJData = (PBYTE) HeapAlloc(GetProcessHeap(), 0, 0x4000);
      if (NULL == pbCJData) __leave;
      
      // Get current directory
      TCHAR szCurrentDirectory[MAX_PATH];
      GetCurrentDirectory(MAX_PATH, szCurrentDirectory);

      // Use the drive letter from the current directory, and open
      // a handle to the volume
      TCHAR szVolumePath[_MAX_PATH];
      wsprintf(szVolumePath, TEXT("\\\\.\\%c:"), szCurrentDirectory[0]);
      HANDLE hCJ = CreateFile(szVolumePath, GENERIC_READ,
         FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);

      if (INVALID_HANDLE_VALUE == hCJ) __leave;

      // Query the change journal information
      USN_JOURNAL_DATA ujd;
      DWORD cb;
      fOk = DeviceIoControl(hCJ, FSCTL_QUERY_USN_JOURNAL, NULL, 0, 
         &ujd, sizeof(ujd), &cb, NULL);

      if (!fOk) __leave;

      // Show the change journal information
      _tprintf(TEXT("UsnJournalID    = 0x%016I64X\r\n"), ujd.UsnJournalID);
      _tprintf(TEXT("FirstUsn        = 0x%016I64X\r\n"), ujd.FirstUsn);
      _tprintf(TEXT("NextUsn         = 0x%016I64X\r\n"), ujd.NextUsn);
      _tprintf(TEXT("LowestValidUsn  = 0x%016I64X\r\n"), ujd.LowestValidUsn);
      _tprintf(TEXT("MaxUsn          = 0x%016I64X\r\n"), ujd.MaxUsn);
      _tprintf(TEXT("MaximumSize     = 0x%016I64X\r\n"), ujd.MaximumSize);
      _tprintf(TEXT("AllocationDelta = 0x%016I64X\r\n"), ujd.AllocationDelta);

      _tprintf(TEXT("\r\nPress any key to continue...\r\n"));
      getch();

      // The first record available for reading from the journal is
      // ujd.FirstUsn.  Start there, and dump all available records
      READ_USN_JOURNAL_DATA rujd;
      ZeroMemory(&rujd, sizeof(rujd));
      rujd.StartUsn = ujd.FirstUsn; // start at ujd.FirstUsn
      rujd.ReasonMask = 0xFFFFFFFF; // get every record
      rujd.UsnJournalID = ujd.UsnJournalID; // must set this to journal's ID

      // Keep reading records from the journal into the output buffer until
      // there's none left.
      while (TRUE) {
         // Get some records from the journal
         fOk = DeviceIoControl(hCJ, FSCTL_READ_USN_JOURNAL, &rujd, sizeof(rujd), 
            pbCJData, HeapSize(GetProcessHeap(), 0, pbCJData), &cb, NULL);

         // We are finished if DeviceIoControl fails, or the number of bytes
         // returned is <= sizeof(USN).  If cb > sizeof(USN), we have at least
         // one record to show the user
         if (!fOk || (cb <= sizeof(USN))) __leave;

         // The first sizeof(USN) bytes of the output buffer tell us the
         // 'next usn' that we should use to read some more records.
         // Store the 'next usn' into rujd.StartUsn for the next call to
         // DeviceIoControl with the FSCTL_READ_USN_JOURNAL code.
         rujd.StartUsn = * (USN*) pbCJData;

         // The first returned record is just after the first sizeof(USN) bytes
         USN_RECORD *pUsnRecord = (PUSN_RECORD) &pbCJData[sizeof(USN)];

         // Walk the output buffer
         while ((PBYTE) pUsnRecord < (pbCJData + cb)) {

            // Create a zero terminated copy of the filename
            WCHAR szFile[MAX_PATH];
            LPWSTR pszFileName = (LPWSTR) 
               ((PBYTE) pUsnRecord  + pUsnRecord->FileNameOffset);
            int cFileName = pUsnRecord->FileNameLength / sizeof(WCHAR);
            wcsncpy(szFile, pszFileName, cFileName);
            szFile[cFileName] = 0;

            // Show some of the record info
            _tprintf(TEXT("Usn(0x%016I64X) Reason(0x%08X) %s\r\n"),
               pUsnRecord->Usn, pUsnRecord->Reason, szFile);

            // Move to next record
            pUsnRecord = (PUSN_RECORD) 
               ((PBYTE) pUsnRecord + pUsnRecord->RecordLength);
         }
      }
   }
   __finally {
      if (!fOk)
         _tprintf(TEXT("There was an error\r\n"));
      if (hCJ != INVALID_HANDLE_VALUE)
         CloseHandle(hCJ);
      if (pbCJData != NULL)
         HeapFree(GetProcessHeap(), 0, pbCJData);
   }
}
