// TreeDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DragDropTreeCtrl.h"
#include "TreeDemo.h"
#include "TreeDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTreeDemoDlg dialog

CTreeDemoDlg::CTreeDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTreeDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTreeDemoDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTreeDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTreeDemoDlg)
	DDX_Control(pDX, IDC_TREE, m_wndTree);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTreeDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CTreeDemoDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTreeDemoDlg message handlers

BOOL CTreeDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	//
	// Assign an image list to the tree view control.
	//
    m_imageList.Create (IDB_IMAGES, 16, 1, RGB (255, 0, 255));
    m_wndTree.SetImageList (&m_imageList, TVSIL_NORMAL);

	//
	// Add items to the tree.
	//
	HTREEITEM hParent = m_wndTree.InsertItem (_T ("Drive C:"), 0, 0);
	m_wndTree.InsertItem (_T ("Folder 1"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 2"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 3"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 4"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 5"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 6"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 7"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 8"), 1, 2, hParent);
	m_wndTree.Expand (hParent, TVE_EXPAND);

	hParent = m_wndTree.InsertItem (_T ("Drive D:"), 0, 0);
	m_wndTree.InsertItem (_T ("Folder 9"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 10"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 11"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 12"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 13"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 14"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 15"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 16"), 1, 2, hParent);

	hParent = m_wndTree.InsertItem (_T ("Drive E:"), 0, 0);
	m_wndTree.InsertItem (_T ("Folder 17"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 18"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 19"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 20"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 21"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 22"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 23"), 1, 2, hParent);
	m_wndTree.InsertItem (_T ("Folder 24"), 1, 2, hParent);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTreeDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CTreeDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}
