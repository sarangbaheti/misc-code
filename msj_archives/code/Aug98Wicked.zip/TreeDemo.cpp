// TreeDemo.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "DragDropTreeCtrl.h"
#include "TreeDemo.h"
#include "TreeDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTreeDemoApp

BEGIN_MESSAGE_MAP(CTreeDemoApp, CWinApp)
	//{{AFX_MSG_MAP(CTreeDemoApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTreeDemoApp construction

CTreeDemoApp::CTreeDemoApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CTreeDemoApp object

CTreeDemoApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CTreeDemoApp initialization

BOOL CTreeDemoApp::InitInstance()
{
	// Standard initialization

	CTreeDemoDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
