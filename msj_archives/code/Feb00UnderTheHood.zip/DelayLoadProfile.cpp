//==========================================
// Matt Pietrek
// Microsoft Systems Journal, March 2000
// FILE: DelayLoadProfile.CPP
//==========================================
#include "stdafx.h"
#include <stdio.h>
#include <shlwapi.h>

#include "DebugInjector.H"

bool ProcessCommandLine( PCSTR pszCmdLine, PSTR pszTargetCmdLine );
bool GetInjectedDLLFullPath( PSTR pszFullPath );
void __stdcall OutputDebugStringCallback( PSTR psz );

char g_szHelp[] =
"Syntax: DelayLoadProfile <TargetCmdLine> [target args]\n\n"
"Matt Pietrek, Microsoft Systems Journal, March 2000\n\n"
"DelayLoadProfile starts a target process.  As the process exits, it\n"
"generates a report indicating which DLLs were imported by the EXE,\n"
"and how many times the DLL was called.\n\n"
"Please see the accompanying article for a full explanation of "
"DelayLoadProfile.\n";

//===========================================================================
int main( int argc, char * argv[] )
{
    //=====================================================
    // Get target cmd line
    char szTargetCmdLine[MAX_PATH*2] = { 0 };
    if ( !ProcessCommandLine( GetCommandLine(), szTargetCmdLine ) )
    {
        printf( g_szHelp );
        return 1;
    }

    //=====================================================
    // Create target in preparation for injection
    CDebugInjector injector;

    if ( !injector.LoadProcess( szTargetCmdLine ) )
    {
        printf( "Unable to start %s\n", szTargetCmdLine );
        return 1;
    }

    //=====================================================
    // Tell the injector which DLL to inject
    char szDllToInject[MAX_PATH];
    GetInjectedDLLFullPath( szDllToInject );

    injector.SetDLLToInject( szDllToInject );

    //=====================================================
    // Indicate where the OutputDebugString strings will go
    injector.SetOutputDebugStringCallback( OutputDebugStringCallback );

    //=====================================================
    // Let the target run.  This cause the injection
    injector.Run();

    return 0;
}

//===========================================================================
bool ProcessCommandLine(PCSTR pszCmdLine,       // Cmd line passed to us
                        PSTR pszTargetCmdLine   // What we'll start the target
                        )                       // process with
{
    // cmd line syntax is: ThisExeName [OurArgs] TargetExe [TargetArgs]

    PSTR p = PathGetArgs( pszCmdLine );
    if ( p && *p )
    {
        strcpy( pszTargetCmdLine, p );
        return true;
    }

    return false;
}

//===========================================================================
bool GetInjectedDLLFullPath( PSTR pszFullPath )
{
    // The DLL should be in the same directory as this EXE.  Get the EXE's
    // full path and replace the EXE name with the DLL name.
    char szExePath[MAX_PATH];

    GetModuleFileName( 0, szExePath, sizeof(szExePath) );
    PathRemoveFileSpec( szExePath );

    strcpy( pszFullPath, szExePath );
    strcat( pszFullPath, "\\DelayLoadProfileDll.DLL" );

    return true;
}

void __stdcall OutputDebugStringCallback( PSTR psz )
{
    // Print everything to the console.  If other OutputDebugString calls
    // in the debuggee annoy you, can can apply filtering here.
    printf( "%s\n", psz );
}
