//==========================================
// Matt Pietrek
// Microsoft Systems Journal, January 1998
// Program: DlgDump.EXE
// FILE: DlgDump.CPP
//==========================================
#include <windows.h>
#include <stdio.h>
#include "MSJPERsrc.h"

BOOL DumpDialog( PVOID pDlg );  // In DlgDumpHelper.H

//=============================== Global Variables ============================
char g_szHelpText[] = 
"Dialog Dumper - Matt Pietrek, 1998 for MSJ\n"
"Syntax: DlgDump <Executable Name>\n";

PSTR g_pszFile = 0;

//==================================== Code ===================================


BOOL DumpAllDialogs( PSTR pszFilename )
{
    // initial hook up to the resources
    PERsrcTbl rsrcTbl( pszFilename );
    
    // Locate the Dialog resources
    PPERsrcType pDlgs = rsrcTbl.GetResourceTypeById( (WORD)RT_DIALOG );
    
    if ( !pDlgs )       // No dialogs?  We're done!
        return FALSE;

    PPERsrcInst pDlgInst = 0;   // Begin enumeration by passing 0

    // Enumerate through each dialog instance...    
    while ( pDlgInst = pDlgs->GetNextResourceInst( pDlgInst ) )
    {
        // Get a pointer to the raw dialog template
        PVOID pDlgData = pDlgInst->GetData();
        
        if ( pDlgInst )
        {
            printf( "====================\n" );

            if ( pDlgInst->IsNamed() )  // Does the dialog have a name? Get it!
            {
                char szDlgName[256];
                pDlgInst->Name( szDlgName, sizeof(szDlgName) );             
                printf( "Dialog name: %s\n", szDlgName );
            }
            else    // Dialog is identified by an integer ID
                printf( "Dialog id: %u\n", pDlgInst->Id() );
                
            DumpDialog( pDlgData );     // The real work. In DlgDumpHelper.CPP

            // We don't have to explicitly delete pDlgInst because the
            // enumeration method does this for us          
            printf( "\n" );
        }                                       
    }
            
    delete pDlgs;   // Delete pointer to the dialog collection
    
    return TRUE;
}

BOOL ProcessCommandLine( int argc, char *argv[] )
{
    if ( argc != 2 )    // One parameter (the filename) should be passed
        return FALSE;

    g_pszFile = argv[1];         // First real argument is first filename
                       
    return TRUE;
}


int main( int argc, char * argv[] )
{   
    if ( !ProcessCommandLine( argc, argv ) )
    {
        printf( g_szHelpText );
                
        return 0;
    }

    DumpAllDialogs( g_pszFile );

    return 0;
}
