////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- December 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#include "stdafx.h"
#include "DeferScroll.h"
#include "PupText.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CDeferScrollHook, CSubclassWnd);

CDeferScrollHook::CDeferScrollHook()
{
	m_bIgnoreThumb=TRUE;
}

CDeferScrollHook::~CDeferScrollHook()
{
}

BOOL CDeferScrollHook::Install(CWnd* pWnd, UINT nStyle)
{
	m_nStyle = nStyle; // style for popup scroll tip
	return HookWindow(pWnd);
}

//////////////////
// Get "scroll tip" text for given scroll pos.
// If you want scroll tips, derive and override this virtual function.
//
BOOL CDeferScrollHook::OnGetScrollTipText(CString& s, UINT nPos)
{
	return FALSE;
}

//////////////////
// Main hook proc intercepts scrolling notifications
//
LRESULT CDeferScrollHook::WindowProc(UINT msg, WPARAM wp, LPARAM lp)
{
	if (msg==WM_VSCROLL) {
		UINT nSBCode = LOWORD(wp);
		UINT nPos    = HIWORD(wp);

		static CPopupText wndTip;	// one and only
		CWnd* pWnd = CWnd::FromHandle(m_hWnd);

		switch (nSBCode) {
		case SB_THUMBTRACK:
			if (m_bIgnoreThumb) {
				// ignoring: don't pass to window, but display scroll tip
				CString s;
				if (OnGetScrollTipText(s,nPos)) {	// if app supplies popup text:
					if (!wndTip) {
						// create scroll tip window
						CPoint pt;
						GetCursorPos(&pt);
						pt.x -= 10;
						wndTip.Create(pt, pWnd, m_nStyle);
					}
					wndTip.SetWindowText(s);
					wndTip.Invalidate();
					wndTip.UpdateWindow();
				}
				return 0; // handled; otherwise (not ignoring) pass along
			}
			break;

		case SB_THUMBPOSITION:
		{
			// convert SB_THUMBPOSITION to SB_THUMBTRACK, and don't ignore it
			BOOL bSaveIgnoreThumb = m_bIgnoreThumb;
			m_bIgnoreThumb = FALSE;
			pWnd->SendMessage(msg, MAKEWPARAM(SB_THUMBTRACK, nPos), lp);
			m_bIgnoreThumb = bSaveIgnoreThumb;
			return 0; // handled
		}

		case SB_ENDSCROLL:
			// end of scrollling: remove scroll tip
			if (wndTip)
				wndTip.DestroyWindow();
			break;
		}
	}
	// I don't handle it: pass along
	return CSubclassWnd::WindowProc(msg, wp, lp);
}

