////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- December 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#include "stdafx.h"
#include "resource.h"
#include "LVScroll.h"
#include "MainFrm.h"
#include "DeferScroll.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_WM_SETFOCUS()
	ON_COMMAND(ID_VIEW_LCDIALOG, OnViewListCtrlDialog)
END_MESSAGE_MAP()

static UINT indicators[] = {
	ID_SEPARATOR,
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	VERIFY(CFrameWnd::OnCreate(lpCreateStruct)==0);

	VERIFY(m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW,
		CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL));
	
	VERIFY(m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC));
	VERIFY(m_wndToolBar.LoadToolBar(IDR_MAINFRAME));

	VERIFY(m_wndStatusBar.Create(this));
	VERIFY(m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)));

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.cx = 250;
	cs.cy = 600;
	return TRUE;
}

void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	m_wndView.SetFocus();
}

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// let the view have first crack at the command
	if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// handle myself
	return CFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

class CMyListCtrlDeferScrollHook : public CDeferScrollHook {
protected:
	virtual BOOL OnGetScrollTipText(CString& s, UINT nPos) {
		s.Format(_T("Item %d"), nPos);
		return TRUE;
	}
};

class CListCtrlDialog : public CDialog {
public:
	CListCtrlDialog(CWnd* pParent) : CDialog(IDD_LCDIALOG, pParent) { }
protected:
	CMyListCtrlDeferScrollHook m_deferScrollHook;
	CListCtrl	m_lcData;
	CButton		m_butnDefer;
	virtual BOOL OnInitDialog();
	afx_msg void OnToggleDefer();
	DECLARE_MESSAGE_MAP()
};

BEGIN_MESSAGE_MAP(CListCtrlDialog, CDialog)
	ON_COMMAND(IDC_DEFER, OnToggleDefer)
END_MESSAGE_MAP()

BOOL CListCtrlDialog::OnInitDialog()
{
	CWaitCursor wait;

	VERIFY(m_butnDefer.SubclassDlgItem(IDC_DEFER, this));
	m_butnDefer.SetCheck(TRUE);

	VERIFY(m_lcData.SubclassDlgItem(IDC_LIST1, this));

	CListCtrl& lc = m_lcData;

	// add columns
	int i;
	static LV_COLUMN cols[2] = {
		{ LVCF_TEXT | LVCF_SUBITEM | LVCF_WIDTH, 0, 60,  "Name" },
		{ LVCF_TEXT | LVCF_SUBITEM | LVCF_WIDTH, 0, 150, "Data" },
	};
	const NUMCOLS = sizeof(cols)/sizeof(cols[0]);
	for(i = 0; i<NUMCOLS; i++) {
		cols[i].iSubItem = i;
		lc.InsertColumn(i,&cols[i]);
	}

	// add items
	LV_ITEM lvi;
	lvi.mask = LVIF_TEXT;
	CString s;
	for(i = 0; i < 4000; i++) {
		s.Format("Item %d", i);
		lvi.iItem = i;
		lvi.iSubItem = 0;
		lvi.pszText = const_cast<LPSTR>((LPCTSTR)s);
		lc.InsertItem(&lvi);
		lc.SetItemText(i,0,s);
		s.Format("This is item number %d", i);
		lc.SetItemText(i,1,s);
	}

	m_deferScrollHook.Install(&lc);

	return TRUE;
}

void CListCtrlDialog::OnToggleDefer()
{
	m_butnDefer.GetCheck() ? m_deferScrollHook.Install(&m_lcData)
		: m_deferScrollHook.Unhook();
}

void CMainFrame::OnViewListCtrlDialog()
{
	CListCtrlDialog(this).DoModal();
}
