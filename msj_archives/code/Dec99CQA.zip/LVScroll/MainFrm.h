////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- December 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#pragma once
#include "View.h"

//////////////////
// Vanilla main frame
//
class CMainFrame : public CFrameWnd {
public:
	CMainFrame();
	virtual ~CMainFrame();

protected: 
	CStatusBar  m_wndStatusBar;	// status bar
	CToolBar    m_wndToolBar;		// toolbar
	CMyView		m_wndView;			// main view

	// overrides
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnCmdMsg(UINT, int, void*, AFX_CMDHANDLERINFO*);

	// msg handlers
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSetFocus(CWnd *pOldWnd);
	afx_msg void OnViewListCtrlDialog();

	DECLARE_MESSAGE_MAP()
	DECLARE_DYNAMIC(CMainFrame)
};
