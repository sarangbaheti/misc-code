////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- December 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#pragma once
#include "SubClass.h"
#include "PupText.h"

//////////////////
// This class implements deferred scrolling for views and list
// controls, and prolbably any other kind of scrolling window.
//
class CDeferScrollHook : public CSubclassWnd {
public:
	CDeferScrollHook();
	virtual ~CDeferScrollHook();
	BOOL Install(CWnd* pWnd, UINT nStyle = CPopupText::JUSTIFYRIGHT);

	// You must override to provide the scrolltip text if you want it.
	virtual BOOL OnGetScrollTipText(CString& s, UINT nPos);

protected:
	UINT	m_nStyle;			// style for popup text
	BOOL	m_bIgnoreThumb;	// ignore SB_THUMBTRACK
	virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	DECLARE_DYNAMIC(CDeferScrollHook)
};
