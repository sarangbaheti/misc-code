////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- December 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#pragma once
#include "DeferScroll.h"

//////////////////
// Deferred scrolling hook for a view.
// Derive from base to implement OnGetScrollTipText
//
class CMyViewDeferScrollHook : public CDeferScrollHook {
protected:
	friend class CMyView;
	UINT m_cyLine;			// height of one line
	virtual BOOL OnGetScrollTipText(CString &s, UINT nPos);
};

//////////////////
// A typical scroll view
//
class CMyView : public CScrollView {
public:
	CMyView();
	virtual ~CMyView();

protected:
	CMyViewDeferScrollHook m_deferScrollHook;
	CFont m_font;		// display font 
	int	m_cyLine;	// height of line in pixels

	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void PostNcDestroy();
	virtual void OnInitialUpdate();
	virtual void OnDraw(CDC* pDC);
	DECLARE_MESSAGE_MAP()
};
