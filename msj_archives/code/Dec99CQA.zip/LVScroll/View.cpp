////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- December 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#include "stdafx.h"
#include "PupText.h"
#include "View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const NUMLINES = 2500;
const MYWM_GETSCROLLTEXT = WM_USER;

BEGIN_MESSAGE_MAP(CMyView, CScrollView)
END_MESSAGE_MAP()

CMyView::CMyView()
{
}

CMyView::~CMyView()
{
}

void CMyView::PostNcDestroy()
{
	// don't delete this
}

BOOL CMyView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CScrollView::PreCreateWindow(cs))
		return FALSE;
	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	return TRUE;
}

void CMyView::OnInitialUpdate()
{
	if (!(HFONT)m_font) {
		// claculate height of text for defer-scroll hook
		// Use menu font.
		CNonClientMetrics ncm;
		m_font.CreateFontIndirect(&ncm.lfMenuFont);
		CClientDC dc = this;
		CFont* pOldFont = dc.SelectObject(&m_font);
		CRect rc;
		dc.DrawText(CString("foo"), &rc, DT_CALCRECT);
		m_cyLine = rc.Height();
		m_deferScrollHook.m_cyLine = m_cyLine;
		dc.SelectObject(pOldFont);
	}
	SetScrollSizes(MM_TEXT, CSize(0, m_cyLine * NUMLINES));
	SetScrollPos(SB_VERT, 0, FALSE);
	SetScrollRange(SB_VERT, 0, 3000);
	m_deferScrollHook.Install(this);
}

/////////////////
// Typical draw handler draws a bunch of lines
//
void CMyView::OnDraw(CDC* pDC)
{
	CRect rc;
	GetClientRect(&rc);
	rc.bottom = rc.top + m_cyLine;
	CString s;

	CFont* pOldFont = pDC->SelectObject(&m_font);
	for (int i=0; i<NUMLINES; i++) {
		s.Format("This is line %d     ", i);
		pDC->DrawText(s, &rc, 0);
		rc += CSize(0, m_cyLine);
	}
	pDC->SelectObject(pOldFont);
}

//////////////////
// You must implement this fn to provide the scroll tip text
//
BOOL CMyViewDeferScrollHook::OnGetScrollTipText(CString& s, UINT nPos)
{
	s.Format(_T("Line %d"),nPos/m_cyLine);
	return TRUE; // handled
}
