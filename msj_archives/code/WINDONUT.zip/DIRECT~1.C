// DIRECTDRAW.C : The Generic Low-Level routines to acess the DirectDraw Interface

// Functions with DIRECTDRAW_ prefacing them are defined in DIRECTDRAW.H, which is included in wincatch.h

#include "windonut.h"

#define I_DIRECT_DRAW           (lpDirectDraw->lpVtbl)
#define I_DIRECT_DRAW_SURFACE   (lpSurface->lpVtbl)

/*****************************************************************************

DIRECTDRAW_Enable: This function creates the DirectDraw primary object and
                   determines that the host machine is capable of displaying
                   the requested video mode. For this game, we are looking
                   for a 640x480 256 color mode, with a front and a back
                   buffer. We will page flip between these two buffers.

*****************************************************************************/

// This define is local to this function

LPDIRECTDRAW DIRECTDRAW_Enable( int            ixRes, 
                                int            iyRes, 
                                int            cColorDepth, 
                                DWORD          dwRamNeeded )
{
  LPDIRECTDRAW        lpDirectDraw;
  HRESULT             hrRetVal;

  hrRetVal = DirectDrawCreate( NULL, &lpDirectDraw, NULL );
  if ( DD_OK == hrRetVal )
    {
    // We want our game to run in exclusive mode
    hrRetVal = I_DIRECT_DRAW->SetCooperativeLevel( lpDirectDraw, 
                                                ghWnd,
                                                DDSCL_FULLSCREEN |
												DDSCL_ALLOWREBOOT | 
											    DDSCL_NOWINDOWCHANGES |
												DDSCL_EXCLUSIVE 
												);

    if ( DD_OK == hrRetVal )
       {
       // Set our graphics mode to whatever the user requested

       hrRetVal = I_DIRECT_DRAW->SetDisplayMode( lpDirectDraw, 
                                                 ixRes,
                                                 iyRes, 
                                                 cColorDepth );

       hrRetVal = DD_OK;

       if ( DD_OK == hrRetVal )
          {
          // Check for enough Video Ram

          DDCAPS  ddcaps;
          ddcaps.dwSize = sizeof( ddcaps );
          hrRetVal = I_DIRECT_DRAW->GetCaps( lpDirectDraw, 
                                             &ddcaps,
                                             NULL );

          if ( DD_OK == hrRetVal )
             {
             if( ddcaps.dwVidMemFree >= dwRamNeeded )  // DAVE: Figure out this number!
               {
               return lpDirectDraw;
               }
             Err("This Game Requires %ld of free VRAM to run", dwRamNeeded);
             }
          else
             {
             Err( "DirectDraw: GetCaps FAILED");
             }
          }
        else
          {
          Err( "DirectDraw: ModeSet FAILED");
          }
        }
    else
       {
       Err( "DirectDraw: SetExclusiveMode FAILED");
       }
    }
  else
    {
    Err( "DirectDraw: DirectDrawCreate FAILED");
    }

  return FALSE;

}

/*************************************************************************/
//
//
//
//
/*************************************************************************/

void DIRECTDRAW_Disable( LPDIRECTDRAW   lpDirectDraw )
{
  I_DIRECT_DRAW->RestoreDisplayMode (lpDirectDraw);
  I_DIRECT_DRAW->Release(lpDirectDraw);
}

/*************************************************************************

DIRECTDRAW_CreateFlippingSurface: This function creates the screen-sized
                                  surfaces for page flipping. The primary
                                  buffer is what is displayed, and the back
                                  buffer is what we render to. After redering,
                                  we flip pages to move the back buffer into
                                  the primary buffer. This process elimimates
                                  "tearing", which in the world of game
                                  programming, sucks.

                                  lpSurfaceArray points to an array of
                                  surfaces. The first element of the array is
                                  always the primary surface, and the
                                  subsequent elements are the back buffers.
                                  Currently, this function only supports one
                                  back buffer                                         

**************************************************************************/

BOOL DIRECTDRAW_CreateFlippingSurface( LPDIRECTDRAW         lpDirectDraw,
                                       int                  iNumBackBuffers, 
                                       LPDIRECTDRAWSURFACE  *lpSurfaceArray)
{
    DDSURFACEDESC       ddsd;
    HRESULT             hrRetVal;
    DDSCAPS             ddcaps;

    // We want to describe our surface. We have a "primary" surface, plus a number
    // of back buffers. We want to use as few back buffers as possible, since they are
    // mega memory hogs, which, in the world of game programming, bites.

    memset( &ddsd, 0, sizeof( ddsd ) );
    ddsd.dwSize = sizeof( ddsd );
    ddsd.dwFlags = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
    ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE |
                          DDSCAPS_FLIP |
                          DDSCAPS_COMPLEX;

    ddsd.dwBackBufferCount = iNumBackBuffers;

    // Call the DirectDraw interface to create the primary surface (which will also
    // create the back buffers, which we will get to in a moment)
    // Provided we succeed, our global variable pointing the to
    // Primary surface (the front buffer), was set.

    hrRetVal = I_DIRECT_DRAW->CreateSurface( lpDirectDraw, &ddsd, &(lpSurfaceArray[0]), NULL );

    if( hrRetVal != DD_OK )
      {
      Err( "CreateSurface FAILED! %08lx", hrRetVal );
      return FALSE;
      }

    // The back buffer was also created, so let's ask DirectDraw to tell us the pointer
    // to it. The front buffer has its own COM interface, we use the GetAttachedSurface
    // method.

    ddcaps.dwCaps = DDSCAPS_BACKBUFFER;

    hrRetVal = lpSurfaceArray[0]->lpVtbl->GetAttachedSurface (lpSurfaceArray[0],
                                                              &ddcaps,
                                                              &(lpSurfaceArray[1]) );

    if( hrRetVal != DD_OK )
      {
      Err( "GetAttachedSurface FAILED! %08lx", hrRetVal );
      return FALSE;
      }

    // If we made it this far, then the two global variables glpFrontBuffer
    // and glpFrontBuffer are set to point to their respective buffers

    return TRUE;

}

/*************************************************************************

DIRECTDRAW_CreateSurface: This function creates a "surface". Think of a
                          surface as a bitmap that lives on the video card.
                          Usually, we will use this function to either create
                          sprites, or planes. A sprite is usually a character
                          in the game, while a plane is usually some scrolling
                          background thing. Programatically, there is no diff
                          between a sprite and a plane, so this program will
                          call everything a sprite.

*************************************************************************/

LPDIRECTDRAWSURFACE DIRECTDRAW_CreateSurface( LPDIRECTDRAW   lpDirectDraw,
                                              DWORD          dwWidth, 
                                              DWORD          dwHeight,
                                              DWORD          dwColorSpaceLowValue,
                                              DWORD          dwColorSpaceHighValue)
{
    DDSURFACEDESC       ddsd;
    HRESULT             hrRetVal;
    DDCOLORKEY          ddck;
    LPDIRECTDRAWSURFACE lpSurface;
    
    // We want to describe our surface. In this case, we just want to allocate
    // a chunk of memory in the video card, that is not on the primary or back
    // buffer surface.

    memset( &ddsd, 0, sizeof( ddsd ) );
    ddsd.dwSize = sizeof( ddsd );
    ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT |DDSD_WIDTH;

    // Make this an off-screen bitmap   
    ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
    
    ddsd.dwHeight = dwHeight;
    ddsd.dwWidth  = dwWidth;

    // We need to set the "Color Key" for this bitmap. These are the
    // transparent colors, so this surface can act like a sprite

    hrRetVal = I_DIRECT_DRAW->CreateSurface( lpDirectDraw, &ddsd, &lpSurface, NULL );
    
    if( DD_OK == hrRetVal )
      {
      ddck.dwColorSpaceLowValue = dwColorSpaceLowValue;
      ddck.dwColorSpaceHighValue = dwColorSpaceHighValue;
      I_DIRECT_DRAW_SURFACE->SetColorKey( lpSurface, DDCKEY_SRCBLT, &ddck);
      }
    else
      {
      Err( "CreateSurface FAILED, rc = %ld", (DWORD) LOWORD( hrRetVal ) );
      lpSurface = NULL;
      }

    return lpSurface;
}

/*************************************************************************

*************************************************************************/

void DIRECTDRAW_FloodFill( LPDIRECTDRAWSURFACE lpSurface, 
                           DWORD               dwColor )
{
  DDBLTFX     ddbltfx;
  HRESULT     hrRetVal;

  ddbltfx.dwSize = sizeof( ddbltfx );
  ddbltfx.dwFillColor = dwColor;

  while (1)
    {
    hrRetVal = I_DIRECT_DRAW_SURFACE->Blt(lpSurface,          // dest surface
                                          NULL,                   // dest rect
                                          NULL,                   // src surface
                                          NULL,                   // src rect
                                          DDBLT_COLORFILL,
                                          &ddbltfx );
    if (DD_OK == hrRetVal) break;
    }
}

/*************************************************************************

lpSurface MUST point to a front surface

*************************************************************************/

void DIRECTDRAW_FlipBackToFront (LPDIRECTDRAWSURFACE lpSurface)
{
  HRESULT     hrRetVal;
  while (1)
    {
    hrRetVal = I_DIRECT_DRAW_SURFACE->Flip(lpSurface, NULL, 0);
    if (DD_OK == hrRetVal) break;
    }
}

/*************************************************************************

*************************************************************************/

LPDIRECTDRAWPALETTE DIRECTDRAW_CreatePalette ( LPDIRECTDRAW        lpDirectDraw,
                                               RGBQUAD             *Palette)
{
  int                 i;
  PALETTEENTRY        pe[256];
  LPDIRECTDRAWPALETTE lpPalette;
  HRESULT             hrRetVal;

  for( i=0; i<256; i++ )
    {
    pe[i].peRed   = Palette[i].rgbRed;
    pe[i].peGreen = Palette[i].rgbGreen;
    pe[i].peBlue  = Palette[i].rgbBlue;
    }
    
  hrRetVal = I_DIRECT_DRAW->CreatePalette( lpDirectDraw, DDPCAPS_8BIT, pe, &lpPalette, NULL );

  if( hrRetVal != DD_OK ) 
    return NULL;
  else
    return lpPalette;
}


/*************************************************************************

*************************************************************************/

LPDIRECTDRAWPALETTE DIRECTDRAW_SetPalette ( LPDIRECTDRAW        lpDirectDraw,
                                            LPDIRECTDRAWSURFACE lpFrontBuffer,
                                            LPDIRECTDRAWPALETTE lpPalette)
{
  LPDIRECTDRAWPALETTE lpOldPalette;

  lpFrontBuffer->lpVtbl->GetPalette(lpFrontBuffer, &lpOldPalette );
  lpFrontBuffer->lpVtbl->SetPalette(lpFrontBuffer, lpPalette );
  return lpOldPalette;
}

/*************************************************************************

*************************************************************************/

LPDIRECTDRAWSURFACE DIRECTDRAW_CreateSurfaceFromBitmap( LPDIRECTDRAW        lpDirectDraw,
                                                        LPDIRECTDRAWSURFACE lpFrontBuffer,
                                                        LPDIRECTDRAWPALETTE *lplpPalette,
                                                        LPSTR               szFileName,
                                                        LPINT               lpiCX,
                                                        LPINT               lpiCY,
                                                        LPDIRECTDRAWSURFACE lpSurface,
                                                        DWORD               dwColorSpaceLowValue,
                                                        DWORD               dwColorSpaceHighValue )
{
    LPBYTE              Image;          // Holds bitmap data
    HANDLE              hFile;
    BITMAPFILEHEADER    BMPFileHead;
    BITMAPINFOHEADER    BMPFileInfo;
    RGBQUAD             Palette[256];
    DWORD               actualRead;
    DDSURFACEDESC       ddsd;
    LPSTR               lpBits;
    LPSTR               lpSrc;
    int                 i;
    HRESULT             hrRetVal;
    DWORD               dwBitCount;

    // First, get the bitmap into memory. This is done by loading
    // the bitmap into memory.

    if (szFileName) // We have been given a filename. Let's get the file
      {
      hFile = CreateFile(szFileName,
                         GENERIC_READ,
                         FILE_SHARE_READ,
                         (LPSECURITY_ATTRIBUTES) NULL,
                         OPEN_EXISTING,
                         FILE_ATTRIBUTE_NORMAL,
                         (HANDLE) NULL);
      if( INVALID_HANDLE_VALUE == hFile)
        {
        return NULL;
        }

      // Read the header and info structures
      if( !ReadFile(hFile, &BMPFileHead, sizeof(BMPFileHead), &actualRead, NULL))
        {
        CloseHandle(hFile);
        return NULL;
        }

      if( !ReadFile(hFile, &BMPFileInfo, sizeof(BMPFileInfo), &actualRead, NULL))
        {
        CloseHandle(hFile);
        return NULL;
        }

      // Check to make sure this is a compatible file (8bpp)
      if (BMPFileInfo.biBitCount != 8)
        {
        CloseHandle(hFile);
        return NULL;
        }

      // Read the palette information
      if(!ReadFile(hFile, Palette, sizeof(Palette), &actualRead, NULL))
        {
        CloseHandle(hFile);
        return NULL;
        }

      dwBitCount = BMPFileInfo.biWidth*BMPFileInfo.biHeight;
      *lpiCX = BMPFileInfo.biWidth;
      *lpiCY = BMPFileInfo.biHeight;

      Image = (LPBYTE) LocalAlloc( LPTR, dwBitCount  );
      if( Image == NULL )
        {
        CloseHandle(hFile);
        return NULL;
        }

      // Read the image bits
      if(!ReadFile(hFile, Image, dwBitCount, &actualRead, NULL))
        {
        LocalFree(Image);
        CloseHandle(hFile);
        return NULL;
        }

      CloseHandle(hFile);
      }

    // Create the Direct Draw Palette and associate it with the front buffer
    // if this has not been done previously

    if( !*lplpPalette )
      {
      *lplpPalette = DIRECTDRAW_CreatePalette ( lpDirectDraw, // Direct Draw Object
                                                Palette);     // RGBQUADS for palette
      if( !(*lplpPalette) )
        return FALSE;

      DIRECTDRAW_SetPalette ( lpDirectDraw,  // Direct Draw Object
                              lpFrontBuffer, // Front buffer
                              *lplpPalette);   // Palette from above call

      }

    // Create the DirectDraw Surface if it was NULL

    if (!lpSurface)
      {
      lpSurface = DIRECTDRAW_CreateSurface( lpDirectDraw,
                                            BMPFileInfo.biWidth,
                                            BMPFileInfo.biHeight,
                                            dwColorSpaceLowValue,
                                            dwColorSpaceHighValue);
      if(!lpSurface)
        {
        LocalFree(Image);
        return NULL;
        }
      }

    // Now, copy the bits from the bitmap into the surface

    ddsd.dwSize = sizeof( ddsd );
    hrRetVal = I_DIRECT_DRAW_SURFACE->Lock( lpSurface, NULL, &ddsd, 0, NULL );
    if( hrRetVal != DD_OK )
      {
      return FALSE;
      }

    // Copy bitmap bits from system memory to video memory
    lpBits = (LPSTR)ddsd.lpSurface;
    lpSrc = (LPSTR)(&Image[dwBitCount]);
    for( i=0; i < BMPFileInfo.biHeight; i++ )
      {
      memcpy( lpBits, lpSrc, BMPFileInfo.biWidth );

      lpBits += ddsd.lPitch;
      lpSrc -= BMPFileInfo.biWidth;
      }
    I_DIRECT_DRAW_SURFACE->Unlock(lpSurface, NULL );
    LocalFree( Image );

	{
    DDCOLORKEY          ddck;

    ddck.dwColorSpaceLowValue = 0xff;
    ddck.dwColorSpaceHighValue = 0xff;
    I_DIRECT_DRAW_SURFACE->SetColorKey( lpSurface, DDCKEY_DESTBLT, &ddck);
	}

    return lpSurface;

} // CreateSurfaceFromBitmap
