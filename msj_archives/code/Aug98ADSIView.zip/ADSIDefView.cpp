//////////////////////////////////////////////////////////////////////////
//
// Filename:   ADSIDefView.cpp
//
// Description:  This implements the default view
//
// Author(s):    Todd Daniell, Brian Daigle
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////
#include "stdafx.h"

// use the STL string object
#include <string>
using namespace std;

#include "ADSIDefView.h"

#ifndef __ABOUT_H_
#include "About.H"
#endif

//////////////////////////////////////////////////////////////////////////
// CADSIDefView Constructor

CADSIDefView::CADSIDefView()
{ 
 // Nullify the member vars
 ClearMemberVar();
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView Desructor

CADSIDefView::~CADSIDefView()
{
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView ClearMemberVar

void CADSIDefView::ClearMemberVar()
{
 // Reset the Bitmap List
 m_iFirstBitmap = 0;

 // Reset the Menu
 m_hMenu = NULL;

 // Clear the Folder Settings
 ::ZeroMemory( &m_FolderSettings, sizeof( m_FolderSettings ));

 // Clear the base Parent Rect
 ::ZeroMemory( &m_rcParent, sizeof( m_rcParent ));

 // Reset the Child Window Handle
 m_hwndChild = NULL;
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView CreateView

STDMETHODIMP CADSIDefView::CreateView( PADSI_CVW2PARAMS lpADSIParams, 
                                       IUnknown * pIShellFolder )
{
 HRESULT hr = E_FAIL;

 // Save the View ID
 m_guidCurrentView = *( lpADSIParams->pvid );

 // Save the Shell Folder Interface
 m_pIShellFolder = pIShellFolder;

 // Save the Shell Browser Interface 
 m_pIShellBrowser = lpADSIParams->pIUnkShellBrowser;

 // Save the Folder Settings
 m_FolderSettings.ViewMode  = lpADSIParams->uViewMode;
 m_FolderSettings.fFlags    = lpADSIParams->uFlags;

 // What is the Browser Window
 HWND hWndParent = NULL;

 hr = m_pIShellBrowser->GetWindow( &hWndParent );

 if (FAILED(hr))
   {
   _ASSERTE(0);
   return hr;
   }

 // Create the base Window for the Browser to use
 RECT  rcView;

 rcView.top    = lpADSIParams->prcView->top;
 rcView.left   = lpADSIParams->prcView->left;
 rcView.bottom = lpADSIParams->prcView->bottom;
 rcView.right  = lpADSIParams->prcView->right;

 Create( hWndParent, rcView, _T("ADSI Default View"), 
         WS_VISIBLE | WS_CHILD, 0, 0 );

 hr = CreateChildView( lpADSIParams->pIUnkShellView );

 // Return our Window to Explorer
 lpADSIParams->hwndView = m_hWnd;

 // Update the Toolbar
 SetToolbars();

 // Setup the menus
 SetMenus( SVUIA_ACTIVATE_FOCUS );

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView DestroyView

STDMETHODIMP CADSIDefView::DestroyView()
{
 HRESULT hr = E_FAIL;

 if ( IsEqualGUID( m_guidCurrentView, CLSID_ADSIClassicView ))
   {
   if ( m_pIADSIClassicView )
     {
     hr = m_pIADSIClassicView->DestroyView();
     }

   // Release the Classic View Object
   m_pIADSIClassicView = NULL;
   }
 else
 if ( IsEqualGUID( m_guidCurrentView, CLSID_ADSIWebView ))
   {
   if ( m_pIADSIWebView )
     {
     hr = m_pIADSIWebView->DestroyView();
     }

   // Release the Web View Object
   m_pIADSIWebView = NULL;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView GetCurrentInfo

STDMETHODIMP CADSIDefView::GetCurrentInfo( UINT * puViewMode, 
                                           UINT * puFlags )
{
 HRESULT hr = E_FAIL;

 if ( IsEqualGUID( m_guidCurrentView, CLSID_ADSIClassicView ))
   {
   if ( m_pIADSIClassicView )
     {
     hr = m_pIADSIClassicView->GetCurrentInfo( puViewMode, puFlags );
     }
   }
 else
 if ( IsEqualGUID( m_guidCurrentView, CLSID_ADSIWebView ))
   {
   if ( m_pIADSIWebView )
     {
     hr = m_pIADSIWebView->GetCurrentInfo( puViewMode, puFlags );
     }
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView GetWindow

STDMETHODIMP CADSIDefView::GetWindow( HWND * lphwnd )
{
 _ASSERTE( NULL != lphwnd );

 *lphwnd = m_hWnd;

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView Refresh

STDMETHODIMP CADSIDefView::Refresh()
{
 HRESULT hr = E_FAIL;

 if ( IsEqualGUID( m_guidCurrentView, CLSID_ADSIClassicView ))
   {
   if ( m_pIADSIClassicView )
     {
     hr = m_pIADSIClassicView->Refresh();
     }
   }
 else
 if ( IsEqualGUID( m_guidCurrentView, CLSID_ADSIWebView ))
   {
   if ( m_pIADSIWebView )
     {
     hr = m_pIADSIWebView->Refresh();
     }
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView GetCurrentView

STDMETHODIMP CADSIDefView::GetCurrentView( GUID *pvid )
{
 *pvid = m_guidCurrentView;

 return S_OK;
}


//////////////////////////////////////////////////////////////////////////
// CADSIDefView OnActivate

STDMETHODIMP CADSIDefView::OnActivate( UINT uState )
{
 SetMenus( uState );

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView OnDeactivate

STDMETHODIMP CADSIDefView::OnDeactivate()
{
 if ( m_uState != SVUIA_DEACTIVATE )
   {
   if ( m_hMenu != NULL )
     {
     // Remove our Menus from IShellBrowser
     m_pIShellBrowser->SetMenuSB( NULL, NULL, NULL );
     m_pIShellBrowser->RemoveMenusSB( m_hMenu );

     // Destroy our Menus
     DestroyMenu( m_hMenu );
     }

   // Reset the Menu Handle
   m_hMenu = NULL;

   // Set our internal state to inactive.
   m_uState = SVUIA_DEACTIVATE;
   }

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView SetCurrentInfo

STDMETHODIMP CADSIDefView::SetCurrentInfo(UINT uViewMode, UINT uFlags)
{
 HRESULT hr = E_FAIL;

 if ( IsEqualGUID( m_guidCurrentView, CLSID_ADSIClassicView ))
   {
   if ( m_pIADSIClassicView )
     {
     hr = m_pIADSIClassicView->SetCurrentInfo( uViewMode, uFlags );
     }
   }
 else
 if ( IsEqualGUID( m_guidCurrentView, CLSID_ADSIWebView ))
   {
   if ( m_pIADSIWebView )
     {
     hr = m_pIADSIWebView->SetCurrentInfo( uViewMode, uFlags );
     }
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView CreateChildView

HRESULT CADSIDefView::CreateChildView( IUnknown *pIShellView )
{
 RECT  rcView;
 HRESULT hr = E_FAIL;

 GetClientRect( &rcView );

 if ( IsEqualGUID( m_guidCurrentView, CLSID_ADSIClassicView ))
   {
   hr = CoCreateInstance(CLSID_ADSIClassicView, 
                         NULL, 
                         CLSCTX_INPROC_SERVER, 
                         IID_IADSIClassicView, 
                         (VOID **) &m_pIADSIClassicView );

   if ( SUCCEEDED( hr ))
     {
     hr = m_pIADSIClassicView->CreateView( pIShellView,
                           (IUnknown *) m_pIShellBrowser,
                           (IUnknown *) m_pIShellFolder,
                           (UINT) m_hWnd,
                           (UINT) rcView.top,
                           (UINT) rcView.left,
                           (UINT) rcView.bottom,
                           (UINT) rcView.right,
                           m_FolderSettings.ViewMode,
                           m_FolderSettings.fFlags,
                           (UINT *) &m_hwndChild );


     if ( FAILED( hr ))
       m_pIADSIClassicView = NULL;
     }
   }
 else
 if ( IsEqualGUID( m_guidCurrentView, CLSID_ADSIWebView ))
   {
   hr = CoCreateInstance(CLSID_ADSIWebView, 
                         NULL, 
                         CLSCTX_INPROC_SERVER, 
                         IID_IADSIWebView, 
                         (VOID **) &m_pIADSIWebView );

   if ( SUCCEEDED( hr ))
     {
     hr = m_pIADSIWebView->CreateView( pIShellView,
                         (IUnknown *) m_pIShellBrowser,
                         (IUnknown *) m_pIShellFolder,
                         (UINT) m_hWnd,
                         (UINT) rcView.top,
                         (UINT) rcView.left,
                         (UINT) rcView.bottom,
                         (UINT) rcView.right,
                         m_FolderSettings.ViewMode,
                         m_FolderSettings.fFlags,
                         (UINT *) &m_hwndChild );

     if ( FAILED( hr ))
       m_pIADSIWebView = NULL;
     }
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
//
// Menu and Toolbar Functions

//////////////////////////////////////////////////////////////////////////
// CADSIDefView GetMenuFromID

HMENU CADSIDefView::GetMenuFromID( HMENU hMain, UINT uID )
{
 MENUITEMINFO miiSubMenu;

 miiSubMenu.cbSize = sizeof( MENUITEMINFO );
 miiSubMenu.fMask  = MIIM_SUBMENU;

 if ( !::GetMenuItemInfo( hMain, uID, FALSE, &miiSubMenu ))
   return NULL;

 return ( miiSubMenu.hSubMenu );
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView IsMenuSeparator

int CADSIDefView::IsMenuSeparator( HMENU hm, UINT i )
{
 return( GetMenuItemID( hm, i ) == 0 );
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView MergeMenus

UINT CADSIDefView::MergeMenus( HMENU hDstMenu, 
                               HMENU hSrcMenu, 
                               UINT uInsert, 
                               UINT uIDAdjust, 
                               UINT uIDAdjustMax, 
                               ULONG uFlags )
{
 int       nItem;
 HMENU     hSubMenu;
 BOOL      bAlreadySeparated = FALSE;
 UINT      uIDMax = uIDAdjust;
 UINT      uTemp;

 if ( !hDstMenu || !hSrcMenu )
   return( uIDMax );

 nItem = ::GetMenuItemCount( hDstMenu );
 
 if ( uInsert >= (UINT) nItem )
   {
   // We are inserting an additional popup on the menu bar (I think)
   // So, it is already separated.

   uInsert            = (UINT) nItem;
   bAlreadySeparated  = TRUE;
   }
 else 
   {
   // otherwise check to see if there is a separator between the items
   // already in the destination menu and the menu being merged in.

   bAlreadySeparated = IsMenuSeparator( hDstMenu, uInsert );
   }

 if (( uFlags & MM_ADDSEPARATOR ) && !bAlreadySeparated )
   {
   // Add a separator between the menus if requested by caller.

   ::InsertMenu( hDstMenu, 
                 uInsert, 
                 MF_BYPOSITION | MF_SEPARATOR, 
                 0, 
                 NULL );
   bAlreadySeparated = TRUE;
   }

 TCHAR     szMenuBuffer[ MAX_MENU_LENGTH ];
 MENUITEMINFO  miiSrc;

 // Go through the menu items and clone them

 for ( nItem = ::GetMenuItemCount( hSrcMenu ) - 1; nItem >= 0; nItem-- )
   {
   miiSrc.cbSize = sizeof( MENUITEMINFO );
   miiSrc.fMask  = MIIM_STATE | MIIM_ID | MIIM_SUBMENU | 
                   MIIM_CHECKMARKS | MIIM_TYPE | MIIM_DATA;

   // We need to reset this every time through the loop in case
   // menus DON'T have IDs

   miiSrc.fType       = MFT_STRING;
   miiSrc.dwTypeData  = szMenuBuffer;
   miiSrc.dwItemData  = 0;
   miiSrc.cch         = MAX_MENU_LENGTH;

   if ( !::GetMenuItemInfo( hSrcMenu, nItem, TRUE, &miiSrc ))
     continue;

   if ( miiSrc.fType & MFT_SEPARATOR )
     {
   // This is a separator; don't put two of them in a row

   if ( bAlreadySeparated )
     continue;

   if ( !::InsertMenuItem( hDstMenu, uInsert, TRUE, &miiSrc ))
     return( uIDMax );
   
   bAlreadySeparated = TRUE;
   }
 else
 if ( miiSrc.hSubMenu )
   {
   // this item has a submenu

   miiSrc.fMask &= ~MIIM_ID;

   hSubMenu    = miiSrc.hSubMenu;
   miiSrc.hSubMenu = CreatePopupMenu();

   if ( !miiSrc.hSubMenu )
     return( uIDMax );

   if ( !::InsertMenuItem( hDstMenu, uInsert, TRUE, &miiSrc ))
     return( uIDMax );

   uTemp = MergeMenus( miiSrc.hSubMenu, hSubMenu, 0, 0, 0xFFFF, uFlags );

   if ( uIDMax <= uTemp )
     uIDMax = uTemp;

   bAlreadySeparated = FALSE;
   }
 else
   {
   // This is just a regular old item Adjust the ID and check it.

   bAlreadySeparated = FALSE;

   if ( !::InsertMenuItem( hDstMenu, uInsert, TRUE, &miiSrc ))
     return( uIDMax );
   }
 } 

 // Ensure the correct number of separators at 
 // the beginning of the inserted menu items.

 if ( uInsert == 0 )
   {
   if ( bAlreadySeparated )
     ::DeleteMenu( hDstMenu, uInsert, MF_BYPOSITION );
   }
 else
   {
   if ( IsMenuSeparator( hDstMenu, uInsert - 1 ))
     {
     if ( bAlreadySeparated )
       {
       ::DeleteMenu( hDstMenu, uInsert, MF_BYPOSITION );
       }
     }
   else
     {
     if (( uFlags & MM_ADDSEPARATOR ) && !bAlreadySeparated )
       {
       // Add a separator between the menus

       ::InsertMenu( hDstMenu, 
                     uInsert, 
                     MF_BYPOSITION | MF_SEPARATOR, 
                     0, 
                     NULL );
       }
     }
   }

 return( uIDMax );
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView UpdateMenusAndToolbars

void CADSIDefView::UpdateMenusAndToolbars()
{
 long  lResult;

 if ( IsEqualGUID( m_guidCurrentView, CLSID_ADSIWebView ))
   {
   // Check the View As Web Page Menu Item
   CheckMenuItem(m_hMenu, 
                 ID_VIEW_ASWEBPAGE, 
                 MF_BYCOMMAND | MF_CHECKED );
   }
 else
   {
   CheckMenuItem( m_hMenu, 
                 ID_VIEW_ASWEBPAGE, 
                 MF_BYCOMMAND | MF_UNCHECKED );
   }

 switch( m_FolderSettings.ViewMode )
   {
   case FVM_ICON:

     m_pIShellBrowser->SendControlMsg( FCW_TOOLBAR, 
                                       TB_CHECKBUTTON, 
                                       ID_VIEW_LARGEICONS, 
                                       (LPARAM) MAKELONG( TRUE,  0 ), 
                                       (LRESULT *) &lResult );
     m_pIShellBrowser->SendControlMsg( FCW_TOOLBAR, 
                                       TB_CHECKBUTTON, 
                                       ID_VIEW_SMALLICONS, 
                                       (LPARAM) MAKELONG( FALSE, 0 ), 
                                       (LRESULT *) &lResult );
     m_pIShellBrowser->SendControlMsg( FCW_TOOLBAR, 
                                       TB_CHECKBUTTON, 
                                       ID_VIEW_LIST,       
                                       (LPARAM) MAKELONG( FALSE, 0 ), 
                                       (LRESULT *) &lResult );
     m_pIShellBrowser->SendControlMsg( FCW_TOOLBAR, 
                                       TB_CHECKBUTTON, 
                                       ID_VIEW_DETAILS,    
                                       (LPARAM) MAKELONG( FALSE, 0 ), 
                                       (LRESULT *) &lResult );

     CheckMenuItem( m_hMenu, 
                   ID_VIEW_LARGEICONS, 
                   MF_BYCOMMAND | MF_CHECKED   );
     CheckMenuItem( m_hMenu, 
                   ID_VIEW_SMALLICONS, 
                   MF_BYCOMMAND | MF_UNCHECKED );
     CheckMenuItem( m_hMenu, 
                   ID_VIEW_LIST,       
                   MF_BYCOMMAND | MF_UNCHECKED );
     CheckMenuItem( m_hMenu, 
                   ID_VIEW_DETAILS,    
                   MF_BYCOMMAND | MF_UNCHECKED );

     break;

   case FVM_SMALLICON:

     m_pIShellBrowser->SendControlMsg( FCW_TOOLBAR, 
                                       TB_CHECKBUTTON, 
                                       ID_VIEW_LARGEICONS, 
                                       (LPARAM) MAKELONG( FALSE, 0 ), 
                                       (LRESULT *) &lResult );
     m_pIShellBrowser->SendControlMsg( FCW_TOOLBAR, 
                                       TB_CHECKBUTTON, 
                                       ID_VIEW_SMALLICONS, 
                                       (LPARAM) MAKELONG( TRUE,  0 ), 
                                       (LRESULT *) &lResult );
     m_pIShellBrowser->SendControlMsg( FCW_TOOLBAR, 
                                       TB_CHECKBUTTON, 
                                       ID_VIEW_LIST,       
                                       (LPARAM) MAKELONG( FALSE, 0 ), 
                                       (LRESULT *) &lResult );
     m_pIShellBrowser->SendControlMsg( FCW_TOOLBAR, 
                                       TB_CHECKBUTTON, 
                                       ID_VIEW_DETAILS,    
                                       (LPARAM) MAKELONG( FALSE, 0 ), 
                                       (LRESULT *) &lResult );

     CheckMenuItem( m_hMenu, 
                   ID_VIEW_LARGEICONS, 
                   MF_BYCOMMAND | MF_UNCHECKED );
     CheckMenuItem( m_hMenu, 
                   ID_VIEW_SMALLICONS, 
                   MF_BYCOMMAND | MF_CHECKED   );
     CheckMenuItem( m_hMenu, 
                   ID_VIEW_LIST,       
                   MF_BYCOMMAND | MF_UNCHECKED );
     CheckMenuItem( m_hMenu, 
                   ID_VIEW_DETAILS,    
                   MF_BYCOMMAND | MF_UNCHECKED );

     break;

   case FVM_LIST:

     m_pIShellBrowser->SendControlMsg( FCW_TOOLBAR, 
                                       TB_CHECKBUTTON, 
                                       ID_VIEW_LARGEICONS, 
                                       (LPARAM) MAKELONG( FALSE, 0 ), 
                                       (LRESULT *) &lResult );
     m_pIShellBrowser->SendControlMsg( FCW_TOOLBAR, 
                                       TB_CHECKBUTTON, 
                                       ID_VIEW_SMALLICONS, 
                                       (LPARAM) MAKELONG( FALSE, 0 ), 
                                       (LRESULT *) &lResult );
     m_pIShellBrowser->SendControlMsg( FCW_TOOLBAR, 
                                       TB_CHECKBUTTON, 
                                       ID_VIEW_LIST,       
                                       (LPARAM) MAKELONG( TRUE,  0 ), 
                                       (LRESULT *) &lResult );
     m_pIShellBrowser->SendControlMsg( FCW_TOOLBAR, 
                                       TB_CHECKBUTTON, 
                                       ID_VIEW_DETAILS,    
                                       (LPARAM) MAKELONG( FALSE, 0 ), 
                                       (LRESULT *) &lResult );

     CheckMenuItem( m_hMenu, 
                   ID_VIEW_LARGEICONS, 
                   MF_BYCOMMAND | MF_UNCHECKED );
     CheckMenuItem( m_hMenu, 
                   ID_VIEW_SMALLICONS, 
                   MF_BYCOMMAND | MF_UNCHECKED );
     CheckMenuItem( m_hMenu, 
                   ID_VIEW_LIST,       
                   MF_BYCOMMAND | MF_CHECKED   );
     CheckMenuItem( m_hMenu, 
                   ID_VIEW_DETAILS,    
                   MF_BYCOMMAND | MF_UNCHECKED );

     break;

   case FVM_DETAILS:

     m_pIShellBrowser->SendControlMsg( FCW_TOOLBAR, 
                                       TB_CHECKBUTTON, 
                                       ID_VIEW_LARGEICONS, 
                                       (LPARAM) MAKELONG( FALSE, 0 ), 
                                       (LRESULT *) &lResult );
     m_pIShellBrowser->SendControlMsg( FCW_TOOLBAR, 
                                       TB_CHECKBUTTON, 
                                       ID_VIEW_SMALLICONS, 
                                       (LPARAM) MAKELONG( FALSE, 0 ), 
                                       (LRESULT *) &lResult );
     m_pIShellBrowser->SendControlMsg( FCW_TOOLBAR, 
                                       TB_CHECKBUTTON, 
                                       ID_VIEW_LIST,       
                                       (LPARAM) MAKELONG( FALSE, 0 ), 
                                       (LRESULT *) &lResult );
     m_pIShellBrowser->SendControlMsg( FCW_TOOLBAR, 
                                       TB_CHECKBUTTON, 
                                       ID_VIEW_DETAILS,    
                                       (LPARAM) MAKELONG( TRUE,  0 ), 
                                       (LRESULT *) &lResult );

     CheckMenuItem( m_hMenu, 
                   ID_VIEW_LARGEICONS, 
                   MF_BYCOMMAND | MF_UNCHECKED );
     CheckMenuItem( m_hMenu, 
                   ID_VIEW_SMALLICONS, 
                   MF_BYCOMMAND | MF_UNCHECKED );
     CheckMenuItem( m_hMenu, 
                   ID_VIEW_LIST,       
                   MF_BYCOMMAND | MF_UNCHECKED );
     CheckMenuItem( m_hMenu, 
                   ID_VIEW_DETAILS,    
                   MF_BYCOMMAND | MF_CHECKED   );

     break;
   }
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView SetMenus

VOID CADSIDefView::SetMenus( UINT uState )
{
 if ( m_uState != uState )
   {
   OnDeactivate();

   HMENU hMenu = CreateMenu();

   if ( hMenu )
     {
     HMENU              hMergeMenu;
     OLEMENUGROUPWIDTHS mwidth = { { 0, 0, 0, 0, 0, 0 } };

     m_hMenu = hMenu;

     m_pIShellBrowser->InsertMenusSB( m_hMenu, &mwidth );

     // Use our Menus When we have Focus
     hMergeMenu = ::LoadMenu( _Module.GetResourceInstance(), 
                             MAKEINTRESOURCE( IDR_SHELLMENU ));

     if ( hMergeMenu )
       {
       MergeMenus( GetMenuFromID( m_hMenu, FCIDM_MENU_VIEW  ), 
                   GetSubMenu( hMergeMenu, 2 ), 
                   (UINT) 4, 0, (UINT) 0xFFFF, NULL );
       MergeMenus( GetMenuFromID( m_hMenu, FCIDM_MENU_HELP  ), 
                   GetSubMenu( hMergeMenu, 4 ), 
                   (UINT) 0, 0, (UINT) 0xFFFF, NULL );

       ::DestroyMenu( hMergeMenu );
       }

     m_pIShellBrowser->SetMenuSB( m_hMenu, NULL, m_hWnd );
     }

   m_uState = uState;
   }

 UpdateMenusAndToolbars();
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView SetToolbars

VOID CADSIDefView::SetToolbars()
{
 TBADDBITMAP tbadd;

 static TBBUTTON tbButtons[] =  // the iBitmap elements need to be set
   {
   {  1,   ID_VIEW_LARGEICONS,  TBSTATE_ENABLED, 
           TBSTYLE_BUTTON | TBSTYLE_CHECKGROUP, 0L, (BYTE) -1 },
   {  2,   ID_VIEW_SMALLICONS,  TBSTATE_ENABLED, 
           TBSTYLE_BUTTON | TBSTYLE_CHECKGROUP, 0L, (BYTE) -1 },
   {  3,   ID_VIEW_LIST,        TBSTATE_ENABLED, 
           TBSTYLE_BUTTON | TBSTYLE_CHECKGROUP, 0L, (BYTE) -1 },
   {  4,   ID_VIEW_DETAILS,     TBSTATE_ENABLED, 
           TBSTYLE_BUTTON | TBSTYLE_CHECKGROUP, 0L, (BYTE) -1 }
   };

 // Add the bitmaps to the cabinet's toolbar (when do we remove them?)

 if ( m_iFirstBitmap == 0 )
   {
   tbadd.hInst = _Module.GetResourceInstance();
   tbadd.nID   = IDB_TOOLBAR;

   m_pIShellBrowser->SendControlMsg( FCW_TOOLBAR, 
                                     TB_ADDBITMAP, 
                                     4, 
                                     (LPARAM) &tbadd, 
                                     (LRESULT*) &m_iFirstBitmap );
   }

 // Set up the button text

 m_pIShellBrowser->SendControlMsg( FCW_TOOLBAR, 
                                   TB_ADDSTRING, 
                                   (WPARAM) NULL, 
                                   (LPARAM) szToolbars, 
                                   (LRESULT*) &tbButtons[0].iString );

 tbButtons[1].iString = tbButtons[0].iString + 1;
 tbButtons[2].iString = tbButtons[0].iString + 2;
 tbButtons[3].iString = tbButtons[0].iString + 3;

 // set the buttons' bitmap indexes then add them to the toolbar

 tbButtons[0].iBitmap = m_iFirstBitmap;
 tbButtons[1].iBitmap = m_iFirstBitmap + 1;
 tbButtons[2].iBitmap = m_iFirstBitmap + 2;
 tbButtons[3].iBitmap = m_iFirstBitmap + 3;

 m_pIShellBrowser->SetToolbarItems( tbButtons, 4, FCT_MERGE );

}

//////////////////////////////////////////////////////////////////////////
// Support for ISupportErrorInfo Interface

//////////////////////////////////////////////////////////////////////////
// CADSIDefView InterfaceSupportsErrorInfo

STDMETHODIMP CADSIDefView::InterfaceSupportsErrorInfo(REFIID riid)
{
 static const IID* arr[] = 
   {
   &IID_IADSIDefView
   };

 for (int i=0;i<sizeof(arr)/sizeof(arr[0]);i++)
   {
   if (InlineIsEqualGUID(*arr[i],riid))
     return S_OK;
   }

 return S_FALSE;
}


//////////////////////////////////////////////////////////////////////////
//
// Base Window Functions

//////////////////////////////////////////////////////////////////////////
// CADSIDefView OnSize

LRESULT CADSIDefView::OnSize( UINT uMsg, 
                              WPARAM wParam, 
                              LPARAM lParam, 
                              BOOL& bHandled)
{
 int cx, cy;

 cx = LOWORD( lParam );
 cy = HIWORD( lParam );

 if ( ::IsWindow( m_hwndChild ))
   ::SetWindowPos( m_hwndChild, NULL, 0, 0, 
                   cx, cy, SWP_NOZORDER | SWP_NOACTIVATE );

 return 0;
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView OnViewAsWebPage

LRESULT CADSIDefView::OnViewAsWebPage( WORD wNotifyCode, 
                                       WORD wID, 
                                       HWND hWndCtl, 
                                       BOOL& bHandled )
{
 // Destroy the Current View
 HRESULT hr = DestroyView();

 if ( FAILED( hr ))
   return 0;

 if ( IsEqualGUID( m_guidCurrentView, CLSID_ADSIClassicView ))
   {
   m_guidCurrentView = CLSID_ADSIWebView;
   }
 else
   {
   m_guidCurrentView = CLSID_ADSIClassicView;
   }

 CComPtr< IShellView > pIShellView;

 hr = m_pIShellBrowser->QueryActiveShellView( &pIShellView );

 if ( SUCCEEDED( hr ))
   {
   hr = CreateChildView((IUnknown *) pIShellView );
   }

 UpdateMenusAndToolbars();

 bHandled = TRUE;

 return 0;
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView OnLargeIcons

LRESULT CADSIDefView::OnLargeIcons( WORD wNotifyCode, 
                                    WORD wID, 
                                    HWND hWndCtl, 
                                    BOOL& bHandled )
{
 m_FolderSettings.ViewMode = FVM_ICON;

 SetCurrentInfo( m_FolderSettings.ViewMode, m_FolderSettings.fFlags );

 UpdateMenusAndToolbars();

 bHandled = TRUE;

 return 0;
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView OnSmallIcons

LRESULT CADSIDefView::OnSmallIcons( WORD wNotifyCode, 
                                    WORD wID, 
                                    HWND hWndCtl, 
                                    BOOL& bHandled )
{
 m_FolderSettings.ViewMode = FVM_SMALLICON;

 SetCurrentInfo( m_FolderSettings.ViewMode, m_FolderSettings.fFlags );

 UpdateMenusAndToolbars();

 bHandled = TRUE;

 return 0;
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView OnList

LRESULT CADSIDefView::OnList( WORD wNotifyCode, 
                              WORD wID, 
                              HWND hWndCtl, 
                              BOOL& bHandled )
{
 m_FolderSettings.ViewMode = FVM_LIST;

 SetCurrentInfo( m_FolderSettings.ViewMode, m_FolderSettings.fFlags );

 UpdateMenusAndToolbars();

 bHandled = TRUE;

 return 0;
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView OnDetails

LRESULT CADSIDefView::OnDetails( WORD wNotifyCode, 
                                 WORD wID, 
                                 HWND hWndCtl, 
                                 BOOL& bHandled )
{
 m_FolderSettings.ViewMode = FVM_DETAILS;

 SetCurrentInfo( m_FolderSettings.ViewMode, m_FolderSettings.fFlags );

 UpdateMenusAndToolbars();

 bHandled = TRUE;

 return 0;
}

//////////////////////////////////////////////////////////////////////////
// CADSIDefView OnAbout

LRESULT CADSIDefView::OnAbout( WORD wNotifyCode, 
                               WORD wID, 
                               HWND hWndCtl, 
                               BOOL& bHandled )
{
 CAbout DlgAbout;

 DlgAbout.DoModal();

 bHandled = TRUE;

 return 0;
}


