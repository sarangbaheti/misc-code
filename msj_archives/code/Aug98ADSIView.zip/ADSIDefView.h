//////////////////////////////////////////////////////////////////////////
//
// Filename:     ADSIDefView.h
//
// Description:  Declaration of the CADSIDefView
//
// Author(s):    Todd Daniell, Brian Daigle
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////

#ifndef __ADSIDEFVIEW_H_
#define __ADSIDEFVIEW_H_

#include "resource.h"       // main symbols

const TCHAR szToolbars[] = 
         _T("Large Icons\0Small Icons\0List\0Details\0\0");

//////////////////////////////////////////////////////////////////////////
// Flags used by the menu merging functions

#define MM_ADDSEPARATOR    0x00001000
#define MM_SUBMENUSHAVEIDS 0x00002000

// Define Maximum Menu Length for Menu Functions
#define MAX_MENU_LENGTH  256

//////////////////////////////////////////////////////////////////////////
// CADSIDefView
class CADSIDefView : 
 public CComObjectRoot,
 public CComCoClass<CADSIDefView, &CLSID_ADSIDefView>,
 public CComControl<CADSIDefView>,
 public IADSIDefView,
 public IPersistStreamInitImpl<CADSIDefView>,
 public IPersistStorageImpl<CADSIDefView>,
 public IQuickActivateImpl<CADSIDefView>,
 public IOleControlImpl<CADSIDefView>,
 public IOleObjectImpl<CADSIDefView>,
 public IOleInPlaceActiveObjectImpl<CADSIDefView>,
 public IViewObjectExImpl<CADSIDefView>,
 public IOleInPlaceObjectWindowlessImpl<CADSIDefView>,
 public IDataObjectImpl<CADSIDefView>,
 public ISupportErrorInfo,
 public IConnectionPointContainerImpl<CADSIDefView>,
 public IObjectSafetyImpl<CADSIDefView>
{
public:
 CADSIDefView();
 ~CADSIDefView();

public:

DECLARE_REGISTRY_RESOURCEID(IDR_ADSIDEFVIEW)
DECLARE_POLY_AGGREGATABLE(CADSIDefView)
DECLARE_GET_CONTROLLING_UNKNOWN()

BEGIN_COM_MAP(CADSIDefView)
 COM_INTERFACE_ENTRY(IADSIDefView)
 COM_INTERFACE_ENTRY2(IDispatch, IADSIDefView)
 COM_INTERFACE_ENTRY_IMPL(IViewObjectEx)
 COM_INTERFACE_ENTRY_IMPL_IID(IID_IViewObject2, IViewObjectEx)
 COM_INTERFACE_ENTRY_IMPL_IID(IID_IViewObject, IViewObjectEx)
 COM_INTERFACE_ENTRY_IMPL(IOleInPlaceObjectWindowless)
 COM_INTERFACE_ENTRY_IMPL_IID(IID_IOleInPlaceObject, 
                               IOleInPlaceObjectWindowless)
 COM_INTERFACE_ENTRY_IMPL_IID(IID_IOleWindow, 
                               IOleInPlaceObjectWindowless)
 COM_INTERFACE_ENTRY_IMPL(IOleInPlaceActiveObject)
 COM_INTERFACE_ENTRY_IMPL(IOleControl)
 COM_INTERFACE_ENTRY_IMPL(IOleObject)
 COM_INTERFACE_ENTRY_IMPL(IQuickActivate)
 COM_INTERFACE_ENTRY_IMPL(IPersistStorage)
 COM_INTERFACE_ENTRY_IMPL(IPersistStreamInit)
 COM_INTERFACE_ENTRY_IMPL(IDataObject)
 COM_INTERFACE_ENTRY(ISupportErrorInfo)
 COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
 COM_INTERFACE_ENTRY_IMPL(IObjectSafety)
END_COM_MAP()

BEGIN_CONNECTION_POINT_MAP(CADSIDefView)
END_CONNECTION_POINT_MAP()

BEGIN_PROPERTY_MAP(CADSIDefView)
 // Example Entries
 // PROP_ENTRY( "Property Description", dispid, clsid )
END_PROPERTY_MAP()

BEGIN_MSG_MAP(CADSIDefView)
 MESSAGE_HANDLER( WM_PAINT, OnPaint )
 MESSAGE_HANDLER( WM_GETDLGCODE, OnGetDlgCode )
 MESSAGE_HANDLER( WM_SETFOCUS, OnSetFocus )
 MESSAGE_HANDLER( WM_KILLFOCUS, OnKillFocus )
 MESSAGE_HANDLER( WM_SIZE, OnSize )
 COMMAND_HANDLER( ID_VIEW_ASWEBPAGE,     0, OnViewAsWebPage )
 COMMAND_HANDLER( ID_VIEW_LARGEICONS,    0, OnLargeIcons )
 COMMAND_HANDLER( ID_VIEW_SMALLICONS,    0, OnSmallIcons )
 COMMAND_HANDLER( ID_VIEW_LIST,          0, OnList )
 COMMAND_HANDLER( ID_VIEW_DETAILS,       0, OnDetails )
 COMMAND_HANDLER( ID_HELP_ABOUTADSIVIEW, 0, OnAbout )
END_MSG_MAP()

 LRESULT OnSize( UINT uMsg, 
                 WPARAM wParam, 
                 LPARAM lParam, 
                 BOOL& bHandled );
 LRESULT OnViewAsWebPage( WORD wNotifyCode, 
                          WORD wID, 
                          HWND hWndCtl, 
                          BOOL& bHandled );
 LRESULT OnLargeIcons( WORD wNotifyCode, 
                       WORD wID, 
                       HWND hWndCtl, 
                       BOOL& bHandled );
 LRESULT OnSmallIcons( WORD wNotifyCode, 
                       WORD wID, 
                       HWND hWndCtl, 
                       BOOL& bHandled );
 LRESULT OnList( WORD wNotifyCode, 
                 WORD wID, 
                 HWND hWndCtl, 
                 BOOL& bHandled );
 LRESULT OnDetails( WORD wNotifyCode, 
                    WORD wID, 
                    HWND hWndCtl, 
                    BOOL& bHandled );
 LRESULT OnAbout( WORD wNotifyCode, 
                  WORD wID, 
                  HWND hWndCtl, 
                  BOOL& bHandled );

// IADSIDefView
public:
 STDMETHOD(CreateView)( PADSI_CVW2PARAMS lpParams, 
                        IUnknown * pIShellFolder );
 STDMETHOD(DestroyView)();
 STDMETHOD(Refresh)();
 STDMETHOD(GetCurrentInfo)( UINT * puViewMode, UINT * puFlags );
 STDMETHOD(SetCurrentInfo)(UINT uViewMode, UINT uFlags);
 STDMETHOD(OnActivate)(UINT uState);
 STDMETHOD(OnDeactivate)(void);
 STDMETHOD(GetWindow)(HWND *lphwnd);
 STDMETHOD(GetCurrentView)(GUID *pvid);

// ISupportsErrorInfo
public:
 STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IViewObjectEx
public:
 STDMETHOD(GetViewStatus)(DWORD* pdwStatus)
 {
   *pdwStatus = VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE;
   return S_OK;
 }

// Internal Methods
private:
 void    ClearMemberVar();

 HRESULT   CreateChildView( IUnknown *pIUnkShellView );

 // Menu and Toolbar Processing Functions
 UINT    MergeMenus( HMENU hDstMenu, 
                     HMENU hSrcMenu, 
                     UINT uInsert, 
                     UINT uIDAdjust, 
                     UINT uIDAdjustMax, 
                     ULONG uFlags );
 int     IsMenuSeparator( HMENU hm, UINT i );
 HMENU   GetMenuFromID( HMENU hMain, UINT uID );
 VOID    SetMenus( UINT uState );
 VOID    SetToolbars();
 void    UpdateMenusAndToolbars();

private:
 //Current Shell Browser Interface
 CComQIPtr< IShellBrowser, &IID_IShellBrowser> m_pIShellBrowser;
 //Current Shell Folder  Interface
 CComQIPtr< IShellFolder,  &IID_IShellFolder>  m_pIShellFolder;

 CComPtr< IADSIClassicView > m_pIADSIClassicView;
 CComPtr< IADSIWebView >   m_pIADSIWebView;

 int                 m_iFirstBitmap;
 FOLDERSETTINGS      m_FolderSettings;     //Folder Settings
 SHELLVIEWID         m_guidCurrentView;
 HMENU               m_hMenu;
 UINT                m_uState;
 BOOL                m_bWEBView;
 RECT                m_rcParent;
 HWND                m_hwndChild;
};

#endif //__ADSIDEFVIEW_H_
