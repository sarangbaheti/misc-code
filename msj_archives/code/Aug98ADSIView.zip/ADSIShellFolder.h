//////////////////////////////////////////////////////////////////////////
//
// Filename:   ADSIShellFolder.h
//
// Description:  The shell folder implementation
//
// Author(s):    Todd Daniell, Dave Mims, Doug Bahr
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////
#ifndef _ADSISHELLFOLDER_H
#define _ADSISHELLFOLDER_H

#include "resource.h"

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define STRING_APPROVED_SECTION    _T("\
SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Shell Extensions\\Approved")

#define STRING_DESKTOP_SECTION     _T("\
SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Desktop\\\
Namespace\\{01313608-A241-11D1-9E8F-00A0C93C9527}")

#define STRING_SHELLFOLDER_SECTION _T("\
CLSID\\{01313608-A241-11D1-9E8F-00A0C93C9527}\\ShellFolder")

#define STRING_ATTRIBUTES_ENTRY    _T("Attributes")

#define STRING_CLSID               _T("\
{01313608-A241-11D1-9E8F-00A0C93C9527}")

#define STRING_ADSIView            _T("ADSIView")

//////////////////////////////////////////////////////////////////////////
// CADSIShellFolder

class CADSIShellFolder : 
 public CComObjectRoot,
 public CComCoClass<CADSIShellFolder,&CLSID_ADSIShellFolder>,
 public IADSIShellFolder,
 public IShellFolder,
 public IPersistFolder2
{
private:
 string m_strObjectPath;

public:
 CADSIShellFolder();
BEGIN_COM_MAP(CADSIShellFolder)
 COM_INTERFACE_ENTRY(IShellFolder)
 COM_INTERFACE_ENTRY(IPersistFolder)
 COM_INTERFACE_ENTRY(IPersistFolder2)
END_COM_MAP()

 static HRESULT WINAPI UpdateRegistry( BOOL bRegister )
 {
   // Get the OS information.

   OSVERSIONINFO OsVersionInfo;
   BOOL      bWindowsNT = FALSE;

   // Initialize the size of OsVersionInfo
   OsVersionInfo.dwOSVersionInfoSize = sizeof( OSVERSIONINFO );

   // Get the OS Version
   if ( ::GetVersionEx( &OsVersionInfo ))
     {
     // Are we running NT ?
     if ( OsVersionInfo.dwPlatformId == VER_PLATFORM_WIN32_NT )
       bWindowsNT = TRUE;
     }
   else
     {
     return E_FAIL;
     }

   // Perform the default registry functions.
   HRESULT hResult = _Module.UpdateRegistryFromResource(
                             IDR_ADSIShellFolder,
                             bRegister );

   // Note : ATL Registry Scripts/Classes do not support the 
   //        writing of Binary Values so, we must write the 
   //        Registry Value using Win32.

   if ( bRegister )
     {
     if ( hResult == NOERROR )
       {
       DWORD     dwDisposition = NULL;
       HKEY      hSectionKey   = NULL;

       if ( bWindowsNT )
         {
         // Add the Extension to the Shell Extensions Approved List...
         // The RISC Version of VC++ 5.x does not support HKLM in its 
         // ATL scripts...

         if ( ERROR_SUCCESS == ::RegCreateKeyEx( HKEY_LOCAL_MACHINE, 
                         (LPCTSTR) STRING_APPROVED_SECTION, 
                                   NULL, 
                             REG_NONE, 
                             REG_OPTION_NON_VOLATILE, 
                             KEY_WRITE | KEY_READ, 
                             NULL, 
                             &hSectionKey, 
                             &dwDisposition ))
           {
           // If the Section Key was created or opened, then write the 
           // 'ShellFolder' Value
           if ( hSectionKey )
             {
             if ( ERROR_SUCCESS != ::RegSetValueEx( hSectionKey,
                                                   (LPCTSTR)STRING_CLSID,
                                                   NULL,
                                                   REG_SZ,
                                                   ( CONST BYTE * )
                                                   (LPCTSTR)
                                                   STRING_ADSIView,
                                                   _tcslen(
                                                   STRING_ADSIView )))
               {
               // If we fail to write the Value, then Fail the regstration.
               hResult = E_FAIL;
               }
             }
           else
             {
             hResult = E_FAIL;
             }
           }

         // Close the key
         ::RegCloseKey( hSectionKey );

         // Reset the Key Value
         hSectionKey = NULL;
         }

       // Build the ADSIView Root Key ( This is done 
       // here for Alpha Support.  The RISC Version of VC++ 5.x 
       // does not support HKLM in its ATL scripts...

       if ( ERROR_SUCCESS != ::RegCreateKeyEx( HKEY_LOCAL_MACHINE, 
                       (LPCTSTR) STRING_DESKTOP_SECTION, 
                                 NULL, 
                           REG_NONE, 
                           REG_OPTION_NON_VOLATILE, 
                           KEY_WRITE | KEY_READ, 
                           NULL, 
                           &hSectionKey, 
                           &dwDisposition ))
         {
         return E_FAIL;
         }

       // Close the Key
       ::RegCloseKey( hSectionKey );

       // Reset the hSectionKey Value
       hSectionKey = NULL;

       // Generate the 'ShellFolder\Attributes' Value here.
       // This is a Binary Registry Value

       if ( ERROR_SUCCESS == ::RegCreateKeyEx( HKEY_CLASSES_ROOT, 
                       (LPCTSTR) STRING_SHELLFOLDER_SECTION, 
                                 NULL, 
                           REG_NONE, 
                           REG_OPTION_NON_VOLATILE, 
                           KEY_WRITE | KEY_READ, 
                           NULL, 
                           &hSectionKey, 
                           &dwDisposition ))
         {
         BYTE  btValue[] = { 0x40, 0x01, 0x00, 0xA0 };
         DWORD dwValueSize = 4;

         // If the Section Key was created or opened, 
         // then write the 'ShellFolder' Value
         if ( hSectionKey )
           {
           if ( ERROR_SUCCESS != ::RegSetValueEx(
                         hSectionKey,
                         (LPCTSTR) STRING_ATTRIBUTES_ENTRY,
                         NULL,
                         REG_BINARY,
                         ( CONST BYTE * )&btValue,
                         dwValueSize ))
             {
             // If we fail to write the Value, 
             // then Fail the regstration.
             hResult = E_FAIL;
             }
           }
         else
           hResult = E_FAIL;
         }

       // Close the Key
       ::RegCloseKey( hSectionKey );
       }
     }
   else
     {
     // If this is Windows NT...
     if ( bWindowsNT )
       {
       DWORD     dwDisposition = NULL;
       HKEY      hSectionKey   = NULL;

       // Remove the Extension to the Shell Extensions Approved List...
       // The RISC Version of VC++ 5.x does not
       // support HKLM in its ATL scripts...

       if ( ERROR_SUCCESS == ::RegCreateKeyEx( HKEY_LOCAL_MACHINE, 
                       (LPCTSTR) STRING_APPROVED_SECTION, 
                                 NULL, 
                           REG_NONE, 
                           REG_OPTION_NON_VOLATILE, 
                           KEY_WRITE | KEY_READ, 
                           NULL, 
                           &hSectionKey, 
                           &dwDisposition ))
         {
         // If the Section Key was created or opened,
         // then write the 'ShellFolder' Value
         if ( hSectionKey )
           {
           if ( ERROR_SUCCESS != ::RegDeleteValue(
                   hSectionKey, (LPCTSTR) STRING_CLSID ))
             {
             // If we fail to write the Value, then Fail the regstration.
             hResult = E_FAIL;
             }
           else
             {
             hResult = E_FAIL;
             }
           }

         // Close the key
         ::RegCloseKey( hSectionKey );

         // Reset the Key Value
         hSectionKey = NULL;
         }
       }

     // Unregister the ADSIView Root Key
     if ( ERROR_SUCCESS != ::RegDeleteKey( HKEY_LOCAL_MACHINE, 
                           (LPCTSTR) STRING_DESKTOP_SECTION ))
       {
       hResult = E_FAIL;
       }

     }

   return hResult;
 }

// IADSIShellFolder
public:
    // *** IShellFolder methods ***
    STDMETHOD(ParseDisplayName) ( HWND hwndOwner,
                                 LPBC pbcReserved,
                                 LPOLESTR lpszDisplayName,
                                 ULONG * pchEaten,
                                 LPITEMIDLIST * ppidl,
                                 ULONG *pdwAttributes);
    STDMETHOD(EnumObjects)   ( HWND hwndOwner,
                               DWORD grfFlags,
                               LPENUMIDLIST * ppenumIDList);
    STDMETHOD(BindToObject)     ( LPCITEMIDLIST pidl,
                                 LPBC pbcReserved,
                                 REFIID riid,
                                 LPVOID * ppvOut);
    STDMETHOD(BindToStorage)    ( LPCITEMIDLIST pidl,
                                 LPBC pbcReserved,
                                 REFIID riid,
                                 LPVOID * ppvObj);
    STDMETHOD(CompareIDs)       ( LPARAM lParam,
                                 LPCITEMIDLIST pidl1,
                                 LPCITEMIDLIST pidl2 );
    STDMETHOD(CreateViewObject) ( HWND hwndOwner,
                                 REFIID riid,
                                 LPVOID * ppvOut);
    STDMETHOD(GetAttributesOf)  ( UINT cidl,
                                 LPCITEMIDLIST * apidl,
                                 ULONG * rgfInOut);
    STDMETHOD(GetUIObjectOf)    ( HWND hwndOwner,
                                 UINT cidl,
                                 LPCITEMIDLIST * apidl,
                                 REFIID riid,
                                 UINT * prgfInOut,
                                 LPVOID * ppvOut);
    STDMETHOD(GetDisplayNameOf) ( LPCITEMIDLIST pidl,
                                 DWORD uFlags,
                                 LPSTRRET lpName);
    STDMETHOD(SetNameOf)        ( HWND hwndOwner,
                                 LPCITEMIDLIST pidl,
                                 LPCOLESTR lpszName,
                                 DWORD uFlags,
                                 LPITEMIDLIST * ppidlOut);

    // *** IPersist methods ***
    STDMETHOD(GetClassID)( LPCLSID lpClassID );

    // *** IPersistFolder methods ***
    STDMETHOD(Initialize)( LPCITEMIDLIST pidl );

    // *** IPersistFolder2 methods ***
    STDMETHOD(GetCurFolder)( LPITEMIDLIST *ppidl );
};

#endif // #ifndef _ADSISHELLFOLDER_H
