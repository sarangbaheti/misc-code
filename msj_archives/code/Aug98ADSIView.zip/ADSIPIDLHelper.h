//////////////////////////////////////////////////////////////////////////
//
// Filename:     ADSIPIDLHelper.h
//
// Description:  ADSI IDList Helder
//
// Author(s):    Doug Bahr
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////
#ifndef _ADSIPIDLHELPER_H
#define _ADSIPIDLHELPER_H

// include the header file for the active directory
#include "activeds.h"

// include the STL list header
#include <string>
using namespace std;

//////////////////////////////////////////////////////////////////////////
// predeclarations
class CADSIPiddleList;
struct EXTRA_OBJECT_PIDL;
struct ADSI_IDLIST;

//////////////////////////////////////////////////////////////////////////
// CADSIPIDLHelper
class CADSIPIDLHelper
{
 ///////////////////////////////////
 // construction / destruction
public:
 CADSIPIDLHelper();
 ~CADSIPIDLHelper();
private:
 ///////////////////////////////////
 // Methods
 LPITEMIDLIST        Next(LPCITEMIDLIST pIDL);
 LPCITEMIDLIST       Last(LPCITEMIDLIST pIDL);
 DWORD               GetSize(LPCITEMIDLIST pIDL);
 HRESULT             Create(UINT cbSize,LPITEMIDLIST & pNewIDL);

 BOOL                IsADSIIDList(LPCITEMIDLIST pIDList);
 EXTRA_OBJECT_PIDL * GetExtraPidlInfo(ADSI_IDLIST * pObjectInfo);
 EXTRA_OBJECT_PIDL * GetExtraPidlInfo(LPCITEMIDLIST pIDList);
 ADSI_IDLIST *       GetPidlInfo(LPCITEMIDLIST pIDList);
 DWORD               GetAttributesFromIDList(LPCITEMIDLIST pIDList);

public:
 HRESULT     Destroy(LPITEMIDLIST & pIDL);
 HRESULT     CopyPIDL(LPCITEMIDLIST pIDL,LPITEMIDLIST & pNewIDL);
 HRESULT     GetADSIObject(LPCTSTR pszADSIPath,IADs * & pADSIObject);

 HRESULT     GetIDListOfADSIObject(LPCTSTR pszADSIPath,
                                   LPITEMIDLIST & pIDList,
                                   BOOL & bIsContainer);
 HRESULT     GetIDListOfADSIObject(IADs * pADSIObject,
                                   LPITEMIDLIST & pIDList,
                                   BOOL & bIsContainer);

 HRESULT     GetEnumeratorOfADSIContainer(IADsContainer * pADSIContainer,
                                           DWORD dwFlags,
                                           CADSIPiddleList * & pIDList);
 HRESULT     GetEnumeratorOfADSIContainer(LPCTSTR pszADSIPath,
                                           DWORD dwFlags,
                                           CADSIPiddleList * & pIDList);

 HRESULT     GetTitleFromIDList(LPCITEMIDLIST pIDL,
                                 DWORD uFlags,
                                 LPSTRRET lpName);
 HRESULT     GetADSIPathFromIDList(LPCITEMIDLIST pIDL,
                                   string & strPath);
 HRESULT     CompareIDs(LPCITEMIDLIST pidl1,
                         LPCITEMIDLIST pidl2);
 HRESULT     GetAttributesOf(UINT cidl,
                             LPCITEMIDLIST * apidl,
                             ULONG * rgfInOut );

 HRESULT     GetIconFromIDList(LPCITEMIDLIST pIDL,
                               DWORD & dwIconID);
 void        FigureOutWhatIconToUse(IADs * pADSIObject,
                                     DWORD & dwOneToUse);
};

//////////////////////////////////////////////////////////////////////////
// extern the global instance, since this is thread safe
// you only need one instance

extern CADSIPIDLHelper g_ADSIPIDLHelper;

#endif //_ADSIPIDLHELPER_H
