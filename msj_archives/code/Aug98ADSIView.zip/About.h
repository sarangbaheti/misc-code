//////////////////////////////////////////////////////////////////////////
//
// Filename:     About.h
//
// Description:  About box dialog header file
//
// Author(s):    Todd Daniell
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////
// About.h : Declaration of the CAbout

#ifndef __ABOUT_H_
#define __ABOUT_H_

#include "resource.h"       // main symbols

//////////////////////////////////////////////////////////////////////////
// CAbout
class CAbout : public CDialogImpl<CAbout> 
{
 public: CAbout(); ~CAbout();

 enum { IDD = IDD_ABOUT };

 BEGIN_MSG_MAP(CAbout)
  MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
  COMMAND_ID_HANDLER(IDOK, OnOK)
  COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
 END_MSG_MAP()

 LRESULT OnInitDialog( UINT uMsg,
                       WPARAM wParam,
                       LPARAM lParam,
                       BOOL& bHandled);

 LRESULT OnOK( WORD wNotifyCode,
               WORD wID,
               HWND hWndCtl,
               BOOL& bHandled);

 LRESULT OnCancel( WORD wNotifyCode,
                   WORD wID,
                   HWND hWndCtl,
                   BOOL& bHandled);
};

#endif //__ABOUT_H_
