//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ADSIView.rc
//
#define IDS_PROJNAME                    100
#define IDS_ADSISHELLFOLDER_DESC        101
#define IDR_ADSIShellFolder             102
#define IDS_ADSISHELLVIEW_DESC          103
#define IDR_ADSIShellView               104
#define IDS_ADSISHELLVIEW2_DESC         105
#define IDR_ADSIShellView2              106
#define IDS_ADSIENUMIDLIST_DESC         107
#define IDR_ADSIEnumIDList              108
#define IDS_COLUMN_NAME                 108
#define IDS_COLUMN_ADSIPATH             109
#define IDS_COLUMN_GUID                 110
#define IDS_COLUMN_CLASS                111
#define IDS_COLUMN_SCHEMA               112
#define IDS_COLUMN_PATHTOPARENT         113
#define IDR_ADSIDEFVIEW                 114
#define IDS_ADSIWEBVIEW_DESC            115
#define IDR_ADSIWebView                 116
#define IDS_ADSICLASSICVIEW_DESC        117
#define IDR_ADSIClassicView             118
#define IDS_ADSIVIEWOBJECT_DESC         119
#define IDR_ADSIViewObject              120
#define IDS_LARGEICON                   120
#define IDS_SMALLICON                   121
#define IDS_LIST                        122
#define IDS_DETAILS                     123
#define IDD_ABOUT                       124
#define IDI_WORLD                       203
#define IDI_DIRECTORY_TREE              204
#define IDI_GEARS                       205
#define IDI_COMPUTER_NETWORK            206
#define IDI_COMPUTER                    208
#define IDR_SHELLMENU                   210
#define IDB_TOOLBAR                     211
#define IDI_GLOBAL_GROUP                213
#define IDI_GROUP                       214
#define IDI_UNKNOWN                     216
#define IDI_USER                        217
#define ID_HELP_ABOUTADSIVIEW           6000
#define ID_VIEW_ASWEBPAGE               6001
#define ID_VIEW_LARGEICONS              6002
#define ID_VIEW_SMALLICONS              6003
#define ID_VIEW_LIST                    6004
#define ID_VIEW_DETAILS                 6005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        226
#define _APS_NEXT_COMMAND_VALUE         6006
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           125
#endif
#endif
