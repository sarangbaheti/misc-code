//////////////////////////////////////////////////////////////////////////
//
// Filename:     ListView32.cpp
//
// Description:  Implementation of the CListView32 class.
//             
// Author(s):    Dave Mims
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ListView32.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////////
// CListView32 constructor

CListView32::CListView32(LPLISTVIEW32EVENTS lpListView32Events )
       :m_wndListControl(WC_LISTVIEW, this, DW_MSGMAPID_LISTCONTROL)
{
 ClearMemberVar();

 m_lpListView32Events = lpListView32Events;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 destructor

CListView32::~CListView32()
{
 ClearMemberVar();
}

//////////////////////////////////////////////////////////////////////////
// CListView32 Utils

void CListView32::ClearMemberVar() 
{ 
 m_bAutoFitItemText          = TRUE;
 m_iCountColumns             = 0;
 m_hImageListLarge           = NULL;
 m_hImageListSmall           = NULL;
 m_lpdwHICONsInImageList     = NULL;
 m_dwCountHICONsInImageList  = 0;
 m_lpListView32Events        = NULL;
 m_lInitialView              = LVS_REPORT;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 LVCOLUMNSet

void CListView32::LVCOLUMNSet( int iIndexCol, 
                               LPCTSTR lpctstrText, 
                               int iWidth, 
                               int iSubItem, 
                               int iFormat, 
                               LV_COLUMN& lvColumn)
{
 // if iWidth is -1, then the width will 
 // be based on the text string length
 // if iSubItem is -1, then the column 
 // index will be used

 ASSERT(NULL != lpctstrText);

 lvColumn.mask         = LVCF_FMT|LVCF_SUBITEM|LVCF_TEXT|LVCF_WIDTH;
 lvColumn.fmt          = iFormat;
 lvColumn.cx           = ((-1 == iWidth)?ListView_GetStringWidth(
                                       m_wndListControl, lpctstrText)
                                       :iWidth);
 lvColumn.pszText      = (LPTSTR)lpctstrText;
 lvColumn.cchTextMax   = ((NULL == lpctstrText)?0:lstrlen(lpctstrText));
 lvColumn.iSubItem     = ((-1 == iSubItem)?iIndexCol:iSubItem);
}

//////////////////////////////////////////////////////////////////////////
// CListView32 AutoFitColumn

void CListView32::AutoFitColumn(int iIndexCol, LPCTSTR lpctstrText)
{
 // Sanity Check - This method should only 
 // be called with Auto Fit is turned on
 ASSERT(m_bAutoFitItemText);
 ASSERT(NULL != lpctstrText);

 // Verify that we are currently in the Report
 // View, if not do nothing and return success
 if (ViewGet() != LVS_REPORT)
   {
   return;
   }

 // What is the Width of the current column
 int iWidthColumn = 0;
 HRESULT hr = ColumnWidthGet(iIndexCol, iWidthColumn);
 if (FAILED(hr))
   {
   ASSERT(0);
   return;
   }

 // What is the width needed for the current item text
 int iWidthItem = ListView_GetStringWidth(m_wndListControl, lpctstrText);

 // NOTE:  The ListView_GetStringWidth macro returns the 
 //        exact width, in pixels, of the specified string. 
 //        If you use the returned string width as the 
 //        column width in a call to the ListView_SetColumnWidth 
 //        macro, the string will be truncated. To get the 
 //        column width that can contain the string 
 //        without truncating it, you must add padding to the 
 //        returned string width.  So let's pad a few pixels...
 iWidthItem += 20;

 if (iWidthItem > iWidthColumn)
   {
   hr = ColumnWidthSet(iIndexCol, iWidthItem);
   if (FAILED(hr))
     {
     ASSERT(0);
     return;
     }
   }
}

//////////////////////////////////////////////////////////////////////////
// Interface

//////////////////////////////////////////////////////////////////////////
// CListView32 CreateEx

HWND CListView32::CreateEx( HWND hWndParent,
                            RECT& rcPos,
                            long lInitialView)
{
 ASSERT( (LVS_ICON == lInitialView)      || 
         (LVS_REPORT == lInitialView)    || 
         (LVS_SMALLICON == lInitialView) ||
         (LVS_LIST == lInitialView));

 // Track the initial list view
 m_lInitialView = lInitialView;

 // Attempt to create the window
 return Create(hWndParent, rcPos);
}

//////////////////////////////////////////////////////////////////////////
// CListView32 StyleSet

void CListView32::StyleSet(long lStyle)
{
 m_wndListControl.SetWindowLong(GWL_STYLE, lStyle);
}

//////////////////////////////////////////////////////////////////////////
// CListView32 StyleGet

long CListView32::StyleGet()
{
 return m_wndListControl.GetWindowLong(GWL_STYLE);
}

//////////////////////////////////////////////////////////////////////////
// CListView32 ViewSet

void CListView32::ViewSet(long lView)
{
 ASSERT( (LVS_ICON == lView)     ||
         (LVS_REPORT == lView)   ||
         (LVS_SMALLICON == lView)||
         (LVS_LIST == lView));

 // Remove the current view from the window style
 long lStyle = StyleGet();
 if (lStyle & LVS_ICON)
   {
   lStyle &= (~LVS_ICON);
   }

 if (lStyle & LVS_REPORT)
   {
   lStyle &= (~LVS_REPORT);
   }

 if (lStyle & LVS_SMALLICON)
   {
   lStyle &= (~LVS_SMALLICON);
   }

 if (lStyle & LVS_LIST)
   {
   lStyle &= (~LVS_LIST);
   }

 // Add the new Style
 lStyle |= lView;

 // Update the Window Style with the new View
 StyleSet(lStyle);
}

//////////////////////////////////////////////////////////////////////////
// CListView32 ViewGet

long CListView32::ViewGet()
{
 // Get the current style
 long lStyle = StyleGet();

 if (LVS_ICON == (lStyle & LVS_TYPEMASK))
   {
   return LVS_ICON;
   }

 if (LVS_REPORT == (lStyle & LVS_TYPEMASK))
   {
   return LVS_REPORT;
   }

 if (LVS_SMALLICON == (lStyle & LVS_TYPEMASK))
   {
   return LVS_SMALLICON;
   }

 if (LVS_LIST == (lStyle & LVS_TYPEMASK))
   {
   return LVS_LIST;
   }

 return -1;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 ColumnAdd

HRESULT  CListView32::ColumnAdd( LPCTSTR lpctstrColumnHeading, 
                                 int iWidth, 
                                 int iSubItem, 
                                 int iFormat )
{
 return ColumnInsert( m_iCountColumns, 
                      lpctstrColumnHeading, 
                      iWidth, 
                      iSubItem, 
                      iFormat );
}

//////////////////////////////////////////////////////////////////////////
// CListView32 ColumnInsert

HRESULT  CListView32::ColumnInsert( int iIndexCol, 
                                    LPCTSTR lpctstrColumnHeading, 
                                    int iWidth, 
                                    int iSubItem, 
                                    int iFormat )
{
 LV_COLUMN lvColumn = { 0 }; 

 LVCOLUMNSet( iIndexCol, 
              lpctstrColumnHeading, 
              iWidth, 
              iSubItem, 
              iFormat, 
              lvColumn );

 if (-1 == ListView_InsertColumn( m_wndListControl, 
                                  iIndexCol, 
                                  &lvColumn ))
   {
   ASSERT(0);
   return E_FAIL;
   }

 ++m_iCountColumns;

 // Should we update the width of the column to fit the text
 if (m_bAutoFitItemText)
   {
   AutoFitColumn(iIndexCol, lpctstrColumnHeading);
   }
 
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 ColumnUpdate

HRESULT  CListView32::ColumnUpdate( int iIndexCol, 
                                    LPCTSTR lpctstrColumnHeading, 
                                    int iWidth, 
                                    int iSubItem, 
                                    int iFormat )
{
 ASSERT((0 <= iIndexCol) && (iIndexCol < m_iCountColumns));

 LV_COLUMN lvColumn = { 0 }; 
 LVCOLUMNSet( iIndexCol, 
              lpctstrColumnHeading, 
              iWidth, 
              iSubItem, 
              iFormat, 
              lvColumn );

 if (!ListView_SetColumn(m_wndListControl, iIndexCol, &lvColumn))
   {
   ASSERT(0);
   return E_FAIL;
   }

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 ColumnRemoveAt

HRESULT  CListView32::ColumnRemoveAt(int iIndexCol)
{
 ASSERT((0 <= iIndexCol) && (iIndexCol < m_iCountColumns));

 if (!ListView_DeleteColumn(m_wndListControl, iIndexCol))
   {
   ASSERT(0);
   return E_FAIL;
   }

 --m_iCountColumns;

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 ColumnRemoveAll

HRESULT  CListView32::ColumnRemoveAll()
{
 for (int iIndexCol = (m_iCountColumns - 1); iIndexCol >= 0; --iIndexCol)
   {
   HRESULT hr = ColumnRemoveAt(iIndexCol);
   if (FAILED(hr))
     {
     ASSERT(0);
     return hr;
     }
   }

 ASSERT(m_iCountColumns == 0);

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 ColumnWidthSet

HRESULT  CListView32::ColumnWidthSet(int iIndexCol, int  iWidth)
{
 ASSERT((0 <= iIndexCol) && (iIndexCol < m_iCountColumns));

 if (!ListView_SetColumnWidth(m_wndListControl, iIndexCol, iWidth))
   {
   ASSERT(0);
   return E_FAIL;
   }

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 ColumnWidthGet

HRESULT  CListView32::ColumnWidthGet(int iIndexCol, int& iWidth)
{
 ASSERT((0 <= iIndexCol) && (iIndexCol < m_iCountColumns));

 iWidth = ListView_GetColumnWidth(m_wndListControl, iIndexCol);

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 RowCount

int CListView32::RowCount()
{
 return ListView_GetItemCount(m_wndListControl);
}

//////////////////////////////////////////////////////////////////////////
// CListView32 RowItemSet

HRESULT  CListView32::RowItemSet( int iIndexRow, 
                                  int iIndexCol, 
                                  LPCTSTR lpctstrItem, 
                                  LPARAM lParam, 
                                  int iImage, 
                                  UINT nState, 
                                  UINT nStateMask)
{
 ASSERT((0 <= iIndexCol) && (iIndexCol < m_iCountColumns));
 ASSERT(0 <= iIndexRow);

 // Setup the mask
 UINT nMask = LVIF_TEXT;
 
 if (lParam != NULL)  
   {
   nMask |= LVIF_PARAM;
   }

 if (iImage != -1)
   {
   nMask |= LVIF_IMAGE;
   }

 if (nState != NULL)
   {
   nMask |= LVIF_STATE;
   }

 // Setup the ITEM structure that specifies what is to be added
 LV_ITEM lvItem    = { 0 };
 lvItem.mask       = nMask;
 lvItem.iItem      = iIndexRow;
 lvItem.iSubItem   = iIndexCol;
 lvItem.state      = nState;
 lvItem.stateMask  = nStateMask;
 lvItem.pszText    = (LPTSTR)lpctstrItem;
 lvItem.cchTextMax = ((NULL == lpctstrItem)?0:lstrlen(lpctstrItem));
 lvItem.iImage     = iImage;
 lvItem.lParam     = lParam;

 // Attempt to add the Row to the List control at the specified index
 // NOTE:  if for the first column (ie. the row is being added) then 
 // Insert the item otherwise add/set the item data
 if(!((0 == iIndexCol)?
       (BOOL)(-1 != ListView_InsertItem(m_wndListControl, &lvItem)):
                    ListView_SetItem(m_wndListControl, &lvItem)))
   {
   ASSERT(0);
   return E_FAIL;
   }

 // Should we update the width of the column to fit the text
 if (m_bAutoFitItemText)
   {
   AutoFitColumn(iIndexCol, lpctstrItem);
   }

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 RowItemGet

HRESULT  CListView32::RowItemGet( int iIndexRow, 
                                  int iIndexCol, 
                                  LPTSTR lptstrData, 
                                  DWORD dwDataSize )
{
 ASSERT((0 <= iIndexCol) && (iIndexCol < m_iCountColumns));
 ASSERT(0 <= iIndexRow);

 // Setup the ITEM structure that specifies what is to be retrieved
 LV_ITEM lvItem    = { 0 };
 lvItem.mask       = LVIF_TEXT;
 lvItem.iItem      = iIndexRow;
 lvItem.iSubItem   = iIndexCol;
 lvItem.state      = NULL;
 lvItem.stateMask  = NULL;
 lvItem.pszText    = lptstrData;
 lvItem.cchTextMax = dwDataSize;
 lvItem.iImage     = -1;
 lvItem.lParam     = NULL;

 if (!ListView_GetItem(m_wndListControl, &lvItem))
   {
   ASSERT(0);
   return E_FAIL;
   }

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 RowRemove

HRESULT  CListView32::RowRemove(int iIndexRow)
{
 ASSERT(0 <= iIndexRow);

 if (!ListView_DeleteItem(m_wndListControl, iIndexRow))
   {
   ASSERT(0);
   return E_FAIL;
   }

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 RowRemoveAll

HRESULT  CListView32::RowRemoveAll()
{
 if (!ListView_DeleteAllItems(m_wndListControl))
   {
   ASSERT(0);
   return E_FAIL;
   }

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 RowLPARAMSet

HRESULT  CListView32::RowLPARAMSet(int iIndexRow, LPARAM lParam)
{
 ASSERT(0 <= iIndexRow);

 // Setup the ITEM structure that specifies what is to be set
 LV_ITEM lvItem  = { 0 };

 lvItem.mask   = LVIF_PARAM;
 lvItem.iItem  = iIndexRow;
 lvItem.lParam = lParam;

 if (!ListView_SetItem(m_wndListControl, &lvItem))
   {
   ASSERT(0);
   return E_FAIL;
   }

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 RowLPARAMGet

HRESULT  CListView32::RowLPARAMGet(int iIndexRow, LPARAM& lParam)
{
 ASSERT(0 <= iIndexRow);

 // Setup the ITEM structure that specifies what is to be retrieved
 LV_ITEM lvItem  = { 0 };

 lvItem.mask   = LVIF_PARAM;
 lvItem.iItem  = iIndexRow;
 lvItem.lParam = NULL;

 if (!ListView_GetItem(m_wndListControl, &lvItem))
   {
   ASSERT(0);
   return E_FAIL;
   }

 lParam = lvItem.lParam;

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 RowStateSet

HRESULT CListView32::RowStateSet(int iIndexRow, UINT nMask, UINT nState)
{
 ASSERT(0 <= iIndexRow);

 ListView_SetItemState(m_wndListControl, iIndexRow, nState, nMask);

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 RowStateGet

HRESULT CListView32::RowStateGet(int iIndexRow, UINT nMask, UINT& nState)
{
 ASSERT(0 <= iIndexRow);

 nState = ListView_GetItemState(m_wndListControl, iIndexRow, nMask);

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 ImageListImageCount

int CListView32::ImageListImageCount(int iImageListType)
{
 HIMAGELIST hImageList = ((LVSIL_SMALL == iImageListType) ?
                         m_hImageListSmall:m_hImageListLarge);

 ASSERT(NULL != hImageList);

 return ImageList_GetImageCount(hImageList);
}

//////////////////////////////////////////////////////////////////////////
// CListView32 ImageListAdd

HRESULT CListView32::ImageListAdd(int iImageListType, HICON hIcon)
{
 ASSERT(NULL != hIcon);

 HIMAGELIST hImageList = ((LVSIL_SMALL == iImageListType) ?
                         m_hImageListSmall:m_hImageListLarge);

 ASSERT(NULL != hImageList);

 if (-1 == ImageList_AddIcon(hImageList, hIcon))
   {
   ASSERT(0);
   return E_FAIL;
   }

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 ImageListAdd

HRESULT CListView32::ImageListAdd(HICON hIcon)
{
 ASSERT(NULL != hIcon);

 // Add the icon to the large image list
 HRESULT hr = ImageListAdd(LVSIL_NORMAL, hIcon);
 if (FAILED(hr))
   {
   ASSERT(0);
   return hr;
   }

 // Add the icon to the small image list
 hr = ImageListAdd(LVSIL_SMALL, hIcon);
 if (FAILED(hr))
   {
   ASSERT(0);
   return hr;
   }

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 ImageListRemove

HRESULT CListView32::ImageListRemove(int iImageListType, int iIndex)
{
 ASSERT((0 <= iIndex)&&(iIndex < ImageListImageCount(iImageListType)));

 HIMAGELIST hImageList = ((LVSIL_SMALL == iImageListType)?
                         m_hImageListSmall:m_hImageListLarge);

 ASSERT(NULL != hImageList);

 if (!ImageList_Remove(hImageList, iIndex))
   {
   ASSERT(0);
   return E_FAIL;
   }

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 ImageListRemove

HRESULT CListView32::ImageListRemove(int iIndex)
{
 // Remove the icon from the large image list
 HRESULT hr = ImageListRemove(LVSIL_NORMAL, iIndex);
 if (FAILED(hr))
   {
   ASSERT(0);
   return hr;
   }

 // Remove the icon from the small image list
 hr = ImageListRemove(LVSIL_SMALL, iIndex);
 if (FAILED(hr))
   {
   ASSERT(0);
   return hr;
   }

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 ImageListImageIndex

HRESULT  CListView32::ImageListImageIndex(HICON hIcon, int& iIndexImage)
{
 // Return the index of the image in the image list

 // Setup the return
 iIndexImage = -1;

 // Is the Icon alreay cached
 for (DWORD dwIndex = 0; dwIndex < m_dwCountHICONsInImageList; ++dwIndex)
   {
   // What is the current HICON
   HICON hIconCurrent = (HICON)*(m_lpdwHICONsInImageList + dwIndex);

   if (hIconCurrent == hIcon)
     {
     iIndexImage = (int)dwIndex;
     return S_OK;
     }
   }

 // New Icon to associate with the Image List
 HRESULT hr = ImageListAdd(hIcon);
 if (FAILED(hr))
   {
   ASSERT(0);
   return hr;
   }

 // Track/cache the new icon handle
 LPDWORD lpdwTemp = m_lpdwHICONsInImageList;
 try
   {
   m_lpdwHICONsInImageList = (LPDWORD)malloc(
                                     (++m_dwCountHICONsInImageList) 
                                     * sizeof(DWORD));
   }
 catch(...)
   {
   ASSERT(0);
   m_lpdwHICONsInImageList = NULL;
   }

 if (NULL == m_lpdwHICONsInImageList)
   {
   ASSERT(0);
   --m_dwCountHICONsInImageList;
   m_lpdwHICONsInImageList = lpdwTemp;
   hr = ImageListRemove((int)m_dwCountHICONsInImageList);
   ASSERT(SUCCEEDED(hr));
   return E_OUTOFMEMORY;
   }

 // Return the index of the new icon
 iIndexImage = (int)(m_dwCountHICONsInImageList - 1);


 // Copy the previously cached values and Cleanup the old list 
 if (NULL != lpdwTemp)
   {
   ASSERT(0 < iIndexImage);

   memcpy((void *)m_lpdwHICONsInImageList, 
         (const void *)lpdwTemp, 
         (iIndexImage * sizeof(DWORD)));

   free(lpdwTemp);
   lpdwTemp = NULL;
   }
 
 // Track the value
 *(m_lpdwHICONsInImageList + iIndexImage) = (DWORD)hIcon;

 // Succeeded
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// Events
//////////////////////////////////////////////////////////////////////////
// CListView32 OnCreate

LRESULT CListView32::OnCreate( UINT /* uMsg */, 
                               WPARAM /* wParam */, 
                               LPARAM lParam, 
                               BOOL& /* bHandled */)
{
 LPCREATESTRUCT lpcs = (LPCREATESTRUCT) lParam;

 ASSERT(NULL != lpcs);

 // Create the list control and default to the report view
 RECT rect = { 0 };

 rect.left = lpcs->x;
 rect.top  = lpcs->y;
 rect.right  = rect.left + lpcs->cx;
 rect.bottom = rect.top  + lpcs->cy;

 if (NULL == m_wndListControl.Create(m_hWnd, 
                                     rect, 
                                     NULL, 
                                     WS_BORDER|WS_CHILD|WS_VISIBLE|
                                     m_lInitialView))
   {
   ASSERT(0);
   return -1;
   }

 // Create the empty small and large image lists 
 // and associate with the list control Large
 m_hImageListLarge = ImageList_Create(DW_IMAGELIST_CXCY_LARGE, 
                                      DW_IMAGELIST_CXCY_LARGE, 
                                      ILC_COLOR, 
                                      DW_IMAGELIST_INITIAL, 
                                      DW_IMAGELIST_GROW);
 if (NULL == m_hImageListLarge)
   {
   _ASSERT(0);
   return -1;
   }

 ListView_SetImageList(m_wndListControl, 
                       m_hImageListLarge, 
                       LVSIL_NORMAL);

 // Small
 m_hImageListSmall = ImageList_Create(DW_IMAGELIST_CXCY_SMALL, 
                                      DW_IMAGELIST_CXCY_SMALL, 
                                      ILC_COLOR, 
                                      DW_IMAGELIST_INITIAL, 
                                      DW_IMAGELIST_GROW);
 if (NULL == m_hImageListSmall)
   {
   _ASSERT(0);
   return -1;
   }

 ListView_SetImageList(m_wndListControl, 
                       m_hImageListSmall, 
                       LVSIL_SMALL);

 return 0;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 OnDestroy

LRESULT CListView32::OnDestroy( UINT   /* uMsg */, 
                                WPARAM /* wParam */, 
                                LPARAM /* lParam */, 
                                BOOL&  /* bHandled */)
{
 // Cleanup the image lists associated with the control
 // Large
 if (NULL != m_hImageListLarge)
   {
   BOOL bSuccess = ImageList_Destroy(m_hImageListLarge);
   ASSERT(bSuccess);
   m_hImageListLarge = NULL;
   }

 // Small
 if (NULL != m_hImageListSmall)
   {
   BOOL bSuccess = ImageList_Destroy(m_hImageListSmall);
   ASSERT(bSuccess);
   m_hImageListSmall = NULL;
   }

 // Cleanup the cached list of icon 
 // handles for what is in the image lists
 if (NULL != m_lpdwHICONsInImageList)
   {
   free(m_lpdwHICONsInImageList);
   m_lpdwHICONsInImageList = NULL;
   }

 m_dwCountHICONsInImageList = 0;

 // Cleanup the list view control
 BOOL bSuccess = m_wndListControl.DestroyWindow();

 ASSERT(bSuccess);

 return 0;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 OnSetFocus

LRESULT CListView32::OnSetFocus( UINT   /* uMsg */, 
                                 WPARAM /* wParam */, 
                                 LPARAM /* lParam */, 
                                 BOOL&  /* bHandled */)
{
 m_wndListControl.SetFocus();
 return 0;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 OnSize

LRESULT CListView32::OnSize( UINT   /* uMsg */, 
                             WPARAM /* wParam */, 
                             LPARAM lParam, 
                             BOOL&  /* bHandled */ )
{
 m_wndListControl.MoveWindow(0, 0, LOWORD(lParam), HIWORD(lParam));
 return 0;   
}

//////////////////////////////////////////////////////////////////////////
// CListView32 OnDblClick

LRESULT CListView32::OnDblClick(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
{
 // Allow my registered callback to handle the event
 if (NULL != m_lpListView32Events)
   {
   return m_lpListView32Events->OnDblClick(idCtrl, pnmh , bHandled);
   }

 // Do the default stuff
 return 0;
}

//////////////////////////////////////////////////////////////////////////
// CListView32 OnSelChanged

LRESULT CListView32::OnSelChanged( int idCtrl, 
                                   LPNMHDR pnmh , 
                                   BOOL& bHandled )
{
 // Allow my registered callback to handle the event
 if (NULL != m_lpListView32Events)
   {
   return m_lpListView32Events->OnSelChanged(idCtrl, pnmh , bHandled);
   }

 // Do the default stuff
 return 0;
}
