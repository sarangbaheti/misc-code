//////////////////////////////////////////////////////////////////////////
//
// Filename: About.cpp
//
// Description: About box dialog implementation file
//
// This files implements the about for for the 
// ADSIView namespace extension
//
// Author(s): Todd Daniell
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "About.h"

//////////////////////////////////////////////////////////////////////////
// CAbout

//////////////////////////////////////////////////////////////////////////
// CAbout Constructor

CAbout::CAbout()
{
}

//////////////////////////////////////////////////////////////////////////
// CAbout Destructor

CAbout::~CAbout()
{
}

//////////////////////////////////////////////////////////////////////////
// CAbout OnInitDialog

LRESULT CAbout::OnInitDialog( UINT /*uMsg*/,
                              WPARAM /*wParam*/,
                              LPARAM /*lParam*/,
                              BOOL& /*bHandled*/)
{
    return 1;  // Let the system set the focus
}

//////////////////////////////////////////////////////////////////////////
// CAbout OnOK

LRESULT CAbout::OnOK( WORD /*wNotifyCode*/,
                      WORD wID,
                      HWND /*hWndCtl*/,
                      BOOL& /*bHandled*/)
{
    EndDialog(wID);
    return 0;
}

//////////////////////////////////////////////////////////////////////////
// CAbout OnCancel

LRESULT CAbout::OnCancel( WORD /*wNotifyCode*/,
                          WORD wID,
                          HWND /*hWndCtl*/,
                          BOOL& /*bHandled*/)
{
    EndDialog(wID);
    return 0;
}

