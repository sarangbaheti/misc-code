//////////////////////////////////////////////////////////////////////////
//
// Filename:     ADSIWebView.h
//
// Description:  ADSI Web View header file
//
// Author(s):    Brian Daigle
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ADSIWEBVIEW_H__INCLUDED_)
#define AFX_ADSIWEBVIEW_H__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// main symbols
#include "resource.h"
#include <mshtml.h>

//////////////////////////////////////////////////////////////////////////
// CADSIWebView

class ATL_NO_VTABLE CADSIWebView : 
 public CComObjectRoot,
 public CComCoClass<CADSIWebView,&CLSID_ADSIWebView>,
 public CComControl<CADSIWebView>,
 public IDispatchImpl< IADSIWebView,
                       &IID_IADSIWebView,
                       &LIBID_ADSIViewLib>,
 public IDispatchImpl< DWebBrowserEvents2,
                       &IID_DWebBrowserEvents2,
                       &LIBID_ADSIViewLib>,
 public IPersistStreamInitImpl<CADSIWebView>,
 public IOleControlImpl<CADSIWebView>,
 public IOleObjectImpl<CADSIWebView>,
 public IOleInPlaceActiveObjectImpl<CADSIWebView>,
 public IViewObjectExImpl<CADSIWebView>,
 public ISupportErrorInfo,
 public IConnectionPointContainerImpl<CADSIWebView>,
 public IOleInPlaceObjectWindowlessImpl<CADSIWebView>,
 public IObjectSafetyImpl<CADSIWebView>,
 public IOleClientSite,
 public IOleInPlaceSite,
 public IOleContainer
{
public:
 CADSIWebView();
 ~CADSIWebView();

//////////////////////////////////////////////////////////////////////////
// COM Map

BEGIN_COM_MAP(CADSIWebView)
 COM_INTERFACE_ENTRY2(IDispatch, IADSIWebView)
 COM_INTERFACE_ENTRY_IID(IID_IADSIWebView, IADSIWebView)
 COM_INTERFACE_ENTRY_IID(IID_DWebBrowserEvents2, DWebBrowserEvents2)
 COM_INTERFACE_ENTRY_IMPL_IID(IID_IViewObject, IViewObjectEx)
 COM_INTERFACE_ENTRY_IMPL_IID(IID_IViewObject2, IViewObjectEx)
 COM_INTERFACE_ENTRY_IMPL(IViewObjectEx)
 COM_INTERFACE_ENTRY_IMPL_IID( IID_IOleWindow,
                               IOleInPlaceObjectWindowless)
 COM_INTERFACE_ENTRY_IMPL_IID( IID_IOleInPlaceObject,
                               IOleInPlaceObjectWindowless)
 COM_INTERFACE_ENTRY_IMPL(IOleInPlaceObjectWindowless)
 COM_INTERFACE_ENTRY_IMPL(IOleInPlaceActiveObject)
 COM_INTERFACE_ENTRY_IMPL(IOleControl)
 COM_INTERFACE_ENTRY_IMPL(IOleObject)
 COM_INTERFACE_ENTRY_IMPL(IPersistStreamInit)
 COM_INTERFACE_ENTRY(ISupportErrorInfo)
 COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
 COM_INTERFACE_ENTRY_IMPL(IObjectSafety)
 COM_INTERFACE_ENTRY(IOleWindow)
 COM_INTERFACE_ENTRY(IOleClientSite)
 COM_INTERFACE_ENTRY(IOleInPlaceSite)
 COM_INTERFACE_ENTRY(IOleContainer)
END_COM_MAP()

//DECLARE_NOT_AGGREGATABLE(CADSIWebView) 
// Remove the comment from the line above if you don't want your object to
// support aggregation. 

//////////////////////////////////////////////////////////////////////////
// Message Map

BEGIN_MSG_MAP(CADSIWebView)
 // Overloaded messages
 MESSAGE_HANDLER(WM_NCDESTROY, OnNCDestroy)
 MESSAGE_HANDLER(WM_SIZE, OnSize)
 MESSAGE_HANDLER(WM_ERASEBKGND, OnErase)

 // Implemented by ATL
 MESSAGE_HANDLER(WM_PAINT, OnPaint)
 MESSAGE_HANDLER(WM_SETFOCUS, OnSetFocus)
 MESSAGE_HANDLER(WM_KILLFOCUS, OnKillFocus)
END_MSG_MAP()

//////////////////////////////////////////////////////////////////////////
// Property Map

BEGIN_PROPERTY_MAP(CADSIWebView)
 // Example Entries
 // PROP_ENTRY( "Property Description", dispid, clsid )
 // PROP_PAGE( CLSID_StockColorPage )
END_PROPERTY_MAP()

//////////////////////////////////////////////////////////////////////////
// Connection Points

BEGIN_CONNECTION_POINT_MAP(CADSIWebView)
END_CONNECTION_POINT_MAP()

//////////////////////////////////////////////////////////////////////////
// Registry resources

DECLARE_REGISTRY_RESOURCEID(IDR_ADSIWebView)
DECLARE_GET_CONTROLLING_UNKNOWN()

//////////////////////////////////////////////////////////////////////////
// ISupportsErrorInfo Interface
public:

 STDMETHOD(InterfaceSupportsErrorInfo)( REFIID riid );

//////////////////////////////////////////////////////////////////////////
// IViewObjectEx Interface
public:

 STDMETHOD(GetViewStatus)( DWORD *pdwStatus );

//////////////////////////////////////////////////////////////////////////
// IOleWindow Interface
public:

 STDMETHOD(GetWindow)( HWND *lphwnd );

 STDMETHOD(ContextSensitiveHelp)( BOOL fEnterMode );

//////////////////////////////////////////////////////////////////////////
// IOleClientSite Interface
public:

 STDMETHOD(SaveObject)(void);

 STDMETHOD(GetMoniker)(  DWORD dwAssign,
                         DWORD dwWhichMoniker,
                         IMoniker **ppmk );

 STDMETHOD(GetContainer)(IOleContainer **ppContainer);

 STDMETHOD(ShowObject)(void);

 STDMETHOD(OnShowWindow)(BOOL fShow);

 STDMETHOD(RequestNewObjectLayout)(void);

//////////////////////////////////////////////////////////////////////////
// IOleContainer Interface
public:

 STDMETHOD(ParseDisplayName)(  LPBC pbc,
                               LPOLESTR lpszDisplayName,
                               unsigned long * pchEaten,
                               LPMONIKER * ppmkOut );

 STDMETHOD(EnumObjects)( unsigned long grfFlags,
                         LPENUMUNKNOWN * ppenumUnknown );

 STDMETHOD(LockContainer)( int fLock );

//////////////////////////////////////////////////////////////////////////
// IOleInPlaceSite Interface
public:

 STDMETHOD(CanInPlaceActivate)( void );

 STDMETHOD(OnInPlaceActivate)( void );

 STDMETHOD(OnUIActivate)( void );

 STDMETHOD(GetWindowContext)(  IOleInPlaceFrame **ppFrame,
                               IOleInPlaceUIWindow **ppDoc,
                               LPRECT lprcPosRect,
                               LPRECT lprcClipRect,
                               LPOLEINPLACEFRAMEINFO lpFrameInfo );

  STDMETHOD(Scroll)( SIZE scrollExtant );

  STDMETHOD(OnUIDeactivate)( BOOL fUndoable );

  STDMETHOD(OnInPlaceDeactivate)( void );

  STDMETHOD(DiscardUndoState)( void );

  STDMETHOD(DeactivateAndUndo)( void );

  STDMETHOD(OnPosRectChange)( LPCRECT lprcPosRect );

//////////////////////////////////////////////////////////////////////////
// DWebBrowserEvents2 Event Handlers
public:

 STDMETHOD(StatusTextChange)( BSTR Text );

 STDMETHOD(ProgressChange)( long Progress, long ProgressMax );

 STDMETHOD(CommandStateChange)( long Command, VARIANT_BOOL Enable );

 STDMETHOD(DownloadBegin)( void );

 STDMETHOD(DownloadComplete)( void );

 STDMETHOD(TitleChange)( BSTR Text );

 STDMETHOD(PropertyChange)( BSTR szProperty );

 STDMETHOD(BeforeNavigate2)( IDispatch* pDisp,
                             VARIANT* URL,
                             VARIANT* Flags,
                             VARIANT* TargetFrameName,
                             VARIANT* PostData,
                             VARIANT* Headers,
                             VARIANT_BOOL* Cancel  );

 STDMETHOD(NewWindow2)( IDispatch** ppDisp, VARIANT_BOOL* Cancel );

 STDMETHOD(NavigateComplete2)( IDispatch* pDisp, VARIANT* URL );

 STDMETHOD(DocumentComplete)( IDispatch* pDisp, VARIANT* URL );

 STDMETHOD(OnQuit)();

 STDMETHOD(OnVisible)( VARIANT_BOOL Visible );

 STDMETHOD(OnToolBar)( VARIANT_BOOL ToolBar );

 STDMETHOD(OnMenuBar)( VARIANT_BOOL MenuBar );

 STDMETHOD(OnStatusBar)( VARIANT_BOOL StatusBar );

 STDMETHOD(OnFullScreen)( VARIANT_BOOL FullScreen );

 STDMETHOD(OnTheaterMode)( VARIANT_BOOL TheaterMode );

//////////////////////////////////////////////////////////////////////////
// Message Map Handlers
public:

 LRESULT OnNCDestroy(  UINT uMsg, WPARAM wParam,
                       LPARAM lParam, BOOL& lResult );

 LRESULT OnErase(  UINT uMsg , WPARAM wParam,
                   LPARAM lParam, BOOL& bHandled );

 LRESULT OnSize( UINT uMsg , WPARAM wParam,
                 LPARAM lParam, BOOL& lResult );

//////////////////////////////////////////////////////////////////////////
// IADSIWebView Interface
public:

 STDMETHOD(SetCurrentInfo)( UINT uViewMode, UINT uFlags );

 STDMETHOD(GetCurrentInfo)( UINT *puViewMode, UINT *puFlags );

 STDMETHOD(GetWindow)( UINT *lphwnd );

 STDMETHOD(Refresh)();

 STDMETHOD(DestroyView)();

 STDMETHOD(CreateView)(  IUnknown  *pIUnkShellView,
                         IUnknown  *pIUnkShellBrowser,
                         IUnknown  *pIUnkShellFolder, 
                         UINT    uhwndParent,
                         UINT    uTop,
                         UINT    uLeft,
                         UINT    uBottom,
                         UINT    uRight,
                         UINT    uViewMode,
                         UINT    uFlags,
                         UINT    *phWnd );

//////////////////////////////////////////////////////////////////////////
// CADSIWebView internal methods
private:

 void    ClearMemberVars();

 HRESULT GetAllCollection( IHTMLElementCollection *& pCollection );

 HRESULT GetElementInCollection( IHTMLElementCollection *pCollection,
                                 long lIndex,
                                 long& lNumElements,
                                 IHTMLElement *& pElement );

 HRESULT GetChildCollection(
                           IHTMLElement *pIHTMLElement,
                           IHTMLElementCollection *& pChildCollection );

 HRESULT GetElementTag( IHTMLElement *pIHTMLElement, string& strTag );

 HRESULT GetElementInnerText(  IHTMLElement *pIHTMLElement,
                               string& strInnerText );

 HRESULT PutElementInnerText(  IHTMLElement *pIHTMLElement,
                               string& strInnerText );

 HRESULT ReplaceText(  string& strTextToSearch,
                       string& strTextToFind,
                       string& strTextToReplace );

 HRESULT ReplaceAllTextTags( IHTMLElementCollection *pCollection,
                             string& strTextToFind,
                             string& strTextToReplace );

 HRESULT GetObjectsIDispatch(  IHTMLElementCollection *pCollection,
                               string& strFindCLSID,
                               IDispatch *& pIDispatch );

 HRESULT CreateClassicView( IHTMLElementCollection *pCollection );

 HRESULT ReplacePath( IHTMLElementCollection *pCollection );

 HRESULT InsertWebControl();

 HRESULT SetupWebBrowser2Sink();

 HRESULT GetTemplateFullPath( string& strTemplatePath );

//////////////////////////////////////////////////////////////////////////
// Web View member variables
private:

 BOOL  m_bInPlaceActive;             //InPlace Activate Flag
 DWORD m_dwWebBrowserEvents2Sink;    //WebBrowserEvents2 Sink Cookie

 FOLDERSETTINGS  m_FolderSettings;   //Folder Settings

//////////////////////////////////////////////////////////////////////////
// Interface pointers for Web View Objects

 CComQIPtr< IShellBrowser, &IID_IShellBrowser >
            m_pIShellBrowser;                  //Shell Browser Interface

 CComQIPtr< IShellFolder,  &IID_IShellFolder >
            m_pIShellFolder;                   //Shell Folder  Interface

 IUnknown            *m_pIUnkShellView;        //Shell View Interface
 IADSIClassicView    *m_pIADSIClassicView;     //Classic View Interface

 IOleObject          *m_pIOleObject;           //Ole Object Interface
 IWebBrowser2        *m_pIWebBrowser2;         //Web Browser2 Interface

};

#endif // !defined(AFX_ADSIWEBVIEW_H__INCLUDED_)
