//////////////////////////////////////////////////////////////////////////
//
// Filename:     ADSIPiddleList.h
//
// Description:  ADSI Enumerator list for IDLists
//
// Author(s):    Doug Bahr
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////

#ifndef _ADSIPIDDLELIST_H
#define _ADSIPIDDLELIST_H

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// include the STL list header
#include <list>
using namespace std;

// typedef a list for use
typedef list<LPITEMIDLIST> LISTOFPIDLS;

//////////////////////////////////////////////////////////////////////////
// CADSIPiddleList

class CADSIPiddleList : 
 public CComObjectRoot,
 public IEnumIDList
{
 ///////////////////////////////////
 // Attributes
protected:
 LISTOFPIDLS           m_ListofPIDLs;
 LISTOFPIDLS::iterator m_ListIterator;
public:

// construction / destruction
public:
 CADSIPiddleList();
 virtual ~CADSIPiddleList();

BEGIN_COM_MAP(CADSIPiddleList)
 COM_INTERFACE_ENTRY(IEnumIDList)
END_COM_MAP()
DECLARE_NOT_AGGREGATABLE(CADSIPiddleList) 

// IEnumIDList
public:
 STDMETHOD(Next)(ULONG cElement,
                   LPITEMIDLIST *rgelt,
                   ULONG * pcElementFetched);
 STDMETHOD(Skip)(ULONG cElement);
 STDMETHOD(Reset)();
 STDMETHOD(Clone)(IEnumIDList **ppEnumIDList);

// C++ Methods
 virtual HRESULT AddIDListAndTakeOwnership(LPITEMIDLIST pIDList);
};

#endif // #ifndef _ADSIPIDDLELIST_H
