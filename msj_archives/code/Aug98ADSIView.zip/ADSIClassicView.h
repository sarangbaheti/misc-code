//////////////////////////////////////////////////////////////////////////
//
// Filename:     ADSIClassicView.h
//
// Description:  This is the 'old' style view
//
// Author(s):    Todd Daniell, Doug Bahr, Dave Mims, Brian Daigle
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////

#ifndef _ADSIClassicView_H
#define _ADSIClassicView_H

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "resource.h"       // main symbols
#include "CPADSIClassic.h"
#include "listview32.h"

//////////////////////////////////////////////////////////////////////////
// predeclare an interface
interface IADs;

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView

class CADSIClassicView : 
 public CComObjectRoot,
 public CComCoClass<CADSIClassicView,&CLSID_ADSIClassicView>,
 public CComControl<CADSIClassicView>,
 public CStockPropImpl<CADSIClassicView, IADSIClassicView, 
                       &IID_IADSIClassicView, &LIBID_ADSIViewLib>,
 public IProvideClassInfo2Impl<&CLSID_ADSIClassicView, 
                       &DIID__ADSIClassicEvents, &LIBID_ADSIViewLib>,
 public IPersistStreamInitImpl<CADSIClassicView>,
 public IPersistStorageImpl<CADSIClassicView>,
 public IQuickActivateImpl<CADSIClassicView>,
 public IOleControlImpl<CADSIClassicView>,
 public IOleObjectImpl<CADSIClassicView>,
 public IOleInPlaceActiveObjectImpl<CADSIClassicView>,
 public IViewObjectExImpl<CADSIClassicView>,
 public IOleInPlaceObjectWindowlessImpl<CADSIClassicView>,
 public IDataObjectImpl<CADSIClassicView>,
 public ISupportErrorInfo,
 public CProxy_ADSIClassicEvents<CADSIClassicView>,
 public IConnectionPointContainerImpl<CADSIClassicView>,
 public IObjectSafetyImpl<CADSIClassicView>,
 public IDispatchImpl<DWebBrowserEvents2, &IID_DWebBrowserEvents2, 
                       &LIBID_ADSIViewLib>,
 public CListView32Events
{
public:
 CADSIClassicView();
 ~CADSIClassicView();

DECLARE_REGISTRY_RESOURCEID(IDR_ADSIClassicView)
DECLARE_POLY_AGGREGATABLE(CADSIClassicView)
DECLARE_GET_CONTROLLING_UNKNOWN()

BEGIN_COM_MAP(CADSIClassicView)
 COM_INTERFACE_ENTRY(IADSIClassicView)
 COM_INTERFACE_ENTRY2(IDispatch, IADSIClassicView)
 COM_INTERFACE_ENTRY_IID(IID_DWebBrowserEvents2, DWebBrowserEvents2)
 COM_INTERFACE_ENTRY_IMPL(IViewObjectEx)
 COM_INTERFACE_ENTRY_IMPL_IID(IID_IViewObject2, IViewObjectEx)
 COM_INTERFACE_ENTRY_IMPL_IID(IID_IViewObject, IViewObjectEx)
 COM_INTERFACE_ENTRY_IMPL(IOleInPlaceObjectWindowless)
 COM_INTERFACE_ENTRY_IMPL_IID(IID_IOleInPlaceObject, 
                               IOleInPlaceObjectWindowless)
 COM_INTERFACE_ENTRY_IMPL_IID(IID_IOleWindow, 
                               IOleInPlaceObjectWindowless)
 COM_INTERFACE_ENTRY_IMPL(IOleInPlaceActiveObject)
 COM_INTERFACE_ENTRY_IMPL(IOleControl)
 COM_INTERFACE_ENTRY_IMPL(IOleObject)
 COM_INTERFACE_ENTRY_IMPL(IQuickActivate)
 COM_INTERFACE_ENTRY_IMPL(IPersistStorage)
 COM_INTERFACE_ENTRY_IMPL(IPersistStreamInit)
 COM_INTERFACE_ENTRY_IMPL(IDataObject)
 COM_INTERFACE_ENTRY(IProvideClassInfo)
 COM_INTERFACE_ENTRY(IProvideClassInfo2)
 COM_INTERFACE_ENTRY(ISupportErrorInfo)
 COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
 COM_INTERFACE_ENTRY_IMPL(IObjectSafety)
END_COM_MAP()

BEGIN_CONNECTION_POINT_MAP(CADSIClassicView)
 CONNECTION_POINT_ENTRY(DIID__ADSIClassicEvents)
END_CONNECTION_POINT_MAP()

BEGIN_PROPERTY_MAP(CADSIClassicView)
 // Example Entries
 // PROP_ENTRY( "Property Description", dispid, clsid )
END_PROPERTY_MAP()

BEGIN_MSG_MAP(CADSIClassicView)
 MESSAGE_HANDLER( WM_PAINT, OnPaint )
 MESSAGE_HANDLER( WM_GETDLGCODE, OnGetDlgCode )
 MESSAGE_HANDLER( WM_SETFOCUS, OnSetFocus )
 MESSAGE_HANDLER( WM_KILLFOCUS, OnKillFocus )
 MESSAGE_HANDLER( WM_SIZE, OnSize )
 MESSAGE_HANDLER( WM_CREATE, OnCreate)
END_MSG_MAP()

 STDMETHOD(SetClientSite)( IOleClientSite* pClientSite );
 STDMETHOD(SetObjectRects)( LPCRECT prcPos,LPCRECT prcClip );

 LRESULT OnCreate(UINT uMsg,
                 WPARAM wParam,
                 LPARAM lParam,
                 BOOL& bHandled);
 LRESULT OnSize(UINT uMsg,
               WPARAM wParam,
               LPARAM lParam,
               BOOL& bHandled);

// IADSIClassicView
public:
 STDMETHOD(SetCurrentInfo)(UINT uViewMode, UINT uFlags);
 STDMETHOD(GetCurrentInfo)( UINT * puViewMode, UINT * puFlags );
 STDMETHOD(GetWindow)( UINT * lphwnd );
 STDMETHOD(DestroyView)();
 STDMETHOD(Refresh)();
 STDMETHOD(CreateView)(  IUnknown  *pIUnkShellView,
             IUnknown  *pIUnkShellBrowser,
             IUnknown  *pIUnkShellFolder, 
             UINT    uhwndParent,
             UINT    uTop,
             UINT    uLeft,          
             UINT    uBottom,        
             UINT    uRight,         
             UINT    uViewMode,      
             UINT    uFlags,         
             UINT    *phWnd );   
 STDMETHOD(GetCurrentPath)(VARIANT *varPath);
 STDMETHOD(GetSelectedName)(VARIANT *varName);
 STDMETHOD(GetSelectedGUID)(VARIANT *varGUID);
 STDMETHOD(GetSelectedClass)(VARIANT *varClass);

// ISupportsErrorInfo
public:
 STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IViewObjectEx
public:
 STDMETHOD(GetViewStatus)(DWORD* pdwStatus)
 {
   *pdwStatus = VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE;
   return S_OK;
 }

// DWebBrowserEvents2
public:
 STDMETHOD(StatusTextChange)(BSTR Text);
 STDMETHOD(ProgressChange)(long Progress, long ProgressMax);
 STDMETHOD(CommandStateChange)(long Command, VARIANT_BOOL Enable);
 STDMETHOD(DownloadBegin)();
 STDMETHOD(DownloadComplete)();
 STDMETHOD(TitleChange)(BSTR Text);
 STDMETHOD(PropertyChange)(BSTR szProperty);
 STDMETHOD(BeforeNavigate2)(IDispatch* pDisp, VARIANT* URL, 
   VARIANT* Flags, VARIANT* TargetFrameName, VARIANT* PostData, 
   VARIANT* Headers, VARIANT_BOOL* Cancel);
 STDMETHOD(NewWindow2)(IDispatch** ppDisp, VARIANT_BOOL* Cancel);
 STDMETHOD(NavigateComplete2)(IDispatch* pDisp, VARIANT* URL);
 STDMETHOD(DocumentComplete)(IDispatch* pDisp, VARIANT* URL);
 STDMETHOD(OnQuit)();
 STDMETHOD(OnVisible)(VARIANT_BOOL Visible);
 STDMETHOD(OnToolBar)(VARIANT_BOOL ToolBar);
 STDMETHOD(OnMenuBar)(VARIANT_BOOL MenuBar);
 STDMETHOD(OnStatusBar)(VARIANT_BOOL StatusBar);
 STDMETHOD(OnFullScreen)(VARIANT_BOOL FullScreen);
 STDMETHOD(OnTheaterMode)(VARIANT_BOOL TheaterMode);

private:
 // Internal Methods
 void  ClearMemberVar();

 // List View Maint. Functions
 HRESULT FillInListView();
 HRESULT AddObjectToList(IADs * pObject);
 HRESULT GetSelectedRow( int &nSelectedRow );

private:
 //Current Shell Browser Interface
 CComQIPtr< IShellBrowser, &IID_IShellBrowser >  m_pIShellBrowser;
   //Current Shell Folder  Interface
 CComQIPtr< IShellFolder,  &IID_IShellFolder >   m_pIShellFolder;
 CComQIPtr< IWebBrowser2, &IID_IWebBrowser2 >    m_pIWebBrowser2;

 FOLDERSETTINGS    m_FolderSettings;   //Folder Settings
 CListView32       m_listView;         //ListView Control
 DWORD             m_dwAdviseCookie;
 RECT              m_rcParent;
 BOOL              m_bInPlace;

// Events proprigated from the list view
protected:
 virtual LRESULT OnDblClick(int idCtrl, LPNMHDR pnmh , BOOL& bHandled);  
 virtual LRESULT OnSelChanged(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);
};

#endif // #ifndef _CADSIClassicView_H
