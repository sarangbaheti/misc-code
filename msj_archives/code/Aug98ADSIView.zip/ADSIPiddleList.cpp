//////////////////////////////////////////////////////////////////////////
//
// Filename:   ADSIPiddleList.cpp
//
// Description:  The IDList Enumerator
//
// Author(s):    Doug Bahr
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#ifndef _ADSIPIDDLELIST_H
#include "ADSIPIDDLELIST.H"
#endif

#ifndef _ADSIPIDLHELPER_H
#include "ADSIPIDLHELPER.H"
#endif

//////////////////////////////////////////////////////////////////////////
// CADSIPiddleList constructor

CADSIPiddleList::CADSIPiddleList()
{
 Reset();
}

//////////////////////////////////////////////////////////////////////////
// CADSIPiddleList destructor

CADSIPiddleList::~CADSIPiddleList()
{
 // get an iterator
 LISTOFPIDLS::iterator m_DeletingIterator;

 // start at the first of the list
 m_DeletingIterator = m_ListofPIDLs.begin();

 // run the list
 while ( m_DeletingIterator != m_ListofPIDLs.end() )
   {
   LPITEMIDLIST pIDList = (LPITEMIDLIST)(*m_DeletingIterator);
   // copy the current one
   HRESULT hr = g_ADSIPIDLHelper.Destroy(pIDList);
   ASSERT( S_OK == hr );

   // move onto the next one
   m_DeletingIterator++;
   }

 // clear the list out
 m_ListofPIDLs.clear();
}

//////////////////////////////////////////////////////////////////////////
// CADSIPiddleList Next

HRESULT CADSIPiddleList::Next( ULONG cElement, 
                               LPITEMIDLIST *rgelt, 
                               ULONG * pcElementFetched)
{
 // clear out the array of pointers
 ::ZeroMemory(rgelt,cElement * sizeof(LPITEMIDLIST));

 // setup a returns
 if ( NULL != pcElementFetched )
   {
   // sanity check!
   ASSERT_POINTER(pcElementFetched,*pcElementFetched);
   *pcElementFetched = 0;
   }

 // setup the returns
 HRESULT hr = S_OK;
 DWORD dwNumberRetrieved = 0;

 // while we are NOT at the end of the list
 while ( m_ListIterator != m_ListofPIDLs.end() )
   {
   // Copy this one and move on
   hr = g_ADSIPIDLHelper.CopyPIDL((LPITEMIDLIST)(*m_ListIterator++),
                                   rgelt[dwNumberRetrieved++]);
   if ( FAILED(hr) )
     break;

   // if we are done, then break out of here
   if ( --cElement == 0 )
     break;
   }

 // if there is no error, return all is right
 if ( SUCCEEDED(hr) )
   {
   // set the number that were retrieved
   if ( NULL != pcElementFetched )
     *pcElementFetched = dwNumberRetrieved;

   // return all is well
   return S_OK;
   }

 // now, destroy all of these new PIDL's
 for ( DWORD dwIndex = 0; dwIndex < dwNumberRetrieved; dwIndex++ )
   {
   g_ADSIPIDLHelper.Destroy(rgelt[dwIndex]);
   }

 // return the error
 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIPiddleList Skip

HRESULT CADSIPiddleList::Skip(ULONG cElement)
{
 // move that many more
 advance(m_ListIterator,cElement);

 // return all is well
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIPiddleList Reset

HRESULT CADSIPiddleList::Reset()
{
 // move back to the start
 m_ListIterator = m_ListofPIDLs.begin();

 // return all is well
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIPiddleList Clone

HRESULT CADSIPiddleList::Clone(IEnumIDList **ppEnumIDList)
{
 // setup the return
 ASSERT_POINTER(ppEnumIDList,*ppEnumIDList);
 *ppEnumIDList = NULL;

 // get the new list
 IEnumIDList *pIEnumIDList = NULL;
 HRESULT hr = CComCreator< CComObject< CADSIPiddleList > >
               ::CreateInstance( NULL, 
                                 IID_IEnumIDList, 
                                 (void**)&pIEnumIDList);
 if (FAILED(hr))
   {
   ASSERT(0);
   return hr;
   }

 ASSERT_POINTER(pIEnumIDList, *pIEnumIDList);

 CADSIPiddleList * pNewList = (CADSIPiddleList *)pIEnumIDList;

 ASSERT_POINTER(pNewList, *pNewList);

 // get an iterator
 LISTOFPIDLS::iterator m_CloningIterator;

 // start at the first of the list
 m_CloningIterator = m_ListofPIDLs.begin();

 // run the list
 while ( m_CloningIterator != m_ListofPIDLs.end() )
   {
   // copy the current one
   LPITEMIDLIST pNewIDL = NULL;
   HRESULT hr = g_ADSIPIDLHelper.CopyPIDL((LPITEMIDLIST)
                                         (*m_CloningIterator),
                                         pNewIDL);
   if ( FAILED(hr) )
     {
     ASSERT( NULL == pNewIDL );
     pIEnumIDList->Release();
     pIEnumIDList = NULL;

     return hr;
     }

   // make sure that we have it
   ASSERT( NULL != pNewIDL );

   // add this to the end of the list
   pNewList->m_ListofPIDLs.push_back(pNewIDL);

   // move onto the next one
   m_CloningIterator++;
   }

 // set the iterator
 pNewList->m_ListIterator = m_ListIterator;

 // set the interface
 *ppEnumIDList = pIEnumIDList;

 // return all is well
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIPiddleList Clone

HRESULT CADSIPiddleList::AddIDListAndTakeOwnership(LPITEMIDLIST pIDList)
{
 // add this to the tail of the list
 m_ListofPIDLs.push_back(pIDList);

 // move the iterator back to the start
 Reset();

 // return all is well
 return S_OK;
}
