//////////////////////////////////////////////////////////////////////////
//
// Filename:     ADSIShellView.cpp
//
// Description:  ADSI ShellView of the ShellFolder
//             
// Author(s):    Todd Daniell
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////

#include "stdafx.h"

// include the STL string object
#include <string>
using namespace std;

#include "ADSIShellView.h"

//////////////////////////////////////////////////////////////////////////
// CADSIShellView constructor

CADSIShellView::CADSIShellView()
{
 // Nullify the member vars
 ClearMemberVar();
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellView destructor

CADSIShellView::~CADSIShellView() 
{    
 // Nullify the member vars
 ClearMemberVar();
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellView Init

HRESULT CADSIShellView::Init( IShellFolder *pIShellFolder ) 
{ 
 // Track the ADSI Path associated with the folder of this view
 m_pIShellFolder = pIShellFolder;

 if (!m_pIShellFolder)
   return E_OUTOFMEMORY;

 return S_OK; 
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellView ClearMemberVar

void CADSIShellView::ClearMemberVar()
{
}

//////////////////////////////////////////////////////////////////////////
// IOleWindow Methods

//////////////////////////////////////////////////////////////////////////
// CADSIShellView GetWindow

STDMETHODIMP CADSIShellView::GetWindow( HWND *lphwnd )
{
 HRESULT hr = E_NOTIMPL;

 _ASSERTE(NULL != lphwnd);

 if ( m_pIADSIDefView )
   hr = m_pIADSIDefView->GetWindow( lphwnd );

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellView ContextSensitiveHelp

STDMETHODIMP CADSIShellView::ContextSensitiveHelp( BOOL /*fEnterMode*/ )
{
 return E_NOTIMPL;
}

//////////////////////////////////////////////////////////////////////////
// IShellView methods

//////////////////////////////////////////////////////////////////////////
// CADSIShellView TranslateAccelerator

STDMETHODIMP CADSIShellView::TranslateAccelerator( LPMSG /*lpmsg*/ )
{
 return E_NOTIMPL;
}

#ifdef _FIX_ENABLEMODELESS_CONFLICT

//////////////////////////////////////////////////////////////////////////
// CADSIShellView EnableModelessSV

STDMETHODIMP CADSIShellView::EnableModelessSV( BOOL /*fEnable */)
{
 return E_NOTIMPL;
}

#else

//////////////////////////////////////////////////////////////////////////
// CADSIShellView EnableModeless

STDMETHODIMP CADSIShellView::EnableModeless( BOOL /*fEnable*/ )
{
 return E_NOTIMPL;
}

#endif

//////////////////////////////////////////////////////////////////////////
// CADSIShellView UIActivate

STDMETHODIMP CADSIShellView::UIActivate( UINT uState )
{
 HRESULT hr = S_OK;

 if ( uState != SVUIA_DEACTIVATE )
   hr = m_pIADSIDefView->OnActivate( uState );
 else
   hr = m_pIADSIDefView->OnDeactivate();

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellView Refresh

STDMETHODIMP CADSIShellView::Refresh()
{
 HRESULT hr = E_NOTIMPL;

 if ( m_pIADSIDefView )
   hr = m_pIADSIDefView->Refresh();

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellView CreateViewWindow

STDMETHODIMP CADSIShellView::CreateViewWindow( IShellView * lpPrevView,
                                               LPCFOLDERSETTINGS lpfs,
                                               IShellBrowser *psb,
                                               RECT *prcView,
                                               HWND *phWnd )
{
 ASSERT_POINTER( phWnd, *phWnd );

 HRESULT hr = S_OK;

 try
   {
   *phWnd = NULL;

   SV2CVW2_PARAMS  ShellView2_Params;

   ShellView2_Params.cbSize    = sizeof( SV2CVW2_PARAMS );
   ShellView2_Params.psvPrev   = lpPrevView;
   ShellView2_Params.pfs       = lpfs;
   ShellView2_Params.psbOwner  = psb;
   ShellView2_Params.prcView   = prcView;
   ShellView2_Params.pvid      = &CLSID_ADSIClassicView;
   ShellView2_Params.hwndView  = NULL;

   hr = CreateViewWindow2( &ShellView2_Params );

   if ( SUCCEEDED( hr ))
     {
     *phWnd = ShellView2_Params.hwndView;
     }
   }
 catch(...)
   {
   _ASSERTE( 0 );

   hr = E_FAIL;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellView DestroyViewWindow

STDMETHODIMP CADSIShellView::DestroyViewWindow()
{
 HRESULT hr = E_NOTIMPL;

 // Do we have a Default View Loaded ?
 if ( m_pIADSIDefView )
   {
   // Destroy the Default View Window(s)
   hr = m_pIADSIDefView->DestroyView();

   // Release the Default View Interface
   m_pIADSIDefView = NULL;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellView GetCurrentInfo

STDMETHODIMP CADSIShellView::GetCurrentInfo(LPFOLDERSETTINGS lpfs)
{
 if ( !m_pIADSIDefView )
   return E_NOTIMPL;

 ASSERT_POINTER(lpfs, *lpfs);

 // ask the view for the information
 return m_pIADSIDefView->GetCurrentInfo( &(lpfs->ViewMode), 
                                         &(lpfs->fFlags) );

}

//////////////////////////////////////////////////////////////////////////
// CADSIShellView AddPropertySheetPages

STDMETHODIMP CADSIShellView::AddPropertySheetPages(
                                         DWORD /*dwReserved*/,
                                         LPFNADDPROPSHEETPAGE /*lpfn*/, 
                                         LPARAM /*lparam*/ )
{
 return E_NOTIMPL;
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellView SaveViewState

STDMETHODIMP CADSIShellView::SaveViewState()
{
 return E_NOTIMPL;
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellView SelectItem

STDMETHODIMP CADSIShellView::SelectItem( LPCITEMIDLIST /*pidlItem*/,
                                         UINT /*uFlags*/)
{
 return E_NOTIMPL;
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellView GetItemObject

STDMETHODIMP CADSIShellView::GetItemObject( UINT     /*uItem*/,
                                            REFIID   /*riid*/,
                                            LPVOID * /*ppv*/)
{
 return E_NOTIMPL;
}

//////////////////////////////////////////////////////////////////////////
// IShellView2 methods

//////////////////////////////////////////////////////////////////////////
// CADSIShellView GetView

STDMETHODIMP CADSIShellView::GetView( SHELLVIEWID* pvid,
                                      ULONG uView )
{
 HRESULT hr = S_OK;

 switch ( uView )
   {
   case SV2GV_DEFAULTVIEW:
     *pvid = CLSID_ADSIClassicView;
     break;

   case SV2GV_CURRENTVIEW:

     if ( m_pIADSIDefView )
       hr = m_pIADSIDefView->GetCurrentView( pvid );
     else
       *pvid = CLSID_ADSIClassicView;

     break;

   case 0:
     *pvid = CLSID_ADSIClassicView;
     break;

   case 1:
     *pvid = CLSID_ADSIWebView;
     break;

   default:
     hr = E_FAIL;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellView CreateViewWindow2

STDMETHODIMP CADSIShellView::CreateViewWindow2( LPSV2CVW2_PARAMS lpParams )
{
 HRESULT hr = S_OK;
 ADSI_CVW2PARAMS ADSIParams;

 if ( !m_pIADSIDefView )
   {
   hr = CoCreateInstance(CLSID_ADSIDefView,
                         NULL,
                         CLSCTX_INPROC_SERVER,
                         IID_IADSIDefView,
                         (VOID **)&m_pIADSIDefView);
   }

 if ( FAILED( hr ))
   return hr;

 ADSIParams.pIUnkShellView =     lpParams->psvPrev;
 ADSIParams.uViewMode =          lpParams->pfs->ViewMode;
 ADSIParams.uFlags =             lpParams->pfs->fFlags;
 ADSIParams.pIUnkShellBrowser =  lpParams->psbOwner;
 ADSIParams.prcView =            lpParams->prcView;
 ADSIParams.pvid =               lpParams->pvid;
 ADSIParams.hwndView =           lpParams->hwndView;

 hr = m_pIADSIDefView->CreateView(&ADSIParams,
                                 (IUnknown *)m_pIShellFolder);

 if ( FAILED( hr )) 
   m_pIADSIDefView = NULL;

 lpParams->hwndView = ADSIParams.hwndView;

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellView HandleRename

STDMETHODIMP CADSIShellView::HandleRename( LPCITEMIDLIST /*pidlNew*/)
{
 return E_NOTIMPL;
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellView SelectAndPositionItem

STDMETHODIMP CADSIShellView::SelectAndPositionItem( LPCITEMIDLIST /*pidl*/,
                                                    UINT /*uFlags*/,
                                                    POINT* /*point*/)
{
 return E_NOTIMPL;
}
