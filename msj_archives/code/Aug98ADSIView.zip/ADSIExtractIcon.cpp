//////////////////////////////////////////////////////////////////////////
//
// Filename:   ADSIExtractIcon.cpp
//
// Description:  ADSI Enumerator list for IDLists
//
//             This file implements the enumerator of IDLists
//             
// Author(s):    Doug Bahr
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ADSIExtractIcon.h"

//////////////////////////////////////////////////////////////////////////
// CADSIExtractIconA GetIconLocation

HRESULT CADSIExtractIconA::GetIconLocation( UINT /*uFlags*/,
                                            LPSTR szIconFile,
                                            UINT cchMax,
                                            int * piIndex,
                                            UINT * pwFlags)
{
 // get the module file name
 if ( 0 == ::GetModuleFileNameA( _Module.GetModuleInstance(),
                                 szIconFile,cchMax) )
   {
   DWORD dwError = ::GetLastError();
   return HRESULT_FROM_WIN32(dwError);
   }

 // if there is a place for the Icon Index
 if ( NULL != piIndex )
   {
   // take the icon resource ID and flag that it is just that
   // by turning on the high order bit
   *piIndex = -1 * (int)m_dwIcon;
   }

 // set that there are no special requirements on the icons
 if ( NULL != pwFlags )
   {
   *pwFlags = 0;
   }

 // return all is well
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIExtractIconA Extract

HRESULT CADSIExtractIconA::Extract( LPCSTR /*pszFile*/,
                                    UINT /*nIconIndex*/,
                                    HICON * /*phiconLarge*/,
                                    HICON * /*phiconSmall*/,
                                    UINT /*nIconSize*/)
{
 // tell the calling app to do the load the icon itself
 return S_FALSE;
}

//////////////////////////////////////////////////////////////////////////
// CADSIExtractIconW GetIconLocation

HRESULT CADSIExtractIconW::GetIconLocation( THIS_ UINT /*uFlags*/,
                                            LPWSTR szIconFile,
                                            UINT cchMax,
                                            int * piIndex,
                                            UINT * pwFlags)
{
 // get the module file name
 if ( 0 == ::GetModuleFileNameW(_Module.GetModuleInstance(),
                               szIconFile,cchMax) )
   {
   DWORD dwError = ::GetLastError();
   return HRESULT_FROM_WIN32(dwError);
   }

 // if there is a place for the Icon Index
 if ( NULL != piIndex )
   {
   // take the icon resource ID and flag that it is just that
   // by turning on the high order bit
   *piIndex = -1 * (int)m_dwIcon;
   }

 // set that there are no special requirements on the icons
 if ( NULL != pwFlags )
   {
   *pwFlags = 0;
   }

 // return all is well
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIExtractIconW Extract

HRESULT CADSIExtractIconW::Extract( THIS_ LPCWSTR /*pszFile*/,
                                    UINT /*nIconIndex*/,
                                    HICON * /*phiconLarge*/,
                                    HICON * /*phiconSmall*/,
                                    UINT /*nIconSize*/)
{
 // tell the calling app to do the load the icon itself
 return S_FALSE;
}

//////////////////////////////////////////////////////////////////////////
//

