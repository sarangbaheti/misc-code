//////////////////////////////////////////////////////////////////////////
//
// Filename:     ADSIClassicView.cpp
//
// Description:  This implements the old style view
//
// Author(s):    Todd Daniell, Doug Bahr, Dave Mims, Brian Daigle
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////

#include "stdafx.h"

// use the STL string object
#include <string>
using namespace std;

#include "ADSIClassicView.h"

#ifndef _ADSIPIDLHELPER_H
#include "ADSIPIDLHELPER.H"
#endif

//////////////////////////////////////////////////////////////////////////
// constants

const DWORD DW_COLUMN_RESID_BEGIN    = IDS_COLUMN_NAME;
const DWORD DW_COLUMN_RESID_END      = IDS_COLUMN_PATHTOPARENT;
const DWORD MAX_ADS_ENUM             = 100;

//////////////////////////////////////////////////////////////////////////
// macros

#define COLUMN_RESID2INDEX(theResId) (theResId - DW_COLUMN_RESID_BEGIN)
#define COLUMN_INDEX2RESID(theIndex) (DW_COLUMN_RESID_BEGIN + theIndex)
#define GET_BSTR_VALUE(FUNCTION,STRING) \
{                                    \
 BSTR bstrValue = NULL;              \
 pADSIObject->FUNCTION(&bstrValue);  \
                                     \
 /* if we have the value */          \
 if ( NULL != bstrValue )            \
   {                                 \
   /* convert this */                \
   STRING = OLE2A(bstrValue);        \
                                     \
   ::SysFreeString(bstrValue);       \
   bstrValue = NULL;                 \
   }                                 \
}

//////////////////////////////////////////////////////////////////////////
// CCADSIClassicView Constructor

CADSIClassicView::CADSIClassicView():m_listView(this)
{ 
 // Nullify the member vars
 ClearMemberVar();
}

//////////////////////////////////////////////////////////////////////////
// CCADSIClassicView Destructor

CADSIClassicView::~CADSIClassicView()
{
 // Verifty that the list control was deleted
 _ASSERTE( NULL == (HWND) m_listView );

 // Nullify the member vars
 ClearMemberVar();
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView ClearMemberVar

void CADSIClassicView::ClearMemberVar()
{
 // Clear the Cookie
 m_dwAdviseCookie = 0;
 m_bWindowOnly = TRUE;

 // We are not implace activated by default
 m_bInPlace = FALSE;

 // Clear the Folder Settings
 ::ZeroMemory( &m_FolderSettings, sizeof( m_FolderSettings ));

 // Clear the base Parent Rect
 ::ZeroMemory( &m_rcParent, sizeof( m_rcParent ));
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView CreateView

STDMETHODIMP CADSIClassicView::CreateView( IUnknown  *pIUnkShellView,
                                           IUnknown  *pIUnkShellBrowser,
                                           IUnknown  *pIUnkShellFolder, 
                                           UINT       uhwndParent,
                                           UINT       uTop,           
                                           UINT       uLeft,          
                                           UINT       uBottom,        
                                           UINT       uRight,         
                                           UINT       uViewMode,      
                                           UINT       uFlags,         
                                           UINT      *phWnd )
{
 // Track the ADSI Path associated with the folder of this view
 try
   {
   // Initialize the return
   *phWnd = NULL;
   }
 catch(...)
   {
   return E_FAIL;
   }

 // Track a reference to the Shell Folder
 m_pIShellFolder = pIUnkShellFolder;

 // Track a reference to the shell browser
 m_pIShellBrowser = pIUnkShellBrowser;

 // Save the current view folder 
 // setting for when GetCurrentInfo is called
 m_FolderSettings.ViewMode = uViewMode;
 m_FolderSettings.fFlags   = uFlags;

 // Set the list view to the specified view style
 long lInitialView = NULL;

 switch( m_FolderSettings.ViewMode )
   {
   case FVM_ICON:
     lInitialView = LVS_ICON;
     break;
   case FVM_SMALLICON:
     lInitialView = LVS_SMALLICON;
     break;
   case FVM_LIST:
     lInitialView = LVS_LIST;
     break;
   case FVM_DETAILS:
     lInitialView = LVS_REPORT;
     break;
   default:
     ASSERT(0);
     m_FolderSettings.ViewMode = FVM_DETAILS;
     lInitialView = LVS_REPORT;
     break;
   }

 _ASSERTE( NULL != uhwndParent );

 // Instantiate the Classic View

 if ( !m_bInPlace )
   {
   RECT  rcView;

   rcView.top    = uTop;
   rcView.bottom = uBottom;
   rcView.left   = uLeft;
   rcView.right  = uRight;

   Create( (HWND) uhwndParent,
           rcView, 
           _T("ADSI Classic View"), 
           WS_VISIBLE | WS_CHILD, 
           0, 
           0 );
   }

 if (!m_hWnd)
   {
   _ASSERTE(0);
   return E_FAIL;
   }

 // Create the list view
 if (NULL == m_listView.CreateEx( m_hWnd, 
                                 (RECT&) m_rcParent, 
                                 lInitialView ))
   {
   _ASSERTE(0);
   return E_OUTOFMEMORY;
   }

 // Set the Control for Single Select Only
 long lStyle = m_listView.StyleGet();

 lStyle |= LVS_SINGLESEL;

 m_listView.StyleSet( lStyle );

 // Add the properties that are consistant across all
 for ( UINT nIndex = DW_COLUMN_RESID_BEGIN; 
       nIndex <= DW_COLUMN_RESID_END; 
       ++nIndex )
   {
   TCHAR szColumnName[48] = { 0 };
   VERIFY(0 != ::LoadString(_Module.GetResourceInstance(), 
                             nIndex, 
                             szColumnName, 
                             sizeof(szColumnName)));

   HRESULT hr = m_listView.ColumnAdd(szColumnName);

   if ( FAILED( hr ))
     {
     _ASSERTE(0);
     return hr;
     }
   }

 // Return the caller my window
 *phWnd = (UINT) ((HWND) m_hWnd );

 // Update/refresh the view
 return Refresh();
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView Refresh

STDMETHODIMP CADSIClassicView::Refresh()
{
 // Remove the row data presented in the view
 HRESULT hr = m_listView.RowRemoveAll();
 if (FAILED(hr))
   {
   ASSERT(0);
   return hr;
   }

 // Get the row data and reinsert into the view
 VERIFY( SUCCEEDED( FillInListView() ) );

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView DestroyView

STDMETHODIMP CADSIClassicView::DestroyView()
{
 // Make sure the list control was created
 if (NULL == (HWND)m_listView)
   {
   ASSERT(0);
   return S_OK;
   }

 // Cleanup the rows
 VERIFY(SUCCEEDED(m_listView.RowRemoveAll()));

 // Cleanup the cols
 VERIFY(SUCCEEDED(m_listView.ColumnRemoveAll()));

 // Destroy the list view
 VERIFY(m_listView.DestroyWindow());

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView GetWindow

STDMETHODIMP CADSIClassicView::GetWindow( UINT * lphWnd )
{
 HRESULT hr = S_OK;
 try
   {
   _ASSERTE(NULL != lphWnd);

   *lphWnd = (UINT) m_hWnd;
   }
 catch( ... )
   {
   _ASSERTE(0);
   hr = E_FAIL;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView GetCurrentInfo

STDMETHODIMP CADSIClassicView::GetCurrentInfo( UINT * puViewMode, 
                                               UINT * puFlags )
{
 ASSERT_POINTER( puViewMode, *puViewMode );
 ASSERT_POINTER( puFlags,    *puFlags );

 *puViewMode = m_FolderSettings.ViewMode;
 *puFlags    = m_FolderSettings.fFlags;

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView SetCurrentInfo

STDMETHODIMP CADSIClassicView::SetCurrentInfo(UINT uViewMode, UINT uFlags)
{
 m_FolderSettings.ViewMode = uViewMode;
 m_FolderSettings.fFlags   = uFlags;

 // Set the list view to the specified view style
 long lView = NULL;

 switch( m_FolderSettings.ViewMode )
   {
   case FVM_ICON:
     lView = LVS_ICON;
     break;
   case FVM_SMALLICON:
     lView = LVS_SMALLICON;
     break;
   case FVM_LIST:
     lView = LVS_LIST;
     break;
   case FVM_DETAILS:
     lView = LVS_REPORT;
     break;
   default:
     m_FolderSettings.ViewMode = FVM_DETAILS;
     lView = LVS_REPORT;
     break;
   }

 m_listView.ViewSet( lView );

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
//  Internal Methods

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView FillInListView

HRESULT CADSIClassicView::FillInListView()
{
 // make a smart pointer ( one that will automatically 
 // release itself when it goes out of scope
 CComPtr <IADs > pADSIObject;

 // Get the IPersistFolder2 Interface ( Only 
 // Available under IE 4.01 and greater shells )
 CComQIPtr<IPersistFolder2, &IID_IPersistFolder2> 
           pIPersistFolder2( m_pIShellFolder );

 // Get the PIDL
 LPITEMIDLIST pIDL = NULL;

 // Get the Current Folder
 HRESULT hr = pIPersistFolder2->GetCurFolder( &pIDL );

 if ( FAILED( hr ))
   return hr;

 ASSERT_POINTER( pIDL, *pIDL );

 // Convert the PIDL to an ADSI Path
 string  strPath;
 hr = g_ADSIPIDLHelper.GetADSIPathFromIDList( pIDL, strPath );

 if ( FAILED( hr ))
   return hr;

 // Destroy the pIDL
 VERIFY(SUCCEEDED( g_ADSIPIDLHelper.Destroy( pIDL )));

 // Get the ADSI Object
 hr = g_ADSIPIDLHelper.GetADSIObject( strPath.c_str(), 
                                     ( IADs *&) pADSIObject );

 if ( FAILED( hr ))
   return hr;

 // make sure that this IS a container
 // make a smart pointer ( one that will automatically 
 // release itself when it goes out of scope
 CComPtr< IADsContainer >    pADSIContainer;

 // now, see if this is a container
 hr = pADSIObject->QueryInterface( IID_IADsContainer,
                                   (LPVOID *) &pADSIContainer );

 if ( FAILED( hr ))
   {
   ASSERT( pADSIContainer == NULL );

   return hr;
   }

 // make sure that this is valid
 ASSERT_POINTER(pADSIContainer,*pADSIContainer);

 // flag that this functions uses the conversion macros
 USES_CONVERSION;

 // flag that we want ALL types
 LPWSTR pwszTypes = NULL;

 // initialize a variant filter
 VARIANT VarFilter;

 ::VariantInit(&VarFilter);

 hr = ::ADsBuildVarArrayStr(&pwszTypes,0,&VarFilter);

 if ( FAILED( hr ))
   {
   VariantClear(&VarFilter);
   return hr;
   }

 // add the filter to the object
 hr = pADSIContainer->put_Filter(VarFilter);

 // clear the variant
 ::VariantClear(&VarFilter);

 if ( FAILED( hr ))
   return hr;

 // get the enumerator
 IEnumVARIANT * pEnumVariant = NULL;
 hr = ::ADsBuildEnumerator(pADSIContainer,&pEnumVariant);

 if ( FAILED( hr ))
   {
   ASSERT( NULL == pEnumVariant );
   return hr;
   }

 ASSERT_POINTER( pEnumVariant, *pEnumVariant );

 // run the list and retrieve them all
 do
   {
   // enumerate all of them
   VARIANT VariantArray[MAX_ADS_ENUM];
   DWORD   dwNumberRetrieved = 0;

   hr = ::ADsEnumerateNext(pEnumVariant,
                           MAX_ADS_ENUM,
                           VariantArray,
                           &dwNumberRetrieved);

   // if there was an error, return
   if ( FAILED(hr) )
     break;

   // figure out if we are done or not
   BOOL bEndThisLoop = FALSE;

   if ( S_FALSE == hr )
      bEndThisLoop = TRUE;

   // make sure that this is within range
   ASSERT( dwNumberRetrieved <= MAX_ADS_ENUM );

   // run the array and do this
   for ( DWORD dwIndex = 0; dwIndex < dwNumberRetrieved; dwIndex++ )
     {
     // get the dispatch
     // NOTE: DO NOT RELEASE THIS OR USE A SMART POINTER
     //       BECAUSE IT IS STILL OWNED BY THE VariantArray
     //       thus we are NOT obtaining ownership!
     IDispatch * pDispatch = VariantArray[dwIndex].pdispVal;
     ASSERT_POINTER(pDispatch,*pDispatch);

     // get the object
     CComPtr< IADs >   pObject;
     hr = pDispatch->QueryInterface(IID_IADs,(LPVOID *)&pObject);

     // clear out the variant
     ::VariantClear(&VariantArray[dwIndex]);

     if ( FAILED(hr) )
       {
       ASSERT( pObject == NULL );
       continue;
       }

     // generate the IDList of this object
     hr = AddObjectToList( pObject );

     if ( FAILED( hr ))
       {
       bEndThisLoop = TRUE;
       break;
       }
     }

   // if we are done, get the heck out of dodge!
   if ( bEndThisLoop )
     break;

   } while ( TRUE );

 // if this failed
 if ( FAILED(hr) )
   return hr;

 // return all is well
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView AddObjectToList

HRESULT CADSIClassicView::AddObjectToList(IADs * pADSIObject)
{
 // make sure that the pointer is valid
 ASSERT_POINTER(pADSIObject,*pADSIObject);

 USES_CONVERSION;

 // get the name of the object
 string strName;
 GET_BSTR_VALUE(get_Name,strName);

 // get the ADS PATH
 string strPath;
 GET_BSTR_VALUE(get_ADsPath,strPath);

 // get the class
 string strClass;
 GET_BSTR_VALUE(get_Class,strClass);

 // get the GUID
 string strGuid;
 GET_BSTR_VALUE(get_GUID,strGuid);
        
 // get the parent
 string strParent;
 GET_BSTR_VALUE(get_Parent,strParent);

 // get the schema
 string strSchema;
 GET_BSTR_VALUE(get_Schema,strSchema);

 // figure out the Icon To use
 DWORD dwIconID = 0;
 g_ADSIPIDLHelper.FigureOutWhatIconToUse(pADSIObject,dwIconID);

 // Load the Icon
 HICON hIcon = ::LoadIcon(_Module.GetResourceInstance(), 
                           MAKEINTRESOURCE(dwIconID));
 if (NULL == hIcon)
   {
   DWORD dwError = ::GetLastError();
   ASSERT(0);
   return HRESULT_FROM_WIN32(dwError);
   }

 int iIndexImage = -1;
 HRESULT hr = m_listView.ImageListImageIndex(hIcon, iIndexImage);
 if (FAILED(hr))
   {
   ASSERT(0);
   return hr;
   }

 ASSERT(-1 != iIndexImage);
 ASSERT(0 == COLUMN_RESID2INDEX(IDS_COLUMN_NAME));

 // Put the Name on the List Control
 DWORD dwIndexRow = 0;

 hr = m_listView.RowItemSet(dwIndexRow, 
                            COLUMN_RESID2INDEX(IDS_COLUMN_NAME), 
                            strName.c_str(), 
                            NULL, 
                            iIndexImage);
 if (FAILED( hr ))
   {
   ASSERT(0);
   return hr;
   }

 // Put the ADSI Path on the List Control
 hr = m_listView.RowItemSet(dwIndexRow, 
                            COLUMN_RESID2INDEX(IDS_COLUMN_ADSIPATH), 
                            strPath.c_str());
 if (FAILED( hr ))
   {
   ASSERT(0);
   return hr;
   }

 // Put the Guid on the List Control
 hr = m_listView.RowItemSet(dwIndexRow, 
                            COLUMN_RESID2INDEX(IDS_COLUMN_GUID), 
                            strGuid.c_str());
 if (FAILED(hr))
   {
   ASSERT(0);
   return hr;
   }

 // Put the Class on the List Control
 hr = m_listView.RowItemSet(dwIndexRow, 
                            COLUMN_RESID2INDEX(IDS_COLUMN_CLASS), 
                            strClass.c_str());
 if (FAILED(hr))
   {
   ASSERT(0);
   return hr;
   }

 // Put the Schema on the List Control
 hr = m_listView.RowItemSet(dwIndexRow, 
                            COLUMN_RESID2INDEX(IDS_COLUMN_SCHEMA), 
                            strSchema.c_str());
 if (FAILED(hr))
   {
   ASSERT(0);
   return hr;
   }

 // Put the Parent on the List Control
 hr = m_listView.RowItemSet(dwIndexRow, 
                            COLUMN_RESID2INDEX(IDS_COLUMN_PATHTOPARENT), 
                            strParent.c_str());
 if (FAILED(hr))
   {
   ASSERT(0);
   return hr;
   }

 // return all is well
 return hr;
}

//////////////////////////////////////////////////////////////////////////
// Events proprigated from the list view

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView OnDblClick

LRESULT CADSIClassicView::OnDblClick(int     /* idCtrl */, 
                                     LPNMHDR pnmh, 
                                     BOOL&   /* bHandled */ )
{
 // Browse into the selected ADSI Object

 // Get the ADSI path of the row that was selected
 LPNMLISTVIEW lpNMListView = (LPNMLISTVIEW)pnmh;

 ASSERT_POINTER(lpNMListView, *lpNMListView);

 TCHAR szADSIPath[2048] = { 0 };
 HRESULT hr = m_listView.RowItemGet(
                               lpNMListView->iItem, 
                               COLUMN_RESID2INDEX(IDS_COLUMN_ADSIPATH), 
                               szADSIPath, 
                               sizeof(szADSIPath));
 if (FAILED(hr))
   {
   ASSERT(0);
   return 0;
   }

 // Build a pidl based on the current path
 BOOL bIsContainer = TRUE;
 LPITEMIDLIST pIDList = NULL;
 hr = g_ADSIPIDLHelper.GetIDListOfADSIObject(szADSIPath, 
                                             pIDList, 
                                             bIsContainer);
 if (FAILED(hr))
   {
   ASSERT(0);
   return 0;
   }

 if (!bIsContainer)
   {
   VERIFY(SUCCEEDED(g_ADSIPIDLHelper.Destroy(pIDList)));
   return 0;
   }

 ASSERT_POINTER(m_pIShellBrowser, *m_pIShellBrowser);

 // Browse to the new folder
 VERIFY(SUCCEEDED(m_pIShellBrowser->BrowseObject(pIDList, 
                         SBSP_DEFBROWSER|SBSP_DEFMODE|SBSP_RELATIVE)));

 VERIFY(SUCCEEDED(g_ADSIPIDLHelper.Destroy(pIDList)));

 // Do the default stuff
 return 0;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView OnSelChanged

LRESULT CADSIClassicView::OnSelChanged(int /* idCtrl */, 
                                       LPNMHDR /*pnmh*/, 
                                       BOOL& /* bHandled */)
{
 Fire_OnSelectionChanged();

 // Do the default stuff
 return 0;
}

//////////////////////////////////////////////////////////////////////////
// Support for ISupportErrorInfo Interface

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView InterfaceSupportsErrorInfo

STDMETHODIMP CADSIClassicView::InterfaceSupportsErrorInfo(REFIID riid)
{
 static const IID* arr[] = 
   {
   &IID_IADSIClassicView
   };

 for (int i=0;i<sizeof(arr)/sizeof(arr[0]);i++)
   {
   if (InlineIsEqualGUID(*arr[i],riid))
     return S_OK;
   }

 return S_FALSE;
}

//////////////////////////////////////////////////////////////////////////
// Support for IOleObject Interface Overloads

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView SetClientSite

HRESULT CADSIClassicView::SetClientSite(IOleClientSite *pClientSite)
{
 HRESULT hr = S_OK;

 // If we are given a client site, then we are in a WEB view.
 m_bInPlace = TRUE;

 if ( NULL != pClientSite )
   {
   // SetClientSite called

   if ( m_spClientSite )
     m_spClientSite->Release();

   m_spClientSite = pClientSite;  // This AddRefs the client site
   }
 else
   {
   _ASSERT( 0 != m_dwAdviseCookie );
   _ASSERT( m_pIWebBrowser2 != NULL );

   // SetClientSite NULL Called

   hr = AtlUnadvise( m_pIWebBrowser2, 
                     IID_DWebBrowserEvents2, 
                     m_dwAdviseCookie );

   m_pIWebBrowser2.Release();

   return S_OK;
   }
 
 try
   {
   CComQIPtr< IServiceProvider, &IID_IServiceProvider > 
               pIServiceProvider(( LPOLECLIENTSITE ) m_spClientSite );

   if ( pIServiceProvider == NULL )
     {
     return hr;
     }

   pIServiceProvider->QueryService( IID_IWebBrowserApp,
                                    IID_IWebBrowser2,
                          (void **) &m_pIWebBrowser2 );

   hr = AtlAdvise( m_pIWebBrowser2, 
                   GetControllingUnknown(),
                   IID_DWebBrowserEvents2,
                   &m_dwAdviseCookie );
   }
 catch(...)
   {
     hr = S_FALSE;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView SetClientSite

STDMETHODIMP CADSIClassicView::SetObjectRects( LPCRECT prcPos, 
                                               LPCRECT prcClip )
{
 IOleInPlaceObjectWindowlessImpl<CADSIClassicView>

 ::SetObjectRects( prcPos, prcClip );

 int cx, cy;

 cx = prcPos->right - prcPos->left;
 cy = prcPos->bottom - prcPos->top;

 if ( ::IsWindow( m_listView ))
   ::SetWindowPos( m_listView, 
                   NULL, 
                   0, 
                   0, 
                   cx, 
                   cy, 
                   SWP_NOZORDER | SWP_NOACTIVATE );

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// Base Window Functions

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView OnCreate

LRESULT CADSIClassicView::OnCreate(UINT uMsg, 
                                   WPARAM wParam, 
                                   LPARAM lParam, 
                                   BOOL& bHandled)
{
 GetWindowRect( &m_rcParent );

 m_rcParent.right  -= m_rcParent.left;
 m_rcParent.bottom -= m_rcParent.top;
 m_rcParent.top    =  m_rcParent.left = 0;

 return 0;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView OnSize

LRESULT CADSIClassicView::OnSize(UINT uMsg, 
                                 WPARAM wParam, 
                                 LPARAM lParam, 
                                 BOOL& bHandled)
{
 int cx, cy;

 cx = LOWORD( lParam );
 cy = HIWORD( lParam );

 if ( ::IsWindow( m_listView ))
   ::SetWindowPos( m_listView, 
                   NULL, 
                   0, 
                   0, 
                   cx, 
                   cy, 
                   SWP_NOZORDER | SWP_NOACTIVATE );

 return 0;
}

//////////////////////////////////////////////////////////////////////////
// DWebBrowserEvents2

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView StatusTextChange

STDMETHODIMP CADSIClassicView::StatusTextChange(BSTR Text)
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView ProgressChange

STDMETHODIMP CADSIClassicView::ProgressChange(long Progress, 
                                            long ProgressMax)
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView CommandStateChange

STDMETHODIMP CADSIClassicView::CommandStateChange(long Command, 
                                                VARIANT_BOOL Enable)
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView DownloadBegin

STDMETHODIMP CADSIClassicView::DownloadBegin()
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView DownloadComplete

STDMETHODIMP CADSIClassicView::DownloadComplete()
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView TitleChange

STDMETHODIMP CADSIClassicView::TitleChange(BSTR Text)
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView PropertyChange

STDMETHODIMP CADSIClassicView::PropertyChange(BSTR szProperty)
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView BeforeNavigate2

STDMETHODIMP CADSIClassicView::BeforeNavigate2(IDispatch* pDisp, 
                                               VARIANT* URL, 
                                               VARIANT* Flags, 
                                               VARIANT* TargetFrameName, 
                                               VARIANT* PostData, 
                                               VARIANT* Headers, 
                                               VARIANT_BOOL* Cancel)
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView NewWindow2

STDMETHODIMP CADSIClassicView::NewWindow2(IDispatch** ppDisp, 
                                          VARIANT_BOOL* Cancel)
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView NavigateComplete2

STDMETHODIMP CADSIClassicView::NavigateComplete2(IDispatch* pDisp, 
                                                 VARIANT* URL)
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView DocumentComplete

STDMETHODIMP CADSIClassicView::DocumentComplete(IDispatch* pDisp, 
                                                VARIANT* URL)
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView OnQuit

STDMETHODIMP CADSIClassicView::OnQuit()
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView OnVisible

STDMETHODIMP CADSIClassicView::OnVisible(VARIANT_BOOL Visible)
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView OnToolBar

STDMETHODIMP CADSIClassicView::OnToolBar(VARIANT_BOOL ToolBar)
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView OnMenuBar

STDMETHODIMP CADSIClassicView::OnMenuBar(VARIANT_BOOL MenuBar)
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView OnStatusBar

STDMETHODIMP CADSIClassicView::OnStatusBar(VARIANT_BOOL StatusBar)
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView OnFullScreen

STDMETHODIMP CADSIClassicView::OnFullScreen(VARIANT_BOOL FullScreen)
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView OnTheaterMode

STDMETHODIMP CADSIClassicView::OnTheaterMode(VARIANT_BOOL TheaterMode)
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
//
// Methods that Supplies Information to Java Script and WEB View

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView GetSelectedRow

HRESULT CADSIClassicView::GetSelectedRow( int &nSelectedRow )
{
 HRESULT hr = S_OK;

 // Initialize the Selected Row
 nSelectedRow = NULL;

 // Get the Number of Rows Available
 int nNumRows = m_listView.RowCount();

 // Loop to Find the Selected Row
 while (( nSelectedRow < nNumRows ) && ( SUCCEEDED( hr )))
   {
   UINT uState = NULL;

   // Get the State of the Row
   hr = m_listView.RowStateGet( nSelectedRow, LVIS_SELECTED, uState );

   // Did we retrieve it and is it Selected
   if ( SUCCEEDED(hr) && (( uState & LVIS_SELECTED ) == LVIS_SELECTED))
       break;

   // Increment to Next Rows.
   nSelectedRow++;
   }

 // Did we reach the end of the list ?
 if ( nSelectedRow >= nNumRows )
   hr = E_FAIL;

 // If we failed to find a selected item,
 //  reflect it in the Selected Row.
 if ( FAILED( hr ))
   nSelectedRow = -1;

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView GetCurrentPath

STDMETHODIMP CADSIClassicView::GetCurrentPath( VARIANT * pvarPath )
{
 // make a smart pointer ( one that will automatically release 
 // itself when it goes out of scope
 CComPtr< IADs >   pADSIObject;

 // Get the IPersistFolder2 Interface ( Only Available 
 // under IE 4.01 and greater shells )
 CComQIPtr<IPersistFolder2, &IID_IPersistFolder2> 
                   pIPersistFolder2( m_pIShellFolder );

 // Get the PIDL
 LPITEMIDLIST pIDL = NULL;

 // Get the Current Folder
 HRESULT hr = pIPersistFolder2->GetCurFolder( &pIDL );

 if ( FAILED( hr ))
   return hr;

 ASSERT_POINTER( pIDL, *pIDL );

 // Convert the PIDL to an ADSI Path
 string  strPath;
 hr = g_ADSIPIDLHelper.GetADSIPathFromIDList( pIDL, strPath );

 if ( SUCCEEDED( hr ))
   {
     // Create the BSTR to return
   CComBSTR bstrPath = strPath.c_str();

     // Assign the return Pointer to the Path
   CComVariant varPath;
   varPath.Attach( pvarPath );
   varPath = bstrPath.Copy();
   varPath.Detach( pvarPath );
   }

 // Destroy the pIDL
 VERIFY( SUCCEEDED( g_ADSIPIDLHelper.Destroy( pIDL )));

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView GetSelectedName

STDMETHODIMP CADSIClassicView::GetSelectedName( VARIANT * pvarName )
{
 HRESULT hr = E_FAIL;

 // Get the Selected Row
 int nSelectedRow = 0;

 if ( SUCCEEDED( hr = GetSelectedRow( nSelectedRow )))
   {
   TCHAR szADSIName[256] = { 0 };

   hr = m_listView.RowItemGet( nSelectedRow, 
                               COLUMN_RESID2INDEX( IDS_COLUMN_NAME ),
                               szADSIName, sizeof( szADSIName ));

   if ( SUCCEEDED( hr ))
     {
     // Create the BSTR to return
     CComBSTR bstrName = szADSIName;

     // Assign the return Pointer to the Name
     CComVariant varName;
     varName.Attach( pvarName );
     varName = bstrName.Copy();
     varName.Detach( pvarName );
     }
   }

 // If we failed
 if ( FAILED( hr ))
   {
     // Create a "Blank" BSTR to return
   CComBSTR bstrName = "";

   // Assign the return Pointer to the Name
   CComVariant varName;
   varName.Attach( pvarName );
   varName.Clear();
   varName = bstrName.Copy();
   varName.Detach( pvarName );
   hr = S_OK;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView GetSelectedGUID

STDMETHODIMP CADSIClassicView::GetSelectedGUID( VARIANT * pvarGUID )
{
 HRESULT hr = E_FAIL;

 // Get the Selected Row
 int nSelectedRow = 0;

 if ( SUCCEEDED( hr = GetSelectedRow( nSelectedRow )))
   {
   TCHAR szADSIGuid[256] = { 0 };

   hr = m_listView.RowItemGet( nSelectedRow, 
                               COLUMN_RESID2INDEX( IDS_COLUMN_GUID ),
                               szADSIGuid, sizeof( szADSIGuid ));

   if ( SUCCEEDED( hr ))
     {
     // Create the BSTR to return
     CComBSTR bstrGuid = szADSIGuid;

     // Assign the return Pointer to the Name
     CComVariant varGuid;
     varGuid.Attach( pvarGUID );
     varGuid.Clear();
     varGuid = bstrGuid.Copy();
     varGuid.Detach( pvarGUID );
     }
   }

 // If we failed
 if ( FAILED( hr ))
   {
     // Create a "Blank" BSTR to return
   CComBSTR bstrGuid = "";

   // Assign the return Pointer to the Name
   CComVariant varGuid;
   varGuid.Attach( pvarGUID );
   varGuid = bstrGuid.Copy();
   varGuid.Detach( pvarGUID );

   hr = S_OK;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIClassicView GetSelectedClass

STDMETHODIMP CADSIClassicView::GetSelectedClass( VARIANT * pvarClass)
{
 HRESULT hr = E_FAIL;

 // Get the Selected Row
 int nSelectedRow = 0;

 if ( SUCCEEDED( hr = GetSelectedRow( nSelectedRow )))
   {
   TCHAR szADSIClass[256] = { 0 };

   hr = m_listView.RowItemGet( nSelectedRow, 
                               COLUMN_RESID2INDEX(IDS_COLUMN_CLASS),
                               szADSIClass, sizeof(szADSIClass));

   if ( SUCCEEDED( hr ))
     {
     // Create the BSTR to return
     CComBSTR bstrClass = szADSIClass;

     // Assign the return Pointer to the Name
     CComVariant varClass;
     varClass.Attach( pvarClass );
     varClass = bstrClass.Copy();
     varClass.Detach( pvarClass );
     }
   }

 // If we failed
 if ( FAILED( hr ))
   {
     // Create a "Blank" BSTR to return
   CComBSTR bstrClass = "";

   // Assign the return Pointer to the Name
   CComVariant varClass;
   varClass.Attach( pvarClass );
   varClass = bstrClass.Copy();
   varClass.Detach( pvarClass );

   hr = S_OK;
   }

 return hr;
}

