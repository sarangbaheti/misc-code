//////////////////////////////////////////////////////////////////////////
//
// Filename:     ADSIWebView.cpp
//
// Description:  ADSI Web View program file
//             
//               The ADSI Web View is an OLE Container used to insert
//               Microsoft's Web Browser control and navigate it to a
//               specific HTML template file (ADSI.HTT).  The HTML script
//               uses DHTML to include our Classic View ActiveX control.
//               After the document is fully loaded by the web control,
//               then the magic happens.  The Web View walks the Document
//               Object Model (DOM) used within the DHTML framework and
//               accessed via interfaces in the web browser control.
//               The document is searched for an object with the same
//               class id tag that is our Classic View.  We get the
//               IDispatch interface for the object and create the real
//               view for the control and pass the necessary information
//               to start the view.  We then call the Classic View and
//               get the ADSI path to be displayed on the banner.  The
//               Web View then searches all tags and looks at all of the
//               inner text of each element within the document.  All of
//               the text that has "%THISADSIPATH%" is replaced with the
//               real path to be displayed.  The rest of the communication
//               of the Classic View ActiveX control is handled by the
//               DHTML script using Java scriptlets.  The scriptlet
//               receives events when selections occur and then the
//               Java scriptlet calls back into the Classic View to get
//               the information about the selection to display it on the
//               left pane of the document.
//
//               Both, the Web View and the Classic view support the
//               IWebBrowserEvents2 Interface.  This allows both the host
//               container of the browser and the client ActiveX control
//               within the browser to receive events about the browser.
//               The events are important to the host container (Web View)
//               because the communcation between the Classic View and the
//               Web View cannot be connected until the document is fully
//               loaded.
//
// Author(s):    Brian Daigle
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
// CADSIWebView.cpp : Implementation of CADSIWebView
//////////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include <string>
using namespace std;

#include "ADSIWebView.h"
#include "ADSIClassicView.h"

#include <comdef.h>
#include <atlconv.h>

//////////////////////////////////////////////////////////////////////////
// BSTR Conversion macros

//////////////////////////////////////////////////////////////////////////
// Convert a BSTR to a String (STL) and Free the BSTR

#define CONVERT_BSTR_TO_STRING( bstrValue, STRING ) \
{                              \
 {                             \
 USES_CONVERSION;              \
                               \
 /* if we have the value */    \
 if ( NULL != bstrValue )      \
   {                           \
   /* convert this */          \
   STRING = OLE2A(bstrValue);  \
                               \
   ::SysFreeString(bstrValue); \
   bstrValue = NULL;           \
   }                           \
 }                             \
}

//////////////////////////////////////////////////////////////////////////
// Convert a String (STL) to a BSTR

#define CONVERT_STRING_TO_BSTR( STRING, bstrValue )  \
{                                      \
 {                                     \
 USES_CONVERSION;                      \
                                       \
 /* if we have the value */            \
 if ( NULL != bstrValue )              \
   {                                   \
   /* free the old one */              \
   ::SysFreeString(bstrValue);         \
   bstrValue = NULL;                   \
   }                                   \
                                       \
 /* convert this */                    \
 bstrValue = A2BSTR( STRING.c_str() ); \
 }                                     \
}

//////////////////////////////////////////////////////////////////////////
// Free a BSTR

#define FREE_BSTR( bstrValue ) \
{                              \
 /* if we have the value */    \
 if ( NULL != bstrValue )      \
   {                           \
   /* free the old one */      \
   ::SysFreeString(bstrValue); \
   bstrValue = NULL;           \
   }                           \
}

//////////////////////////////////////////////////////////////////////////
// ClassicView clsid name used in the HTML page

const TCHAR szCLSIDClassicView[] =
                       _T("clsid:E07D9227-A8D5-11D1-9E97-00A0C93C9527");

const TCHAR szTemplateName[] = _T("ADSI.HTT");

//////////////////////////////////////////////////////////////////////////
// CADSIWebView Constructor

CADSIWebView::CADSIWebView()
{ 
 // Nullify the member vars
 ClearMemberVars();
}

//////////////////////////////////////////////////////////////////////////
// CADSIWebView Destructor

CADSIWebView::~CADSIWebView()
{
}

//////////////////////////////////////////////////////////////////////////
// ClearMemberVars

void CADSIWebView::ClearMemberVars()
{
 m_bInPlaceActive = FALSE;
 m_dwWebBrowserEvents2Sink = 0;

 ::ZeroMemory( &m_FolderSettings, sizeof( m_FolderSettings ) );

 m_pIUnkShellView = NULL;
 m_pIADSIClassicView = NULL;

 m_pIOleObject = NULL;
 m_pIWebBrowser2 = NULL;
}

//////////////////////////////////////////////////////////////////////////
// MessageMap Handlers

//////////////////////////////////////////////////////////////////////////
// OnNCDestroy

LRESULT CADSIWebView::OnNCDestroy( UINT    /* uMsg    */,
                                   WPARAM  /* wParam  */,
                                   LPARAM  /* lParam  */,
                                   BOOL&   /* lResult */ )
{
 // Do nothing.  The Destruction is handled in the
 // DestroyView of the Web View
 return 0;
}

//////////////////////////////////////////////////////////////////////////
// OnSize

LRESULT CADSIWebView::OnSize(  UINT    /* uMsg    */,
                               WPARAM  /* wParam  */,
                               LPARAM  /* lParam  */,
                               BOOL&   /* lResult */ )
{
 // Size the web control if we are activated
 if ( m_pIOleObject && m_bInPlaceActive )
   {
   // Query for the IOleInPlaceObject for the Web Control
   CComQIPtr< IOleInPlaceObject, &IID_IOleInPlaceObject >
             pInPlaceObject(m_pIOleObject);

   if (pInPlaceObject)
     {
     RECT rcClient;

     // Get the client rectangle and set its new position and size
     GetClientRect( &rcClient );
     pInPlaceObject->SetObjectRects( &rcClient, &rcClient );
     }
   }

 return 0;
}

//////////////////////////////////////////////////////////////////////////
// OnErase

LRESULT CADSIWebView::OnErase( UINT    /* uMsg   */,
                               WPARAM  /* wParam */,
                               LPARAM  /* lParam */,
                               BOOL&      bHandled )
{
 // Return ok if we are active.
 if ( m_bInPlaceActive )
   return 0;

 // Return fail since we are not active
 bHandled = FALSE;
 return 1;
}

//////////////////////////////////////////////////////////////////////////
// ISupportErrorInfo Interface

//////////////////////////////////////////////////////////////////////////
// InterfaceSupportsErrorInfo

STDMETHODIMP CADSIWebView::InterfaceSupportsErrorInfo( REFIID riid )
{
 static const IID* arr[] = { &IID_IADSIWebView };

 HRESULT hr = E_FAIL;

 try
   {
   // Compare the interface ID
   for (int i=0;i<sizeof(arr)/sizeof(arr[0]);i++)
     {
     if (InlineIsEqualGUID(*arr[i],riid))
       hr = S_OK;
     }
   }
 catch( ... )
   {
   _ASSERTE(0);
   hr = E_INVALIDARG;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// IViewObjectEx Interface

//////////////////////////////////////////////////////////////////////////
// GetViewStatus

STDMETHODIMP CADSIWebView::GetViewStatus( DWORD *pdwStatus )
{
 HRESULT hr = S_OK;

 ASSERT_POINTER( pdwStatus, *pdwStatus );

 try
   {
   // View with solid opaque background.
   *pdwStatus = VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE;
   }
 catch( ... )
   {
   _ASSERTE(0);
   hr = E_INVALIDARG;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// IOleWindow Interface

//////////////////////////////////////////////////////////////////////////
// GetWindow

STDMETHODIMP CADSIWebView::GetWindow( HWND *lphWnd )
{
 HRESULT hr = S_OK;

 ASSERT_POINTER( lphWnd, *lphWnd );

 try
   {
   // Return the window handle
   *lphWnd = m_hWnd;
   }
 catch( ... )
   {
   _ASSERTE(0);
   hr = E_INVALIDARG;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// ContextSensitiveHelp

STDMETHODIMP CADSIWebView::ContextSensitiveHelp( BOOL fEnterMode )
{
 ATLTRACENOTIMPL(_T("IOleWindow::ContextSensitiveHelp IOleWindow\n"));
}

//////////////////////////////////////////////////////////////////////////
// IOleClientSite Interface

//////////////////////////////////////////////////////////////////////////
// SaveObject

STDMETHODIMP CADSIWebView::SaveObject( void )
{
 ATLTRACENOTIMPL(_T("CADSIWebView::SaveObject IOleClientSite\n"));
}

//////////////////////////////////////////////////////////////////////////
// GetMoniker

STDMETHODIMP CADSIWebView::GetMoniker( DWORD dwAssign,
                                       DWORD dwWhichMoniker,
                                       IMoniker **ppmk )
{
 ATLTRACENOTIMPL(_T("CADSIWebView::GetMoniker IOleClientSite\n"));
}

//////////////////////////////////////////////////////////////////////////
// GetContainer

STDMETHODIMP CADSIWebView::GetContainer( IOleContainer **ppContainer )
{
 HRESULT hr = S_OK;

 ASSERT_POINTER( ppContainer, *ppContainer );

 try
   {
   // Get the OleContainer
   CComQIPtr< IOleContainer, &IID_IOleContainer > pOleContainer( this );

   if (pOleContainer)
     {
     // Give the object a reference
     pOleContainer->AddRef();

     // Return the Interface
     *ppContainer = pOleContainer;
     }
   else
     {
     _ASSERTE(0);
     hr = E_FAIL;
     }
   }
 catch( ... )
   {
   _ASSERTE(0);
   hr = E_INVALIDARG;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// ShowObject

STDMETHODIMP CADSIWebView::ShowObject( void )
{
 ATLTRACENOTIMPL(_T("CADSIWebView::ShowObject IOleClientSite\n"));
}

//////////////////////////////////////////////////////////////////////////
// OnShowWindow

STDMETHODIMP CADSIWebView::OnShowWindow(BOOL fShow)
{
 ATLTRACENOTIMPL(_T("CADSIWebView::OnShowWindow IOleClientSite\n"));
}

//////////////////////////////////////////////////////////////////////////
// RequestNewObjectLayout

STDMETHODIMP CADSIWebView::RequestNewObjectLayout( void )
{
 ATLTRACENOTIMPL(
   _T("CADSIWebView::RequestNewObjectLayout IOleClientSite\n"));
}

//////////////////////////////////////////////////////////////////////////
// IOleContainer

//////////////////////////////////////////////////////////////////////////
// ParseDisplayName

STDMETHODIMP CADSIWebView::ParseDisplayName(LPBC          pbc,
                                            LPOLESTR      lpszDisplayName,
                                            unsigned long *pchEaten,
                                            LPMONIKER     *ppmkOut )
{
 ATLTRACENOTIMPL(_T("CADSIWebView::ParseDisplayName IOleContainer\n"));
}

//////////////////////////////////////////////////////////////////////////
// EnumObjects

STDMETHODIMP CADSIWebView::EnumObjects(  unsigned long grfFlags,
                                         LPENUMUNKNOWN * ppenumUnknown )
{
 ATLTRACENOTIMPL(_T("CADSIWebView::EnumObjects IOleContainer\n"));
}

//////////////////////////////////////////////////////////////////////////
// LockContainer

STDMETHODIMP CADSIWebView::LockContainer( int fLock )
{
 ATLTRACENOTIMPL(_T("CADSIWebView::LockContainer IOleContainer\n"));
}

//////////////////////////////////////////////////////////////////////////
// IOleInPlaceSite Interface

//////////////////////////////////////////////////////////////////////////
// CanInPlaceActivate

STDMETHODIMP CADSIWebView::CanInPlaceActivate( void )
{
 ATLTRACE(_T("IOleInPlaceSite::CanInPlaceActivate\n"));
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// OnInPlaceActivate

STDMETHODIMP CADSIWebView::OnInPlaceActivate( void )
{
 ATLTRACE(_T("IOleInPlaceSite::OnInPlaceActivate\n"));
 m_bInPlaceActive = TRUE;
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// OnUIActivate

STDMETHODIMP CADSIWebView::OnUIActivate( void )
{
 ATLTRACENOTIMPL(_T("IOleInPlaceSite::OnUIActivate\n"));
}

//////////////////////////////////////////////////////////////////////////
// GetWindowContext

STDMETHODIMP CADSIWebView::GetWindowContext(
                     IOleInPlaceFrame **ppFrame,
                     IOleInPlaceUIWindow **ppDoc,
                     LPRECT lprcPosRect,
                     LPRECT lprcClipRect,
                     LPOLEINPLACEFRAMEINFO lpFrameInfo )
{
 GetClientRect(lprcPosRect);
 GetClientRect(lprcClipRect);
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// Scroll

STDMETHODIMP CADSIWebView::Scroll(SIZE scrollExtant)
{
 ATLTRACENOTIMPL(_T("IOleInPlaceSite::Scroll\n"));
}

//////////////////////////////////////////////////////////////////////////
// OnUIDeactivate

STDMETHODIMP CADSIWebView::OnUIDeactivate(BOOL fUndoable)
{
 ATLTRACENOTIMPL(_T("IOleInPlaceSite::OnUIDeactivate\n"));
}

//////////////////////////////////////////////////////////////////////////
// OnInPlaceDeactivate

STDMETHODIMP CADSIWebView::OnInPlaceDeactivate( void )
{
 ATLTRACE(_T("IOleInPlaceSite::OnInPlaceDeactivate\n"));

 m_bInPlaceActive = FALSE;
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// DiscardUndoState

STDMETHODIMP CADSIWebView::DiscardUndoState( void )
{
 ATLTRACENOTIMPL(_T("IOleInPlaceSite::DiscardUndoState\n"));
}

//////////////////////////////////////////////////////////////////////////
// DeactivateAndUndo

STDMETHODIMP CADSIWebView::DeactivateAndUndo( void )
{
 ATLTRACENOTIMPL(_T("IOleInPlaceSite::DeactivateAndUndo\n"));
}

//////////////////////////////////////////////////////////////////////////
// OnPosRectChange

STDMETHODIMP CADSIWebView::OnPosRectChange(LPCRECT lprcPosRect)
{
 ATLTRACENOTIMPL(_T("CADSIWebView::OnPosRectChange IOleInPlaceSite\n"));
}

//////////////////////////////////////////////////////////////////////////
// DWebBrowserEvents2

//////////////////////////////////////////////////////////////////////////
// StatusTextChange

STDMETHODIMP CADSIWebView::StatusTextChange( BSTR Text )
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// ProgressChange

STDMETHODIMP CADSIWebView::ProgressChange( long Progress,
                                           long ProgressMax )
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CommandStateChange

STDMETHODIMP CADSIWebView::CommandStateChange( long Command,
                                               VARIANT_BOOL Enable )
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
//  DownloadBegin

STDMETHODIMP CADSIWebView::DownloadBegin()
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// DownloadComplete

STDMETHODIMP CADSIWebView::DownloadComplete()
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// TitleChange

STDMETHODIMP CADSIWebView::TitleChange( BSTR Text )
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// PropertyChange

STDMETHODIMP CADSIWebView::PropertyChange( BSTR szProperty )
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// BeforeNavigate2

STDMETHODIMP CADSIWebView::BeforeNavigate2(
                                     IDispatch     *pDisp,
                                     VARIANT       *URL,
                                     VARIANT       *Flags,
                                     VARIANT       *TargetFrameName,
                                     VARIANT       *PostData,
                                     VARIANT       *Headers,
                                     VARIANT_BOOL  *Cancel )
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// NewWindow2

STDMETHODIMP CADSIWebView::NewWindow2( IDispatch     **ppDisp,
                                       VARIANT_BOOL   *Cancel  )
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// NavigateComplete2

STDMETHODIMP CADSIWebView::NavigateComplete2( IDispatch *pDisp,
                                              VARIANT   *URL  )
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// DocumentComplete

STDMETHODIMP CADSIWebView::DocumentComplete( IDispatch *pDisp,
                                             VARIANT   *URL )
{
 HRESULT hr = S_OK;
 BOOL    bDocumentCompleted = FALSE;

 try
   {
   ASSERT_POINTER( pDisp, *pDisp );

   // Check to see if the outer frame is complete
   if (pDisp == m_pIWebBrowser2)
     bDocumentCompleted = TRUE;
   }
 catch( ... )
   {
   _ASSERTE(0);
   hr = E_INVALIDARG;
   }

 if (bDocumentCompleted)
   {
   IHTMLElementCollection *pCollection = NULL;

   // Get the all elements collection
   hr = GetAllCollection( pCollection );
   if (SUCCEEDED( hr ))
     {
     // Really create the Classic View
     hr = CreateClassicView( pCollection );
     if (SUCCEEDED( hr ))
       {
       // Replace the document with the correct path
       hr = ReplacePath( pCollection );
       if (SUCCEEDED( hr ))
         {
         // Everything is running
         }
       }

     // Release the collection
     pCollection->Release();
     pCollection = NULL;
     }
   }
 else
   {
   // Completed loading a frame, we need to wait
   // until the outer frame is completed
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// OnQuit

STDMETHODIMP CADSIWebView::OnQuit()
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// OnVisible

STDMETHODIMP CADSIWebView::OnVisible( VARIANT_BOOL Visible )
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// OnToolBar

STDMETHODIMP CADSIWebView::OnToolBar( VARIANT_BOOL ToolBar )
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// OnMenuBar

STDMETHODIMP CADSIWebView::OnMenuBar( VARIANT_BOOL MenuBar )
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// OnStatusBar

STDMETHODIMP CADSIWebView::OnStatusBar( VARIANT_BOOL StatusBar )
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// OnFullScreen

STDMETHODIMP CADSIWebView::OnFullScreen( VARIANT_BOOL FullScreen )
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// OnTheaterMode

STDMETHODIMP CADSIWebView::OnTheaterMode( VARIANT_BOOL TheaterMode )
{
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// IADSIWebView Interface

///////////////////////////////////////////////////

STDMETHODIMP CADSIWebView::CreateView( IUnknown  *pIUnkShellView,
                                       IUnknown  *pIUnkShellBrowser,
                                       IUnknown  *pIUnkShellFolder, 
                                       UINT       uhwndParent,
                                       UINT       uTop,
                                       UINT       uLeft,
                                       UINT       uBottom,
                                       UINT       uRight,
                                       UINT       uViewMode,
                                       UINT       uFlags,
                                       UINT      *phWnd )
{
 // Copy the parameters for when the Classic View gets created
 // during the DocumentComplete event
 try
   {
   // Initialize the return window handle
   *phWnd = NULL;

   // Hold the Shell View pointer to pass it to the Classic View
   m_pIUnkShellView = pIUnkShellView;

   // Hold the Shell Folder pointer to pass it to the Classic View
   m_pIShellFolder = pIUnkShellFolder;

   // Hold the Shell Browser pointer to pass it to the Classic View
   m_pIShellBrowser = pIUnkShellBrowser;

   // Save the current view folder setting to pass to the Classic View
   // and to return it if Def View calls GetCurrentInfo
   m_FolderSettings.ViewMode = uViewMode;
   m_FolderSettings.fFlags   = uFlags;
   }
 catch(...)
   {
   // Failed to set the window handle
   _ASSERTE(0);
   return E_INVALIDARG;
   }

 // Get the template path
 string strTemplatePath;
 HRESULT hr = GetTemplateFullPath( strTemplatePath );
 if (FAILED( hr ))
   {
   _ASSERTE(0);
   return hr;
   }

 // Instantiate the Web View container window
 RECT  rcView;

 rcView.top    = uTop;
 rcView.bottom = uBottom;
 rcView.left   = uLeft;
 rcView.right  = uRight;

 // Create our container window
 Create( (HWND) uhwndParent,
         rcView,
         _T("ADSI Web View"),
         WS_VISIBLE | WS_CHILD,
         0,
         0 );

 // Exit if we fail to create the window
 if (!m_hWnd)
   {
   // Failed to create our window
   _ASSERTE(0);
   return E_FAIL;
   }

 // Insert the web control
 hr = InsertWebControl();
 if (SUCCEEDED( hr ))
   {
   // Setup the sink with the web browser
   hr = SetupWebBrowser2Sink();
   }

 if (FAILED( hr ))
   {
   // Failed inserting the web control or setting up the sink.
   _ASSERTE(0);

   // Destroy our container window
   if (m_hWnd)
     {
     DestroyWindow();
     }

   return E_FAIL;
   }

 // Build the navigate parameters
 CComVariant varURL( strTemplatePath.c_str() );
 CComVariant varFlags( navNoHistory );
 CComVariant varTarget(OLESTR("_self"));
 CComVariant varPostData(OLESTR(""));
 CComVariant varHeaders(OLESTR(""));

 // Tell the web browser to navigate to the HTML template (ADSI.HTT)
 m_pIWebBrowser2->Navigate2( &varURL,
                             &varFlags,
                             &varTarget,
                             &varPostData,
                             &varHeaders );

 // Set the return window handle to be our container's handle
 *phWnd = ( UINT ) m_hWnd;

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// Refresh

STDMETHODIMP CADSIWebView::Refresh()
{
 // Send the refresh to the Classic View
 if (m_pIADSIClassicView)
   return m_pIADSIClassicView->Refresh();

 return E_FAIL;
}

//////////////////////////////////////////////////////////////////////////
// DestroyView

STDMETHODIMP CADSIWebView::DestroyView()
{
 if (m_pIADSIClassicView)
   {
   // Release the Classic view
   m_pIADSIClassicView->Release();
   m_pIADSIClassicView = NULL;
   }

 if (m_dwWebBrowserEvents2Sink)
   {
   // Remove the advise sink
   HRESULT hr = AtlUnadvise( m_pIOleObject,
                             IID_DWebBrowserEvents2,
                             m_dwWebBrowserEvents2Sink );
   if (FAILED( hr ))
     {
     // We failed to remove the sink
     _ASSERTE(0);
     }

   m_dwWebBrowserEvents2Sink = 0;
   }

 if (m_pIWebBrowser2)
   {
   // Release the WebBrowser2 Interface
   m_pIWebBrowser2->Release();
   m_pIWebBrowser2 = NULL;
   }

 // Destroy the web browser object
 if (m_pIOleObject)
   {
   m_pIOleObject->Close(OLECLOSE_NOSAVE);

   // Release the OleObject Interface
   m_pIOleObject->Release();
   m_pIOleObject = NULL;
   }

 // Destroy our container window
 if (m_hWnd)
   {
   DestroyWindow();
   }

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// GetCurrentInfo

STDMETHODIMP CADSIWebView::GetCurrentInfo( UINT * puViewMode,
                                           UINT * puFlags )
{
 HRESULT hr = S_OK;
 try
   {
   ASSERT_POINTER( puViewMode, *puViewMode );
   ASSERT_POINTER( puFlags,    *puFlags );

   *puViewMode = m_FolderSettings.ViewMode;
   *puFlags    = m_FolderSettings.fFlags;
   }
 catch( ... )
   {
   _ASSERTE(0);
   hr = E_INVALIDARG;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// GetWindow

STDMETHODIMP CADSIWebView::GetWindow( UINT * lphWnd )
{
 HRESULT hr = S_OK;
 try
   {
   _ASSERTE(NULL != lphWnd);

   // Return our window handle (the web container)
   *lphWnd = (UINT) m_hWnd;
   }
 catch( ... )
   {
   _ASSERTE(0);
   hr = E_INVALIDARG;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// SetCurrentInfo

STDMETHODIMP CADSIWebView::SetCurrentInfo(UINT uViewMode, UINT uFlags)
{
 m_FolderSettings.ViewMode = uViewMode;
 m_FolderSettings.fFlags   = uFlags;

 // Pass the info to the Classic View if it is active.
 if (m_pIADSIClassicView)
   return m_pIADSIClassicView->SetCurrentInfo( uViewMode, uFlags );

 return E_FAIL;
}

//////////////////////////////////////////////////////////////////////////
// CADSIWebView Internal members

HRESULT  CADSIWebView::GetAllCollection(
                                 IHTMLElementCollection *& pCollection )
{
 IDispatch *pDocumentIDispatch = NULL;

 // Get the document IDispatch
 HRESULT hr = m_pIWebBrowser2->get_Document( &pDocumentIDispatch );
 if (FAILED( hr ))
   {
   // Failed to get the document IDispatch

   _ASSERTE(0);
   return hr;
   }

 // Query for the IHTMLDocument2 Interface
 CComQIPtr< IHTMLDocument2, &IID_IHTMLDocument2 >
            pIHTMLDocument2( pDocumentIDispatch );

 // Release the documents IDispatch pointer
 pDocumentIDispatch->Release();
 pDocumentIDispatch = NULL;

 if (!pIHTMLDocument2)
   {
   // Failed to get the IHTMLDocument2 Interface
   _ASSERTE(0);
   return E_FAIL;
   }

 // Get the ElementCollection for all elements within the Document
 hr = pIHTMLDocument2->get_all( &pCollection );
 if (FAILED( hr ))
   {
   // Failed to get the element collection of all objects
   _ASSERTE(0);
   return hr;
   }

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// GetElementInCollection

HRESULT  CADSIWebView::GetElementInCollection(
                       IHTMLElementCollection *pCollection,
                       long lIndex,
                       long& lNumElements,
                       IHTMLElement *& pIHTMLElement )
{
 // See if it is the first request
 if (lIndex == 0)
   {
   HRESULT hr = E_FAIL;
   try
     {
     // Get the number of elements
     hr = pCollection->get_length( &lNumElements );
     }
   catch( ... )
     {
     _ASSERTE(0);
     hr = E_FAIL;
     }

   if (FAILED( hr ))
     {
     // Failed to get the length of the element collection.

     lNumElements = 0;

     _ASSERTE(0);
     return hr;
     }
   }

 HRESULT hr = E_FAIL;

 // Get the element
 if (lIndex < lNumElements)
   {
   CComVariant varIndex( lIndex );
   CComVariant varName( OLESTR("") );

   IDispatch *pIDispatchItem = NULL;

   // Get the item's IDispatch
   try
     {
     // Get the number of elements
     hr = pCollection->item( varIndex,
                             varName,
                            &pIDispatchItem );
     }
   catch( ... )
     {
     _ASSERTE(0);
     hr = E_FAIL;
     }

   if (SUCCEEDED( hr ))
     {
     // Query for IHTMLElement
     CComQIPtr< IHTMLElement, &IID_IHTMLElement > 
                pElement( pIDispatchItem );

     try
       {
       // Release the item's IDispatch
       pIDispatchItem->Release();
       pIDispatchItem = NULL;

       if (pElement)
         {
         // Return the element interface
         pIHTMLElement = pElement;
         pIHTMLElement->AddRef();

         hr = S_OK;
         }
       }
     catch( ... )
       {
       hr = E_FAIL;
       }
     }
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// GetChildCollection

HRESULT  CADSIWebView::GetChildCollection(
                           IHTMLElement *pIHTMLElement,
                           IHTMLElementCollection *& pChildCollection )
{
 ASSERT_POINTER( pIHTMLElement, *pIHTMLElement );

 IDispatch *pChildDocumentIDispatch = NULL;

 // Get the children of this element
 HRESULT hr = pIHTMLElement->get_children( &pChildDocumentIDispatch );
 if (SUCCEEDED( hr ))
   {
   CComQIPtr< IHTMLElementCollection, &IID_IHTMLElementCollection >
              pCollection( pChildDocumentIDispatch );

   if (pCollection)
     {
     // Return the child element collection
     pChildCollection = pCollection;
     pChildCollection->AddRef();
     }
   else
     hr = E_FAIL;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// GetElementTag

HRESULT CADSIWebView::GetElementTag( IHTMLElement *pIHTMLElement,
                                     string&       strTag )
{
 HRESULT hr = S_OK;

 strTag.erase();

 BSTR bstrTag = NULL;
 try
   {
   hr = pIHTMLElement->get_tagName( &bstrTag );
   if (SUCCEEDED( hr ))
     {
     CONVERT_BSTR_TO_STRING( bstrTag, strTag );
     }
   }
 catch( ... )
   {
   _ASSERTE(0);
   hr = E_FAIL;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// GetElementInnerText

HRESULT CADSIWebView::GetElementInnerText( IHTMLElement *pIHTMLElement,
                                           string&       strInnerText )
{
 HRESULT hr = S_OK;

 strInnerText.erase();

 BSTR bstrInnerText = NULL;
 try
   {
   hr = pIHTMLElement->get_innerText( &bstrInnerText );
   if (SUCCEEDED( hr ))
     {
     CONVERT_BSTR_TO_STRING( bstrInnerText, strInnerText );
     }
   }
 catch( ... )
   {
   _ASSERTE(0);
   hr = E_FAIL;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// PutElementInnerText

HRESULT CADSIWebView::PutElementInnerText( IHTMLElement *pIHTMLElement,
                                           string&       strInnerText )
{
 HRESULT hr = S_OK;

 BSTR bstrInnerText = NULL;
 try
   {
   CONVERT_STRING_TO_BSTR( strInnerText, bstrInnerText );

   // Replace the text in the document
   hr = pIHTMLElement->put_innerText( bstrInnerText );

   FREE_BSTR( bstrInnerText );
   }
 catch( ... )
   {
   _ASSERTE(0);
   hr = E_FAIL;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// ReplaceText

HRESULT CADSIWebView::ReplaceText( string& strTextToSearch,
                                   string& strTextToFind,
                                   string& strTextToReplace )
{
 HRESULT hr = S_OK;
 int iFindStartPos = 0;

 // Loop until all of the strings are replaced
 BOOL bReplacedSomething = FALSE;
 BOOL bReplaceDone = FALSE;
 while( !bReplaceDone )
   {
   try
     {
     int iPos = strTextToSearch.find(  strTextToFind,
                                       iFindStartPos );
     if (iPos >= 0)
       {
       // Set the next find position after this text
       iFindStartPos = iPos + strTextToReplace.length();

       // Replace the text in the string
       strTextToSearch.replace(  iPos,
                                 strTextToFind.length(),
                                 strTextToReplace );

       bReplacedSomething = TRUE;
       }
     else
       {
       // We are finished replacing the text
       bReplaceDone = TRUE;
       }
     }
   catch( ... )
     {
     _ASSERTE(0);
     hr = E_FAIL;
     }
   }

 // Fail if nothing was replaced
 if (!bReplacedSomething)
   hr = E_FAIL;

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// ReplaceAllTextTags

HRESULT  CADSIWebView::ReplaceAllTextTags(
                                   IHTMLElementCollection *pCollection,
                                   string& strTextToFind,
                                   string& strTextToReplace )
{
 BOOL bFinished = FALSE;
 long lIndex = 0;
 long lNumElements = 0;

 while( !bFinished )
   {
   IHTMLElement *pIHTMLElement = NULL;

   // Get an element in the collection
   HRESULT hr = GetElementInCollection(  pCollection,
                                         lIndex,
                                         lNumElements,
                                         pIHTMLElement );
   if(SUCCEEDED( hr ))
     {
     IHTMLElementCollection * pChildCollection = NULL;

     // Get the child collection
     hr = GetChildCollection(  pIHTMLElement, pChildCollection );

     if(SUCCEEDED( hr ))
       {
       // Recurse down the next level
       hr = ReplaceAllTextTags( pChildCollection,
                                strTextToFind,
                                strTextToReplace );

       // Release the child collection
       pChildCollection->Release();
       pChildCollection = NULL;
       }

     // Get the tag
     string strTag;

     hr = GetElementTag( pIHTMLElement, strTag );

     if(SUCCEEDED( hr ))
       {
       // Only replace text that is not a comment
       if (strTag != string( "!" ))
         {
         string strInnerText;

         // Get the inner text
         hr = GetElementInnerText( pIHTMLElement, strInnerText );
         if (SUCCEEDED( hr ) && (strInnerText.length() > 0) )
           {
           // Replace text within the inner text
           hr = ReplaceText( strInnerText,
                             strTextToFind,
                             strTextToReplace );
           if(SUCCEEDED( hr ))
             {
             // Put the new inner text back in the document
             hr = PutElementInnerText( pIHTMLElement, strInnerText );
             if(SUCCEEDED( hr ))
               {
               }
             }
           }
         }
       }

     try
       {
       // Release the element
       pIHTMLElement->Release();
       pIHTMLElement = NULL;
       }
     catch( ... )
       {
       hr = E_FAIL;
       }
     }

   // Finished if all elements are processed
   if (lIndex >= lNumElements)
     bFinished = TRUE;

   // Increment the index of the collection
   lIndex++;
   }

 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// GetObjectsIDispatch

HRESULT  CADSIWebView::GetObjectsIDispatch(
                                     IHTMLElementCollection *pCollection,
                                     string& strFindCLSID,
                                     IDispatch *& pIDispatch )
{
 BOOL bFinished = FALSE;
 long lIndex = 0;
 long lNumElements = 0;

 pIDispatch = NULL;

 while( !bFinished )
   {
   IHTMLElement *pIHTMLElement = NULL;

   // Get an element in the collection
   HRESULT hr = GetElementInCollection( pCollection,
                                        lIndex,
                                        lNumElements,
                                        pIHTMLElement );
   if (SUCCEEDED( hr ))
     {
     BOOL bFound = FALSE;
     IHTMLElementCollection * pChildCollection = NULL;

     // Get the child collection
     hr = GetChildCollection(  pIHTMLElement, pChildCollection );
     if(SUCCEEDED( hr ))
       {
       // Recurse down the next level
       hr = GetObjectsIDispatch( pChildCollection,
                                 strFindCLSID,
                                 pIDispatch );

       // Release the child collection
       pChildCollection->Release();
       pChildCollection = NULL;

       if (SUCCEEDED(hr))
         {
         bFound = TRUE;

         try
           {
           // Release the element
           pIHTMLElement->Release();
           pIHTMLElement = NULL;
           }
         catch( ... )
           {
           hr = E_FAIL;
           }

         return S_OK;
         }
       }

     // Get the tag
     string strTag;
     hr = GetElementTag( pIHTMLElement, strTag );
     if (SUCCEEDED(hr))
       {
       if ( strTag == string("OBJECT") )
         {
         // Get the object's class ID
         CComQIPtr< IHTMLObjectElement, &IID_IHTMLObjectElement >
                     pObject( pIHTMLElement );

         if (pObject)
           {
           // Get the class id of the object
           BSTR bstrCLSID;
           hr = pObject->get_classid( &bstrCLSID );
           if (SUCCEEDED(hr))
             {
             string strCLSID;

             strCLSID.erase();

             CONVERT_BSTR_TO_STRING( bstrCLSID, strCLSID );

             // See if it is the CLSID we are looking for
             if (strCLSID == strFindCLSID)
               {
               // Get the IDispatch pointer of the object
               hr = pObject->get_object( &pIDispatch );
               if (SUCCEEDED(hr))
                 {
                 bFound = TRUE;
                 }
               }
             }
           }
         else
           hr = E_FAIL;
         }
       }

     try
       {
       // Release the element
       pIHTMLElement->Release();
       pIHTMLElement = NULL;
       }
     catch( ... )
       {
       hr = E_FAIL;
       }

     if (bFound)
       {
       return S_OK;
       }
     }

   // Finished if all elements are processed
   if (lIndex >= lNumElements)
     bFinished = TRUE;

   // Increment the index of the collection
   lIndex++;
   }

 return E_FAIL;
}

//////////////////////////////////////////////////////////////////////////
// CreateClassicView

HRESULT  CADSIWebView::CreateClassicView(
                                   IHTMLElementCollection *pCollection )
{
 string strFindCLSID( szCLSIDClassicView );

 IDispatch *pIDispatchClassicView = NULL;

 // Get the IDispatch pointer for the object
 HRESULT hr = GetObjectsIDispatch( pCollection,
                                   strFindCLSID,
                                   pIDispatchClassicView );
 if (SUCCEEDED(hr))
   {
   // Query for classic view
   CComQIPtr< IADSIClassicView, &IID_IADSIClassicView >
             pIADSIClassicView( pIDispatchClassicView );

   if (pIADSIClassicView)
     {
     try
       {
       m_pIADSIClassicView = pIADSIClassicView;
       m_pIADSIClassicView->AddRef();

       HWND hWnd = NULL;

       // Really create the Classic View within the ActiveX control.
       hr = m_pIADSIClassicView->CreateView(
                           (IUnknown *) m_pIUnkShellView,
                           (IUnknown *) m_pIShellBrowser,
                           (IUnknown *) m_pIShellFolder,
                           (UINT) m_hWnd,
                           (UINT) 0,
                           (UINT) 0,
                           (UINT) 0,
                           (UINT) 0,
                           m_FolderSettings.ViewMode,
                           m_FolderSettings.fFlags,
                           (UINT *)&hWnd );
       }
     catch( ... )
       {
       m_pIADSIClassicView = NULL;

       // Failed creating the classic view
       _ASSERTE(0);
       hr = E_UNEXPECTED;
       }
     }
   else
     {
     m_pIADSIClassicView = NULL;

     // Failed getting the classic view interface
     _ASSERTE(0);
     hr = E_UNEXPECTED;
     }
   }
 else
   {
   // The classic view is not inside of this document
   m_pIADSIClassicView = NULL;

   // We will ignore this error so that the document
   // can still run.
   hr = S_OK;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// ReplacePath

HRESULT  CADSIWebView::ReplacePath( IHTMLElementCollection *pCollection )
{
 string strTextToFind;
 string strTextToReplace;

 HRESULT hr = S_OK;

 try
   {
   strTextToFind = _T("%THISADSIPATH%" );
   strTextToReplace = _T("ADSI Path" );

   if (m_pIADSIClassicView)
     {
     CComVariant varPath;

     hr = m_pIADSIClassicView->GetCurrentPath( &varPath );
     if (SUCCEEDED( hr ))
       {
       // Make a copy of the BSTR
       BSTR bstrPath = ::SysAllocString( varPath.bstrVal );

       // Convert the BSTR to a string and free the BSTR
       CONVERT_BSTR_TO_STRING( bstrPath, strTextToReplace );

       // Get the last portion of the path to display
       int iPos = strTextToReplace.rfind( _T("/") );
       if (iPos >= 0)
         {
         // Get only the last path 
         string strCurrentPath;
         strCurrentPath = strTextToReplace.substr( iPos + 1,
                                           strTextToReplace.length() );

         // Reassign the text to place
         strTextToReplace = strCurrentPath;
         }

       // Put parens around the current folder name
       string strFolder;
       strFolder = _T("(");
       strFolder += strTextToReplace;
       strFolder += _T(")");

       // Copy the folder to the text to replace string
       strTextToReplace = strFolder;
       }
     }
   }
 catch( ... )
   {
   _ASSERTE(0);
   hr = E_OUTOFMEMORY;
   }

 if (SUCCEEDED( hr ))
   {
   // Replace our path text with the real ADSI path
   hr = ReplaceAllTextTags(  pCollection,
                             strTextToFind,
                             strTextToReplace );
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// InsertWebControl

HRESULT CADSIWebView::InsertWebControl()
{
 // Initialize the activated state
 m_bInPlaceActive = FALSE;

 // Create Microsoft's Web Browser control and
 // get the OleObject Interface
 CoCreateInstance( CLSID_WebBrowser,
                   NULL,
                   CLSCTX_INPROC,
                   IID_IOleObject,
                   (void**) &m_pIOleObject );
 if (!m_pIOleObject)
   {
   // Failed to create the web browser control
   _ASSERTE(0);
   return E_FAIL;
   }

 ASSERT_POINTER( m_pIOleObject, *m_pIOleObject );

 // Get our OleClientSite
 CComQIPtr< IOleClientSite, &IID_IOleClientSite > pOleClientSite( this );

 HRESULT hr = E_FAIL;

 try
   {
   if (pOleClientSite)
     {
     // Give ownership to the OleObject
     hr = m_pIOleObject->SetClientSite( pOleClientSite );
     }
   else
     {
     // Failed to get our interface
     hr = E_UNEXPECTED;
     }
   }
 catch( ... )
   {
   // Failed to set the client site
   _ASSERTE(0);
   hr = E_POINTER;
   }

 // Return the error
 if (FAILED( hr ))
   {
   // Free the OleObject
   m_pIOleObject->Release();
   m_pIOleObject = NULL;
   return hr;
   }

 MSG msg;
 RECT rcPos;

 // Get the client rect of our container window
 GetClientRect( &rcPos );

 // InPlace activate the web control in our container.
 m_pIOleObject->DoVerb(  OLEIVERB_INPLACEACTIVATE,
                         &msg,
                         pOleClientSite,
                         0,
                         m_hWnd,
                         &rcPos );

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// SetupWebBrowser2Sink

HRESULT CADSIWebView::SetupWebBrowser2Sink()
{
 HRESULT hr = S_OK;

 try
   {
   ASSERT_POINTER( m_pIOleObject, *m_pIOleObject );

   // Query for IWebBrowser2.
   CComQIPtr< IWebBrowser2, &IID_IWebBrowser2 >
              pIWebBrowser2( m_pIOleObject );

   if (pIWebBrowser2)
     {
     ASSERT_POINTER( pIWebBrowser2, *pIWebBrowser2 );

     // Hold the WebBrowser2 Interface
     m_pIWebBrowser2 = pIWebBrowser2;
     m_pIWebBrowser2->AddRef();
     }
   else
     {
     // Failed to get the interface
     _ASSERTE(0);

     m_pIWebBrowser2 = NULL;
     hr = E_POINTER;
     }
   }
 catch( ... )
   {
   // Failed to get the interface
   _ASSERTE(0);
   hr = E_UNEXPECTED;
   }

 if (FAILED( hr ))
   {
   _ASSERTE(0);

   // Release the OleObject Interface
   m_pIOleObject->Release();
   m_pIOleObject = NULL;
   return hr;
   }

 // Get the web browser events
 CComQIPtr< DWebBrowserEvents2, &IID_DWebBrowserEvents2 >
            pIWebBrowserEvents2( this );

 try
   {
   if (pIWebBrowserEvents2)
     {
     // Setup the advise sink
     hr = AtlAdvise( m_pIWebBrowser2,
                     GetControllingUnknown(),
                     IID_DWebBrowserEvents2,
                     &m_dwWebBrowserEvents2Sink );
     }
   else
     {
     // Failed to get the interface
     _ASSERTE(0);
     hr = E_POINTER;
     }
   }
 catch( ... )
   {
   // Failed to get the interface
   _ASSERTE(0);
   hr = E_UNEXPECTED;
   }

 if (FAILED( hr ))
   {
   _ASSERTE(0);

   // Release the WebBrowser2 Interface
   m_pIWebBrowser2->Release();
   m_pIWebBrowser2 = NULL;

   // Release the OleObject Interface
   m_pIOleObject->Release();
   m_pIOleObject = NULL;
   }

 return hr;
}

//////////////////////////////////////////////////////////////////////////
// GetTemplateFullPath

HRESULT CADSIWebView::GetTemplateFullPath( string& strTemplatePath )
{
 // Get the DLLs File Path
 TCHAR szFileName[ MAX_PATH ] = { 0 };

 if (::GetModuleFileName( _Module.GetModuleInstance(), 
                          szFileName,
                          MAX_PATH ) == 0 )
   {
   // Failed to get the current DLL path
   _ASSERTE(0);
   return E_FAIL;
   }

 HRESULT hr = S_OK;

 // Strip the filename off and put our template name

 try
   {
   string strFilePath = szFileName;

   strTemplatePath = _T("");

   // Get the path and strip the filename off
   int iPos = strFilePath.rfind( _T("\\") );
   if (iPos >= 0)
     {
     // Get only the path 
     strTemplatePath = strFilePath.substr( 0, iPos + 1 );
     }

   // Append the template name
   strTemplatePath += szTemplateName;
   }
 catch( ... )
   {
   // Failed to build the path to the template file
   _ASSERTE(0);
   hr = E_FAIL;
   }

 return hr;
}
