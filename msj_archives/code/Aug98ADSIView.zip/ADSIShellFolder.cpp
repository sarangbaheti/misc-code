//////////////////////////////////////////////////////////////////////////
//
// Filename:     ADSIShellFolder.cpp
//
// Description:  This is the Shell Folder Object
//
//               The shell folder is what kicks all of this off.  It
//               is what is used by explorer to enter the namespace
//               as well as create the view and get the children etc.
//
// Author(s):    Todd Daniell, Dave Mims, Doug Bahr
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////

#include "stdafx.h"

// include the STL string class
#include <string>
using namespace std;

// include the other objects that will be used in this module
#include "ADSIShellFolder.h"
#include "ADSIShellView.h"
#include "ADSIExtractIcon.h"
#include "ADSIPIDLHELPER.H"

//////////////////////////////////////////////////////////////////////////
// constants
const TCHAR szADSRoot[] = TEXT("ADS:");

//////////////////////////////////////////////////////////////////////////
// CADSIShellFolder constructor

CADSIShellFolder::CADSIShellFolder()
{
 // set that this object points to the ADSI root
 m_strObjectPath = szADSRoot; 
}

//////////////////////////////////////////////////////////////////////////
// IShellFolder methods 

//////////////////////////////////////////////////////////////////////////
// CADSIShellFolder ParseDisplayName

STDMETHODIMP CADSIShellFolder::ParseDisplayName(HWND /*hwndOwner*/,
                                                LPBC /*pbcReserved*/,
                                                LPOLESTR /*lpszName*/,
                                                ULONG * /*pchEaten*/,
                                                LPITEMIDLIST * /*ppidl*/,
                                                ULONG * /*pdwAttributes*/)
{
 return E_NOTIMPL;
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellFolder EnumObjects

STDMETHODIMP CADSIShellFolder::EnumObjects( HWND /*hwndOwner*/,
                                            DWORD grfFlags,
                                            LPENUMIDLIST * ppenumIDList )
{
 // setup the out params
 *ppenumIDList = NULL; 

 // get an enumerator for this folder
 CADSIPiddleList * pIDList = NULL;
 HRESULT hr = g_ADSIPIDLHelper.GetEnumeratorOfADSIContainer(
                                     m_strObjectPath.c_str(),
                                     grfFlags,
                                     pIDList );

 // if it failed, return the error
 if ( FAILED( hr ))
   return hr;

 // set the out param
 *ppenumIDList = (IEnumIDList *) pIDList;

 // return the value
 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellFolder BindToObject

STDMETHODIMP CADSIShellFolder::BindToObject( LPCITEMIDLIST pidl,
                                             LPBC /*pbcReserved*/,
                                             REFIID riid,
                                             LPVOID * ppvOut)
{
 // setup the default out params
 *ppvOut = NULL;

 // make sure that this is the interface we want
 if ( IID_IShellFolder != riid )
   return E_NOINTERFACE;

 // allocate the object here
 IShellFolder *pIShellFolder = NULL;
 HRESULT hr = CComCreator< CComObject< CADSIShellFolder > >
               ::CreateInstance(NULL,
                     IID_IShellFolder,
                     (void**) &pIShellFolder);
 if (FAILED(hr))
   {
   ASSERT(0);
   return hr;
   }

 ASSERT_POINTER(pIShellFolder, *pIShellFolder);

 CADSIShellFolder * pNewChild = (CADSIShellFolder *) pIShellFolder;

 ASSERT_POINTER(pNewChild, *pNewChild);

 // get the path of this 
 hr = g_ADSIPIDLHelper.GetADSIPathFromIDList(pidl,
                                     pNewChild->m_strObjectPath );
 if ( SUCCEEDED(hr) )
   {
   // return the interface to the caller
   *ppvOut = (LPVOID*)pIShellFolder;

   // return all is well
   return S_OK;
   }

 // delete the object
 pIShellFolder->Release();
 pIShellFolder = NULL;        
                               
 // return the value
 return hr;
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellFolder BindToStorage

STDMETHODIMP CADSIShellFolder::BindToStorage( LPCITEMIDLIST /*pidl*/,
                                              LPBC /*pbcReserved*/,
                                              REFIID /*riid*/,
                                              LPVOID * /*ppvObj*/)
{
 return E_NOTIMPL;
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellFolder CompareIDs

STDMETHODIMP CADSIShellFolder::CompareIDs( LPARAM /*lParam*/,
                                           LPCITEMIDLIST pidl1,
                                           LPCITEMIDLIST pidl2 )
{
 //compare the ID's
 return g_ADSIPIDLHelper.CompareIDs(pidl1,pidl2);
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellFolder CreateViewObject

STDMETHODIMP CADSIShellFolder::CreateViewObject( HWND /*hwndOwner*/,
                                                 REFIID riid,
                                                 LPVOID * ppvOut)
{
 // Initialize the return
 *ppvOut = NULL;
 
 // Do we support the interface
 if (IID_IShellView != riid)
   {
   return E_NOINTERFACE;
   }

 // Create the view object
 IShellView *pIShellView = NULL;
 HRESULT hr = CComCreator< CComObject< CADSIShellView > >
                 ::CreateInstance(NULL,
                                 IID_IShellView,
                                 (void**)&pIShellView);
 if (FAILED(hr))
   {
   ASSERT(0);
   return hr;
   }

 ASSERT_POINTER(pIShellView, *pIShellView);

 CADSIShellView *pShellView = (CADSIShellView *)pIShellView;

 ASSERT_POINTER(pShellView, *pShellView);

 // Get our IShellFolder Pointer
 CComQIPtr< IShellFolder, &IID_IShellFolder > pIShellFolder( this );

 // Initialize the view with ADSI path
 hr = pShellView->Init( pIShellFolder );
 if (FAILED(hr))
   {
   ASSERT(0);
   pIShellView->Release();
   pIShellView = NULL;
   return hr;
   }

 // Return the view to the caller
 *ppvOut = (LPVOID*)pIShellView;

 // Success
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellFolder GetAttributesOf

STDMETHODIMP CADSIShellFolder::GetAttributesOf( UINT cidl,
                                                LPCITEMIDLIST * apidl,
                                                ULONG * rgfInOut)
{
 // get the attributes of the IDLists
 return g_ADSIPIDLHelper.GetAttributesOf(cidl,apidl,rgfInOut);
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellFolder GetUIObjectOf

STDMETHODIMP CADSIShellFolder::GetUIObjectOf( HWND hwndOwner,
                                              UINT cidl,
                                              LPCITEMIDLIST * apidl,
                                              REFIID riid,
                                              UINT * prgfInOut,
                                              LPVOID * ppvOut)
{
 // if this is NOT the extract Icon
 // we have not implemented it yet
 if ( IID_IExtractIconA != riid && IID_IExtractIconW != riid )
   return E_NOTIMPL;

 // setup the out params
 *ppvOut = NULL;

 // make sure that it is only asking for 1
 if ( 1 != cidl )
   return E_NOTIMPL;

 // get the Icon of the object
 DWORD dwIconID = 0;
 HRESULT hr = g_ADSIPIDLHelper.GetIconFromIDList(apidl[0],dwIconID);
 if ( FAILED(hr) )
   return hr;

 // allocate a new one
 if (IID_IExtractIconA == riid)
   {
   IExtractIconA *pIcon = NULL;
   HRESULT hr = CComCreator< CComObject< CADSIExtractIconA > >
                ::CreateInstance( NULL, riid, (void**) &pIcon );

   if (FAILED(hr))
     {
     ASSERT(0);
     return hr;
     }

   ASSERT_POINTER(pIcon, *pIcon);

   hr = ((CADSIExtractIconA*)pIcon)->Init(dwIconID);
   if ( FAILED(hr) )
     {
     pIcon->Release();
     pIcon = NULL;
     return hr;
     }

   // return the interface
   *ppvOut = pIcon;

   // return all is well
   return S_OK;
   }

 ASSERT( IID_IExtractIconW == riid );

 IExtractIconW *pIcon = NULL;
 hr = CComCreator< CComObject< CADSIExtractIconW > >
      ::CreateInstance(NULL, riid, (void**)&pIcon);

 if (FAILED(hr))
   {
   ASSERT(0);
   return hr;
   }

 ASSERT_POINTER(pIcon, *pIcon);

 hr = ((CADSIExtractIconW*)pIcon)->Init(dwIconID);
 if ( FAILED(hr) )
   {
   pIcon->Release();
   pIcon = NULL;
   return hr;
   }

 // return the interface
 *ppvOut = pIcon;

 // return all is well
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellFolder GetDisplayNameOf

STDMETHODIMP CADSIShellFolder::GetDisplayNameOf( LPCITEMIDLIST pIDL,
                                                 DWORD uFlags,
                                                 LPSTRRET lpName)
{
 //get the information from the IDList
 return g_ADSIPIDLHelper.GetTitleFromIDList(pIDL,uFlags,lpName);
}

//////////////////////////////////////////////////////////////////////////
// CADSIShellFolder SetNameOf

STDMETHODIMP CADSIShellFolder::SetNameOf( HWND /*hwndOwner*/,
                                          LPCITEMIDLIST /*pidl*/,
                                          LPCOLESTR /*lpszName*/,
                                          DWORD /*uFlags*/,
                                          LPITEMIDLIST * /*ppidlOut*/)
{
 return E_NOTIMPL;
}

//////////////////////////////////////////////////////////////////////////
// IPersist methods 

//////////////////////////////////////////////////////////////////////////
// CADSIShellFolder GetClassID

STDMETHODIMP CADSIShellFolder::GetClassID( LPCLSID /*lpClassID*/ )
{
 return E_NOTIMPL;
}

//////////////////////////////////////////////////////////////////////////
// IPersistFolder methods 

//////////////////////////////////////////////////////////////////////////
// CADSIShellFolder Initialize

STDMETHODIMP CADSIShellFolder::Initialize( LPCITEMIDLIST /*pidl*/ )
{
 // we do not need to do anything here
 // so just return all is well
 return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// IPersistFolder2 methods 

//////////////////////////////////////////////////////////////////////////
// CADSIShellFolder GetCurFolder

STDMETHODIMP CADSIShellFolder::GetCurFolder( LPITEMIDLIST *ppidl )
{
 // get the information about this object
 BOOL bIsContainer = FALSE;
 return g_ADSIPIDLHelper.GetIDListOfADSIObject( m_strObjectPath.c_str(),
                                                *ppidl,
                                                bIsContainer);
}

// End of CADSIShellFolder
