//////////////////////////////////////////////////////////////////////////
//
// Filename:     CustParams.h
//
// Description:  Custom Interface Parameter Definitions
//
// Author(s):    Todd Daniell, Brian Daigle
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////

#ifndef _ADSI_CUSTPARMS_H
#define _ADSI_CUSTPARMS_H

// Custom parameter for the passes the 
// SV2CVW2_PARAMS used in the custom interfaces
typedef struct
{
 // SV2CVW2_PARAMS...
   
    IUnknown   *pIUnkShellView;    // pIShellView previous

 // Folder settings...

    UINT     uViewMode;            // View mode (FOLDERVIEWMODE values)
    UINT     uFlags;               // View options (FOLDERFLAGS bits)

 // SV2CVW2_PARAMS, Cont...

    IUnknown   *pIUnkShellBrowser; // pIShellBrowser owner
    RECT       *prcView;           // prcView
    GUID       const *pvid;        // SHELLVIEWID

 HWND       hwndView;              // hwndView (handle to 
                                   // be returned from the create)

} ADSI_CVW2PARAMS, *PADSI_CVW2PARAMS ;

#endif // _ADSI_CUSTPARMS_H

