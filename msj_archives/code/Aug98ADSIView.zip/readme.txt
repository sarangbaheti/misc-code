Thanks for your interest in the ADSIView Namespace Extension.

Before you can compile and build the ADSIView sample namespace
extension you will need to perform the following steps.

1) Make sure you are running one of the following platforms:
    a)  Windows� 95 with IE 4.01
    b)  Windows� NT 4.0 with IE 4.01
    c)  Windows� 98 BETA 3
    d)  Windows� NT 5.0 BETA 1

2) Install Visual C++ 5.0.

3) Download and install the ADSI 2.0 runtime environment.
    (http://backoffice.microsoft.com/downtrial/moreinfo/adsi2.asp)

4) Download and install
    a) The VC++ Service Pack 3.0 
        (http://www.microsoft.com/visualc)
    a) The Platform SDK
        (http://www.microsoft.com/msdn)
    b) The ADSI SDK
        (http://www.microsoft.com/msdn)
    c) The Internet Client SDK
        (http://www.microsoft.com/msdn)

5) Inside of Microsoft's� Developer Studio, select "Options"
   under the "Tools" menu item.  Then, select the "Directories"
   tab and move the Platform SDK, ADSI SDK and the Internet Client SDK's
   include and library directories to the top of each list.

   Note:  The directories must be located before the MSDEV include and
   lib directories for the ADSIView sample namespace extension to
   build properly.

Any questions, comments or suggestions should be E-mailed to "adsiview@intertech.com".

