//////////////////////////////////////////////////////////////////////////
//
// Filename:     ADSIShellView.h
//
// Description:  The view of the shell folder
//
// Author(s):    Todd Daniell
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////

#ifndef _ADSISHELLVIEW_H
#define _ADSISHELLVIEW_H

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "resource.h"       // main symbols
#include "ADSIDefView.h"

//////////////////////////////////////////////////////////////////////////
// CADSIShellView

class CADSIShellView : 
 public CComObjectRoot,
 public IShellView2
{
// Members
private:
 CComPtr< IShellFolder >  m_pIShellFolder;
 CComPtr< IADSIDefView >  m_pIADSIDefView;

// Utils     
private:
 void  ClearMemberVar();

// Construction, Destruction & Initialization
public:
 CADSIShellView();
 virtual ~CADSIShellView();
 HRESULT Init( IShellFolder *pIShellFolder );

// Interfaces
BEGIN_COM_MAP(CADSIShellView)
 COM_INTERFACE_ENTRY(IShellView)
 COM_INTERFACE_ENTRY(IShellView2)
END_COM_MAP()

// IADSIShellView
public:

    // *** IOleWindow methods ***
    STDMETHOD(GetWindow)            ( HWND * lphwnd );
    STDMETHOD(ContextSensitiveHelp) ( BOOL fEnterMode );

    // *** IShellView methods ***
    STDMETHOD(TranslateAccelerator) ( LPMSG lpmsg );

#ifdef _FIX_ENABLEMODELESS_CONFLICT
    STDMETHOD(EnableModelessSV)    ( BOOL fEnable );
#else
    STDMETHOD(EnableModeless)    ( BOOL fEnable );
#endif

    STDMETHOD(UIActivate)      ( UINT uState );
    STDMETHOD(Refresh)       ();

    STDMETHOD(CreateViewWindow)    (IShellView *lpPrevView,
                                 LPCFOLDERSETTINGS lpfs,
                                 IShellBrowser * psb,
                                 RECT * prcView,
                                 HWND  *phWnd );
    STDMETHOD(DestroyViewWindow) ();
    STDMETHOD(GetCurrentInfo)    ( LPFOLDERSETTINGS lpfs );
    STDMETHOD(AddPropertySheetPages)(DWORD dwReserved,
                                   LPFNADDPROPSHEETPAGE lpfn,
                                   LPARAM lparam );
    STDMETHOD(SaveViewState)   ();
    STDMETHOD(SelectItem)      ( LPCITEMIDLIST pidlItem, UINT uFlags );
    STDMETHOD(GetItemObject)   ( UINT uItem, REFIID riid, LPVOID *ppv );

    // *** IShellView2 methods ***
    STDMETHOD(GetView)( SHELLVIEWID* pvid, ULONG uView );
    STDMETHOD(CreateViewWindow2)( LPSV2CVW2_PARAMS lpParams );
    STDMETHOD(HandleRename)( LPCITEMIDLIST pidlNew );
    STDMETHOD(SelectAndPositionItem)(LPCITEMIDLIST pidlItem,
                                     UINT uFlags,
                                     POINT* point );
};

#endif // #ifndef _ADSISHELLVIEW_H

