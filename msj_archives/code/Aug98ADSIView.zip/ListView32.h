//////////////////////////////////////////////////////////////////////////
//
// Filename:   ListView32.h
//
// Description:  interface for the CListView32 class.
//
// Author(s):    Dave Mims
//
// Copyright 1998 MSJ
//                All Rights Reserved
//
//////////////////////////////////////////////////////////////////////////

#ifndef _LISTVIEW32_H
#define _LISTVIEW32_H

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

//////////////////////////////////////////////////////////////////////////
// predeclarations
class CListView32Events;
class CListView32;

//////////////////////////////////////////////////////////////////////////
// constants
const DWORD DW_MSGMAPID_LISTCONTROL  = 1;
const DWORD  DW_IMAGELIST_CXCY_LARGE = 32;
const DWORD  DW_IMAGELIST_CXCY_SMALL = 16;
const DWORD  DW_IMAGELIST_INITIAL    = 5;
const DWORD  DW_IMAGELIST_GROW       = 5;

//////////////////////////////////////////////////////////////////////////
// CListView32Events

class CListView32Events
{
// Members
private:

// Construction & Destruction
public:
 CListView32Events(){}
 virtual ~CListView32Events(){}

// Events
protected:
 virtual LRESULT OnDblClick(int idCtrl, 
                             LPNMHDR pnmh , 
                             BOOL& bHandled) PURE; 
 virtual LRESULT OnSelChanged(int idCtrl, 
                               LPNMHDR pnmh , 
                               BOOL& bHandled) PURE;

friend CListView32;
};

typedef CListView32Events* LPLISTVIEW32EVENTS;

//////////////////////////////////////////////////////////////////////////
// CListView32

class CListView32 : public CWindowImpl<CListView32>
{
// Members
protected:
 // Keep the list control self contained
 CContainedWindow    m_wndListControl;     
 // Large Icons for the view
 HIMAGELIST          m_hImageListLarge;      
 // Small Icons for the view
 HIMAGELIST          m_hImageListSmall;      
 // Cache of icon handles in the image list
 LPDWORD             m_lpdwHICONsInImageList;  
 // Cache of icon handles in the image list
 DWORD               m_dwCountHICONsInImageList; 
 // Cache of icon handles in the image list
 LPLISTVIEW32EVENTS  m_lpListView32Events;   
 // Initial View of the list control
 long                m_lInitialView;       

private:
 // Should the column width autofit the longest text in the column
 BOOL        m_bAutoFitItemText; 
 // Should the column width autofit the longest text in the column
 int         m_iCountColumns;  

// Construction & Destruction
public:
 CListView32(LPLISTVIEW32EVENTS lpListView32Events = NULL);
 virtual ~CListView32();

// Utils
private:
 void  ClearMemberVar();
 void  LVCOLUMNSet(int iIndexCol, 
                   LPCTSTR lpctstrText, 
                   int iWidth, 
                   int iSubItem, 
                   int iFormat, 
                   LV_COLUMN& lvColumn);
 void  AutoFitColumn(int iIndexCol, LPCTSTR lpctstrText);

// Interface
public:
 HWND CreateEx(HWND hWndParent, 
               RECT& rcPos, 
               long lInitialView = LVS_REPORT);

 // NOTE:  All row and col indexes are zero based!

 // List Control Window Style
 virtual void  StyleSet(long lStyle);
 virtual long  StyleGet();

 // Set the View of the List control (ie. LVS_REPORT, 
 //              LVS_ICON, LVS_SMALLICON, LVS_LIST)
 virtual void  ViewSet(long lView);
 virtual long  ViewGet();
             
 // Columns
 virtual int   ColumnCount() { return m_iCountColumns; } 
 virtual HRESULT ColumnAdd(LPCTSTR lpctstrColumnHeading, 
                           int iWidth    = -1, 
                           int iSubItem  = -1, 
                           int iFormat   = LVCFMT_LEFT);
 virtual HRESULT ColumnInsert(int iIndexCol, 
                               LPCTSTR lpctstrColumnHeading, 
                               int iWidth    = -1, 
                               int iSubItem  = -1, 
                               int iFormat   = LVCFMT_LEFT);
 virtual HRESULT ColumnUpdate(int iIndexCol, 
                               LPCTSTR lpctstrColumnHeading, 
                               int iWidth    = -1, 
                               int iSubItem  = -1, 
                               int iFormat   = LVCFMT_LEFT);
 virtual HRESULT ColumnRemoveAt(int iIndexCol);
 virtual HRESULT ColumnRemoveAll();
 virtual HRESULT ColumnWidthSet(int iIndexCol, int  iWidth);
 virtual HRESULT ColumnWidthGet(int iIndexCol, int& iWidth);
 virtual void  ColumnAutoFitSet(BOOL bAutoFitItemText) 
                   { m_bAutoFitItemText = bAutoFitItemText; }
 virtual BOOL  ColumnAutoFitGet() { return m_bAutoFitItemText; }

 // Rows
 virtual int   RowCount();
 virtual HRESULT RowItemSet(int iIndexRow, 
                            int iIndexCol, 
                            LPCTSTR lpctstrItem, 
                            LPARAM lParam   = NULL, 
                            int iImage      = -1, 
                            UINT nState     = NULL, 
                            UINT nStateMask = NULL);

 virtual HRESULT RowItemGet(int iIndexRow, 
                            int iIndexCol, 
                            LPTSTR lptstrData, 
                            DWORD dwDataSize);

 virtual HRESULT RowRemove(int iIndexRow);
 virtual HRESULT RowRemoveAll();
 virtual HRESULT RowLPARAMSet(int iIndexRow, LPARAM  lParam);
 virtual HRESULT RowLPARAMGet(int iIndexRow, LPARAM& lParam);
 virtual HRESULT RowStateSet(int iIndexRow, UINT nMask, UINT  nState);
 virtual HRESULT RowStateGet(int iIndexRow, UINT nMask, UINT& nState);

 // Image List
protected:
 virtual int   ImageListImageCount(int iImageListType);
 virtual HRESULT ImageListAdd(int iImageListType, HICON hIcon);
 virtual HRESULT ImageListAdd(HICON hIcon);
 virtual HRESULT ImageListRemove(int iImageListType, int iIndex);
 virtual HRESULT ImageListRemove(int iIndex);

public:
 virtual HRESULT ImageListImageIndex(HICON hIcon, int& iIndexImage);

 // Message Map
public:
 BEGIN_MSG_MAP(CListView32)
 // Events for the list view (outer class)
   MESSAGE_HANDLER(WM_CREATE, OnCreate)
   MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
   MESSAGE_HANDLER(WM_SETFOCUS, OnSetFocus)
   MESSAGE_HANDLER(WM_SIZE, OnSize)
   NOTIFY_CODE_HANDLER(NM_DBLCLK, OnDblClick)
   NOTIFY_CODE_HANDLER(LVN_ITEMCHANGED, OnSelChanged)
 // Events for the list control (inner class)
 ALT_MSG_MAP(DW_MSGMAPID_LISTCONTROL) 
 END_MSG_MAP()

 // Events
protected:
 LRESULT OnCreate(UINT uMsg, 
                  WPARAM wParam, 
                  LPARAM lParam, 
                  BOOL& bHandled);
 LRESULT OnDestroy(UINT uMsg, 
                   WPARAM wParam, 
                   LPARAM lParam, 
                   BOOL& bHandled);
 LRESULT OnSetFocus(UINT uMsg, 
                    WPARAM wParam, 
                    LPARAM lParam, 
                    BOOL& bHandled);
 LRESULT OnSize(UINT uMsg, 
                WPARAM wParam, 
                LPARAM lParam, 
                BOOL& bHandled);
 LRESULT OnDblClick(int idCtrl, LPNMHDR pnmh , BOOL& bHandled);
 LRESULT OnSelChanged(int idCtrl, LPNMHDR pnmh , BOOL& bHandled);
};

#endif // #ifndef _LISTVIEW32_H

