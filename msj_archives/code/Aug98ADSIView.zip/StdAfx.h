// stdafx.h : include file for standard system include files,
//      or project specific include files that are used frequently,
//      but are changed infrequently

#ifndef _STDAFX_H
#define _STDAFX_H

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define STRICT

#define _WIN32_IE   0x0401
#define _WIN32_WINNT 0x0400
#define _ATL_APARTMENT_THREADED


#include <atlbase.h>
//You may derive a class from CComModule and 
//use it if you want to override
//something, but do not change the name of _Module
extern CComModule _Module;
#include <atlcom.h>
#include <atlwin.h>
#include <atlctl.h>

#include <commctrl.h>

#include "ADSIView.h"

#define __DWebBrowserEvents2_DISPINTERFACE_DEFINED__

#include <shlobj.h>

#ifdef _DEBUG
#define ASSERT_POINTER(pointer,SIZEOF)\
    _ASSERT(!IsBadReadPtr(pointer,sizeof(SIZEOF)));
#define ASSERT _ASSERTE
#define VERIFY(theStatement)      ASSERT(theStatement)
#else
#define ASSERT_POINTER(pointer,SIZEOF)
#define ASSERT 
#define VERIFY(theStatement)      (theStatement)
#endif

//{{AFX_INSERT_LOCATION}}

#endif // #ifndef _STDAFX_H
