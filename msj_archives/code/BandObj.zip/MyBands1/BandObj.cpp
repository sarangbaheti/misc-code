////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- November 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
// ---
// CBandObj-- generic Windows band object (IE Info/comm band and desktop band).
// Provides default implementation for IDeskBand. You must also include the
// band object registration script, BandObj.rgs, in your RC file.
//
//
#include "StdAfx.h"
#include "BandObj.h"
#include "atliface.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define BANDOBJCLASS (_T("MSJ_DeskBandClass"))

// To turn on debugging, set these TRUE
BOOL CBandObj::bTRACE = FALSE;

#ifdef _DEBUG
#define BOTRACEFN				\
	CTraceFn __fooble;		\
	if (CBandObj::bTRACE)	\
		TRACE						
#define BOTRACE				\
	if (CBandObj::bTRACE)	\
		TRACE
#else
#define BOTRACEFN
#define BOTRACE
#endif

DEBUG_BEGIN_INTERFACE_NAMES()
	DEBUG_INTERFACE_NAME(IContextMenu)
	DEBUG_INTERFACE_NAME(IContextMenu2)
	DEBUG_INTERFACE_NAME(IContextMenu3)
	DEBUG_INTERFACE_NAME(IDockingWindow)
	DEBUG_INTERFACE_NAME(IInputObject)
	DEBUG_INTERFACE_NAME(IOleWindow)
	DEBUG_INTERFACE_NAME(IDeskBand)
DEBUG_END_INTERFACE_NAMES();

IMPLEMENT_DYNAMIC(CBandObjDll, COleControlModule);

CBandObjDll::CBandObjDll()
{
}

CBandObjDll::~CBandObjDll()
{
}

//////////////////
// Call from your InitInstance to add a new band object class.
//
BOOL CBandObjDll::AddBandClass(REFCLSID clsid, CRuntimeClass* pClass,
	const CATID& catid, UINT nResID)
{
	BOTRACEFN(_T("CBandObjDll::AddBandClass\n"));
	CTLockData lock(m_myself);
	CBandObjFactory* pFact = OnCreateFactory(clsid, pClass, catid, nResID);
	if (pFact) {
		ASSERT_VALID(pFact);
		pFact->m_pNext = m_pBandFactories;
		m_pBandFactories = pFact;
		return TRUE;
	}
	return FALSE;
}

//////////////////
// Override if you ever want to create a different kind of factory (rare)
//
CBandObjFactory* CBandObjDll::OnCreateFactory(REFCLSID clsid,
	CRuntimeClass* pClass, const CATID& catid, UINT nResID)
{
	return new CBandObjFactory(clsid, pClass, catid, nResID);
}

CBandObjFactory* CBandObjDll::GetFactory(REFCLSID clsid)
{
	CTLockData lock(m_myself);
	for (CBandObjFactory* pf=m_pBandFactories; pf; pf=pf->m_pNext) {
		if (pf->GetClassID()==clsid)
			return pf;
	}
	return NULL;
}

//////////////////
// Shutdown: delete all the factories
//
int CBandObjDll::ExitInstance()
{
	BOTRACEFN(_T("CBandObjDll::ExitInstance\n"));
	CTLockData lock(m_myself);
	while (m_pBandFactories) {
		CBandObjFactory* pFact = m_pBandFactories;
		m_pBandFactories = pFact->m_pNext;
		delete pFact;
	}
	return COleControlModule::ExitInstance();
}

////////////////////////////////////////////////////////////////
// CBandObjFactory
//
IMPLEMENT_DYNAMIC(CBandObjFactory, COleObjectFactory)

CBandObjFactory* g_pBandFactories = NULL;

CBandObjFactory::CBandObjFactory(REFCLSID clsid, CRuntimeClass* pClass,
	const CATID& catid, UINT nIDRes)
	:  COleObjectFactory(clsid, pClass, FALSE, NULL)
{
	BOTRACEFN(_T("CBandObjFactory::CBandObjFactory\n"));
	ASSERT(pClass && pClass->IsDerivedFrom(RUNTIME_CLASS(CBandObj)));
	m_pNext = NULL;
	m_catid = catid;
	m_nIDRes = nIDRes;
}

CBandObjFactory::~CBandObjFactory()
{
	BOTRACEFN(_T("CBandObjFactory::~CBandObjFactory\n"));
}

////////////////
// Band objects are not insertable, so bypass MFC's standard
// registration. There's no ProgID
//
BOOL CBandObjFactory::UpdateRegistry(BOOL bRegister)
{
	BOTRACEFN(_T("CBandObjFactory(%p)::UpdateRegistry(%d)\n"), this, bRegister);

	static const LPOLESTR RT_REGISTRY = OLESTR("REGISTRY");
	UINT nID = GetResourceID();
	if (nID==0)
		return TRUE;

	if (!::FindResource(AfxGetResourceHandle(),
		MAKEINTRESOURCE(nID), CString(RT_REGISTRY)))
		return FALSE;

	// initialize registry variables
	CTRegistrar iReg;
	OnInitRegistryVariables(iReg);

	// register/unregister script
	CString s;
	::GetModuleFileName(AfxGetInstanceHandle(),
		s.GetBuffer(_MAX_PATH), _MAX_PATH);

	USES_CONVERSION;
	LPOLESTR lposModuleName = T2OLE(s);
	TRACE("sModuleName=%s\n",OLE2T(lposModuleName));

	HRESULT hr = bRegister ?
		iReg->ResourceRegister(lposModuleName, nID, RT_REGISTRY) :
		iReg->ResourceUnregister(lposModuleName, nID, RT_REGISTRY);
	if (!SUCCEEDED(hr)) {
		TRACE(_T("*** CBandObj:: error %s loading registry script"),DbgName(hr));
		return FALSE;
	}

	if (bRegister==FALSE) {
		// IRegistrar doesn't always delete top-level key right, so delete it
		CString sClsid;
		sClsid = StringFromCLSID(m_clsid);
		if (!sClsid.IsEmpty()) { // for extra-safety! don't delete CLSID !!
			CString sKey;
			sKey.Format(_T("CLSID\\%s"), (LPCTSTR)sClsid);
			AfxGetApp()->DelRegTree(HKEY_CLASSES_ROOT, sKey);
		}
	}

	// register/unregister categories using ICatRegister
	CTCatRegister iCat;
	REFIID clsid = m_clsid;
	hr = bRegister ?
		iCat->RegisterClassImplCategories(clsid, 1, &m_catid) :
		iCat->UnRegisterClassImplCategories(clsid, 1, &m_catid);
	if (!SUCCEEDED(hr)) {
		TRACE(_T("*** CBandObj:: error %s registering categoriy"),DbgName(hr));
		return FALSE;
	}

	return SUCCEEDED(hr); // return, bypassing MFC/COleObjectFactory
}

//////////////////
// Initialize standard variables
//
// %CLSID%		= class ID (GUID) (COleObjectFactory::m_clsid)
// %MODULE%	   = full pathname of DLL
// %Title%     = title (resource substring 0)
// %ClassName% = human-readable COM class name (resource substring 1)
// %ProgID%    = ProgID (resource substring 2)
//
// You can override to add your own in addition
//
BOOL CBandObjFactory::OnInitRegistryVariables(IRegistrar* pReg)
{
	USES_CONVERSION;
	VERIFY(pReg->AddReplacement(OLESTR("CLSID"),
		StringFromCLSID(m_clsid))==S_OK);
	CString sModuleName;
	::GetModuleFileName(AfxGetInstanceHandle(),
		sModuleName.GetBuffer(_MAX_PATH), _MAX_PATH);
	VERIFY(pReg->AddReplacement(OLESTR("MODULE"),
		T2OLE(sModuleName))==S_OK);
	VERIFY(pReg->AddReplacement(OLESTR("Title"),
		T2OLE(GetTitle()))==S_OK);
	VERIFY(pReg->AddReplacement(OLESTR("ClassName"),
		T2OLE(GetClassName()))==S_OK);
	VERIFY(pReg->AddReplacement(OLESTR("ProgID"),
		T2OLE(GetProgID()))==S_OK);
	return TRUE;
}

////////////////////////////////////////////////////////////////
// CBandObj

BEGIN_INTERFACE_MAP(CBandObj, CWnd)
	INTERFACE_PART(CBandObj, IID_IOleWindow,		DeskBand)
	INTERFACE_PART(CBandObj, IID_IDockingWindow, DeskBand)
	INTERFACE_PART(CBandObj, IID_IDeskBand,		DeskBand)
	INTERFACE_PART(CBandObj, IID_IPersist,			PersistStream)
	INTERFACE_PART(CBandObj, IID_IPersistStream,	PersistStream)
	INTERFACE_PART(CBandObj, IID_IInputObject,	InputObject)
	INTERFACE_PART(CBandObj, IID_IContextMenu,	ContextMenu)
	INTERFACE_PART(CBandObj, IID_IObjectWithSite,ObjectWithSite)
END_INTERFACE_MAP()

CBandObj::CBandObj(REFCLSID clsid) : m_clsid(clsid)
{
	BOTRACEFN(_T("CBandObj(%p)::CBandObj\n"),this);
	AfxOleLockApp(); // don't unload DLL while I'm alive

   m_dwBandID = m_dwViewMode = 0;

	// set up default DESKBANDINFO
	m_dbiDefault.ptMinSize = CPointL(-1,-1);
	m_dbiDefault.ptMaxSize = CPointL(-1,-1);
	m_dbiDefault.ptActual  = CPointL(0,0);
	m_dbiDefault.ptIntegral= CPointL(1,1);
	m_dbiDefault.dwModeFlags = DBIMF_NORMAL;

	// stuff to initialize from factory
	CBandObjDll* pApp = (CBandObjDll*)AfxGetApp();
	ASSERT_KINDOF(CBandObjDll, pApp);
	CBandObjFactory* pFact = pApp->GetFactory(clsid);
	m_nIDRes = pFact->GetResourceID();
	m_strTitle = pFact->GetTitle();
	m_bModified = FALSE;
}

CBandObj::~CBandObj()
{
	BOTRACEFN(_T("CBandObj(%p)::~CBandObj\n"), this);
	AfxOleUnlockApp();	// OK by me to unload DLL
}

//////////////////
// called when ref count goes to zero: delete myself
//
void CBandObj::OnFinalRelease()
{
	BOTRACEFN(_T("CBandObj(%p)::OnFinalRelease\n"), this);
	CCmdTarget::OnFinalRelease(); // will delete this
}


//////////////// IUnknown -- all nested versions call these ////////////////

STDMETHODIMP_(ULONG) CBandObj::AddRef()
{
	BOTRACEFN(_T("CBandObj(%p)::AddRef\n"),this);
	return ExternalAddRef();
}

STDMETHODIMP_(ULONG) CBandObj::Release()
{
	BOTRACEFN(_T("CBandObj(%p)::Release\n"), this);
	return ExternalRelease();
}

STDMETHODIMP CBandObj::QueryInterface(REFIID iid, LPVOID* ppvRet)
{
	CTCHECKARG(ppvRet);
	BOTRACEFN(_T("CBandObj(%p)::QueryInterface(%s)\n"),
		this, DbgName(iid));
	HRESULT hr = ExternalQueryInterface(&iid, ppvRet);
	BOTRACE(_T(">CBandObj::QueryInterface returns %s, *ppv=%p\n"),
		DbgName(hr), *ppvRet);
   return hr;
}

//////////////// IDeskBand ////////////////

STDMETHODIMP_(ULONG) CBandObj::XDeskBand::AddRef()
{
	METHOD_PROLOGUE(CBandObj, DeskBand);
	return pThis->AddRef();
}

STDMETHODIMP_(ULONG) CBandObj::XDeskBand::Release()
{
	METHOD_PROLOGUE(CBandObj, DeskBand);
	return pThis->Release();
}

STDMETHODIMP CBandObj::XDeskBand::QueryInterface(REFIID iid, LPVOID* ppvRet)
{
	METHOD_PROLOGUE(CBandObj, DeskBand);
	return pThis->QueryInterface(iid, ppvRet);
}

STDMETHODIMP CBandObj::XDeskBand::GetWindow(HWND* pHwnd)
{
	METHOD_PROLOGUE(CBandObj, DeskBand);
	BOTRACEFN(_T("CBandObj(%p)::IOleWindow::GetWindow\n"), pThis);
	if (pHwnd)
		*pHwnd = pThis->m_hWnd;
	return S_OK;
}

STDMETHODIMP CBandObj::XDeskBand::ContextSensitiveHelp(BOOL fEnterMode)
{
	METHOD_PROLOGUE(CBandObj, DeskBand);
	BOTRACEFN(_T("CBandObj(%p)::IOleWindow::ContextSensitiveHelp\n"), pThis);
	return E_NOTIMPL;	// sorry, not yet
}

STDMETHODIMP CBandObj::XDeskBand::ShowDW(BOOL fShow)
{
	METHOD_PROLOGUE(CBandObj, DeskBand);
	BOTRACEFN(_T("CBandObj(%p)::IDockingWindow::ShowDW(%d)\n"), pThis, fShow);
	pThis->ShowWindow(fShow ? SW_SHOW : SW_HIDE);
	return S_OK;
}

STDMETHODIMP CBandObj::XDeskBand::CloseDW(DWORD dwReserved)
{
	METHOD_PROLOGUE(CBandObj, DeskBand);
	BOTRACEFN(_T("CBandObj(%p)::IDockingWindow::CloseDW\n"), pThis);
	pThis->SendMessage(WM_CLOSE);
	return S_OK;
}

STDMETHODIMP CBandObj::XDeskBand::ResizeBorderDW(LPCRECT prcBorder,
	IUnknown* punkDWSite, BOOL fReserved)
{
	METHOD_PROLOGUE(CBandObj, DeskBand);
	BOTRACEFN(_T("CBandObj(%p)::IDockingWindow::ResizeBorderDW\n"), pThis);
	return E_NOTIMPL;
}

/////////////////
// Windows wants band info: stuff with m_dbiDefault
// or resource information
//
STDMETHODIMP CBandObj::XDeskBand::GetBandInfo(DWORD dwBandID, DWORD dwViewMode,
	DESKBANDINFO* pdbi)
{
	METHOD_PROLOGUE(CBandObj, DeskBand);
	BOTRACEFN(_T("CBandObj(%p)::IDeskBand::GetBandInfo id=%d mode=%0x\n"),
		pThis, dwBandID, dwViewMode);

	pThis->m_dwBandID = dwBandID;			 // save in case you're interested
	pThis->m_dwViewMode = dwViewMode;	 // ditto

	if (!pdbi) 
		return E_INVALIDARG;

	DWORD mask = pdbi->dwMask;
	DESKBANDINFO& m_dbiDefault = pThis->m_dbiDefault;

	if (mask & DBIM_MINSIZE)
		pdbi->ptMinSize = m_dbiDefault.ptMinSize;

	if (mask & DBIM_MAXSIZE)
		pdbi->ptMaxSize = m_dbiDefault.ptMaxSize;

	if (mask & DBIM_INTEGRAL)
		pdbi->ptIntegral = m_dbiDefault.ptIntegral;

	if (mask & DBIM_ACTUAL)  // desired size
		pdbi->ptActual = m_dbiDefault.ptActual;

	if (mask & DBIM_TITLE) {
		USES_CONVERSION;
		lstrcpyW(pdbi->wszTitle, T2OLE(pThis->GetTitle()));
	}

	if (mask & DBIM_MODEFLAGS)
		pdbi->dwModeFlags = m_dbiDefault.dwModeFlags;

	if (mask & DBIM_BKCOLOR)
		pdbi->dwMask &= ~DBIM_BKCOLOR;	 // clear to use default color

	return S_OK;
}

//////////////// IPersistStream ////////////////

STDMETHODIMP_(ULONG) CBandObj::XPersistStream::AddRef()
{
	METHOD_PROLOGUE(CBandObj, PersistStream);
	return pThis->AddRef();
}

STDMETHODIMP_(ULONG) CBandObj::XPersistStream::Release()
{
	METHOD_PROLOGUE(CBandObj, PersistStream);
	return pThis->Release();
}

STDMETHODIMP CBandObj::XPersistStream::QueryInterface(REFIID iid, LPVOID* ppv)
{
	METHOD_PROLOGUE(CBandObj, PersistStream);
	return pThis->QueryInterface(iid, ppv);
}

STDMETHODIMP CBandObj::XPersistStream::GetClassID(LPCLSID pClassID)
{
	METHOD_PROLOGUE(CBandObj, PersistStream);
	BOTRACEFN(_T("CBandObj(%p)::IPersist::GetClassID\n"), pThis);
	return pClassID ? (*pClassID=pThis->m_clsid, S_OK) : E_UNEXPECTED;
}

STDMETHODIMP CBandObj::XPersistStream::IsDirty()
{
	METHOD_PROLOGUE(CBandObj, PersistStream);
	BOTRACEFN(_T("CBandObj(%p)::IPersistStream::IsDirty\n"), pThis);
	return S_FALSE;
}

STDMETHODIMP CBandObj::XPersistStream::Load(LPSTREAM lpStream)
{
	METHOD_PROLOGUE(CBandObj, PersistStream);
	BOTRACEFN(_T("CBandObj(%p)::IPersistStream::Load\n"), pThis);
	return S_OK;
}

STDMETHODIMP CBandObj::XPersistStream::Save(LPSTREAM lpStrm, BOOL bClearDirty)
{
	METHOD_PROLOGUE(CBandObj, PersistStream);
	BOTRACEFN(_T("CBandObj(%p)::IPersistStream::Save\n"), pThis);
	return S_OK;
}

STDMETHODIMP CBandObj::XPersistStream::GetSizeMax(ULARGE_INTEGER* pcbSize)
{
	METHOD_PROLOGUE(CBandObj, PersistStream);
	BOTRACEFN(_T("CBandObj(%p)::IPersistStream::GetSizeMax\n"), pThis);
	if (pcbSize)
		pcbSize->LowPart = pcbSize->HighPart = 0;
	return S_OK;
}

//////////////// IContextMenu ////////////////

STDMETHODIMP_(ULONG) CBandObj::XContextMenu::AddRef()
{
	METHOD_PROLOGUE(CBandObj, ContextMenu);
	return pThis->AddRef();
}

STDMETHODIMP_(ULONG) CBandObj::XContextMenu::Release()
{
	METHOD_PROLOGUE(CBandObj, ContextMenu);
	return pThis->Release();
}

STDMETHODIMP CBandObj::XContextMenu::QueryInterface(REFIID iid, LPVOID* ppv)
{
	METHOD_PROLOGUE(CBandObj, ContextMenu);
	return pThis->QueryInterface(iid, ppv);
}

STDMETHODIMP CBandObj::XContextMenu::QueryContextMenu(HMENU hmenu, UINT index,
	UINT idCmdFirst, UINT idCmdLast, UINT uFlags)
{
	METHOD_PROLOGUE(CBandObj, ContextMenu);
	BOTRACEFN(_T("CBandObj(%p)::IContextMenu::QueryContextMenu\n"), pThis);

	CMenu& m_menu = pThis->m_contextMenu;
	USHORT uRet = 0;
	if (m_menu && !(uFlags & CMF_DEFAULTONLY)) {
		for (UINT i=0; i<m_menu.GetMenuItemCount(); i++) {
			pThis->InitMenuItem(pThis, m_menu, i);
			UINT nMyID = m_menu.GetMenuItemID(i);
			if (idCmdFirst+nMyID <= idCmdLast) {
				CString sItem;
				m_menu.GetMenuString(i, sItem, MF_BYPOSITION);
				if (InsertMenu(hmenu, index,
					m_menu.GetMenuState(i, MF_BYPOSITION) | MF_BYPOSITION,
					idCmdFirst+nMyID,
					(LPCTSTR)sItem)) {
					index++;
				}
				uRet = nMyID+1;
			}
		}
		InsertMenu(hmenu, index, MF_SEPARATOR|MF_BYPOSITION,-1,NULL);
	}
	return MAKE_HRESULT(SEVERITY_SUCCESS, 0, uRet);
}

//////////////////
// Initialize menu item. This works for any item in a context menu
//
void CBandObj::InitMenuItem(CCmdTarget* pTarg, CMenu& menu, UINT nIndex)
{
	CMenu& m_menu = m_contextMenu;
	CCmdUI state;
	state.m_pMenu = &m_menu;
	state.m_nIndex = nIndex;
	state.m_nIndexMax = menu.GetMenuItemCount();
	state.m_nID = menu.GetMenuItemID(nIndex);
	if (state.m_nID == (UINT)-1) {
		// possibly a popup menu, route to first item of that popup
		state.m_pSubMenu = menu.GetSubMenu(nIndex);
		if (state.m_pSubMenu == NULL ||
			(state.m_nID = state.m_pSubMenu->GetMenuItemID(0)) == 0 ||
			state.m_nID == (UINT)-1) {
			// first item of popup can't be routed to
		}
		state.DoUpdate(pTarg, FALSE);    // popups are never auto disabled

	} else {
		// normal menu item
		// Auto enable/disable if 'm_bAutoMenuEnable'
		// and command is _not_ a system command.
		state.m_pSubMenu = NULL;
		state.DoUpdate(pTarg, TRUE);
	}
}

STDMETHODIMP CBandObj::XContextMenu::InvokeCommand(LPCMINVOKECOMMANDINFO lpcmi)
{
	METHOD_PROLOGUE(CBandObj, ContextMenu);
	BOTRACEFN(_T("CBandObj(%p)::IContextMenu::InvokeCommand(%d)\n"),
		pThis, LOWORD(lpcmi->lpVerb));

	if (HIWORD(lpcmi->lpVerb)==0) {
		// Simulate WM_COMMAND. MFC will route to appropriate cmd target
		//
		pThis->OnCmdMsg(LOWORD(lpcmi->lpVerb), CN_COMMAND, NULL, NULL);
		return NOERROR;
	}
	return E_NOTIMPL;
}

STDMETHODIMP CBandObj::XContextMenu::GetCommandString(UINT nID, UINT uFlags,
	UINT*, LPSTR pszName, UINT cchMax)
{
	METHOD_PROLOGUE(CBandObj, ContextMenu);
	BOTRACEFN(_T("CBandObj(%p)::IContextMenu::GetCommandString(%d)\n"),
		pThis, nID);

	CMenu& m_menu = pThis->m_contextMenu;
	HRESULT hr = E_INVALIDARG;
	ASSERT(m_menu);
	CString str;
	BOOL bCopy = TRUE;						 // assume I will return the string
	if (uFlags==GCS_HELPTEXT) {
		// get prompt string
		CString sRes;
		sRes.LoadString(nID);
		AfxExtractSubString(str, sRes, 0);

	} else if ((uFlags==GCS_VERB || uFlags==GCS_VALIDATE)) {
		// get menu item itself
		if (m_menu.GetMenuString(nID, str, MF_BYCOMMAND)) {
			if (uFlags==GCS_VALIDATE) {
				// don't copy for GCS_VALIDATE
				bCopy = FALSE;
			}
			hr = NOERROR;
		}
	}
	if (bCopy) {
		strncpy(pszName, str, cchMax);
		pszName[cchMax-1]=0;
	}

	return hr;
}

//////////////// IInputObject ////////////////

STDMETHODIMP_(ULONG) CBandObj::XInputObject::AddRef()
{
	METHOD_PROLOGUE(CBandObj, InputObject);
	return pThis->AddRef();
}

STDMETHODIMP_(ULONG) CBandObj::XInputObject::Release()
{
	METHOD_PROLOGUE(CBandObj, InputObject);
	return pThis->Release();
}

STDMETHODIMP CBandObj::XInputObject::QueryInterface(REFIID iid, LPVOID* ppv)
{
	METHOD_PROLOGUE(CBandObj, InputObject);
	return pThis->QueryInterface(iid, ppv);
}

STDMETHODIMP CBandObj::XInputObject::UIActivateIO(BOOL fActivate, LPMSG pMsg)
{
	METHOD_PROLOGUE(CBandObj, InputObject);
	BOTRACEFN(_T("CBandObj(%p)::IInputObject::UIActivateIO(%d)\n"),
		pThis, fActivate);
	if (fActivate && pThis->GetSafeHwnd())
		pThis->SetFocus();
	return S_OK;
}

STDMETHODIMP CBandObj::XInputObject::HasFocusIO()
{
	METHOD_PROLOGUE(CBandObj, InputObject);
	BOTRACEFN(_T("CBandObj(%p)::IInputObject::HasFocusIO\n"), pThis);

	HWND hwndFocus = ::GetFocus();
	HWND hwndMe = pThis->GetSafeHwnd();
	return (hwndFocus==hwndMe || ::IsChild(hwndMe, hwndFocus)) ?
		S_OK : S_FALSE;
}

STDMETHODIMP CBandObj::XInputObject::TranslateAcceleratorIO(LPMSG pMsg)
{
	METHOD_PROLOGUE(CBandObj, InputObject);
	BOTRACEFN(_T("CBandObj(%p)::IInputObject::TranslateAcceleratorIO\n"),
		pThis);

	if (WM_KEYFIRST<=pMsg->message && pMsg->message<=WM_KEYLAST) {
		// You can override GetDefaultAccelerator to provide dynamic accels
		HACCEL hAccel = pThis->m_hAccel;
		if (hAccel) {
			HWND hwndMe = pThis->GetSafeHwnd();
			if (hwndMe && ::TranslateAccelerator(hwndMe, hAccel, pMsg))
				return S_OK;
		}
	}
	return S_FALSE; 
}

// **************** IObjectWithSite ****************

STDMETHODIMP_(ULONG) CBandObj::XObjectWithSite::AddRef()
{
	METHOD_PROLOGUE(CBandObj, ObjectWithSite);
	return pThis->AddRef();
}

STDMETHODIMP_(ULONG) CBandObj::XObjectWithSite::Release()
{
	METHOD_PROLOGUE(CBandObj, ObjectWithSite);
	return pThis->Release();
}

STDMETHODIMP CBandObj::XObjectWithSite::QueryInterface(REFIID iid, LPVOID* ppv)
{
	METHOD_PROLOGUE(CBandObj, ObjectWithSite);
	return pThis->QueryInterface(iid, ppv);
}

//////////////////
// SetSite set the site and create window
//
STDMETHODIMP CBandObj::XObjectWithSite::SetSite(IUnknown* pSite)
{
	METHOD_PROLOGUE(CBandObj, ObjectWithSite);
	BOTRACEFN(_T("CBandObj(%p)::IObjectWithSite::SetSite %p\n"), pThis, pSite); 

	return pThis->OnSetSite(pSite);
}

HRESULT CBandObj::OnSetSite(IUnknown* pSite)
{
	m_spSite = pSite;
	if (pSite!=NULL) {
		// Get parent window, which is site's window
		CComQIPtr<IOleWindow> spOleWin = m_spSite;
		if (!spOleWin)
			return E_FAIL;

		HWND hwndParent = NULL;
		spOleWin->GetWindow(&hwndParent);
		if (!hwndParent)
			return E_FAIL;

		CWnd* pParent = CWnd::FromHandle(hwndParent);
		ASSERT_VALID(pParent);
		CRect rc;
		pParent->GetClientRect(&rc);

		// Call virtual Create fn to create the window
		if (!OnCreateWindow(pParent, rc))
			return E_FAIL;

	} else if (!m_spSite) {
		return E_UNEXPECTED;
	}
	return S_OK;
}

STDMETHODIMP CBandObj::XObjectWithSite::GetSite(REFIID iid, void** ppv)
{
	METHOD_PROLOGUE(CBandObj, ObjectWithSite);
	BOTRACEFN(_T("CBandObj(%p)::IObjectWithSite::SetSite %p\n"), pThis, ppv);
	CTCHECKARG(ppv);
	*ppv = NULL;
	SPIInputObjectSite& m_spSite = pThis->m_spSite;
	return m_spSite ? m_spSite->QueryInterface(iid, ppv) : E_FAIL;
}

////////////////////////////////////////////////////////////////
// CBandObj MFC fns
//
IMPLEMENT_DYNAMIC(CBandObj, CWnd)
BEGIN_MESSAGE_MAP(CBandObj, CWnd)
	ON_WM_CREATE()
   ON_WM_SETFOCUS()
   ON_WM_KILLFOCUS()
	ON_WM_MOUSEACTIVATE()
END_MESSAGE_MAP()

//////////////////
// Create the window. You can override to do your own thing
//
BOOL CBandObj::OnCreateWindow(CWnd* pParent, const CRect& rc)
{
	static BOOL bRegistered = FALSE;
	static CCriticalSection cs; // protect static global
	CTLockData lock(cs);

	// register window class if not already
	if (!bRegistered) {
		WNDCLASS wc;
		memset(&wc, 0, sizeof(wc));
		wc.style = CS_HREDRAW | CS_VREDRAW | CS_GLOBALCLASS;
		wc.lpfnWndProc = (WNDPROC)::DefWindowProc; // will get hooked by MFC
		wc.hInstance = AfxGetInstanceHandle();
      wc.hCursor = LoadCursor(NULL, IDC_ARROW);
      wc.hbrBackground = CreateSolidBrush(GetSysColor(COLOR_WINDOW));
      wc.lpszMenuName = NULL;
      wc.lpszClassName = BANDOBJCLASS;
		if (!AfxRegisterClass(&wc)) {
			TRACE(_T("*** CBandObj::GetWindow - AfxRegisterClass failed!\n"));
			return FALSE;
		}
		bRegistered = TRUE;
	}

	// create the window
	if (!CWnd::Create(BANDOBJCLASS, GetTitle(),
		WS_CHILD|WS_CLIPSIBLINGS|WS_BORDER,
		rc, pParent, m_dwBandID, NULL)) {

		TRACE(_T("*** CBandObj::GetWindow failed to create window!\n"));
		return FALSE;
	}
	return TRUE;
}

//////////////////
// Window is being created: load context menu and accels, if any
//
int CBandObj::OnCreate(LPCREATESTRUCT lpcs)
{
	BOTRACEFN(_T("CBandObj(%p)::OnCreate\n"), this);

	// Load context menu if any. context menu is 1st submenu in resource menu.
	CMenu menu;
	if (menu.LoadMenu(GetResourceID())) {
		HMENU hSubMenu = ::GetSubMenu(menu, 0);
		if (hSubMenu) {
			m_contextMenu.Attach(hSubMenu);
			menu.Detach(); // otherwise destructor will destroy my menu!
		}
	}

	// Load accelerators if any
	m_hAccel = ::LoadAccelerators(AfxGetInstanceHandle(),
		MAKEINTRESOURCE(GetResourceID()));

	// If there's no main window, install myself as main window,
	// so PreTranslateMessage etc will work. 
	//
	CWinApp*	pApp = AfxGetApp();
	ASSERT_VALID(pApp);
	if (pApp->m_pMainWnd) {
		TRACE(_T("*** CBandObj: WARNING: Main window already exists ***\n"));
	} else (!pApp->m_pMainWnd); {
		pApp->m_pMainWnd = this;
	}
	return CWnd::OnCreate(lpcs);
}

//////////////////
// This is required to route commands to the app object, which is normally
// done in MFC by CFrameWnd
//
BOOL CBandObj::OnCmdMsg(UINT nID, int nCode, void* pExtra,
	AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// pump through myself first
	if (CWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// pump through app
	CWinApp* pApp = AfxGetApp();
	if (pApp != NULL && pApp->OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	return FALSE;
}

//////////////////
// Focus handling stuff
//
void CBandObj::OnSetFocus(CWnd* pOldWnd)
{
	BOTRACEFN(_T("CBandObj(%p)::OnSetFocus\n"), this);
	OnFocusChange(TRUE);
}

void CBandObj::OnKillFocus(CWnd* pNewWnd)
{
	BOTRACEFN(_T("CBandObj(%p)::OnKillFocus\n"), this);
	OnFocusChange(FALSE);
}

//////////////////
// focus changed: tell site
//
void CBandObj::OnFocusChange(BOOL bFocus)
{
	BOTRACEFN(_T("CBandObj(%p)::OnFocusChange\n"), this);
	if (m_spSite) {
		m_spSite->OnFocusChangeIS((IDockingWindow*)&m_xDeskBand, bFocus);
	}
}

int CBandObj::OnMouseActivate(CWnd* pDesktopWnd, UINT nHitTest, UINT msg)
{
	SetFocus();
	return MA_ACTIVATE;
}

/////////////////////////////////////////////////////////////////////////////
// Special entry points required for inproc servers. Implementation passes
// control to equivalent DLL object methods, so you can override behavior.

extern "C"
STDAPI DllGetClassObject(REFCLSID clsid, REFIID iid, LPVOID* ppv)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	CTCHECKARG(ppv);
	BOTRACEFN(_T("DllGetClassObject(%s, %s)\n"),DbgName(clsid),DbgName(iid));
	SCODE sc = AfxDllGetClassObject(clsid, iid, ppv);
	BOTRACE(_T(" DllGetClassObject returns %s\n"), DbgName(sc));
	return sc;
}

STDAPI DllCanUnloadNow(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	BOTRACEFN("DllCanUnloadNow\n");
	return AfxDllCanUnloadNow();
}

STDAPI DllRegisterServer()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	BOTRACEFN("DllRegisterServer\n");
	return COleObjectFactory::UpdateRegistryAll(TRUE)
		? S_OK : SELFREG_E_CLASS;
}

STDAPI DllUnregisterServer(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	BOTRACEFN("DllUnregisterServer\n");
	return COleObjectFactory::UpdateRegistryAll(FALSE)
		? S_OK : SELFREG_E_CLASS;
}
