////////////////////////////////////////////////////////////////
// ComToys(TM) Copyright 1999 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#pragma once

#include <comdef.h>			 // basic COM defs
#include <shlobj.h>			 // shell objects
#include <afxdisp.h>			 // MFC OLE stuff
#include <afxctl.h>			 // control stuff
#include <atlbase.h>			 // ATL stuff
#include <afxmt.h>			 // Multithreading

#ifndef __cplusplus
#error ComToys requires C++!
#endif

#define DLLFUNC
#define DLLCLASS
#include "debug.h"

// Get a substring (\n separator) from resource string
inline CString PLGetResourceSubstring(UINT nResID, UINT n)
{
	CString sRes, s;
	if (sRes.LoadString(nResID))
		AfxExtractSubString(s, sRes, n);
	return s;
}

// Following is used to check for NULL args
#define CTCHECKARG(ppv)	\
	if (ppv==NULL)				\
		return E_INVALIDARG;	\

//////////////////
// This simple class is used to lock/unlock a critical section. To use it:
//    CTLockData(mySyncObject);
// Constructor calls Lock; destructor calls Unlock, so you don't have to.
//
class CTLockData {
private:
	CSyncObject& m_syncObj;
public:
	CTLockData(CSyncObject& so) : m_syncObj(so) { VERIFY(m_syncObj.Lock()); }
	~CTLockData() { m_syncObj.Unlock(); }
};

// friendly version doesn't require OLESTR ptr
inline LPOLESTR StringFromCLSID(REFCLSID clsid)
{
	LPOLESTR lp=NULL;
	::StringFromCLSID(clsid, &lp);
	return lp;
}

// declare a typedef; eg SPIPersist
#define DECLARE_SMARTPTR(ifacename) \
typedef CComQIPtr<ifacename> SP##ifacename;

// Special case for IUnknown: never use CComQIPtr
typedef CComPtr<IUnknown> SPIUnknown;

// handy registrar class
class CTRegistrar : public CComPtr<IRegistrar> {
public:
	CTRegistrar() {
		CoCreateInstance(CLSID_Registrar, NULL, CLSCTX_INPROC);
		ASSERT(p);
	}
};

// handy Category Register class
class CTCatRegister : public CComPtr<ICatRegister> {
public:
	CTCatRegister() {
		CoCreateInstance(CLSID_StdComponentCategoriesMgr, NULL, CLSCTX_INPROC);
		ASSERT(p);
	}
};
