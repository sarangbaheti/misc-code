////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- November 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#include "StdAfx.h"
#include "IniFile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

void CIniFile::Use(CWinApp *pApp, int where, LPCTSTR pszProfileName)
{
	TCHAR buf[_MAX_PATH];
	VERIFY(::GetModuleFileName(pApp->m_hInstance, buf, _MAX_PATH));
	LPTSTR ext = _tcsrchr(buf, '.');		 // points to ".exe"
	ASSERT(ext);
	_tcscpy(ext, _T(".INI"));				 // now .INI

	LPTSTR name = _tcsrchr(buf, '\\');	// points to "foo.ini"
	VERIFY(name++);
	if (pszProfileName)
		_tcscpy(name, pszProfileName);
	pszProfileName = where==LocalDir ? buf : name;

	// set the name
	free((void*)pApp->m_pszProfileName);
	free((void*)pApp->m_pszRegistryKey);
	pApp->m_pszProfileName = _tcsdup(pszProfileName);
	pApp->m_pszRegistryKey = NULL;
}
