////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- November 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#include "stdafx.h"
#include "resource.h"
#include "EditSearch.h"
#include "StatLink.h"
#include "IniFile.h"
#include "TraceWin.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

class CSearchEditApp : public CWinApp {
public:
	virtual BOOL InitInstance();
	DECLARE_MESSAGE_MAP()
};
BEGIN_MESSAGE_MAP(CSearchEditApp, CWinApp)
END_MESSAGE_MAP()
CSearchEditApp theApp;

class CSearchEditDlg : public CDialog {
public:
	CSearchEditDlg(CWnd* pParent = NULL);	// standard constructor
protected:
	CEditSearch m_wndEdit;					 // search edit control
	CStaticLink	m_wndLink1;					 // static hyperlink
	CStaticLink	m_wndLink2;					 // ...
	HICON m_hIconLg;							 // large icon
	HICON m_hIconSm;							 // small icon
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
};
BEGIN_MESSAGE_MAP(CSearchEditDlg, CDialog)
END_MESSAGE_MAP()

BOOL CSearchEditApp::InitInstance()
{
//	SetRegistryKey(_T("MSJ"));
	CIniFile::Use(this, CIniFile::LocalDir);
	CSearchEditDlg().DoModal();
	return FALSE;
}

CSearchEditDlg::CSearchEditDlg(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_SRCHEDIT_DIALOG, pParent), m_wndEdit(_T("SearchEdit"))
{
	m_hIconLg = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_hIconSm = (HICON)::LoadImage(AfxGetResourceHandle(),
		MAKEINTRESOURCE(IDR_MAINFRAME),
		IMAGE_ICON,
		GetSystemMetrics(SM_CXSMICON),
		GetSystemMetrics(SM_CYSMICON),
		0);
}

BOOL CSearchEditDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	// set large/small icons
	SetIcon(m_hIconLg,TRUE);
	SetIcon(m_hIconSm,FALSE);

	// subclass static controls. URL is static text or 3rd arg
	m_wndLink1.SubclassDlgItem(IDC_MSJURL, this);
	m_wndLink2.SubclassDlgItem(IDC_PDURL,  this);

	// subclass edit search control and ive it focus
	m_wndEdit.SubclassDlgItem(IDC_EDIT1, this);
	m_wndEdit.SetFocus();

	return FALSE;
}
