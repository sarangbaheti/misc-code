////////////////////////////////////////////////////////////////
// Microsoft Systems Journal November 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#include <afxwin.h>
#include <afxcoll.h>
#include <atlbase.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

void usage()
{
	printf("\n");
	printf("Purpose: Load RGS registrar scripts into the registry\n");
	printf("Usage:   rgsrun [-u -q] files\n");
	printf("         -u = unregister\n");
	printf("         -q = quiet\n");
	printf("         Written 7-99 by Paul Dilascia for MSJ.\n");
	exit(-1);
}

/////////////////
// Instantiate IRegistrar
//
class CTRegistrar : public CComQIPtr<IRegistrar> {
public:
	CTRegistrar() {
		CoCreateInstance(CLSID_Registrar, NULL, CLSCTX_INPROC);
		ASSERT(p);
	}
};

//////////////////
// Console app entry point
//
int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0)) {
		fprintf(stderr, "Fatal Error: MFC initialization failed");
		return -1;
	}

	if (FAILED(CoInitialize(0))) {
		printf("Error initializing COM\n");
		(-1);

	} else {
		CTRegistrar spReg;
		BOOL unregister=0;
		BOOL quiet=0;
		BOOL any=0;
		for (int i=1; i<argc; i++) {
			if (argv[i][0]=='/' || argv[i][0]=='-') {
				switch (tolower(argv[i][1])) {
				case 'u':
					unregister=1;
					break;
				case 'q':
					quiet=1;
					break;
				default:
					usage();
					break;
				}
			} else {
				USES_CONVERSION;
				LPOLESTR lpo = T2OLE(argv[i]);
				HRESULT hr = unregister ?
					spReg->FileUnregister(lpo) :
					spReg->FileRegister(lpo);
				if (!quiet) {
					printf(FAILED(hr) ?
						"Error processing %s - ignored\n" : "%s loaded\n",
						argv[i]);
				}
				any = 1;
			}
		}
		if (!any)
			usage();
	}
	CoUninitialize();
	return 0;
}
