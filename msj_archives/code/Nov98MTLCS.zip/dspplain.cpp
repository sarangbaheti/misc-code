////    DspPlain.CPP - Display plaintext and handle caret placement
//
//      Demonstrates use of the ScriptString APIs
//
//      ScriptStringAnalyse          - Calls ScriptItemise, Shape, Place etc.
//      ScriptStringGetLogicalWidths - Returns logical widths for the entire line
//      ScriptStringXtoCP            - Pixel position to character index
//      ScriptStringCPtoX            - Character index to pixel position
//      ScriptString_pSize           - Gets points to SIZE structure for the line
//      ScriptStringOut              - Render line to device
//      ScriptStringFree             - All analyses must be freed


#include "precomp.hxx"
#include "global.h"






////    PaintPlainTextLine
//
//      Use the ScriptString APIs to analyse and display a line
//      as plain text.


void PaintPlainTextLine(
    HDC      hdc,               // In   Device
    int     *piY,               // In   Y position
    RECT    *prc,               // In   Clipping rectange
    int      iFirst,            // In   First character of line
    int      iLen,
    int      iLineHeight) {     // In   Height to advance per line, in pixels

    int      iX;
    HRESULT  hr;
    int      iBuf[200];
    int      iClipWidth;
    int      iTrailing;         // ScriptStringXtoCP result - offset to nearest cluster edge
    RECT     rc;
    int      iFrom;
    int      iTo;
    DWORD    dwFlags;
    int      i;

    SCRIPT_CONTROL         ScriptControl;
    SCRIPT_STATE           ScriptState;
    SCRIPT_STRING_ANALYSIS ssa;


    if (iLen) {

        // There's at least one character to display

        SelectObject(hdc, g_style[0].hf);       // Select plaintext font

        if (g_fRight) {

            iX = prc->right - 1;
            SetTextAlign(hdc, TA_RIGHT);

        } else {

            iX = prc->left;
            SetTextAlign(hdc, TA_LEFT);
        }


        dwFlags = g_dwSSAflags | SSA_GLYPHS;    // Require glyph generation for ScriptStringOut

        ScriptControl = g_ScriptControl;
        ScriptState   = g_ScriptState;

        if (ScriptState.uBidiLevel & 1) {       // ScriptStringAnalyse requires SSA_RTL for rtl reading order
            dwFlags |= SSA_RTL;
        }


        // Draw a line to indicate clipping position

        iClipWidth = prc->right - prc->left - 50;

        if (dwFlags & (SSA_FIT | SSA_CLIP)) {
            if (g_fRight) {
                MoveToEx(hdc, iX - iClipWidth, *piY, NULL);
                LineTo(hdc,   iX - iClipWidth, *piY+iLineHeight);
            } else {
                MoveToEx(hdc, iX + iClipWidth, *piY, NULL);
                LineTo(hdc,   iX + iClipWidth, *piY+iLineHeight);
            }
        }


        // Analyse the string.
        //
        // ScriptStringAnalyse calls the ScriptItemize, ScriptShape,
        // ScriptPlace and ScriptBreak APIs and returns a pointer to a block
        // of memory containing all these results.

        hr = ScriptStringAnalyse(
                hdc,
                g_wcBuf + iFirst,
                iLen, 0, -1,
                dwFlags,
                iClipWidth,
                g_fNullState ? NULL : &ScriptControl,
                g_fNullState ? NULL : &ScriptState,
                NULL,
                NULL, NULL, &ssa);

        if (    SUCCEEDED(hr)
            &&  g_fOverrideDx
            &&  !(dwFlags & SSA_FIT)) {

            // Demonstrate use of pidx parameter by widening every character by 25%.
            // This demo doesn't work with SSA_FIT justification, so we don't even try.

            ScriptStringGetLogicalWidths(ssa, iBuf);

            for (i=0; i<iLen; i++) {
                iBuf[i] = iBuf[i] * 125 / 100;
            }

            // Reanalyse with the updated widths

            ScriptStringFree(&ssa);
            hr = ScriptStringAnalyse(
                    hdc,
                    g_wcBuf + iFirst,
                    iLen, 0, -1,
                    dwFlags,
                    iClipWidth,
                    g_fNullState ? NULL : &ScriptControl,
                    g_fNullState ? NULL : &ScriptState,
                    iBuf,
                    NULL, NULL, &ssa);
        }


        if (SUCCEEDED(hr)) {

            // Check whether mouse clicks in this line are waiting to be processed

            if (g_fMouseDown  &&  g_iMouseDownY > *piY  &&  g_iMouseDownY < *piY+iLineHeight) {

                // Record char pos at left button down

                ScriptStringXtoCP(ssa, g_iMouseDownX-prc->left, &g_iFrom, &iTrailing);
                g_iFrom += iTrailing + iFirst; // Snap to closest cluster edge and make relative to buffer
                g_fMouseDown = FALSE;
            }


            if (g_fMouseUp  &&  g_iMouseUpY > *piY  &&  g_iMouseUpY < *piY+iLineHeight) {

                // Complete selection processing

                ScriptStringXtoCP(ssa, g_iMouseUpX-prc->left, &g_iTo, &iTrailing);
                g_iTo += iTrailing + iFirst; // Snap to closest cluster edge and make relative to buffer

                // Caret is where mouse was raised

                g_iCurChar = g_iTo;
                g_fMouseUp = FALSE;     // Signal that the mouse up is processed
                g_fUpdateCaret = TRUE;  // Request caret update
                g_iCaretSection = CARET_SECTION_PLAINTEXT;    // in plaintext section
            }


            // Display this line

            rc        = *prc;          // Clip to line height (important for selection marking)
            rc.top    = *piY;
            rc.bottom = *piY + iLineHeight;


            // Support selection range specified in either direction

            if (g_iFrom <= g_iTo) {
                iFrom = g_iFrom - iFirst;
                iTo   = g_iTo   - iFirst;
            } else {
                iFrom = g_iTo   - iFirst;
                iTo   = g_iFrom - iFirst;
            }


            hr = ScriptStringOut(
                ssa,
                prc->left,
               *piY,
                ETO_CLIPPED,
               &rc,
                iFrom,   // ScriptStringOut will ignore From/To that are outside this line
                iTo,
                FALSE);


            // Now position the caret if it has moved, either because of a mouse click
            // detected above, or because of an editing function such as a cursor key.

            if (    g_fUpdateCaret
                &&  g_iCaretSection == CARET_SECTION_PLAINTEXT
                &&  g_iCurChar >= iFirst
                &&  g_iCurChar <= iFirst+iLen) {

                // Display caret at coordinate corresponding to g_iCurChar

                g_fUpdateCaret = FALSE;
                if (g_iCurChar < iFirst + iLen) {

                    ScriptStringCPtoX(ssa, g_iCurChar - iFirst, FALSE, &g_iCaretX);

                } else {

                    // represent end of line position by placing caret at right edge
                    g_iCaretX = ScriptString_pSize(ssa)->cx;
                }

                ResetCaret(prc->left + g_iCaretX, *piY, iLineHeight);
            }

            ScriptStringFree(&ssa);
        }

    } else {

        // Although the line is empty we may still need to display the caret

        if (    g_fUpdateCaret
            &&  g_iCaretSection == CARET_SECTION_PLAINTEXT
            &&  g_iCurChar == iFirst) {

            g_fUpdateCaret = FALSE;
            ResetCaret(prc->left, *piY, iLineHeight);
        }
    }

    *piY += iLineHeight;
}






////    PaintPlainText - Demonstrate ScriptString APIs
//
//


void PaintPlainText(
    HDC   hdc,
    int  *piY,
    RECT *prc,
    int   iLineHeight) {

    int   icpLineStart;     // First character of line
    int   icpLineEnd;       // End of line (end of buffer or index of CR character)

    icpLineStart = 0;
    SelectObject(hdc, g_style[0].hf);

    // Display line by line

    while (icpLineStart < g_iTextLen) {

        // Find end of line or end of buffer

        icpLineEnd = icpLineStart;
        while (icpLineEnd < g_iTextLen  &&  g_wcBuf[icpLineEnd] != 0x0D) {
            icpLineEnd++;
        }

        PaintPlainTextLine(
            hdc,
            piY,
            prc,
            icpLineStart,
            icpLineEnd-icpLineStart,
            iLineHeight);


        // Advance to next line

        if (icpLineEnd < g_iTextLen) {
            icpLineEnd++;
        }
        if (icpLineEnd < g_iTextLen  &&  g_wcBuf[icpLineEnd] == 0x0A) {
            icpLineEnd++;
        }
        icpLineStart = icpLineEnd;
    }
}
