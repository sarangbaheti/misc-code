CSSamp - Complex script sample application


This sample application allows you to try out the complex script support
APIs in Uniscribe.

The sample source files demonstrate how to code formatted text display and
editing functionality.

Before you can run the sample program, you must run the included self
extracting 'usp.exe' file and place the enclosed usp10.dll on your path, or
in the same directory as the sample executable.

If you do not already have recent versions of the Microsoft Sans Serif and
Tahoma fonts, you should also run the self extracting 'fonts.exe' to obtain
pre-release versions of those we plan to ship in NT 5 and Office 2000.




UNISCRIBE (USP10.DLL)

USP10.DLL, USP10.H and USP10.HTML represent a snapshot in the evolution
of the Uniscribe interface.

Although we have no plans to make significant changes to the interface, we
will do so if we find serious compatability issues or design or coding errors.

An early version of Uniscribe has already shipped with complex script IE4,
and a more recent version ships with the IE4 that is included in Arabic and
Hebrew Windows 98.
In all those platforms Uniscribe is named as USP.DLL.

The version used in this sample is named USP10.DLL - this is an early
snapshot of the file USP10.DLL that we plan to ship with NT5 and Office9.

Before you use USP10.DLL, you must read and agree to the conditions of
use presented during installation.

You may send reports of bugs in Uniscribe to 'csbugnt@microsoft.com'.




FONTS PROVIDED

The included self extracting file 'fonts.exe' includes early versions of the
Microsoft Sans Serif and Tahoma fonts.

Both of these fonts include Arabic, Hebrew and Thai characters. Both are
designed to Western line spacing metrics and so will work well in software
designed for Western text.

Before you may use these fonts, you must read and agree to the conditions of
use presented during installation.




SAMPLE PROGRAM SOURCE

The most important sample source code is in the files DSPFORMT.CPP and
DSPPLAIN.CPP.


DSPFORMT.CPP displays formatted text. It demonstrates use of the following
formatted string APIs:

    ScriptItemize           - Break string on script and direction boundaries
    ScriptLayout            - Bidi embedding level interpreter
    ScriptShape             - Unicode to glyph translation
    ScriptPlace             - Width and position generation
    ScriptTextOut           - Render item to device
    ScriptXtoCP             - Pixel position to character index
    ScriptCPtoX             - Character index to pixel position
    ScriptGetLogicalWidths  - Generate widths in character order
    ScriptBreak             - Get line breaking flags


DSPPLAIN.CPP displays plaintext. It demonstrates use of the following
plaintext APIs:

    ScriptStringAnalyse          - Calls ScriptItemise, Shape, Place etc.
    ScriptStringGetLogicalWidths - Returns logical widths for the entire line
    ScriptStringXtoCP            - Pixel position to character index
    ScriptStringCPtoX            - Character index to pixel position
    ScriptString_pSize           - Gets points to SIZE structure for the line
    ScriptStringOut              - Render line to device
    ScriptStringFree             - All analyses must be freed


The remaining files implement the samples settings dialog box, and the
representation of text. Please do not treat them as examples of good design
or programming style - they are not. The files are as follows:

dsplogcl.cpp - Displays the text in logical order without honoring ABC widths
initial.txt  - Can be edited in notepad, must be saved as Unicode
cssamp.cpp   - Main program: initialisation and message loop
Edit.cpp     - Handles WM_CHAR, WM_KEYDOWN messages
TextWnd.cpp  - Window procedure for the text display in the right hand side of the sample window
Settings.cpp - Supports the settings control panel.
Debug.cpp    - My idiosyncratic debug macro support
global.h     - Global variables
Precomp.hxx  - Precompiled header
resource.h   - Resource ids
sources      - List of source files in NT5 DDK build environment format
Style.cpp    - Handles representation of style runs for formatted text
Text.cpp     - Stores and manipulates the text representation
cssamp.rc    - Settings dialog layout
cssamp.mak   - Makefile: nmake /f cssamp.mak




NO SUPPORT FOR INDIAN KEYBOARD. (Although Indian text displays fine).

This sample uses an ANSI window so it will run on Win 9x and on NT. WM_CHAR
messages arrive in the ANSI codepage associated with the current keyboard.
I have not allowed for languages that have no default ANSI codepage, so you
will be unable to use the Indian keyboard on NT. Please refer back to the
MSJ article for more details on writing cross platform apps.

If you have NT 5 beta 2 and you wish to view and edit Indian text, one
possibility is to add some to initial.txt using notepad and recompile.




NO SELECTION HIGHLIGHT IN FORMATTED TEXT. Not implemented, sorry.




BEST WISHES from the NT complex scripts team.

