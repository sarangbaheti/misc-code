////    precomp.hxx
//

#include <windows.h>
#include <commdlg.h>

#include "usp10.h"

#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <string.h>

#include "resource.h"

