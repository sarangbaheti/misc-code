////    TEXTWND.CPP
//
//              Maintains the text display panel



#include "precomp.hxx"
#include "global.h"





////    InvalidateText - Force redisplay
//
//

void InvalidateText() {
    RECT rc;
    rc.left   = g_iSettingsWidth;
    rc.top    = 0;
    rc.right  = 10000;
    rc.bottom = 10000;
    InvalidateRect(g_hTextWnd, &rc, TRUE);
}






////    Header - draw a simple header for each text section
//
//      Used to distinguish logical, plaintext and formatted text sections of
//      text window.


void Header(HDC hdc, char* str, RECT *prc, int *piY) {

    HFONT hf, hfold;


    if (*piY > prc->top) {

        // Separate from previous output

        MoveToEx(hdc, prc->left,  *piY+20, NULL);
        LineTo  (hdc, prc->right, *piY+20);
        MoveToEx(hdc, prc->left,  *piY+21, NULL);
        LineTo  (hdc, prc->right, *piY+21);
        *piY += 30;
    }


    hf = CreateFont(16, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, "Arial");
    hfold = (HFONT) SelectObject(hdc, hf);
    ExtTextOut(hdc, prc->left, *piY, 0, prc, str, strlen(str), NULL);

    *piY += 20;

    SelectObject(hdc, hfold);
    DeleteObject(hf);
}






////    ResetCaret - used during paint by each DSP*.CPP
//
//


void ResetCaret(int iX, int iY, int iHeight) {

    g_iCaretX = iX;
    g_iCaretY = iY;

    if (g_iCaretHeight != iHeight) {
        g_iCaretHeight = iHeight;
        HideCaret(g_hTextWnd);
        DestroyCaret();
        CreateCaret(g_hTextWnd, NULL, 0, g_iCaretHeight);
        SetCaretPos(g_iCaretX, g_iCaretY);
        ShowCaret(g_hTextWnd);
    } else {
        SetCaretPos(g_iCaretX, g_iCaretY);
    }

}






////    Paint - redraw part or all of client area
//
//


void Paint(
    HWND         hWnd) {

    PAINTSTRUCT  ps;
    HDC          hdc;
    int          iPos;
    int          iY;
    int          iLineHeight;
    RECT         rc;

    hdc = BeginPaint(hWnd, &ps);

    // Remove the settings dialog from the repaint rectangle


        if (ps.fErase) {

        // Clear to the right of the settings dialog
        rc = ps.rcPaint;
        if (rc.left < g_iSettingsWidth) {
            rc.left = g_iSettingsWidth;
        }
                FillRect(ps.hdc, &rc, (HBRUSH) GetStockObject(WHITE_BRUSH));

        // Also clear below the dialog
        rc = ps.rcPaint;
        if (rc.right > g_iSettingsWidth) {
            rc.right = g_iSettingsWidth;
        }
        if (rc.top < g_iSettingsHeight) {
            rc.top = g_iSettingsHeight;
        }
                FillRect(ps.hdc, &rc, (HBRUSH) GetStockObject(WHITE_BRUSH));
    }


    GetClientRect(hWnd, &rc);
    rc.right  -= rc.left + 20;  rc.left = g_iSettingsWidth+10;
    rc.bottom -= rc.top  + 16;  rc.top  = 8;
    iPos = 0;
    iLineHeight = 40;
    iY = rc.top;


    if (g_fShowLogical) {
        Header(hdc, "Logical characters (ScriptGetCmap, ExtTextOut(ETO_GLYPHINDEX))", &rc, &iY);
        PaintLogical(hdc, &iY, &rc, iLineHeight);
    }


    if (g_fShowPlainText) {
        Header(hdc, "Plain text (ScriptStringAnalyse, ScriptStringOut, ScriptStringFree)", &rc, &iY);
        PaintPlainText(hdc, &iY, &rc, iLineHeight);
    }


    if (g_fShowFancyText) {
        Header(hdc, "Formatted text (ScriptItemize, ScriptLayout, ScriptShape, ScriptPlace, ScriptTextOut)", &rc, &iY);
        PaintFormattedText(hdc, &iY, &rc, iLineHeight);
    }


    EndPaint(hWnd, &ps);
}






////    WndProc - Main window message handler and dispatcher
//


LRESULT CALLBACK TextWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {

    HDC hdc;

    switch (message) {

        case WM_CREATE:
            hdc = GetDC(hWnd);
            g_iLogPixelsY = GetDeviceCaps(hdc, LOGPIXELSY);
            ReleaseDC(hWnd, hdc);
            break;


        case WM_ERASEBKGND:
            //EraseBackground((HDC)wParam);
                        return 0;       // Leave Paint to erase the background


        case WM_CHAR:
            EditChar(LOWORD(wParam));
            break;


        case WM_KEYDOWN:
            EditKeyDown(LOWORD(wParam));
            break;


        case WM_LBUTTONDOWN:
            g_iMouseDownX = LOWORD(lParam);  // horizontal position of cursor
            g_iMouseDownY = HIWORD(lParam);  // vertical position of cursor
            g_fMouseDown  = TRUE;
            SetFocus(hWnd);
            break;

        case WM_MOUSEMOVE:
            // Treat movement like lbuttonup while lbutton is down,
            // so the selection tracks the cursor movement.
            if (wParam & MK_LBUTTON) {
                g_iMouseUpX = LOWORD(lParam);  // horizontal position of cursor
                g_iMouseUpY = HIWORD(lParam);  // vertical position of cursor
                g_fMouseUp = TRUE;
                InvalidateText();
                SetActiveWindow(hWnd);
            }
            break;


        case WM_LBUTTONUP:
            g_iMouseUpX = LOWORD(lParam);  // horizontal position of cursor
            g_iMouseUpY = HIWORD(lParam);  // vertical position of cursor
            g_fMouseUp = TRUE;
            InvalidateText();
            SetActiveWindow(hWnd);
            break;


        case WM_SETFOCUS:
            CreateCaret(hWnd, NULL, 0, g_iCaretHeight);
            SetCaretPos(g_iCaretX, g_iCaretY);
            ShowCaret(hWnd);
            break;


        case WM_KILLFOCUS:
            DestroyCaret();
            break;


        case WM_GETMINMAXINFO:

            // Don't let text window size drop too low

            ((LPMINMAXINFO)lParam)->ptMinTrackSize.x = g_iMinWidth;
            ((LPMINMAXINFO)lParam)->ptMinTrackSize.y = g_iMinHeight;
            return 0;


        case WM_PAINT:
            Paint(hWnd);
            break;

        case WM_DESTROY:
            DestroyWindow(g_hSettingsDlg);
            PostQuitMessage(0);
                        return 0;

        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
    }

    return 0;
}






////    CreateTextWindow - create window class and window
//


HWND CreateTextWindow() {

    WNDCLASS wc;
    HWND     hWnd;



    // Define Text edit window class

    wc.style         = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc   = TextWndProc;
    wc.cbClsExtra    = 0;
    wc.cbWndExtra    = 0;
    wc.hInstance     = g_hInstance;
    wc.hIcon         = LoadIcon (g_hInstance, APPNAME);
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    wc.lpszMenuName  = APPNAME;
    wc.lpszClassName = APPNAME;

    if (!RegisterClass(&wc)) {
        return NULL;
    }

    hWnd  = CreateWindow(
        APPNAME, APPTITLE,
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, 0,
        CW_USEDEFAULT, 0,
        NULL, NULL,
        g_hInstance,
        NULL);

    return hWnd;
}
