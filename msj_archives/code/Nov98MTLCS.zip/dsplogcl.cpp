////    DspLogcl - Display logical text
//
//      Shows logical characters and selection range in backing store order and fixed width.


#include "precomp.hxx"
#include "global.h"






////    DottedLine
//
//      Draws a horizontal or a vertical dotted line
//
//      Not the best algorithm.


void DottedLine(HDC hdc, int x, int y, int dx, int dy) {

    SetPixel(hdc, x, y, 0);

    if (dx) {

        // Horizontal line

        while (dx > 2) {
            x += 3;
            SetPixel(hdc, x, y, 0);
            dx -= 3;
        }
        x += dx;
        SetPixel(hdc, x, y, 0);

    } else {

        // Vertical line

        while (dy > 2) {
            y += 3;
            SetPixel(hdc, x, y, 0);
            dy -= 3;
        }
        y += dy;
        SetPixel(hdc, x, y, 0);
    }
}






////    PaintLogical - show characters in logical sequence
//
//      Display each glyph separately - override the default advance width
//      processing to defeat any overlapping or combining action that the
//      font performs with it's default ABC width.
//
//      To achieve this, we call ScriptGetGlyphABCWidth to obtain the
//      leading side bearing (A), the black box width (B) and the trailing
//      side bearing (C).
//
//      Since we can control only the advance width per glyph, we have to
//      calulate suitable advance widths to override the affect of the
//      ABC values in the font.
//
//      You should never normally need to call ScriptGetGlyphABCWidth.


void PaintLogical(
    HDC   hdc,
    int  *piY,
    RECT *prc,
    int   iLineHeight) {

    const int MAXBUF     = 100;
    const int LINEHEIGHT = 40;
    const int CELLGAP    = 4;      // Pixels between adjacent glyphs

    int   icpLineStart;     // First character of line
    int   icpLineEnd;       // End of line (end of buffer or index of CR character)
    int   icp;
    int   iLen;
    WORD  wGlyphBuf[MAXBUF];
    int   idx[MAXBUF];      // Force widths so all characters show
    ABC   abc;
    int   iTotX;
    int   iFrom;            // Selection range
    int   iTo;


    SCRIPT_CACHE sc;
    HFONT        hf, hfold;
    HRESULT      hr;

    icpLineStart = 0;

    sc = NULL;
    hf = CreateFont(24, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, "Microsoft Sans Serif");
    hfold = (HFONT) SelectObject(hdc, hf);


    // Display line by line

    while (icpLineStart < g_iTextLen) {

        // Find end of line or end of buffer

        icpLineEnd = icpLineStart;
        while (icpLineEnd < g_iTextLen  &&  g_wcBuf[icpLineEnd] != 0x0D) {
            icpLineEnd++;
        }

        // Display this line

        if (icpLineEnd - icpLineStart > MAXBUF) {
            iLen = MAXBUF;
        } else {
            iLen = icpLineEnd - icpLineStart;
        }

        hr = ScriptGetCMap(hdc, &sc, g_wcBuf+icpLineStart, iLen, 0, wGlyphBuf);
        if (SUCCEEDED(hr))
        {

            // Display each glyphs balack box next to the previous. Override the
            // default ABC behaviour.

            idx[0] = 0;

            for (icp=0; icp<iLen; icp++) {

                ScriptGetGlyphABCWidth(hdc, &sc, wGlyphBuf[icp], &abc);

                // Glyph black box width is abc.abcB
                // We'd like the glyph to appear 2 pixels to the right of the
                // previous glyph.
                //
                // The default placement of left edge is abc.abcA.
                //
                // Therefore we need to shift this character to the right by
                // 2 - abc.abcA to get it positioned correctly. We do this by
                // updating the advance width for the previous character.

                if (icp) idx[icp-1] += CELLGAP - abc.abcA;

                // Now adjust the advance width for this character to take us to
                // the right edge of it's black box.

                idx[icp] = abc.abcB + abc.abcA;
            }


            ExtTextOutW(hdc, prc->left+2, *piY+2, ETO_CLIPPED | ETO_GLYPH_INDEX, prc, wGlyphBuf, iLen, idx);


            // Mark the cells to make the characters stand out clearly

            MoveToEx(hdc, prc->left, *piY /*+ 24*/, NULL);
            LineTo(hdc,   prc->left, *piY + 30);

            iTotX = 0;

            for (icp=0; icp<iLen; icp++){

                ScriptGetGlyphABCWidth(hdc, &sc, wGlyphBuf[icp], &abc);

                iTotX += abc.abcB + CELLGAP;
                idx[icp] = iTotX;   // Record cell position for mouse hit testing

                DottedLine(hdc, prc->left + iTotX, *piY, 0, 30);
            }
            MoveToEx(hdc, prc->left + iTotX, *piY /*+ 24*/, NULL);
            LineTo(hdc,   prc->left + iTotX, *piY + 30);

            MoveToEx(hdc, prc->left, *piY, NULL);
            LineTo(hdc,   prc->left + iTotX, *piY);
            MoveToEx(hdc, prc->left, *piY + 30, NULL);
            LineTo(hdc,   prc->left + iTotX, *piY + 30);



            // Check whether mouse clicks in this line are waiting to be processed

            if (g_fMouseDown  &&  g_iMouseDownY > *piY  &&  g_iMouseDownY < *piY+LINEHEIGHT) {

                // Record char pos at left button down

                icp = 0;
                while (    icp < iLen
                       &&  g_iMouseDownX > prc->left + idx[icp]) {
                    icp++;
                }
                g_iFrom = icp + icpLineStart;

                if (g_iFrom < icpLineStart) {
                    g_iFrom = icpLineStart;
                }
                if (g_iFrom > icpLineEnd) {
                    g_iFrom = icpLineEnd;
                }
                g_fMouseDown = FALSE;
            }


            if (g_fMouseUp  &&  g_iMouseUpY > *piY  &&  g_iMouseUpY < *piY+LINEHEIGHT) {

                // Complete selection processing

                icp = 0;
                while (    icp < iLen
                       &&  g_iMouseUpX > prc->left + idx[icp]) {
                    icp++;
                }
                g_iTo = icp + icpLineStart;

                if (g_iTo < icpLineStart) {
                    g_iTo = icpLineStart;
                }
                if (g_iTo > icpLineEnd) {
                    g_iTo = icpLineEnd;
                }

                // Caret is where mouse was raised

                g_iCurChar = g_iTo;
                g_iCaretSection = CARET_SECTION_LOGICAL;  // Show caret in logical text
                g_fUpdateCaret = TRUE;

                g_fMouseUp = FALSE;     // Signal that the mouse up is processed

            }

            if (    g_fUpdateCaret
                &&  g_iCurChar >= icpLineStart
                &&  g_iCurChar <= icpLineEnd
                &&  g_iCaretSection == CARET_SECTION_LOGICAL) {

                g_fUpdateCaret = FALSE;
                if (g_iCurChar <= icpLineStart) {
                    ResetCaret(prc->left, *piY, LINEHEIGHT);
                } else {
                    ResetCaret(prc->left + idx[g_iCurChar - icpLineStart - 1], *piY, LINEHEIGHT);
                }
            }


            // Mark any selected range by drawing a thick line underneath it

            if (g_iFrom <= g_iTo) {
                iFrom = g_iFrom;
                iTo   = g_iTo;
            } else {
                iFrom = g_iTo;
                iTo   = g_iFrom;
            }

            if (iFrom < icpLineStart) {
                iFrom = icpLineStart;
            }
            if (iTo > icpLineEnd) {
                iTo = icpLineEnd;
            }

            if (iFrom < icpLineEnd  &&  iTo > icpLineStart) {

                // Convert iFrom and iTo to pixel positions

                iFrom -= icpLineStart;
                if (iFrom) {
                    iFrom = idx[iFrom-1];
                }
                iTo -= icpLineStart;
                if (iTo) {
                    iTo = idx[iTo-1];
                }

                MoveToEx(hdc, prc->left + iFrom, *piY + 32, NULL);
                LineTo(  hdc, prc->left + iTo+1, *piY + 32);
                MoveToEx(hdc, prc->left + iFrom, *piY + 33, NULL);
                LineTo(  hdc, prc->left + iTo+1, *piY + 33);
            }
        }
        else {
            // ScriptGetCMap failed - therefore this is not a glyphable font.
            // This could indicate
            //      A printer device font
            //      We're running on FE Win95 which cannot handle glyph indices
            //
            // For the sample app, we know we are using a glyphable Truetype font
            // on a screen DC, so it must mean the sample is running on a Far
            // East version of Windows 95.
            // Theoretically we could go to the trouble of calling
            // WideCharToMultiByte and using the 'A' char interfaces to
            // implement DspLogcl.
            // However this is only a sample program - DspPlain and DspFormt
            // work correctly, but there's no advantage in implementing
            // DspLogcl so well.
            // Display an apology.

            ExtTextOutA(hdc, prc->left+2, *piY+2, ETO_CLIPPED, prc, "Sorry, no logical text display on Far East Windows 95.", 54, NULL);
            icpLineEnd = g_iTextLen;  // Hack to stop display of subsequent lines
        }

        // Advance to next line

        if (icpLineEnd < g_iTextLen) {
            icpLineEnd++;
        }
        if (icpLineEnd < g_iTextLen  &&  g_wcBuf[icpLineEnd] == 0x0A) {
            icpLineEnd++;
        }
        icpLineStart = icpLineEnd;

        *piY += LINEHEIGHT;
    }

    ScriptFreeCache(&sc);

    SelectObject(hdc, hfold);
    DeleteObject(hf);


    UNREFERENCED_PARAMETER(iLineHeight);
}






