//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by boids2.rc
//
#define IDI_MAIN_ICON                   101
#define IDR_MAIN_MENU                   102
#define IDR_MAIN_ACCEL                  113
#define IDD_ABOUT                       114
#define IDD_CHANGE_MODE                 115
#define IDD_CHANGE_DRIVER               116
#define IDD_CHANGE_DEVICE               117
#define IDC_MODES                       1001
#define IDC_DRIVERS                     1003
#define IDC_DEVICES                     1004
#define IDM_EXIT                        40001
#define IDM_ABOUT                       40002
#define ID_HELP_ABOUT                   40003
#define IDM_CHANGE_MODES                40004
#define IDM_CHANGE_DRIVERS              40005
#define IDM_CHANGE_DEVICES              40009
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        119
#define _APS_NEXT_COMMAND_VALUE         40010
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
