/******************************************************************************
Module name: QueryCancelAutoPlay.cpp
Written by: Jeffrey Richter
******************************************************************************/


#define STRICT
#include <Windows.h>
#include <WindowsX.h>
#include "Resource.h"


///////////////////////////////////////////////////////////////////////////////


BOOL WINAPI DlgProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {

   BOOL fRet = TRUE;
	switch (uMsg) {

      case WM_INITDIALOG:
         fRet = TRUE; 
         break;

      case WM_COMMAND:
         if (GET_WM_COMMAND_ID(wParam, lParam) == IDCANCEL)
            EndDialog(hwnd, 0);
         break;

      default:
         fRet = FALSE;
         break;
	}

   static UINT uMsgQueryCancelAutoPlay = 
      RegisterWindowMessage("QueryCancelAutoPlay");

   if (uMsg == uMsgQueryCancelAutoPlay) {
      int n = MessageBox(hwnd, "Do you wish to cancel AutoPlay?", NULL, MB_YESNO);
      SetDlgMsgResult(hwnd, uMsg, (n == IDYES) ? 1 : 0);
      fRet = TRUE;
   }
   
   return(fRet);
}


///////////////////////////////////////////////////////////////////////////////


int WINAPI WinMain(HINSTANCE hinstExe, HINSTANCE, LPSTR, int) {
   DialogBox(hinstExe, MAKEINTRESOURCE(IDD_QUERYCANCELAUTOPLAY), 
      NULL, DlgProc);
	return(0);
}


///////////////////////////////// End Of File /////////////////////////////////
