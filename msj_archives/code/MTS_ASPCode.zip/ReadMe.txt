This application requires setup.

Refer to the file 'MarketSetup.htm' in the \Setup directory.