
// this is an approximation of the class factory returned by
// OLEAUT32.DLL's DllGetClassObject({00020424-0000-0000-C000-000000000046})

struct PSTypeLibFactoryBuffer : IPSFactoryBuffer, 
                                CComObjectRootEx<CComMultiThreadModel>
{
BEGIN_COM_MAP(PSTypeLibFactoryBuffer)
    COM_INTERFACE_ENTRY(IPSFactoryBuffer)
END_COM_MAP()
        
    STDMETHODIMP CreateProxy(IUnknown *pUnkOuter, REFIID riid, 
                             IRpcProxyBuffer **ppProxy, void **ppv)
    {
        *ppv = *ppProxy = 0;
// grab the type description of this interface from the registry
        ITypeLib *ptl = 0;
        HRESULT hr = LoadCachedTypeLibFromIID(riid, &ptl);
        if (SUCCEEDED(hr))
        {
            ITypeInfo *pti = 0;
            hr = ptl->GetTypeInfoOfGuid(riid, &pti);
            if (SUCCEEDED(hr))
            {
// ask RPCRT4 to cook up an /Oicf proxy from the ITypeInfo
                hr = CreateProxyFromTypeInfo(pti, pUnkOuter, riid, 
                                             ppProxy, ppv);
                pti->Release();
            }
            ptl->Release();
        }
        return hr;
    }
    
    STDMETHODIMP CreateStub( 
        REFIID riid,
        IUnknown *pUnkServer,
        IRpcStubBuffer **ppStub)
    {
        *ppStub = 0;
// grab the type description of this interface from the registry
        ITypeLib *ptl = 0;
        HRESULT hr = LoadCachedTypeLibFromIID(riid, &ptl);
        if (SUCCEEDED(hr))
        {
            ITypeInfo *pti = 0;
            hr = ptl->GetTypeInfoOfGuid(riid, &pti);
            if (SUCCEEDED(hr))
            {
// ask RPCRT4 to cook up an /Oicf stub from the ITypeInfo
                hr = CreateStubFromTypeInfo(pti, riid, pUnkServer, ppStub);
                pti->Release();
            }
            ptl->Release();
        }
        return hr;
    }
};

