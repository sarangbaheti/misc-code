/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Apr 02 17:10:58 1999
 */
/* Compiler settings for .\MethodTimeHook.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __MethodTimeHook_h__
#define __MethodTimeHook_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ILoader_FWD_DEFINED__
#define __ILoader_FWD_DEFINED__
typedef interface ILoader ILoader;
#endif 	/* __ILoader_FWD_DEFINED__ */


#ifndef __Loader_FWD_DEFINED__
#define __Loader_FWD_DEFINED__

#ifdef __cplusplus
typedef class Loader Loader;
#else
typedef struct Loader Loader;
#endif /* __cplusplus */

#endif 	/* __Loader_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ILoader_INTERFACE_DEFINED__
#define __ILoader_INTERFACE_DEFINED__

/* interface ILoader */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_ILoader;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("233108A2-E3CD-11D2-8117-00E09801FDBE")
    ILoader : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE GetAverageMethodTime( 
            /* [retval][out] */ long __RPC_FAR *pnAvg) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ILoaderVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ILoader __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ILoader __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ILoader __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetAverageMethodTime )( 
            ILoader __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pnAvg);
        
        END_INTERFACE
    } ILoaderVtbl;

    interface ILoader
    {
        CONST_VTBL struct ILoaderVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ILoader_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ILoader_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ILoader_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ILoader_GetAverageMethodTime(This,pnAvg)	\
    (This)->lpVtbl -> GetAverageMethodTime(This,pnAvg)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE ILoader_GetAverageMethodTime_Proxy( 
    ILoader __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pnAvg);


void __RPC_STUB ILoader_GetAverageMethodTime_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ILoader_INTERFACE_DEFINED__ */



#ifndef __METHODTIMEHOOKLib_LIBRARY_DEFINED__
#define __METHODTIMEHOOKLib_LIBRARY_DEFINED__

/* library METHODTIMEHOOKLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_METHODTIMEHOOKLib;

EXTERN_C const CLSID CLSID_Loader;

#ifdef __cplusplus

class DECLSPEC_UUID("233108A3-E3CD-11D2-8117-00E09801FDBE")
Loader;
#endif
#endif /* __METHODTIMEHOOKLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
