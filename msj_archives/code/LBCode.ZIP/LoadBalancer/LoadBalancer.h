/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Apr 02 17:19:10 1999
 */
/* Compiler settings for .\LoadBalancer.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __LoadBalancer_h__
#define __LoadBalancer_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IAdmin_FWD_DEFINED__
#define __IAdmin_FWD_DEFINED__
typedef interface IAdmin IAdmin;
#endif 	/* __IAdmin_FWD_DEFINED__ */


#ifndef __Admin_FWD_DEFINED__
#define __Admin_FWD_DEFINED__

#ifdef __cplusplus
typedef class Admin Admin;
#else
typedef struct Admin Admin;
#endif /* __cplusplus */

#endif 	/* __Admin_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IAdmin_INTERFACE_DEFINED__
#define __IAdmin_INTERFACE_DEFINED__

/* interface IAdmin */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IAdmin;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("5E7F74C5-E165-11D2-B72C-00A0CC212296")
    IAdmin : public IUnknown
    {
    public:
    };
    
#else 	/* C style interface */

    typedef struct IAdminVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IAdmin __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IAdmin __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IAdmin __RPC_FAR * This);
        
        END_INTERFACE
    } IAdminVtbl;

    interface IAdmin
    {
        CONST_VTBL struct IAdminVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IAdmin_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IAdmin_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IAdmin_Release(This)	\
    (This)->lpVtbl -> Release(This)


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IAdmin_INTERFACE_DEFINED__ */



#ifndef __LOADBALANCERLib_LIBRARY_DEFINED__
#define __LOADBALANCERLib_LIBRARY_DEFINED__

/* library LOADBALANCERLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_LOADBALANCERLib;

EXTERN_C const CLSID CLSID_Admin;

#ifdef __cplusplus

class DECLSPEC_UUID("5E7F74C6-E165-11D2-B72C-00A0CC212296")
Admin;
#endif
#endif /* __LOADBALANCERLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
