///////////////////////////////////////////////////////////////////////
//
//  Resource.h - Copyright 1999, Tim Ewald / DevelopMentor
//  

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LoadBalancingAlgorithms.rc
//
#define IDS_PROJNAME                    100
#define IDR_LOADBALANCINGALGORITHMS     101
#define IDR_RANDOM                      102
#define IDR_ROUNDROBIN                  103
#define IDR_METHODTIMING                104
#define IDR_CPULOAD                     105

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
