///////////////////////////////////////////////////////////////////////
//
//  LoadBalancedCategory.h - Copyright 1999, Tim Ewald / DevelopMentor
//  

// CATID_LoadBalanced

// {9FDC5DE0-E180-11d2-B72C-00A0CC212296}
DEFINE_GUID(CATID_LoadBalancedClasses, 0x9fdc5de0, 0xe180, 0x11d2, 0xb7, 0x2c, 0x0, 0xa0, 0xcc, 0x21, 0x22, 0x96);

// {9FDC5DE1-E180-11d2-B72C-00A0CC212296}
DEFINE_GUID(CATID_LoadBalancingAlgorithms, 0x9fdc5de1, 0xe180, 0x11d2, 0xb7, 0x2c, 0x0, 0xa0, 0xcc, 0x21, 0x22, 0x96);


