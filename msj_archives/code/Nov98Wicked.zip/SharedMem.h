#include <afxole.h>
#include <afxmt.h>

class CSharedMemory
{
public:
	CSharedMemory ();
	CSharedMemory (UINT nSize, LPCTSTR pszName = NULL);
	virtual ~CSharedMemory ();

	BOOL Create (UINT nSize, LPCTSTR pszName = NULL);
	BOOL Delete ();
	CString GetName ();
	UINT GetSize ();
	BOOL Write (LPCVOID pBuffer, DWORD dwBytesToWrite,
		DWORD* pdwBytesWritten, DWORD dwOffset);
	BOOL Read (LPVOID pBuffer, DWORD dwBytesToRead, DWORD* pdwBytesRead,
		DWORD dwOffset);
	BOOL Lock ();
	BOOL Unlock ();
	BOOL MeFirst ();

	void* p;			// Address of memory block

protected:
	UINT m_nSize;		// Memory block size
	HANDLE m_hMapping;	// File mapping handle
	CString m_strName;	// Object name
	CMutex* m_pMutex;	// Pointer to mutex for synchronizing reads and writes
	BOOL m_bMeFirst;	// TRUE if this is the first connection
#ifdef _DEBUG
	UINT m_nLockCount;	// Lock count
#endif
};
