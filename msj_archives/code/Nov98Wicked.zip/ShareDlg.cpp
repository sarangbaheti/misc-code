// ShareDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SharedMem.h"
#include "Share.h"
#include "ShareDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CShareDlg dialog

CShareDlg::CShareDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CShareDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CShareDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pMem = NULL;
}

void CShareDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CShareDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CShareDlg, CDialog)
	//{{AFX_MSG_MAP(CShareDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_PUT, OnPutSharedMem)
	ON_BN_CLICKED(IDC_GET, OnGetSharedMem)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShareDlg message handlers

BOOL CShareDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	//
	// Limit the "put" string to 64 characters.
	//
	((CEdit*) GetDlgItem (IDC_PUTTEXT))->LimitText (64);

	//
	// Create a shared memory object.
	//
	try {
		m_pMem = new CSharedMemory (
			256,										// Size
			_T ("394D15E1-2481-11D2-BA24-E3E9C2C82A0F")	// Name
		);
	}
	catch (CMemoryException* e) {
		MessageBox (_T ("Unable to allocate shared memory"),
			_T ("Error"), MB_ICONEXCLAMATION | MB_OK);
		GetDlgItem (IDC_GET)->EnableWindow (FALSE);
		GetDlgItem (IDC_PUT)->EnableWindow (FALSE);
		e->Delete ();
	}
	return TRUE;
}

void CShareDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CShareDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CShareDlg::OnClose() 
{
	if (m_pMem != NULL) {
		delete m_pMem;
		m_pMem = NULL;
	}
	CDialog::OnClose();
}

void CShareDlg::OnPutSharedMem() 
{
#ifndef SMART_READ_WRITE
	if (m_pMem != NULL) {
		CString string;
		GetDlgItemText (IDC_PUTTEXT, string);
		::lstrcpy ((LPTSTR) m_pMem->p, string);
	}	
#else
	if (m_pMem != NULL) {
		CString string;
		GetDlgItemText (IDC_PUTTEXT, string);
		DWORD dwCount = (string.GetLength () + 1) * sizeof (TCHAR);

		DWORD dwBytesWritten;
		m_pMem->Write (&dwCount, sizeof (dwCount), &dwBytesWritten, 0);
		m_pMem->Write (string.GetBuffer (0), dwCount, &dwBytesWritten,
			sizeof (dwCount));
	}
#endif
}

void CShareDlg::OnGetSharedMem() 
{
#ifndef SMART_READ_WRITE
	if (m_pMem != NULL) {
		CString string = (LPCTSTR) m_pMem->p;
		SetDlgItemText (IDC_GETTEXT, string);
	}	
#else
	if (m_pMem != NULL) {
		DWORD dwCount, dwBytesRead;
		m_pMem->Read (&dwCount, sizeof (dwCount), &dwBytesRead, 0);

		TCHAR szText[256];
		m_pMem->Read (szText, dwCount, &dwBytesRead, sizeof (dwCount));
		SetDlgItemText (IDC_GETTEXT, szText);
	}
#endif
}
