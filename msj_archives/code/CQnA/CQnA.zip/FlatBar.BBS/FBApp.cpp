////////////////////////////////////////////////////////////////
// FBApp 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// FBApp illustrates how to create a flat style tool bar in an MFC app.
// Compiles with VC++ 5.0 or later, under Windows 95.
// See FlatBar.cpp for the good stuff.

#include "StdAfx.h"
#include "Resource.h"
#include "FlatBar.h"

//////////////////
// Standard do-nothing application class
//
class CMyApp : public CWinApp {
public:
	DECLARE_DYNAMIC(CMyApp)
	virtual BOOL InitInstance();
protected:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnAppAbout();
};

////////////////
// Standard MFC main frame window uses CFlatToolBar instead of CToolBar
//
class CMainFrame : public CFrameWnd {
public:
	virtual ~CMainFrame();
//protected:
	DECLARE_DYNCREATE(CMainFrame)
	CStatusBar		m_wndStatusBar;
	CFlatToolBar	m_wndToolBar; // <<<< flat tool bar 
	CMainFrame();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	DECLARE_MESSAGE_MAP()
};

/////////////////
// Standard do-nothing doc
//
class CMyDoc : public CDocument {
public:
	virtual void Serialize(CArchive& ar);
	DECLARE_DYNCREATE(CMyDoc)
};

/////////////////
// Standard do-nothing view
//
class CMyView : public CView {
	BOOL	m_bRed;								 // whether to paint red
public:
	DECLARE_DYNCREATE(CMyView)
	CMyView();
	virtual void OnDraw(CDC* pDC);		 // overridden to draw this view

	DECLARE_MESSAGE_MAP()
	afx_msg void OnViewRed();				 // handle View Red command..
	afx_msg void OnUpdateViewRed(CCmdUI* pCmdUI);	// and UI update
};

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////
// CMyApp
//
BEGIN_MESSAGE_MAP(CMyApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

IMPLEMENT_DYNAMIC(CMyApp, CWinApp)

CMyApp theApp;

BOOL CMyApp::InitInstance()
{
	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CMyDoc),
		RUNTIME_CLASS(CMainFrame),			// main SDI frame window
		RUNTIME_CLASS(CMyView));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	return ProcessShellCommand(cmdInfo);
}

void CMyApp::OnAppAbout()
{
	CDialog(IDD_ABOUTBOX).DoModal();
}

////////////////////////////////////////////////////////////////
// CMainFrame
//
IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
END_MESSAGE_MAP()

static UINT indicators[] = {
	ID_SEPARATOR,				// status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME)) {
		TRACE0("Failed to create toolbar\n");
		return -1;		 // fail to create
	}
// m_wndToolBar.ModifyStyle(0, TBSTYLE_FLAT);

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT))) {
		TRACE0("Failed to create status bar\n");
		return -1;		 // fail to create
	}

	// TODO: Remove this if you don't want tool tips or a resizeable toolbar
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// TODO: Delete these three lines if you don't want the toolbar to
	//	 be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	return 0;
}

////////////////////////////////////////////////////////////////
// CMyView
//
BEGIN_MESSAGE_MAP(CMyView, CView)
	ON_COMMAND(ID_VIEW_RED, OnViewRed)
	ON_UPDATE_COMMAND_UI(ID_VIEW_RED, OnUpdateViewRed)
END_MESSAGE_MAP()

IMPLEMENT_DYNCREATE(CMyView, CView)

CMyView::CMyView()
{
	m_bRed = FALSE;
}

void CMyView::OnDraw(CDC* pDC)
{
	if (m_bRed) {
		CRect rc;
		GetClientRect(&rc);
		CBrush b(RGB(255,0,0));				 // red brush
		CBrush* pOldBrush = pDC->SelectObject(&b);
		pDC->PatBlt(0,0,rc.Width(),rc.Height(),PATCOPY);
		pDC->SelectObject(pOldBrush);
	}
}

void CMyView::OnViewRed()
{
	m_bRed = !m_bRed;
	Invalidate();
}

void CMyView::OnUpdateViewRed(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_bRed);
}

////////////////////////////////////////////////////////////////
// CMyDoc
//
IMPLEMENT_DYNCREATE(CMyDoc, CDocument)

void CMyDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring()) {
	} else {
	}
}
