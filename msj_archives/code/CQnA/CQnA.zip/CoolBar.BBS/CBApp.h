////////////////////////////////////////////////////////////////
// 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// 
#include "resource.h"

//////////////////
// Standard application class
//
class CMyApp : public CWinApp {
public:
	DECLARE_DYNAMIC(CMyApp)
	virtual BOOL InitInstance();
protected:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnAppAbout();
};

/////////////////
// Standard do-nothing doc
//
class CMyDoc : public CDocument {
public:
	DECLARE_DYNCREATE(CMyDoc)
	virtual void Serialize(CArchive& ar);
};

/////////////////
// Standard do-nothing view
//
class CMyView : public CView {
	BOOL	m_bRed;								 // whether to paint red
public:
	DECLARE_DYNCREATE(CMyView)
	CMyView();
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view

	DECLARE_MESSAGE_MAP()
	afx_msg void OnViewRed();				 // handle View Red command..
	afx_msg void OnUpdateViewRed(CCmdUI* pCmdUI);	// and UI update
};


