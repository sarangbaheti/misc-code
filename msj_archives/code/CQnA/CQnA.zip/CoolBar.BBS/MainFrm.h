////////////////////////////////////////////////////////////////
// 1997 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it. See MainFrm.cpp
//
#include "CoolBar.h"

////////////////
// Special combo box handles drop down event
//
class CMyComboBox : public CComboBox {
protected:
	DECLARE_DYNAMIC(CMyComboBox)
	DECLARE_MESSAGE_MAP()
	afx_msg void OnDropDown();
};

/////////////////
// My Cool bar: specialized CCoolBar creates bands.
//
class CMyCoolBar : public CCoolBar {
protected:
	DECLARE_DYNAMIC(CMyCoolBar)
	CCoolToolBar	m_wndToolBar;			 // toolbar
	CMyComboBox		m_wndCombo;				 // combo box
	CBitmap			m_bmBackground;		 // background bitmap
	virtual BOOL   OnCreateBands();
};

/////////////////
// Main frame window has cool bar and status bar
//
class CMainFrame : public CFrameWnd {
protected:
	DECLARE_DYNCREATE(CMainFrame)
	CStatusBar  m_wndStatusBar;
	CMyCoolBar  m_wndCoolBar;				 // here's the coolbar
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	DECLARE_MESSAGE_MAP()
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnUpdateFileOpen(CCmdUI* pCmdUI);
};
