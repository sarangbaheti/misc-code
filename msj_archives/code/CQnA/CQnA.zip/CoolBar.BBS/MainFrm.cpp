////////////////////////////////////////////////////////////////
// COOLBAR 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Shows how to use my CCoolBar class to implement a coolbar in MFC.
// Compiles with Visual C++ 5.0 on Windows 95

#include "StdAfx.h"
#include "MainFrm.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////
// CMainFrame
//
IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
END_MESSAGE_MAP()

static UINT indicators[] = {
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

//////////////////
// Create handler creates control bars
//
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// Create cool bar
	if (!m_wndCoolBar.Create(this,
		WS_CHILD|WS_VISIBLE|WS_BORDER|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|
			RBS_TOOLTIPS|RBS_BANDBORDERS|RBS_VARHEIGHT)) {
		TRACE0("Failed to create cool bar\n");
		return -1;      // fail to create
	}

	// Create status bar
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT))) {
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	return 0;
}

////////////////
// Override for flicker-free drawing with no CS_VREDRAW and CS_HREDRAW.
// This has nothing to do with coolbars, but I threw it in because it's
// a good thing to do.
//
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
   cs.lpszClass = AfxRegisterWndClass(
      CS_DBLCLKS,                       // if you need double-clicks
      NULL,                             // no cursor (use default)
      NULL,                             // no background brush
      AfxGetApp()->LoadIcon(IDR_MAINFRAME)); // app icon
   ASSERT(cs.lpszClass);
   return CFrameWnd::PreCreateWindow(cs);
}

////////////////////////////////////////////////////////////////
// CMyCoolBar
//
IMPLEMENT_DYNAMIC(CMyCoolBar, CCoolBar)

const CSize COMBO_MINSIZE(150,25);

////////////////
// This is the virtual function you have to override to add bands
//
BOOL CMyCoolBar::OnCreateBands()
{
	// Create tool bar
	CCoolToolBar& tb = m_wndToolBar;
	if (!tb.Create(this,
		WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|
			CBRS_TOOLTIPS|CBRS_SIZE_DYNAMIC|CBRS_FLYBY) ||
		 !tb.LoadToolBar(IDR_MAINFRAME)) {
		TRACE0("Failed to create toolbar\n");
		return FALSE; // failed to create
	}
	tb.ModifyStyle(0, TBSTYLE_FLAT);
//	tb.SetOwner(GetParent());

	// Create combo box
	CRect rc(0,0,0,0);
	m_wndCombo.Create(WS_VISIBLE|WS_CHILD|WS_VSCROLL|CBS_DROPDOWNLIST|
		WS_CLIPCHILDREN|WS_CLIPSIBLINGS, rc, this, 1001);

// Following is not needed since I'm not using an image list
//	CRebarInfo rbi;
// ... set stuff in rbi...
//	SetBarInfo(&rbi);

	// Get minimum size of bands
	CSize szHorz = tb.CalcDynamicLayout(-1, 0);	      // get min horz size
	CSize szVert = tb.CalcDynamicLayout(-1, LM_HORZ);	// get min vert size
	VERIFY(m_bmBackground.LoadBitmap(IDB_BITMAP1));		// load background bmp

	// Band 1: Add toolbar band
	CRebarBandInfo rbbi;
	rbbi.fMask = RBBIM_STYLE|RBBIM_CHILD|RBBIM_CHILDSIZE|
		RBBIM_BACKGROUND|RBBIM_COLORS;
	rbbi.fStyle = RBBS_FIXEDBMP;
	rbbi.hwndChild = m_wndToolBar;
	rbbi.cxMinChild = szHorz.cx;
	rbbi.cyMinChild = szVert.cy;
	rbbi.hbmBack = m_bmBackground;
	rbbi.clrFore = GetSysColor(COLOR_BTNTEXT);
	rbbi.clrBack = GetSysColor(COLOR_BTNFACE);
	if (!InsertBand(-1, &rbbi))
		return FALSE;

	// Band 2: Add combo box band. Most settings in rbbi same from tool bar
	rbbi.fMask |= RBBIM_TEXT;
	rbbi.lpText = _T("Address:");
	rbbi.cxMinChild = COMBO_MINSIZE.cx;
	rbbi.cyMinChild = COMBO_MINSIZE.cy;
	rbbi.hwndChild = m_wndCombo;
	if (!InsertBand(-1, &rbbi))
		return FALSE;

	return 0; // OK
}

////////////////////////////////////////////////////////////////
// CMyComboBox
//
IMPLEMENT_DYNAMIC(CMyComboBox, CComboBox)

BEGIN_MESSAGE_MAP(CMyComboBox, CComboBox)
	ON_CONTROL_REFLECT(CBN_DROPDOWN, OnDropDown)
END_MESSAGE_MAP()

//////////////////
// Note that I have to resize the window when I get CBN_DROPDOWN
//		
void CMyComboBox::OnDropDown()
{
	CRect rc;
	GetWindowRect(&rc);
	SetWindowPos(NULL,0,0,rc.Width(),200, // use same width but taller height
		SWP_NOMOVE|SWP_NOACTIVATE);
	ResetContent();
	for (int i=1; i<=20; i++) {
		CString s;
		s.Format("http://www.msj%d.com", i);
		AddString(s);
	}
}
