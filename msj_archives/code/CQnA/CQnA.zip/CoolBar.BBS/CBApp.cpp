////////////////////////////////////////////////////////////////
// CBApp 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// CBApp illustrates how to use my CCoolBar class to create a coolbar common
// control in an MFC app. Compiles with VC++ 5.0 or later, under Windows 95.
// This file is generic; the interesting stuff is in CCoolBar and CMainFrame.

#include "StdAfx.h"
#include "CBApp.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////
// CMyApp
//
BEGIN_MESSAGE_MAP(CMyApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

IMPLEMENT_DYNAMIC(CMyApp, CWinApp)

CMyApp theApp;

BOOL CMyApp::InitInstance()
{
	// Create standard doc/frame/view
	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CMyDoc),
		RUNTIME_CLASS(CMainFrame),
		RUNTIME_CLASS(CMyView));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	return ProcessShellCommand(cmdInfo);
}

void CMyApp::OnAppAbout()
{
	CDialog(IDD_ABOUTBOX).DoModal();
}

////////////////////////////////////////////////////////////////
// CMyView
//
IMPLEMENT_DYNCREATE(CMyView, CView)

BEGIN_MESSAGE_MAP(CMyView, CView)
	ON_COMMAND(ID_VIEW_RED, OnViewRed)
	ON_UPDATE_COMMAND_UI(ID_VIEW_RED, OnUpdateViewRed)
END_MESSAGE_MAP()

CMyView::CMyView()
{
	m_bRed = FALSE;
}

const COLORREF COLOR_RED = RGB(255,0,0);

void CMyView::OnDraw(CDC* pDC)
{
	if (m_bRed) {
		CRect rc;
		GetClientRect(&rc);
		CBrush b(COLOR_RED);				 // red brush
		CBrush* pOldBrush = pDC->SelectObject(&b);
		pDC->SetBkColor(COLOR_RED);
		pDC->PatBlt(0,0,rc.Width(),rc.Height(),PATCOPY);
		pDC->SelectObject(pOldBrush);
	}
	CString s = "Are coolbars really cool?";
	CRect rc;
	GetClientRect(&rc);
	pDC->DrawText(s, rc, 0);
}

void CMyView::OnViewRed()
{
	m_bRed = !m_bRed;
	Invalidate();
}

void CMyView::OnUpdateViewRed(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_bRed);
}

////////////////////////////////////////////////////////////////
// CMyDoc
//
IMPLEMENT_DYNCREATE(CMyDoc, CDocument)

void CMyDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring()) {
	} else {
	}
}
