////////////////////////////////////////////////////////////////
// OneDlg 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// OneDlg illustrates how to create an app that allows only one
// instance of itself. Compiles w/VC 5.0 under Win95. Should
// work in NT too, but not tested.
//
#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const LRESULT OpenSesame = 0x1234abcd;
const MY_WM_PING = WM_USER;

//////////////////
// Dialog class that alters the TAB sequence and handles
// the RETURN key.
//
class CMyDialog : public CDialog {
public:
	CMyDialog();
	~CMyDialog();
	DECLARE_MESSAGE_MAP()
	afx_msg LRESULT OnPing(WPARAM, LPARAM);
};

////////////////////////////////////////////////////////////////
// Application class
//
class CApp : public CWinApp {
public:
	CApp() { }
	virtual BOOL InitInstance();
} theApp;

/////////////////
// Initialize: just run the dialog and quit.
//
BOOL CApp::InitInstance()
{
	TRACE("previous instance=%p\n", m_hPrevInstance); // always NULL
	CWnd *pWnd = CWnd::FindWindow(NULL, "Only One Instance Dialog");
	if (pWnd && pWnd->SendMessage(MY_WM_PING)==OpenSesame) {
		// My dialog already exists: activate it
		pWnd->SetForegroundWindow();
	} else {
		// Dialog doesn't exist
		CMyDialog dlg;
		dlg.DoModal();
	}
	return FALSE;
}

////////////////////////////////////////////////////////////////
// CMyDialog
//
BEGIN_MESSAGE_MAP(CMyDialog, CDialog)
	ON_MESSAGE(MY_WM_PING, OnPing)
END_MESSAGE_MAP()

//////////////////
// Construct dialog: set everything to zero or NULL.
//
CMyDialog::CMyDialog() : CDialog(IDD_DIALOG1)
{
}

CMyDialog::~CMyDialog()
{
}

LRESULT CMyDialog::OnPing(WPARAM, LPARAM)
{
	return OpenSesame;
}