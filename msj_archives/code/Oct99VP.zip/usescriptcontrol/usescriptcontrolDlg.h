// usescriptcontrolDlg.h : header file
//

#if !defined(AFX_USESCRIPTCONTROLDLG_H__C1E04346_3A1F_11D3_B7D7_0060081EE21C__INCLUDED_)
#define AFX_USESCRIPTCONTROLDLG_H__C1E04346_3A1F_11D3_B7D7_0060081EE21C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CUsescriptcontrolDlg dialog

class CUsescriptcontrolDlg : public CDialog
{
// Construction
public:
	CUsescriptcontrolDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CUsescriptcontrolDlg)
	enum { IDD = IDD_USESCRIPTCONTROL_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUsescriptcontrolDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CUsescriptcontrolDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_USESCRIPTCONTROLDLG_H__C1E04346_3A1F_11D3_B7D7_0060081EE21C__INCLUDED_)
