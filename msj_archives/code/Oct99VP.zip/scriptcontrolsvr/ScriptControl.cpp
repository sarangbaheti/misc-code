// ScriptControl.cpp : Implementation of CScriptControl

#include "stdafx.h"
#include "ScriptControlSvr.h"
#include "ScriptControl.h"

/////////////////////////////////////////////////////////////////////////////
// CScriptControl

