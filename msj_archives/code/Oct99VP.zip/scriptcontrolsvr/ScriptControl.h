// ScriptControl.h : Declaration of the CScriptControl

#ifndef __SCRIPTCONTROL_H_
#define __SCRIPTCONTROL_H_

#include "resource.h"       // main symbols
#include <atlctl.h>

#include "scriptsite.h"
#include "ScriptControlSvrCP.h"

/////////////////////////////////////////////////////////////////////////////
// CScriptControl
class CScriptControl : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public IDispatchImpl<IScriptControl, &IID_IScriptControl, &LIBID_SCRIPTCONTROLSVRLib>,
	public CComCompositeControl<CScriptControl>,
	public IPersistStreamInitImpl<CScriptControl>,
	public IOleControlImpl<CScriptControl>,
	public IOleObjectImpl<CScriptControl>,
	public IOleInPlaceActiveObjectImpl<CScriptControl>,
	public IViewObjectExImpl<CScriptControl>,
	public IOleInPlaceObjectWindowlessImpl<CScriptControl>,
	public ISupportErrorInfo,
	public IConnectionPointContainerImpl<CScriptControl>,
	public IPersistStorageImpl<CScriptControl>,
	public ISpecifyPropertyPagesImpl<CScriptControl>,
	public IQuickActivateImpl<CScriptControl>,
	public IDataObjectImpl<CScriptControl>,
	public IProvideClassInfo2Impl<&CLSID_ScriptControl, &DIID__IScriptControlEvents, &LIBID_SCRIPTCONTROLSVRLib>,
	public IPropertyNotifySinkCP<CScriptControl>,
	public CComCoClass<CScriptControl, &CLSID_ScriptControl>,
	public CProxy_IScriptControlEvents< CScriptControl >
{
public:
	CScriptControl()
	{
		m_bWindowOnly = TRUE;
		CalcExtent(m_sizeExtent);

		InitScriptingEngine();
	}

	void UpdateButtons()
	{
		switch(m_scriptEngineState)
		{
			case stateReset:
			{
				::EnableWindow(GetDlgItem(IDC_RUNSUBROUTINE), FALSE);
				::EnableWindow(GetDlgItem(IDC_LOADSCRIPT), TRUE);
				::EnableWindow(GetDlgItem(IDC_CONNECT), FALSE);
				::EnableWindow(GetDlgItem(IDC_FUNCTIONS), FALSE);
			}
			break;
			case stateLoaded:
			{
				::EnableWindow(GetDlgItem(IDC_RUNSUBROUTINE), FALSE);
				::EnableWindow(GetDlgItem(IDC_LOADSCRIPT), FALSE);
				::EnableWindow(GetDlgItem(IDC_CONNECT), TRUE);
				::EnableWindow(GetDlgItem(IDC_FUNCTIONS), FALSE);
			}
			break;
			case stateConnected:
			{
				::EnableWindow(GetDlgItem(IDC_RUNSUBROUTINE), FALSE);
				::EnableWindow(GetDlgItem(IDC_LOADSCRIPT), FALSE);
				::EnableWindow(GetDlgItem(IDC_CONNECT), FALSE);
				::EnableWindow(GetDlgItem(IDC_FUNCTIONS), TRUE);
			}
			break;
			case stateFunctionsLoaded:
			{
				::EnableWindow(GetDlgItem(IDC_RUNSUBROUTINE), TRUE);
				::EnableWindow(GetDlgItem(IDC_LOADSCRIPT), FALSE);
				::EnableWindow(GetDlgItem(IDC_CONNECT), FALSE);
				::EnableWindow(GetDlgItem(IDC_FUNCTIONS), FALSE);
			}
			break;
		};

	}

DECLARE_REGISTRY_RESOURCEID(IDR_SCRIPTCONTROL)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CScriptControl)
	COM_INTERFACE_ENTRY(IScriptControl)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IViewObjectEx)
	COM_INTERFACE_ENTRY(IViewObject2)
	COM_INTERFACE_ENTRY(IViewObject)
	COM_INTERFACE_ENTRY(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceObject)
	COM_INTERFACE_ENTRY2(IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY(IOleControl)
	COM_INTERFACE_ENTRY(IOleObject)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY2(IPersist, IPersistStreamInit)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY(ISpecifyPropertyPages)
	COM_INTERFACE_ENTRY(IQuickActivate)
	COM_INTERFACE_ENTRY(IPersistStorage)
	COM_INTERFACE_ENTRY(IDataObject)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
END_COM_MAP()

BEGIN_PROP_MAP(CScriptControl)
	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)
	// Example entries
	// PROP_ENTRY("Property Description", dispid, clsid)
	// PROP_PAGE(CLSID_StockColorPage)
END_PROP_MAP()

BEGIN_CONNECTION_POINT_MAP(CScriptControl)
	CONNECTION_POINT_ENTRY(IID_IPropertyNotifySink)
	CONNECTION_POINT_ENTRY(DIID__IScriptControlEvents)
END_CONNECTION_POINT_MAP()

BEGIN_MSG_MAP(CScriptControl)
	CHAIN_MSG_MAP(CComCompositeControl<CScriptControl>)
	COMMAND_HANDLER(IDC_LOADSCRIPT, BN_CLICKED, OnClickedLoadscript)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_HANDLER(IDC_CONNECT, BN_CLICKED, OnClickedConnect)
	COMMAND_HANDLER(IDC_FUNCTIONS, BN_CLICKED, OnClickedFunctions)
	COMMAND_HANDLER(IDC_RESET, BN_CLICKED, OnClickedReset)
	COMMAND_HANDLER(IDC_RUNSUBROUTINE, BN_CLICKED, OnClickedRunsubroutine)
	COMMAND_HANDLER(IDC_LISTFUNCTIONS, LBN_DBLCLK, OnDblclkListfunctions)
	COMMAND_HANDLER(IDC_TESTEVENTS, BN_CLICKED, OnClickedTestevents)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

BEGIN_SINK_MAP(CScriptControl)
	//Make sure the Event Handlers have __stdcall calling convention
END_SINK_MAP()

	STDMETHOD(OnAmbientPropertyChange)(DISPID dispid)
	{
		if (dispid == DISPID_AMBIENT_BACKCOLOR)
		{
			SetBackgroundColorFromAmbient();
			FireViewChange();
		}
		return IOleControlImpl<CScriptControl>::OnAmbientPropertyChange(dispid);
	}



// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid)
	{
		static const IID* arr[] = 
		{
			&IID_IScriptControl,
		};
		for (int i=0; i<sizeof(arr)/sizeof(arr[0]); i++)
		{
			if (InlineIsEqualGUID(*arr[i], riid))
				return S_OK;
		}
		return S_FALSE;
	}

// IViewObjectEx
	DECLARE_VIEW_STATUS(0)

// IScriptControl
public:

	enum { IDD = IDD_SCRIPTCONTROL };

	typedef enum tagScriptEngineState {
		stateReset = 0,
		stateLoaded = 1,
		stateConnected = 2,
		stateFunctionsLoaded = 3,
	} SCRIPTENGINESTATE;

	SCRIPTENGINESTATE m_scriptEngineState;

	CActiveScriptSite scriptSite;

	void InitScriptingEngine()
	{
		CLSID clsid;
		HRESULT hResult = E_FAIL;
		IActiveScriptSite* pActiveScriptSite = NULL;

		hResult = CLSIDFromProgID( L"VBScript", &clsid );
		if( FAILED( hResult ) )
		{
		}

		HRESULT hr = scriptSite.InitScriptEngine(clsid);
	}	

	LRESULT OnClickedLoadscript(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		BSTR bstrScriptText = NULL;

		GetDlgItemText(IDC_EDITSCRIPTTEXT, bstrScriptText);

		scriptSite.LoadScript(bstrScriptText);

		// add the top level object
		IDispatch* pDisp = 0;
		QueryInterface(IID_IDispatch, (void**)&pDisp);
		scriptSite.AddNamedItem(_bstr_t("Form"), pDisp);
		pDisp->Release();

		m_scriptEngineState = stateLoaded;
		UpdateButtons();

		return 0;
	}

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		char* pszScriptText = new char[4096];
		memset(pszScriptText, 0, 4096);
		char szBuffer[256];

		sprintf(szBuffer, "Sub Form_Load%c%c\tMsgBox %cForm_Load%c %c%c %c%c\tFunction1%c%c %c%c\tFunction2%c%c %c%c\tFunction3%c%c %c%c\tFunction4%c%c End Sub%c%c%c%c", 13, 10, 34, 34, 13, 10, 13, 10, 13, 10, 13, 10, 13, 10, 13, 10, 13, 10, 13, 10, 13, 10, 13, 10, 13, 10, 13, 10, 13, 10, 13, 10);
		strcat(pszScriptText, szBuffer);

		sprintf(szBuffer, "Sub Function1%c%c\tMsgBox %cFunction1%c %c%cEnd Sub%c%c%c%c", 13, 10, 34, 34, 13, 10, 13, 10, 13, 10, 13, 10);
		strcat(pszScriptText, szBuffer);

		sprintf(szBuffer, "Sub Function2%c%c\tMsgBox %cFunction2%c %c%cEnd Sub%c%c%c%c", 13, 10, 34, 34, 13, 10, 13, 10, 13, 10, 13, 10);
		strcat(pszScriptText, szBuffer);

		sprintf(szBuffer, "Sub Function3%c%c\tMsgBox %cFunction3%c %c%cEnd Sub%c%c%c%c", 13, 10, 34, 34, 13, 10, 13, 10, 13, 10, 13, 10);
		strcat(pszScriptText, szBuffer);

		sprintf(szBuffer, "Sub Function4%c%c\tMsgBox %cFunction4%c %c%cEnd Sub%c%c%c%c", 13, 10, 34, 34, 13, 10, 13, 10, 13, 10, 13, 10);
		strcat(pszScriptText, szBuffer);

		SetDlgItemText(IDC_EDITSCRIPTTEXT, pszScriptText);
		delete pszScriptText;

		m_scriptEngineState = stateReset;
		UpdateButtons();

		return 0;
	}

	LRESULT OnClickedConnect(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		scriptSite.Connect();	
		m_scriptEngineState = stateConnected;
		UpdateButtons();

		return 0;
	}

	LRESULT OnClickedFunctions(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		scriptSite.CollectMacros();

		BSTR* pbstrMacroNames;
		long l;

		HRESULT  hr;
		hr = scriptSite.GetMacroNames(&pbstrMacroNames, &l);

		for(long m = 0; m < l; m++)
		{
			char szFunction[256];

			wcstombs(szFunction,  
						pbstrMacroNames[m], 
						256);
			SendMessage(GetDlgItem(IDC_LISTFUNCTIONS), 
									LB_ADDSTRING, 
									0, (LPARAM)szFunction);
			SysFreeString(pbstrMacroNames[m]);
		}
		CoTaskMemFree(pbstrMacroNames);

		m_scriptEngineState = stateFunctionsLoaded;
		UpdateButtons();

		return 0;
	}

	LRESULT OnClickedReset(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		InitScriptingEngine();
		SendMessage(GetDlgItem(IDC_LISTFUNCTIONS), 
									LB_RESETCONTENT, 
									0, 0);
		
		m_scriptEngineState = stateReset;
		UpdateButtons();

		return 0;
	}

	LRESULT OnClickedRunsubroutine(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		char* pszFunction;
		int nNdx = 0;
		int nLen = 0;

		nNdx = SendMessage(GetDlgItem(IDC_LISTFUNCTIONS), LB_GETCURSEL, 0, 0);
		nLen = SendMessage(GetDlgItem(IDC_LISTFUNCTIONS), LB_GETTEXTLEN, nNdx, 0);

		if(nLen >= 0)
		{
			pszFunction = new char[nLen + 1];
			wchar_t* pszwFunctionName = new wchar_t[nLen + 1];

			SendMessage(GetDlgItem(IDC_LISTFUNCTIONS), LB_GETTEXT, 
						nNdx, (LPARAM)pszFunction); 

			mbstowcs(pszwFunctionName,  
						pszFunction, 
						nLen + 1);
			
			BSTR bstrFunction = SysAllocString(pszwFunctionName);
			scriptSite.RunMacro(bstrFunction);
			SysFreeString(bstrFunction);
			delete pszFunction;
			delete pszwFunctionName;
		}

		return 0;
	}

	LRESULT OnDblclkListfunctions(WORD wNotifyCode, WORD wID, 
									HWND hWndCtl, BOOL& bHandled)
	{
		return 0;
	}

	LRESULT OnClickedTestevents(WORD wNotifyCode, WORD wID, 
								HWND hWndCtl, BOOL& bHandled)
	{
		Fire_Load();		
		return 0;
	}
};

#endif //__SCRIPTCONTROL_H_
