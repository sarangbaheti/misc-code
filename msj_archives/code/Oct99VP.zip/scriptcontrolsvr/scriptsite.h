
#ifndef __SCRIPTSITE_H_
#define __SCRIPTSITE_H_

#include "resource.h"       // main symbols
#include <activscp.h>
#include "vector"
#include "typeattr.h"
#include "resource.h"       // main symbols


/////////////////////////////////////////////////////////////////////////
//
// This structure represents a named item. The Active Scripting 
//  engine uses BSTRs as keys for objects used within a script.
//
//
struct NamedItem
{
	/////////////////////////////////////////////////////////////////////////
	// construct a named item
	NamedItem()
	{
		memset(this, 0, sizeof(NamedItem));
	}

	/////////////////////////////////////////////////////////////////////////
	// construct a named item from an IUnknown pointer
	NamedItem(BSTR bstrName, IUnknown* pUnkItem)
	{
		memset(this, 0, sizeof(NamedItem));

		HRESULT hr;

		/////////////////////////////////////////////////////////////////////////
		// Cache the IUnknown pointer...
		if(pUnkItem)
		{
			m_pUnk = pUnkItem;
			m_pUnk->AddRef();

			IProvideClassInfo* pProvideClassInfo = NULL;

			/////////////////////////////////////////////////////////////////////////
			// Cache the type info pointer for the class. 
			hr = pUnkItem->QueryInterface(IID_IProvideClassInfo, 
											(void**)&pProvideClassInfo);
			if(SUCCEEDED(hr))
			{
				pProvideClassInfo->GetClassInfo(&m_pTypeInfo);
				pProvideClassInfo->Release();
			}
		}

		/////////////////////////////////////////////////////////////////////////
		// Make a copy of the name 
		m_bstrName = SysAllocString(bstrName);
	}

	/////////////////////////////////////////////////////////////////////////
	// destruct a named item
	virtual ~NamedItem()
	{
		/////////////////////////////////////////////////////////////////////////
		// release cached interface pointers. 
		if(m_pUnk)
		{
			m_pUnk->Release();
		}
		if(m_pTypeInfo)
		{
			m_pTypeInfo->Release();;
		}

		/////////////////////////////////////////////////////////////////////////
		// delete the BSTR name 
		if(m_bstrName)
		{
			SysFreeString(m_bstrName);
		}
	}

	/////////////////////////////////////////////////////////////////////////
	// An item consists of a name/ITypeInfo/IUnknown pair
	BSTR m_bstrName;
	ITypeInfo* m_pTypeInfo;
	IUnknown* m_pUnk;
};

struct CMacroInfo
{
	CMacroInfo()
	{
		memset(this, 0, sizeof(*this));
	}

	CMacroInfo(DWORD dispID, BSTR bstrMacroName)
	{
		memset(this, 0, sizeof(*this));
		m_dispID = dispID;
		m_bstrMacroName = SysAllocString(bstrMacroName);
	}

	virtual ~CMacroInfo()
	{
		if(m_bstrMacroName)
		{
			SysFreeString(m_bstrMacroName);
		}
	}

	DWORD m_dispID;
	BSTR m_bstrMacroName;
};

class CNamedItems : public std::vector<NamedItem*>
{
public:
	CNamedItems()
	{
	}

	~CNamedItems()
	{
	}
};

class CMacroInfos : public std::vector<CMacroInfo*>
{
public:
	CMacroInfos()
	{
	}

	~CMacroInfos()
	{
	}
};


/////////////////////////////////////////////////////////////////////////////
// CActiveScriptSite
class CActiveScriptSite : 
	public IActiveScriptSiteWindow,
	public IActiveScriptSite
{
protected:
	/////////////////////////////////////////////////////////////////
	// These interfaces come from Microsoft. 
	IActiveScript* m_pActiveScript;
	IActiveScriptParse* m_pActiveScriptParse;

	bool m_bIsInitialized;

	CNamedItems* m_pitems;
	CMacroInfos* m_pmacros;

	HWND m_hWnd;

public:
	CActiveScriptSite()
	{
		m_pActiveScript = 0;
		m_pActiveScriptParse = 0;
		m_bIsInitialized = false;

		m_pitems = 0;
		m_pmacros = 0;

		m_hWnd = NULL;
	}

	virtual ~CActiveScriptSite()
	{
		OutputDebugString("\n\n\nDestroying the site... \n\n\n");
		Reset();
	}


// IUnknown
	STDMETHODIMP QueryInterface(REFIID riid, void** ppv)
	{
		if(riid == IID_IUnknown)
		{
			*ppv = static_cast<IActiveScriptSiteWindow*>(this);
		} else if (riid == IID_IActiveScriptSiteWindow)
		{
			*ppv = static_cast<IActiveScriptSiteWindow*>(this);
		} else if(riid == IID_IActiveScriptSite)
		{
			*ppv = static_cast<IActiveScriptSite*>(this);
		}

		if(*ppv)
		{
			((IUnknown*)(*ppv))->AddRef();
			return S_OK;
		} else
		{
			return E_NOINTERFACE;
		}
	}

	STDMETHODIMP_(ULONG) AddRef()
	{
		return 2;
	}

	STDMETHODIMP_(ULONG) Release()
	{
		return 2;
	}


	STDMETHODIMP Reset()
	{
		// Reset means clear all the named items...
		//  Release the pointefs and set them to zero...
		if(m_pActiveScript)
		{
			// note: this causes the scripting engine to NOT unadvise connection
			// points vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
			//m_pActiveScript->SetScriptState( SCRIPTSTATE_DISCONNECTED );
			m_pActiveScript->Close();

			m_pActiveScript->Release();
			m_pActiveScript = 0;
		}
		if(m_pActiveScriptParse)
		{
			m_pActiveScriptParse->Release();
			m_pActiveScriptParse = 0;
		}
		m_hWnd = NULL;
		m_bIsInitialized = FALSE;

		if(m_pitems)
		{
			delete m_pitems;
			m_pitems = 0;
		}
		if(m_pmacros)
		{	
			delete m_pmacros;
			m_pmacros = 0;
		}

		return S_OK;
	}



// ISupportsErrorInfo
	STDMETHODIMP InterfaceSupportsErrorInfo(REFIID riid);

	//////////////////////////////////////////////////////////////////////////////////////
	// Open a file and read the contents into a BSTR provided by the caller.
	//
	STDMETHODIMP LoadScriptTextFromFile(BSTR bstrFileName, BSTR* pbstrScriptText)
	{
		if(m_bIsInitialized)
		{
			TCHAR szFileName[MAX_PATH + 1];

#ifdef UNICODE
			// if it's unicode, then bstrFileName is okay...
			wcsncpy(szFileName, bstrFileName, MAX_PATH);
#else
			wcstombs(szFileName, bstrFileName, MAX_PATH);
#endif

			// Open the file...
			HANDLE hFile = CreateFile(szFileName, GENERIC_READ,  
										FILE_SHARE_READ, NULL, 
										OPEN_EXISTING, 
										FILE_ATTRIBUTE_NORMAL, 
										NULL);

			if(hFile != INVALID_HANDLE_VALUE)
			{
				// Read the contents
				DWORD nNumberOfBytesToRead = 0;
				DWORD nNumberOfBytesRead = 0;
				BOOL bWorked = false;

				nNumberOfBytesToRead = GetFileSize(hFile, NULL);
				
				char* lpszBuffer = new char [nNumberOfBytesToRead + 1];
				memset(lpszBuffer, 0, nNumberOfBytesToRead + 1);

				if(lpszBuffer)
				{
					bWorked = ReadFile(hFile, lpszBuffer, 
										nNumberOfBytesToRead,
										&nNumberOfBytesRead, 
										NULL);

					if(bWorked)
					{
						_bstr_t bstrScriptText(lpszBuffer);

						*pbstrScriptText = bstrScriptText;
					}

					delete [] lpszBuffer;
				}

				CloseHandle(hFile);
				return S_OK;	
			} else
			{
				return E_FAIL;
			}
		} else
		{
			return E_FAIL;
		}

		return E_FAIL;
	}

	////////////////////////////////////////////////////////////////////////
	// This step queues up the script so it's ready to run.
	//
	//
	STDMETHODIMP ParseScript(BSTR bstrScriptText)
	{
		// parse the script-- necessary step
		HRESULT hr = S_OK;;
		hr = m_pActiveScriptParse->ParseScriptText(bstrScriptText, 
													NULL, 
													NULL, NULL, 
													DWORD( this ), 
													0, 
													SCRIPTTEXT_ISVISIBLE, 
													NULL, 
													NULL);

		return S_OK;
	}

	//////////////////////////////////////////////////////////////////////////
	// Load the script text found in the bstrScriptText.
	// 
	STDMETHODIMP LoadScript(BSTR bstrScriptText)
	{
		HRESULT hr = S_OK;

		// Now load the file and parse it...
		if(SUCCEEDED(hr))
		{
			hr = ParseScript(bstrScriptText);
		}

		return hr;
	}

	////////////////////////////////////////////////////////////////////////////////
	// Connects to the script engine-- gets all the connection points working...
	STDMETHODIMP Connect()
	{
		HRESULT hr = m_pActiveScript->SetScriptState(SCRIPTSTATE_CONNECTED);

		return hr;
	}

	/////////////////////////////////////////////////////////////////////////////////
	// Called by the client to start up the script engine...
	//
	STDMETHODIMP InitScriptEngine(REFCLSID clsid)
	{
		ULONG ul = 0;
		HRESULT hResult = E_FAIL;
		IActiveScriptSite* pActiveScriptSite = NULL;

		hResult = CoCreateInstance(clsid, NULL, 
									CLSCTX_INPROC_SERVER, 
									IID_IActiveScript,
									(void**)&m_pActiveScript);
		
		if(SUCCEEDED(hResult))
		{
			hResult = m_pActiveScript->QueryInterface(IID_IActiveScriptParse, 
														(void**)&m_pActiveScriptParse);
		
			if(FAILED(hResult))
			{
				goto err;
			}
		}
	
		if( FAILED( hResult ) )
		{
			goto err;
		}


		hResult = QueryInterface(IID_IActiveScriptSite, 
			                     (void**)&pActiveScriptSite);

		if(SUCCEEDED(hResult))
		{
			hResult = m_pActiveScript->SetScriptSite(pActiveScriptSite);
			pActiveScriptSite->Release();
		} else
		{
			goto err;
		}

		if(FAILED( hResult ))
		{
			goto err;
		}

		hResult = m_pActiveScriptParse->InitNew();
		if( FAILED( hResult ) )
		{
			goto err;
		}

		m_bIsInitialized = true;
		return S_OK;

err:

		if(m_pActiveScriptParse)
		{
			m_pActiveScriptParse->Release();
			m_pActiveScriptParse = NULL;
		}

		if(m_pActiveScript)
		{
			m_pActiveScript->Release();
			m_pActiveScript = NULL;
		}

		return hResult;
   }


public:
// IActiveScriptSite
	/////////////////////////////////////////////////////////////////////////////////
	// 
	// Get the locality id of the running machine.
	//
	STDMETHODIMP GetLCID(LCID* plcid)
	{
		OutputDebugString( "GetLCID\n" );
		if (plcid == NULL)
			return E_POINTER;

		*plcid = GetUserDefaultLCID();

		return S_OK;
	}

	/////////////////////////////////////////////////////////////////////////////////
	// 
	// This function is called by the COM scripting engine. 
	//
	STDMETHODIMP GetItemInfo(LPCOLESTR pstrName, 
							ULONG dwReturnMask, 
							IUnknown** ppiunkItem, 
							ITypeInfo** ppti)
	{
		OutputDebugString( "GetItemInfo\n" );

		if( ppiunkItem != NULL )
		{
			*ppiunkItem = NULL;
		}

		if( ppti != NULL )
		{
			*ppti = NULL;
		}

		HRESULT hr = S_OK;
		bool bFound = false;

		std::vector<NamedItem*>::iterator iter;
		//Find the named item...
		if(m_pitems)
		{
			for (iter = m_pitems->begin(); iter < m_pitems->end(); iter++) 
			{
				NamedItem* pNamedItem = *iter;

				bFound = (wcscmp(pNamedItem->m_bstrName, pstrName) == 0);
				if (bFound) 
				{
					break;
				}
			}
		}

		if(!bFound)
		{
			return TYPE_E_ELEMENTNOTFOUND;
		}

		if( dwReturnMask&SCRIPTINFO_IUNKNOWN )
		{	
			OutputDebugString( "Looking for item's unknown\n" );
 
			NamedItem* pNamedItem = *iter;
			pNamedItem->m_pUnk->AddRef();
			*ppiunkItem = pNamedItem->m_pUnk;
		}

		if( dwReturnMask&SCRIPTINFO_ITYPEINFO )
		{
			OutputDebugString( "Looking for item's type info\n" );
			NamedItem* pNamedItem = *iter;
			if(pNamedItem->m_pTypeInfo)
			{
				pNamedItem->m_pTypeInfo->AddRef();
			}
			*ppti = pNamedItem->m_pTypeInfo;
		}
			
		return S_OK;
	}

	////////////////////////////////////////////////////////////////////////////
	//
	//  Called by active script engine to get a unique string for this document.
	//
	STDMETHODIMP GetDocVersionString(BSTR * pbstrVersion)
	{
		OutputDebugString( "GetDocVersionString\n" );
		if (pbstrVersion == NULL)
			return E_POINTER;
			
		return E_NOTIMPL;
	}

	////////////////////////////////////////////////////////////////////////////
	//
	//  Called by active script engine when the script terminates...
	//
	STDMETHODIMP OnScriptTerminate(const VARIANT* pvarResult, 
									const EXCEPINFO* pexcepinfo)
	{
		(void)pvarResult;
		(void)pexcepinfo;

		OutputDebugString("OnScriptTerminate()\n");

		return( S_OK );
	}

	////////////////////////////////////////////////////////////////////////////
	//
	//  Called by active script engine when the state changes...
	//
	STDMETHODIMP OnStateChange(tagSCRIPTSTATE ssScriptState)
	{
		OutputDebugString("OnStateChange\n");

		switch(ssScriptState)
		{
			case SCRIPTSTATE_UNINITIALIZED:
				OutputDebugString( "\tSCRIPTSTATE_UNINITIALIZED\n" );
				break;

			case SCRIPTSTATE_INITIALIZED:
				OutputDebugString( "\tSCRIPTSTATE_INITIALIZED\n" );
				break;

			case SCRIPTSTATE_STARTED:
				OutputDebugString( "\tSCRIPTSTATE_STARTED\n" );
				break;

			case SCRIPTSTATE_CONNECTED:
				OutputDebugString( "\tSCRIPTSTATE_CONNECTED\n" );
				break;

			case SCRIPTSTATE_DISCONNECTED:
				OutputDebugString( "\tSCRIPTSTATE_DISCONNECTED\n" );
				break;

			case SCRIPTSTATE_CLOSED:
				OutputDebugString( "\tSCRIPTSTATE_CLOSED\n" );
				break;

			default:
				OutputDebugString( "\tUnknown SCRIPTSTATE value\n" );
				break;
		}

		return S_OK;
	}

	////////////////////////////////////////////////////////////////////////////
	//
	//  Called by active script engine when theere is some error...
	//
	STDMETHODIMP OnScriptError(IActiveScriptError * pscripterror)
	{
		OutputDebugString("OnScriptError()\n");
		return E_NOTIMPL;
	}

	////////////////////////////////////////////////////////////////////////////
	//
	//  Called by active script engine when the script is entered.
	//
	STDMETHODIMP OnEnterScript()
	{
		OutputDebugString("OnEnterScript()\n");
		return S_OK;
	}

	////////////////////////////////////////////////////////////////////////////
	//
	//  Called by active script engine when the script is being left.
	//
	STDMETHODIMP OnLeaveScript()
	{
		OutputDebugString("OnLeaveScript()\n");
		return S_OK;
	}

// IActiveScriptWindow
    STDMETHODIMP GetWindow(HWND* phwnd)
	{
		if (!phwnd)     
		{
			return E_INVALIDARG;   
		}
		else
		{
			*phwnd = m_hWnd; 
			return S_OK;
		}
	}

	STDMETHODIMP EnableModeless(BOOL fEnable)
	{
		return S_OK;
	}

    STDMETHODIMP AttachHostWindow(LONG hWnd)
	{
		m_hWnd = (HWND)hWnd;
		return S_OK;
	}

	// Client calls this to add objects into the scripting engine's awareness...
	STDMETHODIMP AddNamedItem(BSTR bstrName, IUnknown* pUnkItem)
	{
		if(!m_pitems)
		{
			m_pitems = new CNamedItems;

			//////////////////////////////////////////////////////////////////////
			// First add the named item to our own internal collection
			NamedItem* pNamedItem = NULL;

			pNamedItem = new NamedItem(bstrName, pUnkItem);
			m_pitems->push_back(pNamedItem);

			//////////////////////////////////////////////////////////////////////
			// Then add the item to the active script engine...
			HRESULT hr = m_pActiveScript->AddNamedItem(bstrName, 
												SCRIPTITEM_ISVISIBLE | SCRIPTITEM_ISSOURCE);
		}

		return S_OK;
	}

	HRESULT CullMacroNames(ITypeInfo* pTypeInfo = NULL)
	{
		if(m_pmacros)
		{	
			delete m_pmacros;
			m_pmacros = 0;
		}

		m_pmacros = new CMacroInfos;

		CSmartTypeAttr pTypeAttr( pTypeInfo );
		CSmartFuncDesc pFuncDesc( pTypeInfo );

		HRESULT hResult = S_OK;

		hResult = pTypeInfo->GetTypeAttr( &pTypeAttr );
		if( FAILED( hResult ) )
		{
			return( hResult );
		}

		int iMethod;

		for(iMethod = 0; iMethod < pTypeAttr->cFuncs; iMethod++)
		{
			hResult = pTypeInfo->GetFuncDesc(iMethod, &pFuncDesc);
			if(FAILED(hResult))
			{
				return(hResult);
			}
			if((pFuncDesc->funckind == FUNC_DISPATCH) && 
				(pFuncDesc->invkind == INVOKE_FUNC) && 
				(pFuncDesc->cParams == 0))
			{
				BSTR bstrName;
				unsigned int nNames;

				bstrName = NULL;
				hResult = pTypeInfo->GetNames( pFuncDesc->memid, &bstrName, 1,
												&nNames );
				if( FAILED( hResult ) )
				{
					return( hResult );
				}
				ATLASSERT( nNames == 1 );

				{
					// for examination...
					char szName[128];
					wcstombs(szName, bstrName, 127);
					int i = -1;
				}

				CMacroInfo* pMacroInfo = NULL;

				pMacroInfo = new CMacroInfo(pFuncDesc->memid, bstrName);

				m_pmacros->push_back(pMacroInfo);

				SysFreeString( bstrName );
				bstrName = NULL;

			}

			pFuncDesc.Release();
		}

		return S_OK;
	}

	STDMETHODIMP CollectMacros()
	{
		IDispatch* pDispatch = 0;
		ITypeInfo* pTypeInfo = 0;

		if(m_bIsInitialized)
		{
			HRESULT hResult = m_pActiveScript->GetScriptDispatch(NULL, &pDispatch);
			if(SUCCEEDED(hResult))
			{
				hResult = pDispatch->GetTypeInfo(0, GetUserDefaultLCID(), &pTypeInfo);
				if(SUCCEEDED(hResult))
				{
					HRESULT hr = CullMacroNames(pTypeInfo);

					pTypeInfo->Release();
					return(hResult);
				}

				pDispatch->Release();
			}
		}
		return E_NOTIMPL;
	}

	STDMETHODIMP GetMacroNames(BSTR** ppbstrMacroNames, 
								long* plNumNames)
	{
		long lSize = m_pmacros->size();
		CMacroInfo* pMacroInfo = 0;;

		BSTR* pbstrMacroNames = 0;

		if(lSize > 0)
		{
			pbstrMacroNames = (BSTR*)CoTaskMemAlloc(lSize * sizeof(BSTR));
		} else
		{
			return E_NOTIMPL;
		}

		CMacroInfos::iterator iter;
		pbstrMacroNames = (BSTR*)CoTaskMemAlloc(lSize * (sizeof(BSTR)));

		if(m_pmacros)
		{
			long i = 0;

			for (iter = m_pmacros->begin(); iter < m_pmacros->end(); iter++) 
			{
				pMacroInfo = *iter;

				pbstrMacroNames[i] = SysAllocString(pMacroInfo->m_bstrMacroName);
				i++;
			}

			*ppbstrMacroNames = pbstrMacroNames;
		}

		*plNumNames = lSize;
		return S_OK;
	}


	HRESULT RunEmAll()
	{
		CMacroInfos::iterator iter;
		CMacroInfo* pMacroInfo = 0;

		if(m_pmacros)
		{
			for (iter = m_pmacros->begin(); iter < m_pmacros->end(); iter++) 
			{
				pMacroInfo = *iter;

				IDispatch* pDispatch = 0;
				HRESULT hResult = m_pActiveScript->GetScriptDispatch(NULL, &pDispatch);
				if(SUCCEEDED(hResult))
				{

					DISPPARAMS dp = {0, 0};

					VARIANT v;
					VariantInit(&v);
					EXCEPINFO ei;

					unsigned int nArgError = 0;

					memset(&ei, sizeof(EXCEPINFO), 0);

					HRESULT hr = S_OK;
					hr = pDispatch->Invoke(pMacroInfo->m_dispID,
										IID_NULL,
										0, DISPATCH_METHOD,
										&dp,
										&v,
										&ei,
										&nArgError);

					pDispatch->Release();
				}
			}
		}
		return S_OK;
	}

	STDMETHODIMP RunMacro(BSTR bstrMacroName)
	{

		CMacroInfos::iterator iter;

		bool bFound = false;
		CMacroInfo* pMacroInfo = 0;

		if(m_pmacros)
		{
			for (iter = m_pmacros->begin(); iter < m_pmacros->end(); iter++) 
			{
				pMacroInfo = *iter;

				bFound = (wcscmp(pMacroInfo->m_bstrMacroName, bstrMacroName) == 0);
				if (bFound) 
				{
					break;
				}
			}

			if(bFound)
			{
				IDispatch* pDispatch = 0;
				HRESULT hResult = m_pActiveScript->GetScriptDispatch(NULL, &pDispatch);
				if(SUCCEEDED(hResult))
				{

					DISPPARAMS dp = {0, 0};

					VARIANT v;
					VariantInit(&v);
					EXCEPINFO ei;

					unsigned int nArgError = 0;

					memset(&ei, sizeof(EXCEPINFO), 0);

					HRESULT hr;
					hr = pDispatch->Invoke(pMacroInfo->m_dispID,
										IID_NULL,
										0, DISPATCH_METHOD,
										&dp,
										&v,
										&ei,
										&nArgError);

					pDispatch->Release();
				}
			}
		}

		return S_OK;
	}


}; // end of class



#endif //__SCRIPTSITE_H_
