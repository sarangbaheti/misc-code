//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ScriptControlSvr.rc
//
#define IDS_PROJNAME                    100
#define IDB_SCRIPTCONTROL               101
#define IDR_SCRIPTCONTROL               102
#define IDD_SCRIPTCONTROL               103
#define IDC_EDITSCRIPTTEXT              1000
#define IDC_LISTFUNCTIONS               1001
#define IDC_LOADSCRIPT                  1002
#define IDC_RUNSUBROUTINE               1003
#define IDC_CONNECT                     1004
#define IDC_FUNCTIONS                   1005
#define IDC_RESET                       1006
#define IDC_TESTEVENTS                  1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         203
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
