/******************************************************************************
FILE: WndProc.cpp
******************************************************************************/
#include <windows.h>

#include "WndProc.h"
#include "Demo.h"
#include "DX.h"


/******************************************************************************
FUNCTION: MainWndProc
The window procedure for our application.  This is mostly boilerplate code.
The only noteworthy code is the call to DrawPerson().

PARAMETERS:
None

RETURNS:
none
******************************************************************************/
LRESULT CALLBACK MainWndProc( HWND hwnd, UINT uMsg, WPARAM wParam, 
                              LPARAM lParam )
{
   PAINTSTRUCT ps ;
   HDC         hdc ;

   switch( uMsg )
   {   
   case WM_ACTIVATE:
      if ( LOWORD( wParam ) == WA_ACTIVE || 
           LOWORD( wParam ) == WA_CLICKACTIVE )
      {
         ApplicationActive() ;
      } else
      {
         ApplicationInactive() ;
      }
      break ;

   case WM_CLOSE:
      DestroyWindow( hwnd ) ;
      break ;
   
   case WM_DESTROY:
      PostQuitMessage( 0 ) ;
      break ;
   
   case WM_LBUTTONDOWN:
      g_stateListener.m_bRotating = TRUE ;
      SetCapture( hwnd ) ;
      break ;
   
   case WM_LBUTTONUP:
      g_stateListener.m_bRotating = FALSE ;
      ReleaseCapture() ;
      break ;
   
   case WM_PAINT:
      hdc = BeginPaint( hwnd, &ps ) ;
      DrawPerson( hdc, g_arrayPeople[0] ) ;     
      EndPaint( hwnd, &ps ) ;
      break ;
   
   case WM_RBUTTONDOWN:
      g_stateListener.m_nXPos = LOWORD( lParam ) ;
      g_stateListener.m_nYPos = HIWORD( lParam ) ;
      g_stateListener.m_bChanged = TRUE ; 
      break ;   

   }
   return DefWindowProc( hwnd, uMsg, wParam, lParam ) ;
}
