/******************************************************************************
FILE: DX.cpp
This module contains funtions specific to DirectX and COM.  Each componant of
DirectX will have a module dedicated to it.
******************************************************************************/
#include <windows.h>
#include <Dinput.h>
#include <DSound.h>

#include "DX.h"
#include "DXInput.h"
#include "DXSound.h"


/******************************************************************************
FUNCTION: InitDirectX
This function initializes com and then calls the application defined
initialization functions dedicated to the specific DirectX componants.

PARAMETERS:
None

RETURNS:
Failure or Success
******************************************************************************/
BOOL InitDirectX( void )
{
   // Initialize Direct Input -- DXInput.h
   if( !InitDirectInput() )
      return FALSE ;

   // Initialize Direct Sound -- DXSound.h
   if( !InitDirectSound() )
   {
      UnInitDirectInput() ;
      return FALSE ;
   }

   return TRUE ;
}

/******************************************************************************
FUNCTION: ApplicationActive
This function is called when the application becomes active.

PARAMETERS:
None

RETURNS:
None
******************************************************************************/
void ApplicationActive( void )
{
   DSActive() ;
}

/******************************************************************************
FUNCTION: ApplicationInactive
This function is called when the application becomes active.

PARAMETERS:
None

RETURNS:
None
******************************************************************************/
void ApplicationInactive( void )
{
   DSInactive() ;
}

/******************************************************************************
FUNCTION: UnInitDirectX
This function handles uninitialization.

PARAMETERS:
None

RETURNS:
None
******************************************************************************/
void UnInitDirectX( void )
{
   // Uninitialize Direct Input -- DXInput.h
   UnInitDirectInput() ;

   // Uninitialize Direct Sound -- DXSound.h
   UnInitDirectSound() ;
}
