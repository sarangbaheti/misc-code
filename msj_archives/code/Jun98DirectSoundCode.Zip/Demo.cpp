/****************************************************************************** 
FILE: Demo.cpp
This module contains logic relating to the function of the demo, without
including any functionality specific to DirectX.  This module defines the
"reality" of the demo, including a data structure (DemoPerson) used to 
maintain state data for the demo character.

GLOBALS:
g_arrayPeople -- This is an array of pointers to the DemoPerson structure
g_hDemoThread -- This thread constantly updates the game logic
g_hEndEvent -- This event is used to signal the shutdown of the demo thread
******************************************************************************/
#include <windows.h>
#include <math.h>
#include <stdio.h>

#include "resource.h"
#include "Demo.h"
#include "main.h"
#include "DXInput.h"
#include "DXSound.h"

DemoPerson     *g_arrayPeople[MAXPERSON] ;
DemoListener   g_stateListener ;
DemoDopplar    g_stateDopplar ;
DemoCone       g_stateCone ;

HANDLE g_hDemoThread = NULL ;
HANDLE g_hEndEvent = NULL ;

DWORD WINAPI DemoThreadFunc( LPVOID ) ;

void InitDemoReality( void ) ;

void DrawDirection( HDC hdc, int x, int y, int fAngle, float fScale, 
                    LPFPOINT lpfpt ) ;
void DrawCone( HDC hdc, int x, int y, int fAngle, float fScale, 
               LPFPOINT lpfpt ) ;
void DrawDopplar( HDC hdc, int nX, int nY ) ;
void RotatePoint( LPFPOINT lppt, int nAngle ) ;


/******************************************************************************
FUNCTION: InitDemo
This function creates the demo thread and the event which signals shutdown.  
It also initializes further demo state information by calling 
InitDemoReality().

PARAMETERS:
None

RETURNS:
Failure or Success
******************************************************************************/
BOOL InitDemo( void )
{
   DWORD dwID ;

   // Create the event used to signal the shutdown of the demo thread
   g_hEndEvent = CreateEvent( NULL, TRUE, FALSE, NULL ) ;
   if ( !g_hEndEvent )
      return FALSE ;

   // Initialize demo state data
   InitDemoReality() ;

   // Create the thread used to maintain game logic, take input, etc.
   g_hDemoThread = CreateThread( NULL, 0, DemoThreadFunc, NULL, 0, &dwID ) ;

   return g_hDemoThread != NULL ;
}


/******************************************************************************
FUNCTION: InitDemoReality
This function initializes state information for the demo.  This includes a
structure to maintain velocity and coordinates for the "person" etc.

Updated for DirectSound.  Initializes demo objects to show features of
DirectSound.

PARAMETERS:
None

RETURNS:
None
******************************************************************************/
void InitDemoReality( void )
{
   int   nIndex ;
   RECT  rect ;

   // Clear the array of pointers to people.  This currently includes future
   // support for multiple persons for the networked version of the demo.
   for ( nIndex = 0 ; nIndex < MAXPERSON ; nIndex++ )
   {
      g_arrayPeople[nIndex] = NULL ;
   }

   // Allocate a new demo structure
   g_arrayPeople[0] = new DemoPerson ;

   // Center person and set their velocity to 0
   GetClientRect( g_hMainWnd,&rect ) ;

   g_arrayPeople[0]->m_nX = rect.right/2 ;
   g_arrayPeople[0]->m_nY = rect.bottom/2 ;
   g_arrayPeople[0]->m_nVX = 0 ;
   g_arrayPeople[0]->m_nVY = 0 ;
   g_arrayPeople[0]->m_bAction = FALSE ;

   // Setup audio objects for demo

   // Setup listener structure
   // Center the listener object
   g_stateListener.m_fnFaceX = 0 ;
   g_stateListener.m_fnFaceY = -1 ;      
   g_stateListener.m_nXPos = rect.right/2 ;
   g_stateListener.m_nYPos = rect.bottom/2 ;   
   g_stateListener.m_nAngle = 0 ;
   g_stateListener.m_bChanged = FALSE ;
   g_stateListener.m_bRotating = FALSE ;

   // Call function found in DXSound.CPP to actually setup
   // positioning information for the listener
   SetListenerPos( &g_stateListener, FALSE ) ; //-- DXSound.h

   // Setup dopplar structure   
   g_stateDopplar.m_nXPos = DOPPLARBEGIN ;
   g_stateDopplar.m_nYPos = DOPPLARBEGIN ;

   // Call function found in DXSound.CPP to actually setup
   // positioning information for the dopplar object
   SetDopplarPos( &g_stateDopplar, FALSE ) ; //-- DXSound.h

   // Call function in DXSound.CPP to begin playing
   // the dopplar object
   PlayDopplar() ; //-- DXSound.h

   // Setup cone structure
   g_stateCone.m_fnFaceX = 0 ;
   g_stateCone.m_fnFaceY = -1 ;   
   g_stateCone.m_nAngle = 0 ;
   g_stateCone.m_nXPos = (rect.right*3)/4 ;
   g_stateCone.m_nYPos = (rect.bottom*3)/4 ;   

   // Call function in DXSound.cpp to set position
   // for the cone object
   SetConePos( &g_stateCone, FALSE ) ; //-- DXSound.h

   // Call function in DXSound.cpp to begin
   // playing the cone effect
   PlayCone() ; //-- DXSound.h
}


/******************************************************************************
FUNCTION: UnInitDemoReality
This function deletes DemoPerson structures

PARAMETERS:
None

RETURNS:
None
******************************************************************************/
void UnInitDemoReality( void )
{
   int  nIndex ;

   // Delete the DemoPerson structures that have been created
   for ( nIndex = 0 ; nIndex < MAXPERSON ; nIndex++ )
   {
      if ( g_arrayPeople[nIndex] )
         delete g_arrayPeople[nIndex] ;
   }
}


/******************************************************************************
FUNCTION: TakeInput
This function calls functions in the DXInput.cpp module for retrieving
information about the current state of the joystick, and keyboard.  It then
applies this information to the veloccity portion of the demo person 
structure.  This function is called 32 times a second by the demo thread.

PARAMETERS:
None

RETURNS:
None
******************************************************************************/
void TakeInput( void )
{
   int   nX, nY ;
   BOOL  bButton ;

   // Save the history on the button, this is so that we can respond to
   // the trigger button being released
   g_arrayPeople[0]->m_bActionHistory = g_arrayPeople[0]->m_bAction ;

   // Get joystick information and update the velocity members of the
   // DemoPerson structure.  If this fails or the joystick state
   // is in the deadzone then move on, otherwise return.
   if ( GetJoystickInput( &nX, &nY, &bButton ) ) // -- DXInput.h
   {
      g_arrayPeople[0]->m_nVX = (15*nX)/100 ;
      g_arrayPeople[0]->m_nVY = (15*nY)/100 ;
      g_arrayPeople[0]->m_bAction = bButton ;
      if ( nX || nY || bButton )
         return ;
   }

   // Get keyboard information, if and only if the joystick was not
   // a success, or it was in a neutral state.
   if ( GetKeyboardInput( &nX, &nY, &bButton ) ) // -- DXInput.h
   {
      g_arrayPeople[0]->m_nVX = 15*nX ;
      g_arrayPeople[0]->m_nVY = 15*nY ;
      g_arrayPeople[0]->m_bAction = bButton ;
   }
}


/******************************************************************************
FUNCTION: UpdateReality
After input has been taken, this function uses the velocity and button values
in the DemoPerson struct to update the coordinates of the person.  This
function is called 32 times a second by the demo thread.

Updated for DirectSound.  This function recalculates new positions for all of
the demo objects which show features of DirectSound.  It then calls functions
implemented in DXSound.cpp which will actually effect the DirectSound objects.

PARAMETERS: 
None

RETURNS:
None
******************************************************************************/
void UpdateReality( void )
{
   RECT     rect ;
   FPOINT   fpt ;

   // How big is our window... lets shrink the rect some to set up some borders
   GetClientRect( g_hMainWnd, &rect ) ;
   InflateRect( &rect, -16, -32 ) ;

   // If we hit the right or left wall, reverse velocity, and bump the force
   // feedback.
   if ( g_arrayPeople[0]->m_nX <= rect.left && g_arrayPeople[0]->m_nVX < 0 )
   {
      // Play a force feedback effect -- DXInput.h      
      ForceEffect( FEFFECT_BUMPRIGHT ) ;
      g_arrayPeople[0]->m_nVX = -g_arrayPeople[0]->m_nVX*2 ;

      // Play ouch left sound -- DXSound.h
      PlayOuch( g_arrayPeople[0]->m_nX, g_arrayPeople[0]->m_nY, TRUE ) ;
   } else if ( g_arrayPeople[0]->m_nX >= ( rect.right-1 )
              && g_arrayPeople[0]->m_nVX > 0 )
   {
      // Play a force feedback effect -- DXInput.h
      ForceEffect( FEFFECT_BUMPLEFT ) ;
      g_arrayPeople[0]->m_nVX = -g_arrayPeople[0]->m_nVX*2 ;

      // Play ouch right sound -- DXSound.h
      PlayOuch( g_arrayPeople[0]->m_nX, g_arrayPeople[0]->m_nY, TRUE ) ;
   }

   // If we hit the top or bottom wall, reverse velocity, and bump the force
   // feedback.
   if ( g_arrayPeople[0]->m_nY <= rect.top && g_arrayPeople[0]->m_nVY < 0 )
   {
      // Play a force feedback effect -- DXInput.h
      ForceEffect( FEFFECT_BUMPDOWN ) ;
      g_arrayPeople[0]->m_nVY = -g_arrayPeople[0]->m_nVY*2 ;

      // Play ouch top -- DXSound.h
      PlayOuch( g_arrayPeople[0]->m_nX, g_arrayPeople[0]->m_nY, TRUE ) ;
   } else if ( g_arrayPeople[0]->m_nY >= ( rect.bottom-1 )
              && g_arrayPeople[0]->m_nVY > 0 )
   {
      // Play a force feedback effect -- DXInput.h
      ForceEffect( FEFFECT_BUMPUP ) ;
      g_arrayPeople[0]->m_nVY = -g_arrayPeople[0]->m_nVY*2 ;

      // Play ouch bottom -- DXSound.h
      PlayOuch( g_arrayPeople[0]->m_nX, g_arrayPeople[0]->m_nY, TRUE ) ;
   }
  

   g_arrayPeople[0]->m_nX += g_arrayPeople[0]->m_nVX ;
   g_arrayPeople[0]->m_nY += g_arrayPeople[0]->m_nVY ;

   // If the button is being pressed then we will play a little sound
   // to go along with the wavy force feedback effect
   if ( g_arrayPeople[0]->m_bAction )
   {
      // Play sound --DXSound.h
      PlayDance( g_arrayPeople[0]->m_nX, g_arrayPeople[0]->m_nY, TRUE ) ;
   }

   // The the button has been released, stop playing the sound
   if ( g_arrayPeople[0]->m_bActionHistory != g_arrayPeople[0]->m_bAction
        && !g_arrayPeople[0]->m_bAction )
   {
      // Stop sound -- DXSound.h
      StopDance() ;
   }

   // If we recieved a mouse message which indicates that the left
   // button has been pressed, then we rotate the listener position
   if ( g_stateListener.m_bRotating )
   {
      g_stateListener.m_nAngle+=10 ;
      if ( g_stateListener.m_nAngle>360 )
         g_stateListener.m_nAngle-=360 ;

      fpt.y = -1 ;
      fpt.x = 0 ;
      // Call a little function to give us a vector from an angle
      RotatePoint( &fpt, 360-g_stateListener.m_nAngle ) ; //-- Demo.cpp
      g_stateListener.m_fnFaceX = fpt.y ;
      g_stateListener.m_fnFaceY = fpt.x ;
      g_stateListener.m_bChanged = TRUE ;
            
   }

   // If the listener struct has changed then call a function
   // to apply the information to the DirectSound listener
   // object.
   if ( g_stateListener.m_bChanged )
      // -- DXSound.h
      g_stateListener.m_bChanged = !SetListenerPos( &g_stateListener, TRUE ) ;

   // Update dopplar object's position
   g_stateDopplar.m_nXPos+=10 ;
   g_stateDopplar.m_nYPos+=10 ;
   if ( g_stateDopplar.m_nXPos > DOPPLAREND )
   {
      g_stateDopplar.m_nXPos = DOPPLARBEGIN ;
      g_stateDopplar.m_nYPos = DOPPLARBEGIN ;
   }
   // Call a function to actually change the DirectSound object's information
   SetDopplarPos( &g_stateDopplar, TRUE ) ;//-- DXSound.h

   // Update cone object's orientation   
   g_stateCone.m_nAngle += 1 ;
   g_stateCone.m_nAngle %=360 ;
   fpt.y = -1 ;
   fpt.x = 0 ;
   // Retrieve a vector
   RotatePoint( &fpt, 360-g_stateCone.m_nAngle ) ;
   g_stateCone.m_fnFaceX = fpt.y ;
   g_stateCone.m_fnFaceY = fpt.x ;   

   // Call a function in DXSound.h to apply the changes to the sound
   // object.  -- DXSound.h
   SetConePos( &g_stateCone, TRUE ) ;

   // You will notice that all of the functions that effect the 3D features
   // of DirectSound in DXSound.h have a bool for "deferred".  When updating
   // the demo reality we pass a TRUE for this parameter.  This tells our
   // function to tell DirectSound to deferr actual changes until they are
   // committed, saving time.  This function ( implemented in DXSound.h ) calls
   // CommitDeferredSettings() which commits these changes.
   CommitChanges() ; //-- DXSound.h

}


/******************************************************************************
FUNCTION: UpdateVisuals
At this point this function simply invalidates the main window, and lets it
repaint itself at it's leasure.  This means that on a slow machine the update
can be less often than the demo actually takes input and updates itself.

PARAMETERS:
None

RETURNS:
None
******************************************************************************/
void UpdateVisuals( void )
{
   InvalidateRect( g_hMainWnd, NULL, TRUE ) ;
}


/******************************************************************************
FUNCTION: DemoThreadFunc
This is the guts of the logic in the demo.  32 times a second this thread
updates the input and states of the demo.

PARAMETERS:
None

RETURNS:
0
******************************************************************************/
DWORD WINAPI DemoThreadFunc( LPVOID )
{

   // Loop 32 times a second until the g_hEndEvent becomes signalled.
   while ( WaitForSingleObject( g_hEndEvent, 1000/32 ) != WAIT_OBJECT_0 )
   {
      TakeInput() ;
      UpdateReality() ;
      UpdateVisuals() ;
   }
   return 0 ;
}


/******************************************************************************
FUNCTION: UnInitDemo
Signales the demo thread to end, waits for it, and then frees memory.

PARAMETERS:
None

RETURNS:
none
******************************************************************************/
void UnInitDemo( void )
{
   SetEvent( g_hEndEvent ) ;
   WaitForSingleObject( g_hDemoThread, INFINITE ) ;
   CloseHandle( g_hEndEvent ) ;
   CloseHandle( g_hDemoThread ) ;
   UnInitDemoReality() ;
}


/******************************************************************************
FUNCTION: DrawPerson
Draws our person, plus the person info in the upper left corner of the window.
This is using sad GDI functions at this point, however it will be replaced
with more exciting DirectX drawing capabilities in a later article.

Updated for DirectSound.  This function is no longer appropriately named
as it also updates all other visuals for the sound objects.  It is still using
sad GDI functions to do this, but this will soon be remedied.

PARAMETERS:
None

RETURNS:
none
******************************************************************************/
void DrawPerson( HDC hdc, DemoPerson *pDP )
{
   char     szBuffer[256] ;
   RECT     rect ;
   FPOINT   fpt ;

   if ( !pDP )
      return ;

   GetClientRect( g_hMainWnd, &rect ) ;

   sprintf( szBuffer,"Listener X Coordinate:  %d\n"
               "Listener Y Coordinate:  %d\n"
               "Listener Face X:  %lf\n"
               "Listener Face Y:  %lf\n\n"               
               "Cone Angle:  %d\n"
               "Cone Face X:  %lf\n"
               "Cone Face Y:  %lf\n"
      ,g_stateListener.m_nXPos,g_stateListener.m_nYPos,
      g_stateListener.m_fnFaceX,g_stateListener.m_fnFaceY,
      g_stateCone.m_nAngle,g_stateCone.m_fnFaceX,
      g_stateCone.m_fnFaceY ) ;
   DrawText( hdc, szBuffer, -1, &rect, DT_LEFT|DT_NOCLIP ) ;

   Ellipse( hdc, (pDP->m_nX)-15, (pDP->m_nY)-30, (pDP->m_nX)+15, 
            (pDP->m_nY)-5 ) ;
   MoveToEx( hdc, (pDP->m_nX), (pDP->m_nY)-5, NULL ) ;
   LineTo( hdc, (pDP->m_nX), (pDP->m_nY)+15 ) ;
   LineTo( hdc, (pDP->m_nX)+15, (pDP->m_nY)+30 ) ;
   MoveToEx( hdc, (pDP->m_nX), (pDP->m_nY)+15, NULL ) ;
   LineTo( hdc, (pDP->m_nX)-15, (pDP->m_nY)+30 ) ;
   MoveToEx( hdc, (pDP->m_nX)+15, (pDP->m_nY), NULL ) ;
   LineTo( hdc, (pDP->m_nX)-16, (pDP->m_nY) ) ;

   // Draw Listener
   DrawDirection( hdc, g_stateListener.m_nXPos, g_stateListener.m_nYPos, 
       g_stateListener.m_nAngle, 15, &fpt ) ;

   // Draw Dopplar
   DrawDopplar( hdc, g_stateDopplar.m_nXPos, g_stateDopplar.m_nYPos ) ;

   //Draw Cone
   DrawCone( hdc, g_stateCone.m_nXPos, g_stateCone.m_nYPos, g_stateCone.
       m_nAngle, 20, &fpt ) ;
   //Ellipse( hdc, g_stateCone.m_nXPos-2, g_stateCone.m_nYPos-2, 
       //g_stateCone.m_nXPos+2, g_stateCone.m_nYPos+2 ) ;
   
}


/******************************************************************************
FUNCTION: DrawDopplar
Called by Draw person this function draws the "space ship" which provides
visual feedback for the dopplar sound object.

PARAMETERS:
None

RETURNS:
none
******************************************************************************/
void DrawDopplar( HDC hdc, int nX, int nY )
{
   Ellipse( hdc, g_stateDopplar.m_nXPos-20, g_stateDopplar.m_nYPos-10, 
       g_stateDopplar.m_nXPos+20, g_stateDopplar.m_nYPos+10 ) ;
   MoveToEx( hdc, g_stateDopplar.m_nXPos-20, g_stateDopplar.m_nYPos-2, NULL ) ;
   LineTo( hdc, g_stateDopplar.m_nXPos+20, g_stateDopplar.m_nYPos-2 ) ;
   MoveToEx( hdc, g_stateDopplar.m_nXPos-20, g_stateDopplar.m_nYPos+2, NULL ) ;
   LineTo( hdc, g_stateDopplar.m_nXPos+20, g_stateDopplar.m_nYPos+2 ) ;
}


/******************************************************************************
FUNCTION: RotatePoint
Used to get a vector from an angle.  Thanks to Mike Irvine for the assistance
with this code.

PARAMETERS:
None

RETURNS:
none
******************************************************************************/
void RotatePoint( LPFPOINT lppt, int nAngle )
{
   double pi2 = 3.1415926535*2 ;
   double a = lppt->x, b = lppt->y ;
   double sa,ca ;
   double fAngleRadians ;

   fAngleRadians = ( pi2 * nAngle ) / 360 ;
   

   ca = sin( fAngleRadians ) ;
   sa = cos( fAngleRadians ) ;

   lppt->x = (float)( (a * ca) + (b * sa) ) ;
   lppt->y = (float)( (a *-sa) + (b * ca) ) ;
}


/******************************************************************************
FUNCTION: DrawDirection
Called from DrawPersion, this function draws the visual feedback for the 
listener object.  Thanks to Mike Irvine for his assistance with this code.

PARAMETERS:
None

RETURNS:
none
******************************************************************************/
void DrawDirection( HDC hdc, int x, int y, int fAngle, float fScale, 
                    LPFPOINT lpfpt )
{
    int    i ;
    FPOINT fptDir[5] = {{0.0f,  0.0f}, {1.0f, 0.0f}, {0.8f, 0.2f}, 
                        {0.8f, -0.2f}, {1.0f, 0.0f}} ;
    POINT  pt[5] ;

   //Rectangle( hdc, x, y, x+3, y+3 ) ;
   //return ;

    // Adjust the points
    for ( i=0 ; i<5 ; i++ ) {
        // Scale the points
        fptDir[i].x *= fScale ;
        fptDir[i].y *= fScale ;

        // Apply the rotation
        RotatePoint( &fptDir[i], fAngle ) ;

        // Apply the translation
        pt[i].x = ( int )fptDir[i].x + x ;
        pt[i].y = ( int )fptDir[i].y + y ;
    }

    Polyline( hdc, pt, 5 ) ;

    // Calculate return vector
    lpfpt->x = 1.0f ;
    lpfpt->y = 0.0f ;
    RotatePoint( lpfpt, fAngle ) ;
}


/******************************************************************************
FUNCTION: DrawCone
Called from DrawPerson, this function draws the visual feedback for the cone
sound object. -- Thanks to Mike Irvine for kindly assisting in the writing of 
this function.

PARAMETERS:
None

RETURNS:
none
******************************************************************************/
void DrawCone( HDC hdc, int x, int y, int fAngle, float fScale, 
               LPFPOINT lpfpt )
{
    int    i ;
    FPOINT fptDir[5] = {{0.0f, 0.0f}, { 1.0f, 1.0f}, {1.0f, -1.0f}, 
                        {0.0f, 0.0f}, {-1.0f, 0.0f}} ;
    POINT  pt[5] ;

   //Rectangle( hdc, x, y, x+3, y+3 ) ;
   //return ;

    // Adjust the points
    for ( i=0 ; i<5 ; i++ ) {
        // Scale the points
        fptDir[i].x *= fScale ;
        fptDir[i].y *= fScale ;

        // Apply the rotation
        RotatePoint( &fptDir[i], fAngle ) ;

        // Apply the translation
        pt[i].x = (int)fptDir[i].x + x ;
        pt[i].y = (int)fptDir[i].y + y ;
    }

    Polyline( hdc, pt, 5 ) ;

    // Calculate return vector
    lpfpt->x = 1.0f ;
    lpfpt->y = 0.0f ;
    RotatePoint( lpfpt, fAngle ) ;
}
