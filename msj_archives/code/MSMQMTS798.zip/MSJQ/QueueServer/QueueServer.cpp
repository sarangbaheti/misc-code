// QServer.cpp - MSMQ Queue Server main 

// Copyright (c) 1998, Microsoft Corporation.  All rights reserved.

// This source code is intended only as a supplement to Microsoft
// Development Tools and/or on-line documentation.  See these other
// materials for detailed information regarding Microsoft code samples.
 
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.

#include "stdafx.h"

#include "..\Queue\Queue.h"
#include "..\Queue\Queue_i.c"

#include "..\MessageServer\MessageServer.h"
#include "..\MessageServer\MessageServer_i.c"

//===================================
// Static helper functions
//===================================

static inline void ReportHR(HRESULT hr, const char * pszVerb)
{
	if (hr) _RPTF2(FAILED(hr) ? _CRT_ERROR : _CRT_WARN, "%s hr 0x%x\n", pszVerb, hr); 
}

//====================================
// Queue Server main
//===================================

HRESULT _cdecl main()
{
	HRESULT hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);	// initialize COM library
	ReportHR(hr, "CoInitializeEx");
	if(SUCCEEDED(hr))
	{
		// Create new Queue COM Object

		CComPtr<IQueue> pIQueue;
		hr = CoCreateInstance(	CLSID_Queue, NULL, CLSCTX_INPROC_SERVER,
								IID_IQueue, (void **) &pIQueue);
		ReportHR(hr, "CoCreateInstance CLSID_Queue");
		if (SUCCEEDED(hr))
		{
			// Open input queue
			hr = pIQueue->Open(L".\\MSJQueue", MQ_RECEIVE_ACCESS);
			ReportHR(hr, "pIQueue->Open");
			if (SUCCEEDED(hr))
			{
				// Create a COM MessageServer object to process
				// messages transactionally.

				CComPtr<IMessageServer> pIMessageServer;
				hr = CoCreateInstance(	CLSID_MessageServer, NULL, CLSCTX_INPROC_SERVER,
										IID_IMessageServer, (void **) &pIMessageServer);
				ReportHR(hr, "CoCreateInstance CLSID_MessageServer");

				while(SUCCEEDED(hr))
				{
					// Wait for a message to arrive, or for 60 seconds
					hr = pIQueue->AwaitMessage(60000);
					if (SUCCEEDED(hr))
					{
						ReportHR(hr, "pIQueue->AwaitMessage");

						// Process the message inside a transaction.
						
						hr = pIMessageServer->DoWork(pIQueue);
						ReportHR(hr, "pIMessageServer->DoWork");
					}
					else if (hr == MQ_ERROR_IO_TIMEOUT)
					{
						// Treat queue timeout as a retriable warning
						_RPTF0(_CRT_WARN, "pIQueue->AwaitMessage timeout\n");
						hr = S_OK;
					}
					else	// any unexpected error
						ReportHR(hr, "pIQueue->AwaitMessage");
				}
			}
		}
		CoUninitialize();
	}
	return hr;
}