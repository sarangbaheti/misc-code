// MessageServerImp.cpp : Implementation of CMessageServer

// Copyright (c) 1998, Microsoft Corporation.  All rights reserved.

// This source code is intended only as a supplement to Microsoft
// Development Tools and/or on-line documentation.  See these other
// materials for detailed information regarding Microsoft code samples.
 
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.

#include "stdafx.h"

#include <adoid.h>
#include <adoint.h>

#include "MessageServer.h"
#include "MessageServerImp.h"
#include "..\Queue\Queue.h"
#include "..\Queue\Queue_i.c"
#include "..\MessageFormat.h"

//===========================
// Helper functions
//===========================

static inline void DisplayHR(HRESULT hr, const char * pszVerb)
{
	_RPTF2(SUCCEEDED(hr) ? _CRT_WARN : _CRT_ERROR, "%s hr 0x%x\n", pszVerb, hr); 
}


static void DisplayErrorInfo(HRESULT hr, const char * pszVerb)
{
	CComPtr<IErrorInfo> pErrorInfo;
	GetErrorInfo(NULL, &pErrorInfo);

	CComBSTR bstrDesc;
	if (pErrorInfo) pErrorInfo->GetDescription(&bstrDesc);

	_RPTF3(_CRT_WARN, "%s HRESULT 0x%x\n%ls\n", pszVerb, hr, bstrDesc);
	fprintf(stderr,   "%s HRESULT 0x%x\n%ls\n", pszVerb, hr, bstrDesc);
}


// Process input message by inserting a row into the database

static HRESULT ProcessBuffer(BYTE * pbBuffer, DWORD dwcbBuffer, 
							 DWORD dwTimeSent, DWORD dwTimeArrived)						 
{
	time_t timeReceived;
	time( &timeReceived);		// current time of day

	CComPtr<ADOConnection> pADOConnection;

	HRESULT hr = CoCreateInstance(CLSID_CADOConnection, NULL, CLSCTX_INPROC_SERVER,
				IID_IADOConnection, (void **) &pADOConnection);

	if (hr != S_OK) DisplayHR(hr, "CoCreateInstance CLSID_CADOConnection");
	if (SUCCEEDED(hr))
	{
		// Connect to the database
		CComBSTR bstrDSN = L"FILEDSN=MSJQ";
		CComBSTR bstrUserID = L"sa";

		hr = pADOConnection->Open(bstrDSN, bstrUserID, NULL, adOpenUnspecified);

		if (FAILED(hr)) DisplayErrorInfo(hr, "pADOConnection->Open");
		if (SUCCEEDED(hr))
		{	
			// Format a SQL statement and insert a row into our table

			USES_CONVERSION;		// ANSI to TCHAR string conversion

			PMESSAGEFORMAT pMF = reinterpret_cast<PMESSAGEFORMAT>(pbBuffer);

			_RPTF2(	_CRT_WARN, "ProcessBuffer %d %s\n",
					pMF->dwMessageIndex, pMF->get_pString1());

			TCHAR szSQLStmt[1024];	// SQL statement buffer

			const LPCTSTR pszPrototypeInsertStmt =
				_T("insert into MSJQTable ")
				_T(	"(time_created, time_sent, time_arrived, time_received, message_index, string_1, string_2) ")
				_T(	"values( %ld, %ld, %ld, %ld, %ld, \'%s\', \'%s\' )" );
		
			// Convert input character strings to WCHAR strings

			PTSTR ptstr1 = A2T(pMF->get_pString1());
			PTSTR ptstr2 = A2T(pMF->get_pString2());

			// Compose the insert statement, with substitutions

			wsprintf(	szSQLStmt,
						pszPrototypeInsertStmt,
						pMF->timeCreated,
						dwTimeSent,
						dwTimeArrived, 
						timeReceived,
						pMF->dwMessageIndex,
						ptstr1,
						ptstr2);
							
			CComBSTR bstrSQL = szSQLStmt;	// convert to a BSTR

			// Add a row to the table
			hr = pADOConnection->Execute(bstrSQL, NULL, adCmdText, NULL);
			if (FAILED(hr)) 
				DisplayErrorInfo(hr, "pADOConnection->Execute");
		}
	}
	return hr;
}

//===========================
// IMessageServer methods
//===========================

STDMETHODIMP CMessageServer::DoWork(IUnknown * punkIQueue)
{
	HRESULT hr = E_NOINTERFACE;
	CComQIPtr<IQueue, &IID_IQueue> pIQueue(punkIQueue);
	if (pIQueue)
	{
		BYTE *	 pbBuffer = 0;
		DWORD	 dwcbBuffer = 0;
		hr = pIQueue->Receive(&pbBuffer, &dwcbBuffer);
		if (hr != S_OK) DisplayHR(hr, "pIQueue->Receive");
		if (SUCCEEDED(hr))
		{
			DWORD dwtimeSent, dwtimeArrived;
			pIQueue->GetTimeSent(&dwtimeSent);
			pIQueue->GetTimeArrived(&dwtimeArrived);

			// Process the input message

			hr = ProcessBuffer(pbBuffer, dwcbBuffer, dwtimeSent, dwtimeArrived);

			if (hr != S_OK) DisplayHR(hr, "ProcessBuffer");

			// Free the input message buffer
			pIQueue->FreeBuffer(pbBuffer);
			pbBuffer = 0;
		}
	}

	CComPtr<IObjectContext> pIObjectContext;
	HRESULT hrGetContext = GetObjectContext(&pIObjectContext);

	if (SUCCEEDED(hrGetContext))
	{
		// SetComplete or SetAbort based on results
		if (SUCCEEDED(hr))
		{
			HRESULT hrSetComplete = pIObjectContext->SetComplete();
			if (hrSetComplete != S_OK) DisplayHR(hrSetComplete, "SetComplete");
		}
		else
		{
			HRESULT hrSetAbort = pIObjectContext->SetAbort();
			if (hrSetAbort != S_OK) DisplayHR(hrSetAbort, "SetAbort");
		}
	}
	return hr;
}

