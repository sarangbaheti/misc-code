#include "stdafx.h"

#include <atlimpl.cpp>
