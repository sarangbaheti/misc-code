// stdafx.h - standard include file

#ifndef _STDAFX_H_
#define _STDAFX_H_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define STRICT

#define _WIN32_WINNT 0x0400
#define _ATL_APARTMENT_THREADED

#include <atlbase.h>
#include <crtdbg.h>
#include <mq.h>
#include <stdio.h>

#endif // _STDAFX_H_
