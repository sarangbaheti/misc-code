// Client.cpp - Insert messages into a queue
// Copyright (c) 1998, Microsoft Corporation.  All rights reserved.

// This source code is intended only as a supplement to Microsoft
// Development Tools and/or on-line documentation.  See these other
// materials for detailed information regarding Microsoft code samples.
 
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.

#include "stdafx.h"

#include "..\MessageFormat.h"
#include "..\queue\Queue.h"
#include "..\queue\Queue_i.c"

const int MESSAGE_COUNT = 10;

//===========================
// Static helper functions
//===========================

static inline HRESULT CheckHresult(HRESULT hr, LPCSTR pszVerb)
{
	if (hr != S_OK)
	{
		fprintf(stderr, "%s hr 0x%x\n", pszVerb, hr);
		_RPTF2(FAILED(hr) ? _CRT_ERROR : _CRT_WARN, "%s hr 0x%x\n", pszVerb, hr); 
	}
	return hr;
}

//===================================
// Client main
//===================================

HRESULT _cdecl main(int argc, char * argv[])
{
	HRESULT hr = CoInitializeEx(NULL,COINIT_MULTITHREADED);	// initialize COM library
	CheckHresult(hr, "CoInitializeEx");
	if (SUCCEEDED(hr))
	{
		CComPtr<IQueue> pIQueue;

		hr = CoCreateInstance(	CLSID_Queue, NULL, CLSCTX_INPROC_SERVER,
								IID_IQueue, (void **) &pIQueue);
		CheckHresult(hr, "CoCreateInstance CLSID_Queue");
		if (SUCCEEDED(hr))
		{
			WCHAR * pwszQueuePath = L".\\MSJQueue";	// default queue name

			if (argc >= 2)		// queue name provided on command line?
			{
				USES_CONVERSION;
				pwszQueuePath = A2W(argv[1]);	// open named queue
			}

			hr = pIQueue->Open(pwszQueuePath, MQ_SEND_ACCESS);
			if (FAILED(hr))
			{
				CheckHresult(hr, "pIQueue->Open");
				fprintf(stderr, "Unable to open queue named %ls\n", pwszQueuePath);
				fprintf(stderr, 
						"queue name format is: ServerName\\QueueName\n"
						"or a format name of the form: PUBLIC=473C53AF-9BFB-11D1-8048-00C04FC340EE\n");
			}

			for (long i = 1; i <= MESSAGE_COUNT && SUCCEEDED(hr); i++)
			{
				BYTE buffer[100];
				PMESSAGEFORMAT pMF = reinterpret_cast<PMESSAGEFORMAT>(buffer);
				pMF->dwSignature = MESSAGEFORMAT.SIGNATURE;
				pMF->dwVersion   = MESSAGEFORMAT.VERSION;
				time(&pMF->timeCreated);
				pMF->dwMessageIndex = i;
				pMF->dwcbString1 = 1 + wsprintf(pMF->get_pString1(), "String 1 of message %d, ", i);
				pMF->dwcbString2 = 1 + wsprintf(pMF->get_pString2(), "String 2");
				DWORD dwcbBuffer = sizeof(MESSAGEFORMAT) + pMF->dwcbString1 + pMF->dwcbString2;
				hr = pIQueue->Send(buffer, dwcbBuffer);
				CheckHresult(hr, "pIQueue->Send");
			}
		}						// SUCCEEDED(CoInitialize)
		CoUninitialize();		// Release COM libraries
	}
	return hr;
}
