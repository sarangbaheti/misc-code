// QueueImp.cpp : Implementation of CQueue

// Copyright (c) 1998, Microsoft Corporation.  All rights reserved.

// This source code is intended only as a supplement to Microsoft
// Development Tools and/or on-line documentation.  See these other
// materials for detailed information regarding Microsoft code samples.
 
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.

#include "stdafx.h"
#include "Queue.h"
#include "QueueImp.h"
#include <mtx.h>

const int FORMAT_NAME_SIZE = 54;	// format name expected max length

//===========================
// Static helper functions
//===========================

static inline void ReportHR(HRESULT hr, LPCSTR pszVerb)
{
	// Return quietly if hr == S_OK.
	// Issue a warning diagnostic message if SUCCEEDED(hr) but not S_OK.
	// Issue an error (message box) diagnostic message if FAILED(hr).

	_RPTF2(SUCCEEDED(hr) ? _CRT_WARN : _CRT_ERROR, "%s hr 0x%x\n", pszVerb, hr); 
}


static bool IsMTSContextAvailable()
{
	// Determine if we are running in MTS

	IObjectContext * pIObjectContext = 0;	// MTS context pointer

	HRESULT hr = GetObjectContext(&pIObjectContext);// get MTS context
	if (FAILED(hr))						// no context available
	{
		// Issue warning diagnostic only
		_RPTF1(_CRT_WARN, "GetObjectContext hr 0x%x\n", hr);
		return false;					// No context ==> Not in MTS
	}
	pIObjectContext->Release();
	pIObjectContext = 0;
	return true;					// context available ==> In MTS
}


static bool IsFormatName(LPCWSTR pszName)
{
	// returns true if pszName prefix indicates name is an MSMQ Format Name
	if (0 == _wcsnicmp(pszName, L"PUBLIC=", 7) ||
		0 == _wcsnicmp(pszName, L"PRIVATE=", 8))
		return true;
	else
		return false;
}

//===========================
// CQueue::Open
//===========================

STDMETHODIMP CQueue::Open(LPCWSTR pwszQueueOrFormatName, DWORD dwAccess)
{
	Close();

	HRESULT hr = S_OK;

	m_pwszQueueOrFormatName = _wcsdup(pwszQueueOrFormatName); // Save input name

	// Obtain queue's Format Name

	if (IsFormatName(pwszQueueOrFormatName))	// Input name is already a format name
	{
		// Use caller's name "as is" without conversion to a format name
		m_pwszFormatName = _wcsdup(pwszQueueOrFormatName);
	}
	else	// queue name is taken to be a path name
	{
		// Convert path name to Format Name, using the MQIS

		// MSMQ doesn't document a maximum FORMAT_NAME_SIZE, so we
		// make a reasonable guess and provide an expanding buffer.

		DWORD dwNumChars = FORMAT_NAME_SIZE;

		do {
			delete [] m_pwszFormatName;
			m_pwszFormatName = new WCHAR[dwNumChars];

			hr = MQPathNameToFormatName(pwszQueueOrFormatName, m_pwszFormatName, &dwNumChars);
			if (hr) ReportHR(hr, "MQPathNameToFormatName");

		} while (hr == MQ_ERROR_FORMATNAME_BUFFER_TOO_SMALL);

	}	// else queue name is a path name

	// Now open the queue

	if (SUCCEEDED(hr))
	{
		hr = MQOpenQueue(m_pwszFormatName, dwAccess, MQ_DENY_NONE, &m_qh);
		if (hr) ReportHR(hr, "MQOpenQueue");
	}
	return hr;
}

//===========================
// CQueue::Close
//===========================

STDMETHODIMP CQueue::Close()
{
	HRESULT hr = S_OK;

	if (m_qh)
	{
		hr = MQCloseQueue(m_qh);
		if (hr) ReportHR(hr, "MQCloseQueue");
		m_qh = 0;
	}

	delete [] m_pwszQueueOrFormatName;
	m_pwszQueueOrFormatName = 0;

	delete [] m_pwszFormatName;
	m_pwszFormatName = 0;

	return hr;
}

//===========================
// CQueue::GetTimeSent
//===========================

STDMETHODIMP CQueue::GetTimeSent(DWORD * ptimeSent)
{
	_ASSERTE(ptimeSent);
	*ptimeSent = m_dwTimeSent;
	return S_OK;
}

//===========================
// CQueue::GetTimeArrived
//===========================

STDMETHODIMP CQueue::GetTimeArrived(DWORD * ptimeArrived)
{
	_ASSERTE(ptimeArrived);
	*ptimeArrived = m_dwTimeArrived;
	return S_OK;
}

//===========================
// CQueue::Send
//===========================

STDMETHODIMP CQueue::Send(const BYTE * pbBuffer, DWORD dwcbBuffer)
{
	_ASSERTE(pbBuffer);
	_ASSERTE(m_qh);

	const int cProperties = 1;	// number of message properties

	MSGPROPID		rgMsgPropId[cProperties];		// property ids
	MQPROPVARIANT	rgMqPropVariant[cProperties];	// property variants
	HRESULT			rghr[cProperties];

	MQMSGPROPS	MqMsgProps = {cProperties, rgMsgPropId, rgMqPropVariant, rghr};

	rgMsgPropId[0]					= PROPID_M_BODY;
	rgMqPropVariant[0].vt			= VT_UI1 | VT_VECTOR;
	rgMqPropVariant[0].caub.pElems	= const_cast<BYTE *>(pbBuffer);
	rgMqPropVariant[0].caub.cElems	= dwcbBuffer;
	rghr[0]							= S_OK;

	// Develop the right value for the pTransaction parameter.

	// Note: This code assumes that the queue is a transacted queue.
	// We could extract the queue's transactional attribute with
	// MQGetQueueProperties(), but that requires MQIS access.

	ITransaction * pTransaction = 
		IsMTSContextAvailable() ? MQ_MTS_TRANSACTION : MQ_SINGLE_MESSAGE;
	
	HRESULT hr = MQSendMessage(m_qh, &MqMsgProps, pTransaction);
	if (hr) ReportHR(hr, "MQSendMessage");
	return hr;
}

//===========================
// CQueue::AwaitMessage
//===========================

STDMETHODIMP CQueue::AwaitMessage(DWORD dwTimeOut)
{
	_ASSERTE(m_qh);

	const int cProperties = 1;	// number of message properties

	MSGPROPID		rgMsgPropId[cProperties];		// property ids
	MQPROPVARIANT	rgMqPropVariant[cProperties];	// property variants
	HRESULT			rghr[cProperties];				// status results

	MQMSGPROPS	MqMsgProps = {cProperties, rgMsgPropId, rgMqPropVariant, rghr};

	rgMsgPropId[0]			= PROPID_M_BODY_SIZE;
	rgMqPropVariant[0].vt	= VT_UI4;
	rghr[0]					= S_OK;

	// Wait for a message to arrive.  Fetch just its body size.
	// We can't wait within a transaction.

	HRESULT hr = MQReceiveMessage(	m_qh,					// hSource
									dwTimeOut,				// dwTimeout
									MQ_ACTION_PEEK_CURRENT,	// dwAction
									&MqMsgProps,			// pMessageProps
									NULL,					// lpOverlapped
									NULL,					// fnReceiveCallback
									NULL,					// hCursor
									MQ_NO_TRANSACTION);		// pTransaction
		
	m_dwcbMessageBody = rgMqPropVariant[0].ulVal;	// save message length hint

	// Treat a Receive timeout error as a warning.

	if (hr == MQ_ERROR_IO_TIMEOUT)
		_RPTF0(_CRT_WARN, "CQueue::AwaitMessage MQReceiveMessage MQ_ERROR_IO_TIMEOUT\n");
	else if (hr) ReportHR(hr, "CQueue::AwaitMessage MQReceiveMessage");

	return hr; 
}

//===========================
// CQueue::Receive
//===========================

STDMETHODIMP CQueue::Receive(BYTE * * ppbBuffer, DWORD * pdwcbBuffer)
{
	if (!ppbBuffer)		return E_POINTER;
	if (!pdwcbBuffer)	return E_POINTER;

	_ASSERTE(m_qh);			// open queue required

	const int cProperties = 4;	// number of message properties

	MSGPROPID		rgMsgPropId[cProperties];		// property ids
	MQPROPVARIANT	rgMqPropVariant[cProperties];	// property variants
	HRESULT			rghr[cProperties];

	MQMSGPROPS	MqMsgProps = {cProperties, rgMsgPropId, rgMqPropVariant, rghr};

	rgMsgPropId		[0]		= PROPID_M_BODY;		// Message content (the body)
	rgMqPropVariant	[0].vt	= VT_UI1 | VT_VECTOR;
	rghr			[0]		= S_OK;

	rgMsgPropId		[1]		= PROPID_M_BODY_SIZE;	// Length of body
	rgMqPropVariant	[1].vt	= VT_UI4;
	rghr			[1]		= S_OK;

	rgMsgPropId		[2]		= PROPID_M_SENTTIME;	// Time message was sent
	rgMqPropVariant [2].vt	= VT_UI4;
	rghr			[2]		= S_OK;

	rgMsgPropId		[3]		= PROPID_M_ARRIVEDTIME;	// Time message arrived on queue
	rgMqPropVariant [3].vt	= VT_UI4;
	rghr			[3]		= S_OK;

	// Use a transacted receive if MTS context is available

	ITransaction * pTransaction = 
		IsMTSContextAvailable() ? MQ_MTS_TRANSACTION : MQ_NO_TRANSACTION;

	// MQReceiveMessage with expanding buffer

	HRESULT	hr;
	BYTE *	pBuffer = 0;		// start with no initial buffer

	do {
		delete [] pBuffer;
		pBuffer = 0;

		hr = E_OUTOFMEMORY;		// prepare for no-memory error

		// Use minimum buffer size to avoid new BYTE[0]
		m_dwcbMessageBody = max(m_dwcbMessageBody, 1);

		pBuffer = new BYTE[m_dwcbMessageBody];
		if (pBuffer)
		{
			rgMqPropVariant[0].caub.pElems = pBuffer;
			rgMqPropVariant[0].caub.cElems = m_dwcbMessageBody;

			hr = MQReceiveMessage(	m_qh,					// hSource
									0,						// dwTimeout
									MQ_ACTION_RECEIVE,		// dwAction
									&MqMsgProps,			// pMessageProps
									NULL,					// lpOverlapped
									NULL,					// fnReceiveCallback
									NULL,					// hCursor
									pTransaction);

			m_dwcbMessageBody	= rgMqPropVariant[1].ulVal;
			m_dwTimeSent		= rgMqPropVariant[2].ulVal;
			m_dwTimeArrived		= rgMqPropVariant[3].ulVal;

			if (hr == MQ_ERROR_BUFFER_OVERFLOW)
				_RPTF1(_CRT_WARN, "MQReceiveMessage MQ_ERROR_BUFFER_OVERFLOW size = %d\n", m_dwcbMessageBody);
		}
	} while (hr == MQ_ERROR_BUFFER_OVERFLOW);

	if (hr) ReportHR(hr, "CQueue::Receive MQReceiveMessage");
	if (SUCCEEDED(hr))
	{
		*ppbBuffer		= pBuffer;
		*pdwcbBuffer	= m_dwcbMessageBody;
	}
	else
	{
		delete [] pBuffer;
		pBuffer = 0;

		*ppbBuffer		= 0;
		*pdwcbBuffer	= 0;
	}
	return hr;
}

//===========================
// CQueue::FreeBuffer
//===========================

STDMETHODIMP CQueue::FreeBuffer(BYTE * pbBuffer)
{
	delete [] pbBuffer;
	return S_OK;
}
