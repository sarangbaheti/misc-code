	
// QueueImp.h : Declaration of the CQueue

#ifndef __QUEUE_H_
#define __QUEUE_H_

#include <mq.h>
#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CQueue
class ATL_NO_VTABLE CQueue : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CQueue, &CLSID_Queue>,
	public IQueue
{
public:
	CQueue() :	m_qh(0), 
				m_pwszFormatName(NULL), 
				m_pwszQueueOrFormatName(NULL),
				m_pUnkMarshaler(NULL)
	{
	}
	~CQueue()
	{
		Close();
	}

DECLARE_REGISTRY_RESOURCEID(IDR_QUEUE)
DECLARE_NOT_AGGREGATABLE(CQueue)
DECLARE_GET_CONTROLLING_UNKNOWN()

BEGIN_COM_MAP(CQueue)
	COM_INTERFACE_ENTRY(IQueue)
	COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)
END_COM_MAP()

	HRESULT FinalConstruct()
	{
		return CoCreateFreeThreadedMarshaler(
			GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
		m_pUnkMarshaler.Release();
	}

	CComPtr<IUnknown> m_pUnkMarshaler;

// IQueue
public:
	STDMETHOD(FreeBuffer)(/*[in]*/ BYTE * pbBuffer);
	STDMETHOD(Receive)(/*[out]*/ BYTE ** ppbBuffer, /*[out]*/ DWORD * pdwcbBuffer);
	STDMETHOD(AwaitMessage)(/*[in]*/ DWORD dwTimeOut);
	STDMETHOD(Send)(/*[in]*/ const BYTE * pbBuffer, /*[in]*/ DWORD dwcbBuffer);
	STDMETHOD(GetTimeArrived)(/*[out]*/ DWORD * pdwTimeArrived);
	STDMETHOD(GetTimeSent)(/*[out]*/ DWORD * ptimeSent);
	STDMETHOD(Close)();
	STDMETHOD(Open)(/*[in]*/ LPCWSTR pwszQueueOrFormatName, /*[in]*/ DWORD dwAccess);
private:
	DWORD		m_dwTimeArrived;			// Last message
	DWORD		m_dwTimeSent;				// Last message
	DWORD		m_dwcbMessageBody;			// Last message
	LPWSTR		m_pwszFormatName;			// Result of MQIS lookup
	LPWSTR		m_pwszQueueOrFormatName;	// Open parameter
	QUEUEHANDLE	m_qh;
};

#endif //__QUEUE_H_
