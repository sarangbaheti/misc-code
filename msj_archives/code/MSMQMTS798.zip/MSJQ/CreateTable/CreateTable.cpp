// Creates a table for use by MSJQ Sample problem

// Copyright (c) 1998, Microsoft Corporation.  All rights reserved.

// This source code is intended only as a supplement to Microsoft
// Development Tools and/or on-line documentation.  See these other
// materials for detailed information regarding Microsoft code samples.
 
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.

#include "stdafx.h"

#include <initguid.h>
#include <adoid.h>
#include <adoint.h>

//===========================
// Helper functions
//===========================

static inline void DisplayHR(HRESULT hr, const char * pszVerb)
{
	_RPTF2(FAILED(hr) ? _CRT_ERROR : _CRT_WARN, "%s hr 0x%x\n", pszVerb, hr); 
}


static void DisplayErrorInfo(HRESULT hr, const char * pszVerb)
{
	CComPtr<IErrorInfo> pErrorInfo;
	GetErrorInfo(NULL, &pErrorInfo);

	CComBSTR bstrDesc;
	if (pErrorInfo) pErrorInfo->GetDescription(&bstrDesc);

	_RPTF3(_CRT_WARN, "%s HRESULT 0x%x\n%ls\n", pszVerb, hr, bstrDesc);
	fprintf(stderr,   "%s HRESULT 0x%x\n%ls\n", pszVerb, hr, bstrDesc);
}

//===========================
// Main
//===========================

HRESULT _cdecl main()
{
	HRESULT hr = CoInitialize(NULL);	// init COM library
	if (hr != S_OK) DisplayHR(hr, "CoInitialize");
	if (SUCCEEDED(hr))
	{
		// Create ADO Connection object
		CComPtr<ADOConnection> pADOConnection;
		hr = CoCreateInstance(CLSID_CADOConnection, NULL, CLSCTX_INPROC_SERVER,
					IID_IADOConnection, (void **) &pADOConnection);
		if (hr != S_OK) DisplayHR(hr, "CoCreateInstance CLSID_CADOConnection");
		if (SUCCEEDED(hr))
		{
			// Connect to the Data Source
			CComBSTR bstrDSN = L"FILEDSN=MSJQ";
			CComBSTR bstrUserID = L"sa";
			hr = pADOConnection->Open(bstrDSN, bstrUserID, NULL, adOpenUnspecified);
			if (FAILED(hr)) DisplayErrorInfo(hr, "pADOConnection->Open");
			if (SUCCEEDED(hr))
			{
				// Create a SQL table
				CComBSTR bstrSQL =	L"create table MSJQTable ("
									L" time_created   int,"
									L" time_sent      int," 
									L" time_arrived   int,"
									L" time_received  int,"
									L" message_index  int,"
									L" string_1   varchar(50), "
									L" string_2   varchar(50))";

				hr = pADOConnection->Execute(bstrSQL, NULL, adCmdText, NULL);
				if (FAILED(hr)) DisplayErrorInfo(hr, "pADOConnection->Execute");
			}
			pADOConnection.Release();	// release before CoUninitialize
		}
		CoUninitialize();
	}
	return hr;
}