// MessageFormat.h - describes message passed between requestor and server

// Copyright (c) 1998, Microsoft Corporation.  All rights reserved.

// This source code is intended only as a supplement to Microsoft
// Development Tools and/or on-line documentation.  See these other
// materials for detailed information regarding Microsoft code samples.
 
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.

#ifndef _MESSAGEFORMAT_H_
#define _MESSAGEFORMAT_H_

#include <time.h>

typedef struct _MESSAGEFORMAT
{
	// put an easily recognizable signature word at the front of each message
	enum { SIGNATURE = (('Q' << 24) + ('J' << 16) + ('S' << 8) + 'M') };
	DWORD	dwSignature;

	// version control may prove useful if we wish to later change the format

	enum {	MAJOR_VERSION = 1,
			MINOR_VERSION = 3,
			VERSION = ((MAJOR_VERSION << 16) + MINOR_VERSION) };
		
	DWORD	dwVersion;

	// Sample message data
	time_t	timeCreated;	// time of day the MESSAGEFORMAT was created

	DWORD	dwMessageIndex;	// loop counter

	// In the fixed-length part of the message we describe the length
	// of two variable-length strings that follow.  

	DWORD	dwcbString1;	// strlen + 1 for trailing null	
	DWORD	dwcbString2;	// strlen + 1 for trailing null

	// The second string immediately follows first string.
	// The following function provides the address of the second string

	inline char * get_pString1() { return reinterpret_cast<char *>(this) + sizeof(struct _MESSAGEFORMAT); }
	inline char * get_pString2() { return get_pString1() + this->dwcbString1; }

} MESSAGEFORMAT, *PMESSAGEFORMAT;

#endif // _MESSAGEFORMAT_H_