#include "StdAfx.h"
#include "View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define ID_VCOLOR_FIRST ID_VIEW_WINDOW
#define ID_VCOLOR_LAST  ID_VIEW_BLUE

////////////////////////////////////////////////////////////////
// CMyView
//
IMPLEMENT_DYNCREATE(CMyView, CEditView)

BEGIN_MESSAGE_MAP(CMyView, CEditView)
	//{{AFX_MSG_MAP(CMyView)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CMyView::CMyView()
{
}

CMyView::~CMyView()
{
}

void CMyView::OnDraw(CDC* pDC)
{
	CEditView::OnDraw(pDC);
//	CMyDoc* pDoc = GetDocument();
//	ASSERT_VALID(pDoc);
}

////////////////
// Override for flicker-free drawing with no CS_VREDRAW and CS_HREDRAW.
// This has nothing to do with MyEdit, it's just a good thing to do.
//
BOOL CMyView::PreCreateWindow(CREATESTRUCT& cs)
{
/*
   cs.lpszClass = AfxRegisterWndClass(
		CS_DBLCLKS,								 // no redraw
      LoadCursor(NULL, IDC_ARROW),		 // arrow cursor
		NULL,										 // no background brush
		NULL);									 // no icon
   ASSERT(cs.lpszClass);
*/
   return CEditView::PreCreateWindow(cs);
}
