////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//

/////////////////
// Main frame window has menu manager, flatbar, status bar
//
class CMainFrame : public CFrameWnd {
public:
	CMainFrame();
	~CMainFrame();

protected:
	DECLARE_DYNCREATE(CMainFrame)
	CStatusBar				m_wndStatusBar; // standard status bar
	CToolBar					m_wndToolBar;	 // if using toolbar

	// overrides
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	// message handlers
	DECLARE_MESSAGE_MAP()
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);

	// command handlers
	afx_msg void OnToolbarDropDown(NMTOOLBAR* pnmh, LRESULT* plRes);
};
