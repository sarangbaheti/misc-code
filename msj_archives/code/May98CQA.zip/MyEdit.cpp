////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// MyEdit Shows how to use CCool UI classses to implement flat toolbars,
// coolbars and cool menus. Compiles with Visual C++ 5.0 on Windows 95.

#include "StdAfx.h"
#include "resource.h"
#include "MainFrm.h"
#include "View.h"
#include "StatLink.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////
// Standard application class
//
class CMyApp : public CWinApp {
public:
	DECLARE_DYNAMIC(CMyApp)
	virtual BOOL InitInstance();
protected:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnAppAbout();
};

BEGIN_MESSAGE_MAP(CMyApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_NEW,	 CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

IMPLEMENT_DYNAMIC(CMyApp, CWinApp)

CMyApp theApp;

BOOL CMyApp::InitInstance()
{
	SetRegistryKey("MSJ");		// Save settings in registry "MSJ", not INI file
	LoadStdProfileSettings(8); // Load standard INI file options (8 MRU files)

	// initialize coolbars. Note: assumes you have
	// comctl32.dll version 470 or greater
	//
	INITCOMMONCONTROLSEX sex;
	sex.dwSize = sizeof(INITCOMMONCONTROLSEX);
	sex.dwICC = ICC_COOL_CLASSES;
	InitCommonControlsEx(&sex);

	// Create standard doc/frame/view
	AddDocTemplate(new CSingleDocTemplate(IDR_MAINFRAME,
		RUNTIME_CLASS(CMyDoc),
		RUNTIME_CLASS(CMainFrame),
		RUNTIME_CLASS(CMyView)));

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	return ProcessShellCommand(cmdInfo);
}

//////////////////
// Custom about dialog uses CStaticLink for hyperlinks.
//    * for text control, URL is specified as text in dialog editor
//    * for icon control, URL is specified by setting m_iconLink.m_link
//
class CAboutDialog : public CDialog {
protected:
	// static controls with hyperlinks
	CStaticLink	m_wndLink1;
	CStaticLink	m_wndLink2;
	CStaticLink	m_wndLink3;
	CStaticLink	m_wndLink4;

public:
	CAboutDialog() : CDialog(IDD_ABOUTBOX) { }
	virtual BOOL OnInitDialog();
};

const TCHAR msjURL[] = _T("http://www.microsoft.com/msj");



/////////////////
// Initialize dialog: subclass static text/icon controls
//
BOOL CAboutDialog::OnInitDialog()
{
	// subclass static controls. URL is static text or 3rd arg
	m_wndLink1.SubclassDlgItem(IDC_STATICURLPD,		this);
	m_wndLink2.SubclassDlgItem(IDC_STATICURLMSJ,		this, msjURL);
	m_wndLink3.SubclassDlgItem(IDR_MSJLINK,			this, msjURL);
	m_wndLink4.SubclassDlgItem(IDC_STATICURLCOM40,	this,
		_T("http://www.microsoft.com/msdn/downloads/files/40comupd.htm"));
	return CDialog::OnInitDialog();
}

//////////////////
// Handle Help | About : run the About dialog
//
void CMyApp::OnAppAbout()
{
	static CAboutDialog dlg;
	dlg.DoModal();
}
