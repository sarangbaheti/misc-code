#include "Doc.h"

/////////////////
// Standard Edit view
//
class CMyView : public CEditView {
public:
	virtual ~CMyView();
	CMyDoc* GetDocument() { return (CMyDoc*)m_pDocument; }
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

protected:
	DECLARE_DYNCREATE(CMyView)
	CMyView();
	DECLARE_MESSAGE_MAP()
};
