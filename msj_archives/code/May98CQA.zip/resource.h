//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MyEdit.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MSJLINK                     129
#define IDR_FILEDROPDOWN                130
#define IDC_STATICURLPD                 1000
#define IDC_STATICURLMSJ                1001
#define IDC_STATICURLCOM40              1002
#define ID_VIEW_MENU_BUTTONS            32772
#define ID_DISABLED                     32773
#define ID_VIEW_FLAT                    32810
#define ID_COLOR_DISABLE                32818

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32820
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
