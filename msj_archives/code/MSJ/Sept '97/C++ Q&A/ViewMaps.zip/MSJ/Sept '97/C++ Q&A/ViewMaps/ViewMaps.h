////////////////////////////////////////////////////////////////
// VIEWMAPS 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// See VIEWMAPS.CPP for Description of program.
// 
#include "resource.h"       // main symbols

class CMyApp : public CWinApp {
public:
	DECLARE_DYNAMIC(CMyApp)
	CMyApp();
	virtual BOOL InitInstance();
protected:
	afx_msg void OnAppAbout();
	afx_msg void OnDump();
	afx_msg void OnDumpAll();
	DECLARE_MESSAGE_MAP()
};
