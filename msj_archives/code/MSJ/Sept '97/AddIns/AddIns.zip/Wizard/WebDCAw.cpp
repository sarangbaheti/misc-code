// WebDCaw.cpp : implementation file
//

#include "stdafx.h"
#include <atlbase.h>
#include <atlimpl.cpp>
#include <initguid.h>
#include <ObjModel\bldguid.h>
#include "WebDC.h"
#include "WebDCaw.h"

#ifdef _PSEUDO_DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// This is called immediately after the custom AppWizard is loaded.  Initialize
//  the state of the custom AppWizard here.
void CWebDCAppWiz::InitCustomAppWiz()
{
	SetNumberOfSteps(0);
	m_Dictionary[_T("PROJTYPE_DLL")] = _T("1");
	CreateGUIDMacros();
}

CString CWebDCAppWiz::FormatGUID(UINT resID, GUID& guid)
{
	CString strFormat;
	strFormat.LoadString(resID);

	CString strGUID;
	strGUID.Format(strFormat, 
		guid.Data1, guid.Data2, guid.Data3, 
		guid.Data4[0], guid.Data4[1], guid.Data4[2], guid.Data4[3],
		guid.Data4[4], guid.Data4[5], guid.Data4[6], guid.Data4[7]);

	return strGUID;
}

BOOL CWebDCAppWiz::CreateGUIDMacros(void)
{
	GUID guid = GUID_NULL;
	VERIFY( ::CoCreateGuid(&guid) == S_OK );
	CString strGUID;

	// The 1st GUID is the TLID of the ActiveX Control

	guid.Data1++;
	strGUID = FormatGUID(IDS_GUID_EQUALS, guid);
	m_Dictionary[_T("GUID1_EQUALS")] = strGUID;
	strGUID = FormatGUID(IDS_GUID_TEXT, guid);
	m_Dictionary[_T("GUID1_TEXT")] = strGUID;

	// The 2nd GUID is the CLSID of the Control Properties

	guid.Data1++;
	strGUID = FormatGUID(IDS_GUID_EQUALS, guid);
	m_Dictionary[_T("GUID2_EQUALS")] = strGUID;
	strGUID = FormatGUID(IDS_GUID_DEFINE, guid);
	m_Dictionary[_T("GUID2_DEFINE")] = strGUID;
	strGUID = FormatGUID(IDS_GUID_TEXT, guid);
	m_Dictionary[_T("GUID2_TEXT")] = strGUID;

	// The 3th GUID is the CLSID of the Control Events

	guid.Data1++;
	strGUID = FormatGUID(IDS_GUID_EQUALS, guid);
	m_Dictionary[_T("GUID3_EQUALS")] = strGUID;
	strGUID = FormatGUID(IDS_GUID_TEXT, guid);
	m_Dictionary[_T("GUID3_TEXT")] = strGUID;

	// The 4th GUID is the CLSID of the Control itself

	guid.Data1++;
	strGUID = FormatGUID(IDS_GUID_DEFINE, guid);
	m_Dictionary[_T("GUID4_DEFINE")] = strGUID;
	strGUID = FormatGUID(IDS_GUID_TEXT, guid);
	m_Dictionary[_T("GUID4_TEXT")] = strGUID;

	return TRUE;
}


// This is called just before the custom AppWizard is unloaded.
void CWebDCAppWiz::ExitCustomAppWiz()
{
	// TODO: Add code here to deallocate resources used by the custom AppWizard
}

// This is called when the user clicks "Create..." on the New Project dialog
CAppWizStepDlg* CWebDCAppWiz::Next(CAppWizStepDlg* pDlg)
{
	ASSERT(pDlg == NULL);	// By default, this custom AppWizard has no steps

	// Set template macros based on the project name entered by the user.

	// Get value of $$root$$ (already set by AppWizard)
	CString strRoot;
	m_Dictionary.Lookup(_T("root"), strRoot);
	
	// Set value of $$Doc$$, $$DOC$$
	CString strDoc = strRoot.Left(6);
	m_Dictionary[_T("Doc")] = strDoc;
	strDoc.MakeUpper();
	m_Dictionary[_T("DOC")] = strDoc;

	// Set value of $$MAC_TYPE$$
	strRoot = strRoot.Left(4);
	int nLen = strRoot.GetLength();
	if (strRoot.GetLength() < 4)
	{
		CString strPad(_T(' '), 4 - nLen);
		strRoot += strPad;
	}
	strRoot.MakeUpper();
	m_Dictionary[_T("MAC_TYPE")] = strRoot;

	// Return NULL to indicate there are no more steps.  (In this case, there are
	//  no steps at all.)
	return NULL;
}

void CWebDCAppWiz::CustomizeProject(IBuildProject* pProject)
{
	IConfigurations* pConfigs = NULL;
	pProject->get_Configurations(&pConfigs);
	ASSERT(pConfigs);

    CComPtr<IUnknown> pUnk;
    CComQIPtr<IEnumVARIANT, &IID_IEnumVARIANT> pNewEnum;
    if (SUCCEEDED(pConfigs->get__NewEnum(&pUnk)) && pUnk != NULL)
    {
        pNewEnum = pUnk;
        VARIANT varConfig;
        CComQIPtr<IConfiguration, &IID_IConfiguration> pConfig;
		while (pNewEnum->Next(1, &varConfig, NULL) == S_OK)
        {
            ASSERT (varConfig.vt == VT_DISPATCH);
            pConfig = varConfig.pdispVal;
            VariantClear(&varConfig);

			// Add Control registration custom build step

			VARIANT reserved;
			CComBSTR bstrCommand(
				"regsvr32 /s /c \"$(TargetPath)\"\n"
				"echo regsvr32 exec. time > \"$(OutDir)\\regsvr32.trg\"");
			CComBSTR bstrOutput("$(OutDir)\\regsvr32.trg");
		    CComBSTR bstrDescription("Registering ActiveX Control...");
			pConfig->AddCustomBuildStep(bstrCommand, bstrOutput,
				bstrDescription, reserved);
			
			// Remove old output name (DLL)
			
			CComBSTR bstrTool = "link.exe";
			CComBSTR bstrOption = "/out:";
			pConfig->RemoveToolSettings(bstrTool, bstrOption, reserved);

			// Change output name to OCX

			USES_CONVERSION;
            CComBSTR bstrName;
            pConfig->get_Name(&bstrName);
			BOOL bDebug = (BOOL) _tcsstr(OLE2T(bstrName), _T("Debug"));
			bstrOption = bDebug ? "/out:Debug\\" : "/out:Release\\";
			bstrOption += m_Dictionary[_T("safe_root")].AllocSysString();
			bstrOption += ".ocx";
			pConfig->AddToolSettings(bstrTool, bstrOption, reserved);
        }
    }

}

CWebDCAppWiz WebDCaw;

