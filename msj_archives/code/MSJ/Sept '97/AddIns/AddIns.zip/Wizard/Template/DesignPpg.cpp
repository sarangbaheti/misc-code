// $$Safe_root$$Ppg.cpp:
// Implementation of the C$$Safe_root$$PropPage property page class.

#include "stdafx.h"
#include "$$root$$.h"
#include "$$Safe_root$$Ppg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(C$$Safe_root$$PropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(C$$Safe_root$$PropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(C$$Safe_root$$PropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(C$$Safe_root$$PropPage, "$$SAFE_ROOT$$.$$Safe_root$$PropPage.1",
	$$GUID2_DEFINE$$)


/////////////////////////////////////////////////////////////////////////////
// C$$Safe_root$$PropPage::C$$Safe_root$$PropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for C$$Safe_root$$PropPage

BOOL C$$Safe_root$$PropPage::C$$Safe_root$$PropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_$$SAFE_ROOT$$_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// C$$Safe_root$$PropPage::C$$Safe_root$$PropPage - Constructor

C$$Safe_root$$PropPage::C$$Safe_root$$PropPage() :
	COlePropertyPage(IDD, IDS_$$SAFE_ROOT$$_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(C$$Safe_root$$PropPage)
	// NOTE: ClassWizard will add member initialization here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// C$$Safe_root$$PropPage::DoDataExchange - Moves data between page and properties

void C$$Safe_root$$PropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(C$$Safe_root$$PropPage)
	// NOTE: ClassWizard will add DDP, DDX, and DDV calls here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// C$$Safe_root$$PropPage message handlers
