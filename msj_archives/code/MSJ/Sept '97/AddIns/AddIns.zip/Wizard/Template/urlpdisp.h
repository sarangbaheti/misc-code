#include <atlbase.h>
#include "designer.h"

class CURLBuilder
{
protected:
	CComQIPtr<IOleObject, &IID_IOleObject> m_pOleObject;
	CComPtr<IOleClientSite> m_pClientSite;
	CComQIPtr<IServiceProvider, &IID_IServiceProvider> m_pProvider;
	CComPtr<IBuilderWizardManager> m_pManager;

public:
	CURLBuilder(IDispatch* pControl);
	BOOL GetURL(CString& strResult);
	BOOL IsAvailable() { return !(!m_pManager); }
};

/////////////////////////////////////////////////////////////////////////////
// IURLPickerDispatch wrapper class

class IURLPickerDispatch : public COleDispatchDriver
{
public:
	IURLPickerDispatch() {}
	IURLPickerDispatch(LPDISPATCH pDispatch)
		: COleDispatchDriver(pDispatch) {}
	IURLPickerDispatch(const IURLPickerDispatch& dispatchSrc)
		: COleDispatchDriver(dispatchSrc) {}

	long Execute(LPDISPATCH pIDispatch, long hwnd,
		LPUNKNOWN pvarServiceProvider, VARIANT* pvarValue,
		LPCTSTR pszcBaseURL, LPCTSTR pszcAdditionalFilters,
		LPCTSTR pszcDlgTitle, VARIANT* pvarTargetFrame,
		long* pdwFlags, VARIANT_BOOL* pbRet);
};

/////////////////////////////////////////////////////////////////////////////
// URL Builder Category ID: {73CEF3D9-AE85-11cf-A406-00AA00C00940}

DEFINE_GUID(CATID_URLBuilder, 
	0x73cef3d9, 0xae85, 0x11cf, 0xa4, 0x6, 0x0, 0xaa, 0x0, 0xc0, 0x9, 0x40);
