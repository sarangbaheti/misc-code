// $$root$$.cpp:
// Implementation of C$$Safe_root$$App and Control registration.

#include "stdafx.h"
#include <initguid.h>
#include "webdc.h"
#include "catreg.h"
#include "$$root$$.h"
#include "$$Safe_root$$Ctl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


C$$Safe_root$$App NEAR theApp;

const GUID CDECL BASED_CODE _tlid =
		{ $$GUID1_EQUALS$$ };
const WORD _wVerMajor = 1;
const WORD _wVerMinor = 0;


////////////////////////////////////////////////////////////////////////////
// C$$Safe_root$$App::InitInstance - DLL initialization

BOOL C$$Safe_root$$App::InitInstance()
{
	BOOL bInit = COleControlModule::InitInstance();

	if (bInit)
	{
		// TODO: Add your own module initialization code here.
	}

	return bInit;
}


////////////////////////////////////////////////////////////////////////////
// C$$Safe_root$$App::ExitInstance - DLL termination

int C$$Safe_root$$App::ExitInstance()
{
	// TODO: Add your own module termination code here.

	return COleControlModule::ExitInstance();
}


/////////////////////////////////////////////////////////////////////////////
// DllRegisterServer - Adds entries to the system registry

STDAPI DllRegisterServer(void)
{
	AFX_MANAGE_STATE(_afxModuleAddrThis);

	if (!AfxOleRegisterTypeLib(AfxGetInstanceHandle(), _tlid))
		return ResultFromScode(SELFREG_E_TYPELIB);

	if (!COleObjectFactoryEx::UpdateRegistryAll(TRUE))
		return ResultFromScode(SELFREG_E_CLASS);

	RegisterComponentCategory(CATID_WebDesigntimeControl,
		L"Web Design-time Control");
	RegisterClassImplCategory(C$$Safe_root$$Ctrl::guid,
		CATID_WebDesigntimeControl, TRUE);

	return NOERROR;
}


/////////////////////////////////////////////////////////////////////////////
// DllUnregisterServer - Removes entries from the system registry

STDAPI DllUnregisterServer(void)
{
	AFX_MANAGE_STATE(_afxModuleAddrThis);

	if (!AfxOleUnregisterTypeLib(_tlid, _wVerMajor, _wVerMinor))
		return ResultFromScode(SELFREG_E_TYPELIB);

	if (!COleObjectFactoryEx::UpdateRegistryAll(FALSE))
		return ResultFromScode(SELFREG_E_CLASS);

	RegisterClassImplCategory(C$$Safe_root$$Ctrl::guid,
		CATID_WebDesigntimeControl, FALSE);

	return NOERROR;
}
