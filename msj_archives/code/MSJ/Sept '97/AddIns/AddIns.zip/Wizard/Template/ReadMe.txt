========================================================================
		Design-Time ActiveX Control : $$SAFE_ROOT$$
========================================================================

ControlWizard has created this project for your $$SAFE_ROOT$$
Design-Time ActiveX Control.

This skeleton project not only demonstrates the basics of writing an
Design Time ActiveX Control, but is also a starting point for writing
the specific features of your control.

