// $$Safe_root$$Ppg.h:
// Declaration of the C$$Safe_root$$PropPage property page class.

////////////////////////////////////////////////////////////////////////////
// C$$Safe_root$$PropPage : See $$Safe_root$$Ppg.cpp.cpp for implementation.

class C$$Safe_root$$PropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(C$$Safe_root$$PropPage)
	DECLARE_OLECREATE_EX(C$$Safe_root$$PropPage)

// Constructor
public:
	C$$Safe_root$$PropPage();

// Dialog Data
	//{{AFX_DATA(C$$Safe_root$$PropPage)
	enum { IDD = IDD_PROPPAGE_$$SAFE_ROOT$$ };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(C$$Safe_root$$PropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

