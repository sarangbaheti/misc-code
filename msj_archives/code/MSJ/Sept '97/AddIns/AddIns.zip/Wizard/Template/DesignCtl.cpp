// $$Safe_root$$Ctl.cpp:
// Implementation of the C$$Safe_root$$Ctrl ActiveX Control class.

#include "stdafx.h"
#include "$$root$$.h"
#include "$$Safe_root$$Ctl.h"
#include "$$Safe_root$$Ppg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(C$$Safe_root$$Ctrl, COleControl)

/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(C$$Safe_root$$Ctrl, COleControl)
	//{{AFX_MSG_MAP(C$$Safe_root$$Ctrl)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(C$$Safe_root$$Ctrl, COleControl)
	//{{AFX_DISPATCH_MAP(C$$Safe_root$$Ctrl)
	// NOTE - ClassWizard will add and remove dispatch map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(C$$Safe_root$$Ctrl, COleControl)
	//{{AFX_EVENT_MAP(C$$Safe_root$$Ctrl)
	// NOTE - ClassWizard will add and remove event map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_EVENT_MAP
END_EVENT_MAP()

/////////////////////////////////////////////////////////////////////////////
// IActive$$Safe_root$$er Interface map

BEGIN_INTERFACE_MAP(C$$Safe_root$$Ctrl, COleControl)
	INTERFACE_PART(C$$Safe_root$$Ctrl, IID_IActiveDesigner, ActiveDesigner)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(C$$Safe_root$$Ctrl, 1)
	PROPPAGEID(C$$Safe_root$$PropPage::guid)
END_PROPPAGEIDS(C$$Safe_root$$Ctrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(C$$Safe_root$$Ctrl, "$$SAFE_ROOT$$.$$Safe_root$$Ctrl.1",
	$$GUID4_DEFINE$$)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(C$$Safe_root$$Ctrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_D$$Safe_root$$ =
		{ $$GUID2_EQUALS$$ };
const IID BASED_CODE IID_D$$Safe_root$$Events =
		{ $$GUID3_EQUALS$$ };

/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dw$$Safe_root$$OleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(C$$Safe_root$$Ctrl, IDS_$$SAFE_ROOT$$, _dw$$Safe_root$$OleMisc)


/////////////////////////////////////////////////////////////////////////////
// C$$Safe_root$$Ctrl::C$$Safe_root$$CtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for C$$Safe_root$$Ctrl

BOOL C$$Safe_root$$Ctrl::C$$Safe_root$$CtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_$$SAFE_ROOT$$,
			IDB_$$SAFE_ROOT$$,
			afxRegApartmentThreading,
			_dw$$Safe_root$$OleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}

/////////////////////////////////////////////////////////////////////////////
// C$$Safe_root$$Ctrl::C$$Safe_root$$Ctrl - Constructor

C$$Safe_root$$Ctrl::C$$Safe_root$$Ctrl()
{
	InitializeIIDs(&IID_D$$Safe_root$$, &IID_D$$Safe_root$$Events);

	// TODO: Initialize your control's instance data here.
}

/////////////////////////////////////////////////////////////////////////////
// C$$Safe_root$$Ctrl::~C$$Safe_root$$Ctrl - Destructor

C$$Safe_root$$Ctrl::~C$$Safe_root$$Ctrl()
{
	// TODO: Cleanup your control's instance data here.
}

/////////////////////////////////////////////////////////////////////////////
// C$$Safe_root$$Ctrl::OnDraw - Drawing function

void C$$Safe_root$$Ctrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
	// TODO: Replace the following code with your own drawing code.
	pdc->FillRect(rcBounds, CBrush::FromHandle((HBRUSH)GetStockObject(WHITE_BRUSH)));
	pdc->Ellipse(rcBounds);
}

/////////////////////////////////////////////////////////////////////////////
// C$$Safe_root$$Ctrl::DoPropExchange - Persistence support

void C$$Safe_root$$Ctrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	// TODO: Call PX_ functions for each persistent custom property.

}

/////////////////////////////////////////////////////////////////////////////
// C$$Safe_root$$Ctrl::OnResetState - Reset control to default state

void C$$Safe_root$$Ctrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}

/////////////////////////////////////////////////////////////////////////////
// C$$Safe_root$$Ctrl::GetRuntimeText

HRESULT C$$Safe_root$$Ctrl::GetRuntimeText(CString& strText)
{
	// TODO: Replace the code below with your own

	strText = _T("<p><i>Your $$root$$ Control text here!</i>");
	return S_OK;
}

/////////////////////////////////////////////////////////////////////////////
// C$$Safe_root$$Ctrl::XActiveDesigner - IActiveDesigner interface
//
// The following functions represent the implementation of the IActiveDesigner
// interface. For the most part, these functions can be left as is. The
// SaveRuntimeState() function will call the C$$Safe_root$$Ctrl::GetRuntimeText()
// function when it needs to generate run-time text.

STDMETHODIMP_(ULONG) C$$Safe_root$$Ctrl::XActiveDesigner::AddRef(void)
{
	METHOD_MANAGE_STATE(C$$Safe_root$$Ctrl, ActiveDesigner)
	return (ULONG)pThis->ExternalAddRef();
}

STDMETHODIMP_(ULONG) C$$Safe_root$$Ctrl::XActiveDesigner::Release(void)
{
	METHOD_MANAGE_STATE(C$$Safe_root$$Ctrl, ActiveDesigner)
	return (ULONG)pThis->ExternalRelease();
}

STDMETHODIMP C$$Safe_root$$Ctrl::XActiveDesigner::QueryInterface(
	REFIID iid,	LPVOID far* ppvObj)
{
	METHOD_MANAGE_STATE(C$$Safe_root$$Ctrl, ActiveDesigner)
	return (HRESULT)pThis->ExternalQueryInterface(&iid, ppvObj);
}

STDMETHODIMP C$$Safe_root$$Ctrl::XActiveDesigner::GetRuntimeClassID(CLSID *pclsid)
{
    *pclsid = CLSID_NULL;
    return S_FALSE;
}

STDMETHODIMP C$$Safe_root$$Ctrl::XActiveDesigner::GetRuntimeMiscStatusFlags(DWORD *pdwMiscFlags)
{
	if (!pdwMiscFlags)
		return E_INVALIDARG;
	*pdwMiscFlags = NULL;
	return E_UNEXPECTED;
}

STDMETHODIMP C$$Safe_root$$Ctrl::XActiveDesigner::QueryPersistenceInterface(REFIID riid)
{
	if (riid == IID_IPersistTextStream)
		return S_OK;
	return S_FALSE;
}

STDMETHODIMP C$$Safe_root$$Ctrl::XActiveDesigner::SaveRuntimeState(
	REFIID riidPersist,	REFIID riidObjStgMed, void  *pObjStgMed)
{   
	HRESULT  hr;
	CString  cstrText;
	BSTR     bstrText;

	METHOD_MANAGE_STATE(C$$Safe_root$$Ctrl, ActiveDesigner)

	if (riidPersist != IID_IPersistTextStream)
		return E_NOINTERFACE;

	if (riidObjStgMed != IID_IStream)
		return E_NOINTERFACE;

	hr = pThis->GetRuntimeText(cstrText);
	if (SUCCEEDED(hr))
	{
		bstrText = cstrText.AllocSysString();
		if (bstrText)
		{
			hr = ((IStream *)pObjStgMed)->Write(bstrText,
				SysStringByteLen(bstrText) + sizeof(OLECHAR), NULL);
			SysFreeString(bstrText);
		}
		else
			hr = E_OUTOFMEMORY;
	}

	return hr;
}

STDMETHODIMP C$$Safe_root$$Ctrl::XActiveDesigner::GetExtensibilityObject(IDispatch **ppvObjOut)
{
	if (!ppvObjOut)
		return E_INVALIDARG;
	return this->QueryInterface(IID_IDispatch, (void **)ppvObjOut);
}


/////////////////////////////////////////////////////////////////////////////
// C$$Safe_root$$Ctrl message handlers
