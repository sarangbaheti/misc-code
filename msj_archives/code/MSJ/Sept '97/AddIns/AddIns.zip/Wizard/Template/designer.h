//=--------------------------------------------------------------------------=
// Designer.H
//=--------------------------------------------------------------------------=
// Copyright (c) 1988-1993, Microsoft Corporation
//                 All Rights Reserved
// Information Contained Herein Is Proprietary and Confidential.
//=--------------------------------------------------------------------------=
// just about everything you might find useful in an ActiveX[tm] Designer.
//
#ifndef _DESIGNER_H_


// CATID for Designers
//
// {4EB304D0-7555-11cf-A0C2-00AA0062BE57}
DEFINE_GUID(CATID_Designer, 0x4eb304d0, 0x7555, 0x11cf, 0xa0, 0xc2, 0x0, 0xaa, 0x0, 0x62, 0xbe, 0x57);

// IActiveDesigner
//
// {51AAE3E0-7486-11cf-A0C2-00AA0062BE57}
DEFINE_GUID(IID_IActiveDesigner, 0x51aae3e0, 0x7486, 0x11cf, 0xa0, 0xc2, 0x0, 0xaa, 0x0, 0x62, 0xbe, 0x57);


#undef  INTERFACE
#define INTERFACE IActiveDesigner

DECLARE_INTERFACE_(IActiveDesigner, IUnknown)
{
	// IUnknown methods
	//
	STDMETHOD(QueryInterface)(THIS_ REFIID riid, LPVOID FAR* ppvObj) PURE;
	STDMETHOD_(ULONG,AddRef)(THIS) PURE;
	STDMETHOD_(ULONG,Release)(THIS) PURE;

	// IActiveDesigner methods
	//
	STDMETHOD(GetRuntimeClassID)(THIS_ CLSID *pclsid) PURE;
	STDMETHOD(GetRuntimeMiscStatusFlags)(THIS_ DWORD *dwMiscFlags) PURE;
	STDMETHOD(QueryPersistenceInterface)(THIS_ REFIID riid) PURE;
	STDMETHOD(SaveRuntimeState)(THIS_ REFIID riidItf, REFIID riidObj, void *pObj) PURE;
	STDMETHOD(GetExtensibilityObject)(THIS_ IDispatch **ppvObjOut) PURE;
};


//-------------------------------------------------------------------------
//  IServiceProvider Interface
//    This interface is implemented by an object that wish to provide "services"
//
//-------------------------------------------------------------------------
#ifndef __IServiceProvider_INTERFACE_DEFINED__
#define __IServiceProvider_INTERFACE_DEFINED__
#ifndef __IServiceProvider_INTERFACE_DEFINED
#define __IServiceProvider_INTERFACE_DEFINED

// { 6d5140c1-7436-11ce-8034-00aa006009fa }
DEFINE_GUID(IID_IServiceProvider, 0x6d5140c1, 0x7436, 0x11ce, 0x80, 0x34, 0x00, 0xaa, 0x00, 0x60, 0x09, 0xfa);

#undef  INTERFACE
#define INTERFACE  IServiceProvider

DECLARE_INTERFACE_(IServiceProvider, IUnknown)
{
   //BEGIN_INTERFACE
    // *** IUnknown methods ***
    STDMETHOD(QueryInterface)(THIS_ REFIID riid, LPVOID FAR* ppvObj) PURE;
    STDMETHOD_(ULONG, AddRef)(THIS) PURE;
    STDMETHOD_(ULONG, Release)(THIS) PURE;

    // *** IServiceProvider methods ***
    STDMETHOD(QueryService)(THIS_
                /* [in]  */ REFGUID rsid,
                /* [in]  */ REFIID iid,
                /* [out] */ void ** ppvObj) PURE;
};

#endif // __IServiceProvider_INTERFACE_DEFINED
#endif // __IServiceProvider_INTERFACE_DEFINED__


///////////////////////////////////////////////////////////////////////////////
// IBuilderWizardManager Interface
// 

// {95FC88C2-9FCB-11cf-A405-00AA00C00940}
DEFINE_GUID(SID_SBuilderWizardManager, 0x95fc88c2, 0x9fcb, 0x11cf, 0xa4, 0x5, 0x0, 0xaa, 0x0, 0xc0, 0x9, 0x40);

// {95FC88C3-9FCB-11cf-A405-00AA00C00940}
DEFINE_GUID(IID_IBuilderWizardManager, 0x95fc88c3, 0x9fcb, 0x11cf, 0xa4, 0x5, 0x0, 0xaa, 0x0, 0xc0, 0x9, 0x40);

#undef  INTERFACE
#define INTERFACE  IBuilderWizardManager

DECLARE_INTERFACE_(IBuilderWizardManager, IUnknown)
{
   //BEGIN_INTERFACE
    // *** IUnknown methods ***
    STDMETHOD(QueryInterface)(THIS_ REFIID riid, LPVOID FAR* ppvObj) PURE;
    STDMETHOD_(ULONG, AddRef)(THIS) PURE;
    STDMETHOD_(ULONG, Release)(THIS) PURE;

    // *** IBuilderWizardManager methods ***
    STDMETHOD(DoesBuilderExist)(REFGUID rguidBuilder) PURE;
    STDMETHOD(MapObjectToBuilderCLSID)(REFCLSID rclsidObject, DWORD dwPromptOpt, HWND hwndPromptOwner, CLSID *pclsidBuilder) PURE;
    STDMETHOD(MapBuilderCATIDToCLSID)(REFGUID rguidBuilder, DWORD dwPromptOpt, HWND hwndPromptOwner, CLSID *pclsidBuilder) PURE;
    STDMETHOD(GetBuilder)(REFGUID rguidBuilder, DWORD grfGetOpt, HWND hwndPromptOwner,
            IDispatch **ppdispApp, HWND *pwndBuilderOwner, REFIID riidBuilder, IUnknown **ppunkBuilder) PURE;
    STDMETHOD(EnableModeless)(BOOL fEnable) PURE;    
};

#ifndef _tagBLDPROMPTOPT_DEFINED
#define _tagBLDPROMPTOPT_DEFINED
#define _BLDPROMPTOPT_DEFINED
typedef 
enum tagBLDPROMPTOPT
    {	BLDPROMPTOPT_PROMPTIFMULTIPLE	= 0,
	BLDPROMPTOPT_PROMPTALWAYS	= 1,
	BLDPROMPTOPT_PROMPTNEVER	= 2
    }	BLDPROMPTOPT;

#endif
#ifndef _tagBLDGETOPT_DEFINED
#define _tagBLDGETOPT_DEFINED
#define _BLDGETOPT_DEFINED
typedef 
enum tagBLDGETOPT
    {	BLDGETOPT_FAUTOMAPGUID	= 0x1,
	BLDGETOPT_FAUTOMAPENABLEPROMPT	= 0x2,
	BLDGETOPT_FAUTOMAPPROMPTALWAYS	= 0x4,
	BLDGETOPT_FOBJECTBUILDER	= 0x8,
	BLDGETOPT_FNOINTRINSICS	= 0x80000000
    }	BLDGETFLAGS;

#endif


#define _DESIGNER_H_
#endif // _DESIGNER_H_

