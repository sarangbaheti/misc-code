// Component Category registration helper functions

#include "stdafx.h"
#include "catreg.h"

HRESULT RegisterComponentCategory(CATID catid,
	WCHAR* catDescription, BOOL bRegister)
{
	ICatRegister* pcr = NULL;
	HRESULT hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr, 
		NULL, CLSCTX_INPROC_SERVER, IID_ICatRegister, (void**)&pcr);
	if (FAILED(hr))
		return hr;

	// Make sure the HKCR\Component Categories\{..catid...}
	// key is registered

	CATEGORYINFO catinfo;
	catinfo.catid = catid;
	catinfo.lcid = 0x0409; // English is all for now

	// Make sure the provided description is not too long.
	// Only copy the first 127 characters if it is

	int len = min(wcslen(catDescription), 127);
	wcsncpy(catinfo.szDescription, catDescription, len);
	catinfo.szDescription[len] = 0;

	if (bRegister)
		hr = pcr->RegisterCategories(1, &catinfo);
	else 
		hr = pcr->UnRegisterCategories(1, &catid);

	pcr->Release();
	return hr;
}

HRESULT RegisterClassReqCategory(const CLSID& pclsid,
	CATID rgcatid, BOOL bRegister)
{
	ICatRegister* pcr = NULL;
	HRESULT hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr, 
		NULL, CLSCTX_INPROC_SERVER, IID_ICatRegister, (void**)&pcr);
	if (FAILED(hr))
		return hr;

	return bRegister ? pcr->RegisterClassReqCategories(pclsid, 1, &rgcatid)
		: pcr->UnRegisterClassReqCategories(pclsid, 1, &rgcatid);
}

HRESULT RegisterClassImplCategory(const CLSID& pclsid,
	CATID rgcatid, BOOL bRegister)
{
	ICatRegister* pcr = NULL;
	HRESULT hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr, 
		NULL, CLSCTX_INPROC_SERVER, IID_ICatRegister, (void**)&pcr);
	if (FAILED(hr))
		return hr;

	return bRegister ? pcr->RegisterClassImplCategories(pclsid, 1, &rgcatid)
		: pcr->UnRegisterClassImplCategories(pclsid, 1, &rgcatid);
}
