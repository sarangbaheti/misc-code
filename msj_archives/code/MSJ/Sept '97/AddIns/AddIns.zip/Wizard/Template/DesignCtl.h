// $$Safe_root$$Ctl.h:
// Declaration of the C$$Safe_root$$Ctrl ActiveX Control class.

#include "webdc.h"
#include "designer.h"

/////////////////////////////////////////////////////////////////////////////
// C$$Safe_root$$Ctrl : See $$Safe_root$$Ctl.cpp for implementation.

class C$$Safe_root$$Ctrl : public COleControl
{
	DECLARE_DYNCREATE(C$$Safe_root$$Ctrl)

// Constructor
public:
	C$$Safe_root$$Ctrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(C$$Safe_root$$Ctrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	//}}AFX_VIRTUAL

// Implementation
protected:
	~C$$Safe_root$$Ctrl();
    virtual HRESULT GetRuntimeText(CString& strText);

	DECLARE_OLECREATE_EX(C$$Safe_root$$Ctrl)    // Class factory and guid
	DECLARE_OLETYPELIB(C$$Safe_root$$Ctrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(C$$Safe_root$$Ctrl)     // Property page IDs
	DECLARE_OLECTLTYPE(C$$Safe_root$$Ctrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(C$$Safe_root$$Ctrl)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(C$$Safe_root$$Ctrl)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

// Event maps
	//{{AFX_EVENT(C$$Safe_root$$Ctrl)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Interface maps
	DECLARE_INTERFACE_MAP();

public:
    BEGIN_INTERFACE_PART(ActiveDesigner, IActiveDesigner)
		STDMETHOD(GetRuntimeClassID)(CLSID *pclsid);
		STDMETHOD(GetRuntimeMiscStatusFlags)(DWORD *dwMiscFlags);
		STDMETHOD(QueryPersistenceInterface)(REFIID riidPersist);
		STDMETHOD(SaveRuntimeState)(REFIID riidPersist, REFIID riidObjStgMed, void *pObjStgMed);
		STDMETHOD(GetExtensibilityObject)(IDispatch **ppvObjOut);
	END_INTERFACE_PART(ActiveDesigner)

	// Dispatch and event IDs
	enum {
	//{{AFX_DISP_ID(C$$Safe_root$$Ctrl)
		// NOTE: ClassWizard will add and remove enumeration elements here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DISP_ID
	};
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.
