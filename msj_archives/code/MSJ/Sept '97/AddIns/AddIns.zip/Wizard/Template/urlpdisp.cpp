// Machine generated IDispatch wrapper class(es) created with ClassWizard

#include "stdafx.h"
#include "designer.h"
#include "urlpdefs.h"
#include <initguid.h>
#include "urlpdisp.h"
#include <atlimpl.cpp>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CURLBuilder::CURLBuilder(IDispatch* pControl)
{
	_ASSERTE(pControl);
	m_pOleObject = pControl;
	if (!m_pOleObject)
		return;
	
	m_pOleObject->GetClientSite(&m_pClientSite);
	m_pProvider = m_pClientSite;
	if (!m_pProvider)
		return;

	m_pProvider->QueryService(SID_SBuilderWizardManager,
		IID_IBuilderWizardManager, (LPVOID*)&m_pManager);
}

BOOL CURLBuilder::GetURL(CString& strResult)
{
	_ASSERTE(IsAvailable());

	HWND hWndOwner;
	CComPtr<IDispatch> pAppDisp;
	CComPtr<IDispatch> pBuilder;

	m_pManager->GetBuilder(CATID_URLBuilder,
		BLDGETOPT_FAUTOMAPGUID,	NULL, &pAppDisp,
		&hWndOwner, IID_IDispatch, (IUnknown**)&pBuilder);

	LPOLESTR pszName;
    CString	strBaseURL;
	CComPtr<IMoniker> pMoniker;
	if (m_pClientSite->GetMoniker(OLEGETMONIKER_FORCEASSIGN,
		OLEWHICHMK_CONTAINER, &pMoniker) == S_OK)
	{
		CComPtr<IBindCtx> pBindCtx;
		if (CreateBindCtx(0, &pBindCtx) == S_OK)
		{
			if (pMoniker->GetDisplayName(pBindCtx, 0, &pszName) == S_OK)
			{
				strBaseURL = pszName;
				AfxFreeTaskMem((void*)pszName);
			}
		}
	}
	
    VARIANT	varURL;
    LPCTSTR	pszBaseURL;
	if (strBaseURL.GetLength())
		pszBaseURL = strBaseURL;
	else
		pszBaseURL = NULL;

    try
    {
	    IURLPickerDispatch ddrv;
	    VARIANT_BOOL bRet = FALSE;
		long lURLFlags = URLP_EDITURLTITLE;
	    ddrv.AttachDispatch(pBuilder, FALSE);
	    ddrv.Execute(pAppDisp, (long)hWndOwner, m_pProvider, &varURL,
			pszBaseURL, NULL, NULL, NULL, &lURLFlags, &bRet);
    }
    catch (...)
    {
        return FALSE;
    }

	if (VT_EMPTY != varURL.vt)
	{
		strResult = varURL.bstrVal;
		return TRUE;
	}

	return FALSE;
}



/////////////////////////////////////////////////////////////////////////////
// IURLPickerDispatch operations

long IURLPickerDispatch::Execute(LPDISPATCH pIDispatch, long hwnd,
	LPUNKNOWN pvarServiceProvider, VARIANT* pvarValue,
	LPCTSTR pszcBaseURL, LPCTSTR pszcAdditionalFilters,
	LPCTSTR pszcDlgTitle, VARIANT* pvarTargetFrame, long *pdwFlags,
	VARIANT_BOOL* pbRet)
{
	long result;
	static BYTE parms[] =
		VTS_DISPATCH VTS_I4 VTS_UNKNOWN VTS_PVARIANT VTS_BSTR
		VTS_BSTR VTS_BSTR VTS_PVARIANT VTS_PI4 VTS_PBOOL;

	InvokeHelper(0x1, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		pIDispatch, hwnd, pvarServiceProvider, pvarValue, pszcBaseURL,
		pszcAdditionalFilters, pszcDlgTitle, pvarTargetFrame, pdwFlags, pbRet);

	return result;
}

