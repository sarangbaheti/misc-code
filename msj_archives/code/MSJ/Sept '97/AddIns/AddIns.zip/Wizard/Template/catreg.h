// Component Category registration helper functions

#include <comcat.h>

HRESULT RegisterComponentCategory(CATID catid, WCHAR* catDescription,
	BOOL bRegister = TRUE);
HRESULT RegisterClassReqCategory(const CLSID& rclsid, CATID rgcatid,
	BOOL bRegister = TRUE);
HRESULT RegisterClassImplCategory(const CLSID& rclsid, CATID rgcatid,
	BOOL bRegister = TRUE);
