#if !defined(AFX_WEBDCAW_H__45E122FF_969C_11D0_A307_000000000000__INCLUDED_)
#define AFX_WEBDCAW_H__45E122FF_969C_11D0_A307_000000000000__INCLUDED_

// WebDCaw.h : header file
//

class CDialogChooser;

// All function calls made by mfcapwz.dll to this custom AppWizard (except for
//  GetCustomAppWizClass-- see WebDC.cpp) are through this class.  You may
//  choose to override more of the CCustomAppWiz virtual functions here to
//  further specialize the behavior of this custom AppWizard.
class CWebDCAppWiz : public CCustomAppWiz
{
	BOOL CreateGUIDMacros(void);
	CString FormatGUID(UINT resID, GUID& guid);

public:
	virtual CAppWizStepDlg* Next(CAppWizStepDlg* pDlg);
		
	virtual void InitCustomAppWiz();
	virtual void ExitCustomAppWiz();
	virtual void CustomizeProject(IBuildProject* pProject);
};

// This declares the one instance of the CWebDCAppWiz class.  You can access
//  m_Dictionary and any other public members of this class through the
//  global WebDCaw.  (Its definition is in WebDCaw.cpp.)
extern CWebDCAppWiz WebDCaw;

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WEBDCAW_H__45E122FF_969C_11D0_A307_000000000000__INCLUDED_)
