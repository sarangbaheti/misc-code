// DSAddIn.h : header file
//

#if !defined(AFX_DSADDIN_H__4F913315_A457_11D0_8381_00A0C91EF7B9__INCLUDED_)
#define AFX_DSADDIN_H__4F913315_A457_11D0_8381_00A0C91EF7B9__INCLUDED_

#include "commands.h"

// {971046B4-A461-11D0-8381-00A0C91EF7B9}
DEFINE_GUID(CLSID_DSAddIn,
0x971046b4, 0xa461, 0x11d0, 0x83, 0x81, 0, 0xa0, 0xc9, 0x1e, 0xf7, 0xb9);

/////////////////////////////////////////////////////////////////////////////
// CDSAddIn

class CDSAddIn : 
	public IDSAddIn,
	public CComObjectRoot,
	public CComCoClass<CDSAddIn, &CLSID_DSAddIn>
{
public:
	DECLARE_REGISTRY(CDSAddIn, "Replace.DSAddIn.1",
		"REPLACE Developer Studio Add-in", IDS_REPLACE_LONGNAME,
		THREADFLAGS_BOTH)

	CDSAddIn() {}
	BEGIN_COM_MAP(CDSAddIn)
		COM_INTERFACE_ENTRY(IDSAddIn)
	END_COM_MAP()
	DECLARE_NOT_AGGREGATABLE(CDSAddIn)

// IDSAddIns
public:
	STDMETHOD(OnConnection)(THIS_ IApplication* pApp, VARIANT_BOOL bFirstTime,
		long dwCookie, VARIANT_BOOL* OnConnection);
	STDMETHOD(OnDisconnection)(THIS_ VARIANT_BOOL bLastTime);

protected:
	CCommandsObj* m_pCommands;
	DWORD m_dwCookie;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DSADDIN_H__4F913315_A457_11D0_8381_00A0C91EF7B9__INCLUDED)
