// Replace.h : main header file for the REPLACE DLL
//

#if !defined(AFX_REPLACE_H__4F91330B_A457_11D0_8381_00A0C91EF7B9__INCLUDED_)
#define AFX_REPLACE_H__4F91330B_A457_11D0_8381_00A0C91EF7B9__INCLUDED_

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

#include <ObjModel\addguid.h>
#include <ObjModel\appguid.h>
#include <ObjModel\bldguid.h>
#include <ObjModel\textguid.h>
#include <ObjModel\dbgguid.h>


//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REPLACE_H__4F91330B_A457_11D0_8381_00A0C91EF7B9__INCLUDED)
