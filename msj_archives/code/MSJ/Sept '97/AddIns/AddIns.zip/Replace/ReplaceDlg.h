#if !defined(AFX_REPLACEDLG_H__971046B1_A461_11D0_8381_00A0C91EF7B9__INCLUDED_)
#define AFX_REPLACEDLG_H__971046B1_A461_11D0_8381_00A0C91EF7B9__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ReplaceDlg.h : header file
//

#include "afxadv.h"

class CRecentEntry : public CRecentFileList
{
public:
	CRecentEntry(LPCTSTR pSection);
	virtual ~CRecentEntry();
	virtual void Add( LPCTSTR lpszPathName );
};

/////////////////////////////////////////////////////////////////////////////
// CReplaceDlg dialog

class CReplaceDlg : public CDialog
{
// Construction
public:
	CReplaceDlg(IApplication* pApplication, CWnd* pParent = NULL);
	BOOL IsValid()		{ return m_bValid; }

// Dialog Data
	//{{AFX_DATA(CReplaceDlg)
	enum { IDD = IDD_REPLACE };
	CComboBox	m_comboReplace;
	CComboBox	m_comboFind;
	BOOL	m_bMatchCase;
	BOOL	m_bMatchWord;
	CString	m_strFind;
	CString	m_strReplace;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReplaceDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	BOOL m_bValid;
	IApplication* m_pApplication;
	CComQIPtr<IWindows, &IID_IWindows> m_pWindows;
	CComQIPtr<ITextDocument, &IID_ITextDocument> m_pDocument;
	long m_lDocIndex, m_lCount; 
	CRecentEntry m_recentFind, m_recentReplace;
	CPoint m_ptSelect;

	BOOL GetFirstDocument();
	BOOL GetNextDocument();
	BOOL FindNext();
	BOOL Replace();
	VARIANT MatchFlags();

	// Generated message map functions
	//{{AFX_MSG(CReplaceDlg)
	afx_msg void OnFindNext();
	afx_msg void OnReplace();
	afx_msg void OnReplaceAll();
	virtual BOOL OnInitDialog();
	afx_msg void OnNextDoc();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REPLACEDLG_H__971046B1_A461_11D0_8381_00A0C91EF7B9__INCLUDED_)
