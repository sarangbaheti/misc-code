// ReplaceDlg.cpp : implementation file
//

#include "stdafx.h"
#include <comdef.h>
#include "Replace.h"
#include "ReplaceDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CRecentEntry::CRecentEntry(LPCTSTR pSection)
: CRecentFileList(0, pSection, "Last%d", 16, _MAX_PATH)
{
	ReadList();
}

CRecentEntry::~CRecentEntry()
{
	WriteList();
}

void CRecentEntry::Add(LPCTSTR lpszPathName)
{
	if (!_tcslen(lpszPathName))
		return;

	for (int nLoop = 0; nLoop < GetSize(); nLoop++)
	{
		if (m_arrNames[nLoop] == lpszPathName)
			return;
	}

	CRecentFileList::Add(lpszPathName);
}

/////////////////////////////////////////////////////////////////////////////
// CReplaceDlg dialog

CReplaceDlg::CReplaceDlg(IApplication* pApplication, CWnd* pParent /*=NULL*/)
: CDialog(CReplaceDlg::IDD, pParent),  
  m_pApplication(pApplication),
  m_recentFind(_T("Recent Find")),
  m_recentReplace(_T("Recent Replace"))
{
	ASSERT(pApplication);

	IDispatch* pDispatch;
	VERIFY_OK( m_pApplication->get_Windows(&pDispatch) );
	VERIFY( m_pWindows = pDispatch );

	VERIFY_OK( m_pWindows->get_Count(&m_lCount) );
	if (!m_lCount || !GetFirstDocument())
	{
		AfxMessageBox(_T("No text documents in workspace"));
		m_bValid = FALSE;
		return;
	}
	
	pApplication->get_ActiveDocument(&pDispatch);
	CComQIPtr<ITextDocument, &IID_ITextDocument> pDocument(pDispatch);
	
	pDocument->get_Selection(&pDispatch);
	CComQIPtr<ITextSelection, &IID_ITextSelection> pSelection(pDispatch);

	CComBSTR bstrText;
	pSelection->get_Text(&bstrText);
	if (bstr_t(bstrText) == bstr_t(_T("")))
	{
		pSelection->WordRight(CComVariant(dsMove), CComVariant(1));
		pSelection->WordLeft(CComVariant(dsMove), CComVariant(1));
		pSelection->WordRight(CComVariant(dsExtend), CComVariant(1));
		pSelection->get_Text(&bstrText);
		pSelection->WordLeft(CComVariant(dsMove), CComVariant(1));
	}

	//{{AFX_DATA_INIT(CReplaceDlg)
	m_bMatchCase = FALSE;
	m_bMatchWord = FALSE;
	m_strFind = bstrText;
	m_strReplace = _T("");
	//}}AFX_DATA_INIT

	m_bValid = TRUE;
	m_strFind.TrimRight();
}

void CReplaceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CReplaceDlg)
	DDX_Control(pDX, IDC_COMBO_REPLACE, m_comboReplace);
	DDX_Control(pDX, IDC_COMBO_FIND, m_comboFind);
	DDX_Check(pDX, IDC_CHECK_MATCHCASE, m_bMatchCase);
	DDX_Check(pDX, IDC_CHECK_MATCHWORD, m_bMatchWord);
	DDX_CBString(pDX, IDC_COMBO_FIND, m_strFind);
	DDX_CBString(pDX, IDC_COMBO_REPLACE, m_strReplace);
	//}}AFX_DATA_MAP
}

BOOL CReplaceDlg::GetFirstDocument()
{
	m_lDocIndex = 0;
	return GetNextDocument();
}

BOOL CReplaceDlg::GetNextDocument()
{
	if (m_pDocument)
		m_pDocument.Release();

	while (!m_pDocument && m_lDocIndex < m_lCount)
	{
		IDispatch* pDispatch;
		CComVariant index(++m_lDocIndex);
		if (m_pWindows->Item(index, &pDispatch) == S_OK)
		{
			CComQIPtr<ITextWindow, &IID_ITextWindow> pWindow;
			VERIFY( pWindow = pDispatch );
			pWindow->get_Parent(&pDispatch);
			VERIFY( m_pDocument = pDispatch );

			CComBSTR bstrType;
			m_pDocument->get_Type(&bstrType);
			if (bstr_t(bstrType) != bstr_t(_T("Text")))
				m_pDocument.Release();
			else
			{
				m_pDocument->put_Active(VARIANT_TRUE);
				pWindow->put_Active(VARIANT_TRUE);
				m_ptSelect = CPoint(-1, -1);
			}
		}
	}

	return (m_pDocument != NULL);
}

VARIANT CReplaceDlg::MatchFlags()
{
	int nWord = m_bMatchWord ? dsMatchWord : 0;
	int nCase = m_bMatchCase ? dsMatchCase : 0;
	return CComVariant(dsMatchForward|nWord|nCase);
}

BEGIN_MESSAGE_MAP(CReplaceDlg, CDialog)
	//{{AFX_MSG_MAP(CReplaceDlg)
	ON_BN_CLICKED(IDC_FINDNEXT, OnFindNext)
	ON_BN_CLICKED(IDC_REPLACE, OnReplace)
	ON_BN_CLICKED(IDC_REPLACEALL, OnReplaceAll)
	ON_BN_CLICKED(IDC_NEXTDOC, OnNextDoc)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CReplaceDlg message handlers

BOOL CReplaceDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	ASSERT(IsValid());

	for (int nLoop = 0; nLoop < m_recentFind.GetSize(); nLoop++)
	{
		if (!m_recentFind[nLoop].IsEmpty())
			m_comboFind.AddString(m_recentFind[nLoop]);
	}
	
	for (nLoop = 0; nLoop < m_recentReplace.GetSize(); nLoop++)
	{
		if (!m_recentReplace[nLoop].IsEmpty())
			m_comboReplace.AddString(m_recentReplace[nLoop]);
	}
	
	GetDlgItem(IDC_NEXTDOC)->EnableWindow(m_lCount > 1);
	return TRUE;
}

void CReplaceDlg::OnFindNext() 
{
	UpdateData(TRUE);
	if (!FindNext())
	{
		CString strMessage;
		strMessage.Format("Finished searching for '%s'", m_strFind);
		AfxMessageBox(strMessage);
		GetFirstDocument();
	}
}

BOOL CReplaceDlg::FindNext() 
{
	IDispatch* pDispatch;
	m_pDocument->get_Selection(&pDispatch);
	CComQIPtr<ITextSelection, &IID_ITextSelection> pSelection(pDispatch);

	VARIANT_BOOL vbFound;
	pSelection->FindText(m_strFind.AllocSysString(), MatchFlags(), &vbFound);
	if (vbFound == VARIANT_FALSE)
		return GetNextDocument() ? FindNext() : FALSE;

	CPoint ptCurrent;
	pSelection->get_CurrentLine(&ptCurrent.y);
	pSelection->get_CurrentColumn(&ptCurrent.x);
	if (m_ptSelect == CPoint(-1, -1))
		m_ptSelect = ptCurrent;
	else if (ptCurrent.y == m_ptSelect.y && ptCurrent.x == m_ptSelect.x)
		return GetNextDocument() ? FindNext() : FALSE;

	return TRUE;
}

void CReplaceDlg::OnReplace()
{
	UpdateData(TRUE);
	Replace();
	OnFindNext();
}

BOOL CReplaceDlg::Replace()
{
	BSTR curSel;
	IDispatch* pDispatch;
	m_pDocument->get_Selection(&pDispatch);
	CComQIPtr<ITextSelection, &IID_ITextSelection> pSelection(pDispatch);
	pSelection->get_Text(&curSel);

	VARIANT_BOOL bRetVal = VARIANT_FALSE;
	CString strCurSel(curSel);
	int nResult = m_bMatchCase ? strCurSel.Compare(m_strFind) : 
		strCurSel.CompareNoCase(m_strFind);
	if (nResult == 0)		// A match!
	{
		VERIFY_OK( pSelection->ReplaceText(bstr_t(m_strFind),
			bstr_t(m_strReplace), MatchFlags(), &bRetVal) );
	}

	return bRetVal != VARIANT_FALSE;
}

void CReplaceDlg::OnReplaceAll() 
{
	UpdateData(TRUE);
	GetFirstDocument();
	do
	{
		Replace();
	} while	(FindNext());

	CString strMessage;
	strMessage.Format("Finished searching for '%s'", m_strFind);
	AfxMessageBox(strMessage);
	GetFirstDocument();
}

void CReplaceDlg::OnNextDoc() 
{
	GetFirstDocument();
}

void CReplaceDlg::OnDestroy() 
{
	UpdateData(TRUE);
	m_recentFind.Add(m_strFind);
	m_recentReplace.Add(m_strReplace);
	CDialog::OnDestroy();
}
