#if !defined(AFX_TRACEDLG_H__221E37DA_D46C_11D0_A409_000000000000__INCLUDED_)
#define AFX_TRACEDLG_H__221E37DA_D46C_11D0_A409_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// TraceDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTraceDlg dialog

class CTraceDlg : public CDialog
{
// Construction
public:
	CTraceDlg(CMapStringToPtr& mapExpr, CMapStringToPtr& mapEnable,
		CWnd* pParent = NULL);

// Dialog Data
	//{{AFX_DATA(CTraceDlg)
	enum { IDD = IDD_TRACE_DIALOG };
	CListBox	m_listExpr;
	CButton	m_btnClose;
	CEdit	m_edtExpr;
	CButton	m_btnRemove;
	CButton	m_btnAdd;
	CCheckListBox	m_listPoints;
	CString	m_strExpr;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTraceDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CStringArray* GetPointExprArray();
	CMapStringToPtr& m_mapExpr;
	CMapStringToPtr& m_mapEnable;

	// Generated message map functions
	//{{AFX_MSG(CTraceDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeEditExpression();
	afx_msg void OnButtonAdd();
	afx_msg void OnButtonRemove();
	afx_msg void OnSelChangeListExpressions();
	afx_msg void OnSelChangeListTracepoints();
	afx_msg void OnClose();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRACEDLG_H__221E37DA_D46C_11D0_A409_000000000000__INCLUDED_)
