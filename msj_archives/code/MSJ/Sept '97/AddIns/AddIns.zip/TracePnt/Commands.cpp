// Commands.cpp : implementation file
//

#include "stdafx.h"
#include <comdef.h>
#include "TracePnt.h"
#include "Commands.h"
#include "TraceDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCommands

CCommands::CCommands()
{
	m_pApplication == NULL;
	m_pApplicationEventsObj = NULL;
	m_pDebuggerEventsObj = NULL;
	m_pDebugger == NULL;
}

CCommands::~CCommands()
{
	ASSERT (m_pApplication != NULL);
	m_pApplication->Release();
	m_pDebugger->Release();
}

void CCommands::CleanUpMaps()
{
	for (POSITION pos = m_mapExpr.GetStartPosition(); pos != NULL; )
	{
		CString strPoint;
		CStringArray* pExpr = NULL;
		m_mapExpr.GetNextAssoc(pos, strPoint, (void*&)pExpr);
		ASSERT (pExpr != NULL);
		m_mapExpr.RemoveKey(strPoint);
		delete pExpr;
	}

	for (pos = m_mapEnable.GetStartPosition(); pos != NULL; )
	{
		CString strPoint;
		BOOL* pEnable = NULL;
		m_mapEnable.GetNextAssoc(pos, strPoint, (void*&)pEnable);
		ASSERT (pEnable != NULL);
		m_mapEnable.RemoveKey(strPoint);
		delete pEnable;
	}
}

void CCommands::SetApplicationObject(IApplication* pApplication)
{
	// This function assumes pApplication has already been AddRef'd
	//  for us, which CDSAddIn did in its QueryInterface call
	//  just before it called us.
	m_pApplication = pApplication;

	// Create Application event handlers
	XApplicationEventsObj::CreateInstance(&m_pApplicationEventsObj);
	m_pApplicationEventsObj->AddRef();
	m_pApplicationEventsObj->Connect(m_pApplication);
	m_pApplicationEventsObj->m_pCommands = this;

	// Create Debugger event handler
	CComPtr<IDispatch> pDebugger;
	if (SUCCEEDED(m_pApplication->get_Debugger(&pDebugger)) 
		&& pDebugger != NULL)
	{
		XDebuggerEventsObj::CreateInstance(&m_pDebuggerEventsObj);
		m_pDebuggerEventsObj->AddRef();
		m_pDebuggerEventsObj->Connect(pDebugger);
		m_pDebuggerEventsObj->m_pCommands = this;

		VERIFY(SUCCEEDED(pDebugger->QueryInterface(IID_IDebugger,
			(LPVOID*) &m_pDebugger)));
	}
}

void CCommands::UnadviseFromEvents()
{
	ASSERT (m_pApplicationEventsObj != NULL);
	m_pApplicationEventsObj->Disconnect(m_pApplication);
	m_pApplicationEventsObj->Release();
	m_pApplicationEventsObj = NULL;

	if (m_pDebuggerEventsObj != NULL)
	{
		// Since we were able to connect to the Debugger events, we
		//  should be able to access the Debugger object again to
		//  unadvise from its events (thus the VERIFY_OK below--see stdafx.h).
		CComPtr<IDispatch> pDebugger;
		VERIFY_OK(m_pApplication->get_Debugger(&pDebugger));
		ASSERT (pDebugger != NULL);
		m_pDebuggerEventsObj->Disconnect(pDebugger);
		m_pDebuggerEventsObj->Release();
		m_pDebuggerEventsObj = NULL;
	}
}


/////////////////////////////////////////////////////////////////////////////
// Event handlers

// TODO: Fill out the implementation for those events you wish handle
//  Use m_pCommands->GetApplicationObject() to access the Developer
//  Studio Application object

// Application events

HRESULT CCommands::XApplicationEvents::BeforeBuildStart()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::BuildFinish(long nNumErrors, long nNumWarnings)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::BeforeApplicationShutDown()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::DocumentOpen(IDispatch* theDocument)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::BeforeDocumentClose(IDispatch* theDocument)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::DocumentSave(IDispatch* theDocument)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::NewDocument(IDispatch* theDocument)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::WindowActivate(IDispatch* theWindow)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::WindowDeactivate(IDispatch* theWindow)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::WorkspaceOpen()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::WorkspaceClose()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	m_pCommands->CleanUpMaps();
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::NewWorkspace()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

// Debugger event

HRESULT CCommands::XDebuggerEvents::BreakpointHit(IDispatch* pBP)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	CComQIPtr<IBreakpoint, &IID_IBreakpoint> pBreakpoint = pBP;

	// We only care about line# breakpoints.  We can tell whether this
	//  is a line# breakpoint by seeing whether its Location property
	//  begins with a period (e.g., ".253")

	CComBSTR bstrLocation;
	pBreakpoint->get_Location(&bstrLocation);
	if (bstrLocation.Length() == 0 || *(BSTR)bstrLocation != '.')
		return S_OK;

	// Is it enabled as a tracepoint?

	CComBSTR bstrFile;
	pBreakpoint->get_File(&bstrFile);
	CString strFullInfo = (BSTR) bstrFile;
	strFullInfo += (BSTR) bstrLocation;
	BOOL* pEnable = NULL;
	m_pCommands->m_mapEnable.Lookup(strFullInfo, (void*&)pEnable);
	if (pEnable == NULL || *pEnable == FALSE)
		return S_OK;

	// Yes, it's a tracepoint.  Let's output the expressions.

	CStringArray* pExprArray = NULL;
	m_pCommands->m_mapExpr.Lookup(strFullInfo, (void*&)pExprArray);
	ASSERT(pExprArray);

	IDebugger* pDebugger = m_pCommands->GetDebuggerObject();
	IApplication* pApplication = m_pCommands->GetApplicationObject();
	for (int nLoop = 0; nLoop < pExprArray->GetSize(); nLoop++)
	{
		CComBSTR bstrValue(_T("<Expression could not be evaluated>"));
		pDebugger->Evaluate(CComBSTR(pExprArray->GetAt(nLoop)),
			&bstrValue);

		CComBSTR bstrOut(pExprArray->GetAt(nLoop));
		bstrOut += CComBSTR(_T(" = "));
		bstrOut += bstrValue;

		pApplication->PrintToOutputWindow(bstrOut);
	}

	pDebugger->Go();
	return S_OK;
}


/////////////////////////////////////////////////////////////////////////////
// CCommands methods

STDMETHODIMP CCommands::TracePntCommandMethod() 
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// Add line breakpoints to Map
	
	CComPtr<IDispatch> pDisp;
	VERIFY_OK(m_pDebugger->get_Breakpoints(&pDisp));
	CComQIPtr<IBreakpoints, &IID_IBreakpoints> pBreakpoints = pDisp;
	long cBreakpoints;
	VERIFY_OK(pBreakpoints->get_Count(&cBreakpoints));

	if (cBreakpoints == 0)
	{
		AfxMessageBox("This workspace has no breakpoints set.");
		return S_OK;
	}

	for (long i=0; i < cBreakpoints; i++)
	{
		pDisp = NULL;
		pBreakpoints->Item(COleVariant(i), &pDisp);
		CComQIPtr<IBreakpoint, &IID_IBreakpoint> pBreakpoint = pDisp;

		// We only care about line breakpoints.  We can tell whether this
		//  is a line breakpoint by seeing whether its Location property
		//  begins with a period (e.g., ".253")

		CComBSTR bstrLocation;
		pBreakpoint->get_Location(&bstrLocation);
		if (bstrLocation.Length() > 0 && *(BSTR)bstrLocation == '.')
		{
			CComBSTR bstrFile;
			pBreakpoint->get_File(&bstrFile);
			CString strFullInfo = (BSTR) bstrFile;
			strFullInfo += (BSTR) bstrLocation;
			
			void* temp;
			if (!m_mapExpr.Lookup(strFullInfo, temp))
			{
				m_mapExpr.SetAt(strFullInfo, new CStringArray);
				m_mapEnable.SetAt(strFullInfo, new BOOL(FALSE));
			}
		}
	}

	VERIFY_OK(m_pApplication->EnableModeless(VARIANT_FALSE));

	CTraceDlg dlg(m_mapExpr, m_mapEnable);
	dlg.DoModal();
		
	VERIFY_OK(m_pApplication->EnableModeless(VARIANT_TRUE));
	return S_OK;
}
