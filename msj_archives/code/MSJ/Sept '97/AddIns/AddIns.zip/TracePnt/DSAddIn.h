// DSAddIn.h : header file
//

#if !defined(AFX_DSADDIN_H__221E37D5_D46C_11D0_A409_000000000000__INCLUDED_)
#define AFX_DSADDIN_H__221E37D5_D46C_11D0_A409_000000000000__INCLUDED_

#include "commands.h"

// {221E37C2-D46C-11D0-A409-000000000000}
DEFINE_GUID(CLSID_DSAddIn,
0x221e37c2, 0xd46c, 0x11d0, 0xa4, 0x9, 0, 0, 0, 0, 0, 0);

/////////////////////////////////////////////////////////////////////////////
// CDSAddIn

class CDSAddIn : 
	public IDSAddIn,
	public CComObjectRoot,
	public CComCoClass<CDSAddIn, &CLSID_DSAddIn>
{
public:
	DECLARE_REGISTRY(CDSAddIn, "TracePnt.DSAddIn.1",
		"TRACEPNT Developer Studio Add-in", IDS_TRACEPNT_LONGNAME,
		THREADFLAGS_BOTH)

	CDSAddIn() {}
	BEGIN_COM_MAP(CDSAddIn)
		COM_INTERFACE_ENTRY(IDSAddIn)
	END_COM_MAP()
	DECLARE_NOT_AGGREGATABLE(CDSAddIn)

// IDSAddIns
public:
	STDMETHOD(OnConnection)(THIS_ IApplication* pApp, VARIANT_BOOL bFirstTime,
		long dwCookie, VARIANT_BOOL* OnConnection);
	STDMETHOD(OnDisconnection)(THIS_ VARIANT_BOOL bLastTime);

protected:
	CCommandsObj* m_pCommands;
	DWORD m_dwCookie;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DSADDIN_H__221E37D5_D46C_11D0_A409_000000000000__INCLUDED)
