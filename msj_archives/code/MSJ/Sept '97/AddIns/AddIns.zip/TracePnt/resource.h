//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TracePnt.rc
//
#define IDS_TRACEPNT_LONGNAME           1
#define IDS_TRACEPNT_DESCRIPTION        2
#define IDS_CMD_STRING                  3
#define IDR_TOOLBAR_MEDIUM              128
#define IDR_TOOLBAR_LARGE               129
#define IDD_TRACE_DIALOG                129
#define IDC_LIST_TRACEPOINTS            1001
#define IDC_EDIT_EXPRESSION             1002
#define IDC_LIST_EXPRESSIONS            1003
#define IDC_BUTTON_ADD                  1004
#define IDC_BUTTON_REMOVE               1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
