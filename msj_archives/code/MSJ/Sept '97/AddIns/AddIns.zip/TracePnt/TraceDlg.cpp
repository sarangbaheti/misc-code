// TraceDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "TraceDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTraceDlg dialog


CTraceDlg::CTraceDlg(CMapStringToPtr& mapExpr, CMapStringToPtr& mapEnable,
	CWnd* pParent /*=NULL*/)
: CDialog(CTraceDlg::IDD, pParent),
  m_mapExpr(mapExpr),
  m_mapEnable(mapEnable)
{
	//{{AFX_DATA_INIT(CTraceDlg)
	m_strExpr = _T("");
	//}}AFX_DATA_INIT
}


void CTraceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTraceDlg)
	DDX_Control(pDX, IDC_LIST_EXPRESSIONS, m_listExpr);
	DDX_Control(pDX, IDOK, m_btnClose);
	DDX_Control(pDX, IDC_EDIT_EXPRESSION, m_edtExpr);
	DDX_Control(pDX, IDC_BUTTON_REMOVE, m_btnRemove);
	DDX_Control(pDX, IDC_BUTTON_ADD, m_btnAdd);
	DDX_Control(pDX, IDC_LIST_TRACEPOINTS, m_listPoints);
	DDX_Text(pDX, IDC_EDIT_EXPRESSION, m_strExpr);
	//}}AFX_DATA_MAP
}

CStringArray* CTraceDlg::GetPointExprArray()
{
	CString strPoint;
	CStringArray* pArray;
	int nIndex = m_listPoints.GetCurSel();
	ASSERT(nIndex >= 0);

	m_listPoints.GetText(nIndex, strPoint);
	VERIFY( m_mapExpr.Lookup(strPoint, (void*&)pArray) );
	ASSERT_VALID( pArray );

	return pArray;
}

BEGIN_MESSAGE_MAP(CTraceDlg, CDialog)
	//{{AFX_MSG_MAP(CTraceDlg)
	ON_EN_CHANGE(IDC_EDIT_EXPRESSION, OnChangeEditExpression)
	ON_BN_CLICKED(IDC_BUTTON_ADD, OnButtonAdd)
	ON_BN_CLICKED(IDC_BUTTON_REMOVE, OnButtonRemove)
	ON_LBN_SELCHANGE(IDC_LIST_EXPRESSIONS, OnSelChangeListExpressions)
	ON_LBN_SELCHANGE(IDC_LIST_TRACEPOINTS, OnSelChangeListTracepoints)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTraceDlg message handlers

BOOL CTraceDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	POSITION pos = m_mapExpr.GetStartPosition();
	for (int nLoop = 0; pos != NULL; nLoop++)
    {
		void* temp;
		CString strPoint;
		m_mapExpr.GetNextAssoc(pos, strPoint, temp);
		ASSERT(temp);
		m_listPoints.AddString(strPoint);
    }

	pos = m_mapEnable.GetStartPosition();
	for (nLoop = 0; pos != NULL; nLoop++)
	{
		BOOL* pEnable;
		CString strPoint;
		m_mapEnable.GetNextAssoc(pos, strPoint, (void*&)pEnable);
		ASSERT(pEnable && (*pEnable == TRUE || *pEnable == FALSE));
		m_listPoints.SetCheck(nLoop, *pEnable);
	}

	m_listPoints.SetCurSel(0);
	OnSelChangeListTracepoints();
	return TRUE;
}

void CTraceDlg::OnChangeEditExpression() 
{
	UpdateData(TRUE);
	if (m_strExpr.GetLength())
	{
		m_btnAdd.EnableWindow(TRUE);
		m_btnClose.SetButtonStyle(BS_PUSHBUTTON, TRUE);
		SendMessage(DM_SETDEFID, IDC_BUTTON_ADD, 0);
		m_btnAdd.SetButtonStyle(BS_DEFPUSHBUTTON, TRUE);
	}
	else
	{
		m_btnAdd.EnableWindow(FALSE);
		m_btnAdd.SetButtonStyle(BS_PUSHBUTTON, TRUE);
		SendMessage(DM_SETDEFID, IDOK, 0);
		m_btnClose.SetButtonStyle(BS_DEFPUSHBUTTON, TRUE);
	}
}

void CTraceDlg::OnButtonAdd() 
{
	// Add expression to map

	GetPointExprArray()->Add(m_strExpr);
	
	// Add expression to list box and remove from edit box
	
	int nIndex = m_listExpr.AddString(m_strExpr);
	m_strExpr.Empty();
	UpdateData(FALSE);
	OnChangeEditExpression();
	m_edtExpr.SetFocus();
}

void CTraceDlg::OnButtonRemove() 
{
	// Remove expression from list box
	
	CString strExpr;
	int nIndex = m_listExpr.GetCurSel();
	m_listExpr.GetText(nIndex, strExpr);
	m_listExpr.DeleteString(nIndex);
	if (m_listExpr.GetCount() == 0)
		m_btnRemove.EnableWindow(FALSE);

	// Remove expression from map
	
	CStringArray* pArray = GetPointExprArray();
	for (nIndex = 0; nIndex < pArray->GetSize(); nIndex++)
	{
		if (pArray->GetAt(nIndex) == strExpr)
			pArray->RemoveAt(nIndex);
	}
}

void CTraceDlg::OnSelChangeListExpressions() 
{
	m_btnRemove.EnableWindow(TRUE);
	int nIndex = m_listExpr.GetCurSel();
	m_listExpr.GetText(nIndex, m_strExpr);

	UpdateData(FALSE);
	OnChangeEditExpression();
	m_edtExpr.SetFocus();
	m_edtExpr.SetSel(0, -1);
}

void CTraceDlg::OnSelChangeListTracepoints() 
{
	m_listExpr.ResetContent();
	CStringArray* pArray = GetPointExprArray();
	for (int nIndex = 0; nIndex < pArray->GetSize(); nIndex++)
		m_listExpr.AddString(pArray->GetAt(nIndex));
}

void CTraceDlg::OnClose() 
{
	POSITION pos = m_mapEnable.GetStartPosition();
	for (int nLoop = 0; pos != NULL; nLoop++)
	{
		BOOL* pEnable;
		CString strPoint;
		m_mapEnable.GetNextAssoc(pos, strPoint, (void*&)pEnable);
		ASSERT(pEnable);

		*pEnable = m_listPoints.GetCheck(nLoop);
		ASSERT(*pEnable == FALSE || *pEnable == TRUE);
	}
	
	CDialog::OnClose();
}

void CTraceDlg::OnOK() 
{
	OnClose();	
	CDialog::OnOK();
}
