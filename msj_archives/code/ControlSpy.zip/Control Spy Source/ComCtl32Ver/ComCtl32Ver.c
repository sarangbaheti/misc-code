// ComCtl32Ver.c : Implementation File

// Get Common Control version information.

// Mark J. Finocchio (markfi), Microsoft Corporation

// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright  1994-1996  Microsoft Corporation.  All Rights Reserved.

// Included files
#include <windows.h>
#include <winuser.h>
#include "Resource\Resource.h"

// Typedefs
typedef struct _DllVersionInfo
{
	DWORD cbSize;
	DWORD dwMajorVersion;
	DWORD dwMinorVersion;
	DWORD dwBuildNumber;
	DWORD dwPlatformID;
} DLLVERSIONINFO;
typedef HRESULT (CALLBACK* DLLGETVERSIONPROC)(DLLVERSIONINFO *);

// Function prototypes
HRESULT GetComCtlVersion(LPDWORD pdwMajor,LPDWORD pdwMinor);

// Main function
int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,PSTR szCmdLine,int iCmdShow)
{
	DWORD dwMajor;
	DWORD dwMinor;
	TCHAR szVer[31];
	TCHAR szDisp[81];

	// Get common control version
	GetComCtlVersion(&dwMajor,&dwMinor);
	wsprintf(szVer,"COMCTL32 Version %d.%d\n",dwMajor,dwMinor);
	wsprintf(szDisp,"%s\nUnknown distribution method",szVer);

	switch(dwMajor)
	{
		case 4:
			switch(dwMinor)
			{
				case 0:
					wsprintf(szDisp,"%s\nDistributed via Microsoft Windows 95/Windows NT 4.0",szVer);
					break;

				case 70:
					wsprintf(szDisp,"%s\nDistributed via Microsoft Internet Explorer 3.x",szVer);
					break;

				case 71:
					wsprintf(szDisp,"%s\nDistributed via Microsoft Internet Explorer 4.0",szVer);
					break;

				case 72:
					wsprintf(szDisp,"%s\nDistributed via Microsoft Internet Explorer 4.01/Windows 98",szVer);
					break;
			}
			break;

		case 5:
			switch(dwMinor)
			{
				case 0:
					wsprintf(szDisp,"%s\nDistributed via Microsoft Windows NT 5.0",szVer);
					break;
			}
			break;		
	}

	// Output version information
	return MessageBox(NULL,szDisp,"Common Control 32 Version",MB_OK|MB_ICONINFORMATION);
}

//        Name: GetComCtlVersion
// Description: Retrieves COMCTL32.DLL version information
//  Parameters: Pointer to major number, pointer to minor number
//     Returns: E_INVALIDARG or E_FAIL on error, S_OK on success
HRESULT GetComCtlVersion(LPDWORD pdwMajor, LPDWORD pdwMinor)
{
	HINSTANCE hComCtl;

	if(IsBadWritePtr(pdwMajor,sizeof(DWORD)) || IsBadWritePtr(pdwMinor,sizeof(DWORD)))
		return E_INVALIDARG;

	// load the DLL
	hComCtl = LoadLibrary(TEXT("comctl32.dll"));

	if(hComCtl)
	{
		HRESULT hr = S_OK;
		DLLGETVERSIONPROC pDllGetVersion;
   
		// You must get this function explicitly because earlier versions of the DLL 
		// don't implement this function. That makes the lack of implementation of the 
		// function a version marker in itself.
		pDllGetVersion = (DLLGETVERSIONPROC)GetProcAddress(hComCtl,TEXT("DllGetVersion"));
   
		if(pDllGetVersion)
		{
			DLLVERSIONINFO dvi;
      
			ZeroMemory(&dvi,sizeof(dvi));
			dvi.cbSize = sizeof(dvi);
   
			hr = (*pDllGetVersion)(&dvi);
      
			if(SUCCEEDED(hr))
			{
				*pdwMajor = dvi.dwMajorVersion;
				*pdwMinor = dvi.dwMinorVersion;
			}
			else
				hr = E_FAIL;
		}
		else
		{
			// If GetProcAddress failed, then the DLL is a version previous to the one shipped with IE 3.x.
			*pdwMajor = 4;
			*pdwMinor = 0;
		}
   
		FreeLibrary(hComCtl);

		return hr;
	}

	return E_FAIL;
}