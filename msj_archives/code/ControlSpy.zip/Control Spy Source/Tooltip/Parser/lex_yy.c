/* \program files\mks\mksnt\lex -o ../Parser/lex_yy.c -P /progra~1/mks/etc/yylex.c ../Parser/cci.l */
#define YYNEWLINE 10
#define INITIAL 0
#define yy_endst 126
#define yy_nxtmax 654
#define YY_LA_SIZE 16

static unsigned short yy_la_act[] = {
 23, 26, 23, 26, 23, 26, 23, 26, 23, 26, 23, 26, 26, 23, 26, 23,
 26, 26, 8, 26, 23, 26, 23, 26, 23, 26, 23, 26, 23, 26, 23, 26,
 26, 25, 26, 25, 26, 24, 24, 23, 23, 23, 23, 23, 23, 23, 22, 23,
 23, 23, 23, 23, 21, 23, 23, 23, 23, 23, 18, 19, 20, 23, 23, 23,
 17, 23, 23, 23, 23, 14, 23, 23, 23, 9, 23, 8, 23, 23, 23, 7,
 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 15, 23,
 23, 23, 23, 23, 23, 11, 23, 23, 6, 23, 5, 23, 23, 23, 23, 4,
 23, 23, 23, 23, 23, 23, 23, 3, 23, 23, 23, 13, 23, 23, 12, 23,
 23, 23, 23, 23, 23, 23, 23, 23, 23, 2, 23, 23, 23, 23, 1, 23,
 23, 0, 23, 23, 23, 23, 23, 23, 23, 23, 10, 23, 0, 16, 23, 0

};

static unsigned char yy_look[] = {
 0
};

static short yy_final[] = {
 0, 0, 2, 4, 6, 8, 10, 12, 13, 15, 17, 18, 20, 22, 24, 26,
 28, 30, 32, 33, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46,
 48, 49, 50, 51, 52, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64,
 66, 67, 68, 69, 71, 72, 73, 75, 76, 77, 78, 79, 81, 82, 83, 84,
 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 96, 97, 98, 99, 100, 101,
 103, 104, 106, 106, 107, 108, 109, 110, 111, 113, 114, 115, 116, 117, 118, 119,
 121, 122, 123, 125, 126, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 139,
 140, 141, 142, 144, 145, 147, 148, 149, 150, 151, 152, 153, 154, 156, 159
};
#ifndef yy_state_t
#define yy_state_t unsigned char
#endif

static yy_state_t yy_begin[] = {
 0, 0, 0
};

static yy_state_t yy_next[] = {
 21, 21, 21, 21, 21, 21, 21, 21, 21, 19, 20, 21, 21, 19, 21, 21,
 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21,
 19, 21, 7, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 10, 21, 18,
 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 21, 21, 21, 21, 21, 21,
 21, 17, 6, 17, 17, 17, 9, 17, 17, 16, 17, 17, 17, 1, 12, 17,
 13, 17, 4, 3, 8, 17, 17, 17, 17, 17, 17, 21, 21, 21, 21, 17,
 21, 17, 6, 17, 17, 17, 17, 17, 17, 16, 17, 17, 17, 2, 17, 17,
 15, 17, 5, 3, 14, 17, 17, 17, 17, 17, 17, 21, 21, 21, 21, 21,
 20, 20, 22, 49, 20, 41, 42, 43, 50, 51, 52, 53, 54, 23, 23, 23,
 23, 23, 23, 23, 23, 23, 23, 20, 23, 23, 23, 23, 23, 23, 23, 23,
 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23,
 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23,
 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23,
 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23,
 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23,
 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23,
 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 24, 24, 24,
 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24,
 24, 24, 24, 24, 24, 24, 24, 25, 26, 27, 28, 24, 29, 24, 24, 24,
 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24,
 24, 24, 24, 24, 24, 24, 24, 25, 26, 27, 28, 30, 29, 31, 32, 33,
 34, 35, 36, 37, 39, 40, 44, 45, 46, 38, 47, 32, 55, 55, 55, 55,
 55, 55, 55, 55, 55, 55, 56, 57, 58, 48, 59, 30, 63, 31, 32, 33,
 34, 35, 36, 37, 39, 40, 44, 45, 46, 38, 47, 32, 37, 64, 65, 66,
 67, 68, 61, 69, 70, 60, 71, 62, 72, 73, 74, 75, 41, 42, 43, 77,
 78, 79, 80, 81, 98, 119, 84, 120, 121, 122, 123, 124, 37, 126, 126, 126,
 126, 126, 38, 126, 126, 76, 126, 126, 126, 126, 39, 40, 82, 82, 82, 82,
 82, 82, 82, 82, 82, 82, 84, 82, 82, 82, 82, 82, 82, 82, 82, 82,
 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 83, 82,
 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82,
 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82,
 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82,
 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82,
 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82,
 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 82, 85, 86, 87, 88,
 89, 90, 91, 92, 93, 94, 95, 96, 99, 97, 91, 102, 100, 103, 104, 105,
 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 101, 116, 85, 86, 87, 88,
 89, 90, 91, 92, 93, 94, 95, 89, 90, 125, 91, 102, 118, 103, 104, 105,
 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 101, 116, 126, 126, 117, 126,
 126, 126, 126, 126, 126, 126, 126, 126, 126, 116, 126, 126, 126, 126, 126, 126,
 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 115, 0

};

static yy_state_t yy_check[] = {
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 20, 20, 18, 48, 20, 40, 40, 40, 49, 50, 12, 52, 53, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 20, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 17, 17, 17,
 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17,
 17, 17, 17, 17, 17, 17, 17, 16, 25, 26, 27, 17, 28, 17, 17, 17,
 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17,
 17, 17, 17, 17, 17, 17, 17, 16, 25, 26, 27, 29, 28, 30, 15, 32,
 33, 34, 35, 14, 38, 39, 37, 44, 45, 14, 46, 13, 11, 11, 11, 11,
 11, 11, 11, 11, 11, 11, 9, 56, 57, 13, 58, 29, 62, 30, 15, 32,
 33, 34, 35, 14, 38, 39, 37, 44, 45, 14, 46, 13, 8, 63, 64, 65,
 66, 67, 8, 68, 69, 8, 70, 8, 71, 72, 61, 74, 75, 75, 75, 76,
 77, 78, 60, 80, 97, 118, 6, 119, 120, 121, 122, 123, 8, ~0, ~0, ~0,
 ~0, ~0, 8, ~0, ~0, 75, ~0, ~0, ~0, ~0, 61, 74, 7, 7, 7, 7,
 7, 7, 7, 7, 7, 7, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7,
 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 84, 85, 86, 87,
 5, 89, 90, 91, 92, 93, 94, 4, 96, 4, 99, 3, 99, 102, 103, 104,
 105, 106, 107, 108, 109, 101, 111, 112, 113, 2, 3, 115, 84, 85, 86, 87,
 5, 89, 90, 91, 92, 93, 94, 4, 96, 117, 99, 3, 1, 102, 103, 104,
 105, 106, 107, 108, 109, 101, 111, 112, 113, 2, 3, 115, ~0, ~0, 1, ~0,
 ~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0, 117, ~0, ~0, ~0, ~0, ~0, ~0,
 ~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0, 1, 0

};

static yy_state_t yy_default[] = {
 126, 17, 17, 17, 17, 17, 17, 126, 17, 17, 11, 126, 17, 17, 17, 17,
 17, 126, 126, 20, 126, 126, 126, 22, 17, 17, 17, 17, 17, 17, 17, 17,
 17, 17, 17, 17, 17, 17, 17, 17, 17, 126, 126, 126, 17, 17, 17, 17,
 17, 17, 17, 17, 17, 17, 17, 11, 17, 17, 17, 17, 17, 17, 17, 17,
 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17,
 17, 17, 7, 126, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17,
 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17,
 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 0
};

static short yy_base[] = {
 0, 539, 502, 502, 498, 491, 321, 428, 307, 293, 655, 300, 53, 282, 266, 269,
 217, 204, 83, 655, 119, 655, 141, 655, 655, 213, 213, 233, 222, 264, 264, 655,
 253, 267, 259, 254, 655, 259, 261, 265, 85, 655, 655, 655, 270, 254, 277, 655,
 58, 58, 53, 655, 63, 64, 655, 655, 283, 277, 293, 655, 317, 315, 292, 308,
 298, 299, 315, 302, 303, 315, 312, 322, 314, 655, 319, 348, 321, 330, 322, 655,
 334, 655, 655, 655, 486, 487, 489, 477, 655, 494, 480, 494, 499, 481, 497, 655,
 501, 338, 655, 488, 655, 492, 489, 487, 502, 498, 501, 499, 501, 509, 655, 506,
 514, 501, 655, 516, 655, 530, 330, 338, 332, 330, 332, 340, 655, 655, 655
};


#line 1 "/progra~1/mks/etc/yylex.c"
/*
 * Copyright 1988, 1992 by Mortice Kern Systems Inc.  All rights reserved.
 * All rights reserved.
 *
 * $Header: /u/rd/src/lex/RCS/yylex.c,v 1.44 1993/05/26 14:47:37 ignac Exp $
 *
 */
#include <stdlib.h>
#include <stdio.h>
#if	__STDC__
#define YY_ARGS(args)	args
#else
#define YY_ARGS(args)	()
#endif

#ifdef LEX_WINDOWS
#include <windows.h>

/*
 * define, if not already defined
 * the flag YYEXIT, which will allow
 * graceful exits from yylex()
 * without resorting to calling exit();
 */

#ifndef YYEXIT
#define YYEXIT	1
#endif

/*
 * the following is the handle to the current
 * instance of a windows program. The user
 * program calling yylex must supply this!
 */

extern HANDLE hInst;	

#endif	/* LEX_WINDOWS */

/*
 * Define m_textmsg() to an appropriate function for internationalized messages
 * or custom processing.
 */
#ifndef I18N
#define	m_textmsg(id, str, cls)	(str)
#else /*I18N*/
extern	char* m_textmsg YY_ARGS((int id, const char* str, char* cls));
#endif/*I18N*/

/*
 * Include string.h to get definition of memmove() and size_t.
 * If you do not have string.h or it does not declare memmove
 * or size_t, you will have to declare them here.
 */
#include <string.h>
/* Uncomment next line if memmove() is not declared in string.h */
/*extern char * memmove();*/
/* Uncomment next line if size_t is not available in stdio.h or string.h */
/*typedef unsigned size_t;*/
/* Drop this when LATTICE provides memmove */
#ifdef LATTICE
#define memmove	memcopy
#endif

/*
 * YY_STATIC determines the scope of variables and functions
 * declared by the lex scanner. It must be set with a -DYY_STATIC
 * option to the compiler (it cannot be defined in the lex program).
 */
#ifdef	YY_STATIC
/* define all variables as static to allow more than one lex scanner */
#define	YY_DECL	static
#else
/* define all variables as global to allow other modules to access them */
#define	YY_DECL	
#endif

/*
 * You can redefine yygetc. For YACC Tracing, compile this code
 * with -DYYTRACE to get input from yt_getc
 */
#ifdef YYTRACE
extern int	yt_getc YY_ARGS((void));
#define yygetc()	yt_getc()
#else
#define	yygetc()	getc(yyin) 	/* yylex input source */
#endif

/*
 * the following can be redefined by the user.
 */
#ifdef YYEXIT
#define	YY_FATAL(msg)	{ fprintf(yyout, "yylex: %s\n", msg); yyLexFatal = 1; }
#else /* YYEXIT */
#define	YY_FATAL(msg)	{ fprintf(stderr, "yylex: %s\n", msg); exit(1); }
#endif /* YYEXIT */

#define	ECHO		fputs(yytext, yyout)
#define	output(c)	putc((c), yyout) /* yylex sink for unmatched chars */
#define	YY_INTERACTIVE	1		/* save micro-seconds if 0 */
#define	YYLMAX		100		/* token and pushback buffer size */

/*
 * If %array is used (or defaulted), yytext[] contains the token.
 * If %pointer is used, yytext is a pointer to yy_tbuf[].
 */
YY_DECL char	yytext[YYLMAX+1];

#define	BEGIN		yy_start =
#define	REJECT		goto yy_reject
#define	NLSTATE		(yy_lastc = YYNEWLINE)
#define	YY_INIT \
	(yy_start = yyleng = yy_end = 0, yy_lastc = YYNEWLINE)
#define	yymore()	goto yy_more
#define	yyless(n)	if ((n) < 0 || (n) > yy_end) ; \
			else { YY_SCANNER; yyleng = (n); YY_USER; }

YY_DECL	void	yy_reset YY_ARGS((void));
YY_DECL	int	input	YY_ARGS((void));
YY_DECL	int	unput	YY_ARGS((int c));

/* functions defined in libl.lib */
extern	int	yywrap	YY_ARGS((void));
extern	void	yyerror	YY_ARGS((char *fmt, ...));
extern	void	yycomment	YY_ARGS((char *term));
extern	int	yymapch	YY_ARGS((int delim, int escape));

#line 16 "../Parser/cci.l"

// Included files
#include <windows.h>
#include <commctrl.h>
#include "cci.h"
#include "ytab.h"
#include "..\tooltip.h"

// Function prototypes
void stripquotes();

#line 128 "/progra~1/mks/etc/yylex.c"


#ifdef	YY_DEBUG
#undef	YY_DEBUG
#define	YY_DEBUG(fmt, a1, a2)	fprintf(stderr, fmt, a1, a2)
#else
#define	YY_DEBUG(fmt, a1, a2)
#endif

/*
 * The declaration for the lex scanner can be changed by
 * redefining YYLEX or YYDECL. This must be done if you have
 * more than one scanner in a program.
 */
#ifndef	YYLEX
#define	YYLEX yylex			/* name of lex scanner */
#endif

#ifndef YYDECL
#define	YYDECL	int YYLEX YY_ARGS((void))	/* declaration for lex scanner */
#endif

/*
 * stdin and stdout may not neccessarily be constants.
 * If stdin and stdout are constant, and you want to save a few cycles, then
 * #define YY_STATIC_STDIO 1 in this file or on the commandline when
 * compiling this file
 */
#ifndef YY_STATIC_STDIO
#define YY_STATIC_STDIO	0
#endif

#if YY_STATIC_STDIO
YY_DECL	FILE   *yyin = stdin;
YY_DECL	FILE   *yyout = stdout;
#else
YY_DECL	FILE   *yyin = (FILE *)0;
YY_DECL	FILE   *yyout = (FILE *)0;
#endif
YY_DECL	int	yylineno = 1;		/* line number */

/* yy_sbuf[0:yyleng-1] contains the states corresponding to yytext.
 * yytext[0:yyleng-1] contains the current token.
 * yytext[yyleng:yy_end-1] contains pushed-back characters.
 * When the user action routine is active,
 * yy_save contains yytext[yyleng], which is set to '\0'.
 * Things are different when YY_PRESERVE is defined. 
 */
static	yy_state_t yy_sbuf [YYLMAX+1];	/* state buffer */
static	int	yy_end = 0;		/* end of pushback */
static	int	yy_start = 0;		/* start state */
static	int	yy_lastc = YYNEWLINE;	/* previous char */
YY_DECL	int	yyleng = 0;		/* yytext token length */
#ifdef YYEXIT
static	int yyLexFatal;
#endif /* YYEXIT */

#ifndef YY_PRESERVE	/* the efficient default push-back scheme */

static	char yy_save;	/* saved yytext[yyleng] */

#define	YY_USER	{ /* set up yytext for user */ \
		yy_save = yytext[yyleng]; \
		yytext[yyleng] = 0; \
	}
#define	YY_SCANNER { /* set up yytext for scanner */ \
		yytext[yyleng] = yy_save; \
	}

#else		/* not-so efficient push-back for yytext mungers */

static	char yy_save [YYLMAX];
static	char *yy_push = yy_save+YYLMAX;

#define	YY_USER { \
		size_t n = yy_end - yyleng; \
		yy_push = yy_save+YYLMAX - n; \
		if (n > 0) \
			memmove(yy_push, yytext+yyleng, n); \
		yytext[yyleng] = 0; \
	}
#define	YY_SCANNER { \
		size_t n = yy_save+YYLMAX - yy_push; \
		if (n > 0) \
			memmove(yytext+yyleng, yy_push, n); \
		yy_end = yyleng + n; \
	}

#endif


#ifdef LEX_WINDOWS

/*
 * When using the windows features of lex,
 * it is necessary to load in the resources being
 * used, and when done with them, the resources must
 * be freed up, otherwise we have a windows app that
 * is not following the rules. Thus, to make yylex()
 * behave in a windows environment, create a new
 * yylex() which will call the original yylex() as
 * another function call. Observe ...
 */

/*
 * The actual lex scanner (usually yylex(void)).
 * NOTE: you should invoke yy_init() if you are calling yylex()
 * with new input; otherwise old lookaside will get in your way
 * and yylex() will die horribly.
 */
static int win_yylex();			/* prototype for windows yylex handler */

YYDECL {
	int wReturnValue;
	HANDLE hRes_table;
	unsigned short *old_yy_la_act;	/* remember previous pointer values */
	short *old_yy_final;
	yy_state_t *old_yy_begin;
	yy_state_t *old_yy_next;
	yy_state_t *old_yy_check;
	yy_state_t *old_yy_default;
	short *old_yy_base;

	/*
	 * the following code will load the required
	 * resources for a Windows based parser.
	 */

	hRes_table = LoadResource (hInst,
		FindResource (hInst, "UD_RES_yyLEX", "yyLEXTBL"));
	
	/*
	 * return an error code if any
	 * of the resources did not load
	 */

	if (hRes_table == NULL)
		return (0);
	
	/*
	 * the following code will lock the resources
	 * into fixed memory locations for the scanner
	 * (and remember previous pointer locations)
	 */

	old_yy_la_act = yy_la_act;
	old_yy_final = yy_final;
	old_yy_begin = yy_begin;
	old_yy_next = yy_next;
	old_yy_check = yy_check;
	old_yy_default = yy_default;
	old_yy_base = yy_base;

	yy_la_act = (unsigned short *)LockResource (hRes_table);
	yy_final = (short *)(yy_la_act + Sizeof_yy_la_act);
	yy_begin = (yy_state_t *)(yy_final + Sizeof_yy_final);
	yy_next = (yy_state_t *)(yy_begin + Sizeof_yy_begin);
	yy_check = (yy_state_t *)(yy_next + Sizeof_yy_next);
	yy_default = (yy_state_t *)(yy_check + Sizeof_yy_check);
	yy_base = (yy_state_t *)(yy_default + Sizeof_yy_default);


	/*
	 * call the standard yylex() code
	 */

	wReturnValue = win_yylex();

	/*
	 * unlock the resources
	 */

	UnlockResource (hRes_table);

	/*
	 * and now free the resource
	 */

	FreeResource (hRes_table);

	/*
	 * restore previously saved pointers
	 */

	yy_la_act = old_yy_la_act;
	yy_final = old_yy_final;
	yy_begin = old_yy_begin;
	yy_next = old_yy_next;
	yy_check = old_yy_check;
	yy_default = old_yy_default;
	yy_base = old_yy_base;

	return (wReturnValue);
}	/* end function */

static int win_yylex() {

#else /* LEX_WINDOWS */

/*
 * The actual lex scanner (usually yylex(void)).
 * NOTE: you should invoke yy_init() if you are calling yylex()
 * with new input; otherwise old lookaside will get in your way
 * and yylex() will die horribly.
 */
YYDECL {

#endif /* LEX_WINDOWS */

	register int c, i, yybase;
	unsigned	yyst;	/* state */
	int yyfmin, yyfmax;	/* yy_la_act indices of final states */
	int yyoldi, yyoleng;	/* base i, yyleng before look-ahead */
	int yyeof;		/* 1 if eof has already been read */

#line 342 "/progra~1/mks/etc/yylex.c"



#if !YY_STATIC_STDIO
	if (yyin == (FILE *)0)
		yyin = stdin;
	if (yyout == (FILE *)0)
		yyout = stdout;
#endif

#ifdef YYEXIT
	yyLexFatal = 0;
#endif /* YYEXIT */

	yyeof = 0;
	i = yyleng;
	YY_SCANNER;

  yy_again:
	yyleng = i;
	/* determine previous char. */
	if (i > 0)
		yy_lastc = yytext[i-1];
	/* scan previously accepted token adjusting yylineno */
	while (i > 0)
		if (yytext[--i] == YYNEWLINE)
			yylineno++;
	/* adjust pushback */
	yy_end -= yyleng;
	memmove(yytext, yytext+yyleng, (size_t) yy_end);
	i = 0;

  yy_contin:
	yyoldi = i;

	/* run the state machine until it jams */
	yyst = yy_begin[yy_start + (yy_lastc == YYNEWLINE)];
	yy_sbuf[i] = (yy_state_t) yyst;
	do {
		YY_DEBUG(m_textmsg(1547, "<state %d, i = %d>\n", "I num1 num2"), yyst, i);
		if (i >= YYLMAX) {
			YY_FATAL(m_textmsg(1548, "Token buffer overflow", "E"));
#ifdef YYEXIT
			if (yyLexFatal)
				return -2;
#endif /* YYEXIT */
		}	/* endif */

		/* get input char */
		if (i < yy_end)
			c = yytext[i];		/* get pushback char */
		else if (!yyeof && (c = yygetc()) != EOF) {
			yy_end = i+1;
			yytext[i] = (char) c;
		} else /* c == EOF */ {
			c = EOF;		/* just to make sure... */
			if (i == yyoldi) {	/* no token */
				yyeof = 0;
				if (yywrap())
					return 0;
				else
					goto yy_again;
			} else {
				yyeof = 1;	/* don't re-read EOF */
				break;
			}
		}
		YY_DEBUG(m_textmsg(1549, "<input %d = 0x%02x>\n", "I num hexnum"), c, c);

		/* look up next state */
		while ((yybase = yy_base[yyst]+(unsigned char)c) > yy_nxtmax
		    || yy_check[yybase] != (yy_state_t) yyst) {
			if (yyst == yy_endst)
				goto yy_jammed;
			yyst = yy_default[yyst];
		}
		yyst = yy_next[yybase];
	  yy_jammed: ;
	  yy_sbuf[++i] = (yy_state_t) yyst;
	} while (!(yyst == yy_endst || YY_INTERACTIVE && yy_base[yyst] > yy_nxtmax && yy_default[yyst] == yy_endst));
	YY_DEBUG(m_textmsg(1550, "<stopped %d, i = %d>\n", "I num1 num2"), yyst, i);
	if (yyst != yy_endst)
		++i;

  yy_search:
	/* search backward for a final state */
	while (--i > yyoldi) {
		yyst = yy_sbuf[i];
		if ((yyfmin = yy_final[yyst]) < (yyfmax = yy_final[yyst+1]))
			goto yy_found;	/* found final state(s) */
	}
	/* no match, default action */
	i = yyoldi + 1;
	output(yytext[yyoldi]);
	goto yy_again;

  yy_found:
	YY_DEBUG(m_textmsg(1551, "<final state %d, i = %d>\n", "I num1 num2"), yyst, i);
	yyoleng = i;		/* save length for REJECT */
	
	/* pushback look-ahead RHS */
	if ((c = (int)(yy_la_act[yyfmin]>>9) - 1) >= 0) { /* trailing context? */
		unsigned char *bv = yy_look + c*YY_LA_SIZE;
		static unsigned char bits [8] = {
			1<<0, 1<<1, 1<<2, 1<<3, 1<<4, 1<<5, 1<<6, 1<<7
		};
		while (1) {
			if (--i < yyoldi) {	/* no / */
				i = yyoleng;
				break;
			}
			yyst = yy_sbuf[i];
			if (bv[(unsigned)yyst/8] & bits[(unsigned)yyst%8])
				break;
		}
	}

	/* perform action */
	yyleng = i;
	YY_USER;
	switch (yy_la_act[yyfmin] & 0777) {
	case 0:
#line 34 "../Parser/cci.l"
	{ return YMSG; }
	break;
	case 1:
#line 35 "../Parser/cci.l"
	{ return YSTYLE; }
	break;
	case 2:
#line 36 "../Parser/cci.l"
	{
							  return YSETWINLONG;
							}
	break;
	case 3:
#line 39 "../Parser/cci.l"
	{
							  return YRECREATE;
							}
	break;
	case 4:
#line 45 "../Parser/cci.l"
	{ return YSTRBUF; }
	break;
	case 5:
#line 47 "../Parser/cci.l"
	{ 
								UINT x;
								strcpy(yylval.szVal,yytext); 
								// Remove quotes
								for(x=0;x<strlen((LPSTR)(yylval.szVal))-2;x++)
									((LPSTR)(yylval.szVal))[x] = ((LPSTR)(yylval.szVal))[x+1];
								((LPSTR)(yylval.szVal))[x] = '\0';
								return YSTR; 
							}
	break;
	case 6:
#line 57 "../Parser/cci.l"
	{ yylval.intVal=TRUE; return YBOOL; }
	break;
	case 7:
#line 58 "../Parser/cci.l"
	{ yylval.intVal=FALSE; return YBOOL; }
	break;
	case 8:
#line 60 "../Parser/cci.l"
	{ yylval.intVal=atoi(yytext); return YINT; }
	break;
	case 9:
#line 62 "../Parser/cci.l"
	{ yylval.intVal=(INT)NULL; return YNULL; }
	break;
	case 10:
#line 67 "../Parser/cci.l"
	{ return YMAKELONG; }
	break;
	case 11:
#line 68 "../Parser/cci.l"
	{ return YTOOLINFO; }
	break;
	case 12:
#line 69 "../Parser/cci.l"
	{ return YRECT; }
	break;
	case 13:
#line 70 "../Parser/cci.l"
	{ return YRGB; }
	break;
	case 14:
#line 71 "../Parser/cci.l"
	{ return YPOINT; }
	break;
	case 15:
#line 72 "../Parser/cci.l"
	{ return YTTHTI; }
	break;
	case 16:
#line 73 "../Parser/cci.l"
	{ return YMSG; }
	break;
	case 17:
#line 77 "../Parser/cci.l"
	{ yylval.intVal=sizeof(TOOLINFO); return YINT; }
	break;
	case 18:
#line 78 "../Parser/cci.l"
	{ yylval.intVal=(INT)g_hTool0; return YINT; }
	break;
	case 19:
#line 79 "../Parser/cci.l"
	{ yylval.intVal=(INT)g_hTool1; return YINT; }
	break;
	case 20:
#line 80 "../Parser/cci.l"
	{ yylval.intVal=(INT)g_hTool2; return YINT; }
	break;
	case 21:
#line 81 "../Parser/cci.l"
	{ yylval.intVal=(INT)g_hContainer; return  YINT; }
	break;
	case 22:
#line 82 "../Parser/cci.l"
	{
								yylval.intVal=(INT)g_hInstance; return YINT; }
	break;
	case 23:
#line 88 "../Parser/cci.l"
	{
								int dType;
								yylval.intVal = GetValue(yytext,&dType);
								switch(dType)
								{
									case VMSGID:
										return YMSGID;
									case VINT:
										return YINT;
									case VLPTCBK:
										return YLPTCBK;
								}
								return YUNKNOWN;
							}
	break;
	case 24:
#line 105 "../Parser/cci.l"
	{ ; }
	break;
	case 25:
#line 109 "../Parser/cci.l"
	{ ; }
	break;
	case 26:
#line 113 "../Parser/cci.l"
	{ return *yytext; }
	break;

#line 463 "/progra~1/mks/etc/yylex.c"

	}
	YY_SCANNER;
	i = yyleng;
	goto yy_again;			/* action fell though */

  yy_reject:
	YY_SCANNER;
	i = yyoleng;			/* restore original yytext */
	if (++yyfmin < yyfmax)
		goto yy_found;		/* another final state, same length */
	else
		goto yy_search;		/* try shorter yytext */

  yy_more:
	YY_SCANNER;
	i = yyleng;
	if (i > 0)
		yy_lastc = yytext[i-1];
	goto yy_contin;
}
/*
 * Safely switch input stream underneath LEX
 */
typedef struct yy_save_block_tag {
	FILE	* oldfp;
	int	oldline;
	int	oldend;
	int	oldstart;
	int	oldlastc;
	int	oldleng;
	char	savetext[YYLMAX+1];
	yy_state_t	savestate[YYLMAX+1];
} YY_SAVED;

YY_SAVED *
yySaveScan(fp)
FILE * fp;
{
	YY_SAVED * p;

	if ((p = (YY_SAVED *) malloc(sizeof(*p))) == NULL)
		return p;

	p->oldfp = yyin;
	p->oldline = yylineno;
	p->oldend = yy_end;
	p->oldstart = yy_start;
	p->oldlastc = yy_lastc;
	p->oldleng = yyleng;
	(void) memcpy(p->savetext, yytext, sizeof yytext);
	(void) memcpy((char *) p->savestate, (char *) yy_sbuf,
		sizeof yy_sbuf);

	yyin = fp;
	yylineno = 1;
	YY_INIT;

	return p;
}
/*f
 * Restore previous LEX state
 */
void
yyRestoreScan(p)
YY_SAVED * p;
{
	if (p == NULL)
		return;
	yyin = p->oldfp;
	yylineno = p->oldline;
	yy_end = p->oldend;
	yy_start = p->oldstart;
	yy_lastc = p->oldlastc;
	yyleng = p->oldleng;

	(void) memcpy(yytext, p->savetext, sizeof yytext);
	(void) memcpy((char *) yy_sbuf, (char *) p->savestate,
		sizeof yy_sbuf);
	free(p);
}
/*
 * User-callable re-initialization of yylex()
 */
void
yy_reset()
{
	YY_INIT;
	yylineno = 1;		/* line number */
}
/* get input char with pushback */
YY_DECL int
input()
{
	int c;
#ifndef YY_PRESERVE
	if (yy_end > yyleng) {
		yy_end--;
		memmove(yytext+yyleng, yytext+yyleng+1,
			(size_t) (yy_end-yyleng));
		c = yy_save;
		YY_USER;
#else
	if (yy_push < yy_save+YYLMAX) {
		c = *yy_push++;
#endif
	} else
		c = yygetc();
	yy_lastc = c;
	if (c == YYNEWLINE)
		yylineno++;
	return c;
}

/*f
 * pushback char
 */
YY_DECL int
unput(c)
	int c;
{
#ifndef YY_PRESERVE
	if (yy_end >= YYLMAX) {
		YY_FATAL(m_textmsg(1552, "Push-back buffer overflow", "E"));
	} else {
		if (yy_end > yyleng) {
			yytext[yyleng] = yy_save;
			memmove(yytext+yyleng+1, yytext+yyleng,
				(size_t) (yy_end-yyleng));
			yytext[yyleng] = 0;
		}
		yy_end++;
		yy_save = (char) c;
#else
	if (yy_push <= yy_save) {
		YY_FATAL(m_textmsg(1552, "Push-back buffer overflow", "E"));
	} else {
		*--yy_push = c;
#endif
		if (c == YYNEWLINE)
			yylineno--;
	}	/* endif */
	return c;
}

#line 116 "../Parser/cci.l"

/* USER SUBROUTINE SECTION */

int yywrap()
{
	return 1;
}