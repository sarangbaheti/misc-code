// Pager.c : Implementation File

// Control Spy: Pager

// Mark J. Finocchio (markfi), Microsoft Corporation

// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) 1998 Microsoft Corporation.  All Rights Reserved.

// Defines
#define CSMAIN

// Included files
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <richedit.h>
#include <stdio.h>

#include "Parser\Cci.h"
#include "Pager.h"
#include "Resource\Resource.h"

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//  ** User definable Control Implementation Code
/////////////////////////////////////////////////////////////////////////////////////////////////////////

// User global variables
HWND g_hToolbar = NULL;				// Value returned by 'toolbar' keyword in parser
HWND g_hCustom = NULL;				// Value returned by 'custom' in parser

HIMAGELIST g_hImageList;

//        Name: InitialControlStyles
// Description: Control styles used upon initial creation
//  Parameters: Pointer to styles and extended styles
//     Returns: none
void InitialControlStyles(LPDWORD p_pStyles,LPDWORD p_pExStyles)
{
	*p_pStyles = WS_CHILD|WS_VISIBLE|PGS_HORZ;
	*p_pExStyles = WS_EX_STATICEDGE;
}

//        Name: ControlStateCallback
// Description: Control state callback for user code
//  Parameters: State, can be CSPY_STARTUP, CSPY_SHUTDOWN, or user numeric state value provided
//				through interface
//     Returns: none
void ControlStateCallback(INT p_dState)
{
	// Customizable code placed here

	// Control handle is g_hControl
	// Parent handle is g_hContainer
	// Main Dialog handle is g_hDialog
	// Instance handle is g_hInstance

	switch(p_dState)
	{
		case 0:  // Numeric state generated via interface
			break;

		case CSPY_STARTUP:  // Control just created
		{
			TBBUTTON tbbStruct[10];
			LPSTR pLabels = "Sun\0Mercury\0Venus\0Earth\0Mars\0Jupiter\0Saturn\0Uranus\0Neptune\0Pluto\0\0";

			HDC hDC;
			HBITMAP hBitmap;
			int dX;

			// TOOLBAR child

			g_hToolbar = CreateWindowEx(0,TOOLBARCLASSNAME,NULL,WS_VISIBLE|WS_CHILD|TBSTYLE_FLAT|CCS_NORESIZE|CCS_NODIVIDER,
				0,0,0,0,g_hControl,NULL,g_hInstance,NULL);

			// Since created toolbar with CreateWindowEx, specify the button structure size
			// This step is not required if CreateToolbarEx was used
			SendMessage(g_hToolbar,TB_BUTTONSTRUCTSIZE,sizeof(TBBUTTON),0);

			// Create and initialize image list used for child toolbar
			g_hImageList = ImageList_Create(16,16,ILC_COLORDDB|ILC_MASK,10,1);
			// Load images based on color depth
			hDC = GetDC(g_hDialog);
			if(GetDeviceCaps(hDC,BITSPIXEL) <= 8)
				hBitmap = LoadBitmap(g_hInstance,MAKEINTRESOURCE(IDB_PLANETS4));
			else
				hBitmap = LoadBitmap(g_hInstance,MAKEINTRESOURCE(IDB_PLANETS));
			ReleaseDC(g_hDialog,hDC);
			// Add images to image list
			ImageList_AddMasked(g_hImageList,hBitmap,RGB(0,255,255));
			DeleteObject(hBitmap);

			// Add image lists to toolbar
			SendMessage(g_hToolbar,TB_SETIMAGELIST,0,(LPARAM)g_hImageList);

			// Add strings to toolbar
			SendMessage(g_hToolbar,TB_ADDSTRING,0,(LPARAM)pLabels);

			// Add buttons to control
			for(dX=0;dX<10;dX++)
			{
				tbbStruct[dX].iBitmap = dX;
				tbbStruct[dX].fsStyle = TBSTYLE_BUTTON;
				tbbStruct[dX].fsState = TBSTATE_ENABLED;
				tbbStruct[dX].idCommand = dX;
				tbbStruct[dX].dwData = 0;
				tbbStruct[dX].iString = dX;
			}
			SendMessage(g_hToolbar,TB_ADDBUTTONS,10,(LPARAM)tbbStruct);

			// Resize toolbar
			SendMessage(g_hToolbar,TB_AUTOSIZE,0,0);

			// Add child to pager control
			SendMessage(g_hControl,PGM_SETCHILD,0,(LPARAM)g_hToolbar);
			
			// Force control to recalculate size of contained window
			SendMessage(g_hControl,PGM_RECALCSIZE,0,0);
		}
			break;

		case CSPY_SHUTDOWN:  // Control spy closing
			
			// Clean up
			if(g_hImageList)
				ImageList_Destroy(g_hImageList);

			break;
	}
}

//        Name: ProcessControlNotification
// Description: Handles all notification messages from the contol, callbacks handled here
//  Parameters: Notification message structure
//     Returns: Result
LRESULT ProcessControlNotification(LPNMHDR p_pNotifyStruct)
{
	// Custom control notification messages handled here

	// Control handle is g_hControl
	// Parent handle is g_hContainer
	// Main Dialog handle is g_hDialog
	// Instance handle is g_hInstance

	LPNMPGCALCSIZE pNMPGCalcSize;
	LPNMPGSCROLL pNMPGScroll;

	switch(p_pNotifyStruct->code)
	{
		case PGN_CALCSIZE:  // Scrollable dimensions of contained window query, track via NMPGCALCSIZE
		{
			SIZE sizeControl;
			pNMPGCalcSize = (LPNMPGCALCSIZE)p_pNotifyStruct;
			// Add code here

			// Determine size of child
			SendMessage(g_hToolbar,TB_GETMAXSIZE,0,(LPARAM)&sizeControl);

			// Set requested size
			if(pNMPGCalcSize->dwFlag == PGF_CALCWIDTH)
				pNMPGCalcSize->iWidth = sizeControl.cx;
			if(pNMPGCalcSize->dwFlag == PGF_CALCHEIGHT)
				pNMPGCalcSize->iHeight = sizeControl.cy;
		}
			break;

		case PGN_SCROLL:  // Contained window is being scrolled, track via NMPGSCROLL
			pNMPGScroll = (LPNMPGSCROLL)p_pNotifyStruct;
			// Add code here
			break;

		// Common notifications
		case NM_RELEASEDCAPTURE:  // Control is releasing mouse capture, track via NMHDR
			// Use p_pNotifyStruct
			// Add code here
			break;
	}

	// Return
	return 0;
}

//        Name: ProcessControlCommand
// Description: Handles all command messages from the contol, callbacks handled here
//  Parameters: Command notification code
//     Returns: Result
LRESULT ProcessControlCommand(WORD p_wCode)
{
	// Control handle is g_hControl
	// Parent handle is g_hContainer
	// Main Dialog handle is g_hDialog
	// Instance handle is g_hInstance

	// Return
	return 0;
}

//        Name: RegisterControl
// Description: Used to register the control so it may be created
//  Parameters: none
//     Returns: none
void RegisterControl()
{
	INITCOMMONCONTROLSEX icc;

	// Initialize common controls structure
	icc.dwSize = sizeof(INITCOMMONCONTROLSEX);

	icc.dwICC = ICC_PAGESCROLLER_CLASS|ICC_BAR_CLASSES;

	// Initialize common control
	InitCommonControlsEx(&icc);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//  ** Background Logic Code
/////////////////////////////////////////////////////////////////////////////////////////////////////////

//        Name: WinMain
// Description: Main entry point
//  Parameters: Application instance, previous instance, command line, show command
//     Returns: Return code
int WINAPI WinMain(HINSTANCE p_hInstance,HINSTANCE p_hPrevInstance,PSTR p_szCmdLine,int p_iCmdShow)
{
	RegisterControl();

	// Make instance handle available to all functions
	g_hInstance = p_hInstance;

	// Initialize global variables
	g_dLastNotifyIndex = -1;
	g_dLastMessageIndex = -1;
	g_dLastSendMessageIndex = -1;
	g_dLastStylesIndex = -1;
	g_dLastExStylesIndex = -1;
	g_hStyles = NULL;
	g_hInformation = NULL;
	g_hControl = NULL;
	g_cFilter = '\0';
	g_dSLCurrent = -1;
	g_dSLCount = 0;
	g_pSL = NULL;
	g_pSLIndex = NULL;
	g_bSendAll = FALSE;
	g_bLogging = FALSE;
	g_hLogOn = NULL;
	g_hLogOff = NULL;

	// Main application dialog
	return DialogBox(p_hInstance,MAKEINTRESOURCE(IDD_MAINDIALOG),NULL,DlgProc);
}

//        Name: CreateControl
// Description: Creates and initializes the control on the specified window. The controls destination
//				size is that of the static rectangle IDC_CONTROL_RECT
//  Parameters: Creation styles, extended styles
//     Returns: none
void CreateControl(UINT p_dStyles,UINT p_dExStyles)
{
	RECT rectControl;
	POINT pointControl;
	SIZE sizeControl;

	// Get bounding rectangle of control and convert to client coordinates
	GetWindowRect(GetDlgItem(g_hDialog,IDC_CONTROL_RECT),&rectControl);
	pointControl.x = rectControl.left;
	pointControl.y = rectControl.top;
	sizeControl.cx = rectControl.right-rectControl.left;
	sizeControl.cy = rectControl.bottom-rectControl.top;
	ScreenToClient(g_hContainer,&pointControl);

	// Create control which starts at pointControl extends to sizeControl
	// >> Start control specific
	g_hControl =  CreateWindowEx(p_dExStyles,WC_PAGESCROLLER,NULL,p_dStyles,pointControl.x,pointControl.y,
		sizeControl.cx,sizeControl.cy,g_hContainer,NULL,g_hInstance,NULL);
	// End control specific <<

	// Check if control was created
	if(!g_hControl)
	{
		// >> Start control specific
		MessageBox(g_hDialog,"Unable to create control! Make sure common control version is at least 4.71 (IE4).","Error",MB_OK|MB_ICONSTOP);
		// End control specific <<
		PostMessage(g_hDialog,WM_CLOSE,0,0);
		return;
	}

	// Initialize control
	ControlStateCallback(CSPY_STARTUP);
}

//        Name: DialogProc
// Description: Dialog message callback
//  Parameters: Handle to dialog, message, message parameters
//     Returns: TRUE if handled message, FALSE otherwise
BOOL CALLBACK DlgProc(HWND p_hDlg,UINT p_iMsg,WPARAM p_wParam,LPARAM p_lParam)
{
	switch(p_iMsg)
	{
		// Initialize Dialog
		case WM_INITDIALOG:
		{
			DWORD dControlStyles;
			DWORD dControlExStyles;

			// Make dialog handle available to all functions
			g_hDialog = p_hDlg;
			// Create support controls (tooltips, images lists, etc.)
			CreateSupportControls();
			// Create control
			InitialControlStyles(&dControlStyles,&dControlExStyles);
			CreateControl(dControlStyles,dControlExStyles);
		}
			break;

		// Process command messages from interface
		case WM_COMMAND:
			return CommandHandler(HIWORD(p_wParam),LOWORD(p_wParam));

		// Close
		case WM_CLOSE:
			// Clean up
			ControlStateCallback(CSPY_SHUTDOWN);
			if(g_pSL)
				free(g_pSL);
			if(g_pSLIndex)
				free(g_pSLIndex);
			// Uninstall hook and end dialog
			UnhookWindowsHookEx(g_hGMHook);
			UnhookWindowsHookEx(g_hCWHook);
			EndDialog(p_hDlg,0);
			return TRUE;
	}

	// Did not process message
	return FALSE;
}

//        Name: CreateSupportControls
// Description: Create all controls that make up the background support
//  Parameters: none
//     Returns: none
void CreateSupportControls()
{
	RECT rectContainer;
	POINT pointContainer;
	SIZE sizeContainer;
	WNDCLASSEX wcContainer;
	HWND hSendMsgList;
	UINT dIndex;
	int dX;
	HANDLE hImageDestroy;
	HANDLE hImageDestroySmall;
	HANDLE hImageLoad;
	HANDLE hImageExecute;

	// Create tool tips control
	g_hToolTips = CreateWindowEx(0,TOOLTIPS_CLASS,NULL,TTS_ALWAYSTIP,CW_USEDEFAULT,CW_USEDEFAULT,
		CW_USEDEFAULT,CW_USEDEFAULT,g_hDialog,NULL,g_hInstance,NULL);
	// Make tool tips are above all other siblings
	SetWindowPos(g_hToolTips,HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);
	
	// Enumerate all child controls to register them with the tool tip control
	EnumChildWindows(g_hDialog,AddToolTipEnum,(LPARAM)g_hDialog);

	// Install a hook to monitor all messages going to the dialog and its children
	// and pass them on to the tooltip control
	g_hGMHook = SetWindowsHookEx(WH_GETMESSAGE,GetMsgProc,NULL,GetCurrentThreadId());	
	g_hCWHook = SetWindowsHookEx(WH_CALLWNDPROC,CallWndProc,NULL,GetCurrentThreadId());	

	// Create container for control
	// Get bounding rectangle of container and convert to client coordinates
	GetWindowRect(GetDlgItem(g_hDialog,IDC_CONTAINER_RECT),&rectContainer);
	pointContainer.x = rectContainer.left;
	pointContainer.y = rectContainer.top;
	sizeContainer.cx = rectContainer.right-rectContainer.left;
	sizeContainer.cy = rectContainer.bottom-rectContainer.top;
	ScreenToClient(g_hDialog,&pointContainer);

	// Create Container which starts at pointContainer extends to sizeContainer
	wcContainer.cbSize = sizeof(wcContainer);
	wcContainer.style = CS_HREDRAW|CS_VREDRAW;
	wcContainer.lpfnWndProc = ContainerWndProc;
	wcContainer.cbClsExtra = 0;
	wcContainer.cbWndExtra = 0;
	wcContainer.hInstance = g_hInstance;
	wcContainer.hIcon = NULL;
	wcContainer.hCursor = LoadCursor(NULL,IDC_ARROW);
	wcContainer.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	wcContainer.lpszMenuName = NULL;
	wcContainer.lpszClassName = "CSPYContainer";
	wcContainer.hIconSm = NULL;

	RegisterClassEx(&wcContainer);

	// Create container
	g_hContainer = CreateWindowEx(WS_EX_STATICEDGE,"CSPYContainer","",WS_CHILD|WS_VISIBLE,pointContainer.x,pointContainer.y,
		sizeContainer.cx,sizeContainer.cy,g_hDialog,NULL,g_hInstance,NULL);

	// Initialize list of available messages to send to control
	hSendMsgList = GetDlgItem(g_hDialog,IDC_SENDMSGLIST);
	for(dX=1;dX<sizeof(g_mlTable)/sizeof(MessageList);dX++)
	{
		// Do not add window messages
		if(strncmp(g_mlTable[dX].pMessageID,"WM",2) && g_mlTable[dX].dMessageNo != MSGFILTERENTRY)
		{
			dIndex = ListBox_AddString(hSendMsgList,g_mlTable[dX].pMessageID);
			ListBox_SetItemData(hSendMsgList,dIndex,g_mlTable[dX].dMessageNo);
		}
	}

	// Select first
	ListBox_SetCurSel(hSendMsgList,0);
	CommandHandler(LBN_SELCHANGE,IDC_SENDMSGLIST);

	// Load images for buttons
	hImageLoad = LoadImage(g_hInstance,MAKEINTRESOURCE(IDI_LOAD),IMAGE_ICON,16,16,LR_DEFAULTCOLOR); 
	hImageDestroy = LoadImage(g_hInstance,MAKEINTRESOURCE(IDI_DESTROY),IMAGE_ICON,16,16,LR_DEFAULTCOLOR);
	hImageDestroySmall = LoadImage(g_hInstance,MAKEINTRESOURCE(IDI_DESTROY),IMAGE_ICON,12,12,LR_DEFAULTCOLOR);
	hImageExecute = LoadImage(g_hInstance,MAKEINTRESOURCE(IDI_EXECUTE),IMAGE_ICON,16,16,LR_DEFAULTCOLOR);
	g_hLogOff = LoadImage(g_hInstance,MAKEINTRESOURCE(IDI_LOGOFF),IMAGE_ICON,16,16,LR_DEFAULTCOLOR);
	g_hLogOn = LoadImage(g_hInstance,MAKEINTRESOURCE(IDI_LOGON),IMAGE_ICON,16,16,LR_DEFAULTCOLOR);

	SendMessage(GetDlgItem(g_hDialog,IDC_FORWARD),BM_SETIMAGE,IMAGE_ICON,
		(LPARAM)LoadImage(g_hInstance,MAKEINTRESOURCE(IDI_FORWARD),IMAGE_ICON,16,16,LR_DEFAULTCOLOR));
	SendMessage(GetDlgItem(g_hDialog,IDC_FASTFORWARD),BM_SETIMAGE,IMAGE_ICON,
		(LPARAM)LoadImage(g_hInstance,MAKEINTRESOURCE(IDI_FASTFORWARD),IMAGE_ICON,16,16,LR_DEFAULTCOLOR));
	SendMessage(GetDlgItem(g_hDialog,IDC_REVERSE),BM_SETIMAGE,IMAGE_ICON,
		(LPARAM)LoadImage(g_hInstance,MAKEINTRESOURCE(IDI_REVERSE),IMAGE_ICON,16,16,LR_DEFAULTCOLOR));
	SendMessage(GetDlgItem(g_hDialog,IDC_FASTREVERSE),BM_SETIMAGE,IMAGE_ICON,
		(LPARAM)LoadImage(g_hInstance,MAKEINTRESOURCE(IDI_FASTREVERSE),IMAGE_ICON,16,16,LR_DEFAULTCOLOR));

	SendMessage(GetDlgItem(g_hDialog,IDC_CLEARNOTIFY),BM_SETIMAGE,IMAGE_ICON,(LPARAM)hImageDestroySmall);	
	SendMessage(GetDlgItem(g_hDialog,IDC_CLEARMESSAGE),BM_SETIMAGE,IMAGE_ICON,(LPARAM)hImageDestroySmall);

	SendMessage(GetDlgItem(g_hDialog,IDC_LOAD),BM_SETIMAGE,IMAGE_ICON,(LPARAM)hImageLoad);
	SendMessage(GetDlgItem(g_hDialog,IDC_REFRESH),BM_SETIMAGE,IMAGE_ICON,
		(LPARAM)LoadImage(g_hInstance,MAKEINTRESOURCE(IDI_REFRESH),IMAGE_ICON,16,16,LR_DEFAULTCOLOR));
	SendMessage(GetDlgItem(g_hDialog,IDC_DESTROY),BM_SETIMAGE,IMAGE_ICON,(LPARAM)hImageDestroy);

	SendMessage(GetDlgItem(g_hDialog,IDC_LOGTOGGLE),BM_SETIMAGE,IMAGE_ICON,(LPARAM)g_hLogOff);
	SendMessage(GetDlgItem(g_hDialog,IDC_LOGFILEBROWSE),BM_SETIMAGE,IMAGE_ICON,(LPARAM)hImageLoad);
	SendMessage(GetDlgItem(g_hDialog,IDC_CLEARLOG),BM_SETIMAGE,IMAGE_ICON,(LPARAM)hImageDestroy);

	SendMessage(GetDlgItem(g_hDialog,IDC_EXECUTE),BM_SETIMAGE,IMAGE_ICON,(LPARAM)hImageExecute);

	// Initialize user callback spin control
	SendMessage(GetDlgItem(g_hDialog,IDC_SPIN),UDM_SETRANGE,0,MAKELONG(9999,0));

	// Load application icons
	SendMessage(g_hDialog,WM_SETICON,TRUE,(LPARAM)LoadIcon(g_hInstance,MAKEINTRESOURCE(IDI_APPICON)));
	SendMessage(g_hDialog,WM_SETICON,FALSE,(LPARAM)LoadIcon(g_hInstance,MAKEINTRESOURCE(IDI_APPICONSM)));

	UpdateUI();
}

//        Name: ContainerWndProc
// Description: Container callback
//  Parameters: Handle to dialog, message, message parameters
//     Returns: TRUE if handled message, FALSE otherwise
LRESULT CALLBACK ContainerWndProc(HWND p_hWnd,UINT p_iMsg,WPARAM p_wParam,LPARAM p_lParam)
{
	LPNMHDR pNotifyStruct;

	switch(p_iMsg)
	{
		// Allow custom processing before returning
		case WM_NOTIFY:
			pNotifyStruct = (LPNMHDR)p_lParam;
			if(pNotifyStruct->hwndFrom == g_hControl)
				return ProcessControlNotification(pNotifyStruct);
			break;

		// Allow custom processing before returning
		case WM_COMMAND:
			if((HWND)p_lParam == g_hControl)
				return ProcessControlCommand(HIWORD(p_wParam));
			break;
	}
	return DefWindowProc(p_hWnd,p_iMsg,p_wParam,p_lParam);
}

//        Name: CommandHandler
// Description: Handle all non-main control command messages, such as message from support controls
//  Parameters: Notification code, control
//     Returns: TRUE if handled
BOOL CommandHandler(WORD p_wNotifyCode,WORD p_wControl)
{
	RECT rectWindow;
	int dSLRefresh;

	// Process control commands
	switch(p_wControl)
	{
		case IDC_SENDMSGLIST:
			if(p_wNotifyCode == LBN_SELCHANGE)
			{
				LPSTR pBuf;
				INT dMsgNo;
				CHAR szMessage[41];

				// Get message number
				dMsgNo = ListBox_GetItemData(GetDlgItem(g_hDialog,IDC_SENDMSGLIST),ListBox_GetCurSel(GetDlgItem(g_hDialog,IDC_SENDMSGLIST)));
					
				// Allocate buffer
				pBuf = (LPSTR)malloc(RESSTRSIZE);

				// Get message signature and set description
				wsprintf(pBuf,"wParam is %s\r\nlParam is %s\r\nlResult is %s",CCIGetSignature(GetMessageSignature(dMsgNo,WPSIG),SIGDESC),
					CCIGetSignature(GetMessageSignature(dMsgNo,LPSIG),SIGDESC),CCIGetSignature(GetMessageSignature(dMsgNo,LRSIG),SIGDESC));
				SetWindowText(GetDlgItem(g_hDialog,IDC_MSGSIGNATURE),pBuf);

				// Get message signature and set template
				ListBox_GetText(GetDlgItem(g_hDialog,IDC_SENDMSGLIST),ListBox_GetCurSel(GetDlgItem(g_hDialog,IDC_SENDMSGLIST)),szMessage);
				wsprintf(pBuf,"MSG (%s,\r\n%s,\r\n%s)",szMessage,CCIGetSignature(GetMessageSignature(dMsgNo,WPSIG),SIGTEMP),
					CCIGetSignature(GetMessageSignature(dMsgNo,LPSIG),SIGTEMP));
				SetWindowText(GetDlgItem(g_hDialog,IDC_MSGPARAMS),pBuf);

				// Clean up
				free(pBuf);

				return TRUE;
			}
			break;

		case IDC_SEND:
			// Send message to control
			if(p_wNotifyCode == BN_CLICKED)
			{
				CCIResult* pCCIResult;
				LPSTR pBuf;
				LPSTR pResult;

				// Create temporary storage
				pResult = (LPSTR)malloc(RESSTRSIZE);
				pBuf = (LPSTR)malloc(RESSTRSIZE);
	
				// Get input string
				GetWindowText(GetDlgItem(g_hDialog,IDC_MSGPARAMS),pBuf,RESSTRSIZE);

				// Parse input string
				pCCIResult = CCIInterpret(pBuf);

				// Check for errors
				if(*(pCCIResult->pError))
				{
					int dErrLoc;

					lstrcpy(pResult,pCCIResult->pError);

					// If currently sending all statments, stop
					if(g_bSendAll)
					{
						g_bSendAll = FALSE;
						UpdateUI();
					}
					
					// Move to current error line
					dErrLoc = SendMessage(GetDlgItem(g_hDialog,IDC_MSGPARAMS),EM_LINEINDEX,(LPARAM)pCCIResult->dErrLine-1,0);
					SendMessage(GetDlgItem(g_hDialog,IDC_MSGPARAMS),EM_SETSEL,dErrLoc,dErrLoc);
					SendMessage(GetDlgItem(g_hDialog,IDC_MSGPARAMS),EM_SCROLLCARET,0,0);
					// Set focus
					SetFocus(GetDlgItem(g_hDialog,IDC_MSGPARAMS));
				}
				else
				{
					// Check statement type
					if(pCCIResult->ccitWParam == STYLEV)
					{
						LONG dStyles;
						LONG dExStyles;
						UINT dIndex;
						int dX;

						// Setting styles
						dStyles = GetWindowLong(g_hControl,GWL_STYLE);
						dExStyles = GetWindowLong(g_hControl,GWL_EXSTYLE);

						// Turn off styles
						dStyles &= ~(((CCIStyle*)pCCIResult->pWParam)->dStyleOff);
						dExStyles &= ~(((CCIStyle*)pCCIResult->pWParam)->dExStyleOff);
						// Turn on styles
						dStyles |= ((CCIStyle*)pCCIResult->pWParam)->dStyleOn;
						dExStyles |= ((CCIStyle*)pCCIResult->pWParam)->dExStyleOn;

						// Set control styles
						// Refresh control
						if(!((CCIStyle*)pCCIResult->pWParam)->bRecreate)
						{
							SetWindowLong(g_hControl,GWL_STYLE,dStyles);
							SetWindowLong(g_hControl,GWL_EXSTYLE,dExStyles);
						}
						else
						{
							ControlStateCallback(CSPY_SHUTDOWN);
							DestroyWindow(g_hControl);
							g_hControl = NULL;
							CreateControl(dStyles,dExStyles);
						}

						// Refresh style lists if styles dialog is open
						if(g_hStyles)
						{
							HWND hStylesList;
							HWND hExStylesList;

							hStylesList = GetDlgItem(g_hStyles,IDC_STYLESLIST);
							hExStylesList = GetDlgItem(g_hStyles,IDC_EXSTYLESLIST);

							// Styles
							dIndex = ListBox_GetTopIndex(hStylesList);
							dStyles = GetWindowLong(g_hControl,GWL_STYLE);
							for(dX=0;dX<sizeof(g_slTable)/sizeof(StyleList);dX++)
								ListBox_SetSel(hStylesList,((dStyles&g_slTable[dX].dStyleNo)==g_slTable[dX].dStyleNo)?TRUE:FALSE,dX);
							ListBox_SetTopIndex(hStylesList,dIndex);

							// Extended styles
							dIndex = ListBox_GetTopIndex(hExStylesList);
							dExStyles = GetWindowLong(g_hControl,GWL_EXSTYLE);
							for(dX=0;dX<sizeof(g_exslTable)/sizeof(StyleList);dX++)
								ListBox_SetSel(hExStylesList,((dExStyles&g_exslTable[dX].dStyleNo)==g_exslTable[dX].dStyleNo)?TRUE:FALSE,dX);
							ListBox_SetTopIndex(hExStylesList,dIndex);
						}

						// Results
						wsprintf(pResult,"Styles\tCleared: 0x%x, Set: 0x%x\r\nExStyles\tCleared: 0x%x, Set: 0x%x\r\n(%s)",
							((CCIStyle*)pCCIResult->pWParam)->dStyleOff,((CCIStyle*)pCCIResult->pWParam)->dStyleOn,
							((CCIStyle*)pCCIResult->pWParam)->dExStyleOff,((CCIStyle*)pCCIResult->pWParam)->dExStyleOn,
							(((CCIStyle*)pCCIResult->pWParam)->bRecreate)?"Recreate":"SetWindowLong");
					}
					else
					{
						// Sending message to control
						LRESULT dLResult;

						// Send message
						dLResult = SendMessage(g_hControl,pCCIResult->dMsgNo,(WPARAM)pCCIResult->pWParam,(LPARAM)pCCIResult->pLParam);
	
						// Create display for result
						lstrcpy(pResult,"lResult:\t");
						CCIRender(GetMessageSignature(pCCIResult->dMsgNo,LRSIG),(void*)dLResult,pBuf);
						lstrcat(pResult,pBuf);
	
						// Create display for parameters
						lstrcat(pResult,"\r\nwParam:\t");
						CCIRender(pCCIResult->ccitWParam,pCCIResult->pWParam,pBuf);
						lstrcat(pResult,pBuf);
						lstrcat(pResult,",\r\nlParam:\t");
						CCIRender(pCCIResult->ccitLParam,pCCIResult->pLParam,pBuf);
						lstrcat(pResult,pBuf);
					}
					
					// Move to next statement in list if exists
					if(g_dSLCount)
					{
						if(g_dSLCurrent < g_dSLCount-1)
							g_dSLCurrent++;
						else
						{
							// If currently sending all statments, stop
							if(g_bSendAll)
								g_bSendAll = FALSE;
						}
						if(g_bSendAll)
							PostMessage(g_hDialog,WM_COMMAND,MAKEWPARAM(IDC_SEND,BN_CLICKED),(LPARAM)GetDlgItem(g_hDialog,IDC_SEND));
						UpdateUI();
					}
				}
		
				// Output result string
				SetWindowText(GetDlgItem(g_hDialog,IDC_RETURN),pResult);
	
				// Write output to log file if logging
				if(g_bLogging)
				{
					FILE* fpL;
					CHAR szLogFile[_MAX_PATH];

					// Get path
					GetWindowText(GetDlgItem(g_hDialog,IDC_LOGFILE),szLogFile,sizeof(szLogFile));
					if(*szLogFile)
					{	
						if((fpL = fopen(szLogFile,"a")) != NULL)
						{
							fputs("**************** Statement ****************\n",fpL);
							fputs(pCCIResult->pInput,fpL);
							fputs("\n>>>>>>>>>>>>>>>>  Result   <<<<<<<<<<<<<<<<\n",fpL);
							fputs(pResult,fpL);
							fputs("\n\n",fpL);
							fclose(fpL);
						}
					}
				}

				// Clean up and return
				CCIDestroy(pCCIResult);
				free(pBuf);
				free(pResult);

				return TRUE;
			}
			break;

		case IDC_SENDALL:
			if(p_wNotifyCode == BN_CLICKED)
			{
				g_dSLCurrent = 0;
				g_bSendAll = TRUE;			
				PostMessage(g_hDialog,WM_COMMAND,MAKEWPARAM(IDC_SEND,BN_CLICKED),(LPARAM)GetDlgItem(g_hDialog,IDC_SEND));
				UpdateUI();
				return TRUE;
			}
			break;

		// Statement file
		case IDC_REFRESH:
			if(p_wNotifyCode == BN_CLICKED)
				dSLRefresh = g_dSLCurrent;
			else
				break;

			// Fall through

		case IDC_LOAD:
			if(p_wNotifyCode == BN_CLICKED)
			{
				LONG dSLSize;
				LPSTR pSLStatement;
				LPSTR pSLDelimiter;
				FILE* fpSL;
				int dX;

				// Check if loading or refreshing
				if(p_wControl == IDC_LOAD)
				{
					OPENFILENAME ofn;
					CHAR szFile[_MAX_PATH];
					CHAR szFilter[] = "Text Files (*.TXT)\0*.txt\0All Files (*.*)\0*.*\0\0";

					ZeroMemory(&ofn,sizeof(ofn));
					ofn.lStructSize = sizeof(OPENFILENAME);
					ofn.hwndOwner = g_hDialog;
					ofn.Flags = OFN_HIDEREADONLY|OFN_FILEMUSTEXIST;
					ofn.nMaxFile = sizeof(szFile);
					*szFile = '\0';
					ofn.lpstrFile = szFile;
					ofn.lpstrTitle = "Load Statement List";
					ofn.lpstrDefExt = "txt";
					ofn.lpstrFilter = szFilter;

					if(!GetOpenFileName(&ofn))
						return TRUE;

					strcpy(g_szSLFile,ofn.lpstrFile);
				}

				// Open file for reading
				if((fpSL = fopen(g_szSLFile,"rb")) == NULL)
				{
					MessageBox(g_hDialog,"Error opening file!","Error",MB_OK|MB_ICONSTOP);
					return TRUE;
				}

				// Determine size of file
				fseek(fpSL,0,SEEK_END);
				// Free statement list memory
				dSLSize = ftell(fpSL);
				if(g_pSL)
					free(g_pSL);
				g_pSL = NULL;
				if(g_pSLIndex)
					free(g_pSLIndex);
				g_pSLIndex = NULL;
				// Allocate memory for file
				g_pSL = (LPSTR)malloc(dSLSize+1);
				ZeroMemory(g_pSL,dSLSize+1);
				rewind(fpSL);
				// Load file into memory for manipulation
				fread(g_pSL,dSLSize,sizeof(CHAR),fpSL);
				fclose(fpSL);
				// Determine number of statements
				g_dSLCount = 0;
				g_dSLCurrent = -1;
				pSLStatement = g_pSL;
				while(pSLDelimiter = strchr(pSLStatement,';'))
				{
					g_dSLCount++;
					pSLStatement = pSLDelimiter+1;
				}
				// Check for zero statements
				if(!g_dSLCount)
				{
					MessageBox(g_hDialog,"No statments found in file! (Make sure each statement ends with a semicolon ';')","Error",MB_OK);
					if(g_pSL)
						free(g_pSL);
					g_pSL = NULL;
					return TRUE;
				}
				g_dSLCurrent = 0;
				// Create statement list index
				g_pSLIndex = (CHAR**)malloc(g_dSLCount*sizeof(LPSTR));
				// Separate into statements
				for(dX=0;dX<g_dSLCount;dX++)
				{
					if(!dX)
						g_pSLIndex[dX] = strtok(g_pSL,";");
					else
						g_pSLIndex[dX] = strtok(NULL,";");
				}

				// Restore position is refreshing
				if(p_wControl == IDC_REFRESH)
				{
					g_dSLCurrent = dSLRefresh;
					if(g_dSLCurrent > g_dSLCount-1)
						g_dSLCurrent = g_dSLCount-1;
				}

				// Update return label
				SetWindowText(GetDlgItem(g_hDialog,IDC_RETURNLABEL),"Last Return &Value:");

				UpdateUI();
				return TRUE;
			}
			break;
			
		case IDC_DESTROY:
			if(p_wNotifyCode == BN_CLICKED)
			{
				// Free statement list memory
				if(g_pSL)
					free(g_pSL);
				g_pSL = NULL;
				if(g_pSLIndex)
					free(g_pSLIndex);
				g_pSLIndex = NULL;
				// Reinitialize tracking variables
				g_dSLCurrent = -1;
				g_dSLCount = 0;

				// Update return label
				SetWindowText(GetDlgItem(g_hDialog,IDC_RETURNLABEL),"Return &Value:");

				// Reset parameters display
				CommandHandler(LBN_SELCHANGE,IDC_SENDMSGLIST);

				UpdateUI();

				return TRUE;
			}
			break;

		// Statement navigation
		case IDC_FORWARD:
			if(p_wNotifyCode == BN_CLICKED)
			{
				if(g_dSLCurrent < g_dSLCount-1)
					g_dSLCurrent++;
				UpdateUI();
				return TRUE;
			}
			break;

		case IDC_FASTFORWARD:
			if(p_wNotifyCode == BN_CLICKED)
			{
				g_dSLCurrent = g_dSLCount-1;
				UpdateUI();
				return TRUE;
			}
			break;

		case IDC_REVERSE:
			if(p_wNotifyCode == BN_CLICKED)
			{
				if(g_dSLCurrent > 0)
					g_dSLCurrent--;
				UpdateUI();
				return TRUE;
			}
			break;

		case IDC_FASTREVERSE:
			if(p_wNotifyCode == BN_CLICKED)
			{
				g_dSLCurrent = 0;
				UpdateUI();
				return TRUE;
			}
			break;

		// Log file
		case IDC_LOGTOGGLE:
			if(p_wNotifyCode == BN_CLICKED)
			{
				g_bLogging = !g_bLogging;

				// For for invalid log file names
				if(g_bLogging)
				{
					FILE* fpL;
					CHAR szLogFile[_MAX_PATH];

					// Check if valid log file name
					GetWindowText(GetDlgItem(g_hDialog,IDC_LOGFILE),szLogFile,sizeof(szLogFile));
					if(*szLogFile)
					{	
						// Try to open/create file
						if((fpL = fopen(szLogFile,"a")) == NULL)
						{
							// Invalid file name
							g_bLogging = FALSE;
							MessageBox(g_hDialog,"Unable to open/create file!","Error",MB_OK|MB_ICONSTOP);
							SetFocus(GetDlgItem(g_hDialog,IDC_LOGFILE));
							return TRUE;						
						}
						else
							fclose(fpL);
					}
					else
					{
						// No file name
						g_bLogging = FALSE;
						MessageBox(g_hDialog,"Please enter a file name.","Error",MB_OK|MB_ICONSTOP);
						SetFocus(GetDlgItem(g_hDialog,IDC_LOGFILE));
						return TRUE;
					}
				}

				// Update switch icon
				SendMessage(GetDlgItem(g_hDialog,IDC_LOGTOGGLE),BM_SETIMAGE,IMAGE_ICON,(LPARAM)((g_bLogging)?g_hLogOn:g_hLogOff));
				
				// Update interface
				UpdateUI();
				return TRUE;
			}
			break;

		case IDC_CLEARLOG:
			if(p_wNotifyCode == BN_CLICKED)
			{
				CHAR szLogFile[_MAX_PATH];

				// Confirm choice
				if(MessageBox(g_hDialog,"Delete contents of the current log file?","Delete Log File",MB_YESNO|MB_ICONQUESTION) == IDNO)
					return TRUE;

				// Get path
				GetWindowText(GetDlgItem(g_hDialog,IDC_LOGFILE),szLogFile,sizeof(szLogFile));
				if(remove(szLogFile))
					MessageBox(g_hDialog,"Unable to remove log file!","Error",MB_OK|MB_ICONSTOP);
				return TRUE;
			}
			break;

		case IDC_LOGFILEBROWSE:
			if(p_wNotifyCode == BN_CLICKED)
			{
				// Get file to log to
				OPENFILENAME ofn;
				CHAR szLogFile[_MAX_PATH];
				CHAR szFilter[] = "Text Files (*.TXT)\0*.txt\0All Files (*.*)\0*.*\0\0";

				ZeroMemory(&ofn,sizeof(ofn));
				ofn.lStructSize = sizeof(OPENFILENAME);
				ofn.hwndOwner = g_hDialog;
				ofn.Flags = OFN_HIDEREADONLY;
				ofn.nMaxFile = sizeof(szLogFile);
				*szLogFile = '\0';
				ofn.lpstrFile = szLogFile;
				ofn.lpstrTitle = "Select Log File";
				ofn.lpstrDefExt = "txt";
				ofn.lpstrFilter = szFilter;

				if(!GetOpenFileName(&ofn))
					return TRUE;

				// Copy contents to log path
				SetWindowText(GetDlgItem(g_hDialog,IDC_LOGFILE),szLogFile);
				
				return TRUE;
			}
			break;

		// User callback interface
		case IDC_EXECUTE:
			if(p_wNotifyCode == BN_CLICKED)
			{
				CHAR szValue[6];

				GetWindowText(GetDlgItem(g_hDialog,IDC_STATE),szValue,sizeof(szValue));
				ControlStateCallback(atoi(szValue));
			}
			break;

		// Menu items
		case ID_STYLES:
			// Check if styles box is already open, if so, return
			if(g_hStyles)
			{
				SetFocus(g_hStyles);
				return TRUE;
			}
			// Open styles dialog box to allow changes to control styles
			g_hStyles = CreateDialog(g_hInstance,MAKEINTRESOURCE(IDD_STYLESDIALOG),g_hDialog,StylesProc);
			// Center window
			GetWindowRect(g_hStyles,&rectWindow);
			SetWindowPos(g_hStyles,NULL,(GetSystemMetrics(SM_CXSCREEN)-rectWindow.right+rectWindow.left)/2,
				(GetSystemMetrics(SM_CYSCREEN)-rectWindow.bottom+rectWindow.top)/2,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_SHOWWINDOW);
			return TRUE;

		case ID_INFORMATION:
			// Check if information box is already open, if so, return
			if(g_hInformation)
			{
				SetFocus(g_hInformation);
				return TRUE;
			}
			LoadLibrary("RICHED32.DLL");
			g_hInformation = CreateDialog(g_hInstance,MAKEINTRESOURCE(IDD_INFODIALOG),g_hDialog,InformationProc);
			// Center window
			GetWindowRect(g_hInformation,&rectWindow);
			SetWindowPos(g_hInformation,NULL,(GetSystemMetrics(SM_CXSCREEN)-rectWindow.right+rectWindow.left)/2,
				(GetSystemMetrics(SM_CYSCREEN)-rectWindow.bottom+rectWindow.top)/2,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_SHOWWINDOW);
			return TRUE;

		case ID_ABOUT:
			DialogBox(g_hInstance,MAKEINTRESOURCE(IDD_ABOUT),g_hDialog,AboutProc);
			return TRUE;

		case ID_FILTERWINDOWMESSAGES:
		case ID_FILTERCONTROLMESSAGES:
		case ID_FILTERUNKNOWNMESSAGES:
		case ID_FILTERCOMMONNOTIFICATIONS:
		case ID_FILTERCONTROLNOTIFICATIONS:
		case ID_FILTERUNKNOWNNOTIFICATIONS:
			FilterMessages(p_wControl);
			return TRUE;

		// Clear lists
		case IDC_CLEARNOTIFY:
			if(p_wNotifyCode == BN_CLICKED)
			{
				ListBox_ResetContent(GetDlgItem(g_hDialog,IDC_NOTIFYLIST));
				return TRUE;
			}
			break;
					
		case IDC_CLEARMESSAGE:
			if(p_wNotifyCode == BN_CLICKED)
			{
				ListBox_ResetContent(GetDlgItem(g_hDialog,IDC_MSGLIST));
				return TRUE;
			}
			break;
	}
	
	// Unhandled
	return FALSE;
}

//        Name: AddToolTipEnum
// Description: Enumerate callback to add windows to tool tip control
//  Parameters: Handle to child, second argument unused
//     Returns: none
BOOL CALLBACK AddToolTipEnum(HWND p_hChild,LPARAM p_lParam)
{
	TOOLINFO tiInfo;
	CHAR szClass[64];
	CHAR szToolTip[81];

	// Add child to tool tip control unless it is a static control
	GetClassName(p_hChild,szClass,sizeof(szClass));
	if(lstrcmpi(szClass,TEXT("STATIC")))
	{
		tiInfo.cbSize = sizeof(TOOLINFO);
		tiInfo.uFlags = TTF_IDISHWND;
		tiInfo.hwnd = (HWND)p_lParam;
		tiInfo.uId = (UINT)p_hChild;
		if(!LoadString(g_hInstance,GetDlgCtrlID(p_hChild)+TTOFFSET,szToolTip,sizeof(szToolTip)))
			*szToolTip = 0;
		tiInfo.lpszText = szToolTip;
		SendMessage(g_hToolTips,TTM_ADDTOOL,0,(LPARAM)&tiInfo);
	}

	return TRUE;
}

//        Name: DeleteToolTipEnum
// Description: Enumerate callback to remove windows from tool tip control
//  Parameters: Handle to child, second argument unused
//     Returns: none
BOOL CALLBACK DeleteToolTipEnum(HWND p_hChild,LPARAM p_lParam)
{
	TOOLINFO tiInfo;
	CHAR szClass[64];
	CHAR szToolTip[81];

	// Add child to tool tip control unless it is a static control
	GetClassName(p_hChild,szClass,sizeof(szClass));
	if(lstrcmpi(szClass,TEXT("STATIC")))
	{
		tiInfo.cbSize = sizeof(TOOLINFO);
		tiInfo.uFlags = TTF_IDISHWND;
		tiInfo.hwnd = (HWND)p_lParam;
		tiInfo.uId = (UINT)p_hChild;
		if(!LoadString(g_hInstance,GetDlgCtrlID(p_hChild)+TTOFFSET,szToolTip,sizeof(szToolTip)))
			*szToolTip = 0;
		tiInfo.lpszText = szToolTip;
		SendMessage(g_hToolTips,TTM_DELTOOL,0,(LPARAM)&tiInfo);
	}

	return TRUE;
}

//        Name: GetMsgProc
// Description: Get Message hook callback
//  Parameters: Hook code, removal flag, address of structure with message
//     Returns: none
LRESULT CALLBACK GetMsgProc(int p_dCode,WPARAM p_wParam,LPARAM p_lParam)
{
	// Check if should continue with hook
	if(p_dCode < 0)
		return CallNextHookEx(g_hGMHook,p_dCode,p_wParam,p_lParam);

	// Extract message information and pass on to helper
	MessageProc((MSG*)p_lParam);

	return CallNextHookEx(g_hGMHook,p_dCode,p_wParam,p_lParam);
}

//        Name: CallWndProc
// Description: Send message (window proc call) hook callback
//  Parameters: Hook code, removal flag, address of structure with message
//     Returns: none
LRESULT CALLBACK CallWndProc(int p_dCode,WPARAM p_wParam,LPARAM p_lParam)
{
	CWPSTRUCT* pCWPStruct;
	MSG msgHold;

	// Check if should continue with hook
	if(p_dCode < 0)
		return CallNextHookEx(g_hCWHook,p_dCode,p_wParam,p_lParam);

	// Extract message information and pass on to helper
	pCWPStruct = (CWPSTRUCT*)p_lParam;
	msgHold.hwnd = pCWPStruct->hwnd;
	msgHold.message = pCWPStruct->message;
	msgHold.wParam = pCWPStruct->wParam;
	msgHold.lParam = pCWPStruct->lParam;

	MessageProc(&msgHold);

	return CallNextHookEx(g_hCWHook,p_dCode,p_wParam,p_lParam);
}

//        Name: MessageProc
// Description: Common message hook helper callback
//  Parameters: Pointer to intercepted message
//     Returns: none
void MessageProc(MSG* p_pMsg)
{
	TOOLINFO tiInfo;
	POINT pointCursor;
	LRESULT dResult;
	LPNMHDR pNotifyStruct;
	HWND hNotifyList;
	HWND hMsgList;
	HWND hSendMsgList;
	HWND hStylesList;
	HWND hExStylesList;

	// Log message if intended for control
	if(p_pMsg->hwnd == g_hControl)
		LogMessage(p_pMsg->message);

	// Initialize handles
	hNotifyList = GetDlgItem(g_hDialog,IDC_NOTIFYLIST);
	hMsgList = GetDlgItem(g_hDialog,IDC_MSGLIST);
	hSendMsgList = GetDlgItem(g_hDialog,IDC_SENDMSGLIST);
	hStylesList = GetDlgItem(g_hStyles,IDC_STYLESLIST);
	hExStylesList = GetDlgItem(g_hStyles,IDC_EXSTYLESLIST);

	// Continue, route messages to tooptip control and log notifications from control
	switch(p_pMsg->message)
	{
		// Track notifications and commands from control and log
		case WM_NOTIFY:
			// Determine if this notification was from the control created, if so, log
			pNotifyStruct = (LPNMHDR)p_pMsg->lParam;
			if(pNotifyStruct->hwndFrom == g_hControl && p_pMsg->hwnd == g_hContainer)
				LogNotification(pNotifyStruct->code);
			break;

		case WM_COMMAND:
			// Determine if this command was from the control created, if so, log
			if((HWND)p_pMsg->lParam == g_hControl && p_pMsg->hwnd == g_hContainer)
				LogNotification(HIWORD(p_pMsg->wParam));
			break;

		// Tool Tip Support
		// Check for NC mouse movements of the list, if found, hide tool tip
		case WM_NCMOUSEMOVE:
			if(p_pMsg->hwnd == hNotifyList || p_pMsg->hwnd == hMsgList || p_pMsg->hwnd == hSendMsgList || p_pMsg->hwnd == hStylesList || p_pMsg->hwnd == hExStylesList)
				SendMessage(g_hToolTips,TTM_POP,0,0);
			break;

		case WM_MOUSEMOVE:
			// If mouse is moving over list boxes, update tool tip if necessary
			if(p_pMsg->hwnd == hNotifyList || p_pMsg->hwnd == hMsgList || p_pMsg->hwnd == hSendMsgList || p_pMsg->hwnd == hStylesList || p_pMsg->hwnd == hExStylesList)
			{
				GetCursorPos(&pointCursor);
				ScreenToClient(p_pMsg->hwnd,&pointCursor);
				dResult = SendMessage(p_pMsg->hwnd,LB_ITEMFROMPOINT,0,MAKELPARAM(pointCursor.x,pointCursor.y));
				// Do not update tooltip if still over same index
				if(p_pMsg->hwnd == hNotifyList)
				{
					if(LOWORD(dResult) == g_dLastNotifyIndex)
						break;
					else
						g_dLastNotifyIndex = LOWORD(dResult);
				}
				else if(p_pMsg->hwnd == hMsgList)
				{
					if(LOWORD(dResult) == g_dLastMessageIndex)
						break;
					else
						g_dLastMessageIndex = LOWORD(dResult);
				}
				else if(p_pMsg->hwnd == hSendMsgList)
				{
					if(LOWORD(dResult) == g_dLastSendMessageIndex)
						break;
					else
						g_dLastSendMessageIndex = LOWORD(dResult);
				}
				else if(p_pMsg->hwnd == hStylesList)
				{
					if(LOWORD(dResult) == g_dLastStylesIndex)
						break;
					else
						g_dLastStylesIndex = LOWORD(dResult);
				}
				else
				{
					if(LOWORD(dResult) == g_dLastExStylesIndex)
						break;
					else
						g_dLastExStylesIndex = LOWORD(dResult);
				}

				// Check if cursor is over item
				if(!HIWORD(dResult))
				{
					tiInfo.cbSize = sizeof(TOOLINFO);
					tiInfo.uFlags = TTF_IDISHWND;
					tiInfo.hwnd = GetParent(p_pMsg->hwnd);
					tiInfo.uId = (UINT)p_pMsg->hwnd;
					// Get text to display
					if(p_pMsg->hwnd == hNotifyList)
						tiInfo.lpszText = GetNotifyString(ListBox_GetItemData(p_pMsg->hwnd,LOWORD(dResult)),DESC);
					else if(p_pMsg->hwnd == hStylesList)
						tiInfo.lpszText = g_slTable[LOWORD(dResult)].pStyleDesc;
					else if(p_pMsg->hwnd == hExStylesList)
						tiInfo.lpszText = g_exslTable[LOWORD(dResult)].pStyleDesc;
					else
						tiInfo.lpszText = GetMessageString(ListBox_GetItemData(p_pMsg->hwnd,LOWORD(dResult)),DESC);
					SendMessage(g_hToolTips,TTM_UPDATETIPTEXT,0,(LPARAM)&tiInfo);
				}
				else
					SendMessage(g_hToolTips,TTM_POP,0,0);
			}
			else
			{
				// Reset last index holds
				g_dLastSendMessageIndex = -1;
				g_dLastMessageIndex = -1;
				g_dLastNotifyIndex = -1;
				g_dLastStylesIndex = -1;
				g_dLastExStylesIndex = -1;
			}
			// Fall through

		case WM_LBUTTONDOWN:
		case WM_LBUTTONUP:
		case WM_RBUTTONDOWN:
		case WM_RBUTTONUP:
		case WM_MBUTTONDOWN:
		case WM_MBUTTONUP:
			// Relay mouse messages if message sent to child of dialog
			if(IsChild(g_hDialog,(HWND)p_pMsg->hwnd) || IsChild(g_hStyles,(HWND)p_pMsg->hwnd))
				SendMessage(g_hToolTips,TTM_RELAYEVENT,0,(LPARAM)p_pMsg);
			break;
	}
}

//        Name: FilterMessages
// Description: Toggle message and notification visibility switches
//  Parameters: Type to filter
//     Returns: none
void FilterMessages(int p_dType)
{
	MENUITEMINFO miiSelection;
	int dX;

	miiSelection.cbSize = sizeof(miiSelection);
	miiSelection.fMask = MIIM_STATE;

	// Get the menu item information
	GetMenuItemInfo(GetMenu(g_hDialog),p_dType,FALSE,&miiSelection);

	// Toggle check state
	if(miiSelection.fState&MFS_CHECKED)
	{
		miiSelection.fState &= ~MFS_CHECKED;
		miiSelection.fState |= MFS_UNCHECKED;
	}
	else
	{
		miiSelection.fState &= ~MFS_UNCHECKED;
		miiSelection.fState |= MFS_CHECKED;
	}
	SetMenuItemInfo(GetMenu(g_hDialog),p_dType,FALSE,&miiSelection);

	// Set filter flags in tables
	switch(p_dType)
	{
		case ID_FILTERWINDOWMESSAGES:
			for(dX=0;dX<sizeof(g_mlTable)/sizeof(MessageList);dX++)
				if(!strncmp(g_mlTable[dX].pMessageID,"WM",2))
					g_mlTable[dX].bFilter = (miiSelection.fState&MFS_CHECKED)?TRUE:FALSE;
			break;
	
		case ID_FILTERCONTROLMESSAGES:
			for(dX=0;dX<sizeof(g_mlTable)/sizeof(MessageList);dX++)
				if(!strncmp(g_mlTable[dX].pMessageID,MSGPREFIX,lstrlen(MSGPREFIX)))
					g_mlTable[dX].bFilter = (miiSelection.fState&MFS_CHECKED)?TRUE:FALSE;
			break;

		case ID_FILTERUNKNOWNMESSAGES:
			for(dX=0;dX<sizeof(g_mlTable)/sizeof(MessageList);dX++)
				if(g_mlTable[dX].dMessageNo == MSGFILTERENTRY)
				{
					g_mlTable[dX].bFilter = (miiSelection.fState&MFS_CHECKED)?TRUE:FALSE;
					break;
				}
			break;

		case ID_FILTERCOMMONNOTIFICATIONS:
			for(dX=0;dX<sizeof(g_nlTable)/sizeof(NotifyList);dX++)
				if(!strncmp(g_nlTable[dX].pNotifyID,"NM",2))
					g_nlTable[dX].bFilter = (miiSelection.fState&MFS_CHECKED)?TRUE:FALSE;
			break;

		case ID_FILTERCONTROLNOTIFICATIONS:
			for(dX=0;dX<sizeof(g_nlTable)/sizeof(NotifyList);dX++)
				if(!strncmp(g_nlTable[dX].pNotifyID,NTFYPREFIX,lstrlen(NTFYPREFIX)))
					g_nlTable[dX].bFilter = (miiSelection.fState&MFS_CHECKED)?TRUE:FALSE;
			break;

		case ID_FILTERUNKNOWNNOTIFICATIONS:
			for(dX=0;dX<sizeof(g_nlTable)/sizeof(NotifyList);dX++)
				if(g_nlTable[dX].dNotifyNo == NTFYFILTERENTRY)
				{
					g_nlTable[dX].bFilter = (miiSelection.fState&MFS_CHECKED)?TRUE:FALSE;
					break;
				}
			break;
	}
}

//        Name: LogMessage
// Description: Takes a message, converts it to its text representation and logs it
//  Parameters: Message
//     Returns: none
void LogMessage(UINT p_dCode)
{
	LPSTR pId;
	HWND hMessageList;
	int dIndex;
	CHAR szMessage[41];

	// Get ID
	pId = GetMessageString(p_dCode,ID);

	// Process ID based on type
	if(pId == LPFILTER)
		return;
	else if(pId)
		lstrcpy(szMessage,pId);
	else
	{
		// Unknown
		if((pId = GetMessageString(MSGFILTERENTRY,ID)) == LPFILTER)
			return;
		wsprintf(szMessage,"%s (0x%x)",pId,p_dCode);
		p_dCode = MSGFILTERENTRY;
	}

	// Log
	hMessageList = GetDlgItem(g_hDialog,IDC_MSGLIST);

	// Clear out history if reached limit
	if(ListBox_GetCount(hMessageList) == MAXHISTORY)
		ListBox_ResetContent(hMessageList);

	// Add entry
	dIndex = ListBox_AddString(hMessageList,szMessage);
	ListBox_SetItemData(hMessageList,dIndex,p_dCode);
	ListBox_SetTopIndex(hMessageList,dIndex);
}

//        Name: LogNotification
// Description: Takes a notification, converts it to its text representation and logs it
//  Parameters: Notification message
//     Returns: none
void LogNotification(UINT p_dCode)
{
	LPSTR pId;
	HWND hNotifyList;
	int dIndex;
	CHAR szNotify[41];

	// Get ID
	pId = GetNotifyString(p_dCode,ID);

	// Process ID based on type
	if(pId == LPFILTER)
		return;
	else if(pId)
		lstrcpy(szNotify,pId);
	else
	{
		// Unknown
		if((pId = GetNotifyString(NTFYFILTERENTRY,ID)) == LPFILTER)
			return;
		wsprintf(szNotify,"%s (0x%x)",pId,p_dCode);
		p_dCode = NTFYFILTERENTRY;
	}

	// Log
	hNotifyList = GetDlgItem(g_hDialog,IDC_NOTIFYLIST);

	// Clear out history if reached limit
	if(ListBox_GetCount(hNotifyList) == MAXHISTORY)
		ListBox_ResetContent(hNotifyList);

	// Add entry
	dIndex = ListBox_AddString(hNotifyList,szNotify);
	ListBox_SetItemData(hNotifyList,dIndex,p_dCode);
	ListBox_SetTopIndex(hNotifyList,dIndex);
}

//        Name: GetMessageString
// Description: Given a numeric ID, return message string
//  Parameters: Message ID, item to get	(ID or DESC)
//     Returns: Pointer to description
LPSTR GetMessageString(UINT p_dMessageNo,int p_dItem)
{
	UINT dUpperBound;
	UINT dLowerBound;
	UINT dIndex; 

	// Set bounds for search
	dLowerBound = 1;
	dUpperBound = sizeof(g_mlTable)/sizeof(MessageList);
	dIndex = (dUpperBound+dLowerBound)/2;

	// Perform binary tree search for ID
	while(g_mlTable[dIndex-1].dMessageNo != p_dMessageNo)
	{
		// Do comparisions
		if(g_mlTable[dIndex-1].dMessageNo < p_dMessageNo)
			dLowerBound = dIndex+1;
		else if(g_mlTable[dIndex-1].dMessageNo > p_dMessageNo)
			dUpperBound = dIndex-1;

		// Set new index
		dIndex = (dUpperBound+dLowerBound)/2;

		// Check if no match was found
		if(dLowerBound > dUpperBound)
			return NULL;
	}

	// Return match field, check for filters when returning IDs
	if(p_dItem == ID)
		return (!g_mlTable[dIndex-1].bFilter)?g_mlTable[dIndex-1].pMessageID:LPFILTER;
	else
		return g_mlTable[dIndex-1].pMessageDesc;
}

//        Name: GetNotifyString
// Description: Given a numeric ID, return notification string
//  Parameters: Notification ID (initially from a WM_NOTIFY or WM_COMMAND), item to get
//				(ID or DESC)
//     Returns: Pointer to description
LPSTR GetNotifyString(UINT p_dNotifyNo,int p_dItem)
{
	UINT dUpperBound;
	UINT dLowerBound;
	UINT dIndex; 

	// Set bounds for search
	dLowerBound = 1;
	dUpperBound = sizeof(g_nlTable)/sizeof(NotifyList);
	dIndex = (dUpperBound+dLowerBound)/2;

	// Perform binary tree search for ID
	while(g_nlTable[dIndex-1].dNotifyNo != p_dNotifyNo)
	{
		// Do comparisions
		if(g_nlTable[dIndex-1].dNotifyNo < p_dNotifyNo)
			dLowerBound = dIndex+1;
		else if(g_nlTable[dIndex-1].dNotifyNo > p_dNotifyNo)
			dUpperBound = dIndex-1;

		// Set new index
		dIndex = (dUpperBound+dLowerBound)/2;

		// Check if no match was found
		if(dLowerBound > dUpperBound)
			return NULL;
	}

	// Return match field, check for filters when returning IDs
	if(p_dItem == ID)
		return (!g_nlTable[dIndex-1].bFilter)?g_nlTable[dIndex-1].pNotifyID:LPFILTER;
	else
		return g_nlTable[dIndex-1].pNotifyDesc;
}

//        Name: GetMessageSignature
// Description: Given a numeric ID, return parameter and return types for messages
//  Parameters: Message ID, item to get
//     Returns: Signature value
BYTE GetMessageSignature(UINT p_dMessageNo,int p_dItem)
{
	UINT dUpperBound;
	UINT dLowerBound;
	UINT dIndex; 

	// Set bounds for search
	dLowerBound = 1;
	dUpperBound = sizeof(g_mlTable)/sizeof(MessageList);
	dIndex = (dUpperBound+dLowerBound)/2;

	// Perform binary tree search for ID
	while(g_mlTable[dIndex-1].dMessageNo != p_dMessageNo)
	{
		// Do comparisions
		if(g_mlTable[dIndex-1].dMessageNo < p_dMessageNo)
			dLowerBound = dIndex+1;
		else if(g_mlTable[dIndex-1].dMessageNo > p_dMessageNo)
			dUpperBound = dIndex-1;

		// Set new index
		dIndex = (dUpperBound+dLowerBound)/2;

		// Check if no match was found
		if(dLowerBound > dUpperBound)
			return 0;
	}

	// Return match field
	if(p_dItem == WPSIG)
		return g_mlTable[dIndex-1].dWParam;
	else if(p_dItem == LPSIG)
		return g_mlTable[dIndex-1].dLParam;
	else
		return g_mlTable[dIndex-1].dLResult;
}

//        Name: GetValue
// Description: Given a string, return actual numeric value for messages, styles, and other values
//  Parameters: Pointer to string, Pointer to return type (VUNKNOWN, VMSGID, VINT)
//     Returns: Value
UINT GetValue(LPSTR p_szToken,LPINT p_pType)
{
	int dX;

	// Search Messages
	for(dX=0;dX<sizeof(g_mlTable)/sizeof(MessageList);dX++)
		if(!(*p_szToken == 'W' && *(p_szToken+1) == 'M'))  // Skip windows messages
			if(!lstrcmp(p_szToken,g_mlTable[dX].pMessageID))
			{
				*p_pType = VMSGID;
				return g_mlTable[dX].dMessageNo;
			}

	// No messages match, search values
	for(dX=0;dX<sizeof(g_vlTable)/sizeof(ValueList);dX++)
		if(!lstrcmp(p_szToken,g_vlTable[dX].pValueID))
		{
			*p_pType = VINT;
			return g_vlTable[dX].dValueNo;
		}

	// No values match, search styles
	for(dX=0;dX<sizeof(g_slTable)/sizeof(StyleList);dX++)
		if(!lstrcmp(p_szToken,g_slTable[dX].pStyleID))
		{
			*p_pType = VINT;
			return g_slTable[dX].dStyleNo;
		}

	// No styles match, search extended styles
	for(dX=0;dX<sizeof(g_exslTable)/sizeof(StyleList);dX++)
		if(!lstrcmp(p_szToken,g_exslTable[dX].pStyleID))
		{
			*p_pType = VINT;
			return g_exslTable[dX].dStyleNo;
		}

	// Nothing matches, token is unknown
	*p_pType = VUNKNOWN;
	return 0;
}

//        Name: StylesProc
// Description: Styles dialog message callback
//  Parameters: Handle to dialog, message, message parameters
//     Returns: TRUE if handled message, FALSE otherwise
BOOL CALLBACK StylesProc(HWND p_hDlg,UINT p_iMsg,WPARAM p_wParam,LPARAM p_lParam)
{
	HWND hStylesList;
	HWND hExStylesList;
	LONG dStyles;
	LONG dExStyles;
	UINT dX;
	UINT dIndex;

	switch(p_iMsg)
	{
		// Initialize Dialog
		case WM_INITDIALOG:
			// Get current styles
			dStyles = GetWindowLong(g_hControl,GWL_STYLE);
			// Get handle to styles list
			hStylesList = GetDlgItem(p_hDlg,IDC_STYLESLIST);
			for(dX=0;dX<sizeof(g_slTable)/sizeof(StyleList);dX++)
			{
				ListBox_AddString(hStylesList,g_slTable[dX].pStyleID);
				// Set selection and values
				if((dStyles&g_slTable[dX].dStyleNo)==g_slTable[dX].dStyleNo)
					ListBox_SetSel(hStylesList,TRUE,dX);
			}
			ListBox_SetTopIndex(hStylesList,0);

			// Get current extended styles
			dExStyles = GetWindowLong(g_hControl,GWL_EXSTYLE);
			// Get handle to extended styles list
			hExStylesList = GetDlgItem(p_hDlg,IDC_EXSTYLESLIST);
			for(dX=0;dX<sizeof(g_exslTable)/sizeof(StyleList);dX++)
			{
				ListBox_AddString(hExStylesList,g_exslTable[dX].pStyleID);
				// Set selection and values
				if((dExStyles&g_exslTable[dX].dStyleNo)==g_exslTable[dX].dStyleNo)
					ListBox_SetSel(hExStylesList,TRUE,dX);
			}
			ListBox_SetTopIndex(hExStylesList,0);

			// Enumerate all child controls to register them with the tool tip control
			EnumChildWindows(p_hDlg,AddToolTipEnum,(LPARAM)p_hDlg);
			break;

		// Process command messages from control
		case WM_COMMAND:
			if(HIWORD(p_wParam) == BN_CLICKED && (LOWORD(p_wParam) == IDC_APPLYSTYLES) || (LOWORD(p_wParam) == IDC_APPLYSTYLESRC))
			{
				// Get handle to styles dialog
				hStylesList = GetDlgItem(p_hDlg,IDC_STYLESLIST);
				// Get all styles
				dStyles = 0;
				for(dX=0;dX<sizeof(g_slTable)/sizeof(StyleList);dX++)
				{
					if(ListBox_GetSel(hStylesList,dX) > 0)
						dStyles |= g_slTable[dX].dStyleNo;
				}

				// Get handle to extended styles dialog
				hExStylesList = GetDlgItem(p_hDlg,IDC_EXSTYLESLIST);
				// Get all styles
				dExStyles = 0;
				for(dX=0;dX<sizeof(g_exslTable)/sizeof(StyleList);dX++)
				{
					if(ListBox_GetSel(hExStylesList,dX) > 0)
						dExStyles |= g_exslTable[dX].dStyleNo;
				}

				// Refresh control
				if(LOWORD(p_wParam) == IDC_APPLYSTYLES)
				{
					SetWindowLong(g_hControl,GWL_STYLE,dStyles);
					SetWindowLong(g_hControl,GWL_EXSTYLE,dExStyles);
				}
				else
				{
					ControlStateCallback(CSPY_SHUTDOWN);
					DestroyWindow(g_hControl);
					g_hControl = NULL;
					CreateControl(dStyles,dExStyles);
				}

				// Refresh style lists				
				// Styles
				dStyles = GetWindowLong(g_hControl,GWL_STYLE);
				dIndex = ListBox_GetTopIndex(hStylesList);
				for(dX=0;dX<sizeof(g_slTable)/sizeof(StyleList);dX++)
					ListBox_SetSel(hStylesList,((dStyles&g_slTable[dX].dStyleNo)==g_slTable[dX].dStyleNo)?TRUE:FALSE,dX);
				ListBox_SetTopIndex(hStylesList,dIndex);

				// Extended styles
				dIndex = ListBox_GetTopIndex(hExStylesList);
				dExStyles = GetWindowLong(g_hControl,GWL_EXSTYLE);
				for(dX=0;dX<sizeof(g_exslTable)/sizeof(StyleList);dX++)
					ListBox_SetSel(hExStylesList,((dExStyles&g_exslTable[dX].dStyleNo)==g_exslTable[dX].dStyleNo)?TRUE:FALSE,dX);
				ListBox_SetTopIndex(hExStylesList,dIndex);
				
				return TRUE;
			}
			break;
		
		// Close
		case WM_CLOSE:
			// Enumerate all child controls to remove them with the tool tip control
			EnumChildWindows(p_hDlg,DeleteToolTipEnum,(LPARAM)p_hDlg);
			DestroyWindow(p_hDlg);
			g_hStyles = NULL;
			return TRUE;
	}

	// Did not process message
	return FALSE;
}

//        Name: InformationProc
// Description: Information dialog message callback
//  Parameters: Handle to dialog, message, message parameters
//     Returns: TRUE if handled message, FALSE otherwise
BOOL CALLBACK InformationProc(HWND p_hDlg,UINT p_iMsg,WPARAM p_wParam,LPARAM p_lParam)
{
	HWND hDisplay;
	EDITSTREAM esDisplay;
	HRSRC hInfo;
	DWORD dInfoSize;
	HGLOBAL hInfoMem;
	void* pInfoData;
	CHARRANGE crSel;

	switch(p_iMsg)
	{
		// Initialize Dialog
		case WM_INITDIALOG:
			PostMessage(p_hDlg,INFO_DISPLAY,0,0);
			break;

		// Load in information file
		case INFO_DISPLAY:
			// Display control information
			hDisplay = GetDlgItem(p_hDlg,IDC_DISPLAY);

			// Load text into display
			hInfo = FindResource(NULL,"INFORMATION","RTF");
			if(hInfo)
			{
				dInfoSize = SizeofResource(NULL,hInfo);
				hInfoMem = LoadResource(NULL,hInfo);
				pInfoData = LockResource(hInfoMem);
			}
			else
				break;

			esDisplay.dwCookie = (DWORD)pInfoData;
			esDisplay.pfnCallback = DisplayStreamCallback;
			esDisplay.dwError = 0;
			g_dInfoDisplayStart = 0;
			g_dInfoDisplayEnd = dInfoSize-1;

			SendMessage(hDisplay,EM_STREAMIN,SF_RTF,(LPARAM)&esDisplay);

			// Position caret at end of file
			crSel.cpMin = -1;
			crSel.cpMax = -1;
			SendMessage(hDisplay,EM_EXSETSEL,0,(LPARAM)&crSel);

			return TRUE;

		// Close
		case WM_CLOSE:
			DestroyWindow(p_hDlg);
			g_hInformation = NULL;
			return TRUE;
	}

	// Did not process message
	return FALSE;
}

//        Name: AboutProc
// Description: About dialog message callback
//  Parameters: Handle to dialog, message, message parameters
//     Returns: TRUE if handled message, FALSE otherwise
BOOL CALLBACK AboutProc(HWND p_hDlg,UINT p_iMsg,WPARAM p_wParam,LPARAM p_lParam)
{
	RECT rectWindow;

	switch(p_iMsg)
	{
		case WM_INITDIALOG:
			// Center window
			GetWindowRect(p_hDlg,&rectWindow);
			SetWindowPos(p_hDlg,NULL,(GetSystemMetrics(SM_CXSCREEN)-rectWindow.right+rectWindow.left)/2,
				(GetSystemMetrics(SM_CYSCREEN)-rectWindow.bottom+rectWindow.top)/2,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_SHOWWINDOW);
			break;

		// Close
		case WM_CLOSE:
			EndDialog(p_hDlg,0);
			return TRUE;
	}

	// Did not process message
	return FALSE;
}

//        Name: DisplayStreamCallback
// Description: Callback for rich edit control contained in the information dialog box
//  Parameters: Application defined value, pointer to buffer, number of bytes to read, bytes transferred
//     Returns: 0 on success
DWORD CALLBACK DisplayStreamCallback(DWORD p_dwCookie,LPBYTE p_pbBuff,LONG p_cb,LONG* p_pcb)
{
	LONG dToCopy;

	// Check if out of buffer to copy
	if(g_dInfoDisplayStart > g_dInfoDisplayEnd)
	{
		*p_pcb = 0;
		return 0;
	}

	// Compute buffer size to copy
	dToCopy = g_dInfoDisplayEnd-g_dInfoDisplayStart+1;
	if(dToCopy > p_cb)
		dToCopy = p_cb;

	// Transfer buffer	
	memcpy(p_pbBuff,(void*)(p_dwCookie+g_dInfoDisplayStart),dToCopy);

	*p_pcb = dToCopy;

	g_dInfoDisplayStart += dToCopy;

	// Success
	return 0;
}

//        Name: UpdateUI
// Description: Enable and disable user interface components based on current state
//  Parameters: none
//     Returns: none
void UpdateUI()
{
	CHAR szCount[21];
	LPSTR pStatement;

	// Update user interface based on statement list
	EnableWindow(GetDlgItem(g_hDialog,IDC_FORWARD),g_dSLCurrent<g_dSLCount-1);
	EnableWindow(GetDlgItem(g_hDialog,IDC_FASTFORWARD),g_dSLCurrent<g_dSLCount-1);
	EnableWindow(GetDlgItem(g_hDialog,IDC_REVERSE),g_dSLCurrent>0);
	EnableWindow(GetDlgItem(g_hDialog,IDC_FASTREVERSE),g_dSLCurrent>0);
	EnableWindow(GetDlgItem(g_hDialog,IDC_SENDALL),g_dSLCount&&!g_bSendAll);
	EnableWindow(GetDlgItem(g_hDialog,IDC_REFRESH),g_dSLCount);
	EnableWindow(GetDlgItem(g_hDialog,IDC_DESTROY),g_dSLCount);
	EnableWindow(GetDlgItem(g_hDialog,IDC_SEND),!g_bSendAll);
	EnableWindow(GetDlgItem(g_hDialog,IDC_LOGFILE),!g_bLogging);
	EnableWindow(GetDlgItem(g_hDialog,IDC_LOGFILEBROWSE),!g_bLogging);

	// Update current parameters display
	if(g_dSLCount)
	{
		CHAR szDisplay[_MAX_PATH+31];
		wsprintf(szDisplay,"Statement List Open\r\n[%s]",g_szSLFile);
		SetWindowText(GetDlgItem(g_hDialog,IDC_MSGSIGNATURE),szDisplay);
	}

	// Update count display
	if(g_dSLCount)
	{
		wsprintf(szCount,"%d of %d",g_dSLCurrent+1,g_dSLCount);
		pStatement = StrTrim(g_pSLIndex[g_dSLCurrent]);
		if(pStatement)
		{
			SetWindowText(GetDlgItem(g_hDialog,IDC_MSGPARAMS),pStatement);
			free(pStatement);
		}
		else
			SetWindowText(GetDlgItem(g_hDialog,IDC_MSGPARAMS),"");
	}
	else
		*szCount = '\0';
	SetWindowText(GetDlgItem(g_hDialog,IDC_COUNT),szCount);
}

//        Name: StrTrim
// Description: Remove leading and trailing whitespace from given string, allocates memory
//				so must free return pointer
//  Parameters: Pointer to string
//     Returns: none
LPSTR StrTrim(LPSTR p_pStr)
{
	int dStart;
	int dEnd;
	LPSTR pReturn;

	dStart = 0;
	while(*(p_pStr+dStart) == '\r' || *(p_pStr+dStart) == '\n' || *(p_pStr+dStart) == '\t' || *(p_pStr+dStart) == ' ')
		dStart++;
	
	if(!*(p_pStr+dStart))
		return NULL;

	dEnd = strlen(p_pStr)-1;
	while(*(p_pStr+dEnd) == '\r' || *(p_pStr+dEnd) == '\n' || *(p_pStr+dEnd) == '\t' || *(p_pStr+dEnd) == ' ')
		dEnd--;

	pReturn = (LPSTR)malloc(dEnd-dStart+2);
	strncpy(pReturn,p_pStr+dStart,dEnd-dStart+1);
	pReturn[dEnd-dStart+1] = '\0';

	return pReturn;
}