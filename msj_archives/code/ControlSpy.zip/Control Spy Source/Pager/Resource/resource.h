//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Pager.rc
//
#define IDD_MAINDIALOG                  101
#define IDI_APPICON                     103
#define IDB_PLANETS                     151
#define IDB_PLANETS4                    152
#define IDR_MENU                        155
#define IDD_STYLESDIALOG                156
#define IDD_INFODIALOG                  157
#define IDI_FORWARD                     163
#define IDI_REVERSE                     164
#define IDI_FASTFORWARD                 165
#define IDI_FASTREVERSE                 166
#define IDI_LOAD                        168
#define IDI_REFRESH                     169
#define IDD_ABOUT                       169
#define IDI_DESTROY                     170
#define IDI_LOGON                       171
#define IDI_LOGOFF                      172
#define IDI_APPICONSM                   173
#define IDI_EXECUTE                     175
#define IDC_NOTIFYLIST                  1000
#define IDC_MSGLIST                     1001
#define IDC_SENDMSGLIST                 1002
#define IDC_CONTROL_RECT                1009
#define IDC_CONTAINER_RECT              1010
#define IDC_MSGPARAMS                   1036
#define IDC_MSGSIGNATURE                1037
#define IDC_SEND                        1038
#define IDC_RETURN                      1039
#define IDC_SENDALL                     1040
#define IDC_STYLESLIST                  1046
#define IDC_EXSTYLESLIST                1047
#define IDC_APPLYSTYLESRC               1048
#define IDC_APPLYSTYLES                 1049
#define IDC_DISPLAY                     1051
#define IDC_FORWARD                     1053
#define IDC_FASTFORWARD                 1054
#define IDC_REVERSE                     1055
#define IDC_FASTREVERSE                 1056
#define IDC_CLEARNOTIFY                 1057
#define IDC_CLEARMESSAGE                1058
#define IDC_LOAD                        1059
#define IDC_REFRESH                     1060
#define IDC_DESTROY                     1061
#define IDC_COUNT                       1062
#define IDC_LOGFILE                     1063
#define IDC_LOGTOGGLE                   1064
#define IDC_LOGFILEBROWSE               1065
#define IDC_CLEARLOG                    1066
#define IDC_EXECUTE                     1067
#define IDC_RETURNLABEL                 1069
#define IDC_STATE                       1070
#define IDC_DATETIMEPICKER1             1071
#define IDC_SPIN                        1071
#define IDS_MERCURY                     2000
#define IDS_VENUS                       2001
#define IDS_EARTH                       2002
#define IDS_MARS                        2003
#define IDS_JUPITER                     2004
#define IDS_SATURN                      2005
#define IDS_URANUS                      2006
#define IDS_NEPTUNE                     2007
#define IDS_PLUTO                       2008
#define IDS_TT_NOTIFYLIST               3000
#define IDS_TT_MSGLIST                  3001
#define IDS_TT_SENDMSGLIST              3002
#define IDS_TT_MSGSIGNATURE             3037
#define IDS_TT_SEND                     3038
#define IDS_TT_RETURN                   3039
#define IDS_TT_APPLYSTYLESRC            3048
#define IDS_TT_APPLYSTYLES              3049
#define IDS_TT_FORWARD                  3053
#define IDS_TT_FASTFORWARD              3054
#define IDS_TT_REVERSE                  3055
#define IDS_TT_FASTREVERSE              3056
#define IDS_TT_CLEARNOTIFY              3057
#define IDS_TT_CLEARMESSAGE             3058
#define IDS_TT_LOAD                     3059
#define IDS_TT_REFRESH                  3060
#define IDS_TT_DESTROY                  3061
#define IDS_TT_LOGTOGGLE                3064
#define IDS_TT_LOGFILEBROWSE            3065
#define IDS_TT_CLEARLOG                 3066
#define IDS_TT_EXECUTE                  3067
#define ID_INFORMATION                  40005
#define ID_ABOUT                        40006
#define ID_STYLES                       40022
#define ID_FILTERWINDOWMESSAGES         40025
#define ID_FILTERCONTROLMESSAGES        40026
#define ID_FILTERUNKNOWNMESSAGES        40027
#define ID_FILTERCONTROLNOTIFICATIONS   40028
#define ID_FILTERUNKNOWNNOTIFICATIONS   40029
#define ID_FILTERCOMMONNOTIFICATIONS    40030

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        178
#define _APS_NEXT_COMMAND_VALUE         40031
#define _APS_NEXT_CONTROL_VALUE         1072
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
