// Cci.h : Parser include

// Control Spy: Image List

// Mark J. Finocchio (markfi), Microsoft Corporation

// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) 1998 Microsoft Corporation.  All Rights Reserved.

// Defines
#define CCITYPE		BYTE
#define STRBUFSIZE	128
#define ERRBUFSIZE	128
#define TEMPFILE	"c:\\cciparse.tmp"
#define SIGTEMP		0
#define SIGDESC		1
#define ALLOCMAX	32

#define VUNKNOWN	0
#define VMSGID		1
#define VINT		2

#define MAXAPIPARAM	10		// Maximum number of parameters allowed for API functions
#define APINOSTART	10000	// API starting "message id"
#define APINOEND	19999	// API starting "message id"

#define IMAGELISTADD				0	// Control API
#define IMAGELISTADDMASKED			1	// Control API
#define IMAGELISTBEGINDRAG			2	// Control API
#define IMAGELISTCOPY				3	// Control API
#define IMAGELISTCREATE				4	// Control API
#define IMAGELISTDESTROY			5	// Control API
#define IMAGELISTDRAGENTER			6	// Control API
#define IMAGELISTDRAGLEAVE			7	// Control API
#define IMAGELISTDRAGMOVE			8	// Control API
#define IMAGELISTDRAGSHOWNOLOCK		9	// Control API
#define IMAGELISTDRAW				10	// Control API
#define IMAGELISTDRAWEX				11	// Control API
#define IMAGELISTDRAWINDIRECT		12	// Control API
#define IMAGELISTDUPLICATE			13	// Control API
#define IMAGELISTENDDRAG			14	// Control API
#define IMAGELISTGETBKCOLOR			15	// Control API
#define IMAGELISTGETDRAGIMAGE		16	// Control API
#define IMAGELISTGETICON			17	// Control API
#define IMAGELISTGETICONSIZE		18	// Control API
#define IMAGELISTGETIMAGECOUNT		19	// Control API
#define IMAGELISTGETIMAGEINFO		20	// Control API
#define IMAGELISTLOADIMAGE			21	// Control API
#define IMAGELISTMERGE				22	// Control API
#define IMAGELISTREAD				23	// Control API
#define IMAGELISTREMOVE				24	// Control API
#define IMAGELISTREPLACE			25	// Control API
#define IMAGELISTREPLACEICON		26	// Control API
#define IMAGELISTSETBKCOLOR			27	// Control API
#define IMAGELISTSETDRAGCURSORIMAGE	28	// Control API
#define IMAGELISTSETICONSIZE		29	// Control API
#define IMAGELISTSETIMAGECOUNT		30	// Control API
#define IMAGELISTSETOVERLAYIMAGE	31	// Control API
#define IMAGELISTWRITE				32	// Control API

#define NOV				0	// Non-Parse type
#define ERRV			1	// Non-Parse type
#define SUCCESSV		2	// Non-Parse type
#define BITMASKV		3	// Non-Parse type
#define	NUMV			4	// Parse type
#define BOOLV			5	// Parse type
#define LPSTRV			6	// Parse type
#define LPSTRVI			7	// Parse type

// >> Start control specific
#define APIV			8	// API placeholder flag, not used in parser
#define APIPARAMLISTV	9	// API placeholder flag, not used in parser
#define IMAGELISTV		10	// Non-Parse type, Param
#define BITMAPV			11	// Non-Parse type, Param
#define WINDOWV			12	// Non-Parse type, Param
#define DCV				13	// Non-Parse type, Param
#define INSTANCEV		14	// Non-Parse type, Param
#define STREAMV			15	// Non-Parse type, Param
#define ICONV			16	// Non-Parse type, Param
// << End control specific
// >> Start control specific
#define RGBV			17	// Parse type, Param
#define LPINTBUFV		18	// Parse type, Param
#define LPILDPVI		19	// Parse type, Param
#define LPPOINTV		20	// Parse type, Param
#define LPIIV			21	// Parse type, Param
// << End control specific

#define STYLEV			(CCITYPE)-1	// Non-Parse type, non rendering nor display

// Typedefs
typedef struct tagCCITypeVal
{
	CCITYPE	cciType;
	void*	cciValue;
} CCITypeVal;

typedef struct tagCCIStyle
{
	LONG dStyleOn;
	LONG dStyleOff;
	LONG dExStyleOn;
	LONG dExStyleOff;
	BOOL bRecreate;
} CCIStyle;

typedef struct tagCCIResult
{
	LPSTR pInput;

	UINT dMsgNo;

	CCITYPE ccitWParam;
	CCITYPE ccitLParam;

	void* pWParam;
	void* pLParam;

	LPSTR pError;
	int dErrLine;
} CCIResult;


// Global variables
extern HINSTANCE g_hInstance;
extern HIMAGELIST g_hImageList0;
extern HIMAGELIST g_hImageList1;
extern HBITMAP g_hBitmap0;
extern HBITMAP g_hBitmap1;
extern HDC g_hDC;
extern LPSTREAM g_hStream;
extern HICON g_hIcon;
extern HWND g_hContainer;

extern HWND g_hDialog;
extern LPSTR g_pSignature[][2];
extern void* g_pMemTrack[];

// Function prototypes
CCIResult* CCIInterpret(LPSTR);
void CCIRender(CCITYPE,void*,LPSTR);
void CCIDestroy(CCIResult*);
void CCIDestroyHelper(CCITYPE,void*);
LPSTR CCIGetSignature(BYTE,BYTE);
void CCIMemTrack(void*);
