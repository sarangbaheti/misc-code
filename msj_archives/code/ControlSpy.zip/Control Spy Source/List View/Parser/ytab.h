typedef union {
	INT intVal;
	CHAR szVal[STRBUFSIZE];
	CCITypeVal tvVal;
} YYSTYPE;
#define YUNKNOWN	257
#define YMSG	258
#define YSTYLE	259
#define YSETWINLONG	260
#define YRECREATE	261
#define YMSGID	262
#define YINT	263
#define YBOOL	264
#define YNULL	265
#define YSTR	266
#define YSTRBUF	267
#define YLPTCBK	268
#define YRGB	269
#define YRECT	270
#define YPOINT	271
#define YMAKELPARAM	272
#define YMAKELONG	273
#define YLVITEM	274
#define YLVFINDINFO	275
#define YLVHTI	276
#define YLVCOLUMN	277
#define YINTARR	278
#define YRECTARR	279
#define YINTBUF	280
#define YLVBKIMAGE	281
extern YYSTYPE yylval;
