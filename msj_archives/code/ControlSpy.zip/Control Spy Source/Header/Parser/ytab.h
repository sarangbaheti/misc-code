typedef union {
	INT intVal;
	CHAR szVal[STRBUFSIZE];
	CCITypeVal tvVal;
} YYSTYPE;
#define YUNKNOWN	257
#define YMSG	258
#define YSTYLE	259
#define YSETWINLONG	260
#define YRECREATE	261
#define YMSGID	262
#define YINT	263
#define YBOOL	264
#define YNULL	265
#define YSTR	266
#define YSTRBUF	267
#define YLPTCBK	268
#define YMAKELPARAM	269
#define YRECT	270
#define YINTARR	271
#define YHDITEM	272
#define YHDHTINFO	273
#define YHDLAYOUT	274
#define YPOINT	275
extern YYSTYPE yylval;
