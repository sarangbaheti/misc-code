typedef union {
	INT intVal;
	CHAR szVal[STRBUFSIZE];
	CCITypeVal tvVal;
} YYSTYPE;
#define YUNKNOWN	257
#define YMSG	258
#define YSTYLE	259
#define YSETWINLONG	260
#define YRECREATE	261
#define YMSGID	262
#define YINT	263
#define YBOOL	264
#define YNULL	265
#define YSTR	266
#define YSTRBUF	267
#define YLPTCBK	268
#define YRGB	269
#define YRECT	270
#define YTVHTINFO	271
#define YTVITEMEX	272
#define YTVIS	273
#define YTVSORTCB	274
extern YYSTYPE yylval;
