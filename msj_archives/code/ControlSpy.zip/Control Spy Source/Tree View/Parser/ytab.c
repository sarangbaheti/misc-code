/* \program files\mks\mksnt\yacc -d -o ../Parser/ytab.c -D ../Parser/ytab.h -P /progra~1/mks/etc/yyparse.c ../Parser/cci.y */
#ifdef YYTRACE
#define YYDEBUG 1
#else
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#endif
/*
 * Portable way of defining ANSI C prototypes
 */
#ifndef YY_ARGS
#if __STDC__
#define YY_ARGS(x)	x
#else
#define YY_ARGS(x)	()
#endif
#endif

#ifdef YACC_WINDOWS

#include <windows.h>

/*
 * the following is the handle to the current
 * instance of a windows program. The user
 * program calling yyparse must supply this!
 */

extern HANDLE hInst;	

#endif	/* YACC_WINDOWS */

#if YYDEBUG
typedef struct yyNamedType_tag {	/* Tokens */
	char	* name;		/* printable name */
	short	token;		/* token # */
	short	type;		/* token type */
} yyNamedType;
typedef struct yyTypedRules_tag {	/* Typed rule table */
	char	* name;		/* compressed rule string */
	short	type;		/* rule result type */
} yyTypedRules;

#endif

#line 16 "../Parser/cci.y"

// Included files
#include <windows.h>
#include <stdio.h>
#include <commctrl.h>
#include "cci.h"

// Function prototypes
void yyerror(char* error);
void yy_reset(void);
int yyparse(void);

// Global variables
extern char yytext[];
extern int yylineno;
extern FILE *yyin;

CCIResult* g_pCCIResult;
LPSTR g_pSignature[][2] = { { "0", "No value" },
							{ "0", "Numeric value (<0 is ERROR, otherwise OK)" },
							{ "0", "Numeric value (non-zero is SUCCESS, otherwise ERROR)" },
							{ "0", "Bitmasked value" },
							{ "0", "Numeric decimal value" },
							{ "TRUE", "Boolean value (TRUE or FALSE)" },
							{ "buffer", "Pointer to string buffer (use 'buffer', max 127 chars)" },
							{ "\"string\"", "Pointer to initialized string (imbedded quotes not allowed)" },
							// >> Start control specific
							{ "imagelist", "Imagelist handle (use 'imagelist' or NULL)" },
							{ "root", "Tree item handle (use 'root', 'node0', 'node1', ..., 'nodeN', or NULL)" },
							{ "RECT(root)", "Pointer to RECT structure initialized with Item Handle" },
							{ "tooltip", "Tootip handle (use 'tooltip')" },
							// << End control specific
							// >> Start control specific
							{ "RGB(0,0,0)", "Red, green, and blue (RGB) value" },
							{ "RECT", "Pointer to RECT structure" },
							{ "TVHITTESTINFO(0,0)", "Pointer to TVHITTESTINFO structure with initialized POINT" },
							{ "TVITEMEX(0,root,0/0/0,0,\"string\",127,0,0,0,0,0)", "Pointer to initialized TVITEMEX structure" },
							{ "TVINSERTSTRUCT(root,0,TVITEMEX(0,0,0/0/0,0,\"string\",127,0,0,0,0,0))", "Pointer to initialized TVINSERTSTRUCT structure" },
							{ "TVSORTCB(root,compare,0)", "Pointer to initialized TVSORTCB (use 'compare' for internal callback)" }
							// << End control specific
						  };
void* g_pMemTrack[ALLOCMAX];
typedef union {
	INT intVal;
	CHAR szVal[STRBUFSIZE];
	CCITypeVal tvVal;
} YYSTYPE;
#define YUNKNOWN	257
#define YMSG	258
#define YSTYLE	259
#define YSETWINLONG	260
#define YRECREATE	261
#define YMSGID	262
#define YINT	263
#define YBOOL	264
#define YNULL	265
#define YSTR	266
#define YSTRBUF	267
#define YLPTCBK	268
#define YRGB	269
#define YRECT	270
#define YTVHTINFO	271
#define YTVITEMEX	272
#define YTVIS	273
#define YTVSORTCB	274
extern int yychar, yyerrflag;
extern YYSTYPE yylval;
#if YYDEBUG
enum YY_Types { YY_t_NoneDefined, YY_t_intVal, YY_t_szVal, YY_t_tvVal
};
#endif
#if YYDEBUG
yyTypedRules yyRules[] = {
	{ "&00: %01 &00",  0},
	{ "%01: %06",  0},
	{ "%01: %07",  0},
	{ "%06: &03 &20 &07 &21 %03 &21 %03 &22",  0},
	{ "%03: &10",  3},
	{ "%03: %04",  3},
	{ "%03: &09",  3},
	{ "%03: &12",  3},
	{ "%03: &11",  3},
	{ "%03: &14 &20 &08 &21 &08 &21 &08 &22",  3},
	{ "%03: &15",  3},
	{ "%03: &15 &20 &08 &22",  3},
	{ "%03: &16 &20 &08 &21 &08 &22",  3},
	{ "%03: &17 &20 %04 &21 &08 &21 %02 &21 %04 &21 &11 &21 &08 &21 &08 &21 &08 &21 &08 &21 &08 &21 &08 &22",  3},
	{ "%03: &17 &20 %04 &21 &08 &21 %02 &21 %04 &21 &13 &21 &08 &21 &08 &21 &08 &21 &08 &21 &08 &21 &08 &22",  3},
	{ "%03: &18 &20 &08 &21 &08 &21 &17 &20 %04 &21 &08 &21 %02 &21 %04 &21 &11 &21 &08 &21 &08 &21 &08 &21 &08 &21 &08 &21 &08 &22 &22",  3},
	{ "%03: &18 &20 &08 &21 &08 &21 &17 &20 %04 &21 &08 &21 %02 &21 %04 &21 &13 &21 &08 &21 &08 &21 &08 &21 &08 &21 &08 &21 &08 &22 &22",  3},
	{ "%03: &19 &20 &08 &21 &08 &21 &08 &22",  3},
	{ "%02: %04 &23 %04 &23 %04",  1},
	{ "%07: &04 &20 %04 &21 %04 &21 %04 &21 %04 &21 %05 &22",  0},
	{ "%05: &05",  1},
	{ "%05: &06",  1},
	{ "%04: %04 &24 &08",  1},
	{ "%04: &08",  1},
{ "$accept",  0},{ "error",  0}
};
yyNamedType yyTokenTypes[] = {
	{ "$end",  0,  0},
	{ "error",  256,  0},
	{ "YUNKNOWN",  257,  0},
	{ "YMSG",  258,  0},
	{ "YSTYLE",  259,  0},
	{ "YSETWINLONG",  260,  1},
	{ "YRECREATE",  261,  1},
	{ "YMSGID",  262,  1},
	{ "YINT",  263,  1},
	{ "YBOOL",  264,  1},
	{ "YNULL",  265,  1},
	{ "YSTR",  266,  2},
	{ "YSTRBUF",  267,  0},
	{ "YLPTCBK",  268,  1},
	{ "YRGB",  269,  0},
	{ "YRECT",  270,  0},
	{ "YTVHTINFO",  271,  0},
	{ "YTVITEMEX",  272,  0},
	{ "YTVIS",  273,  0},
	{ "YTVSORTCB",  274,  0},
	{ "'('",  40,  0},
	{ "','",  44,  0},
	{ "')'",  41,  0},
	{ "'/'",  47,  0},
	{ "'|'",  124,  0}

};
#endif
static short yydef[] = {

	  -1,    4,    3,    5
};
static short yyex[] = {

	   0,    0,   -1,    1
};
static short yyact[] = {

	-127, -128,  259,  258, -126,   40, -125,   40, -149,  263, 
	-123,  262, -121, -122,  124,   44, -120,   44, -130,  263, 
	-149, -144, -145, -142, -143, -114,   -2, -115, -116, -117, 
	-118,  274,  273,  272,  271,  270,  269,  267,  266,  265, 
	 264,  263, -112, -122,  124,   44, -111,   40, -110,   40, 
	-109,   40, -108,   40, -107,   40, -106,   40, -122,  124, 
	-105,   44, -103,  263, -102,  263, -100,  263,  -99,  263, 
	 -98,  263,  -96, -122,  124,   44,  -95,   44,  -94,   44, 
	 -93, -122,  124,   44,  -92,   44, -140,   41,  -91,   44, 
	-146,   41,  -89,  263,  -88,  263,  -87,  263,  -86,  263, 
	 -85,  263,  -84, -122,  124,   44,  -83,   44,  -82,   44, 
	 -81,   44, -139,   41,  -80,   44, -132, -131,  261,  260, 
	 -78,  263,  -77,  272,  -74,  263, -133,   41, -134,   41, 
	 -73,   40,  -72, -122,  124,   47,  -71,   44, -141,   41, 
	 -67, -122,  124,   44,  -66, -122,  124,   47,  -65, -122, 
	 124,   44,  -64,  263,  -62,  -63,  268,  266,  -61,   44, 
	 -60,   44,  -59,   44,  -57,  263,  -56,  263,  -55,   44, 
	 -54,   44,  -53,   44,  -51,  263,  -50,  263,  -49, -122, 
	 124,   44,  -48,   44,  -47,   44,  -45,  -46,  268,  266, 
	 -44,  263,  -43,  263,  -42,   44,  -41,   44,  -40,   44, 
	 -39,   44,  -38,  263,  -37,  263,  -36,  263,  -35,  263, 
	 -34,   44,  -33,   44,  -32,   44,  -31,   44,  -30,  263, 
	 -29,  263,  -28,  263,  -27,  263,  -26,   44,  -25,   44, 
	 -24,   44,  -23,   44,  -22,  263,  -21,  263,  -20,  263, 
	 -19,  263,  -18,   44,  -17,   44, -137,   41, -138,   41, 
	 -16,  263,  -15,  263,  -14,   44,  -13,   44,  -12,  263, 
	 -11,  263,  -10,   44,   -9,   44,   -8,  263,   -7,  263, 
	  -6,   41,   -5,   41, -135,   41, -136,   41,   -1
};
static short yypact[] = {

	   8,   55,   59,   59,  277,  275,  273,  271,  269,  267, 
	 265,  263,  261,  259,  257,  255,  253,  251,  249,  247, 
	 245,  243,  241,  239,  237,  235,  233,  231,  229,  227, 
	 225,  223,  221,  219,  217,  215,  213,  211,  209,  207, 
	 205,  203,  201,  199,  197,  195,  193,  191,  188,  185, 
	 183,  180,  177,  175,    9,  173,  171,  169,  167,  165, 
	   9,  163,  161,  159,  156,    9,  153,  150,  146,  142, 
	   9,    9,    9,  139,  137,  134,  131,  129,  127,  125, 
	   9,  123,  121,  118,  115,  113,  111,  109,  107,  104, 
	 101,   99,   97,   95,   93,    9,   91,   89,   87,   85, 
	  82,   79,   77,   74,   31,   71,   69,   67,    9,   65, 
	  63,    9,   61,   57,   53,   51,   49,   47,   44,   31, 
	   9,   19,   17,   14,   11,    9,    7,    5,    2
};
static short yygo[] = {

	  -1,  -58,  -75,   60,  -97, -113,  104,  -52,  -76,   -4, 
	 -68,  -69,  -70,  -76,  -90, -101, -104, -119, -124,   -3, 
	 125,  120,  111,  108,   95,   80,   72,   71,   70,   65, 
	  60,   54,  -79, -147, -148,   -1
};
static short yypgo[] = {

	   0,    0,    0,    5,    5,    2,   19,   32,   32,   34, 
	   5,    5,    5,    5,    5,    5,    5,    5,    5,    5, 
	   5,    5,   33,    0,    0,   19,    0
};
static short yyrlen[] = {

	   0,    0,    0,    1,    1,    5,    3,    1,    1,   12, 
	   8,   31,   31,   24,   24,    6,    4,    8,    1,    1, 
	   1,    1,    8,    1,    1,    1,    2
};
#define YYS0	128
#define YYDELTA	123
#define YYNPACT	129
#define YYNDEF	4

#define YYr24	0
#define YYr25	1
#define YYr26	2
#define YYr5	3
#define YYr10	4
#define YYr18	5
#define YYr22	6
#define YYr21	7
#define YYr20	8
#define YYr19	9
#define YYr17	10
#define YYr16	11
#define YYr15	12
#define YYr14	13
#define YYr13	14
#define YYr12	15
#define YYr11	16
#define YYr9	17
#define YYr8	18
#define YYr7	19
#define YYr6	20
#define YYr4	21
#define YYr3	22
#define YYrACCEPT	YYr24
#define YYrERROR	YYr25
#define YYrLR2	YYr26
#if YYDEBUG
char * yysvar[] = {
	"$accept",
	"statement",
	"stateshift",
	"parameter",
	"intbmval",
	"applystyle",
	"message",
	"style",
	0
};
short yyrmap[] = {

	  24,   25,   26,    5,   10,   18,   22,   21,   20,   19, 
	  17,   16,   15,   14,   13,   12,   11,    9,    8,    7, 
	   6,    4,    3,    1,    2,   23,    0
};
short yysmap[] = {

	   5,   20,   25,   85,  146,  145,  144,  143,  142,  141, 
	 140,  139,  138,  137,  136,  135,  132,  131,  130,  129, 
	 128,  127,  126,  125,  124,  123,  122,  121,  120,  119, 
	 118,  117,  116,  115,  114,  113,  112,  111,  110,  109, 
	 108,  107,  106,  105,  104,  103,  102,  101,  100,   99, 
	  98,   97,   96,   95,   94,   93,   92,   91,   90,   89, 
	  88,   87,   86,   84,   83,   82,   81,   80,   79,   78, 
	  76,   75,   74,   71,   70,   69,   68,   67,   66,   63, 
	  61,   60,   59,   58,   57,   56,   55,   54,   53,   52, 
	  50,   48,   47,   46,   45,   44,   43,   42,   41,   40, 
	  39,   38,   37,   36,   35,   34,   33,   32,   31,   30, 
	  29,   28,   27,   21,   19,   18,   17,   16,   15,   13, 
	  12,   11,   10,    9,    7,    6,    2,    1,    0,   14, 
	  64,   65,   72,   73,  147,  148,  133,  134,   62,   49, 
	  77,   22,   23,   24,   26,   51,    4,    3,    8
};
int yyntoken = 25;
int yynvar = 8;
int yynstate = 149;
int yynrule = 27;
#endif

#if YYDEBUG
/*
 * Package up YACC context for tracing
 */
typedef struct yyTraceItems_tag {
	int	state, lookahead, errflag, done;
	int	rule, npop;
	short	* states;
	int	nstates;
	YYSTYPE * values;
	int	nvalues;
	short	* types;
} yyTraceItems;
#endif

#line 2 "/progra~1/mks/etc/yyparse.c"

/*
 * Copyright 1985, 1990 by Mortice Kern Systems Inc.  All rights reserved.
 * 
 * Automaton to interpret LALR(1) tables.
 *
 * Macros:
 *	yyclearin - clear the lookahead token.
 *	yyerrok - forgive a pending error
 *	YYERROR - simulate an error
 *	YYACCEPT - halt and return 0
 *	YYABORT - halt and return 1
 *	YYRETURN(value) - halt and return value.  You should use this
 *		instead of return(value).
 *	YYREAD - ensure yychar contains a lookahead token by reading
 *		one if it does not.  See also YYSYNC.
 *	YYRECOVERING - 1 if syntax error detected and not recovered
 *		yet; otherwise, 0.
 *
 * Preprocessor flags:
 *	YYDEBUG - includes debug code if 1.  The parser will print
 *		 a travelogue of the parse if this is defined as 1
 *		 and yydebug is non-zero.
 *		yacc -t sets YYDEBUG to 1, but not yydebug.
 *	YYTRACE - turn on YYDEBUG, and undefine default trace functions
 *		so that the interactive functions in 'ytrack.c' will
 *		be used.
 *	YYSSIZE - size of state and value stacks (default 150).
 *	YYSTATIC - By default, the state stack is an automatic array.
 *		If this is defined, the stack will be static.
 *		In either case, the value stack is static.
 *	YYALLOC - Dynamically allocate both the state and value stacks
 *		by calling malloc() and free().
 *	YYDYNAMIC - Dynamically allocate (and reallocate, if necessary)
 *		both the state and value stacks by calling malloc(),
 *		realloc(), and free().
 *	YYSYNC - if defined, yacc guarantees to fetch a lookahead token
 *		before any action, even if it doesnt need it for a decision.
 *		If YYSYNC is defined, YYREAD will never be necessary unless
 *		the user explicitly sets yychar = -1
 *
 * Copyright (c) 1983, by the University of Waterloo
 */
/*
 * Prototypes
 */

extern int yylex YY_ARGS((void));

#if YYDEBUG

#include <stdlib.h>		/* common prototypes */
#include <string.h>

extern char *	yyValue YY_ARGS((YYSTYPE, int));	/* print yylval */
extern void yyShowState YY_ARGS((yyTraceItems *));
extern void yyShowReduce YY_ARGS((yyTraceItems *));
extern void yyShowGoto YY_ARGS((yyTraceItems *));
extern void yyShowShift YY_ARGS((yyTraceItems *));
extern void yyShowErrRecovery YY_ARGS((yyTraceItems *));
extern void yyShowErrDiscard YY_ARGS((yyTraceItems *));

extern void yyShowRead YY_ARGS((int));
#endif

/*
 * If YYDEBUG defined and yydebug set,
 * tracing functions will be called at appropriate times in yyparse()
 * Pass state of YACC parse, as filled into yyTraceItems yyx
 * If yyx.done is set by the tracing function, yyparse() will terminate
 * with a return value of -1
 */
#define YY_TRACE(fn) { \
	yyx.state = yystate; yyx.lookahead = yychar; yyx.errflag =yyerrflag; \
	yyx.states = yys+1; yyx.nstates = yyps-yys; \
	yyx.values = yyv+1; yyx.nvalues = yypv-yyv; \
	yyx.types = yytypev+1; yyx.done = 0; \
	yyx.rule = yyi; yyx.npop = yyj; \
	fn(&yyx); \
	if (yyx.done) YYRETURN(-1); }

#ifndef I18N
#define m_textmsg(id, str, cls)	(str)
#else /*I18N*/
#include <m_nls.h>
#endif/*I18N*/

#ifndef YYSSIZE
# define YYSSIZE	150
#endif

#ifdef YYDYNAMIC
#define YYALLOC
char *getenv();
int atoi();
int yysinc = -1; /* stack size increment, <0 = double, 0 = none, >0 = fixed */
#endif

#ifdef YYALLOC
int yyssize = YYSSIZE;
#endif

#define YYERROR		goto yyerrlabel
#define yyerrok		yyerrflag = 0
#if YYDEBUG
#define yyclearin	{ if (yydebug) yyShowRead(-1); yychar = -1; }
#else
#define yyclearin	yychar = -1
#endif
#define YYACCEPT	YYRETURN(0)
#define YYABORT		YYRETURN(1)
#define YYRECOVERING()	(yyerrflag != 0)
#ifdef YYALLOC
#define YYRETURN(val)	{ retval = (val); goto yyReturn; }
#else
#define YYRETURN(val)	return(val);
#endif
#if YYDEBUG
/* The if..else makes this macro behave exactly like a statement */
# define YYREAD	if (yychar < 0) {					\
			if ((yychar = yylex()) < 0)	{		\
				if (yychar == -2) YYABORT; \
				yychar = 0;				\
			}	/* endif */			\
			if (yydebug)					\
				yyShowRead(yychar);			\
		} else
#else
# define YYREAD	if (yychar < 0) {					\
			if ((yychar = yylex()) < 0) {			\
				if (yychar == -2) YYABORT; \
				yychar = 0;				\
			}	/* endif */			\
		} else
#endif

#define YYERRCODE	256		/* value of `error' */
#define	YYQYYP	yyq[yyq-yyp]

YYSTYPE	yyval;				/* $ */
YYSTYPE	*yypvt;				/* $n */
YYSTYPE	yylval;				/* yylex() sets this */

int	yychar,				/* current token */
	yyerrflag,			/* error flag */
	yynerrs;			/* error count */

#if YYDEBUG
int yydebug = 0;		/* debug if this flag is set */
extern char	*yysvar[];	/* table of non-terminals (aka 'variables') */
extern yyNamedType yyTokenTypes[];	/* table of terminals & their types */
extern short	yyrmap[], yysmap[];	/* map internal rule/states */
extern int	yynstate, yynvar, yyntoken, yynrule;

extern int	yyGetType YY_ARGS((int));	/* token type */
extern char	*yyptok YY_ARGS((int));	/* printable token string */
extern int	yyExpandName YY_ARGS((int, int, char *, int));
				  /* expand yyRules[] or yyStates[] */
static char *	yygetState YY_ARGS((int));

#define yyassert(condition, msg, arg) \
	if (!(condition)) { \
		printf(m_textmsg(2824, "\nyacc bug: ", "E")); \
		printf(msg, arg); \
		YYABORT; }
#else /* !YYDEBUG */
#define yyassert(condition, msg, arg)
#endif

#line 315 "../Parser/cci.y"
/* USER SUBROUTINES */

//        Name: yyerror
// Description: Custom parser error handler
//  Parameters: Pointer to error string return by YACC
//     Returns: none
void yyerror(char* error)
{
	int dX;

	sprintf(g_pCCIResult->pError,"%s: '%s' (line %d)",error,yytext,yylineno);
	g_pCCIResult->dErrLine = yylineno;

	g_pCCIResult->dMsgNo = 0;
	g_pCCIResult->pWParam = NULL;
	g_pCCIResult->pLParam = NULL;
	g_pCCIResult->ccitWParam = -1;
	g_pCCIResult->ccitLParam = -1;

	// Clean up allocated memory that resulted from the imcomplete parse
	for(dX=0;dX<ALLOCMAX;dX++)
		if(g_pMemTrack[dX])
			free(g_pMemTrack[dX]);

	return;
}

//        Name: CCIInterpret
// Description: Interpreter entry point, returns result
//  Parameters: Input string
//     Returns: Pointer to CCIResult struct with result of parse
CCIResult* CCIInterpret(LPSTR p_pInput)
{
	int dX;

	// Create result structure
	g_pCCIResult = (CCIResult*)malloc(sizeof(CCIResult));

	// Initialize result structure
	g_pCCIResult->pInput = (LPSTR)malloc(strlen(p_pInput)+1);
	strcpy(g_pCCIResult->pInput,p_pInput);
	g_pCCIResult->pError = (LPSTR)malloc(ERRBUFSIZE);
	*(g_pCCIResult->pError) = '\0';
	g_pCCIResult->dErrLine = -1;

	g_pCCIResult->dMsgNo = 0;
	
	g_pCCIResult->pWParam = NULL;
	g_pCCIResult->pLParam = NULL;

	g_pCCIResult->ccitWParam = -1;
	g_pCCIResult->ccitLParam = -1;

	// Copy input to temporary file
	if((yyin = fopen(TEMPFILE,"w+b")) == NULL)
	{
		strcpy(g_pCCIResult->pError,"Could not create temporary file!");
		return g_pCCIResult;
	}
	fputs(p_pInput,yyin);
	rewind(yyin);

	// Initialize memory tracking for error recovery
	for(dX=0;dX<ALLOCMAX;dX++)
		g_pMemTrack[dX] = NULL;

	// Parse input
	yy_reset();
	yyparse();

	// CCIResult is now full
	fclose(yyin);
	remove(TEMPFILE);

	// Return
	return g_pCCIResult;
}

//        Name: CCIGetSignature
// Description: Get either template or description of signature item
//  Parameters: Type of information to return, item to query
//     Returns: Pointer to template or description string
LPSTR CCIGetSignature(BYTE p_dType,BYTE p_dItem)
{
	if(p_dItem == SIGTEMP)
		return g_pSignature[p_dType][0];
	else
		return g_pSignature[p_dType][1];
}

//        Name: CCIGetSignature
// Description: Convert parameter value to printable text format
//  Parameters: Type of parameter, actual value, buffer to write out to
//     Returns: none
void CCIRender(CCITYPE p_pCCIType,void* p_pValue,LPSTR p_pDisplay)
{
	CHAR szBuf[3][31];
	switch(p_pCCIType)
	{
		case NOV:
			strcpy(p_pDisplay,"No Value");
			break;

		case ERRV:
			sprintf(p_pDisplay,"%d (%s)",(INT)p_pValue,((INT)p_pValue<0)?"ERROR":"OK");
			break;

		case SUCCESSV:
			sprintf(p_pDisplay,"%d (%s)",(INT)p_pValue,((INT)p_pValue==0)?"FAIL":"SUCCESS");
			break;

		case BITMASKV:
		case NUMV:
			sprintf(p_pDisplay,"%d (0x%x)",(INT)p_pValue,(INT)p_pValue);
			break;

		case BOOLV:
			sprintf(p_pDisplay,"%s",p_pValue?"TRUE":"FALSE");
			break;

		case LPSTRV:
		case LPSTRVI:
			sprintf(p_pDisplay,"%s",(LPSTR)p_pValue);
			break;

		// >> Start control specific
		case RGBV:
			sprintf(p_pDisplay,"RGB(%d,%d,%d)",
				GetRValue((DWORD)p_pValue),
				GetGValue((DWORD)p_pValue),
				GetBValue((DWORD)p_pValue));

			if((INT)p_pValue == -1)
				strcat(p_pDisplay," (System color)");

			break;

		case LPRECTV:
			sprintf(p_pDisplay,"RECT(%d,%d,%d,%d)",
				((LPRECT)p_pValue)->left,
				((LPRECT)p_pValue)->top,
				((LPRECT)p_pValue)->right,
				((LPRECT)p_pValue)->bottom);
			break;

		case LPTVHTINFOVI:
		{
			int dFlags[] = { TVHT_ABOVE, TVHT_BELOW, TVHT_NOWHERE, TVHT_ONITEM, TVHT_ONITEMBUTTON, TVHT_ONITEMICON,
				TVHT_ONITEMINDENT, TVHT_ONITEMLABEL, TVHT_ONITEMRIGHT, TVHT_ONITEMSTATEICON, TVHT_TOLEFT, TVHT_TORIGHT };
			LPSTR szFlags[] = { "TVHT_ABOVE", "TVHT_BELOW", "TVHT_NOWHERE", "TVHT_ONITEM", "TVHT_ONITEMBUTTON", "TVHT_ONITEMICON",
				"TVHT_ONITEMINDENT", "TVHT_ONITEMLABEL", "TVHT_ONITEMRIGHT", "TVHT_ONITEMSTATEICON", "TVHT_TOLEFT", "TVHT_TORIGHT" };
			int dX;
			BOOL bFirst = TRUE;
			LPSTR pHeader;

			pHeader = (LPSTR)malloc(1024);

			sprintf(pHeader,"TVHITTESTINFO(POINT(%d,%d),",((LPTVHITTESTINFO)p_pValue)->pt.x,((LPTVHITTESTINFO)p_pValue)->pt.y);

			for(dX=0;dX<12;dX++)
				if(((LPTVHITTESTINFO)p_pValue)->flags&dFlags[dX])
				{
					if(!bFirst)
						strcat(pHeader,"|");
					else
						bFirst = FALSE;
					strcat(pHeader,szFlags[dX]);
				}
			
			sprintf(p_pDisplay,"%s,0x%x)",pHeader,((LPTVHITTESTINFO)p_pValue)->hItem);

			free(pHeader);
		}	
			break;

		case LPTVITEMEXVI:
			// Do conversions before display
			itoa(((LPTVITEMEX)p_pValue)->iImage,szBuf[0],10);
			itoa(((LPTVITEMEX)p_pValue)->iSelectedImage,szBuf[1],10);
			itoa(((LPTVITEMEX)p_pValue)->cChildren,szBuf[2],10);

			sprintf(p_pDisplay,"TVITEMEX(0x%x,0x%x,0x%x,0x%x,%s,%d,%s,%s,%s,%d,%d)",
				((LPTVITEMEX)p_pValue)->mask,
				((LPTVITEMEX)p_pValue)->hItem,
				((LPTVITEMEX)p_pValue)->state,
				((LPTVITEMEX)p_pValue)->stateMask,
				(((LPTVITEMEX)p_pValue)->pszText==LPSTR_TEXTCALLBACK)?"LPSTR_TEXTCALLBACK":((LPTVITEMEX)p_pValue)->pszText,
				((LPTVITEMEX)p_pValue)->cchTextMax,
				(((LPTVITEMEX)p_pValue)->iImage==I_IMAGECALLBACK)?"I_IMAGECALLBACK":szBuf[0],
				(((LPTVITEMEX)p_pValue)->iSelectedImage==I_IMAGECALLBACK)?"I_IMAGECALLBACK":szBuf[1],
				(((LPTVITEMEX)p_pValue)->cChildren==I_CHILDRENCALLBACK)?"I_CHILDRENCALLBACK":szBuf[2],
				((LPTVITEMEX)p_pValue)->lParam,
				((LPTVITEMEX)p_pValue)->iIntegral);
			break;

		case LPTVISVI:
			// Do conversions before display
			itoa(((LPTVINSERTSTRUCT)p_pValue)->itemex.iImage,szBuf[0],10);
			itoa(((LPTVINSERTSTRUCT)p_pValue)->itemex.iSelectedImage,szBuf[1],10);
			itoa(((LPTVINSERTSTRUCT)p_pValue)->itemex.cChildren,szBuf[2],10);

			sprintf(p_pDisplay,"TVINSERTSTRUCT(0x%x,0x%x,TVITEMEX(0x%x,0x%x,0x%x,0x%x,%s,%d,%s,%s,%s,%d,%d))",
				((LPTVINSERTSTRUCT)p_pValue)->hParent,
				((LPTVINSERTSTRUCT)p_pValue)->hInsertAfter,
				((LPTVINSERTSTRUCT)p_pValue)->itemex.mask,
				((LPTVINSERTSTRUCT)p_pValue)->itemex.hItem,
				((LPTVINSERTSTRUCT)p_pValue)->itemex.state,
				((LPTVINSERTSTRUCT)p_pValue)->itemex.stateMask,
				(((LPTVINSERTSTRUCT)p_pValue)->itemex.pszText==LPSTR_TEXTCALLBACK)?"LPSTR_TEXTCALLBACK":((LPTVINSERTSTRUCT)p_pValue)->itemex.pszText,
				((LPTVINSERTSTRUCT)p_pValue)->itemex.cchTextMax,
				(((LPTVINSERTSTRUCT)p_pValue)->itemex.iImage==I_IMAGECALLBACK)?"I_IMAGECALLBACK":szBuf[0],
				(((LPTVINSERTSTRUCT)p_pValue)->itemex.iSelectedImage==I_IMAGECALLBACK)?"I_IMAGECALLBACK":szBuf[1],
				(((LPTVINSERTSTRUCT)p_pValue)->itemex.cChildren==I_CHILDRENCALLBACK)?"I_CHILDRENCALLBACK":szBuf[2],
				((LPTVINSERTSTRUCT)p_pValue)->itemex.lParam,
				((LPTVINSERTSTRUCT)p_pValue)->itemex.iIntegral);
			break;

		case LPTVSORTCBVI:
			sprintf(p_pDisplay,"TVSORTCB(0x%x,0x%x,%d)",
				((LPTVSORTCB)p_pValue)->hParent,
				((LPTVSORTCB)p_pValue)->lpfnCompare,
				((LPTVSORTCB)p_pValue)->lParam);
			break;
		// End control specific <<

		default:
			*p_pDisplay = '\0';
			break;
	}
}

//        Name: CCIDestroy
// Description: Free memory allocated by a CCIResult structure
//  Parameters: Pointer to CCIResult structure
//     Returns: none
void CCIDestroy(CCIResult* p_pCCIResult)
{
	// Free input and error buffer
	if(p_pCCIResult->pInput)
		free(p_pCCIResult->pInput);
	if(p_pCCIResult->pError)
		free(p_pCCIResult->pError);

	// Remove wParam
	CCIDestroyHelper(p_pCCIResult->ccitWParam,p_pCCIResult->pWParam);	
	// Remove lParam
	CCIDestroyHelper(p_pCCIResult->ccitLParam,p_pCCIResult->pLParam);

	// Remove structure
	free(p_pCCIResult);
}

//        Name: CCIDestroyHelper
// Description: CCIDestory second level helper
//  Parameters: Type of parameter, data to free
//     Returns: none
void CCIDestroyHelper(CCITYPE p_pCCIType,void* p_pValue)
{
	switch(p_pCCIType)
	{
		// No storage
		case NUMV:
		case BOOLV:
		case RGBV:
			break;

		// >> Start control specific
		// Multiple level storage (wParam/lParam values whose members point to memory)
		case LPTVITEMEXVI:
			if(((LPTVITEMEX)p_pValue)->pszText && ((LPTVITEMEX)p_pValue)->pszText != LPSTR_TEXTCALLBACK)
				free(((LPTVITEMEX)p_pValue)->pszText);

		case LPTVISVI:
			if(p_pCCIType == LPTVISVI)
				if(((LPTVINSERTSTRUCT)p_pValue)->itemex.pszText && ((LPTVINSERTSTRUCT)p_pValue)->itemex.pszText != LPSTR_TEXTCALLBACK)
					free(((LPTVINSERTSTRUCT)p_pValue)->itemex.pszText);

		// Fall through
		
		// Single level storage (wParam/lParam that point to memory)
		default:
			if(p_pValue)
				free(p_pValue);
		// End control specific <<
	}
}

//        Name: CCIMemTrack
// Description: Track all memory during parsing in the event of an error so that memory
//				can be freed
//  Parameters: Pointer to allocated memory
//     Returns: none
void CCIMemTrack(void* p_pMem)
{
	int dX;
	BOOL bFoundSlot = FALSE;

	for(dX=0;dX<ALLOCMAX;dX++)
	{
		if(!g_pMemTrack[dX])
		{
			bFoundSlot = TRUE;
			g_pMemTrack[dX] = p_pMem;
			break;
		}
	}

	if(!bFoundSlot)
		OutputDebugString("Allocation track overflow!\n");
}


#ifdef YACC_WINDOWS

/*
 * the following is the yyparse() function that will be
 * callable by a windows type program. It in turn will
 * load all needed resources, obtain pointers to these
 * resources, and call a statically defined function
 * win_yyparse(), which is the original yyparse() fn
 * When win_yyparse() is complete, it will return a
 * value to the new yyparse(), where it will be stored
 * away temporarily, all resources will be freed, and
 * that return value will be given back to the caller
 * yyparse(), as expected.
 */

static int win_yyparse();			/* prototype */

yyparse() 
{
	int wReturnValue;
	HANDLE hRes_table;		/* handle of resource after loading */
	short *old_yydef;		/* the following are used for saving */
	short *old_yyex;		/* the current pointers */
	short *old_yyact;
	short *old_yypact;
	short *old_yygo;
	short *old_yypgo;
	short *old_yyrlen;

	/*
	 * the following code will load the required
	 * resources for a Windows based parser.
	 */

	hRes_table = LoadResource (hInst, 
		FindResource (hInst, "UD_RES_yyYACC", "yyYACCTBL"));
	
	/*
	 * return an error code if any
	 * of the resources did not load
	 */

	if (hRes_table == NULL)
		return (1);
	
	/*
	 * the following code will lock the resources
	 * into fixed memory locations for the parser
	 * (also, save the current pointer values first)
	 */

	old_yydef = yydef;
	old_yyex = yyex;
	old_yyact = yyact;
	old_yypact = yypact;
	old_yygo = yygo;
	old_yypgo = yypgo;
	old_yyrlen = yyrlen;

	yydef = (short *)LockResource (hRes_table);
	yyex = (short *)(yydef + Sizeof_yydef);
	yyact = (short *)(yyex + Sizeof_yyex);
	yypact = (short *)(yyact + Sizeof_yyact);
	yygo = (short *)(yypact + Sizeof_yypact);
	yypgo = (short *)(yygo + Sizeof_yygo);
	yyrlen = (short *)(yypgo + Sizeof_yypgo);

	/*
	 * call the official yyparse() function
	 */

	wReturnValue = win_yyparse();

	/*
	 * unlock the resources
	 */

	UnlockResource (hRes_table);

	/*
	 * and now free the resource
	 */

	FreeResource (hRes_table);

	/*
	 * restore previous pointer values
	 */

	yydef = old_yydef;
	yyex = old_yyex;
	yyact = old_yyact;
	yypact = old_yypact;
	yygo = old_yygo;
	yypgo = old_yypgo;
	yyrlen = old_yyrlen;

	return (wReturnValue);
}	/* end yyparse */

static int win_yyparse() 

#else /* YACC_WINDOWS */

/*
 * we are not compiling a windows resource
 * based parser, so call yyparse() the old
 * standard way.
 */

yyparse() 

#endif /* YACC_WINDOWS */

{
	register short		yyi, *yyp;	/* for table lookup */
	register short		*yyps;		/* top of state stack */
	register short		yystate;	/* current state */
	register YYSTYPE	*yypv;		/* top of value stack */
	register short		*yyq;
	register int		yyj;
#if YYDEBUG
	yyTraceItems	yyx;			/* trace block */
	short	* yytp;
	int	yyruletype = 0;
#endif
#ifdef YYSTATIC
	static short	yys[YYSSIZE + 1];
	static YYSTYPE	yyv[YYSSIZE + 1];
#if YYDEBUG
	static short	yytypev[YYSSIZE+1];	/* type assignments */
#endif
#else /* ! YYSTATIC */
#ifdef YYALLOC
	YYSTYPE *yyv;
	short	*yys;
#if YYDEBUG
	short	*yytypev;
#endif
	YYSTYPE save_yylval;
	YYSTYPE save_yyval;
	YYSTYPE *save_yypvt;
	int save_yychar, save_yyerrflag, save_yynerrs;
	int retval; 			/* return value holder */
#else
	short		yys[YYSSIZE + 1];
	static YYSTYPE	yyv[YYSSIZE + 1];	/* historically static */
#if YYDEBUG
	short	yytypev[YYSSIZE+1];		/* mirror type table */
#endif
#endif /* ! YYALLOC */
#endif /* ! YYSTATIC */
#ifdef YYDYNAMIC
	char *envp;
#endif


#ifdef YYDYNAMIC
	if ((envp = getenv("YYSTACKSIZE")) != (char *)0) {
		yyssize = atoi(envp);
		if (yyssize <= 0)
			yyssize = YYSSIZE;
	}
	if ((envp = getenv("YYSTACKINC")) != (char *)0)
		yysinc = atoi(envp);
#endif
#ifdef YYALLOC
	yys = (short *) malloc((yyssize + 1) * sizeof(short));
	yyv = (YYSTYPE *) malloc((yyssize + 1) * sizeof(YYSTYPE));
#if YYDEBUG
	yytypev = (short *) malloc((yyssize + 1) * sizeof(short));
#endif
	if (yys == (short *)0 || yyv == (YYSTYPE *)0
#if YYDEBUG
		|| yytypev == (short *) 0
#endif
	) {
		yyerror("Not enough space for parser stacks");
		return 1;
	}
	save_yylval = yylval;
	save_yyval = yyval;
	save_yypvt = yypvt;
	save_yychar = yychar;
	save_yyerrflag = yyerrflag;
	save_yynerrs = yynerrs;
#endif

	yynerrs = 0;
	yyerrflag = 0;
	yyclearin;
	yyps = yys;
	yypv = yyv;
	*yyps = yystate = YYS0;		/* start state */
#if YYDEBUG
	yytp = yytypev;
	yyi = yyj = 0;			/* silence compiler warnings */
#endif

yyStack:
	yyassert((unsigned)yystate < yynstate, m_textmsg(587, "state %d\n", ""), yystate);
#ifdef YYDYNAMIC
	if (++yyps > &yys[yyssize]) {
		int yynewsize;
		int yysindex = yyps - yys;
		int yyvindex = yypv - yyv;
#if YYDEBUG
		int yytindex = yytp - yytypev;
#endif
		if (yysinc == 0) {		/* no increment */
			yyerror("Parser stack overflow");
			YYABORT;
		} else if (yysinc < 0)		/* binary-exponential */
			yynewsize = yyssize * 2;
		else				/* fixed increment */
			yynewsize = yyssize + yysinc;
		if (yynewsize < yyssize) {
			yyerror("Not enough space for parser stacks");
			YYABORT;
		}
		yyssize = yynewsize;
		yys = (short *) realloc(yys, (yyssize + 1) * sizeof(short));
		yyps = yys + yysindex;
		yyv = (YYSTYPE *) realloc(yyv, (yyssize + 1) * sizeof(YYSTYPE));
		yypv = yyv + yyvindex;
#if YYDEBUG
		yytypev = (short *)realloc(yytypev,(yyssize + 1)*sizeof(short));
		yytp = yytypev + yytindex;
#endif
		if (yys == (short *)0 || yyv == (YYSTYPE *)0
#if YYDEBUG
			|| yytypev == (short *) 0
#endif
		) {
			yyerror("Not enough space for parser stacks");
			YYABORT;
		}
	}
#else
	if (++yyps > &yys[YYSSIZE]) {
		yyerror("Parser stack overflow");
		YYABORT;
	}
#endif /* !YYDYNAMIC */
	*yyps = yystate;	/* stack current state */
	*++yypv = yyval;	/* ... and value */
#if YYDEBUG
	*++yytp = yyruletype;	/* ... and type */

	if (yydebug)
		YY_TRACE(yyShowState)
#endif

	/*
	 *	Look up next action in action table.
	 */
yyEncore:
#ifdef YYSYNC
	YYREAD;
#endif

#ifdef YACC_WINDOWS
	if (yystate >= Sizeof_yypact) 	/* simple state */
#else /* YACC_WINDOWS */
	if (yystate >= sizeof yypact/sizeof yypact[0]) 	/* simple state */
#endif /* YACC_WINDOWS */
		yyi = yystate - YYDELTA;	/* reduce in any case */
	else {
		if(*(yyp = &yyact[yypact[yystate]]) >= 0) {
			/* Look for a shift on yychar */
#ifndef YYSYNC
			YYREAD;
#endif
			yyq = yyp;
			yyi = yychar;
			while (yyi < *yyp++)
				;
			if (yyi == yyp[-1]) {
				yystate = ~YYQYYP;
#if YYDEBUG
				if (yydebug) {
					yyruletype = yyGetType(yychar);
					YY_TRACE(yyShowShift)
				}
#endif
				yyval = yylval;	/* stack what yylex() set */
				yyclearin;		/* clear token */
				if (yyerrflag)
					yyerrflag--;	/* successful shift */
				goto yyStack;
			}
		}

		/*
	 	 *	Fell through - take default action
	 	 */

#ifdef YACC_WINDOWS
		if (yystate >= Sizeof_yydef)
#else /* YACC_WINDOWS */
		if (yystate >= sizeof yydef /sizeof yydef[0])
#endif /* YACC_WINDOWS */
			goto yyError;
		if ((yyi = yydef[yystate]) < 0)	 { /* default == reduce? */
			/* Search exception table */
#ifdef YACC_WINDOWS
			yyassert((unsigned)~yyi < Sizeof_yyex,
				m_textmsg(2825, "exception %d\n", "I num"), yystate);
#else /* YACC_WINDOWS */
			yyassert((unsigned)~yyi < sizeof yyex/sizeof yyex[0],
				m_textmsg(2825, "exception %d\n", "I num"), yystate);
#endif /* YACC_WINDOWS */
			yyp = &yyex[~yyi];
#ifndef YYSYNC
			YYREAD;
#endif
			while((yyi = *yyp) >= 0 && yyi != yychar)
				yyp += 2;
			yyi = yyp[1];
			yyassert(yyi >= 0,
				 m_textmsg(2826, "Ex table not reduce %d\n", "I num"), yyi);
		}
	}

	yyassert((unsigned)yyi < yynrule, m_textmsg(2827, "reduce %d\n", "I num"), yyi);
	yyj = yyrlen[yyi];
#if YYDEBUG
	if (yydebug)
		YY_TRACE(yyShowReduce)
	yytp -= yyj;
#endif
	yyps -= yyj;		/* pop stacks */
	yypvt = yypv;		/* save top */
	yypv -= yyj;
	yyval = yypv[1];	/* default action $ = $1 */
#if YYDEBUG
	yyruletype = yyRules[yyrmap[yyi]].type;
#endif

	switch (yyi) {		/* perform semantic action */
		
case YYr3: {	/* message :  YMSG '(' YMSGID ',' parameter ',' parameter ')' */
#line 107 "../Parser/cci.y"

			g_pCCIResult->dMsgNo = yypvt[-5].intVal;
			g_pCCIResult->ccitWParam = yypvt[-3].tvVal.cciType;
			g_pCCIResult->pWParam = yypvt[-3].tvVal.cciValue;
			g_pCCIResult->ccitLParam = yypvt[-1].tvVal.cciType;
			g_pCCIResult->pLParam = yypvt[-1].tvVal.cciValue;
		
} break;

case YYr4: {	/* parameter :  YNULL */
#line 117 "../Parser/cci.y"

			yyval.tvVal.cciType = NUMV;
			yyval.tvVal.cciValue = (void*)yypvt[0].intVal; 
		
} break;

case YYr5: {	/* parameter :  intbmval */
#line 122 "../Parser/cci.y"
 
			yyval.tvVal.cciType = NUMV;
			yyval.tvVal.cciValue = (void*)yypvt[0].intVal; 
		
} break;

case YYr6: {	/* parameter :  YBOOL */
#line 127 "../Parser/cci.y"
 
			yyval.tvVal.cciType = BOOLV;
			yyval.tvVal.cciValue = (void*)yypvt[0].intVal; 
		
} break;

case YYr7: {	/* parameter :  YSTRBUF */
#line 132 "../Parser/cci.y"

			yyval.tvVal.cciType = LPSTRV;
			yyval.tvVal.cciValue = (void*)malloc(STRBUFSIZE);
			CCIMemTrack(yyval.tvVal.cciValue);
			ZeroMemory(yyval.tvVal.cciValue,STRBUFSIZE);
		
} break;

case YYr8: {	/* parameter :  YSTR */
#line 139 "../Parser/cci.y"

			yyval.tvVal.cciType = LPSTRVI;
			yyval.tvVal.cciValue = (void*)malloc(strlen(yypvt[0].szVal)+1);
			CCIMemTrack(yyval.tvVal.cciValue);
			strcpy((LPSTR)(yyval.tvVal.cciValue),yypvt[0].szVal);
		
} break;

case YYr9: {	/* parameter :  YRGB '(' YINT ',' YINT ',' YINT ')' */
#line 148 "../Parser/cci.y"

			yyval.tvVal.cciType = RGBV;
			yyval.tvVal.cciValue = (void*)RGB(yypvt[-5].intVal,yypvt[-3].intVal,yypvt[-1].intVal);
		
} break;

case YYr10: {	/* parameter :  YRECT */
#line 153 "../Parser/cci.y"

			yyval.tvVal.cciType = LPRECTV;
			yyval.tvVal.cciValue = malloc(sizeof(RECT));
			CCIMemTrack(yyval.tvVal.cciValue);
			ZeroMemory(yyval.tvVal.cciValue,sizeof(RECT));
		
} break;

case YYr11: {	/* parameter :  YRECT '(' YINT ')' */
#line 160 "../Parser/cci.y"

			yyval.tvVal.cciType = LPRECTV;
			yyval.tvVal.cciValue = malloc(sizeof(RECT));
			CCIMemTrack(yyval.tvVal.cciValue);
			ZeroMemory(yyval.tvVal.cciValue,sizeof(RECT));

			*((HTREEITEM*)yyval.tvVal.cciValue) = (HTREEITEM)yypvt[-1].intVal;
		
} break;

case YYr12: {	/* parameter :  YTVHTINFO '(' YINT ',' YINT ')' */
#line 169 "../Parser/cci.y"

			yyval.tvVal.cciType = LPTVHTINFOVI;
			yyval.tvVal.cciValue = malloc(sizeof(TVHITTESTINFO));
			CCIMemTrack(yyval.tvVal.cciValue);
			ZeroMemory(yyval.tvVal.cciValue,sizeof(TVHITTESTINFO));
			
			((LPTVHITTESTINFO)yyval.tvVal.cciValue)->pt.x = yypvt[-3].intVal;
			((LPTVHITTESTINFO)yyval.tvVal.cciValue)->pt.y = yypvt[-1].intVal;
		
} break;

case YYr13: {	/* parameter :  YTVITEMEX '(' intbmval ',' YINT ',' stateshift ',' intbmval ',' YSTR ',' YINT ',' YINT ',' YINT ',' YINT ',' YINT ',' YINT ')' */
#line 179 "../Parser/cci.y"

			yyval.tvVal.cciType = LPTVITEMEXVI;
			yyval.tvVal.cciValue = malloc(sizeof(TVITEMEX));
			CCIMemTrack(yyval.tvVal.cciValue);
			ZeroMemory(yyval.tvVal.cciValue,sizeof(TVITEMEX));
			((LPTVITEMEX)yyval.tvVal.cciValue)->mask = yypvt[-21].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->hItem = (HTREEITEM)yypvt[-19].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->state = yypvt[-17].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->stateMask = yypvt[-15].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->pszText = (LPSTR)malloc(STRBUFSIZE);
			CCIMemTrack(((LPTVITEMEX)yyval.tvVal.cciValue)->pszText);
			strcpy(((LPTVITEMEX)yyval.tvVal.cciValue)->pszText,yypvt[-13].szVal);
			((LPTVITEMEX)yyval.tvVal.cciValue)->cchTextMax = yypvt[-11].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->iImage = yypvt[-9].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->iSelectedImage = yypvt[-7].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->cChildren = yypvt[-5].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->lParam = yypvt[-3].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->iIntegral = yypvt[-1].intVal;
		
} break;

case YYr14: {	/* parameter :  YTVITEMEX '(' intbmval ',' YINT ',' stateshift ',' intbmval ',' YLPTCBK ',' YINT ',' YINT ',' YINT ',' YINT ',' YINT ',' YINT ')' */
#line 199 "../Parser/cci.y"

			yyval.tvVal.cciType = LPTVITEMEXVI;
			yyval.tvVal.cciValue = malloc(sizeof(TVITEMEX));
			CCIMemTrack(yyval.tvVal.cciValue);
			((LPTVITEMEX)yyval.tvVal.cciValue)->mask = yypvt[-21].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->hItem = (HTREEITEM)yypvt[-19].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->state = yypvt[-17].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->stateMask = yypvt[-15].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->pszText = (LPSTR)yypvt[-13].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->cchTextMax = yypvt[-11].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->iImage = yypvt[-9].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->iSelectedImage = yypvt[-7].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->cChildren = yypvt[-5].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->lParam = yypvt[-3].intVal;
			((LPTVITEMEX)yyval.tvVal.cciValue)->iIntegral = yypvt[-1].intVal;
		
} break;

case YYr15: {	/* parameter :  YTVIS '(' YINT ',' YINT ',' YTVITEMEX '(' intbmval ',' YINT ',' stateshift ',' intbmval ',' YSTR ',' YINT ',' YINT ',' YINT ',' YINT ',' YINT ',' YINT ')' ')' */
#line 216 "../Parser/cci.y"

			yyval.tvVal.cciType = LPTVISVI;
			yyval.tvVal.cciValue = malloc(sizeof(TVINSERTSTRUCT));
			CCIMemTrack(yyval.tvVal.cciValue);
			ZeroMemory(yyval.tvVal.cciValue,sizeof(TVINSERTSTRUCT));

			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->hParent = (HTREEITEM)yypvt[-28].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->hInsertAfter = (HTREEITEM)yypvt[-26].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.mask = yypvt[-22].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.hItem = (HTREEITEM)yypvt[-20].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.state = yypvt[-18].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.stateMask = yypvt[-16].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.pszText = (LPSTR)malloc(STRBUFSIZE);
			CCIMemTrack(((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.pszText);
			strcpy(((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.pszText,yypvt[-14].szVal);
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.cchTextMax = yypvt[-12].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.iImage = yypvt[-10].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.iSelectedImage = yypvt[-8].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.cChildren = yypvt[-6].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.lParam = yypvt[-4].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.iIntegral = yypvt[-2].intVal;
		
} break;

case YYr16: {	/* parameter :  YTVIS '(' YINT ',' YINT ',' YTVITEMEX '(' intbmval ',' YINT ',' stateshift ',' intbmval ',' YLPTCBK ',' YINT ',' YINT ',' YINT ',' YINT ',' YINT ',' YINT ')' ')' */
#line 239 "../Parser/cci.y"

			yyval.tvVal.cciType = LPTVISVI;
			yyval.tvVal.cciValue = malloc(sizeof(TVINSERTSTRUCT));
			CCIMemTrack(yyval.tvVal.cciValue);

			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->hParent = (HTREEITEM)yypvt[-28].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->hInsertAfter = (HTREEITEM)yypvt[-26].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.mask = yypvt[-22].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.hItem = (HTREEITEM)yypvt[-20].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.state = yypvt[-18].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.stateMask = yypvt[-16].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.pszText = (LPSTR)yypvt[-14].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.cchTextMax = yypvt[-12].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.iImage = yypvt[-10].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.iSelectedImage = yypvt[-8].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.cChildren = yypvt[-6].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.lParam = yypvt[-4].intVal;
			((LPTVINSERTSTRUCT)yyval.tvVal.cciValue)->itemex.iIntegral = yypvt[-2].intVal;
		
} break;

case YYr17: {	/* parameter :  YTVSORTCB '(' YINT ',' YINT ',' YINT ')' */
#line 259 "../Parser/cci.y"

			yyval.tvVal.cciType = LPTVSORTCBVI;
			yyval.tvVal.cciValue = malloc(sizeof(TVSORTCB));
			CCIMemTrack(yyval.tvVal.cciValue);
			ZeroMemory(yyval.tvVal.cciValue,sizeof(TVSORTCB));

			((LPTVSORTCB)yyval.tvVal.cciValue)->hParent = (HTREEITEM)yypvt[-5].intVal;
			((LPTVSORTCB)yyval.tvVal.cciValue)->lpfnCompare = (PFNTVCOMPARE)yypvt[-3].intVal;
			((LPTVSORTCB)yyval.tvVal.cciValue)->lParam = yypvt[-1].intVal;
		
} break;

case YYr18: {	/* stateshift :  intbmval '/' intbmval '/' intbmval */
#line 272 "../Parser/cci.y"

			yyval.intVal = yypvt[-4].intVal + INDEXTOOVERLAYMASK(yypvt[-2].intVal) + INDEXTOSTATEIMAGEMASK(yypvt[0].intVal);
		
} break;

case YYr19: {	/* style :  YSTYLE '(' intbmval ',' intbmval ',' intbmval ',' intbmval ',' applystyle ')' */
#line 281 "../Parser/cci.y"

			g_pCCIResult->ccitWParam = STYLEV;
			g_pCCIResult->pWParam = (void*)malloc(sizeof(CCIStyle));
			CCIMemTrack(g_pCCIResult->pWParam);
			((CCIStyle*)g_pCCIResult->pWParam)->dStyleOn = yypvt[-9].intVal;	// Styles on
			((CCIStyle*)g_pCCIResult->pWParam)->dStyleOff = yypvt[-7].intVal;	// Styles off
			((CCIStyle*)g_pCCIResult->pWParam)->dExStyleOn = yypvt[-5].intVal; // Exstyles on
			((CCIStyle*)g_pCCIResult->pWParam)->dExStyleOff = yypvt[-3].intVal; // Exstyles off
			((CCIStyle*)g_pCCIResult->pWParam)->bRecreate = yypvt[-1].intVal; // Recreate or SetWindowLong
		
} break;

case YYr20: {	/* applystyle :  YSETWINLONG */
#line 296 "../Parser/cci.y"

			yyval.intVal = FALSE;
		
} break;

case YYr21: {	/* applystyle :  YRECREATE */
#line 301 "../Parser/cci.y"

			yyval.intVal = TRUE;
		
} break;

case YYr22: {	/* intbmval :  intbmval '|' YINT */
#line 307 "../Parser/cci.y"

			yyval.intVal = yyval.intVal | yypvt[0].intVal;
		
} break;
#line 314 "/progra~1/mks/etc/yyparse.c"
	case YYrACCEPT:
		YYACCEPT;
	case YYrERROR:
		goto yyError;
	}

	/*
	 *	Look up next state in goto table.
	 */

	yyp = &yygo[yypgo[yyi]];
	yyq = yyp++;
	yyi = *yyps;
	while (yyi < *yyp++)
		;

	yystate = ~(yyi == *--yyp? YYQYYP: *yyq);
#if YYDEBUG
	if (yydebug)
		YY_TRACE(yyShowGoto)
#endif
	goto yyStack;

yyerrlabel:	;		/* come here from YYERROR	*/
/*
#pragma used yyerrlabel
 */
	yyerrflag = 1;
	if (yyi == YYrERROR) {
		yyps--;
		yypv--;
#if YYDEBUG
		yytp--;
#endif
	}

yyError:
	switch (yyerrflag) {

	case 0:		/* new error */
		yynerrs++;
		yyi = yychar;
		yyerror("Syntax error");
		if (yyi != yychar) {
			/* user has changed the current token */
			/* try again */
			yyerrflag++;	/* avoid loops */
			goto yyEncore;
		}

	case 1:		/* partially recovered */
	case 2:
		yyerrflag = 3;	/* need 3 valid shifts to recover */
			
		/*
		 *	Pop states, looking for a
		 *	shift on `error'.
		 */

		for ( ; yyps > yys; yyps--, yypv--
#if YYDEBUG
					, yytp--
#endif
		) {
#ifdef YACC_WINDOWS
			if (*yyps >= Sizeof_yypact)
#else /* YACC_WINDOWS */
			if (*yyps >= sizeof yypact/sizeof yypact[0])
#endif /* YACC_WINDOWS */
				continue;
			yyp = &yyact[yypact[*yyps]];
			yyq = yyp;
			do
				;
			while (YYERRCODE < *yyp++);

			if (YYERRCODE == yyp[-1]) {
				yystate = ~YYQYYP;
				goto yyStack;
			}
				
			/* no shift in this state */
#if YYDEBUG
			if (yydebug && yyps > yys+1)
				YY_TRACE(yyShowErrRecovery)
#endif
			/* pop stacks; try again */
		}
		/* no shift on error - abort */
		break;

	case 3:
		/*
		 *	Erroneous token after
		 *	an error - discard it.
		 */

		if (yychar == 0)  /* but not EOF */
			break;
#if YYDEBUG
		if (yydebug)
			YY_TRACE(yyShowErrDiscard)
#endif
		yyclearin;
		goto yyEncore;	/* try again in same state */
	}
	YYABORT;

#ifdef YYALLOC
yyReturn:
	yylval = save_yylval;
	yyval = save_yyval;
	yypvt = save_yypvt;
	yychar = save_yychar;
	yyerrflag = save_yyerrflag;
	yynerrs = save_yynerrs;
	free((char *)yys);
	free((char *)yyv);
#if YYDEBUG
	free((char *)yytypev);
#endif
	return(retval);
#endif
}

		
#if YYDEBUG
/*
 * Return type of token
 */
int
yyGetType(tok)
int tok;
{
	yyNamedType * tp;
	for (tp = &yyTokenTypes[yyntoken-1]; tp > yyTokenTypes; tp--)
		if (tp->token == tok)
			return tp->type;
	return 0;
}
/*
 * Print a token legibly.
 */
char *
yyptok(tok)
int tok;
{
	yyNamedType * tp;
	for (tp = &yyTokenTypes[yyntoken-1]; tp > yyTokenTypes; tp--)
		if (tp->token == tok)
			return tp->name;
	return "";
}

/*
 * Read state 'num' from YYStatesFile
 */
#ifdef YYTRACE

static char *
yygetState(num)
int num;
{
	int	size;
	static FILE *yyStatesFile = (FILE *) 0;
	static char yyReadBuf[YYMAX_READ+1];

	if (yyStatesFile == (FILE *) 0
	 && (yyStatesFile = fopen(YYStatesFile, "r")) == (FILE *) 0)
		return "yyExpandName: cannot open states file";

	if (num < yynstate - 1)
		size = (int)(yyStates[num+1] - yyStates[num]);
	else {
		/* length of last item is length of file - ptr(last-1) */
		if (fseek(yyStatesFile, 0L, 2) < 0)
			goto cannot_seek;
		size = (int) (ftell(yyStatesFile) - yyStates[num]);
	}
	if (size < 0 || size > YYMAX_READ)
		return "yyExpandName: bad read size";
	if (fseek(yyStatesFile, yyStates[num], 0) < 0) {
	cannot_seek:
		return "yyExpandName: cannot seek in states file";
	}

	(void) fread(yyReadBuf, 1, size, yyStatesFile);
	yyReadBuf[size] = '\0';
	return yyReadBuf;
}
#endif /* YYTRACE */
/*
 * Expand encoded string into printable representation
 * Used to decode yyStates and yyRules strings.
 * If the expansion of 's' fits in 'buf', return 1; otherwise, 0.
 */
int
yyExpandName(num, isrule, buf, len)
int num, isrule;
char * buf;
int len;
{
	int	i, n, cnt, type;
	char	* endp, * cp;
	char	*s;

	if (isrule)
		s = yyRules[num].name;
	else
#ifdef YYTRACE
		s = yygetState(num);
#else
		s = "*no states*";
#endif

	for (endp = buf + len - 8; *s; s++) {
		if (buf >= endp) {		/* too large: return 0 */
		full:	(void) strcpy(buf, " ...\n");
			return 0;
		} else if (*s == '%') {		/* nonterminal */
			type = 0;
			cnt = yynvar;
			goto getN;
		} else if (*s == '&') {		/* terminal */
			type = 1;
			cnt = yyntoken;
		getN:
			if (cnt < 100)
				i = 2;
			else if (cnt < 1000)
				i = 3;
			else
				i = 4;
			for (n = 0; i-- > 0; )
				n = (n * 10) + *++s - '0';
			if (type == 0) {
				if (n >= yynvar)
					goto too_big;
				cp = yysvar[n];
			} else if (n >= yyntoken) {
			    too_big:
				cp = "<range err>";
			} else
				cp = yyTokenTypes[n].name;

			if ((i = strlen(cp)) + buf > endp)
				goto full;
			(void) strcpy(buf, cp);
			buf += i;
		} else
			*buf++ = *s;
	}
	*buf = '\0';
	return 1;
}
#ifndef YYTRACE
/*
 * Show current state of yyparse
 */
void
yyShowState(tp)
yyTraceItems * tp;
{
	short * p;
	YYSTYPE * q;

	printf(
	    m_textmsg(2828, "state %d (%d), char %s (%d)\n", "I num1 num2 char num3"),
	      yysmap[tp->state], tp->state,
	      yyptok(tp->lookahead), tp->lookahead);
}
/*
 * show results of reduction
 */
void
yyShowReduce(tp)
yyTraceItems * tp;
{
	printf("reduce %d (%d), pops %d (%d)\n",
		yyrmap[tp->rule], tp->rule,
		tp->states[tp->nstates - tp->npop],
		yysmap[tp->states[tp->nstates - tp->npop]]);
}
void
yyShowRead(val)
int val;
{
	printf(m_textmsg(2829, "read %s (%d)\n", "I token num"), yyptok(val), val);
}
void
yyShowGoto(tp)
yyTraceItems * tp;
{
	printf(m_textmsg(2830, "goto %d (%d)\n", "I num1 num2"), yysmap[tp->state], tp->state);
}
void
yyShowShift(tp)
yyTraceItems * tp;
{
	printf(m_textmsg(2831, "shift %d (%d)\n", "I num1 num2"), yysmap[tp->state], tp->state);
}
void
yyShowErrRecovery(tp)
yyTraceItems * tp;
{
	short	* top = tp->states + tp->nstates - 1;

	printf(
	m_textmsg(2832, "Error recovery pops state %d (%d), uncovers %d (%d)\n", "I num1 num2 num3 num4"),
		yysmap[*top], *top, yysmap[*(top-1)], *(top-1));
}
void
yyShowErrDiscard(tp)
yyTraceItems * tp;
{
	printf(m_textmsg(2833, "Error recovery discards %s (%d), ", "I token num"),
		yyptok(tp->lookahead), tp->lookahead);
}
#endif	/* ! YYTRACE */
#endif	/* YYDEBUG */
