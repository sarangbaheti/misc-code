typedef union {
	INT intVal;
	CHAR szVal[STRBUFSIZE];
	CCITypeVal tvVal;
} YYSTYPE;
#define YUNKNOWN	257
#define YMSG	258
#define YSTYLE	259
#define YSETWINLONG	260
#define YRECREATE	261
#define YMSGID	262
#define YINT	263
#define YBOOL	264
#define YNULL	265
#define YSTR	266
#define YSTRBUF	267
#define YMAKELONG	268
#define YMAKEWPARAM	269
#define YMAKELPARAM	270
#define YRGB	271
#define YRECT	272
#define YSIZE	273
#define YPOINT	274
#define YINTBUF	275
#define YTBINSERTMARK	276
#define YCOLORSCHEME	277
#define YTBB	278
#define YTBBI	279
#define YTBSAVEPARAMS	280
#define YTBADDBITMAP	281
#define YTBREPLACEBITMAP	282
extern YYSTYPE yylval;
