/* \program files\mks\mksnt\yacc -d -o ../Parser/ytab.c -D ../Parser/ytab.h -P /progra~1/mks/etc/yyparse.c ../Parser/cci.y */
#ifdef YYTRACE
#define YYDEBUG 1
#else
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#endif
/*
 * Portable way of defining ANSI C prototypes
 */
#ifndef YY_ARGS
#if __STDC__
#define YY_ARGS(x)	x
#else
#define YY_ARGS(x)	()
#endif
#endif

#ifdef YACC_WINDOWS

#include <windows.h>

/*
 * the following is the handle to the current
 * instance of a windows program. The user
 * program calling yyparse must supply this!
 */

extern HANDLE hInst;	

#endif	/* YACC_WINDOWS */

#if YYDEBUG
typedef struct yyNamedType_tag {	/* Tokens */
	char	* name;		/* printable name */
	short	token;		/* token # */
	short	type;		/* token type */
} yyNamedType;
typedef struct yyTypedRules_tag {	/* Typed rule table */
	char	* name;		/* compressed rule string */
	short	type;		/* rule result type */
} yyTypedRules;

#endif

#line 16 "../Parser/cci.y"

// Included files
#include <windows.h>
#include <stdio.h>
#include <commctrl.h>
#include "cci.h"

// Function prototypes
void yyerror(char* error);
void yy_reset(void);
int yyparse(void);

// Global variables
extern char yytext[];
extern int yylineno;
extern FILE *yyin;

CCIResult* g_pCCIResult;
LPSTR g_pSignature[][2] = { { "0", "No value" },
							{ "0", "Numeric value (<0 is ERROR, otherwise OK)" },
							{ "0", "Numeric value (non-zero is SUCCESS, otherwise ERROR)" },
							{ "0", "Bitmasked value" },
							{ "0", "Numeric decimal value" },
							{ "TRUE", "Boolean value (TRUE or FALSE)" },
							{ "buffer", "Pointer to string buffer (use 'buffer', max 127 chars)" },
							{ "\"string\"", "Pointer to initialized string (imbedded quotes not allowed)" },
							// >> Start control specific
							{ "tbbsize", "Size of TBBUTTON structure (use 'tbbsize')" },
							{ "0", "Bitmap flag value" },
							{ "instance", "Handle to application instance (use 'instance')" },
							{ "0", "Double word value packed value" },
							{ "MAKELONG(0,0)", "Numeric value (use 'MAKELONG(<val>,<val>)')" },
							{ "MAKEWPARAM(0,0)", "Numeric value (use 'MAKEWPARAM(<val>,<val>)')" },
							{ "MAKELPARAM(0,0)", "Numeric value (use 'MAKELPARAM(<val>,<val>)')" },
							{ "imagelist", "Handle to image list (use 'imagelist')" },
							{ "DisabledIL", "Handle to disabled image list (use 'DisabledIL')" },
							{ "HotIL", "Handle to hot image list (use 'HotIL')" },
							{ "tooltip", "Handle to tooltip control (use 'tooltip')" },
							{ "parent", "Handle to parent window (use 'parent' or NULL)" },
							{ "1", "Single item array supported" },
							// << End control specific
							// >> Start control specific
							{ "RGB(0,0,0)", "Red, green, and blue (RGB) value" },
							{ "RECT", "Pointer to RECT structure" },
							{ "SIZE", "Pointer to SIZE structure" },
							{ "POINT(0,0)", "Pointer to initialized POINT structure" },
							{ "intbuf", "Pointer to integer buffer (use 'intbuf')" },
							{ "TBINSERTMARK", "Pointer to TBINSERTMARK structure" },
							{ "TBINSERTMARK(0,0)", "Pointer to initialized TBINSERTMARK structure" },
							{ "COLORSCHEME(cssize,RGB(0,0,0),RGB(0,0,0))", "Pointer to initialized COLORSCHEME structure (use 'cssize' for size)" },
							{ "TBBUTTON", "Pointer to TBBUTTON structure" },
							{ "TBBUTTON(0,0,0,0,0,0)", "Pointer to initialized TBBUTTON structure" },
							{ "TBBUTTONINFO(tbbisize,0,0,0,0,0,0,0,\"string\",127)", "Pointer to initialized TBBUTTONINFO structure (use 'tbbisize' for size)" },
							{ "TBSAVEPARAMS(tbkey,\"subkey\",\"valuename\")", "Pointer to initialized TBSAVEPARAMS structure (use 'tbkey' for key handle)" },
							{ "TBADDBITMAP(instance,0)", "Pointer to initialized TBADDBITMAP structure (use 'instance' for handle)" },
							{ "TBREPLACEBITMAP(instance,0,instance,0,0)", "Pointer to initialized TBREPLACEBITMAP structure (use 'instance' for handles" }
							// << End control specific
						  };
void* g_pMemTrack[ALLOCMAX];
typedef union {
	INT intVal;
	CHAR szVal[STRBUFSIZE];
	CCITypeVal tvVal;
} YYSTYPE;
#define YUNKNOWN	257
#define YMSG	258
#define YSTYLE	259
#define YSETWINLONG	260
#define YRECREATE	261
#define YMSGID	262
#define YINT	263
#define YBOOL	264
#define YNULL	265
#define YSTR	266
#define YSTRBUF	267
#define YMAKELONG	268
#define YMAKEWPARAM	269
#define YMAKELPARAM	270
#define YRGB	271
#define YRECT	272
#define YSIZE	273
#define YPOINT	274
#define YINTBUF	275
#define YTBINSERTMARK	276
#define YCOLORSCHEME	277
#define YTBB	278
#define YTBBI	279
#define YTBSAVEPARAMS	280
#define YTBADDBITMAP	281
#define YTBREPLACEBITMAP	282
extern int yychar, yyerrflag;
extern YYSTYPE yylval;
#if YYDEBUG
enum YY_Types { YY_t_NoneDefined, YY_t_intVal, YY_t_szVal, YY_t_tvVal
};
#endif
#if YYDEBUG
yyTypedRules yyRules[] = {
	{ "&00: %01 &00",  0},
	{ "%01: %05",  0},
	{ "%01: %06",  0},
	{ "%05: &03 &28 &07 &29 %02 &29 %02 &30",  0},
	{ "%02: &10",  3},
	{ "%02: %03",  3},
	{ "%02: &09",  3},
	{ "%02: &12",  3},
	{ "%02: &11",  3},
	{ "%02: &13 &28 %03 &29 &08 &30",  3},
	{ "%02: &13 &28 &09 &29 &08 &30",  3},
	{ "%02: &14 &28 &08 &29 &08 &30",  3},
	{ "%02: &14 &28 &08 &29 &09 &30",  3},
	{ "%02: &15 &28 &08 &29 &08 &30",  3},
	{ "%02: &16 &28 &08 &29 &08 &29 &08 &30",  3},
	{ "%02: &17",  3},
	{ "%02: &18",  3},
	{ "%02: &19 &28 &08 &29 &08 &30",  3},
	{ "%02: &20",  3},
	{ "%02: &21",  3},
	{ "%02: &21 &28 &08 &29 &08 &30",  3},
	{ "%02: &22 &28 &08 &29 &16 &28 &08 &29 &08 &29 &08 &30 &29 &16 &28 &08 &29 &08 &29 &08 &30 &30",  3},
	{ "%02: &23",  3},
	{ "%02: &23 &28 &08 &29 &08 &29 %03 &29 %03 &29 &08 &29 &08 &30",  3},
	{ "%02: &24 &28 &08 &29 %03 &29 &08 &29 &08 &29 %03 &29 %03 &29 &08 &29 &08 &29 &11 &29 &08 &30",  3},
	{ "%02: &25 &28 &08 &29 &11 &29 &11 &30",  3},
	{ "%02: &26 &28 &08 &29 &08 &30",  3},
	{ "%02: &27 &28 &08 &29 &08 &29 &08 &29 &08 &29 &08 &30",  3},
	{ "%06: &04 &28 %03 &29 %03 &29 %03 &29 %03 &29 %04 &30",  0},
	{ "%04: &05",  1},
	{ "%04: &06",  1},
	{ "%03: %03 &31 &08",  1},
	{ "%03: &08",  1},
{ "$accept",  0},{ "error",  0}
};
yyNamedType yyTokenTypes[] = {
	{ "$end",  0,  0},
	{ "error",  256,  0},
	{ "YUNKNOWN",  257,  0},
	{ "YMSG",  258,  0},
	{ "YSTYLE",  259,  0},
	{ "YSETWINLONG",  260,  1},
	{ "YRECREATE",  261,  1},
	{ "YMSGID",  262,  1},
	{ "YINT",  263,  1},
	{ "YBOOL",  264,  1},
	{ "YNULL",  265,  1},
	{ "YSTR",  266,  2},
	{ "YSTRBUF",  267,  0},
	{ "YMAKELONG",  268,  0},
	{ "YMAKEWPARAM",  269,  0},
	{ "YMAKELPARAM",  270,  0},
	{ "YRGB",  271,  0},
	{ "YRECT",  272,  0},
	{ "YSIZE",  273,  0},
	{ "YPOINT",  274,  0},
	{ "YINTBUF",  275,  0},
	{ "YTBINSERTMARK",  276,  0},
	{ "YCOLORSCHEME",  277,  0},
	{ "YTBB",  278,  0},
	{ "YTBBI",  279,  0},
	{ "YTBSAVEPARAMS",  280,  0},
	{ "YTBADDBITMAP",  281,  0},
	{ "YTBREPLACEBITMAP",  282,  0},
	{ "'('",  40,  0},
	{ "','",  44,  0},
	{ "')'",  41,  0},
	{ "'|'",  124,  0}

};
#endif
static short yydef[] = {

	  -1,    5,    4,    3
};
static short yyex[] = {

	   0,    0,   -1,    1
};
static short yyact[] = {

	-134, -135,  259,  258, -133,   40, -132,   40, -165,  263, 
	-130,  262, -128, -129,  124,   44, -127,   44, -137,  263, 
	-165, -160, -161, -158, -159, -116, -117, -118, -119, -151, 
	-150, -120, -148,   -3, -121,   -2, -122, -123, -124, -125, 
	 282,  281,  280,  279,  278,  277,  276,  275,  274,  273, 
	 272,  271,  270,  269,  268,  267,  266,  265,  264,  263, 
	-114, -129,  124,   44, -113,   40, -112,   40, -111,   40, 
	-110,   40, -109,   40, -108,   40, -107,   40, -106,   40, 
	-105,   40, -104,   40, -103,   40, -102,   40, -129,  124, 
	-101,   44,  -99,  263,  -98,  263,  -97,  263,  -96,  263, 
	 -95,  263,  -94,  263,  -93,  263,  -92,  263,  -91,  263, 
	 -90,  263,  -89,  263, -165,  -88,  264,  263,  -85, -129, 
	 124,   44,  -84,   44,  -83,   44,  -82,   44,  -81,   44, 
	 -80,   44,  -79,   44,  -78,   44,  -77,   44,  -76,   44, 
	 -75,   44,  -74,   44,  -73,   44,  -72, -129,  124,   44, 
	-162,   41,  -70,  263,  -69,  263,  -68,  266,  -66,  263, 
	 -65,  271,  -64,  263,  -63,  263,  -62,  263,  -61,  263, 
	 -59,  -60,  264,  263,  -58,  263,  -57,  263,  -56, -129, 
	 124,   44,  -55,   44, -142,   41,  -54,   44,  -53, -129, 
	 124,   44,  -52,   44,  -51,   40, -147,   41, -149,   41, 
	 -50,   44, -153,   41, -154,   41, -155,   41, -156,   41, 
	-157,   41, -139, -138,  261,  260,  -48,  263,  -47,  266, 
	 -46,  263,  -44,  263,  -43,  263, -140,   41,  -42,   44, 
	-143,   41,  -41,   44,  -40, -129,  124,   44,  -39,   44, 
	-152,   41,  -38,  263,  -37,  263,  -35,  263,  -34,   44, 
	 -33,   44,  -32, -129,  124,   44,  -31,   44,  -30,  263, 
	 -28,  263,  -27,  263, -141,   41,  -26, -129,  124,   44, 
	 -25,   44,  -24,   41,  -22,  263,  -21,   44,  -20, -129, 
	 124,   44, -145,   41,  -19,  271,  -18,  263,  -17,   40, 
	 -16,   44,  -15,  263,  -14,  263,  -13,   44,  -12,   44, 
	 -11,  263,  -10,  266,   -9,   44,   -8,   44,   -7,  263, 
	  -6,  263,   -5,   41, -144,   41, -146,   41,   -1
};
static short yypact[] = {

	   8,   73,   77,   89,  317,  315,  313,  311,  309,  307, 
	 305,  303,  301,  299,  297,  295,  293,  291,  289,  287, 
	 285,  283,  280,  277,  275,    9,  273,  271,  268,  265, 
	 263,  261,    9,  259,  257,  254,  251,  249,  247,    9, 
	 245,  243,  241,  239,  236,  233,  231,  229,  227,  225, 
	 223,    9,  221,  219,  217,  214,  211,  209,  207,  205, 
	 203,  201,  199,  197,  195,  193,  190,  187,  185,  183, 
	 180,  177,  175,  172,  169,  167,  165,  163,  161,  159, 
	   9,  157,  155,  153,    9,  151,  148,  145,  143,  141, 
	 139,  137,  135,  133,  131,  129,  127,  125,  123,  120, 
	  40,  116,  113,  111,  109,  107,  105,  103,  101,   99, 
	  97,   95,   93,    9,   91,   87,   85,   83,   81,   79, 
	  75,   71,   69,   67,   65,   62,   40,    9,   19,   17, 
	  14,   11,    9,    7,    5,    2
};
static short yygo[] = {

	  -1,  -86, -115,  100,  -23,  -29,  -36,  -45,  -67,  -71, 
	 -87, -100, -126, -131,   -4,  132,  127,  113,  101,   84, 
	  80,   51,   39,   32,   25,  -49, -163, -164,   -1
};
static short yypgo[] = {

	   0,    0,    0,    2,    2,    2,   14,   25,   25,   27, 
	   2,    2,    2,    2,    2,    2,    2,    2,    2,    2, 
	   2,    2,    2,    2,    2,    2,    2,    2,    2,    2, 
	   2,   26,    0,    0,   14,    0
};
static short yyrlen[] = {

	   0,    0,    0,    1,    1,    1,    3,    1,    1,   12, 
	  12,    6,    8,   22,   14,   22,    6,    1,    6,    1, 
	   1,    8,    6,    6,    6,    6,    6,    1,    1,    1, 
	   1,    8,    1,    1,    1,    2
};
#define YYS0	135
#define YYDELTA	130
#define YYNPACT	136
#define YYNDEF	4

#define YYr33	0
#define YYr34	1
#define YYr35	2
#define YYr5	3
#define YYr19	4
#define YYr22	5
#define YYr31	6
#define YYr30	7
#define YYr29	8
#define YYr28	9
#define YYr27	10
#define YYr26	11
#define YYr25	12
#define YYr24	13
#define YYr23	14
#define YYr21	15
#define YYr20	16
#define YYr18	17
#define YYr17	18
#define YYr16	19
#define YYr15	20
#define YYr14	21
#define YYr13	22
#define YYr12	23
#define YYr11	24
#define YYr10	25
#define YYr9	26
#define YYr8	27
#define YYr7	28
#define YYr6	29
#define YYr4	30
#define YYr3	31
#define YYrACCEPT	YYr33
#define YYrERROR	YYr34
#define YYrLR2	YYr35
#if YYDEBUG
char * yysvar[] = {
	"$accept",
	"statement",
	"parameter",
	"intbmval",
	"applystyle",
	"message",
	"style",
	0
};
short yyrmap[] = {

	  33,   34,   35,    5,   19,   22,   31,   30,   29,   28, 
	  27,   26,   25,   24,   23,   21,   20,   18,   17,   16, 
	  15,   14,   13,   12,   11,   10,    9,    8,    7,    6, 
	   4,    3,    1,    2,   32,    0
};
short yysmap[] = {

	   5,   20,   22,   34,  162,  161,  160,  159,  158,  157, 
	 156,  155,  154,  153,  152,  151,  150,  149,  148,  146, 
	 145,  144,  143,  142,  141,  140,  138,  137,  136,  135, 
	 134,  133,  132,  131,  130,  129,  128,  127,  125,  124, 
	 123,  121,  119,  118,  117,  116,  115,  114,  113,  105, 
	 102,  101,  100,   99,   97,   96,   95,   94,   93,   92, 
	  91,   90,   89,   88,   87,   86,   85,   84,   83,   82, 
	  81,   79,   78,   77,   76,   75,   74,   73,   72,   71, 
	  70,   69,   68,   67,   66,   65,   64,   63,   62,   61, 
	  60,   59,   58,   57,   56,   55,   54,   53,   52,   51, 
	  50,   49,   48,   47,   46,   45,   44,   43,   42,   41, 
	  40,   39,   38,   37,   36,   30,   29,   28,   27,   24, 
	  21,   19,   18,   17,   16,   15,   13,   12,   11,   10, 
	   9,    7,    6,    2,    1,    0,   14,  111,  112,  120, 
	 139,   98,  122,  163,  147,  164,  103,   23,  104,   25, 
	  26,  126,  106,  107,  108,  109,  110,   31,   32,   33, 
	  35,   80,    4,    3,    8
};
int yyntoken = 32;
int yynvar = 7;
int yynstate = 165;
int yynrule = 36;
#endif

#if YYDEBUG
/*
 * Package up YACC context for tracing
 */
typedef struct yyTraceItems_tag {
	int	state, lookahead, errflag, done;
	int	rule, npop;
	short	* states;
	int	nstates;
	YYSTYPE * values;
	int	nvalues;
	short	* types;
} yyTraceItems;
#endif

#line 2 "/progra~1/mks/etc/yyparse.c"

/*
 * Copyright 1985, 1990 by Mortice Kern Systems Inc.  All rights reserved.
 * 
 * Automaton to interpret LALR(1) tables.
 *
 * Macros:
 *	yyclearin - clear the lookahead token.
 *	yyerrok - forgive a pending error
 *	YYERROR - simulate an error
 *	YYACCEPT - halt and return 0
 *	YYABORT - halt and return 1
 *	YYRETURN(value) - halt and return value.  You should use this
 *		instead of return(value).
 *	YYREAD - ensure yychar contains a lookahead token by reading
 *		one if it does not.  See also YYSYNC.
 *	YYRECOVERING - 1 if syntax error detected and not recovered
 *		yet; otherwise, 0.
 *
 * Preprocessor flags:
 *	YYDEBUG - includes debug code if 1.  The parser will print
 *		 a travelogue of the parse if this is defined as 1
 *		 and yydebug is non-zero.
 *		yacc -t sets YYDEBUG to 1, but not yydebug.
 *	YYTRACE - turn on YYDEBUG, and undefine default trace functions
 *		so that the interactive functions in 'ytrack.c' will
 *		be used.
 *	YYSSIZE - size of state and value stacks (default 150).
 *	YYSTATIC - By default, the state stack is an automatic array.
 *		If this is defined, the stack will be static.
 *		In either case, the value stack is static.
 *	YYALLOC - Dynamically allocate both the state and value stacks
 *		by calling malloc() and free().
 *	YYDYNAMIC - Dynamically allocate (and reallocate, if necessary)
 *		both the state and value stacks by calling malloc(),
 *		realloc(), and free().
 *	YYSYNC - if defined, yacc guarantees to fetch a lookahead token
 *		before any action, even if it doesnt need it for a decision.
 *		If YYSYNC is defined, YYREAD will never be necessary unless
 *		the user explicitly sets yychar = -1
 *
 * Copyright (c) 1983, by the University of Waterloo
 */
/*
 * Prototypes
 */

extern int yylex YY_ARGS((void));

#if YYDEBUG

#include <stdlib.h>		/* common prototypes */
#include <string.h>

extern char *	yyValue YY_ARGS((YYSTYPE, int));	/* print yylval */
extern void yyShowState YY_ARGS((yyTraceItems *));
extern void yyShowReduce YY_ARGS((yyTraceItems *));
extern void yyShowGoto YY_ARGS((yyTraceItems *));
extern void yyShowShift YY_ARGS((yyTraceItems *));
extern void yyShowErrRecovery YY_ARGS((yyTraceItems *));
extern void yyShowErrDiscard YY_ARGS((yyTraceItems *));

extern void yyShowRead YY_ARGS((int));
#endif

/*
 * If YYDEBUG defined and yydebug set,
 * tracing functions will be called at appropriate times in yyparse()
 * Pass state of YACC parse, as filled into yyTraceItems yyx
 * If yyx.done is set by the tracing function, yyparse() will terminate
 * with a return value of -1
 */
#define YY_TRACE(fn) { \
	yyx.state = yystate; yyx.lookahead = yychar; yyx.errflag =yyerrflag; \
	yyx.states = yys+1; yyx.nstates = yyps-yys; \
	yyx.values = yyv+1; yyx.nvalues = yypv-yyv; \
	yyx.types = yytypev+1; yyx.done = 0; \
	yyx.rule = yyi; yyx.npop = yyj; \
	fn(&yyx); \
	if (yyx.done) YYRETURN(-1); }

#ifndef I18N
#define m_textmsg(id, str, cls)	(str)
#else /*I18N*/
#include <m_nls.h>
#endif/*I18N*/

#ifndef YYSSIZE
# define YYSSIZE	150
#endif

#ifdef YYDYNAMIC
#define YYALLOC
char *getenv();
int atoi();
int yysinc = -1; /* stack size increment, <0 = double, 0 = none, >0 = fixed */
#endif

#ifdef YYALLOC
int yyssize = YYSSIZE;
#endif

#define YYERROR		goto yyerrlabel
#define yyerrok		yyerrflag = 0
#if YYDEBUG
#define yyclearin	{ if (yydebug) yyShowRead(-1); yychar = -1; }
#else
#define yyclearin	yychar = -1
#endif
#define YYACCEPT	YYRETURN(0)
#define YYABORT		YYRETURN(1)
#define YYRECOVERING()	(yyerrflag != 0)
#ifdef YYALLOC
#define YYRETURN(val)	{ retval = (val); goto yyReturn; }
#else
#define YYRETURN(val)	return(val);
#endif
#if YYDEBUG
/* The if..else makes this macro behave exactly like a statement */
# define YYREAD	if (yychar < 0) {					\
			if ((yychar = yylex()) < 0)	{		\
				if (yychar == -2) YYABORT; \
				yychar = 0;				\
			}	/* endif */			\
			if (yydebug)					\
				yyShowRead(yychar);			\
		} else
#else
# define YYREAD	if (yychar < 0) {					\
			if ((yychar = yylex()) < 0) {			\
				if (yychar == -2) YYABORT; \
				yychar = 0;				\
			}	/* endif */			\
		} else
#endif

#define YYERRCODE	256		/* value of `error' */
#define	YYQYYP	yyq[yyq-yyp]

YYSTYPE	yyval;				/* $ */
YYSTYPE	*yypvt;				/* $n */
YYSTYPE	yylval;				/* yylex() sets this */

int	yychar,				/* current token */
	yyerrflag,			/* error flag */
	yynerrs;			/* error count */

#if YYDEBUG
int yydebug = 0;		/* debug if this flag is set */
extern char	*yysvar[];	/* table of non-terminals (aka 'variables') */
extern yyNamedType yyTokenTypes[];	/* table of terminals & their types */
extern short	yyrmap[], yysmap[];	/* map internal rule/states */
extern int	yynstate, yynvar, yyntoken, yynrule;

extern int	yyGetType YY_ARGS((int));	/* token type */
extern char	*yyptok YY_ARGS((int));	/* printable token string */
extern int	yyExpandName YY_ARGS((int, int, char *, int));
				  /* expand yyRules[] or yyStates[] */
static char *	yygetState YY_ARGS((int));

#define yyassert(condition, msg, arg) \
	if (!(condition)) { \
		printf(m_textmsg(2824, "\nyacc bug: ", "E")); \
		printf(msg, arg); \
		YYABORT; }
#else /* !YYDEBUG */
#define yyassert(condition, msg, arg)
#endif

#line 363 "../Parser/cci.y"
/* USER SUBROUTINES */

//        Name: yyerror
// Description: Custom parser error handler
//  Parameters: Pointer to error string return by YACC
//     Returns: none
void yyerror(char* error)
{
	int dX;

	sprintf(g_pCCIResult->pError,"%s: '%s' (line %d)",error,yytext,yylineno);
	g_pCCIResult->dErrLine = yylineno;

	g_pCCIResult->dMsgNo = 0;
	g_pCCIResult->pWParam = NULL;
	g_pCCIResult->pLParam = NULL;
	g_pCCIResult->ccitWParam = -1;
	g_pCCIResult->ccitLParam = -1;

	// Clean up allocated memory that resulted from the imcomplete parse
	for(dX=0;dX<ALLOCMAX;dX++)
		if(g_pMemTrack[dX])
			free(g_pMemTrack[dX]);

	return;
}

//        Name: CCIInterpret
// Description: Interpreter entry point, returns result
//  Parameters: Input string
//     Returns: Pointer to CCIResult struct with result of parse
CCIResult* CCIInterpret(LPSTR p_pInput)
{
	int dX;

	// Create result structure
	g_pCCIResult = (CCIResult*)malloc(sizeof(CCIResult));

	// Initialize result structure
	g_pCCIResult->pInput = (LPSTR)malloc(strlen(p_pInput)+1);
	strcpy(g_pCCIResult->pInput,p_pInput);
	g_pCCIResult->pError = (LPSTR)malloc(ERRBUFSIZE);
	*(g_pCCIResult->pError) = '\0';
	g_pCCIResult->dErrLine = -1;

	g_pCCIResult->dMsgNo = 0;
	
	g_pCCIResult->pWParam = NULL;
	g_pCCIResult->pLParam = NULL;

	g_pCCIResult->ccitWParam = -1;
	g_pCCIResult->ccitLParam = -1;

	// Copy input to temporary file
	if((yyin = fopen(TEMPFILE,"w+b")) == NULL)
	{
		strcpy(g_pCCIResult->pError,"Could not create temporary file!");
		return g_pCCIResult;
	}
	fputs(p_pInput,yyin);
	rewind(yyin);

	// Initialize memory tracking for error recovery
	for(dX=0;dX<ALLOCMAX;dX++)
		g_pMemTrack[dX] = NULL;

	// Parse input
	yy_reset();
	yyparse();

	// CCIResult is now full
	fclose(yyin);
	remove(TEMPFILE);

	// Return
	return g_pCCIResult;
}

//        Name: CCIGetSignature
// Description: Get either template or description of signature item
//  Parameters: Type of information to return, item to query
//     Returns: Pointer to template or description string
LPSTR CCIGetSignature(BYTE p_dType,BYTE p_dItem)
{
	if(p_dItem == SIGTEMP)
		return g_pSignature[p_dType][0];
	else
		return g_pSignature[p_dType][1];
}

//        Name: CCIGetSignature
// Description: Convert parameter value to printable text format
//  Parameters: Type of parameter, actual value, buffer to write out to
//     Returns: none
void CCIRender(CCITYPE p_pCCIType,void* p_pValue,LPSTR p_pDisplay)
{
	CHAR szBuf[31];
	switch(p_pCCIType)
	{
		case NOV:
			strcpy(p_pDisplay,"No Value");
			break;

		case ERRV:
			sprintf(p_pDisplay,"%d (%s)",(INT)p_pValue,((INT)p_pValue<0)?"ERROR":"OK");
			break;

		case SUCCESSV:
			sprintf(p_pDisplay,"%d (%s)",(INT)p_pValue,((INT)p_pValue==0)?"FAIL":"SUCCESS");
			break;

		case BITMASKV:
		case NUMV:
			sprintf(p_pDisplay,"%d (0x%x)",(INT)p_pValue,(INT)p_pValue);
			break;

		case BOOLV:
			sprintf(p_pDisplay,"%s",p_pValue?"TRUE":"FALSE");
			break;

		case LPSTRV:
		case LPSTRVI:
			sprintf(p_pDisplay,"%s",(LPSTR)p_pValue);
			break;

		// >> Start control specific
		case BITMAPFLAGV:
			sprintf(p_pDisplay,"0x%x%s",(INT)p_pValue,(((INT)p_pValue)&TBBF_LARGE)?" (TBBF_LARGE)":"");
			break;

		case LOHIV:
			sprintf(p_pDisplay,"LOWORD: %d, HIWORD: %d (0x%x)",LOWORD((INT)p_pValue),HIWORD((INT)p_pValue),(INT)p_pValue);
			break;

		case RGBV:
			sprintf(p_pDisplay,"RGB(%d,%d,%d)",
				GetRValue((DWORD)p_pValue),
				GetGValue((DWORD)p_pValue),
				GetBValue((DWORD)p_pValue));
			break;

		case LPRECTV:
			sprintf(p_pDisplay,"RECT(%d,%d,%d,%d)",
				((LPRECT)p_pValue)->left,
				((LPRECT)p_pValue)->top,
				((LPRECT)p_pValue)->right,
				((LPRECT)p_pValue)->bottom);
			break;

		case LPSIZEV:
			sprintf(p_pDisplay,"SIZE(%d,%d)",((LPSIZE)p_pValue)->cx,((LPSIZE)p_pValue)->cy);
			break;

		case LPPOINTVI:
			sprintf(p_pDisplay,"POINT(%d,%d)",((LPPOINT)p_pValue)->x,((LPPOINT)p_pValue)->y);
			break;

		case LPINTBUFV:
			sprintf(p_pDisplay,"%d (0x%x)",*((LPINT)p_pValue),*((LPINT)p_pValue));
			break;

		case LPTBINSERTMARKV:
		case LPTBINSERTMARKVI:
			sprintf(p_pDisplay,"TBINSERTMARK(%d,0x%x)",((LPTBINSERTMARK)p_pValue)->iButton,((LPTBINSERTMARK)p_pValue)->dwFlags);
			break;

		case LPCOLORSCHEMEVI:
			sprintf(p_pDisplay,"COLORSCHEME(%d,RGB(%d,%d,%d),RGB(%d,%d,%d))",((LPCOLORSCHEME)p_pValue)->dwSize,
				GetRValue(((LPCOLORSCHEME)p_pValue)->clrBtnHighlight),GetGValue(((LPCOLORSCHEME)p_pValue)->clrBtnHighlight),GetBValue(((LPCOLORSCHEME)p_pValue)->clrBtnHighlight),
				GetRValue(((LPCOLORSCHEME)p_pValue)->clrBtnShadow),GetGValue(((LPCOLORSCHEME)p_pValue)->clrBtnShadow),GetBValue(((LPCOLORSCHEME)p_pValue)->clrBtnShadow));
			break;

		case LPTBBUTTONV:
		case LPTBBUTTONVI:
			sprintf(p_pDisplay,"TBBUTTON(%d,%d,0x%x,0x%x,%d,%d)",
				((LPTBBUTTON)p_pValue)->iBitmap,
				((LPTBBUTTON)p_pValue)->idCommand,
				((LPTBBUTTON)p_pValue)->fsState,
				((LPTBBUTTON)p_pValue)->fsStyle,
				((LPTBBUTTON)p_pValue)->dwData,
				((LPTBBUTTON)p_pValue)->iString);
			break;

		case LPTBBUTTONINFOVI:
			// Do conversions before display
			itoa(((PCOMBOBOXEXITEM)p_pValue)->iImage,szBuf,10);
			sprintf(p_pDisplay,"TBBUTTONINFO(%d,%d,%d,%s,%d,%d,%d,%d,%s,%d)",
				((LPTBBUTTONINFO)p_pValue)->cbSize,
				((LPTBBUTTONINFO)p_pValue)->dwMask,
				((LPTBBUTTONINFO)p_pValue)->idCommand,
				(((LPTBBUTTONINFO)p_pValue)->iImage==I_IMAGECALLBACK)?"I_IMAGECALLBACK":szBuf,
				((LPTBBUTTONINFO)p_pValue)->fsState,
				((LPTBBUTTONINFO)p_pValue)->fsStyle,
				((LPTBBUTTONINFO)p_pValue)->cx,
				((LPTBBUTTONINFO)p_pValue)->lParam,
				((LPTBBUTTONINFO)p_pValue)->pszText,
				((LPTBBUTTONINFO)p_pValue)->cchText);
			break;

		case LPTBSAVEPARAMSVI:
			sprintf(p_pDisplay,"TBSAVEPARAMS(0x%x,%s,%s)",((TBSAVEPARAMS*)p_pValue)->hkr,
				((TBSAVEPARAMS*)p_pValue)->pszSubKey,((TBSAVEPARAMS*)p_pValue)->pszValueName);
			break;

		case LPTBADDBITMAPVI:
			sprintf(p_pDisplay,"TBADDBITMAP(0x%x,%d)",((LPTBADDBITMAP)p_pValue)->hInst,
				((LPTBADDBITMAP)p_pValue)->nID);
			break;

		case LPTBREPLACEBITMAPVI:
			sprintf(p_pDisplay,"TBREPLACEBITMAP(0x%x,%d,0x%x,%d,%d)",
				((LPTBREPLACEBITMAP)p_pValue)->hInstOld,
				((LPTBREPLACEBITMAP)p_pValue)->nIDOld,
				((LPTBREPLACEBITMAP)p_pValue)->hInstNew,
				((LPTBREPLACEBITMAP)p_pValue)->nIDNew,
				((LPTBREPLACEBITMAP)p_pValue)->nButtons);
			break;
		// End control specific <<

		default:
			*p_pDisplay = '\0';
			break;
	}
}

//        Name: CCIDestroy
// Description: Free memory allocated by a CCIResult structure
//  Parameters: Pointer to CCIResult structure
//     Returns: none
void CCIDestroy(CCIResult* p_pCCIResult)
{
	// Free input and error buffer
	if(p_pCCIResult->pInput)
		free(p_pCCIResult->pInput);
	if(p_pCCIResult->pError)
		free(p_pCCIResult->pError);

	// Remove wParam
	CCIDestroyHelper(p_pCCIResult->ccitWParam,p_pCCIResult->pWParam);	
	// Remove lParam
	CCIDestroyHelper(p_pCCIResult->ccitLParam,p_pCCIResult->pLParam);

	// Remove structure
	free(p_pCCIResult);
}

//        Name: CCIDestroyHelper
// Description: CCIDestory second level helper
//  Parameters: Type of parameter, data to free
//     Returns: none
void CCIDestroyHelper(CCITYPE p_pCCIType,void* p_pValue)
{
	switch(p_pCCIType)
	{
		// No storage
		case NUMV:
		case BOOLV:
		case RGBV:
			break;

		// >> Start control specific
		// Multiple level storage (wParam/lParam values whose members point to memory)
		case LPTBBUTTONINFOVI:
		case LPTBSAVEPARAMSVI:
			if(p_pCCIType == LPTBBUTTONINFOVI)
			{
				if(((LPTBBUTTONINFO)p_pValue)->pszText)
					free(((LPTBBUTTONINFO)p_pValue)->pszText);
			}
			else
			{
				if(((TBSAVEPARAMS*)p_pValue)->pszSubKey)
					free((LPSTR)((TBSAVEPARAMS*)p_pValue)->pszSubKey);
				if(((TBSAVEPARAMS*)p_pValue)->pszValueName)
					free((LPSTR)((TBSAVEPARAMS*)p_pValue)->pszValueName);
			}
		// Fall through
		
		// Single level storage (wParam/lParam that point to memory)
		default:
			if(p_pValue)
				free(p_pValue);
		// End control specific <<
	}
}

//        Name: CCIMemTrack
// Description: Track all memory during parsing in the event of an error so that memory
//				can be freed
//  Parameters: Pointer to allocated memory
//     Returns: none
void CCIMemTrack(void* p_pMem)
{
	int dX;
	BOOL bFoundSlot = FALSE;

	for(dX=0;dX<ALLOCMAX;dX++)
	{
		if(!g_pMemTrack[dX])
		{
			bFoundSlot = TRUE;
			g_pMemTrack[dX] = p_pMem;
			break;
		}
	}

	if(!bFoundSlot)
		OutputDebugString("Allocation track overflow!\n");
}


#ifdef YACC_WINDOWS

/*
 * the following is the yyparse() function that will be
 * callable by a windows type program. It in turn will
 * load all needed resources, obtain pointers to these
 * resources, and call a statically defined function
 * win_yyparse(), which is the original yyparse() fn
 * When win_yyparse() is complete, it will return a
 * value to the new yyparse(), where it will be stored
 * away temporarily, all resources will be freed, and
 * that return value will be given back to the caller
 * yyparse(), as expected.
 */

static int win_yyparse();			/* prototype */

yyparse() 
{
	int wReturnValue;
	HANDLE hRes_table;		/* handle of resource after loading */
	short *old_yydef;		/* the following are used for saving */
	short *old_yyex;		/* the current pointers */
	short *old_yyact;
	short *old_yypact;
	short *old_yygo;
	short *old_yypgo;
	short *old_yyrlen;

	/*
	 * the following code will load the required
	 * resources for a Windows based parser.
	 */

	hRes_table = LoadResource (hInst, 
		FindResource (hInst, "UD_RES_yyYACC", "yyYACCTBL"));
	
	/*
	 * return an error code if any
	 * of the resources did not load
	 */

	if (hRes_table == NULL)
		return (1);
	
	/*
	 * the following code will lock the resources
	 * into fixed memory locations for the parser
	 * (also, save the current pointer values first)
	 */

	old_yydef = yydef;
	old_yyex = yyex;
	old_yyact = yyact;
	old_yypact = yypact;
	old_yygo = yygo;
	old_yypgo = yypgo;
	old_yyrlen = yyrlen;

	yydef = (short *)LockResource (hRes_table);
	yyex = (short *)(yydef + Sizeof_yydef);
	yyact = (short *)(yyex + Sizeof_yyex);
	yypact = (short *)(yyact + Sizeof_yyact);
	yygo = (short *)(yypact + Sizeof_yypact);
	yypgo = (short *)(yygo + Sizeof_yygo);
	yyrlen = (short *)(yypgo + Sizeof_yypgo);

	/*
	 * call the official yyparse() function
	 */

	wReturnValue = win_yyparse();

	/*
	 * unlock the resources
	 */

	UnlockResource (hRes_table);

	/*
	 * and now free the resource
	 */

	FreeResource (hRes_table);

	/*
	 * restore previous pointer values
	 */

	yydef = old_yydef;
	yyex = old_yyex;
	yyact = old_yyact;
	yypact = old_yypact;
	yygo = old_yygo;
	yypgo = old_yypgo;
	yyrlen = old_yyrlen;

	return (wReturnValue);
}	/* end yyparse */

static int win_yyparse() 

#else /* YACC_WINDOWS */

/*
 * we are not compiling a windows resource
 * based parser, so call yyparse() the old
 * standard way.
 */

yyparse() 

#endif /* YACC_WINDOWS */

{
	register short		yyi, *yyp;	/* for table lookup */
	register short		*yyps;		/* top of state stack */
	register short		yystate;	/* current state */
	register YYSTYPE	*yypv;		/* top of value stack */
	register short		*yyq;
	register int		yyj;
#if YYDEBUG
	yyTraceItems	yyx;			/* trace block */
	short	* yytp;
	int	yyruletype = 0;
#endif
#ifdef YYSTATIC
	static short	yys[YYSSIZE + 1];
	static YYSTYPE	yyv[YYSSIZE + 1];
#if YYDEBUG
	static short	yytypev[YYSSIZE+1];	/* type assignments */
#endif
#else /* ! YYSTATIC */
#ifdef YYALLOC
	YYSTYPE *yyv;
	short	*yys;
#if YYDEBUG
	short	*yytypev;
#endif
	YYSTYPE save_yylval;
	YYSTYPE save_yyval;
	YYSTYPE *save_yypvt;
	int save_yychar, save_yyerrflag, save_yynerrs;
	int retval; 			/* return value holder */
#else
	short		yys[YYSSIZE + 1];
	static YYSTYPE	yyv[YYSSIZE + 1];	/* historically static */
#if YYDEBUG
	short	yytypev[YYSSIZE+1];		/* mirror type table */
#endif
#endif /* ! YYALLOC */
#endif /* ! YYSTATIC */
#ifdef YYDYNAMIC
	char *envp;
#endif


#ifdef YYDYNAMIC
	if ((envp = getenv("YYSTACKSIZE")) != (char *)0) {
		yyssize = atoi(envp);
		if (yyssize <= 0)
			yyssize = YYSSIZE;
	}
	if ((envp = getenv("YYSTACKINC")) != (char *)0)
		yysinc = atoi(envp);
#endif
#ifdef YYALLOC
	yys = (short *) malloc((yyssize + 1) * sizeof(short));
	yyv = (YYSTYPE *) malloc((yyssize + 1) * sizeof(YYSTYPE));
#if YYDEBUG
	yytypev = (short *) malloc((yyssize + 1) * sizeof(short));
#endif
	if (yys == (short *)0 || yyv == (YYSTYPE *)0
#if YYDEBUG
		|| yytypev == (short *) 0
#endif
	) {
		yyerror("Not enough space for parser stacks");
		return 1;
	}
	save_yylval = yylval;
	save_yyval = yyval;
	save_yypvt = yypvt;
	save_yychar = yychar;
	save_yyerrflag = yyerrflag;
	save_yynerrs = yynerrs;
#endif

	yynerrs = 0;
	yyerrflag = 0;
	yyclearin;
	yyps = yys;
	yypv = yyv;
	*yyps = yystate = YYS0;		/* start state */
#if YYDEBUG
	yytp = yytypev;
	yyi = yyj = 0;			/* silence compiler warnings */
#endif

yyStack:
	yyassert((unsigned)yystate < yynstate, m_textmsg(587, "state %d\n", ""), yystate);
#ifdef YYDYNAMIC
	if (++yyps > &yys[yyssize]) {
		int yynewsize;
		int yysindex = yyps - yys;
		int yyvindex = yypv - yyv;
#if YYDEBUG
		int yytindex = yytp - yytypev;
#endif
		if (yysinc == 0) {		/* no increment */
			yyerror("Parser stack overflow");
			YYABORT;
		} else if (yysinc < 0)		/* binary-exponential */
			yynewsize = yyssize * 2;
		else				/* fixed increment */
			yynewsize = yyssize + yysinc;
		if (yynewsize < yyssize) {
			yyerror("Not enough space for parser stacks");
			YYABORT;
		}
		yyssize = yynewsize;
		yys = (short *) realloc(yys, (yyssize + 1) * sizeof(short));
		yyps = yys + yysindex;
		yyv = (YYSTYPE *) realloc(yyv, (yyssize + 1) * sizeof(YYSTYPE));
		yypv = yyv + yyvindex;
#if YYDEBUG
		yytypev = (short *)realloc(yytypev,(yyssize + 1)*sizeof(short));
		yytp = yytypev + yytindex;
#endif
		if (yys == (short *)0 || yyv == (YYSTYPE *)0
#if YYDEBUG
			|| yytypev == (short *) 0
#endif
		) {
			yyerror("Not enough space for parser stacks");
			YYABORT;
		}
	}
#else
	if (++yyps > &yys[YYSSIZE]) {
		yyerror("Parser stack overflow");
		YYABORT;
	}
#endif /* !YYDYNAMIC */
	*yyps = yystate;	/* stack current state */
	*++yypv = yyval;	/* ... and value */
#if YYDEBUG
	*++yytp = yyruletype;	/* ... and type */

	if (yydebug)
		YY_TRACE(yyShowState)
#endif

	/*
	 *	Look up next action in action table.
	 */
yyEncore:
#ifdef YYSYNC
	YYREAD;
#endif

#ifdef YACC_WINDOWS
	if (yystate >= Sizeof_yypact) 	/* simple state */
#else /* YACC_WINDOWS */
	if (yystate >= sizeof yypact/sizeof yypact[0]) 	/* simple state */
#endif /* YACC_WINDOWS */
		yyi = yystate - YYDELTA;	/* reduce in any case */
	else {
		if(*(yyp = &yyact[yypact[yystate]]) >= 0) {
			/* Look for a shift on yychar */
#ifndef YYSYNC
			YYREAD;
#endif
			yyq = yyp;
			yyi = yychar;
			while (yyi < *yyp++)
				;
			if (yyi == yyp[-1]) {
				yystate = ~YYQYYP;
#if YYDEBUG
				if (yydebug) {
					yyruletype = yyGetType(yychar);
					YY_TRACE(yyShowShift)
				}
#endif
				yyval = yylval;	/* stack what yylex() set */
				yyclearin;		/* clear token */
				if (yyerrflag)
					yyerrflag--;	/* successful shift */
				goto yyStack;
			}
		}

		/*
	 	 *	Fell through - take default action
	 	 */

#ifdef YACC_WINDOWS
		if (yystate >= Sizeof_yydef)
#else /* YACC_WINDOWS */
		if (yystate >= sizeof yydef /sizeof yydef[0])
#endif /* YACC_WINDOWS */
			goto yyError;
		if ((yyi = yydef[yystate]) < 0)	 { /* default == reduce? */
			/* Search exception table */
#ifdef YACC_WINDOWS
			yyassert((unsigned)~yyi < Sizeof_yyex,
				m_textmsg(2825, "exception %d\n", "I num"), yystate);
#else /* YACC_WINDOWS */
			yyassert((unsigned)~yyi < sizeof yyex/sizeof yyex[0],
				m_textmsg(2825, "exception %d\n", "I num"), yystate);
#endif /* YACC_WINDOWS */
			yyp = &yyex[~yyi];
#ifndef YYSYNC
			YYREAD;
#endif
			while((yyi = *yyp) >= 0 && yyi != yychar)
				yyp += 2;
			yyi = yyp[1];
			yyassert(yyi >= 0,
				 m_textmsg(2826, "Ex table not reduce %d\n", "I num"), yyi);
		}
	}

	yyassert((unsigned)yyi < yynrule, m_textmsg(2827, "reduce %d\n", "I num"), yyi);
	yyj = yyrlen[yyi];
#if YYDEBUG
	if (yydebug)
		YY_TRACE(yyShowReduce)
	yytp -= yyj;
#endif
	yyps -= yyj;		/* pop stacks */
	yypvt = yypv;		/* save top */
	yypv -= yyj;
	yyval = yypv[1];	/* default action $ = $1 */
#if YYDEBUG
	yyruletype = yyRules[yyrmap[yyi]].type;
#endif

	switch (yyi) {		/* perform semantic action */
		
case YYr3: {	/* message :  YMSG '(' YMSGID ',' parameter ',' parameter ')' */
#line 130 "../Parser/cci.y"

			g_pCCIResult->dMsgNo = yypvt[-5].intVal;
			g_pCCIResult->ccitWParam = yypvt[-3].tvVal.cciType;
			g_pCCIResult->pWParam = yypvt[-3].tvVal.cciValue;
			g_pCCIResult->ccitLParam = yypvt[-1].tvVal.cciType;
			g_pCCIResult->pLParam = yypvt[-1].tvVal.cciValue;
		
} break;

case YYr4: {	/* parameter :  YNULL */
#line 140 "../Parser/cci.y"

			yyval.tvVal.cciType = NUMV;
			yyval.tvVal.cciValue = (void*)yypvt[0].intVal; 
		
} break;

case YYr5: {	/* parameter :  intbmval */
#line 145 "../Parser/cci.y"
 
			yyval.tvVal.cciType = NUMV;
			yyval.tvVal.cciValue = (void*)yypvt[0].intVal; 
		
} break;

case YYr6: {	/* parameter :  YBOOL */
#line 150 "../Parser/cci.y"
 
			yyval.tvVal.cciType = BOOLV;
			yyval.tvVal.cciValue = (void*)yypvt[0].intVal; 
		
} break;

case YYr7: {	/* parameter :  YSTRBUF */
#line 155 "../Parser/cci.y"

			yyval.tvVal.cciType = LPSTRV;
			yyval.tvVal.cciValue = (void*)malloc(STRBUFSIZE);
			CCIMemTrack(yyval.tvVal.cciValue);
			ZeroMemory(yyval.tvVal.cciValue,STRBUFSIZE);
		
} break;

case YYr8: {	/* parameter :  YSTR */
#line 162 "../Parser/cci.y"

			yyval.tvVal.cciType = LPSTRVI;
			yyval.tvVal.cciValue = (void*)malloc(strlen(yypvt[0].szVal)+1);
			CCIMemTrack(yyval.tvVal.cciValue);
			strcpy((LPSTR)(yyval.tvVal.cciValue),yypvt[0].szVal);
		
} break;

case YYr9: {	/* parameter :  YMAKELONG '(' intbmval ',' YINT ')' */
#line 171 "../Parser/cci.y"

			yyval.tvVal.cciType = NUMV;
			yyval.tvVal.cciValue = (void*)MAKELONG((WORD)yypvt[-3].intVal,(WORD)yypvt[-1].intVal);
		
} break;

case YYr10: {	/* parameter :  YMAKELONG '(' YBOOL ',' YINT ')' */
#line 176 "../Parser/cci.y"

			yyval.tvVal.cciType = NUMV;
			yyval.tvVal.cciValue = (void*)MAKELONG((WORD)yypvt[-3].intVal,(WORD)yypvt[-1].intVal);
		
} break;

case YYr11: {	/* parameter :  YMAKEWPARAM '(' YINT ',' YINT ')' */
#line 181 "../Parser/cci.y"

			yyval.tvVal.cciType = NUMV;
			yyval.tvVal.cciValue = (void*)MAKEWPARAM((WORD)yypvt[-3].intVal,(WORD)yypvt[-1].intVal);
		
} break;

case YYr12: {	/* parameter :  YMAKEWPARAM '(' YINT ',' YBOOL ')' */
#line 186 "../Parser/cci.y"

			yyval.tvVal.cciType = NUMV;
			yyval.tvVal.cciValue = (void*)MAKEWPARAM((WORD)yypvt[-3].intVal,(WORD)yypvt[-1].intVal);
		
} break;

case YYr13: {	/* parameter :  YMAKELPARAM '(' YINT ',' YINT ')' */
#line 191 "../Parser/cci.y"

			yyval.tvVal.cciType = NUMV;
			yyval.tvVal.cciValue = (void*)MAKELPARAM((WORD)yypvt[-3].intVal,(WORD)yypvt[-1].intVal);
		
} break;

case YYr14: {	/* parameter :  YRGB '(' YINT ',' YINT ',' YINT ')' */
#line 196 "../Parser/cci.y"

			yyval.tvVal.cciType = RGBV;
			yyval.tvVal.cciValue = (void*)RGB(yypvt[-5].intVal,yypvt[-3].intVal,yypvt[-1].intVal);
		
} break;

case YYr15: {	/* parameter :  YRECT */
#line 201 "../Parser/cci.y"

			yyval.tvVal.cciType = LPRECTV;
			yyval.tvVal.cciValue = malloc(sizeof(RECT));
			CCIMemTrack(yyval.tvVal.cciValue);
			ZeroMemory(yyval.tvVal.cciValue,sizeof(RECT));
		
} break;

case YYr16: {	/* parameter :  YSIZE */
#line 208 "../Parser/cci.y"

			yyval.tvVal.cciType = LPSIZEV;
			yyval.tvVal.cciValue = malloc(sizeof(SIZE));
			CCIMemTrack(yyval.tvVal.cciValue);
			ZeroMemory(yyval.tvVal.cciValue,sizeof(SIZE));
		
} break;

case YYr17: {	/* parameter :  YPOINT '(' YINT ',' YINT ')' */
#line 215 "../Parser/cci.y"

			yyval.tvVal.cciType = LPPOINTVI;
			yyval.tvVal.cciValue = malloc(sizeof(POINT));
			CCIMemTrack(yyval.tvVal.cciValue);
			ZeroMemory(yyval.tvVal.cciValue,sizeof(POINT));
			((LPPOINT)yyval.tvVal.cciValue)->x = yypvt[-3].intVal;
			((LPPOINT)yyval.tvVal.cciValue)->y = yypvt[-1].intVal;
		
} break;

case YYr18: {	/* parameter :  YINTBUF */
#line 224 "../Parser/cci.y"

			yyval.tvVal.cciType = LPINTBUFV;
			yyval.tvVal.cciValue = malloc(sizeof(INT));
			CCIMemTrack(yyval.tvVal.cciValue);
			*((LPINT)yyval.tvVal.cciValue) = 0;
		
} break;

case YYr19: {	/* parameter :  YTBINSERTMARK */
#line 231 "../Parser/cci.y"

			yyval.tvVal.cciType = LPTBINSERTMARKV;
			yyval.tvVal.cciValue = malloc(sizeof(TBINSERTMARK));
			CCIMemTrack(yyval.tvVal.cciValue);
			ZeroMemory(yyval.tvVal.cciValue,sizeof(TBINSERTMARK));
		
} break;

case YYr20: {	/* parameter :  YTBINSERTMARK '(' YINT ',' YINT ')' */
#line 238 "../Parser/cci.y"

			yyval.tvVal.cciType = LPTBINSERTMARKVI;
			yyval.tvVal.cciValue = malloc(sizeof(TBINSERTMARK));
			CCIMemTrack(yyval.tvVal.cciValue);
			((LPTBINSERTMARK)yyval.tvVal.cciValue)->iButton = yypvt[-3].intVal;
			((LPTBINSERTMARK)yyval.tvVal.cciValue)->dwFlags = yypvt[-1].intVal;
		
} break;

case YYr21: {	/* parameter :  YCOLORSCHEME '(' YINT ',' YRGB '(' YINT ',' YINT ',' YINT ')' ',' YRGB '(' YINT ',' YINT ',' YINT ')' ')' */
#line 246 "../Parser/cci.y"

			yyval.tvVal.cciType = LPCOLORSCHEMEVI;
			yyval.tvVal.cciValue = malloc(sizeof(COLORSCHEME));
			CCIMemTrack(yyval.tvVal.cciValue);
			((LPCOLORSCHEME)yyval.tvVal.cciValue)->dwSize = yypvt[-19].intVal;
			((LPCOLORSCHEME)yyval.tvVal.cciValue)->clrBtnHighlight = RGB(yypvt[-15].intVal,yypvt[-13].intVal,yypvt[-11].intVal);
			((LPCOLORSCHEME)yyval.tvVal.cciValue)->clrBtnShadow = RGB(yypvt[-6].intVal,yypvt[-4].intVal,yypvt[-2].intVal);
		
} break;

case YYr22: {	/* parameter :  YTBB */
#line 255 "../Parser/cci.y"

			yyval.tvVal.cciType = LPTBBUTTONV;
			yyval.tvVal.cciValue = malloc(sizeof(TBBUTTON));
			CCIMemTrack(yyval.tvVal.cciValue);
			ZeroMemory(yyval.tvVal.cciValue,sizeof(TBBUTTON));
		
} break;

case YYr23: {	/* parameter :  YTBB '(' YINT ',' YINT ',' intbmval ',' intbmval ',' YINT ',' YINT ')' */
#line 262 "../Parser/cci.y"

			yyval.tvVal.cciType = LPTBBUTTONVI;
			yyval.tvVal.cciValue = malloc(sizeof(TBBUTTON));
			CCIMemTrack(yyval.tvVal.cciValue);
			((LPTBBUTTON)yyval.tvVal.cciValue)->iBitmap = yypvt[-11].intVal;
			((LPTBBUTTON)yyval.tvVal.cciValue)->idCommand = yypvt[-9].intVal;
			((LPTBBUTTON)yyval.tvVal.cciValue)->fsState = yypvt[-7].intVal;
			((LPTBBUTTON)yyval.tvVal.cciValue)->fsStyle = yypvt[-5].intVal;
			((LPTBBUTTON)yyval.tvVal.cciValue)->dwData = yypvt[-3].intVal;
			((LPTBBUTTON)yyval.tvVal.cciValue)->iString = yypvt[-1].intVal;
		
} break;

case YYr24: {	/* parameter :  YTBBI '(' YINT ',' intbmval ',' YINT ',' YINT ',' intbmval ',' intbmval ',' YINT ',' YINT ',' YSTR ',' YINT ')' */
#line 274 "../Parser/cci.y"

			yyval.tvVal.cciType = LPTBBUTTONINFOVI;
			yyval.tvVal.cciValue = malloc(sizeof(TBBUTTONINFO));
			CCIMemTrack(yyval.tvVal.cciValue);
			((LPTBBUTTONINFO)yyval.tvVal.cciValue)->cbSize = yypvt[-19].intVal;
			((LPTBBUTTONINFO)yyval.tvVal.cciValue)->dwMask = yypvt[-17].intVal;
			((LPTBBUTTONINFO)yyval.tvVal.cciValue)->idCommand = yypvt[-15].intVal;
			((LPTBBUTTONINFO)yyval.tvVal.cciValue)->iImage = yypvt[-13].intVal;
			((LPTBBUTTONINFO)yyval.tvVal.cciValue)->fsState = yypvt[-11].intVal;
			((LPTBBUTTONINFO)yyval.tvVal.cciValue)->fsStyle = yypvt[-9].intVal;
			((LPTBBUTTONINFO)yyval.tvVal.cciValue)->cx = yypvt[-7].intVal;
			((LPTBBUTTONINFO)yyval.tvVal.cciValue)->lParam = yypvt[-5].intVal;
			((LPTBBUTTONINFO)yyval.tvVal.cciValue)->pszText = (LPSTR)malloc(STRBUFSIZE);
			CCIMemTrack(((LPTBBUTTONINFO)yyval.tvVal.cciValue)->pszText);
			strcpy(((LPTBBUTTONINFO)yyval.tvVal.cciValue)->pszText,yypvt[-3].szVal);
			((LPTBBUTTONINFO)yyval.tvVal.cciValue)->cchText = yypvt[-1].intVal;
		
} break;

case YYr25: {	/* parameter :  YTBSAVEPARAMS '(' YINT ',' YSTR ',' YSTR ')' */
#line 292 "../Parser/cci.y"

			yyval.tvVal.cciType = LPTBSAVEPARAMSVI;
			yyval.tvVal.cciValue = malloc(sizeof(TBSAVEPARAMS));
			CCIMemTrack(yyval.tvVal.cciValue);
			((TBSAVEPARAMS*)yyval.tvVal.cciValue)->hkr = (HKEY)yypvt[-5].intVal;
			(LPSTR)((TBSAVEPARAMS*)yyval.tvVal.cciValue)->pszSubKey = malloc(STRBUFSIZE);
			CCIMemTrack((LPSTR)((TBSAVEPARAMS*)yyval.tvVal.cciValue)->pszSubKey);
			strcpy((LPSTR)((TBSAVEPARAMS*)yyval.tvVal.cciValue)->pszSubKey,yypvt[-3].szVal);
			(LPSTR)((TBSAVEPARAMS*)yyval.tvVal.cciValue)->pszValueName = malloc(STRBUFSIZE);
			CCIMemTrack((LPSTR)((TBSAVEPARAMS*)yyval.tvVal.cciValue)->pszValueName);
			strcpy((LPSTR)((TBSAVEPARAMS*)yyval.tvVal.cciValue)->pszValueName,yypvt[-1].szVal);
		
} break;

case YYr26: {	/* parameter :  YTBADDBITMAP '(' YINT ',' YINT ')' */
#line 305 "../Parser/cci.y"

			yyval.tvVal.cciType = LPTBADDBITMAPVI;
			yyval.tvVal.cciValue = malloc(sizeof(TBADDBITMAP));
			CCIMemTrack(yyval.tvVal.cciValue);
			((LPTBADDBITMAP)yyval.tvVal.cciValue)->hInst = (HINSTANCE)yypvt[-3].intVal;
			((LPTBADDBITMAP)yyval.tvVal.cciValue)->nID = yypvt[-1].intVal;
		
} break;

case YYr27: {	/* parameter :  YTBREPLACEBITMAP '(' YINT ',' YINT ',' YINT ',' YINT ',' YINT ')' */
#line 313 "../Parser/cci.y"

			yyval.tvVal.cciType = LPTBREPLACEBITMAPVI;
			yyval.tvVal.cciValue = malloc(sizeof(TBREPLACEBITMAP));
			CCIMemTrack(yyval.tvVal.cciValue);
			((LPTBREPLACEBITMAP)yyval.tvVal.cciValue)->hInstOld = (HINSTANCE)yypvt[-9].intVal;
			((LPTBREPLACEBITMAP)yyval.tvVal.cciValue)->nIDOld = yypvt[-7].intVal;
			((LPTBREPLACEBITMAP)yyval.tvVal.cciValue)->hInstNew = (HINSTANCE)yypvt[-5].intVal;
			((LPTBREPLACEBITMAP)yyval.tvVal.cciValue)->nIDNew = yypvt[-3].intVal;
			((LPTBREPLACEBITMAP)yyval.tvVal.cciValue)->nButtons = yypvt[-1].intVal;
		
} break;

case YYr28: {	/* style :  YSTYLE '(' intbmval ',' intbmval ',' intbmval ',' intbmval ',' applystyle ')' */
#line 329 "../Parser/cci.y"

			g_pCCIResult->ccitWParam = STYLEV;
			g_pCCIResult->pWParam = (void*)malloc(sizeof(CCIStyle));
			CCIMemTrack(g_pCCIResult->pWParam);
			((CCIStyle*)g_pCCIResult->pWParam)->dStyleOn = yypvt[-9].intVal;	// Styles on
			((CCIStyle*)g_pCCIResult->pWParam)->dStyleOff = yypvt[-7].intVal;	// Styles off
			((CCIStyle*)g_pCCIResult->pWParam)->dExStyleOn = yypvt[-5].intVal; // Exstyles on
			((CCIStyle*)g_pCCIResult->pWParam)->dExStyleOff = yypvt[-3].intVal; // Exstyles off
			((CCIStyle*)g_pCCIResult->pWParam)->bRecreate = yypvt[-1].intVal; // Recreate or SetWindowLong
		
} break;

case YYr29: {	/* applystyle :  YSETWINLONG */
#line 344 "../Parser/cci.y"

			yyval.intVal = FALSE;
		
} break;

case YYr30: {	/* applystyle :  YRECREATE */
#line 349 "../Parser/cci.y"

			yyval.intVal = TRUE;
		
} break;

case YYr31: {	/* intbmval :  intbmval '|' YINT */
#line 355 "../Parser/cci.y"

			yyval.intVal = yyval.intVal | yypvt[0].intVal;
		
} break;
#line 314 "/progra~1/mks/etc/yyparse.c"
	case YYrACCEPT:
		YYACCEPT;
	case YYrERROR:
		goto yyError;
	}

	/*
	 *	Look up next state in goto table.
	 */

	yyp = &yygo[yypgo[yyi]];
	yyq = yyp++;
	yyi = *yyps;
	while (yyi < *yyp++)
		;

	yystate = ~(yyi == *--yyp? YYQYYP: *yyq);
#if YYDEBUG
	if (yydebug)
		YY_TRACE(yyShowGoto)
#endif
	goto yyStack;

yyerrlabel:	;		/* come here from YYERROR	*/
/*
#pragma used yyerrlabel
 */
	yyerrflag = 1;
	if (yyi == YYrERROR) {
		yyps--;
		yypv--;
#if YYDEBUG
		yytp--;
#endif
	}

yyError:
	switch (yyerrflag) {

	case 0:		/* new error */
		yynerrs++;
		yyi = yychar;
		yyerror("Syntax error");
		if (yyi != yychar) {
			/* user has changed the current token */
			/* try again */
			yyerrflag++;	/* avoid loops */
			goto yyEncore;
		}

	case 1:		/* partially recovered */
	case 2:
		yyerrflag = 3;	/* need 3 valid shifts to recover */
			
		/*
		 *	Pop states, looking for a
		 *	shift on `error'.
		 */

		for ( ; yyps > yys; yyps--, yypv--
#if YYDEBUG
					, yytp--
#endif
		) {
#ifdef YACC_WINDOWS
			if (*yyps >= Sizeof_yypact)
#else /* YACC_WINDOWS */
			if (*yyps >= sizeof yypact/sizeof yypact[0])
#endif /* YACC_WINDOWS */
				continue;
			yyp = &yyact[yypact[*yyps]];
			yyq = yyp;
			do
				;
			while (YYERRCODE < *yyp++);

			if (YYERRCODE == yyp[-1]) {
				yystate = ~YYQYYP;
				goto yyStack;
			}
				
			/* no shift in this state */
#if YYDEBUG
			if (yydebug && yyps > yys+1)
				YY_TRACE(yyShowErrRecovery)
#endif
			/* pop stacks; try again */
		}
		/* no shift on error - abort */
		break;

	case 3:
		/*
		 *	Erroneous token after
		 *	an error - discard it.
		 */

		if (yychar == 0)  /* but not EOF */
			break;
#if YYDEBUG
		if (yydebug)
			YY_TRACE(yyShowErrDiscard)
#endif
		yyclearin;
		goto yyEncore;	/* try again in same state */
	}
	YYABORT;

#ifdef YYALLOC
yyReturn:
	yylval = save_yylval;
	yyval = save_yyval;
	yypvt = save_yypvt;
	yychar = save_yychar;
	yyerrflag = save_yyerrflag;
	yynerrs = save_yynerrs;
	free((char *)yys);
	free((char *)yyv);
#if YYDEBUG
	free((char *)yytypev);
#endif
	return(retval);
#endif
}

		
#if YYDEBUG
/*
 * Return type of token
 */
int
yyGetType(tok)
int tok;
{
	yyNamedType * tp;
	for (tp = &yyTokenTypes[yyntoken-1]; tp > yyTokenTypes; tp--)
		if (tp->token == tok)
			return tp->type;
	return 0;
}
/*
 * Print a token legibly.
 */
char *
yyptok(tok)
int tok;
{
	yyNamedType * tp;
	for (tp = &yyTokenTypes[yyntoken-1]; tp > yyTokenTypes; tp--)
		if (tp->token == tok)
			return tp->name;
	return "";
}

/*
 * Read state 'num' from YYStatesFile
 */
#ifdef YYTRACE

static char *
yygetState(num)
int num;
{
	int	size;
	static FILE *yyStatesFile = (FILE *) 0;
	static char yyReadBuf[YYMAX_READ+1];

	if (yyStatesFile == (FILE *) 0
	 && (yyStatesFile = fopen(YYStatesFile, "r")) == (FILE *) 0)
		return "yyExpandName: cannot open states file";

	if (num < yynstate - 1)
		size = (int)(yyStates[num+1] - yyStates[num]);
	else {
		/* length of last item is length of file - ptr(last-1) */
		if (fseek(yyStatesFile, 0L, 2) < 0)
			goto cannot_seek;
		size = (int) (ftell(yyStatesFile) - yyStates[num]);
	}
	if (size < 0 || size > YYMAX_READ)
		return "yyExpandName: bad read size";
	if (fseek(yyStatesFile, yyStates[num], 0) < 0) {
	cannot_seek:
		return "yyExpandName: cannot seek in states file";
	}

	(void) fread(yyReadBuf, 1, size, yyStatesFile);
	yyReadBuf[size] = '\0';
	return yyReadBuf;
}
#endif /* YYTRACE */
/*
 * Expand encoded string into printable representation
 * Used to decode yyStates and yyRules strings.
 * If the expansion of 's' fits in 'buf', return 1; otherwise, 0.
 */
int
yyExpandName(num, isrule, buf, len)
int num, isrule;
char * buf;
int len;
{
	int	i, n, cnt, type;
	char	* endp, * cp;
	char	*s;

	if (isrule)
		s = yyRules[num].name;
	else
#ifdef YYTRACE
		s = yygetState(num);
#else
		s = "*no states*";
#endif

	for (endp = buf + len - 8; *s; s++) {
		if (buf >= endp) {		/* too large: return 0 */
		full:	(void) strcpy(buf, " ...\n");
			return 0;
		} else if (*s == '%') {		/* nonterminal */
			type = 0;
			cnt = yynvar;
			goto getN;
		} else if (*s == '&') {		/* terminal */
			type = 1;
			cnt = yyntoken;
		getN:
			if (cnt < 100)
				i = 2;
			else if (cnt < 1000)
				i = 3;
			else
				i = 4;
			for (n = 0; i-- > 0; )
				n = (n * 10) + *++s - '0';
			if (type == 0) {
				if (n >= yynvar)
					goto too_big;
				cp = yysvar[n];
			} else if (n >= yyntoken) {
			    too_big:
				cp = "<range err>";
			} else
				cp = yyTokenTypes[n].name;

			if ((i = strlen(cp)) + buf > endp)
				goto full;
			(void) strcpy(buf, cp);
			buf += i;
		} else
			*buf++ = *s;
	}
	*buf = '\0';
	return 1;
}
#ifndef YYTRACE
/*
 * Show current state of yyparse
 */
void
yyShowState(tp)
yyTraceItems * tp;
{
	short * p;
	YYSTYPE * q;

	printf(
	    m_textmsg(2828, "state %d (%d), char %s (%d)\n", "I num1 num2 char num3"),
	      yysmap[tp->state], tp->state,
	      yyptok(tp->lookahead), tp->lookahead);
}
/*
 * show results of reduction
 */
void
yyShowReduce(tp)
yyTraceItems * tp;
{
	printf("reduce %d (%d), pops %d (%d)\n",
		yyrmap[tp->rule], tp->rule,
		tp->states[tp->nstates - tp->npop],
		yysmap[tp->states[tp->nstates - tp->npop]]);
}
void
yyShowRead(val)
int val;
{
	printf(m_textmsg(2829, "read %s (%d)\n", "I token num"), yyptok(val), val);
}
void
yyShowGoto(tp)
yyTraceItems * tp;
{
	printf(m_textmsg(2830, "goto %d (%d)\n", "I num1 num2"), yysmap[tp->state], tp->state);
}
void
yyShowShift(tp)
yyTraceItems * tp;
{
	printf(m_textmsg(2831, "shift %d (%d)\n", "I num1 num2"), yysmap[tp->state], tp->state);
}
void
yyShowErrRecovery(tp)
yyTraceItems * tp;
{
	short	* top = tp->states + tp->nstates - 1;

	printf(
	m_textmsg(2832, "Error recovery pops state %d (%d), uncovers %d (%d)\n", "I num1 num2 num3 num4"),
		yysmap[*top], *top, yysmap[*(top-1)], *(top-1));
}
void
yyShowErrDiscard(tp)
yyTraceItems * tp;
{
	printf(m_textmsg(2833, "Error recovery discards %s (%d), ", "I token num"),
		yyptok(tp->lookahead), tp->lookahead);
}
#endif	/* ! YYTRACE */
#endif	/* YYDEBUG */
