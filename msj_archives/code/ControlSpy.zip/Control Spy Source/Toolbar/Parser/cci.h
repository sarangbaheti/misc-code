// Cci.h : Parser include

// Control Spy: Toolbar

// Mark J. Finocchio (markfi), Microsoft Corporation

// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) 1998 Microsoft Corporation.  All Rights Reserved.

// Defines
#define CCITYPE		BYTE
#define STRBUFSIZE	128
#define ERRBUFSIZE	128
#define TEMPFILE	"c:\\cciparse.tmp"
#define SIGTEMP		0
#define SIGDESC		1
#define ALLOCMAX	32

#define VUNKNOWN	0
#define VMSGID		1
#define VINT		2
#define VLPTCBK		3

#define NOV				0	// Non-Parse type
#define ERRV			1	// Non-Parse type
#define SUCCESSV		2	// Non-Parse type
#define BITMASKV		3	// Non-Parse type
#define	NUMV			4	// Parse type
#define BOOLV			5	// Parse type
#define LPSTRV			6	// Parse type
#define LPSTRVI			7	// Parse type
// >> Start control specific
#define TBBUTTONSIZEV	8	// Non-Parse type, Param
#define BITMAPFLAGV		9	// Non-Parse type, Return
#define INSTANCEV		10	// Non-Parse type, Param
#define LOHIV			11	// Non-Parse type, Return
#define MAKELONGV		12	// Non-Parse type, Param
#define MAKEWPARAMV		13	// Non-Parse type, Param
#define MAKELPARAMV		14	// Non-Parse type, Param
#define IMAGELISTV		15	// Non-Parse type, Param
#define DISABLEDILV		16	// Non-Parse type, Param
#define HOTILV			17	// Non-Parse type, Param
#define TOOLTIPV		18	// Non-Parse type, Param
#define PARENTV			19	// Non-Parse type, Param
#define ONEV			20	// Non-Parse type, Param
// << End control specific
// >> Start control specific
#define RGBV			21	// Parse type
#define LPRECTV			22	// Parse type
#define LPSIZEV			23	// Parse type
#define LPPOINTVI		24	// Parse type
#define LPINTBUFV		25	// Parse type
#define LPTBINSERTMARKV	26	// Parse type
#define LPTBINSERTMARKVI 27	// Parse type
#define LPCOLORSCHEMEVI	28	// Parse type
#define LPTBBUTTONV		29	// Parse type
#define LPTBBUTTONVI	30	// Parse type
#define LPTBBUTTONINFOVI 31 // Parse type
#define LPTBSAVEPARAMSVI 32	// Parse type
#define LPTBADDBITMAPVI	33	// Parse type
#define LPTBREPLACEBITMAPVI	34	// Parse type
// << End control specific

#define STYLEV			(CCITYPE)-1	// Non-Parse type, non rendering nor display

// Typedefs
typedef struct tagCCITypeVal
{
	CCITYPE	cciType;
	void*	cciValue;
} CCITypeVal;

typedef struct tagCCIStyle
{
	LONG dStyleOn;
	LONG dStyleOff;
	LONG dExStyleOn;
	LONG dExStyleOff;
	BOOL bRecreate;
} CCIStyle;

typedef struct tagCCIResult
{
	LPSTR pInput;

	UINT dMsgNo;

	CCITYPE ccitWParam;
	CCITYPE ccitLParam;

	void* pWParam;
	void* pLParam;

	LPSTR pError;
	int dErrLine;
} CCIResult;


// Global variables
extern HIMAGELIST g_hImageList;
extern HIMAGELIST g_hDisabledIL;
extern HIMAGELIST g_hHotIL;
extern HWND g_hToolTip;
extern HWND g_hDialog;
extern HWND g_hContainer;
extern HWND g_hInstance;
extern HKEY g_hSaveResKey;
extern LPSTR g_pSignature[][2];
extern void* g_pMemTrack[];

// Function prototypes
CCIResult* CCIInterpret(LPSTR);
void CCIRender(CCITYPE,void*,LPSTR);
void CCIDestroy(CCIResult*);
void CCIDestroyHelper(CCITYPE,void*);
LPSTR CCIGetSignature(BYTE,BYTE);
void CCIMemTrack(void*);
