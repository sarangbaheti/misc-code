/* \program files\mks\mksnt\lex -o ../Parser/lex_yy.c -P /progra~1/mks/etc/yylex.c ../Parser/cci.l */
#define YYNEWLINE 10
#define INITIAL 0
#define yy_endst 226
#define yy_nxtmax 798
#define YY_LA_SIZE 29

static unsigned short yy_la_act[] = {
 35, 38, 35, 38, 35, 38, 35, 38, 35, 38, 35, 38, 35, 38, 38, 35,
 38, 35, 38, 38, 8, 38, 35, 38, 35, 38, 35, 38, 35, 38, 35, 38,
 35, 38, 35, 38, 35, 38, 35, 38, 35, 38, 38, 37, 38, 37, 38, 36,
 36, 35, 35, 35, 35, 35, 33, 35, 35, 35, 35, 31, 35, 35, 35, 35,
 35, 35, 35, 35, 35, 30, 35, 35, 35, 35, 35, 27, 35, 35, 35, 35,
 35, 35, 35, 35, 35, 29, 35, 35, 35, 35, 35, 26, 35, 35, 35, 35,
 35, 25, 35, 35, 35, 35, 35, 35, 35, 32, 35, 35, 35, 35, 34, 35,
 35, 35, 35, 35, 35, 28, 35, 35, 35, 24, 35, 35, 35, 35, 35, 35,
 35, 35, 35, 35, 18, 35, 35, 35, 35, 16, 35, 35, 35, 9, 35, 8,
 35, 35, 35, 7, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35,
 35, 35, 35, 35, 35, 35, 35, 23, 35, 35, 35, 35, 35, 35, 35, 35,
 22, 35, 35, 35, 35, 35, 35, 35, 35, 35, 21, 35, 35, 35, 35, 35,
 19, 35, 35, 35, 35, 20, 35, 35, 35, 35, 35, 35, 35, 35, 35, 17,
 35, 35, 6, 35, 5, 35, 35, 35, 35, 4, 35, 35, 35, 35, 35, 35,
 35, 3, 35, 35, 35, 13, 35, 35, 14, 35, 35, 35, 35, 35, 35, 35,
 35, 35, 35, 2, 35, 35, 35, 35, 1, 35, 35, 35, 15, 35, 35, 0,
 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 11, 35, 35, 35, 35, 35,
 35, 12, 35, 35, 10, 35, 0
};

static unsigned char yy_look[] = {
 0
};

static short yy_final[] = {
 0, 0, 2, 4, 6, 8, 10, 12, 14, 15, 17, 19, 20, 22, 24, 26,
 28, 30, 32, 34, 36, 38, 40, 42, 43, 45, 46, 47, 48, 49, 50, 51,
 52, 53, 54, 56, 57, 58, 59, 61, 62, 63, 64, 65, 66, 67, 68, 69,
 71, 72, 73, 74, 75, 77, 78, 79, 80, 81, 82, 83, 84, 85, 87, 88,
 89, 90, 91, 93, 94, 95, 96, 97, 99, 100, 101, 102, 103, 104, 105, 107,
 108, 109, 110, 112, 113, 114, 115, 116, 117, 119, 120, 121, 123, 124, 125, 126,
 127, 128, 129, 130, 131, 132, 134, 135, 136, 137, 139, 140, 141, 143, 144, 145,
 146, 147, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162,
 163, 164, 165, 166, 167, 169, 170, 171, 172, 173, 174, 175, 176, 178, 179, 180,
 181, 182, 183, 184, 185, 186, 188, 189, 190, 191, 192, 194, 195, 196, 197, 199,
 200, 201, 202, 203, 204, 205, 206, 207, 209, 210, 212, 212, 213, 214, 215, 216,
 217, 219, 220, 221, 222, 223, 224, 225, 227, 228, 229, 231, 232, 234, 235, 236,
 237, 238, 239, 240, 241, 242, 243, 245, 246, 247, 248, 250, 251, 252, 254, 255,
 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 268, 269, 270, 271, 272, 273,
 275, 276, 278
};
#ifndef yy_state_t
#define yy_state_t unsigned char
#endif

static yy_state_t yy_begin[] = {
 0, 0, 0
};

static yy_state_t yy_next[] = {
 26, 26, 26, 26, 26, 26, 26, 26, 26, 24, 25, 26, 26, 24, 26, 26,
 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26,
 24, 26, 8, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 11, 26, 23,
 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 26, 26, 26, 26, 26, 26,
 26, 22, 7, 15, 19, 22, 10, 22, 20, 17, 22, 22, 22, 1, 13, 22,
 14, 22, 5, 3, 9, 22, 22, 22, 22, 22, 22, 26, 26, 26, 26, 22,
 26, 22, 7, 18, 19, 22, 22, 22, 20, 17, 22, 22, 22, 2, 22, 22,
 21, 22, 6, 4, 16, 22, 22, 22, 22, 22, 22, 26, 26, 26, 26, 26,
 25, 25, 27, 93, 25, 94, 95, 96, 97, 98, 99, 100, 101, 28, 28, 28,
 28, 28, 28, 28, 28, 28, 28, 25, 28, 28, 28, 28, 28, 28, 28, 28,
 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28,
 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28,
 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28,
 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28,
 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28,
 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28,
 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 29, 29, 29,
 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29,
 29, 29, 29, 29, 29, 29, 29, 30, 31, 32, 33, 29, 34, 29, 29, 29,
 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29,
 29, 29, 29, 29, 29, 29, 29, 30, 31, 32, 33, 35, 34, 36, 37, 38,
 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 54, 53,
 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 35, 66, 36, 37, 38,
 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 54, 53,
 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 67, 66, 68, 69, 70,
 71, 72, 74, 75, 76, 77, 78, 79, 81, 82, 84, 85, 86, 87, 73, 88,
 80, 89, 90, 91, 83, 92, 103, 104, 105, 48, 106, 67, 107, 68, 69, 70,
 71, 72, 74, 75, 76, 77, 78, 79, 81, 82, 84, 85, 86, 87, 73, 88,
 80, 89, 90, 91, 83, 30, 108, 110, 111, 48, 112, 113, 121, 122, 123, 124,
 125, 115, 126, 102, 109, 109, 109, 109, 109, 109, 109, 109, 109, 109, 73, 127,
 128, 114, 119, 117, 129, 30, 130, 131, 132, 133, 116, 134, 80, 135, 136, 137,
 138, 72, 139, 120, 118, 140, 141, 142, 143, 144, 145, 146, 147, 148, 73, 149,
 151, 84, 152, 79, 153, 154, 155, 156, 157, 158, 159, 83, 80, 150, 160, 161,
 162, 163, 164, 165, 166, 167, 168, 169, 186, 204, 205, 209, 210, 211, 213, 214,
 215, 84, 216, 217, 218, 219, 220, 221, 212, 222, 223, 83, 170, 170, 170, 170,
 170, 170, 170, 170, 170, 170, 224, 170, 170, 170, 170, 170, 170, 170, 170, 170,
 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 171, 170,
 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170,
 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170,
 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170,
 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170,
 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170,
 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 172, 173, 174, 175,
 176, 177, 178, 179, 180, 181, 182, 183, 184, 187, 185, 179, 190, 188, 191, 192,
 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 225, 189, 172, 173, 174, 175,
 176, 177, 178, 179, 180, 181, 182, 183, 177, 178, 206, 179, 190, 207, 191, 192,
 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 190, 189, 208, 226, 203, 226,
 226, 226, 226, 226, 226, 226, 226, 226, 226, 189, 206, 226, 226, 207, 206, 226,
 226, 226, 226, 226, 226, 226, 226, 226, 226, 226, 190, 226, 226, 226, 226, 226,
 226, 226, 226, 226, 226, 226, 226, 226, 226, 189, 226, 226, 226, 226, 206, 0

};

static yy_state_t yy_check[] = {
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 25, 25, 23, 92, 25, 93, 94, 95, 96, 97, 98, 99, 100, 27, 27, 27,
 27, 27, 27, 27, 27, 27, 27, 25, 27, 27, 27, 27, 27, 27, 27, 27,
 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27,
 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27,
 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27,
 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27,
 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27,
 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27,
 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 21, 30, 31, 32, 22, 33, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 21, 30, 31, 32, 20, 33, 35, 36, 37,
 19, 39, 40, 41, 42, 43, 44, 45, 46, 18, 48, 49, 50, 51, 17, 17,
 54, 55, 56, 57, 58, 59, 60, 53, 53, 63, 64, 20, 65, 35, 36, 37,
 19, 39, 40, 41, 42, 43, 44, 45, 46, 18, 48, 49, 50, 51, 17, 17,
 54, 55, 56, 57, 58, 59, 60, 53, 53, 63, 64, 62, 65, 67, 68, 69,
 70, 16, 73, 74, 75, 76, 77, 72, 80, 81, 79, 84, 85, 86, 16, 87,
 72, 83, 89, 90, 79, 15, 102, 103, 104, 15, 13, 62, 106, 67, 68, 69,
 70, 16, 73, 74, 75, 76, 77, 72, 80, 81, 79, 84, 85, 86, 16, 87,
 72, 83, 89, 90, 79, 14, 107, 10, 110, 15, 111, 112, 120, 121, 122, 123,
 124, 9, 125, 14, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 9, 126,
 127, 9, 115, 115, 128, 14, 129, 130, 131, 119, 115, 133, 115, 134, 135, 136,
 137, 9, 138, 115, 115, 139, 118, 141, 142, 143, 144, 145, 146, 147, 9, 148,
 150, 117, 151, 115, 152, 153, 154, 155, 156, 157, 116, 117, 115, 117, 159, 160,
 161, 162, 163, 164, 165, 166, 114, 168, 185, 203, 204, 208, 209, 210, 212, 213,
 214, 117, 215, 216, 211, 211, 219, 220, 210, 221, 222, 117, 8, 8, 8, 8,
 8, 8, 8, 8, 8, 8, 218, 8, 8, 8, 8, 8, 8, 8, 8, 8,
 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 7, 172, 173, 174,
 175, 6, 177, 178, 179, 180, 181, 182, 5, 184, 5, 187, 4, 187, 190, 191,
 192, 193, 194, 195, 196, 197, 189, 199, 200, 201, 224, 4, 7, 172, 173, 174,
 175, 6, 177, 178, 179, 180, 181, 182, 5, 184, 2, 187, 4, 206, 190, 191,
 192, 193, 194, 195, 196, 197, 189, 199, 200, 201, 3, 4, 1, ~0, 3, ~0,
 ~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0, 3, 2, ~0, ~0, 206, 1, ~0,
 ~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0, 3, ~0, ~0, ~0, ~0, ~0,
 ~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0, ~0, 3, ~0, ~0, ~0, ~0, 1, 0

};

static yy_state_t yy_default[] = {
 226, 22, 22, 22, 22, 22, 22, 22, 226, 22, 22, 12, 226, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 226, 226, 25, 226, 226, 226, 27, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 12, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 8, 226, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
 22, 22, 0
};

static short yy_base[] = {
 0, 683, 647, 677, 631, 627, 620, 599, 556, 399, 390, 799, 420, 341, 388, 342,
 335, 273, 262, 263, 252, 230, 204, 83, 799, 119, 799, 141, 799, 799, 214, 228,
 220, 216, 799, 249, 261, 259, 799, 254, 273, 273, 264, 272, 274, 270, 268, 799,
 263, 274, 258, 280, 799, 276, 287, 282, 285, 279, 283, 274, 274, 799, 311, 295,
 277, 294, 799, 332, 320, 332, 331, 799, 341, 323, 327, 320, 332, 326, 799, 337,
 339, 320, 799, 344, 328, 339, 323, 346, 799, 328, 350, 799, 55, 54, 52, 52,
 69, 65, 69, 62, 71, 799, 349, 345, 340, 799, 352, 378, 799, 799, 380, 375,
 390, 799, 449, 417, 444, 440, 437, 421, 391, 381, 386, 398, 397, 397, 413, 407,
 400, 409, 422, 408, 799, 423, 427, 421, 411, 419, 433, 421, 799, 417, 435, 425,
 441, 425, 443, 432, 428, 799, 428, 430, 437, 439, 445, 441, 450, 442, 799, 443,
 458, 446, 445, 453, 466, 450, 458, 799, 466, 799, 799, 799, 615, 616, 618, 606,
 799, 623, 609, 623, 628, 610, 626, 799, 630, 470, 799, 617, 799, 621, 618, 616,
 631, 627, 630, 628, 630, 638, 799, 635, 643, 630, 799, 447, 469, 799, 662, 799,
 464, 471, 465, 469, 462, 478, 462, 481, 470, 799, 488, 485, 469, 488, 477, 799,
 643, 799, 799
};


#line 1 "/progra~1/mks/etc/yylex.c"
/*
 * Copyright 1988, 1992 by Mortice Kern Systems Inc.  All rights reserved.
 * All rights reserved.
 *
 * $Header: /u/rd/src/lex/RCS/yylex.c,v 1.44 1993/05/26 14:47:37 ignac Exp $
 *
 */
#include <stdlib.h>
#include <stdio.h>
#if	__STDC__
#define YY_ARGS(args)	args
#else
#define YY_ARGS(args)	()
#endif

#ifdef LEX_WINDOWS
#include <windows.h>

/*
 * define, if not already defined
 * the flag YYEXIT, which will allow
 * graceful exits from yylex()
 * without resorting to calling exit();
 */

#ifndef YYEXIT
#define YYEXIT	1
#endif

/*
 * the following is the handle to the current
 * instance of a windows program. The user
 * program calling yylex must supply this!
 */

extern HANDLE hInst;	

#endif	/* LEX_WINDOWS */

/*
 * Define m_textmsg() to an appropriate function for internationalized messages
 * or custom processing.
 */
#ifndef I18N
#define	m_textmsg(id, str, cls)	(str)
#else /*I18N*/
extern	char* m_textmsg YY_ARGS((int id, const char* str, char* cls));
#endif/*I18N*/

/*
 * Include string.h to get definition of memmove() and size_t.
 * If you do not have string.h or it does not declare memmove
 * or size_t, you will have to declare them here.
 */
#include <string.h>
/* Uncomment next line if memmove() is not declared in string.h */
/*extern char * memmove();*/
/* Uncomment next line if size_t is not available in stdio.h or string.h */
/*typedef unsigned size_t;*/
/* Drop this when LATTICE provides memmove */
#ifdef LATTICE
#define memmove	memcopy
#endif

/*
 * YY_STATIC determines the scope of variables and functions
 * declared by the lex scanner. It must be set with a -DYY_STATIC
 * option to the compiler (it cannot be defined in the lex program).
 */
#ifdef	YY_STATIC
/* define all variables as static to allow more than one lex scanner */
#define	YY_DECL	static
#else
/* define all variables as global to allow other modules to access them */
#define	YY_DECL	
#endif

/*
 * You can redefine yygetc. For YACC Tracing, compile this code
 * with -DYYTRACE to get input from yt_getc
 */
#ifdef YYTRACE
extern int	yt_getc YY_ARGS((void));
#define yygetc()	yt_getc()
#else
#define	yygetc()	getc(yyin) 	/* yylex input source */
#endif

/*
 * the following can be redefined by the user.
 */
#ifdef YYEXIT
#define	YY_FATAL(msg)	{ fprintf(yyout, "yylex: %s\n", msg); yyLexFatal = 1; }
#else /* YYEXIT */
#define	YY_FATAL(msg)	{ fprintf(stderr, "yylex: %s\n", msg); exit(1); }
#endif /* YYEXIT */

#define	ECHO		fputs(yytext, yyout)
#define	output(c)	putc((c), yyout) /* yylex sink for unmatched chars */
#define	YY_INTERACTIVE	1		/* save micro-seconds if 0 */
#define	YYLMAX		100		/* token and pushback buffer size */

/*
 * If %array is used (or defaulted), yytext[] contains the token.
 * If %pointer is used, yytext is a pointer to yy_tbuf[].
 */
YY_DECL char	yytext[YYLMAX+1];

#define	BEGIN		yy_start =
#define	REJECT		goto yy_reject
#define	NLSTATE		(yy_lastc = YYNEWLINE)
#define	YY_INIT \
	(yy_start = yyleng = yy_end = 0, yy_lastc = YYNEWLINE)
#define	yymore()	goto yy_more
#define	yyless(n)	if ((n) < 0 || (n) > yy_end) ; \
			else { YY_SCANNER; yyleng = (n); YY_USER; }

YY_DECL	void	yy_reset YY_ARGS((void));
YY_DECL	int	input	YY_ARGS((void));
YY_DECL	int	unput	YY_ARGS((int c));

/* functions defined in libl.lib */
extern	int	yywrap	YY_ARGS((void));
extern	void	yyerror	YY_ARGS((char *fmt, ...));
extern	void	yycomment	YY_ARGS((char *term));
extern	int	yymapch	YY_ARGS((int delim, int escape));

#line 16 "../Parser/cci.l"

// Included files
#include <windows.h>
#include <commctrl.h>
#include "cci.h"
#include "ytab.h"
#include "..\toolbar.h"

// Function prototypes
void stripquotes();

#line 128 "/progra~1/mks/etc/yylex.c"


#ifdef	YY_DEBUG
#undef	YY_DEBUG
#define	YY_DEBUG(fmt, a1, a2)	fprintf(stderr, fmt, a1, a2)
#else
#define	YY_DEBUG(fmt, a1, a2)
#endif

/*
 * The declaration for the lex scanner can be changed by
 * redefining YYLEX or YYDECL. This must be done if you have
 * more than one scanner in a program.
 */
#ifndef	YYLEX
#define	YYLEX yylex			/* name of lex scanner */
#endif

#ifndef YYDECL
#define	YYDECL	int YYLEX YY_ARGS((void))	/* declaration for lex scanner */
#endif

/*
 * stdin and stdout may not neccessarily be constants.
 * If stdin and stdout are constant, and you want to save a few cycles, then
 * #define YY_STATIC_STDIO 1 in this file or on the commandline when
 * compiling this file
 */
#ifndef YY_STATIC_STDIO
#define YY_STATIC_STDIO	0
#endif

#if YY_STATIC_STDIO
YY_DECL	FILE   *yyin = stdin;
YY_DECL	FILE   *yyout = stdout;
#else
YY_DECL	FILE   *yyin = (FILE *)0;
YY_DECL	FILE   *yyout = (FILE *)0;
#endif
YY_DECL	int	yylineno = 1;		/* line number */

/* yy_sbuf[0:yyleng-1] contains the states corresponding to yytext.
 * yytext[0:yyleng-1] contains the current token.
 * yytext[yyleng:yy_end-1] contains pushed-back characters.
 * When the user action routine is active,
 * yy_save contains yytext[yyleng], which is set to '\0'.
 * Things are different when YY_PRESERVE is defined. 
 */
static	yy_state_t yy_sbuf [YYLMAX+1];	/* state buffer */
static	int	yy_end = 0;		/* end of pushback */
static	int	yy_start = 0;		/* start state */
static	int	yy_lastc = YYNEWLINE;	/* previous char */
YY_DECL	int	yyleng = 0;		/* yytext token length */
#ifdef YYEXIT
static	int yyLexFatal;
#endif /* YYEXIT */

#ifndef YY_PRESERVE	/* the efficient default push-back scheme */

static	char yy_save;	/* saved yytext[yyleng] */

#define	YY_USER	{ /* set up yytext for user */ \
		yy_save = yytext[yyleng]; \
		yytext[yyleng] = 0; \
	}
#define	YY_SCANNER { /* set up yytext for scanner */ \
		yytext[yyleng] = yy_save; \
	}

#else		/* not-so efficient push-back for yytext mungers */

static	char yy_save [YYLMAX];
static	char *yy_push = yy_save+YYLMAX;

#define	YY_USER { \
		size_t n = yy_end - yyleng; \
		yy_push = yy_save+YYLMAX - n; \
		if (n > 0) \
			memmove(yy_push, yytext+yyleng, n); \
		yytext[yyleng] = 0; \
	}
#define	YY_SCANNER { \
		size_t n = yy_save+YYLMAX - yy_push; \
		if (n > 0) \
			memmove(yytext+yyleng, yy_push, n); \
		yy_end = yyleng + n; \
	}

#endif


#ifdef LEX_WINDOWS

/*
 * When using the windows features of lex,
 * it is necessary to load in the resources being
 * used, and when done with them, the resources must
 * be freed up, otherwise we have a windows app that
 * is not following the rules. Thus, to make yylex()
 * behave in a windows environment, create a new
 * yylex() which will call the original yylex() as
 * another function call. Observe ...
 */

/*
 * The actual lex scanner (usually yylex(void)).
 * NOTE: you should invoke yy_init() if you are calling yylex()
 * with new input; otherwise old lookaside will get in your way
 * and yylex() will die horribly.
 */
static int win_yylex();			/* prototype for windows yylex handler */

YYDECL {
	int wReturnValue;
	HANDLE hRes_table;
	unsigned short *old_yy_la_act;	/* remember previous pointer values */
	short *old_yy_final;
	yy_state_t *old_yy_begin;
	yy_state_t *old_yy_next;
	yy_state_t *old_yy_check;
	yy_state_t *old_yy_default;
	short *old_yy_base;

	/*
	 * the following code will load the required
	 * resources for a Windows based parser.
	 */

	hRes_table = LoadResource (hInst,
		FindResource (hInst, "UD_RES_yyLEX", "yyLEXTBL"));
	
	/*
	 * return an error code if any
	 * of the resources did not load
	 */

	if (hRes_table == NULL)
		return (0);
	
	/*
	 * the following code will lock the resources
	 * into fixed memory locations for the scanner
	 * (and remember previous pointer locations)
	 */

	old_yy_la_act = yy_la_act;
	old_yy_final = yy_final;
	old_yy_begin = yy_begin;
	old_yy_next = yy_next;
	old_yy_check = yy_check;
	old_yy_default = yy_default;
	old_yy_base = yy_base;

	yy_la_act = (unsigned short *)LockResource (hRes_table);
	yy_final = (short *)(yy_la_act + Sizeof_yy_la_act);
	yy_begin = (yy_state_t *)(yy_final + Sizeof_yy_final);
	yy_next = (yy_state_t *)(yy_begin + Sizeof_yy_begin);
	yy_check = (yy_state_t *)(yy_next + Sizeof_yy_next);
	yy_default = (yy_state_t *)(yy_check + Sizeof_yy_check);
	yy_base = (yy_state_t *)(yy_default + Sizeof_yy_default);


	/*
	 * call the standard yylex() code
	 */

	wReturnValue = win_yylex();

	/*
	 * unlock the resources
	 */

	UnlockResource (hRes_table);

	/*
	 * and now free the resource
	 */

	FreeResource (hRes_table);

	/*
	 * restore previously saved pointers
	 */

	yy_la_act = old_yy_la_act;
	yy_final = old_yy_final;
	yy_begin = old_yy_begin;
	yy_next = old_yy_next;
	yy_check = old_yy_check;
	yy_default = old_yy_default;
	yy_base = old_yy_base;

	return (wReturnValue);
}	/* end function */

static int win_yylex() {

#else /* LEX_WINDOWS */

/*
 * The actual lex scanner (usually yylex(void)).
 * NOTE: you should invoke yy_init() if you are calling yylex()
 * with new input; otherwise old lookaside will get in your way
 * and yylex() will die horribly.
 */
YYDECL {

#endif /* LEX_WINDOWS */

	register int c, i, yybase;
	unsigned	yyst;	/* state */
	int yyfmin, yyfmax;	/* yy_la_act indices of final states */
	int yyoldi, yyoleng;	/* base i, yyleng before look-ahead */
	int yyeof;		/* 1 if eof has already been read */

#line 342 "/progra~1/mks/etc/yylex.c"



#if !YY_STATIC_STDIO
	if (yyin == (FILE *)0)
		yyin = stdin;
	if (yyout == (FILE *)0)
		yyout = stdout;
#endif

#ifdef YYEXIT
	yyLexFatal = 0;
#endif /* YYEXIT */

	yyeof = 0;
	i = yyleng;
	YY_SCANNER;

  yy_again:
	yyleng = i;
	/* determine previous char. */
	if (i > 0)
		yy_lastc = yytext[i-1];
	/* scan previously accepted token adjusting yylineno */
	while (i > 0)
		if (yytext[--i] == YYNEWLINE)
			yylineno++;
	/* adjust pushback */
	yy_end -= yyleng;
	memmove(yytext, yytext+yyleng, (size_t) yy_end);
	i = 0;

  yy_contin:
	yyoldi = i;

	/* run the state machine until it jams */
	yyst = yy_begin[yy_start + (yy_lastc == YYNEWLINE)];
	yy_sbuf[i] = (yy_state_t) yyst;
	do {
		YY_DEBUG(m_textmsg(1547, "<state %d, i = %d>\n", "I num1 num2"), yyst, i);
		if (i >= YYLMAX) {
			YY_FATAL(m_textmsg(1548, "Token buffer overflow", "E"));
#ifdef YYEXIT
			if (yyLexFatal)
				return -2;
#endif /* YYEXIT */
		}	/* endif */

		/* get input char */
		if (i < yy_end)
			c = yytext[i];		/* get pushback char */
		else if (!yyeof && (c = yygetc()) != EOF) {
			yy_end = i+1;
			yytext[i] = (char) c;
		} else /* c == EOF */ {
			c = EOF;		/* just to make sure... */
			if (i == yyoldi) {	/* no token */
				yyeof = 0;
				if (yywrap())
					return 0;
				else
					goto yy_again;
			} else {
				yyeof = 1;	/* don't re-read EOF */
				break;
			}
		}
		YY_DEBUG(m_textmsg(1549, "<input %d = 0x%02x>\n", "I num hexnum"), c, c);

		/* look up next state */
		while ((yybase = yy_base[yyst]+(unsigned char)c) > yy_nxtmax
		    || yy_check[yybase] != (yy_state_t) yyst) {
			if (yyst == yy_endst)
				goto yy_jammed;
			yyst = yy_default[yyst];
		}
		yyst = yy_next[yybase];
	  yy_jammed: ;
	  yy_sbuf[++i] = (yy_state_t) yyst;
	} while (!(yyst == yy_endst || YY_INTERACTIVE && yy_base[yyst] > yy_nxtmax && yy_default[yyst] == yy_endst));
	YY_DEBUG(m_textmsg(1550, "<stopped %d, i = %d>\n", "I num1 num2"), yyst, i);
	if (yyst != yy_endst)
		++i;

  yy_search:
	/* search backward for a final state */
	while (--i > yyoldi) {
		yyst = yy_sbuf[i];
		if ((yyfmin = yy_final[yyst]) < (yyfmax = yy_final[yyst+1]))
			goto yy_found;	/* found final state(s) */
	}
	/* no match, default action */
	i = yyoldi + 1;
	output(yytext[yyoldi]);
	goto yy_again;

  yy_found:
	YY_DEBUG(m_textmsg(1551, "<final state %d, i = %d>\n", "I num1 num2"), yyst, i);
	yyoleng = i;		/* save length for REJECT */
	
	/* pushback look-ahead RHS */
	if ((c = (int)(yy_la_act[yyfmin]>>9) - 1) >= 0) { /* trailing context? */
		unsigned char *bv = yy_look + c*YY_LA_SIZE;
		static unsigned char bits [8] = {
			1<<0, 1<<1, 1<<2, 1<<3, 1<<4, 1<<5, 1<<6, 1<<7
		};
		while (1) {
			if (--i < yyoldi) {	/* no / */
				i = yyoleng;
				break;
			}
			yyst = yy_sbuf[i];
			if (bv[(unsigned)yyst/8] & bits[(unsigned)yyst%8])
				break;
		}
	}

	/* perform action */
	yyleng = i;
	YY_USER;
	switch (yy_la_act[yyfmin] & 0777) {
	case 0:
#line 34 "../Parser/cci.l"
	{ return YMSG; }
	break;
	case 1:
#line 35 "../Parser/cci.l"
	{ return YSTYLE; }
	break;
	case 2:
#line 36 "../Parser/cci.l"
	{
							  return YSETWINLONG;
							}
	break;
	case 3:
#line 39 "../Parser/cci.l"
	{
							  return YRECREATE;
							}
	break;
	case 4:
#line 45 "../Parser/cci.l"
	{ return YSTRBUF; }
	break;
	case 5:
#line 47 "../Parser/cci.l"
	{ 
								UINT x;
								strcpy(yylval.szVal,yytext); 
								// Remove quotes
								for(x=0;x<strlen((LPSTR)(yylval.szVal))-2;x++)
									((LPSTR)(yylval.szVal))[x] = ((LPSTR)(yylval.szVal))[x+1];
								((LPSTR)(yylval.szVal))[x] = '\0';
								return YSTR; 
							}
	break;
	case 6:
#line 57 "../Parser/cci.l"
	{ yylval.intVal=TRUE; return YBOOL; }
	break;
	case 7:
#line 58 "../Parser/cci.l"
	{ yylval.intVal=FALSE; return YBOOL; }
	break;
	case 8:
#line 60 "../Parser/cci.l"
	{ yylval.intVal=atoi(yytext); return YINT; }
	break;
	case 9:
#line 62 "../Parser/cci.l"
	{ yylval.intVal=(INT)NULL; return YNULL; }
	break;
	case 10:
#line 67 "../Parser/cci.l"
	{ return YMAKELONG; }
	break;
	case 11:
#line 68 "../Parser/cci.l"
	{ return YMAKEWPARAM; }
	break;
	case 12:
#line 69 "../Parser/cci.l"
	{ return YMAKELPARAM; }
	break;
	case 13:
#line 70 "../Parser/cci.l"
	{ return YRGB; }
	break;
	case 14:
#line 71 "../Parser/cci.l"
	{ return YRECT; }
	break;
	case 15:
#line 72 "../Parser/cci.l"
	{ return YSIZE; }
	break;
	case 16:
#line 73 "../Parser/cci.l"
	{ return YPOINT; }
	break;
	case 17:
#line 74 "../Parser/cci.l"
	{ return YTBINSERTMARK; }
	break;
	case 18:
#line 75 "../Parser/cci.l"
	{ return YCOLORSCHEME; }
	break;
	case 19:
#line 76 "../Parser/cci.l"
	{ return YTBB; }
	break;
	case 20:
#line 77 "../Parser/cci.l"
	{ return YTBBI; }
	break;
	case 21:
#line 78 "../Parser/cci.l"
	{ return YTBSAVEPARAMS; }
	break;
	case 22:
#line 79 "../Parser/cci.l"
	{ return YTBADDBITMAP; }
	break;
	case 23:
#line 80 "../Parser/cci.l"
	{ return YTBREPLACEBITMAP; }
	break;
	case 24:
#line 84 "../Parser/cci.l"
	{
								yylval.intVal=sizeof(TBBUTTON); return YINT; }
	break;
	case 25:
#line 86 "../Parser/cci.l"
	{
								yylval.intVal=(INT)g_hInstance; return YINT; }
	break;
	case 26:
#line 88 "../Parser/cci.l"
	{ return YINTBUF; }
	break;
	case 27:
#line 89 "../Parser/cci.l"
	{ yylval.intVal=(INT)sizeof(COLORSCHEME); return YINT; }
	break;
	case 28:
#line 90 "../Parser/cci.l"
	{
								yylval.intVal=sizeof(TBBUTTONINFO); return YINT; }
	break;
	case 29:
#line 92 "../Parser/cci.l"
	{
								yylval.intVal=(INT)g_hImageList; return YINT; }
	break;
	case 30:
#line 94 "../Parser/cci.l"
	{
								yylval.intVal=(INT)g_hDisabledIL; return YINT; }
	break;
	case 31:
#line 96 "../Parser/cci.l"
	{ yylval.intVal=(INT)g_hHotIL; return YINT; };
	break;
	case 32:
#line 97 "../Parser/cci.l"
	{
								yylval.intVal=(INT)g_hToolTip; return YINT; }
	break;
	case 33:
#line 99 "../Parser/cci.l"
	{ yylval.intVal=(INT)g_hContainer; return YINT; }
	break;
	case 34:
#line 100 "../Parser/cci.l"
	{ yylval.intVal=(INT)g_hSaveResKey; return YINT; }
	break;
	case 35:
#line 105 "../Parser/cci.l"
	{
								int dType;
								yylval.intVal = GetValue(yytext,&dType);
								switch(dType)
								{
									case VMSGID:
										return YMSGID;
									case VINT:
										return YINT;
								}
								return YUNKNOWN;
							}
	break;
	case 36:
#line 120 "../Parser/cci.l"
	{ ; }
	break;
	case 37:
#line 124 "../Parser/cci.l"
	{ ; }
	break;
	case 38:
#line 128 "../Parser/cci.l"
	{ return *yytext; }
	break;

#line 463 "/progra~1/mks/etc/yylex.c"

	}
	YY_SCANNER;
	i = yyleng;
	goto yy_again;			/* action fell though */

  yy_reject:
	YY_SCANNER;
	i = yyoleng;			/* restore original yytext */
	if (++yyfmin < yyfmax)
		goto yy_found;		/* another final state, same length */
	else
		goto yy_search;		/* try shorter yytext */

  yy_more:
	YY_SCANNER;
	i = yyleng;
	if (i > 0)
		yy_lastc = yytext[i-1];
	goto yy_contin;
}
/*
 * Safely switch input stream underneath LEX
 */
typedef struct yy_save_block_tag {
	FILE	* oldfp;
	int	oldline;
	int	oldend;
	int	oldstart;
	int	oldlastc;
	int	oldleng;
	char	savetext[YYLMAX+1];
	yy_state_t	savestate[YYLMAX+1];
} YY_SAVED;

YY_SAVED *
yySaveScan(fp)
FILE * fp;
{
	YY_SAVED * p;

	if ((p = (YY_SAVED *) malloc(sizeof(*p))) == NULL)
		return p;

	p->oldfp = yyin;
	p->oldline = yylineno;
	p->oldend = yy_end;
	p->oldstart = yy_start;
	p->oldlastc = yy_lastc;
	p->oldleng = yyleng;
	(void) memcpy(p->savetext, yytext, sizeof yytext);
	(void) memcpy((char *) p->savestate, (char *) yy_sbuf,
		sizeof yy_sbuf);

	yyin = fp;
	yylineno = 1;
	YY_INIT;

	return p;
}
/*f
 * Restore previous LEX state
 */
void
yyRestoreScan(p)
YY_SAVED * p;
{
	if (p == NULL)
		return;
	yyin = p->oldfp;
	yylineno = p->oldline;
	yy_end = p->oldend;
	yy_start = p->oldstart;
	yy_lastc = p->oldlastc;
	yyleng = p->oldleng;

	(void) memcpy(yytext, p->savetext, sizeof yytext);
	(void) memcpy((char *) yy_sbuf, (char *) p->savestate,
		sizeof yy_sbuf);
	free(p);
}
/*
 * User-callable re-initialization of yylex()
 */
void
yy_reset()
{
	YY_INIT;
	yylineno = 1;		/* line number */
}
/* get input char with pushback */
YY_DECL int
input()
{
	int c;
#ifndef YY_PRESERVE
	if (yy_end > yyleng) {
		yy_end--;
		memmove(yytext+yyleng, yytext+yyleng+1,
			(size_t) (yy_end-yyleng));
		c = yy_save;
		YY_USER;
#else
	if (yy_push < yy_save+YYLMAX) {
		c = *yy_push++;
#endif
	} else
		c = yygetc();
	yy_lastc = c;
	if (c == YYNEWLINE)
		yylineno++;
	return c;
}

/*f
 * pushback char
 */
YY_DECL int
unput(c)
	int c;
{
#ifndef YY_PRESERVE
	if (yy_end >= YYLMAX) {
		YY_FATAL(m_textmsg(1552, "Push-back buffer overflow", "E"));
	} else {
		if (yy_end > yyleng) {
			yytext[yyleng] = yy_save;
			memmove(yytext+yyleng+1, yytext+yyleng,
				(size_t) (yy_end-yyleng));
			yytext[yyleng] = 0;
		}
		yy_end++;
		yy_save = (char) c;
#else
	if (yy_push <= yy_save) {
		YY_FATAL(m_textmsg(1552, "Push-back buffer overflow", "E"));
	} else {
		*--yy_push = c;
#endif
		if (c == YYNEWLINE)
			yylineno--;
	}	/* endif */
	return c;
}

#line 131 "../Parser/cci.l"

/* USER SUBROUTINE SECTION */

int yywrap()
{
	return 1;
}