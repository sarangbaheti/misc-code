// Cci.h : Parser include

// Control Spy: Flat Scroll Bar

// Mark J. Finocchio (markfi), Microsoft Corporation

// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) 1998 Microsoft Corporation.  All Rights Reserved.

// Defines
#define CCITYPE		BYTE
#define STRBUFSIZE	128
#define ERRBUFSIZE	128
#define TEMPFILE	"c:\\cciparse.tmp"
#define SIGTEMP		0
#define SIGDESC		1
#define ALLOCMAX	32

#define VUNKNOWN	0
#define VMSGID		1
#define VINT		2

#define MAXAPIPARAM	8		// Maximum number of parameters allowed for API functions
#define APINOSTART	10000	// API starting "message id"
#define APINOEND	19999	// API starting "message id"

#define INITIALIZEFLATSB		0	// Control API
#define FLATSBENABLESCROLLBAR	1	// Control API
#define FLATSBGETSCROLLINFO		2	// Control API
#define FLATSBGETSCROLLPOS		3	// Control API
#define FLATSBGETSCROLLPROP		4	// Control API
#define FLATSBGETSCROLLRANGE	5	// Control API
#define FLATSBSETSCROLLINFO		6	// Control API
#define FLATSBSETSCROLLPOS		7	// Control API
#define FLATSBSETSCROLLPROP		8	// Control API
#define FLATSBSETSCROLLRANGE	9	// Control API
#define FLATSBSHOWSCROLLBAR		10	// Control API
#define UNINITIALIZEFLATSB		11	// Control API

#define NOV				0	// Non-Parse type
#define ERRV			1	// Non-Parse type
#define SUCCESSV		2	// Non-Parse type
#define BITMASKV		3	// Non-Parse type
#define	NUMV			4	// Parse type
#define BOOLV			5	// Parse type
#define LPSTRV			6	// Parse type
#define LPSTRVI			7	// Parse type

// >> Start control specific
#define APIV			8	// API placeholder flag, not used in parser
#define APIPARAMLISTV	9	// API placeholder flag, not used in parser
#define UFSBV			10	// Non-Parse type, Return
#define WINDOWV			11	// Non-Parse type, Param
// << End control specific
// >> Start control specific
#define RGBV			12	// Parse type, Param
#define LPINTBUFV		13	// Parse type, Param
#define LPSCROLLINFOVI	14	// Parse type, Param
// << End control specific

#define STYLEV			(CCITYPE)-1	// Non-Parse type, non rendering nor display

// Typedefs
typedef struct tagCCITypeVal
{
	CCITYPE	cciType;
	void*	cciValue;
} CCITypeVal;

typedef struct tagCCIStyle
{
	LONG dStyleOn;
	LONG dStyleOff;
	LONG dExStyleOn;
	LONG dExStyleOff;
	BOOL bRecreate;
} CCIStyle;

typedef struct tagCCIResult
{
	LPSTR pInput;

	UINT dMsgNo;

	CCITYPE ccitWParam;
	CCITYPE ccitLParam;

	void* pWParam;
	void* pLParam;

	LPSTR pError;
	int dErrLine;
} CCIResult;


// Global variables
extern HPALETTE g_hPalette;
extern HWND g_hContainer;
extern HWND g_hDialog;
extern LPSTR g_pSignature[][2];
extern void* g_pMemTrack[];

// Function prototypes
CCIResult* CCIInterpret(LPSTR);
void CCIRender(CCITYPE,void*,LPSTR);
void CCIDestroy(CCIResult*);
void CCIDestroyHelper(CCITYPE,void*);
LPSTR CCIGetSignature(BYTE,BYTE);
void CCIMemTrack(void*);
