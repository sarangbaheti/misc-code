/* \program files\mks\mksnt\yacc -d -o ../Parser/ytab.c -D ../Parser/ytab.h -P /progra~1/mks/etc/yyparse.c ../Parser/cci.y */
#ifdef YYTRACE
#define YYDEBUG 1
#else
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#endif
/*
 * Portable way of defining ANSI C prototypes
 */
#ifndef YY_ARGS
#if __STDC__
#define YY_ARGS(x)	x
#else
#define YY_ARGS(x)	()
#endif
#endif

#ifdef YACC_WINDOWS

#include <windows.h>

/*
 * the following is the handle to the current
 * instance of a windows program. The user
 * program calling yyparse must supply this!
 */

extern HANDLE hInst;	

#endif	/* YACC_WINDOWS */

#if YYDEBUG
typedef struct yyNamedType_tag {	/* Tokens */
	char	* name;		/* printable name */
	short	token;		/* token # */
	short	type;		/* token type */
} yyNamedType;
typedef struct yyTypedRules_tag {	/* Typed rule table */
	char	* name;		/* compressed rule string */
	short	type;		/* rule result type */
} yyTypedRules;

#endif

#line 16 "../Parser/cci.y"

// Included files
#include <windows.h>
#include <stdio.h>
#include <commctrl.h>
#include "cci.h"

// Function prototypes
void yyerror(char* error);
void yy_reset(void);
int yyparse(void);

// Global variables
extern char yytext[];
extern int yylineno;
extern FILE *yyin;

CCIResult* g_pCCIResult;
LPSTR g_pSignature[][2] = { { "0", "No value" },
							{ "0", "Numeric value (<0 is ERROR, otherwise OK)" },
							{ "0", "Numeric value (non-zero is SUCCESS, otherwise ERROR)" },
							{ "0", "Bitmasked value" },
							{ "0", "Numeric decimal value" },
							{ "TRUE", "Boolean value (TRUE or FALSE)" },
							{ "buffer", "Pointer to string buffer (use 'buffer', max 127 chars)" },
							{ "\"string\"", "Pointer to initialized string (imbedded quotes not allowed)" },
							// >> Start control specific
							{ "0", "Date and time range flags" },
							{ "0", "Date and time valid flags" },
							{ "font", "Font handle (use 'font' or NULL)" },
							// << End control specific
							// >> Start control specific
							{ "RGB(0,0,0)", "Red, green, and blue (RGB) value" },
							{ "SYSTEMTIME", "Pointer to SYSTEMTIME structure" },
							{ "SYSTEMTIME(0,0,0,0,0,0,0,0)", "Pointer to initialized SYSTEMTIME structre" },
							{ "systimearr", "Pointer to 2 element SYSTEMTIME array" },
							{ "systimearr(SYSTEMTIME(0,0,0,0,0,0,0,0),\r\nSYSTEMTIME(0,0,0,0,0,0,0,0))", "Pointer to initialized 2 element SYSTEMTIME array" }
							// << End control specific
						  };
void* g_pMemTrack[ALLOCMAX];
typedef union {
	INT intVal;
	CHAR szVal[STRBUFSIZE];
	CCITypeVal tvVal;
} YYSTYPE;
#define YUNKNOWN	257
#define YMSG	258
#define YSTYLE	259
#define YSETWINLONG	260
#define YRECREATE	261
#define YMSGID	262
#define YINT	263
#define YBOOL	264
#define YNULL	265
#define YSTR	266
#define YSTRBUF	267
#define YRGB	268
#define YSYSTIME	269
#define YSYSTIMEAR	270
extern int yychar, yyerrflag;
extern YYSTYPE yylval;
#if YYDEBUG
enum YY_Types { YY_t_NoneDefined, YY_t_intVal, YY_t_szVal, YY_t_tvVal
};
#endif
#if YYDEBUG
yyTypedRules yyRules[] = {
	{ "&00: %01 &00",  0},
	{ "%01: %05",  0},
	{ "%01: %06",  0},
	{ "%05: &03 &16 &07 &17 %02 &17 %02 &18",  0},
	{ "%02: &10",  3},
	{ "%02: %03",  3},
	{ "%02: &09",  3},
	{ "%02: &12",  3},
	{ "%02: &11",  3},
	{ "%02: &13 &16 &08 &17 &08 &17 &08 &18",  3},
	{ "%02: &14",  3},
	{ "%02: &14 &16 &08 &17 &08 &17 &08 &17 &08 &17 &08 &17 &08 &17 &08 &17 &08 &18",  3},
	{ "%02: &15",  3},
	{ "%02: &15 &16 &14 &16 &08 &17 &08 &17 &08 &17 &08 &17 &08 &17 &08 &17 &08 &17 &08 &18 &17 &14 &16 &08 &17 &08 &17 &08 &17 &08 &17 &08 &17 &08 &17 &08 &17 &08 &18 &18",  3},
	{ "%06: &04 &16 %03 &17 %03 &17 %03 &17 %03 &17 %04 &18",  0},
	{ "%04: &05",  1},
	{ "%04: &06",  1},
	{ "%03: %03 &19 &08",  1},
	{ "%03: &08",  1},
{ "$accept",  0},{ "error",  0}
};
yyNamedType yyTokenTypes[] = {
	{ "$end",  0,  0},
	{ "error",  256,  0},
	{ "YUNKNOWN",  257,  0},
	{ "YMSG",  258,  0},
	{ "YSTYLE",  259,  0},
	{ "YSETWINLONG",  260,  1},
	{ "YRECREATE",  261,  1},
	{ "YMSGID",  262,  1},
	{ "YINT",  263,  1},
	{ "YBOOL",  264,  1},
	{ "YNULL",  265,  1},
	{ "YSTR",  266,  2},
	{ "YSTRBUF",  267,  0},
	{ "YRGB",  268,  1},
	{ "YSYSTIME",  269,  0},
	{ "YSYSTIMEAR",  270,  0},
	{ "'('",  40,  0},
	{ "','",  44,  0},
	{ "')'",  41,  0},
	{ "'|'",  124,  0}

};
#endif
static short yydef[] = {

	  -1,    5,    4,    3
};
static short yyex[] = {

	   0,    0,   -1,    1
};
static short yyact[] = {

	 -83,  -84,  259,  258,  -82,   40,  -81,   40, -100,  263, 
	 -79,  262,  -77,  -78,  124,   44,  -76,   44,  -86,  263, 
	-100,  -95,  -96,  -93,  -94,  -74,   -3,   -2,  270,  269, 
	 268,  267,  266,  265,  264,  263,  -72,  -78,  124,   44, 
	 -71,   40,  -70,   40,  -69,   40,  -78,  124,  -68,   44, 
	 -66,  269,  -65,  263,  -64,  263,  -62,  -78,  124,   44, 
	 -61,   40,  -60,   44,  -59,   44,  -97,   41,  -57,  263, 
	 -56,  263,  -55,  263,  -54,  -78,  124,   44,  -53,   44, 
	 -52,   44,  -51,   44,  -88,  -87,  261,  260,  -49,  263, 
	 -48,  263,  -47,  263,  -89,   41,  -46,   44,  -45,   44, 
	 -92,   41,  -44,  263,  -43,  263,  -42,   44,  -41,   44, 
	 -40,  263,  -39,  263,  -38,   44,  -37,   44,  -36,  263, 
	 -35,  263,  -34,   44,  -33,   44,  -32,  263,  -31,  263, 
	 -30,   44,  -29,   44,  -28,  263,  -27,  263,  -26,   44, 
	 -91,   41,  -25,  263,  -24,   41,  -23,   44,  -22,  269, 
	 -21,   40,  -20,  263,  -19,   44,  -18,  263,  -17,   44, 
	 -16,  263,  -15,   44,  -14,  263,  -13,   44,  -12,  263, 
	 -11,   44,  -10,  263,   -9,   44,   -8,  263,   -7,   44, 
	  -6,  263,   -5,   41,  -90,   41,   -1
};
static short yypact[] = {

	   8,   41,   43,   47,  185,  183,  181,  179,  177,  175, 
	 173,  171,  169,  167,  165,  163,  161,  159,  157,  155, 
	 153,  151,  149,  147,  145,  143,  141,  139,  137,  135, 
	 133,  131,  129,  127,  125,  123,  121,  119,  117,  115, 
	 113,  111,  109,  107,  105,  103,  101,   99,   97,   95, 
	  93,   91,   89,   86,   83,   81,   79,   76,   73,   71, 
	  69,    9,   67,   65,   63,   61,   58,   28,   55,   53, 
	  51,    9,   49,   45,   38,   28,    9,   19,   17,   14, 
	  11,    9,    7,    5,    2
};
static short yygo[] = {

	  -1,  -63,  -73,   67,  -58,  -67,  -75,  -80,   -4,   81, 
	  76,   71,   61,  -50,  -98,  -99,   -1
};
static short yypgo[] = {

	   0,    0,    0,    2,    2,    2,    8,   13,   13,   15, 
	   2,    2,    2,    2,    2,    2,    2,   14,    0,    0, 
	   8,    0
};
static short yyrlen[] = {

	   0,    0,    0,    1,    1,    1,    3,    1,    1,   12, 
	  40,   18,    8,    1,    1,    1,    1,    8,    1,    1, 
	   1,    2
};
#define YYS0	84
#define YYDELTA	79
#define YYNPACT	85
#define YYNDEF	4

#define YYr19	0
#define YYr20	1
#define YYr21	2
#define YYr5	3
#define YYr10	4
#define YYr12	5
#define YYr17	6
#define YYr16	7
#define YYr15	8
#define YYr14	9
#define YYr13	10
#define YYr11	11
#define YYr9	12
#define YYr8	13
#define YYr7	14
#define YYr6	15
#define YYr4	16
#define YYr3	17
#define YYrACCEPT	YYr19
#define YYrERROR	YYr20
#define YYrLR2	YYr21
#if YYDEBUG
char * yysvar[] = {
	"$accept",
	"statement",
	"parameter",
	"intbmval",
	"applystyle",
	"message",
	"style",
	0
};
short yyrmap[] = {

	  19,   20,   21,    5,   10,   12,   17,   16,   15,   14, 
	  13,   11,    9,    8,    7,    6,    4,    3,    1,    2, 
	  18,    0
};
short yysmap[] = {

	   5,   16,   17,   22,   98,   97,   96,   95,   94,   93, 
	  92,   91,   90,   89,   88,   87,   86,   85,   84,   83, 
	  82,   81,   80,   79,   78,   76,   75,   74,   73,   72, 
	  71,   70,   69,   68,   67,   66,   65,   64,   63,   62, 
	  61,   60,   59,   58,   56,   55,   53,   52,   51,   50, 
	  47,   46,   45,   44,   43,   42,   41,   40,   38,   37, 
	  36,   35,   34,   33,   32,   31,   30,   29,   28,   27, 
	  26,   25,   24,   18,   15,   13,   12,   11,   10,    9, 
	   7,    6,    2,    1,    0,   14,   48,   49,   54,   99, 
	  77,   57,   19,   20,   21,   23,   39,    4,    3,    8
};
int yyntoken = 20;
int yynvar = 7;
int yynstate = 100;
int yynrule = 22;
#endif

#if YYDEBUG
/*
 * Package up YACC context for tracing
 */
typedef struct yyTraceItems_tag {
	int	state, lookahead, errflag, done;
	int	rule, npop;
	short	* states;
	int	nstates;
	YYSTYPE * values;
	int	nvalues;
	short	* types;
} yyTraceItems;
#endif

#line 2 "/progra~1/mks/etc/yyparse.c"

/*
 * Copyright 1985, 1990 by Mortice Kern Systems Inc.  All rights reserved.
 * 
 * Automaton to interpret LALR(1) tables.
 *
 * Macros:
 *	yyclearin - clear the lookahead token.
 *	yyerrok - forgive a pending error
 *	YYERROR - simulate an error
 *	YYACCEPT - halt and return 0
 *	YYABORT - halt and return 1
 *	YYRETURN(value) - halt and return value.  You should use this
 *		instead of return(value).
 *	YYREAD - ensure yychar contains a lookahead token by reading
 *		one if it does not.  See also YYSYNC.
 *	YYRECOVERING - 1 if syntax error detected and not recovered
 *		yet; otherwise, 0.
 *
 * Preprocessor flags:
 *	YYDEBUG - includes debug code if 1.  The parser will print
 *		 a travelogue of the parse if this is defined as 1
 *		 and yydebug is non-zero.
 *		yacc -t sets YYDEBUG to 1, but not yydebug.
 *	YYTRACE - turn on YYDEBUG, and undefine default trace functions
 *		so that the interactive functions in 'ytrack.c' will
 *		be used.
 *	YYSSIZE - size of state and value stacks (default 150).
 *	YYSTATIC - By default, the state stack is an automatic array.
 *		If this is defined, the stack will be static.
 *		In either case, the value stack is static.
 *	YYALLOC - Dynamically allocate both the state and value stacks
 *		by calling malloc() and free().
 *	YYDYNAMIC - Dynamically allocate (and reallocate, if necessary)
 *		both the state and value stacks by calling malloc(),
 *		realloc(), and free().
 *	YYSYNC - if defined, yacc guarantees to fetch a lookahead token
 *		before any action, even if it doesnt need it for a decision.
 *		If YYSYNC is defined, YYREAD will never be necessary unless
 *		the user explicitly sets yychar = -1
 *
 * Copyright (c) 1983, by the University of Waterloo
 */
/*
 * Prototypes
 */

extern int yylex YY_ARGS((void));

#if YYDEBUG

#include <stdlib.h>		/* common prototypes */
#include <string.h>

extern char *	yyValue YY_ARGS((YYSTYPE, int));	/* print yylval */
extern void yyShowState YY_ARGS((yyTraceItems *));
extern void yyShowReduce YY_ARGS((yyTraceItems *));
extern void yyShowGoto YY_ARGS((yyTraceItems *));
extern void yyShowShift YY_ARGS((yyTraceItems *));
extern void yyShowErrRecovery YY_ARGS((yyTraceItems *));
extern void yyShowErrDiscard YY_ARGS((yyTraceItems *));

extern void yyShowRead YY_ARGS((int));
#endif

/*
 * If YYDEBUG defined and yydebug set,
 * tracing functions will be called at appropriate times in yyparse()
 * Pass state of YACC parse, as filled into yyTraceItems yyx
 * If yyx.done is set by the tracing function, yyparse() will terminate
 * with a return value of -1
 */
#define YY_TRACE(fn) { \
	yyx.state = yystate; yyx.lookahead = yychar; yyx.errflag =yyerrflag; \
	yyx.states = yys+1; yyx.nstates = yyps-yys; \
	yyx.values = yyv+1; yyx.nvalues = yypv-yyv; \
	yyx.types = yytypev+1; yyx.done = 0; \
	yyx.rule = yyi; yyx.npop = yyj; \
	fn(&yyx); \
	if (yyx.done) YYRETURN(-1); }

#ifndef I18N
#define m_textmsg(id, str, cls)	(str)
#else /*I18N*/
#include <m_nls.h>
#endif/*I18N*/

#ifndef YYSSIZE
# define YYSSIZE	150
#endif

#ifdef YYDYNAMIC
#define YYALLOC
char *getenv();
int atoi();
int yysinc = -1; /* stack size increment, <0 = double, 0 = none, >0 = fixed */
#endif

#ifdef YYALLOC
int yyssize = YYSSIZE;
#endif

#define YYERROR		goto yyerrlabel
#define yyerrok		yyerrflag = 0
#if YYDEBUG
#define yyclearin	{ if (yydebug) yyShowRead(-1); yychar = -1; }
#else
#define yyclearin	yychar = -1
#endif
#define YYACCEPT	YYRETURN(0)
#define YYABORT		YYRETURN(1)
#define YYRECOVERING()	(yyerrflag != 0)
#ifdef YYALLOC
#define YYRETURN(val)	{ retval = (val); goto yyReturn; }
#else
#define YYRETURN(val)	return(val);
#endif
#if YYDEBUG
/* The if..else makes this macro behave exactly like a statement */
# define YYREAD	if (yychar < 0) {					\
			if ((yychar = yylex()) < 0)	{		\
				if (yychar == -2) YYABORT; \
				yychar = 0;				\
			}	/* endif */			\
			if (yydebug)					\
				yyShowRead(yychar);			\
		} else
#else
# define YYREAD	if (yychar < 0) {					\
			if ((yychar = yylex()) < 0) {			\
				if (yychar == -2) YYABORT; \
				yychar = 0;				\
			}	/* endif */			\
		} else
#endif

#define YYERRCODE	256		/* value of `error' */
#define	YYQYYP	yyq[yyq-yyp]

YYSTYPE	yyval;				/* $ */
YYSTYPE	*yypvt;				/* $n */
YYSTYPE	yylval;				/* yylex() sets this */

int	yychar,				/* current token */
	yyerrflag,			/* error flag */
	yynerrs;			/* error count */

#if YYDEBUG
int yydebug = 0;		/* debug if this flag is set */
extern char	*yysvar[];	/* table of non-terminals (aka 'variables') */
extern yyNamedType yyTokenTypes[];	/* table of terminals & their types */
extern short	yyrmap[], yysmap[];	/* map internal rule/states */
extern int	yynstate, yynvar, yyntoken, yynrule;

extern int	yyGetType YY_ARGS((int));	/* token type */
extern char	*yyptok YY_ARGS((int));	/* printable token string */
extern int	yyExpandName YY_ARGS((int, int, char *, int));
				  /* expand yyRules[] or yyStates[] */
static char *	yygetState YY_ARGS((int));

#define yyassert(condition, msg, arg) \
	if (!(condition)) { \
		printf(m_textmsg(2824, "\nyacc bug: ", "E")); \
		printf(msg, arg); \
		YYABORT; }
#else /* !YYDEBUG */
#define yyassert(condition, msg, arg)
#endif

#line 237 "../Parser/cci.y"
/* USER SUBROUTINES */

//        Name: yyerror
// Description: Custom parser error handler
//  Parameters: Pointer to error string return by YACC
//     Returns: none
void yyerror(char* error)
{
	int dX;

	sprintf(g_pCCIResult->pError,"%s: '%s' (line %d)",error,yytext,yylineno);
	g_pCCIResult->dErrLine = yylineno;

	g_pCCIResult->dMsgNo = 0;
	g_pCCIResult->pWParam = NULL;
	g_pCCIResult->pLParam = NULL;
	g_pCCIResult->ccitWParam = -1;
	g_pCCIResult->ccitLParam = -1;

	// Clean up allocated memory that resulted from the imcomplete parse
	for(dX=0;dX<ALLOCMAX;dX++)
		if(g_pMemTrack[dX])
			free(g_pMemTrack[dX]);

	return;
}

//        Name: CCIInterpret
// Description: Interpreter entry point, returns result
//  Parameters: Input string
//     Returns: Pointer to CCIResult struct with result of parse
CCIResult* CCIInterpret(LPSTR p_pInput)
{
	int dX;

	// Create result structure
	g_pCCIResult = (CCIResult*)malloc(sizeof(CCIResult));

	// Initialize result structure
	g_pCCIResult->pInput = (LPSTR)malloc(strlen(p_pInput)+1);
	strcpy(g_pCCIResult->pInput,p_pInput);
	g_pCCIResult->pError = (LPSTR)malloc(ERRBUFSIZE);
	*(g_pCCIResult->pError) = '\0';
	g_pCCIResult->dErrLine = -1;

	g_pCCIResult->dMsgNo = 0;
	
	g_pCCIResult->pWParam = NULL;
	g_pCCIResult->pLParam = NULL;

	g_pCCIResult->ccitWParam = -1;
	g_pCCIResult->ccitLParam = -1;

	// Copy input to temporary file
	if((yyin = fopen(TEMPFILE,"w+b")) == NULL)
	{
		strcpy(g_pCCIResult->pError,"Could not create temporary file!");
		return g_pCCIResult;
	}
	fputs(p_pInput,yyin);
	rewind(yyin);

	// Initialize memory tracking for error recovery
	for(dX=0;dX<ALLOCMAX;dX++)
		g_pMemTrack[dX] = NULL;

	// Parse input
	yy_reset();
	yyparse();

	// CCIResult is now full
	fclose(yyin);
	remove(TEMPFILE);

	// Return
	return g_pCCIResult;
}

//        Name: CCIGetSignature
// Description: Get either template or description of signature item
//  Parameters: Type of information to return, item to query
//     Returns: Pointer to template or description string
LPSTR CCIGetSignature(BYTE p_dType,BYTE p_dItem)
{
	if(p_dItem == SIGTEMP)
		return g_pSignature[p_dType][0];
	else
		return g_pSignature[p_dType][1];
}

//        Name: CCIGetSignature
// Description: Convert parameter value to printable text format
//  Parameters: Type of parameter, actual value, buffer to write out to
//     Returns: none
void CCIRender(CCITYPE p_pCCIType,void* p_pValue,LPSTR p_pDisplay)
{
	CHAR szBuf[4][31];
	switch(p_pCCIType)
	{
		case NOV:
			strcpy(p_pDisplay,"No Value");
			break;

		case ERRV:
			sprintf(p_pDisplay,"%d (%s)",(INT)p_pValue,((INT)p_pValue<0)?"ERROR":"OK");
			break;

		case SUCCESSV:
			sprintf(p_pDisplay,"%d (%s)",(INT)p_pValue,((INT)p_pValue==0)?"FAIL":"SUCCESS");
			break;

		case BITMASKV:
		case NUMV:
			sprintf(p_pDisplay,"%d (0x%x)",(INT)p_pValue,(INT)p_pValue);
			break;

		case BOOLV:
			sprintf(p_pDisplay,"%s",p_pValue?"TRUE":"FALSE");
			break;

		case LPSTRV:
		case LPSTRVI:
			sprintf(p_pDisplay,"%s",(LPSTR)p_pValue);
			break;

		// >> Start control specific
		case GDTRV:
			if((INT)p_pValue&GDTR_MIN && (INT)p_pValue&GDTR_MAX)
				strcpy(p_pDisplay,"GDTR_MIN and GDTR_MAX");
			else if((INT)p_pValue&GDTR_MIN)
				strcpy(p_pDisplay,"GDTR_MIN");
			else if((INT)p_pValue&GDTR_MAX)
				strcpy(p_pDisplay,"GDTR_MAX");
			else
				strcpy(p_pDisplay,"Neither GDTR_MIN nor GDTR_MAX");
			break;

		case GDTVALIDV:
			sprintf(p_pDisplay,"%s (%x)",((INT)p_pValue==GDT_VALID)?"GDT_VALID":"GDT_NONE",(INT)p_pValue);
			break;

		case RGBV:
			if((INT)p_pValue == -1)
				strcpy(p_pDisplay,"ERROR");
			else
				sprintf(p_pDisplay,"RGB(%d,%d,%d)",
					GetRValue((DWORD)p_pValue),
					GetGValue((DWORD)p_pValue),
					GetBValue((DWORD)p_pValue));
			break;

		case LPSYSTIMEV:
		case LPSYSTIMEVI:
			sprintf(p_pDisplay,"SYSTEMTIME(%d,%d,%d,%d,%d,%d,%d,%d)",
				((PSYSTEMTIME)p_pValue)->wYear,((PSYSTEMTIME)p_pValue)->wMonth,((PSYSTEMTIME)p_pValue)->wDayOfWeek,
				((PSYSTEMTIME)p_pValue)->wDay,((PSYSTEMTIME)p_pValue)->wHour,((PSYSTEMTIME)p_pValue)->wMinute,
				((PSYSTEMTIME)p_pValue)->wSecond,((PSYSTEMTIME)p_pValue)->wMilliseconds);
			break;

		case LPSYSTIMEARV:
		case LPSYSTIMEARVI:
			sprintf(p_pDisplay,"SYSTEMTIME(%d,%d,%d,%d,%d,%d,%d,%d)\r\n\tSYSTEMTIME(%d,%d,%d,%d,%d,%d,%d,%d)",
				((PSYSTEMTIME)p_pValue)->wYear,((PSYSTEMTIME)p_pValue)->wMonth,((PSYSTEMTIME)p_pValue)->wDayOfWeek,
				((PSYSTEMTIME)p_pValue)->wDay,((PSYSTEMTIME)p_pValue)->wHour,((PSYSTEMTIME)p_pValue)->wMinute,
				((PSYSTEMTIME)p_pValue)->wSecond,((PSYSTEMTIME)p_pValue)->wMilliseconds,
				(((PSYSTEMTIME)p_pValue)+1)->wYear,(((PSYSTEMTIME)p_pValue)+1)->wMonth,(((PSYSTEMTIME)p_pValue)+1)->wDayOfWeek,
				(((PSYSTEMTIME)p_pValue)+1)->wDay,(((PSYSTEMTIME)p_pValue)+1)->wHour,(((PSYSTEMTIME)p_pValue)+1)->wMinute,
				(((PSYSTEMTIME)p_pValue)+1)->wSecond,(((PSYSTEMTIME)p_pValue)+1)->wMilliseconds);
			break;
		// End control specific <<

		default:
			*p_pDisplay = '\0';
			break;
	}
}

//        Name: CCIDestroy
// Description: Free memory allocated by a CCIResult structure
//  Parameters: Pointer to CCIResult structure
//     Returns: none
void CCIDestroy(CCIResult* p_pCCIResult)
{
	// Free input and error buffer
	if(p_pCCIResult->pInput)
		free(p_pCCIResult->pInput);
	if(p_pCCIResult->pError)
		free(p_pCCIResult->pError);

	// Remove wParam
	CCIDestroyHelper(p_pCCIResult->ccitWParam,p_pCCIResult->pWParam);	
	// Remove lParam
	CCIDestroyHelper(p_pCCIResult->ccitLParam,p_pCCIResult->pLParam);

	// Remove structure
	free(p_pCCIResult);
}

//        Name: CCIDestroyHelper
// Description: CCIDestory second level helper
//  Parameters: Type of parameter, data to free
//     Returns: none
void CCIDestroyHelper(CCITYPE p_pCCIType,void* p_pValue)
{
	switch(p_pCCIType)
	{
		// No storage
		case NUMV:
		case BOOLV:
		case RGBV:
			break;

		// >> Start control specific
		// Multiple level storage (wParam/lParam values whose members point to memory)
		// Fall through
		
		// Single level storage (wParam/lParam that point to memory)
		default:
			if(p_pValue)
				free(p_pValue);
		// End control specific <<
	}
}

//        Name: CCIMemTrack
// Description: Track all memory during parsing in the event of an error so that memory
//				can be freed
//  Parameters: Pointer to allocated memory
//     Returns: none
void CCIMemTrack(void* p_pMem)
{
	int dX;
	BOOL bFoundSlot = FALSE;

	for(dX=0;dX<ALLOCMAX;dX++)
	{
		if(!g_pMemTrack[dX])
		{
			bFoundSlot = TRUE;
			g_pMemTrack[dX] = p_pMem;
			break;
		}
	}

	if(!bFoundSlot)
		OutputDebugString("Allocation track overflow!\n");
}


#ifdef YACC_WINDOWS

/*
 * the following is the yyparse() function that will be
 * callable by a windows type program. It in turn will
 * load all needed resources, obtain pointers to these
 * resources, and call a statically defined function
 * win_yyparse(), which is the original yyparse() fn
 * When win_yyparse() is complete, it will return a
 * value to the new yyparse(), where it will be stored
 * away temporarily, all resources will be freed, and
 * that return value will be given back to the caller
 * yyparse(), as expected.
 */

static int win_yyparse();			/* prototype */

yyparse() 
{
	int wReturnValue;
	HANDLE hRes_table;		/* handle of resource after loading */
	short *old_yydef;		/* the following are used for saving */
	short *old_yyex;		/* the current pointers */
	short *old_yyact;
	short *old_yypact;
	short *old_yygo;
	short *old_yypgo;
	short *old_yyrlen;

	/*
	 * the following code will load the required
	 * resources for a Windows based parser.
	 */

	hRes_table = LoadResource (hInst, 
		FindResource (hInst, "UD_RES_yyYACC", "yyYACCTBL"));
	
	/*
	 * return an error code if any
	 * of the resources did not load
	 */

	if (hRes_table == NULL)
		return (1);
	
	/*
	 * the following code will lock the resources
	 * into fixed memory locations for the parser
	 * (also, save the current pointer values first)
	 */

	old_yydef = yydef;
	old_yyex = yyex;
	old_yyact = yyact;
	old_yypact = yypact;
	old_yygo = yygo;
	old_yypgo = yypgo;
	old_yyrlen = yyrlen;

	yydef = (short *)LockResource (hRes_table);
	yyex = (short *)(yydef + Sizeof_yydef);
	yyact = (short *)(yyex + Sizeof_yyex);
	yypact = (short *)(yyact + Sizeof_yyact);
	yygo = (short *)(yypact + Sizeof_yypact);
	yypgo = (short *)(yygo + Sizeof_yygo);
	yyrlen = (short *)(yypgo + Sizeof_yypgo);

	/*
	 * call the official yyparse() function
	 */

	wReturnValue = win_yyparse();

	/*
	 * unlock the resources
	 */

	UnlockResource (hRes_table);

	/*
	 * and now free the resource
	 */

	FreeResource (hRes_table);

	/*
	 * restore previous pointer values
	 */

	yydef = old_yydef;
	yyex = old_yyex;
	yyact = old_yyact;
	yypact = old_yypact;
	yygo = old_yygo;
	yypgo = old_yypgo;
	yyrlen = old_yyrlen;

	return (wReturnValue);
}	/* end yyparse */

static int win_yyparse() 

#else /* YACC_WINDOWS */

/*
 * we are not compiling a windows resource
 * based parser, so call yyparse() the old
 * standard way.
 */

yyparse() 

#endif /* YACC_WINDOWS */

{
	register short		yyi, *yyp;	/* for table lookup */
	register short		*yyps;		/* top of state stack */
	register short		yystate;	/* current state */
	register YYSTYPE	*yypv;		/* top of value stack */
	register short		*yyq;
	register int		yyj;
#if YYDEBUG
	yyTraceItems	yyx;			/* trace block */
	short	* yytp;
	int	yyruletype = 0;
#endif
#ifdef YYSTATIC
	static short	yys[YYSSIZE + 1];
	static YYSTYPE	yyv[YYSSIZE + 1];
#if YYDEBUG
	static short	yytypev[YYSSIZE+1];	/* type assignments */
#endif
#else /* ! YYSTATIC */
#ifdef YYALLOC
	YYSTYPE *yyv;
	short	*yys;
#if YYDEBUG
	short	*yytypev;
#endif
	YYSTYPE save_yylval;
	YYSTYPE save_yyval;
	YYSTYPE *save_yypvt;
	int save_yychar, save_yyerrflag, save_yynerrs;
	int retval; 			/* return value holder */
#else
	short		yys[YYSSIZE + 1];
	static YYSTYPE	yyv[YYSSIZE + 1];	/* historically static */
#if YYDEBUG
	short	yytypev[YYSSIZE+1];		/* mirror type table */
#endif
#endif /* ! YYALLOC */
#endif /* ! YYSTATIC */
#ifdef YYDYNAMIC
	char *envp;
#endif


#ifdef YYDYNAMIC
	if ((envp = getenv("YYSTACKSIZE")) != (char *)0) {
		yyssize = atoi(envp);
		if (yyssize <= 0)
			yyssize = YYSSIZE;
	}
	if ((envp = getenv("YYSTACKINC")) != (char *)0)
		yysinc = atoi(envp);
#endif
#ifdef YYALLOC
	yys = (short *) malloc((yyssize + 1) * sizeof(short));
	yyv = (YYSTYPE *) malloc((yyssize + 1) * sizeof(YYSTYPE));
#if YYDEBUG
	yytypev = (short *) malloc((yyssize + 1) * sizeof(short));
#endif
	if (yys == (short *)0 || yyv == (YYSTYPE *)0
#if YYDEBUG
		|| yytypev == (short *) 0
#endif
	) {
		yyerror("Not enough space for parser stacks");
		return 1;
	}
	save_yylval = yylval;
	save_yyval = yyval;
	save_yypvt = yypvt;
	save_yychar = yychar;
	save_yyerrflag = yyerrflag;
	save_yynerrs = yynerrs;
#endif

	yynerrs = 0;
	yyerrflag = 0;
	yyclearin;
	yyps = yys;
	yypv = yyv;
	*yyps = yystate = YYS0;		/* start state */
#if YYDEBUG
	yytp = yytypev;
	yyi = yyj = 0;			/* silence compiler warnings */
#endif

yyStack:
	yyassert((unsigned)yystate < yynstate, m_textmsg(587, "state %d\n", ""), yystate);
#ifdef YYDYNAMIC
	if (++yyps > &yys[yyssize]) {
		int yynewsize;
		int yysindex = yyps - yys;
		int yyvindex = yypv - yyv;
#if YYDEBUG
		int yytindex = yytp - yytypev;
#endif
		if (yysinc == 0) {		/* no increment */
			yyerror("Parser stack overflow");
			YYABORT;
		} else if (yysinc < 0)		/* binary-exponential */
			yynewsize = yyssize * 2;
		else				/* fixed increment */
			yynewsize = yyssize + yysinc;
		if (yynewsize < yyssize) {
			yyerror("Not enough space for parser stacks");
			YYABORT;
		}
		yyssize = yynewsize;
		yys = (short *) realloc(yys, (yyssize + 1) * sizeof(short));
		yyps = yys + yysindex;
		yyv = (YYSTYPE *) realloc(yyv, (yyssize + 1) * sizeof(YYSTYPE));
		yypv = yyv + yyvindex;
#if YYDEBUG
		yytypev = (short *)realloc(yytypev,(yyssize + 1)*sizeof(short));
		yytp = yytypev + yytindex;
#endif
		if (yys == (short *)0 || yyv == (YYSTYPE *)0
#if YYDEBUG
			|| yytypev == (short *) 0
#endif
		) {
			yyerror("Not enough space for parser stacks");
			YYABORT;
		}
	}
#else
	if (++yyps > &yys[YYSSIZE]) {
		yyerror("Parser stack overflow");
		YYABORT;
	}
#endif /* !YYDYNAMIC */
	*yyps = yystate;	/* stack current state */
	*++yypv = yyval;	/* ... and value */
#if YYDEBUG
	*++yytp = yyruletype;	/* ... and type */

	if (yydebug)
		YY_TRACE(yyShowState)
#endif

	/*
	 *	Look up next action in action table.
	 */
yyEncore:
#ifdef YYSYNC
	YYREAD;
#endif

#ifdef YACC_WINDOWS
	if (yystate >= Sizeof_yypact) 	/* simple state */
#else /* YACC_WINDOWS */
	if (yystate >= sizeof yypact/sizeof yypact[0]) 	/* simple state */
#endif /* YACC_WINDOWS */
		yyi = yystate - YYDELTA;	/* reduce in any case */
	else {
		if(*(yyp = &yyact[yypact[yystate]]) >= 0) {
			/* Look for a shift on yychar */
#ifndef YYSYNC
			YYREAD;
#endif
			yyq = yyp;
			yyi = yychar;
			while (yyi < *yyp++)
				;
			if (yyi == yyp[-1]) {
				yystate = ~YYQYYP;
#if YYDEBUG
				if (yydebug) {
					yyruletype = yyGetType(yychar);
					YY_TRACE(yyShowShift)
				}
#endif
				yyval = yylval;	/* stack what yylex() set */
				yyclearin;		/* clear token */
				if (yyerrflag)
					yyerrflag--;	/* successful shift */
				goto yyStack;
			}
		}

		/*
	 	 *	Fell through - take default action
	 	 */

#ifdef YACC_WINDOWS
		if (yystate >= Sizeof_yydef)
#else /* YACC_WINDOWS */
		if (yystate >= sizeof yydef /sizeof yydef[0])
#endif /* YACC_WINDOWS */
			goto yyError;
		if ((yyi = yydef[yystate]) < 0)	 { /* default == reduce? */
			/* Search exception table */
#ifdef YACC_WINDOWS
			yyassert((unsigned)~yyi < Sizeof_yyex,
				m_textmsg(2825, "exception %d\n", "I num"), yystate);
#else /* YACC_WINDOWS */
			yyassert((unsigned)~yyi < sizeof yyex/sizeof yyex[0],
				m_textmsg(2825, "exception %d\n", "I num"), yystate);
#endif /* YACC_WINDOWS */
			yyp = &yyex[~yyi];
#ifndef YYSYNC
			YYREAD;
#endif
			while((yyi = *yyp) >= 0 && yyi != yychar)
				yyp += 2;
			yyi = yyp[1];
			yyassert(yyi >= 0,
				 m_textmsg(2826, "Ex table not reduce %d\n", "I num"), yyi);
		}
	}

	yyassert((unsigned)yyi < yynrule, m_textmsg(2827, "reduce %d\n", "I num"), yyi);
	yyj = yyrlen[yyi];
#if YYDEBUG
	if (yydebug)
		YY_TRACE(yyShowReduce)
	yytp -= yyj;
#endif
	yyps -= yyj;		/* pop stacks */
	yypvt = yypv;		/* save top */
	yypv -= yyj;
	yyval = yypv[1];	/* default action $ = $1 */
#if YYDEBUG
	yyruletype = yyRules[yyrmap[yyi]].type;
#endif

	switch (yyi) {		/* perform semantic action */
		
case YYr3: {	/* message :  YMSG '(' YMSGID ',' parameter ',' parameter ')' */
#line 99 "../Parser/cci.y"

			g_pCCIResult->dMsgNo = yypvt[-5].intVal;
			g_pCCIResult->ccitWParam = yypvt[-3].tvVal.cciType;
			g_pCCIResult->pWParam = yypvt[-3].tvVal.cciValue;
			g_pCCIResult->ccitLParam = yypvt[-1].tvVal.cciType;
			g_pCCIResult->pLParam = yypvt[-1].tvVal.cciValue;
		
} break;

case YYr4: {	/* parameter :  YNULL */
#line 109 "../Parser/cci.y"

			yyval.tvVal.cciType = NUMV;
			yyval.tvVal.cciValue = (void*)yypvt[0].intVal; 
		
} break;

case YYr5: {	/* parameter :  intbmval */
#line 114 "../Parser/cci.y"
 
			yyval.tvVal.cciType = NUMV;
			yyval.tvVal.cciValue = (void*)yypvt[0].intVal; 
		
} break;

case YYr6: {	/* parameter :  YBOOL */
#line 119 "../Parser/cci.y"
 
			yyval.tvVal.cciType = BOOLV;
			yyval.tvVal.cciValue = (void*)yypvt[0].intVal; 
		
} break;

case YYr7: {	/* parameter :  YSTRBUF */
#line 124 "../Parser/cci.y"

			yyval.tvVal.cciType = LPSTRV;
			yyval.tvVal.cciValue = (void*)malloc(STRBUFSIZE);
			CCIMemTrack(yyval.tvVal.cciValue);
			ZeroMemory(yyval.tvVal.cciValue,STRBUFSIZE);
		
} break;

case YYr8: {	/* parameter :  YSTR */
#line 131 "../Parser/cci.y"

			yyval.tvVal.cciType = LPSTRVI;
			yyval.tvVal.cciValue = (void*)malloc(strlen(yypvt[0].szVal)+1);
			CCIMemTrack(yyval.tvVal.cciValue);
			strcpy((LPSTR)(yyval.tvVal.cciValue),yypvt[0].szVal);
		
} break;

case YYr9: {	/* parameter :  YRGB '(' YINT ',' YINT ',' YINT ')' */
#line 140 "../Parser/cci.y"

			yyval.tvVal.cciType = RGBV;
			yyval.tvVal.cciValue = (void*)RGB(yypvt[-5].intVal,yypvt[-3].intVal,yypvt[-1].intVal);
		
} break;

case YYr10: {	/* parameter :  YSYSTIME */
#line 145 "../Parser/cci.y"

			yyval.tvVal.cciType = LPSYSTIMEV;
			yyval.tvVal.cciValue = malloc(sizeof(SYSTEMTIME));
			CCIMemTrack(yyval.tvVal.cciValue);
			ZeroMemory(yyval.tvVal.cciValue,sizeof(SYSTEMTIME));
		
} break;

case YYr11: {	/* parameter :  YSYSTIME '(' YINT ',' YINT ',' YINT ',' YINT ',' YINT ',' YINT ',' YINT ',' YINT ')' */
#line 152 "../Parser/cci.y"

			yyval.tvVal.cciType = LPSYSTIMEVI;
			yyval.tvVal.cciValue = malloc(sizeof(SYSTEMTIME));
			CCIMemTrack(yyval.tvVal.cciValue);
			ZeroMemory(yyval.tvVal.cciValue,sizeof(SYSTEMTIME));
			((PSYSTEMTIME)yyval.tvVal.cciValue)->wYear = yypvt[-15].intVal;
			((PSYSTEMTIME)yyval.tvVal.cciValue)->wMonth = yypvt[-13].intVal;
			((PSYSTEMTIME)yyval.tvVal.cciValue)->wDayOfWeek = yypvt[-11].intVal;
			((PSYSTEMTIME)yyval.tvVal.cciValue)->wDay = yypvt[-9].intVal;
			((PSYSTEMTIME)yyval.tvVal.cciValue)->wHour = yypvt[-7].intVal;
			((PSYSTEMTIME)yyval.tvVal.cciValue)->wMinute = yypvt[-5].intVal;
			((PSYSTEMTIME)yyval.tvVal.cciValue)->wSecond = yypvt[-3].intVal;
			((PSYSTEMTIME)yyval.tvVal.cciValue)->wMilliseconds = yypvt[-1].intVal;
		
} break;

case YYr12: {	/* parameter :  YSYSTIMEAR */
#line 167 "../Parser/cci.y"

			yyval.tvVal.cciType = LPSYSTIMEARV;
			yyval.tvVal.cciValue = malloc(sizeof(SYSTEMTIME)*2);
			CCIMemTrack(yyval.tvVal.cciValue);
			ZeroMemory(yyval.tvVal.cciValue,sizeof(SYSTEMTIME)*2);
		
} break;

case YYr13: {	/* parameter :  YSYSTIMEAR '(' YSYSTIME '(' YINT ',' YINT ',' YINT ',' YINT ',' YINT ',' YINT ',' YINT ',' YINT ')' ',' YSYSTIME '(' YINT ',' YINT ',' YINT ',' YINT ',' YINT ',' YINT ',' YINT ',' YINT ')' ')' */
#line 174 "../Parser/cci.y"

			yyval.tvVal.cciType = LPSYSTIMEARVI;
			yyval.tvVal.cciValue = malloc(sizeof(SYSTEMTIME)*2);
			CCIMemTrack(yyval.tvVal.cciValue);
			ZeroMemory(yyval.tvVal.cciValue,sizeof(SYSTEMTIME)*2);
			((PSYSTEMTIME)yyval.tvVal.cciValue)->wYear = yypvt[-35].intVal;
			((PSYSTEMTIME)yyval.tvVal.cciValue)->wMonth = yypvt[-33].intVal;
			((PSYSTEMTIME)yyval.tvVal.cciValue)->wDayOfWeek = yypvt[-31].intVal;
			((PSYSTEMTIME)yyval.tvVal.cciValue)->wDay = yypvt[-29].intVal;
			((PSYSTEMTIME)yyval.tvVal.cciValue)->wHour = yypvt[-27].intVal;
			((PSYSTEMTIME)yyval.tvVal.cciValue)->wMinute = yypvt[-25].intVal;
			((PSYSTEMTIME)yyval.tvVal.cciValue)->wSecond = yypvt[-23].intVal;
			((PSYSTEMTIME)yyval.tvVal.cciValue)->wMilliseconds = yypvt[-21].intVal;

			(((PSYSTEMTIME)yyval.tvVal.cciValue)+1)->wYear = yypvt[-16].intVal;
			(((PSYSTEMTIME)yyval.tvVal.cciValue)+1)->wMonth = yypvt[-14].intVal;
			(((PSYSTEMTIME)yyval.tvVal.cciValue)+1)->wDayOfWeek = yypvt[-12].intVal;
			(((PSYSTEMTIME)yyval.tvVal.cciValue)+1)->wDay = yypvt[-10].intVal;
			(((PSYSTEMTIME)yyval.tvVal.cciValue)+1)->wHour = yypvt[-8].intVal;
			(((PSYSTEMTIME)yyval.tvVal.cciValue)+1)->wMinute = yypvt[-6].intVal;
			(((PSYSTEMTIME)yyval.tvVal.cciValue)+1)->wSecond = yypvt[-4].intVal;
			(((PSYSTEMTIME)yyval.tvVal.cciValue)+1)->wMilliseconds = yypvt[-2].intVal;
		
} break;

case YYr14: {	/* style :  YSTYLE '(' intbmval ',' intbmval ',' intbmval ',' intbmval ',' applystyle ')' */
#line 203 "../Parser/cci.y"

			g_pCCIResult->ccitWParam = STYLEV;
			g_pCCIResult->pWParam = (void*)malloc(sizeof(CCIStyle));
			CCIMemTrack(g_pCCIResult->pWParam);
			((CCIStyle*)g_pCCIResult->pWParam)->dStyleOn = yypvt[-9].intVal;	// Styles on
			((CCIStyle*)g_pCCIResult->pWParam)->dStyleOff = yypvt[-7].intVal;	// Styles off
			((CCIStyle*)g_pCCIResult->pWParam)->dExStyleOn = yypvt[-5].intVal; // Exstyles on
			((CCIStyle*)g_pCCIResult->pWParam)->dExStyleOff = yypvt[-3].intVal; // Exstyles off
			((CCIStyle*)g_pCCIResult->pWParam)->bRecreate = yypvt[-1].intVal; // Recreate or SetWindowLong
		
} break;

case YYr15: {	/* applystyle :  YSETWINLONG */
#line 218 "../Parser/cci.y"

			yyval.intVal = FALSE;
		
} break;

case YYr16: {	/* applystyle :  YRECREATE */
#line 223 "../Parser/cci.y"

			yyval.intVal = TRUE;
		
} break;

case YYr17: {	/* intbmval :  intbmval '|' YINT */
#line 229 "../Parser/cci.y"

			yyval.intVal = yyval.intVal | yypvt[0].intVal;
		
} break;
#line 314 "/progra~1/mks/etc/yyparse.c"
	case YYrACCEPT:
		YYACCEPT;
	case YYrERROR:
		goto yyError;
	}

	/*
	 *	Look up next state in goto table.
	 */

	yyp = &yygo[yypgo[yyi]];
	yyq = yyp++;
	yyi = *yyps;
	while (yyi < *yyp++)
		;

	yystate = ~(yyi == *--yyp? YYQYYP: *yyq);
#if YYDEBUG
	if (yydebug)
		YY_TRACE(yyShowGoto)
#endif
	goto yyStack;

yyerrlabel:	;		/* come here from YYERROR	*/
/*
#pragma used yyerrlabel
 */
	yyerrflag = 1;
	if (yyi == YYrERROR) {
		yyps--;
		yypv--;
#if YYDEBUG
		yytp--;
#endif
	}

yyError:
	switch (yyerrflag) {

	case 0:		/* new error */
		yynerrs++;
		yyi = yychar;
		yyerror("Syntax error");
		if (yyi != yychar) {
			/* user has changed the current token */
			/* try again */
			yyerrflag++;	/* avoid loops */
			goto yyEncore;
		}

	case 1:		/* partially recovered */
	case 2:
		yyerrflag = 3;	/* need 3 valid shifts to recover */
			
		/*
		 *	Pop states, looking for a
		 *	shift on `error'.
		 */

		for ( ; yyps > yys; yyps--, yypv--
#if YYDEBUG
					, yytp--
#endif
		) {
#ifdef YACC_WINDOWS
			if (*yyps >= Sizeof_yypact)
#else /* YACC_WINDOWS */
			if (*yyps >= sizeof yypact/sizeof yypact[0])
#endif /* YACC_WINDOWS */
				continue;
			yyp = &yyact[yypact[*yyps]];
			yyq = yyp;
			do
				;
			while (YYERRCODE < *yyp++);

			if (YYERRCODE == yyp[-1]) {
				yystate = ~YYQYYP;
				goto yyStack;
			}
				
			/* no shift in this state */
#if YYDEBUG
			if (yydebug && yyps > yys+1)
				YY_TRACE(yyShowErrRecovery)
#endif
			/* pop stacks; try again */
		}
		/* no shift on error - abort */
		break;

	case 3:
		/*
		 *	Erroneous token after
		 *	an error - discard it.
		 */

		if (yychar == 0)  /* but not EOF */
			break;
#if YYDEBUG
		if (yydebug)
			YY_TRACE(yyShowErrDiscard)
#endif
		yyclearin;
		goto yyEncore;	/* try again in same state */
	}
	YYABORT;

#ifdef YYALLOC
yyReturn:
	yylval = save_yylval;
	yyval = save_yyval;
	yypvt = save_yypvt;
	yychar = save_yychar;
	yyerrflag = save_yyerrflag;
	yynerrs = save_yynerrs;
	free((char *)yys);
	free((char *)yyv);
#if YYDEBUG
	free((char *)yytypev);
#endif
	return(retval);
#endif
}

		
#if YYDEBUG
/*
 * Return type of token
 */
int
yyGetType(tok)
int tok;
{
	yyNamedType * tp;
	for (tp = &yyTokenTypes[yyntoken-1]; tp > yyTokenTypes; tp--)
		if (tp->token == tok)
			return tp->type;
	return 0;
}
/*
 * Print a token legibly.
 */
char *
yyptok(tok)
int tok;
{
	yyNamedType * tp;
	for (tp = &yyTokenTypes[yyntoken-1]; tp > yyTokenTypes; tp--)
		if (tp->token == tok)
			return tp->name;
	return "";
}

/*
 * Read state 'num' from YYStatesFile
 */
#ifdef YYTRACE

static char *
yygetState(num)
int num;
{
	int	size;
	static FILE *yyStatesFile = (FILE *) 0;
	static char yyReadBuf[YYMAX_READ+1];

	if (yyStatesFile == (FILE *) 0
	 && (yyStatesFile = fopen(YYStatesFile, "r")) == (FILE *) 0)
		return "yyExpandName: cannot open states file";

	if (num < yynstate - 1)
		size = (int)(yyStates[num+1] - yyStates[num]);
	else {
		/* length of last item is length of file - ptr(last-1) */
		if (fseek(yyStatesFile, 0L, 2) < 0)
			goto cannot_seek;
		size = (int) (ftell(yyStatesFile) - yyStates[num]);
	}
	if (size < 0 || size > YYMAX_READ)
		return "yyExpandName: bad read size";
	if (fseek(yyStatesFile, yyStates[num], 0) < 0) {
	cannot_seek:
		return "yyExpandName: cannot seek in states file";
	}

	(void) fread(yyReadBuf, 1, size, yyStatesFile);
	yyReadBuf[size] = '\0';
	return yyReadBuf;
}
#endif /* YYTRACE */
/*
 * Expand encoded string into printable representation
 * Used to decode yyStates and yyRules strings.
 * If the expansion of 's' fits in 'buf', return 1; otherwise, 0.
 */
int
yyExpandName(num, isrule, buf, len)
int num, isrule;
char * buf;
int len;
{
	int	i, n, cnt, type;
	char	* endp, * cp;
	char	*s;

	if (isrule)
		s = yyRules[num].name;
	else
#ifdef YYTRACE
		s = yygetState(num);
#else
		s = "*no states*";
#endif

	for (endp = buf + len - 8; *s; s++) {
		if (buf >= endp) {		/* too large: return 0 */
		full:	(void) strcpy(buf, " ...\n");
			return 0;
		} else if (*s == '%') {		/* nonterminal */
			type = 0;
			cnt = yynvar;
			goto getN;
		} else if (*s == '&') {		/* terminal */
			type = 1;
			cnt = yyntoken;
		getN:
			if (cnt < 100)
				i = 2;
			else if (cnt < 1000)
				i = 3;
			else
				i = 4;
			for (n = 0; i-- > 0; )
				n = (n * 10) + *++s - '0';
			if (type == 0) {
				if (n >= yynvar)
					goto too_big;
				cp = yysvar[n];
			} else if (n >= yyntoken) {
			    too_big:
				cp = "<range err>";
			} else
				cp = yyTokenTypes[n].name;

			if ((i = strlen(cp)) + buf > endp)
				goto full;
			(void) strcpy(buf, cp);
			buf += i;
		} else
			*buf++ = *s;
	}
	*buf = '\0';
	return 1;
}
#ifndef YYTRACE
/*
 * Show current state of yyparse
 */
void
yyShowState(tp)
yyTraceItems * tp;
{
	short * p;
	YYSTYPE * q;

	printf(
	    m_textmsg(2828, "state %d (%d), char %s (%d)\n", "I num1 num2 char num3"),
	      yysmap[tp->state], tp->state,
	      yyptok(tp->lookahead), tp->lookahead);
}
/*
 * show results of reduction
 */
void
yyShowReduce(tp)
yyTraceItems * tp;
{
	printf("reduce %d (%d), pops %d (%d)\n",
		yyrmap[tp->rule], tp->rule,
		tp->states[tp->nstates - tp->npop],
		yysmap[tp->states[tp->nstates - tp->npop]]);
}
void
yyShowRead(val)
int val;
{
	printf(m_textmsg(2829, "read %s (%d)\n", "I token num"), yyptok(val), val);
}
void
yyShowGoto(tp)
yyTraceItems * tp;
{
	printf(m_textmsg(2830, "goto %d (%d)\n", "I num1 num2"), yysmap[tp->state], tp->state);
}
void
yyShowShift(tp)
yyTraceItems * tp;
{
	printf(m_textmsg(2831, "shift %d (%d)\n", "I num1 num2"), yysmap[tp->state], tp->state);
}
void
yyShowErrRecovery(tp)
yyTraceItems * tp;
{
	short	* top = tp->states + tp->nstates - 1;

	printf(
	m_textmsg(2832, "Error recovery pops state %d (%d), uncovers %d (%d)\n", "I num1 num2 num3 num4"),
		yysmap[*top], *top, yysmap[*(top-1)], *(top-1));
}
void
yyShowErrDiscard(tp)
yyTraceItems * tp;
{
	printf(m_textmsg(2833, "Error recovery discards %s (%d), ", "I token num"),
		yyptok(tp->lookahead), tp->lookahead);
}
#endif	/* ! YYTRACE */
#endif	/* YYDEBUG */
