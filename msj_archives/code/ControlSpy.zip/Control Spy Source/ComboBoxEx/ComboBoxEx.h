// ComboBoxEx.h : Header

// Messages and their descriptions

// Mark J. Finocchio (markfi), Microsoft Corporation

// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) 1998 Microsoft Corporation.  All Rights Reserved.

// Defines
#define ID		0
#define DESC	1
#define WPSIG	0
#define LPSIG	1
#define LRSIG	2

// Defines
#define MAXHISTORY	4096

#define TTOFFSET	2000
#define ITEMOFFSET	2000

#define RESSTRSIZE	1024

#define GET			0x1
#define LOG			0x2

#define CSPY_STARTUP	-1
#define CSPY_SHUTDOWN	-2

#define INFO_DISPLAY	WM_USER+1

// >> Start control specific
#define MSGPREFIX	"CB"
#define NTFYPREFIX	"CB"
// End control specific <<

#define LPFILTER	&g_cFilter
#define MSGFILTERENTRY	-1
#define NTFYFILTERENTRY	0

// Typedefs
typedef struct tagNotifyList
{
	LPSTR pNotifyID;		// Text based ID
	UINT dNotifyNo;			// Numeric ID
	BOOL bFilter;			// Filter: 0=Show message, 1=Do not show
	LPSTR pNotifyDesc;		// Text based description
} NotifyList;

typedef struct tagMessageList
{
	LPSTR pMessageID;		// Text based ID
	UINT dMessageNo;		// Numeric ID
	BOOL bFilter;			// Filter: 0=Show message, 1=Do not show
	LPSTR pMessageDesc;		// Text based description
	BYTE dWParam;			// wParam Signature
	BYTE dLParam;			// lParam Signature
	BYTE dLResult;			// lResult Signature
} MessageList;

typedef struct tagStyleList
{
	LPSTR pStyleID;			// Text based ID
	UINT dStyleNo;			// Numeric ID
	LPSTR pStyleDesc;		// Text based description
} StyleList;

typedef struct tagValueList
{
	LPSTR pValueID;			// Text based ID
	UINT dValueNo;			// Numeric value
} ValueList;

// Function prototypes
void InitialControlStyles(LPDWORD,LPDWORD);
LRESULT ProcessControlNotification(LPNMHDR);
LRESULT ProcessControlCommand(WORD);
void ControlStateCallback(INT);
void RegisterControl();

// Support function prototypes
void CreateControl(UINT,UINT);
BOOL CALLBACK DlgProc(HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK GetMsgProc(int,WPARAM,LPARAM);
LRESULT CALLBACK CallWndProc(int,WPARAM,LPARAM);
void MessageProc(MSG*);
void CreateSupportControls();
LRESULT CALLBACK ContainerWndProc(HWND,UINT,WPARAM,LPARAM);
BOOL CommandHandler(WORD,WORD);
BOOL CALLBACK AddToolTipEnum(HWND,LPARAM);
BOOL CALLBACK DeleteToolTipEnum(HWND,LPARAM);
void FilterMessages(int);
void LogMessage(UINT);
void LogNotification(UINT);
LPSTR GetMessageString(UINT,int);
BYTE GetMessageSignature(UINT,int);
LPSTR GetNotifyString(UINT,int);
UINT GetValue(LPSTR,LPINT);
BOOL CALLBACK StylesProc(HWND,UINT,WPARAM,LPARAM);
BOOL CALLBACK InformationProc(HWND,UINT,WPARAM,LPARAM);
BOOL CALLBACK AboutProc(HWND,UINT,WPARAM,LPARAM);
DWORD CALLBACK DisplayStreamCallback(DWORD,LPBYTE,LONG,LONG*);
LPSTR StrTrim(LPSTR);
void UpdateUI();

// Global variable definitions
extern NotifyList g_nlTable[];
extern MessageList g_mlTable[];
extern StyleList g_slTable[];
extern StyleList g_exslTable[];
extern ValueList g_vlTable[];

// Allocate in context of main source file
#ifdef CSMAIN

// Global variables
HINSTANCE g_hInstance;
HWND g_hDialog;
HWND g_hContainer;
HWND g_hControl;
HWND g_hStyles;
HWND g_hInformation;

HWND g_hToolTips;
HHOOK g_hGMHook;
HHOOK g_hCWHook;
int g_dLastNotifyIndex;
int g_dLastMessageIndex;
int g_dLastSendMessageIndex;
int g_dLastStylesIndex;
int g_dLastExStylesIndex;
UINT g_dInfoDisplayStart;
UINT g_dInfoDisplayEnd;
CHAR g_cFilter;
int g_dSLCurrent;
int g_dSLCount;
LPSTR g_pSL;
CHAR** g_pSLIndex;
CHAR g_szSLFile[_MAX_PATH];
BOOL g_bSendAll;
BOOL g_bLogging;
HANDLE g_hLogOn;
HANDLE g_hLogOff;

// >> Start control specific
// Notification table (all notifications sent by control)
// Used for list box contents and tool tips
NotifyList g_nlTable[] =  {	{ "Unknown",			0,		0,	"Unknown notification" },

							{ "CBN_SELCHANGE",		1,		0,	"Selection in the list box is about to change" },
							{ "CBN_DBLCLK",			2,		0,	"User double-clicked a string of the list" },
							{ "CBN_SETFOCUS",		3,		0,	"Combo box received keyboard focus" },
							{ "CBN_KILLFOCUS",		4,		0,	"Combo box lost keyboard focus" },
							{ "CBN_EDITCHANGE",		5,		0,	"User took action that may have altered text in the edit box" },
							{ "CBN_EDITUPDATE",		6,		0,	"Combo box edit box is about to display altered text" },
							{ "CBN_DROPDOWN",		7,		0,	"Combo box list is about to be made visible" },
							{ "CBN_CLOSEUP",		8,		0,	"Drop down list box has been closed" },
							{ "CBN_SELENDOK",		9,		0,	"User selected a list item" },
							{ "CBN_SELENDCANCEL",	10,		0,	"Selection in the combo box list is about to change" },
				
// Unicode					{ "CBEN_DRAGBEGIN",		-809,	0,	"User began dragging from the edit box (Unicode)" },
							{ "CBEN_DRAGBEGIN",		-808,	0,	"User began dragging from the edit box" },
// Unicode					{ "CBEN_GETDISPINFO",	-807,	0,	"Information required about a callback item for display (Unicode)" },
// Unicode					{ "CBEN_ENDEDIT",		-806,	0,	"User concluded an edit box operation or selected a list item (Unicode)" },
							{ "CBEN_ENDEDIT",		-805,	0,	"User concluded an edit box operation or selected a list item" },
							{ "CBEN_BEGINEDIT",		-804,	0,	"User activated the drop-down list or clicked in the edit box" },
							{ "CBEN_DELETEITEM",	-802,	0,	"An item has been deleted" },
							{ "CBEN_INSERTITEM",	-801,	0,	"New item inserted in the combo box" },
							{ "CBEN_GETDISPINFO",	-800,	0,	"Information required about a callback item for display" },

							{ "NM_SETCURSOR",		-17,	0,	"Control is setting the cursor" } };
// End control specific <<

// Start control specific <<
// Message table (all messages to control)
// Used for list box contents, tool tips, and parser
MessageList g_mlTable[] = {	{ "WM_NULL",			0,		0,	"No operation", 0, 0, 0 },
							{ "WM_CREATE",			1,		0,	"Window created and about to be displayed", 0, 0, 0 },
							{ "WM_DESTROY",			2,		0,	"Window is being destroy and has been removed from the screen", 0, 0, 0 },
							{ "WM_MOVE",			3,		0,	"Window has been moved", 0, 0, 0 },
							{ "WM_SIZE",			5,		0,	"Window size has been changed", 0, 0, 0 },
							{ "WM_ACTIVATE",		6,		0,	"Window is either being activated for deactivated", 0, 0, 0 },
							{ "WM_SETFOCUS",		7,		0,	"Window has keyboard focus", 0, 0, 0 },
							{ "WM_KILLFOCUS",		8,		0,	"Window is about to lose focus", 0, 0, 0 },
							{ "WM_ENABLE",			10,		0,	"Window enabled state is changing", 0, 0, 0 },
							{ "WM_SETREDRAW",		11,		0,	"Allow or prevent redraws to take place", 0, 0, 0 },
							{ "WM_SETTEXT",			12,		0,	"Set the text of the window", 0, 0, 0 },
							{ "WM_GETTEXT",			13,		0,	"Retrieve corresponding window text", 0, 0, 0 },
							{ "WM_GETTEXTLENGTH",	14,		0,	"Return length, in characters, of associated text", 0, 0, 0 },
							{ "WM_PAINT",			15,		0,	"Paint a portion of the client area", 0, 0, 0 },
							{ "WM_CLOSE",			16,		0,	"Window or application should terminate", 0, 0, 0 },
							{ "WM_QUERYENDSESSION",	17,		0,	"User chose to end current Windows session", 0, 0, 0 },
							{ "WM_QUIT",			18,		0,	"Terminate application request", 0, 0, 0 },
							{ "WM_QUERYOPEN",		19,		0,	"User requested that iconic window be restored", 0, 0, 0 },
							{ "WM_ERASEBKGND",		20,		0,	"Window background must be erased", 0, 0, 0 },
							{ "WM_SYSCOLORCHANGE",	21,		0,	"A change has been made to a system color setting", 0, 0, 0 },
							{ "WM_ENDSESSION",		22,		0,	"Windows session might be ending", 0, 0, 0 },
							{ "WM_SHOWWINDOW",		24,		0,	"Window is about to be hidden or shown", 0, 0, 0 },
							{ "WM_SETTINGCHANGE",	26,		0,	"A system wide setting has changed", 0, 0, 0 },
							{ "WM_WININICHANGE",	26,		0,	"A system wide setting has changed", 0, 0, 0 },
							{ "WM_DEVMODECHANGE",	27,		0,	"User changed device-mode settings", 0, 0, 0 },
							{ "WM_ACTIVATEAPP",		28,		0,	"A window belonging to another application is about to be activated", 0, 0, 0 },
							{ "WM_FONTCHANGE",		29,		0,	"Pool of font resources has changed", 0, 0, 0 },
							{ "WM_TIMECHANGE",		30,		0,	"System time has changed", 0, 0, 0 },
							{ "WM_CANCELMODE",		31,		0,	"Window is to cancel its current mode", 0, 0, 0 },
							{ "WM_SETCURSOR",		32,		0,	"Cursor moved within window and is not captured", 0, 0, 0 },
							{ "WM_MOUSEACTIVATE",	33,		0,	"Window activation via mouse click", 0, 0, 0 },
							{ "WM_CHILDACTIVATE",	34,		0,	"MDI child window has been activated, moved, or sized", 0, 0, 0 },
							{ "WM_QUEUESYNC",		35,		0,	"Separate user-input messages from other journal playback hook messages", 0, 0, 0 },
							{ "WM_GETMINMAXINFO",	36,		0,	"Return minimum or maximum tracking size", 0, 0, 0 },
							{ "WM_PAINTICON",		38,		0,	"Icon is to be painted of minimized window", 0, 0, 0 },
							{ "WM_ICONERASEBKGND",	39,		0,	"Background of the minimized window icon must be painted", 0, 0, 0 },
							{ "WM_NEXTDLGCTL",		40,		0,	"Set the keyboard focus to a different control", 0, 0, 0 },
							{ "WM_SPOOLERSTATUS",	42,		0,	"Job as been added or removed from the Print Manager queue", 0, 0, 0 },
							{ "WM_DRAWITEM",		43,		0,	"Visual aspect of control has changed", 0, 0, 0 },
							{ "WM_MEASUREITEM",		44,		0,	"Provide measurements of owner drawn control", 0, 0, 0 },
							{ "WM_DELETEITEM",		45,		0,	"Items removed from the list/combo box", 0, 0, 0 },
							{ "WM_VKEYTOITEM",		46,		0,	"List box want keyboard input notification", 0, 0, 0 },
							{ "WM_CHARTOITEM",		47,		0,	"List box with keyboard input enabled received a character message", 0, 0, 0 },
							{ "WM_SETFONT",			48,		0,	"Set desired font window is to use while drawing text", 0, 0, 0 },
							{ "WM_GETFONT",			49,		0,	"Return the font with which the window is currently drawing its text", 0, 0, 0 },
							{ "WM_SETHOTKEY",		50,		0,	"Associate hot key", 0, 0, 0 },
							{ "WM_GETHOTKEY",		51,		0,	"Hot key association query", 0, 0, 0 },
							{ "WM_QUERYDRAGICON",	55,		0,	"Minimized iconic window is about to be dragged by user", 0, 0, 0 },
							{ "WM_COMPAREITEM",		57,		0,	"Report the relative item position in a sorted list of an owner-draw combo or list box", 0, 0, 0 },
							{ "WM_COMPACTING",		65,		0,	"System memory is low", 0, 0, 0 },
							{ "WM_WINDOWPOSCHANGING",70,	0,	"Size, position, or Z order is about to change", 0, 0, 0 },
							{ "WM_WINDOWPOSCHANGED",71,		0,	"Size, position, or Z order has changed", 0, 0, 0 },
							{ "WM_POWER",			72,		0,	"System is about to enter suspended mode", 0, 0, 0 },
							{ "WM_COPYDATA",		74,		0,	"Data has be passed to application ", 0, 0, 0 },
							{ "WM_CANCELJOURNAL",	75,		0,	"User cancelled journaling activities", 0, 0, 0 },
							{ "WM_NOTIFY",			78,		0,	"Control event occurred or requires information", 0, 0, 0 },
							{ "WM_INPUTLANGCHANGEREQUEST",80,0,	"User requests to change the current input language", 0, 0, 0 },
							{ "WM_INPUTLANGCHANGE",	81,		0,	"Input language has changed", 0, 0, 0 },
							{ "WM_TCARD",			82,		0,	"User clicked an authorable button on a WinHelp Training Card", 0, 0, 0 },
							{ "WM_HELP",			83,		0,	"User pressed F1", 0, 0, 0 },
							{ "WM_USERCHANGED",		84,		0,	"User has logged on or off", 0, 0, 0 },
							{ "WM_NOTIFYFORMAT",	85,		0,	"Return whether should use ANSI or Unicode structures", 0, 0, 0 },
							{ "WM_CONTEXTMENU",		123,	0,	"User clicked the right mouse button in the window", 0, 0, 0 },
							{ "WM_STYLECHANGING",	124,	0,	"One or more of the window's styles is about to change", 0, 0, 0 },
							{ "WM_STYLECHANGED",	125,	0,	"Window's style has changed", 0, 0, 0 },
							{ "WM_DISPLAYCHANGE",	126,	0,	"Display resolution has changed", 0, 0, 0 },
							{ "WM_GETICON",			127,	0,	"Return the handle of the large or small associated icon", 0, 0, 0 },
							{ "WM_SETICON",			128,	0,	"Set large or small icon", 0, 0, 0 },
							{ "WM_NCCREATE",		129,	0,	"Non-client area created and is about to be displayed", 0, 0, 0 },
							{ "WM_NCDESTROY",		130,	0,	"Non-client area is being destroyed", 0, 0, 0 },
							{ "WM_NCCALCSIZE",		131,	0,	"Size and position of client area must be calculated", 0, 0, 0 },
							{ "WM_NCHITTEST",		132,	0,	"Mouse cursor moved or button was pressed or released", 0, 0, 0 },
							{ "WM_NCPAINT",			133,	0,	"Frame must be painted", 0, 0, 0 },
							{ "WM_NCACTIVATE",		134,	0,	"Nonclient area needs to be changed to reflect active state", 0, 0, 0 },
							{ "WM_GETDLGCODE",		135,	0,	"Chance to override default behavior to dialog box input", 0, 0, 0 },
							{ "WM_NCMOUSEMOVE",		160,	0,	"User moved mouse within non-client area", 0, 0, 0 },
							{ "WM_NCLBUTTONDOWN",	161,	0,	"User pressed left mouse button in non-client area", 0, 0, 0 },
							{ "WM_NCLBUTTONUP",		162,	0,	"User released left mouse button in non-client area", 0, 0, 0 },
							{ "WM_NCLBUTTONDBLCLK",	163,	0,	"User double clicked left mouse button in non-client area", 0, 0, 0 },
							{ "WM_NCRBUTTONDOWN",	164,	0,	"User pressed right mouse button in non-client area", 0, 0, 0 },
							{ "WM_NCRBUTTONUP",		165,	0,	"User released right mouse button in non-client area", 0, 0, 0 },
							{ "WM_NCRBUTTONDBLCLK",	166,	0,	"User double clicked right mouse button in non-client area", 0, 0, 0 },
							{ "WM_NCMBUTTONDOWN",	167,	0,	"User pressed middle mouse button in non-client area", 0, 0, 0 },
							{ "WM_NCMBUTTONUP",		168,	0,	"User released middle mouse button in non-client area", 0, 0, 0 },
							{ "WM_NCMBUTTONDBLCLK",	169,	0,	"User double clicked middle mouse button in non-client area", 0, 0, 0 },
							{ "WM_KEYDOWN",			256,	0,	"Non-system key pressed", 0, 0, 0 },
							{ "WM_KEYUP",			257,	0,	"Non-system key released", 0, 0, 0 },
							{ "WM_CHAR",			258,	0,	"Key down message has been translated", 0, 0, 0 },
							{ "WM_DEADCHAR",		259,	0,	"Dead character code translated", 0, 0, 0 },
							{ "WM_SYSKEYDOWN",		260,	0,	"System key has been pressed (F10 or ALT-key)", 0, 0, 0 },
							{ "WM_SYSKEYUP",		261,	0,	"System key has been released (F10 or ALT-key)", 0, 0, 0 },
							{ "WM_SYSCHAR",			262,	0,	"System ALT key has been translated", 0, 0, 0 },
							{ "WM_SYSDEADCHAR",		263,	0,	"Dead system character code translated", 0, 0, 0 },
							{ "WM_IME_STARTCOMPOSITION",269,0,	"IME is about to generate a composition string due to a keystroke", 0, 0, 0 },
							{ "WM_IME_ENDCOMPOSITION",270,	0,	"IME ended composition", 0, 0, 0 },
							{ "WM_IME_COMPOSITION",	271,	0,	"IME changed composition status as a result of a key stroke", 0, 0, 0 },
							{ "WM_INITDIALOG",		272,	0,	"Dialog box is about to be displayed", 0, 0, 0 },
							{ "WM_COMMAND",			273,	0,	"Window received a command notification", 0, 0, 0 },
							{ "WM_SYSCOMMAND",		274,	0,	"User chose a command from the system menu", 0, 0, 0 },
							{ "WM_TIMER",			275,	0,	"Timer expired", 0, 0, 0 },
							{ "WM_HSCROLL",			276,	0,	"Scroll event occurred in the horizontal scroll bar", 0, 0, 0 },
							{ "WM_VSCROLL",			277,	0,	"Scroll event occurred in the vertical scroll bar", 0, 0, 0 },
							{ "WM_INITMENU",		278,	0,	"Menu is about to become active", 0, 0, 0 },
							{ "WM_INITMENUPOPUP",	279,	0,	"Drop-down or sub-menu is about to become active", 0, 0, 0 },
							{ "WM_MENUSELECT",		287,	0,	"Menu item has been selected", 0, 0, 0 },
							{ "WM_MENUCHAR",		288,	0,	"User pressed an unknown menu key", 0, 0, 0 },
							{ "WM_ENTERIDLE",		289,	0,	"Child modal dialog or menu is entering an idle state", 0, 0, 0 },
							{ "WM_CTLCOLORMSGBOX",	306,	0,	"Message box is about to be drawn", 0, 0, 0 },
							{ "WM_CTLCOLOREDIT",	307,	0,	"Edit box is about to be drawn", 0, 0, 0 },
							{ "WM_CTLCOLORLISTBOX",	308,	0,	"List box is about to be drawn", 0, 0, 0 },
							{ "WM_CTLCOLORBTN",		309,	0,	"Button is about to be drawn", 0, 0, 0 },
							{ "WM_CTLCOLORDLG",		310,	0,	"Dialog box is about to be drawn", 0, 0, 0 },
							{ "WM_CTLCOLORSCROLLBAR",311,	0,	"Scroll bar is about to be drawn", 0, 0, 0 },
							{ "WM_CTLCOLORSTATIC",	312,	0,	"Static control is about to be drawn", 0, 0, 0 },

							{ "CB_LIMITTEXT",		321,	0,	"Limit the text length the user may type into the combo box edit field", NUMV, NOV, BOOLV },
							{ "CB_DELETESTRING",	324,	0,	"Delete string in the list box of the combo box", NUMV, NOV, ERRV },
							{ "CB_GETCOUNT",		326,	0,	"Retrieve the number of items in the combo box", NOV, NOV, ERRV },
							{ "CB_GETCURSEL",		327,	0,	"Retrieve the index of the currectly selected item", NOV, NOV, ERRV },
							{ "CB_GETLBTEXT",		328,	0,	"Retrieve a string from the list of the combo box", NUMV, LPSTRV, ERRV },
							{ "CB_GETLBTEXTLEN",	329,	0,	"Retrieve the length of a string in the list of the combo box", NUMV, NOV, ERRV },
							{ "CB_RESETCONTENT",	331,	0,	"Remove all items from the combo box", NOV, NOV, ERRV },
							{ "CB_SELECTSTRING",	333,	0,	"Search the list for an item that begins with a specified string", NUMV, LPSTRVI, ERRV },
							{ "CB_SETCURSEL",		334,	0,	"Select a string in the combo box list", NUMV, NOV, ERRV },
							{ "CB_SHOWDROPDOWN",	335,	0,	"Show or hide the list box of the combo box", BOOLV, NOV, BOOLV },
							{ "CB_GETITEMDATA",		336,	0,	"Retrieve the application-supplied 32-bit associated item value", NUMV, NOV, ERRV },
							{ "CB_SETITEMDATA",		337,	0,	"Set the 32-bit value associated with the combo box item", NUMV, NUMV, ERRV },
							{ "CB_GETDROPPEDCONTROLRECT",338,0,	"Retrieve the screen coordinates of the drop-down list box", NOV, LPRECTV, ERRV },
							{ "CB_SETITEMHEIGHT",	339,	0,	"Set the height of the list items or selection field of the combo box", NUMV, NUMV, ERRV },
							{ "CB_GETITEMHEIGHT",	340,	0,	"Determine the height of the list items or selection field", NUMV, NOV, ERRV },
							{ "CB_SETEXTENDEDUI",	341,	0,	"Select the default or extended user interface for the combo box", BOOLV, NOV, ERRV },
							{ "CB_GETEXTENDEDUI",	342,	0,	"Determine if combo box has the default or extended user interface", NOV, NOV, BOOLV },
							{ "CB_GETDROPPEDSTATE",	343,	0,	"Determine whether the combo box is dropped down", NOV, NOV, BOOLV },
							{ "CB_FINDSTRINGEXACT",	344,	0,	"Find the first specified string in the combo box", NUMV, LPSTRVI, ERRV },
							{ "CB_SETDROPPEDWIDTH",	352,	0,	"Set the maximum allowable width of the combo box width", NUMV, NOV, ERRV },

							{ "WM_MOUSEMOVE",		512,	0,	"Mouse cursor moved", 0, 0, 0 },
							{ "WM_LBUTTONDOWN",		513,	0,	"User pressed left mouse button in client area", 0, 0, 0 },
							{ "WM_LBUTTONUP",		514,	0,	"User released left mouse button in client area", 0, 0, 0 },
							{ "WM_LBUTTONDBLCLK",	515,	0,	"User double clicked left mouse button in client area", 0, 0, 0 },
							{ "WM_RBUTTONDOWN",		516,	0,	"User pressed right mouse button in client area", 0, 0, 0 },
							{ "WM_RBUTTONUP",		517,	0,	"User released right mouse button in client area", 0, 0, 0 },
							{ "WM_RBUTTONDBLCLK",	518,	0,	"User double clicked right mouse button in client area", 0, 0, 0 },
							{ "WM_MBUTTONDOWN",		519,	0,	"User pressed middle mouse button in client area", 0, 0, 0 },
							{ "WM_MBUTTONUP",		520,	0,	"User released middle mouse button in client area", 0, 0, 0 },
							{ "WM_MBUTTONDBLCLK",	521,	0,	"User double clicked middle mouse button in client area", 0, 0, 0 },
							{ "WM_MOUSEWHEEL",		522,	0,	"Mouse wheel rotated", 0, 0, 0 },
							{ "WM_PARENTNOTIFY",	528,	0,	"Child window created or destroyed, or mouse click event occurred to child", 0, 0, 0 },
							{ "WM_ENTERMENULOOP",	529,	0,	"Menu modal loop has been entered", 0, 0, 0 },
							{ "WM_EXITMENULOOP",	530,	0,	"Menu modal loop has been exited", 0, 0, 0 },
							{ "WM_NEXTMENU",		531,	0,	"Right or left arrow key was used to switch between menu bar and system menu", 0, 0, 0 },
							{ "WM_SIZING",			532,	0,	"Window is resizing", 0, 0, 0 },
							{ "WM_CAPTURECHANGED",	533,	0,	"Window is losing mouse capture", 0, 0, 0 },
							{ "WM_MOVING",			534,	0,	"Window is moving", 0, 0, 0 },
							{ "WM_POWERBROADCAST",	536,	0,	"Power-management event notification", 0, 0, 0 },
							{ "WM_DEVICECHANGE",	537,	0,	"Hardware configuration has changed", 0, 0, 0 },
							{ "WM_MDICREATE",		544,	0,	"Create a MDI child window", 0, 0, 0 },
							{ "WM_MDIDESTROY",		545,	0,	"Destroy MDI child window", 0, 0, 0 },
							{ "WM_MDIACTIVATE",		546,	0,	"Activate a different MDI child window", 0, 0, 0 },
							{ "WM_MDIRESTORE",		547,	0,	"Restore MDI child window size", 0, 0, 0 },
							{ "WM_MDINEXT",			548,	0,	"Activate the next or previous MDI child window", 0, 0, 0 },
							{ "WM_MDIMAXIMIZE",		549,	0,	"Maximize a MDI child window", 0, 0, 0 },
							{ "WM_MDITILE",			550,	0,	"Arrange all MDI children in a tile format", 0, 0, 0 },
							{ "WM_MDICASCADE",		551,	0,	"Arrange all MDI child windows in cascade format", 0, 0, 0 },
							{ "WM_MDIICONARRANGE",	552,	0,	"Arrange all minimized MDI child windows", 0, 0, 0 },
							{ "WM_MDIGETACTIVE",	553,	0,	"Return handle of active MDI child window", 0, 0, 0 },
							{ "WM_MDISETMENU",		560,	0,	"Replace entire menu of the MDI frame", 0, 0, 0 },
							{ "WM_ENTERSIZEMOVE",	561,	0,	"Entered moving or sizing modal loop", 0, 0, 0 },
							{ "WM_EXITSIZEMOVE",	562,	0,	"Window exited the moving or sizing modal loop", 0, 0, 0 },
							{ "WM_DROPFILES",		563,	0,	"Dropped file notification", 0, 0, 0 },
							{ "WM_MDIREFRESHMENU",	564,	0,	"Refresh the MDI menu of the frame", 0, 0, 0 },
							{ "WM_IME_SETCONTEXT",	641,	0,	"IME window is about to be activated", 0, 0, 0 },
							{ "WM_IME_NOTIFY",		642,	0,	"IME window change notification", 0, 0, 0 },
							{ "WM_IME_CONTROL",		643,	0,	"IME window must carry out requested command", 0, 0, 0 },
							{ "WM_IME_COMPOSITIONFULL",644,	0,	"IME cannot extend the area of the composition window", 0, 0, 0 },
							{ "WM_IME_SELECT",		645,	0,	"System is about to change the current IME", 0, 0, 0 },
							{ "WM_IME_CHAR",		646,	0,	"IME got a character of the conversion result", 0, 0, 0 },
							{ "WM_IME_KEYDOWN",		656,	0,	"IME key press notification", 0, 0, 0 },
							{ "WM_IME_KEYUP",		657,	0,	"IME key release notification", 0, 0, 0 },
							{ "WM_MOUSEHOVER",		673,	0,	"Mouse cursor is hovering", 0, 0, 0 },
							{ "WM_MOUSELEAVE",		675,	0,	"Mouse cursor moved out of window", 0, 0 ,0 },
							{ "WM_CUT",				768,	0,	"Delete current selection", 0, 0, 0 },
							{ "WM_COPY",			769,	0,	"Copy current selection into the clipboard in text format", 0, 0, 0 },
							{ "WM_PASTE",			770,	0,	"Copy current content of the clipboard to control", 0, 0, 0 },
							{ "WM_CLEAR",			771,	0,	"Clear the current selection, if any, from the edit control", 0, 0, 0 },
							{ "WM_UNDO",			772,	0,	"Undo last operation", 0, 0, 0 },
							{ "WM_RENDERFORMAT",	773,	0,	"Render data in the specified clipboard format", 0, 0, 0 },
							{ "WM_RENDERALLFORMATS",774,	0,	"Render data in all clipboard formats", 0, 0, 0 },
							{ "WM_DESTROYCLIPBOARD",775,	0,	"Clipboard has been emptied", 0, 0, 0 },
							{ "WM_DRAWCLIPBOARD",	776,	0,	"Content of the clipboard changed", 0, 0, 0 },
							{ "WM_PAINTCLIPBOARD",	777,	0,	"Clipboard viewer's client area needs repainting", 0, 0, 0 },
							{ "WM_VSCROLLCLIPBOARD",778,	0,	"Event occurred in the clipboard viewer's vertical scroll bar", 0, 0, 0 },
							{ "WM_SIZECLIPBOARD",	779,	0,	"Clipboard viewer's client area has changed size", 0, 0, 0 },
							{ "WM_ASKCBFORMATNAME",	780,	0,	"Request of an owner displayed clipboard format", 0, 0, 0 },
							{ "WM_CHANGECBCHAIN",	781,	0,	"A window is being removed from the clipboard viewer chain", 0, 0, 0 },
							{ "WM_HSCROLLCLIPBOARD",782,	0,	"Event occurred in the clipboard viewer's horizontal scroll bar", 0, 0, 0 },
							{ "WM_QUERYNEWPALETTE",	783,	0,	"Window may realize its logical palette what focus is received", 0, 0, 0 },
							{ "WM_PALETTEISCHANGING",784,	0,	"A window is about to realize its logical palette", 0, 0, 0 },
							{ "WM_PALETTECHANGED",	785,	0,	"A window has realized its logical palette", 0, 0, 0 },
							{ "WM_HOTKEY",			786,	0,	"User pressed registered hotkey", 0, 0, 0 },
							{ "WM_PRINT",			791,	0,	"Render image in current device context request", 0, 0, 0 },
							{ "WM_PRINTCLIENT",		792,	0,	"Render client area in current device context request", 0, 0, 0 },
							{ "WM_DDE_INITIATE",	992,	0,	"Initiate a conversation with a DDE client", 0, 0, 0 },
							{ "WM_DDE_TERMINATE",	993,	0,	"Terminate a DDE conversation", 0, 0, 0 },
							{ "WM_DDE_ADVISE",		994,	0,	"DDE server data item update notification request", 0, 0, 0 },
							{ "WM_DDE_UNADVISE",	995,	0,	"Data or clipboard format client item should no longer be updated", 0, 0, 0 },
							{ "WM_DDE_ACK",			996,	0,	"DDE message has been received and processed", 0, 0, 0 },
							{ "WM_DDE_DATA",		997,	0,	"Data item received or data item available", 0, 0, 0 },
							{ "WM_DDE_REQUEST",		998,	0,	"Client requests the value of a data item", 0, 0, 0 },
							{ "WM_DDE_POKE",		999,	0,	"Client requests unsolicited data be accepted", 0, 0, 0 },
							{ "WM_DDE_EXECUTE",		1000,	0,	"Process a string as a series of commands", 0, 0, 0 },

							{ "CBEM_INSERTITEM",	1025,	0,	"Insert a new item", NOV, LPCBEITEMVI, ERRV },
							{ "CBEM_SETIMAGELIST",	1026,	0,	"Set associated image list", NOV, IMAGELISTV, NUMV },
							{ "CBEM_GETIMAGELIST",	1027,	0,	"Retrieve the handle of the associated image list", NOV, NOV, NUMV },
							{ "CBEM_GETITEM",		1028,	0,	"Retrieve item information", NOV, LPCBEITEMVI, SUCCESSV },
							{ "CBEM_SETITEM",		1029,	0,	"Set the attributes of an item", NOV, LPCBEITEMVI, SUCCESSV },
							{ "CBEM_GETCOMBOCONTROL",1030,	0,	"Return handle to the child combo box control", NOV, NOV, NUMV },
							{ "CBEM_GETEDITCONTROL",1031,	0,	"Return handle to the edit box portion of the ComboBoxEx control", NOV, NOV, NUMV },
							{ "CBEM_GETEXTENDEDSTYLE",1033,	0,	"Retrieve the extended styles of the control", NOV, NOV, NUMV },
							{ "CBEM_HASEDITCHANGED",1034,	0,	"Determines if user changed contents of the combo box edit control", NOV, NOV, NUMV },
// Unicode					{ "CBEM_INSERTITEM",	1035,	0,	"Insert a new item (Unicode)", NOV, NOV, NOV },
// Unicode					{ "CBEM_SETITEM",		1036,	0,	"Set the attributes of an item (Unicode)", NOV, NOV, NOV },
// Unicode					{ "CBEM_GETITEM",		1037,	0,	"Retrieve item information (Unicode)", NOV, NOV, NOV },
							{ "CBEM_SETEXTENDEDSTYLE",1038,	0,	"Set extended styles of the control", BITMASKV, BITMASKV, NUMV },
							{ "CBEM_SETUNICODEFORMAT",8197,	0,	"Sets Unicode format flag (Mapped to CCM_SETUNICODEFORMAT)", BOOLV, NOV, NUMV },							
							{ "CBEM_GETUNICODEFORMAT",8198,	0,	"Gets Unicode format flag (Mapped to CCM_GETUNICODEFORMAT)", NOV, NOV, NUMV }, 

							{ "Unknown",			-1,		0,	"Unknown message", 0, 0, 0 } };
// End control specific <<

// >> Start control specific
// Used for list box contents, tool tips, and parser
// Styles table
StyleList g_slTable[] =   {	{ "CBS_DROPDOWN",			CBS_DROPDOWN,		"Edit field displaying selection with drop down list box"},
							{ "CBS_DROPDOWNLIST",		CBS_DROPDOWNLIST,	"Static field displaying selection with drop down list box"},
							{ "CBS_SIMPLE",				CBS_SIMPLE,			"List box is displayed at all times"},
							
							{ "WS_BORDER",				WS_BORDER,			"Draws a border around window" },
							{ "WS_CAPTION",				WS_CAPTION,			"Includes a title bar" },
							{ "WS_CHILD",				WS_CHILD,			"Window that is a child of another" },
							{ "WS_CLIPCHILDREN",		WS_CLIPCHILDREN,	"Exclude area occupied by child windows when drawing in parent window" },
							{ "WS_CLIPSIBLINGS",		WS_CLIPSIBLINGS,	"Clips child windows relative to each other" },
							{ "WS_DISABLED",			WS_DISABLED,		"Disable window" },
							{ "WS_DLGFRAME",			WS_DLGFRAME,		"Draws a double border around window" },
							{ "WS_GROUP",				WS_GROUP,			"Specifies first control in a group of controls for arrow key navigation" },
							{ "WS_HSCROLL",				WS_HSCROLL,			"Include a horizontal scroll bar" },
							{ "WS_MAXIMIZE",			WS_MAXIMIZE,		"Make window maximum size" },
							{ "WS_MAXIMIZEBOX",			WS_MAXIMIZEBOX,		"Include maximize button" },
							{ "WS_MINIMIZE",			WS_MINIMIZE,		"Make window minimum size" },
							{ "WS_MINIMIZEBOX",			WS_MINIMIZEBOX,		"Include minimize button" },
							{ "WS_OVERLAPPED",			WS_OVERLAPPED,		"Include caption and a border" },
							{ "WS_OVERLAPPEDWINDOW",	WS_OVERLAPPEDWINDOW,"Include caption, border, title, system menu, thick frame, min/max boxes" },
							{ "WS_POPUP",				WS_POPUP,			"Window that is a popup window" },
							{ "WS_POPUPWINDOW",			WS_POPUPWINDOW,		"Popup window with a border, and system menu" },
							{ "WS_SYSMENU",				WS_SYSMENU,			"Include control menu in title bar" },
							{ "WS_TABSTOP",				WS_TABSTOP,			"Include in tab key navigation" },
							{ "WS_THICKFRAME",			WS_THICKFRAME,		"Draw a thick frame used to resize window" },
							{ "WS_VISIBLE",				WS_VISIBLE,			"Make window visible" },
							{ "WS_VSCROLL",				WS_VSCROLL,			"Include a vertical scroll bar" } };

// End control specific <<

// >> Start control specific
// Extended styles table
// Used for list box contents, tool tips, and parser
StyleList g_exslTable[] = {	{ "WS_EX_ACCEPTFILES",		WS_EX_ACCEPTFILES,	"Accept drag-and-drop files" },
							{ "WS_EX_CLIENTEDGE",		WS_EX_CLIENTEDGE,	"Draw 3D look with sunken border" },
							{ "WS_EX_CONTEXTHELP",		WS_EX_CONTEXTHELP,	"Include question mark button in title bar" },
							{ "WS_EX_CONTROLPARENT",	WS_EX_CONTROLPARENT,"Allow tab key control navigation" },
							{ "WS_EX_DLGMODALFRAME",	WS_EX_DLGMODALFRAME,"Draw window with double border" },
							{ "WS_EX_LEFT",				WS_EX_LEFT,			"Provide generic left-aligned properties" },
							{ "WS_EX_LEFTSCROLLBAR",	WS_EX_LEFTSCROLLBAR,"Place vertical scroll bar on left side of client area" },
							{ "WS_EX_LTRREADING",		WS_EX_LTRREADING,	"Provide left-to-right reading order properties" },
							{ "WS_EX_MDICHILD",			WS_EX_MDICHILD,		"Window that is a multiple document interface child window" },
							{ "WS_EX_NOPARENTNOTIFY",	WS_EX_NOPARENTNOTIFY,"Do not send creation and destruction notifications to parent" },
							{ "WS_EX_OVERLAPPEDWINDOW", WS_EX_OVERLAPPEDWINDOW,"Draw an extended client and window border" },
							{ "WS_EX_PALETTEWINDOW",	WS_EX_PALETTEWINDOW,"Draw extended window border and make a topmost window" },
							{ "WS_EX_RIGHT",			WS_EX_RIGHT,		"Provide generic right-aligned properties" },
							{ "WS_EX_RIGHTSCROLLBAR",	WS_EX_RIGHTSCROLLBAR,"Place vertical scroll bar on right side of client area" },
							{ "WS_EX_RTLREADING",		WS_EX_RTLREADING,	"Provide right-to-left reading order properties" },
							{ "WS_EX_STATICEDGE",		WS_EX_STATICEDGE,	"Draw 3D style that shows that input is not accepted" },
							{ "WS_EX_TOOLWINDOW",		WS_EX_TOOLWINDOW,	"Display smaller title bar and smaller display font" },
							{ "WS_EX_TOPMOST",			WS_EX_TOPMOST,		"Display as topmost window" },
							{ "WS_EX_TRANSPARENT",		WS_EX_TRANSPARENT,	"Windows underneath are not obscured" },
							{ "WS_EX_WINDOWEDGE",		WS_EX_WINDOWEDGE,	"Draw border with raised edge" } };
// End control specific <<

// >> Start control specific
// Message parameter value table
// Used by parser
ValueList g_vlTable[] = {   { "CBEIF_DI_SETITEM",		CBEIF_DI_SETITEM },
							{ "CBEIF_IMAGE",			CBEIF_IMAGE },
							{ "CBEIF_INDENT",			CBEIF_INDENT },
							{ "CBEIF_LPARAM",			CBEIF_LPARAM },
							{ "CBEIF_OVERLAY",			CBEIF_OVERLAY },
							{ "CBEIF_SELECTEDIMAGE",	CBEIF_SELECTEDIMAGE },
							{ "CBEIF_TEXT",				CBEIF_TEXT },
							{ "CBES_EX_CASESENSITIVE",	CBES_EX_CASESENSITIVE },
							{ "CBES_EX_NOEDITIMAGE",	CBES_EX_NOEDITIMAGE },
							{ "CBES_EX_NOEDITIMAGEINDENT",CBES_EX_NOEDITIMAGEINDENT },
							{ "CBES_EX_NOSIZELIMIT",	CBES_EX_NOSIZELIMIT },
							{ "CBES_EX_PATHWORDBREAKPROC",CBES_EX_PATHWORDBREAKPROC },

							{ "LPSTR_TEXTCALLBACK",		(INT)LPSTR_TEXTCALLBACK },
							{ "I_IMAGECALLBACK",		I_IMAGECALLBACK },
							{ "I_INDENTCALLBACK",		I_INDENTCALLBACK } };
// End control specific <<

#endif
