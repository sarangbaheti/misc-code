/******************************************************************************
Module name: CJTest.cpp
Written by: Jeffrey Cooperstein & Jeffrey Richter
******************************************************************************/


#include "stdafx.h"
#include "Resource.H"
#include "ChangeJrnl.h"
#include "PathDB.h"


///////////////////////////////////////////////////////////////////////////////


// This is the file where we will store our directory database. It will be
// in the root directory of the volume we are working with
#define DBSTORAGEFILE TEXT("\\CJTestPathDBFile.dat")

#define HIGHPART(x) ((DWORD) ((x) >> 32))
#define LOPART(x)   ((DWORD) (x))

// Global variables
struct APPGLOBALS {
   APPGLOBALS() {
      m_LastFileReferenceNumber = 0;
      m_LastSourceInfo = 0;
   }

   CChangeJrnl m_cj; // Change Journal
   CPathDB     m_db; // Directory Database

   // Members that help format display output
   DWORDLONG   m_LastFileReferenceNumber;
   DWORD       m_LastSourceInfo;

   // Flag that indicates that we've processed all records
   BOOL        m_fUpToDate; 
};

APPGLOBALS g_Globals;

// Prototypes
void ProcessAvailableRecords(HWND hwnd, BOOL fShowRecords);
void InitialzeForMonitoring(HWND hwnd);


///////////////////////////////////////////////////////////////////////////////


// Adds a string to an edit control
void AddText(HWND hwnd, LPCTSTR pszFormat, ...) {

   va_list argList;
   va_start(argList, pszFormat);

   TCHAR sz[20 * 1024];
   _vstprintf(sz, pszFormat, argList);
   va_end(argList);

   // If the edit control is longer than 20000 characters, 
   // chop off the first fifty lines.
   while (GetWindowTextLength(hwnd) > 20000) {
      Edit_SetSel(hwnd, 0, Edit_LineIndex(hwnd, 50));
      Edit_ReplaceSel(hwnd, TEXT(""));
   }
   int nLen = GetWindowTextLength(hwnd);
   Edit_SetSel(hwnd, nLen, nLen);
   Edit_ReplaceSel(hwnd, sz);
   int nLenNew = GetWindowTextLength(hwnd);
   Edit_SetSel(hwnd, nLenNew, nLenNew);
   Edit_Scroll(hwnd, 1, 0);
}


///////////////////////////////////////////////////////////////////////////////


BOOL Dlg_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam) {
   
   // Have the results window use a fixed-pitch font
   SetWindowFont(GetDlgItem(hwnd, IDC_RESULTS), 
      GetStockFont(ANSI_FIXED_FONT), FALSE);

   // The app will monitor the journal that is on the current drive
   TCHAR szCurrentDirectory[MAX_PATH];
   GetCurrentDirectory(MAX_PATH, szCurrentDirectory);

   // Initialize the CChangeJrnl class with the current drive letter and tell
   // it to allocate a buffer of 10000 bytes to read journal records
   if (!g_Globals.m_cj.Init(szCurrentDirectory[0], 10000)) {
      MessageBox(hwnd, TEXT("CChangeJrnl Initialization Error"), 
		  NULL, MB_OK);
      EndDialog(hwnd, IDCANCEL);
      return(FALSE);
   }

   SetFocus(GetDlgItem(hwnd, IDC_RESULTS));
   AddText(GetDlgItem(hwnd, IDC_RESULTS), TEXT("Monitoring %c:\\\r\n"),
      szCurrentDirectory[0]);

   TCHAR cDriveLetter;
   DWORDLONG CurUsnJournalID;
   USN CurUsn;

   // Try to load cached directory database from file
   BOOL fOk = g_Globals.m_db.StreamFromFile(DBSTORAGEFILE, &cDriveLetter,
      &CurUsnJournalID, &CurUsn);

   // If we were able to read cached data, and the data came from the correct
   // drive, we can pick up processing the journal where we left off.
   if (fOk && (cDriveLetter == szCurrentDirectory[0])) {

      g_Globals.m_fUpToDate = TRUE;

      // Start processing records where we left off
      g_Globals.m_cj.SeekToUsn(CurUsn, 0xFFFFFFFF, FALSE, CurUsnJournalID);

      // Process all available records (but don't output them to screen since
      // this could be very time consuming).
      // The ProcessAvailableRecords function will handle scenarios where the
      // journal is not active or the journal ID has changed since we cached
      // the data to disk.
      ProcessAvailableRecords(hwnd, FALSE);
   } else {
      // Make sure the dialog is visible because the next function will bring
      // up a modal dialog
      ShowWindow(hwnd, SW_SHOW);

      // There's no cached data for the directory database. We need to make
      // sure the journal is in the correct state, and populate the directory
      // database.
      InitialzeForMonitoring(hwnd);
   }
   return(FALSE);
}


///////////////////////////////////////////////////////////////////////////////


BOOL Dlg_OnSize(HWND hwnd, UINT state, int cx, int cy) {

   // Size the output edit control to fill the entire dialog
   int n = LOWORD(GetDialogBaseUnits());
   HWND hwndCtl = GetDlgItem(hwnd, IDC_RESULTS);
   SetWindowPos(hwndCtl, NULL, n, n, cx - n - n, cy - n - n, SWP_NOZORDER);
   return(FALSE);
}


///////////////////////////////////////////////////////////////////////////////


void DumpJrnlStats(HWND hwnd) {

   // Dump the information about the volume's journal
   HWND h = GetDlgItem(hwnd, IDC_RESULTS);
   USN_JOURNAL_DATA ujd;
   if (!g_Globals.m_cj.Query(&ujd)) {
      AddText(h, 
         TEXT("*** Error while querying volume for journal information ***"));
      return;
   }

   // Convert journal ID to time string
   TCHAR szDateTime[1024];
   if (!CChangeJrnl::GetDateTimeFormatFromFileTime(ujd.UsnJournalID,
      szDateTime, sizeof(szDateTime) / sizeof(szDateTime[0]))) {
      lstrcpy(szDateTime, TEXT("ERROR"));
   }

   AddText(h, TEXT("**************************************\r\n"));
   AddText(h, TEXT("UsnJournalID time = %s\r\n"), szDateTime);
   AddText(h, TEXT("UsnJournalID    = 0x%016I64X\r\n"), ujd.UsnJournalID);
   AddText(h, TEXT("FirstUsn        = 0x%016I64X\r\n"), ujd.FirstUsn);
   AddText(h, TEXT("NextUsn         = 0x%016I64X\r\n"), ujd.NextUsn);
   AddText(h, TEXT("LowestValidUsn  = 0x%016I64X\r\n"), ujd.LowestValidUsn);
   AddText(h, TEXT("MaxUsn          = 0x%016I64X\r\n"), ujd.MaxUsn);
   AddText(h, TEXT("MaximumSize     = 0x%016I64X\r\n"), ujd.MaximumSize);
   AddText(h, TEXT("AllocationDelta = 0x%016I64X\r\n"), ujd.AllocationDelta);
   AddText(h, TEXT("**************************************\r\n"));
}


///////////////////////////////////////////////////////////////////////////////


void Dlg_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify) {

   switch (id) {
      case IDCANCEL:
         // If we've kept up to date with the journal, save the directory
         // database out to disk.
         if (g_Globals.m_fUpToDate) {
            g_Globals.m_db.StreamToFile(DBSTORAGEFILE, g_Globals.m_cj);
         }
         EndDialog(hwnd, id);
         break;

      case ID_JRNLINFO:
         DumpJrnlStats(hwnd);
         break;

      case ID_DELETEJRNL:
         if (IDYES == MessageBox(hwnd,
            TEXT("Are you sure you want to delete the current journal?\r\n")
            TEXT("(It will be automatically recreated by the application)"),
            TEXT("Delete Change Journal"), MB_YESNO)) {

            // Delete the journal - Don't wait for it to return. When we try to
            // read more records, we'll see that the journal is gone. At that
            // point, the InitialzeForMonitoring function will re-create it
            USN_JOURNAL_DATA ujd;
            g_Globals.m_cj.Query(&ujd);
            g_Globals.m_cj.Delete(ujd.UsnJournalID, USN_DELETE_FLAG_DELETE);
         }
         break;
   }
}


///////////////////////////////////////////////////////////////////////////////


LRESULT Dlg_OnChangeJournalChanged(HWND hwnd, WPARAM wParam, LPARAM lParam) {

   // We get this notification if there are new records to process, or possibly
   // if the journal has been deleted. The ProcessAvailableRecords function
   // will handle both cases.
   ProcessAvailableRecords(hwnd, TRUE);
   return(0);
}


///////////////////////////////////////////////////////////////////////////////


INT_PTR WINAPI Dlg_Proc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
   
   switch (uMsg) {
      chHANDLE_DLGMSG(hwnd, WM_INITDIALOG, Dlg_OnInitDialog);
      chHANDLE_DLGMSG(hwnd, WM_SIZE,       Dlg_OnSize);
      chHANDLE_DLGMSG(hwnd, WM_COMMAND,    Dlg_OnCommand);
      case WM_CHANGEJOURNALCHANGED:
         Dlg_OnChangeJournalChanged(hwnd, wParam, lParam);
         break;
   }
   return(FALSE);
}


///////////////////////////////////////////////////////////////////////////////


int WINAPI _tWinMain(HINSTANCE hinstExe, HINSTANCE, LPTSTR pszCmdLine, int) {

   DialogBox(hinstExe, MAKEINTRESOURCE(IDD_CJTEST), NULL, Dlg_Proc);
   return(0);
}


///////////////////////////////////////////////////////////////////////////////


void ProcessAvailableRecords(HWND hwnd, BOOL fShowRecords /* = TRUE*/) {

   // Process all available journal records from the current location to the
   // end of the journal. Before this function is called, at least one call has
   // to be made to the SeekToUsn function. If this function completes without
   // error, it sets up a notification that waits for more data to become
   // available.

   HWND hwndOut = GetDlgItem(hwnd, IDC_RESULTS);
   SetWindowRedraw(hwndOut, FALSE);

   PUSN_RECORD pRecord;

   // Use EnumNext to loop through available records
   while (pRecord = g_Globals.m_cj.EnumNext()) {
      // Create a zero terminated copy of the filename
      WCHAR szFile[MAX_PATH];
      LPWSTR pszFileName = (LPWSTR) 
         ((PBYTE) pRecord + pRecord->FileNameOffset);
      int cFileName = pRecord->FileNameLength / sizeof(WCHAR);
      wcsncpy(szFile, pszFileName, cFileName);
      szFile[cFileName] = 0;

      // If this is a close record for a directory, we may need to adjust 
      // our directory database
      if (   0 != (pRecord->FileAttributes & FILE_ATTRIBUTE_DIRECTORY)
          && 0 != (pRecord->Reason & USN_REASON_CLOSE)) {

         // Process newly created directories
         if (0 != (pRecord->Reason & USN_REASON_FILE_CREATE)) {
            g_Globals.m_db.Add(pRecord->FileReferenceNumber, szFile,
               pRecord->ParentFileReferenceNumber);
         }

         // Process renamed directories
         if (0 != (pRecord->Reason & USN_REASON_RENAME_NEW_NAME)) {
            g_Globals.m_db.Change(pRecord->FileReferenceNumber, szFile,
               pRecord->ParentFileReferenceNumber);
         }

         // Process deleted directories
         if (0 != (pRecord->Reason & USN_REASON_FILE_DELETE)) {
            g_Globals.m_db.Delete(pRecord->FileReferenceNumber);
         }
      }

      // Dump the record to screen if requested
      if (fShowRecords) {
         CString szPath;
         TCHAR szFullName[MAX_PATH];

         // Get the full path for this record from the directory database
         if (g_Globals.m_db.Get(pRecord->ParentFileReferenceNumber, szPath)) {
            _stprintf(szFullName, TEXT("%s\\%s"), (LPCTSTR) szPath,
               (LPCTSTR) szFile);
         } else {
            _stprintf(szFullName, 
               TEXT("%s can not find path for objects parent ID 0x%016I64X"),
               szFile, pRecord->ParentFileReferenceNumber);
         }

         // If this record is dealing with a different file than the last
         // record we displayed, print its full path.
         if (g_Globals.m_LastFileReferenceNumber != 
            pRecord->FileReferenceNumber) {

            g_Globals.m_LastSourceInfo = -1;
            AddText(hwndOut, TEXT("%s\r\n"), (LPCTSTR) szFullName);
         }

         // Store the FRN of the current record so we know if we need to
         // re-print its full path on the next record
         g_Globals.m_LastFileReferenceNumber = pRecord->FileReferenceNumber;

         // If the source info has changed since the last record we displayed,
         // print the new source info
         if (g_Globals.m_LastSourceInfo != pRecord->SourceInfo) {
            AddText(hwndOut, TEXT(" SourceInfo = %i\r\n"), pRecord->SourceInfo);
            g_Globals.m_LastSourceInfo = pRecord->SourceInfo;
         }

         // Show the reason codes
         TCHAR szReason[1024];
         if (!CChangeJrnl::GetReasonString(pRecord->Reason, szReason,
            sizeof(szReason) / sizeof(szReason[0]))) {
            lstrcpy(szReason, TEXT("ERROR"));
         }

         AddText(hwndOut, TEXT("  %s"), szReason);

         // If the record has a 'rename' flag set, append the filename
         if (0 != (pRecord->Reason & 
            (USN_REASON_RENAME_OLD_NAME | USN_REASON_RENAME_NEW_NAME))) {
            AddText(hwndOut, TEXT(" (%s)"), (LPCTSTR) szFullName);
         }

         AddText(hwndOut, TEXT("\r\n"));
      }
   }
   // EnumNext will return NULL with the 'last error' set to NO_ERROR if
   // we reached the end of available journal records without problems
   BOOL fOk = (S_OK == GetLastError());

   SetWindowRedraw(hwndOut, TRUE);
   InvalidateRect(hwndOut, NULL, FALSE);

   if (fOk) {
      // We successfully processed all new records
      // Wait for more data. Specify a delay of 500 milliseconds after new data
      // is available so that we don't pound the journal with read requests
      // every time a new record is added
      g_Globals.m_cj.NotifyMoreData(hwnd, 500);
   } else {
      // There was a problem. The journal could have been deleted, the id could
      // have changed, or records may have been purged before we got to them.
      // No matter what it was, we have to invalidate cached data and start
      // from scratch
      InitialzeForMonitoring(hwnd);
   }
}


///////////////////////////////////////////////////////////////////////////////


void InitialzeForMonitoring(HWND hwnd) {

   // This function ensures that the journal on the volume is active, and it
   // will also populate the directory database.
   HWND hwndOut = GetDlgItem(hwnd, IDC_RESULTS);

   BOOL fOk = TRUE;
   USN_JOURNAL_DATA ujd;

   // Try to query for current journal information
   while (fOk && !g_Globals.m_cj.Query(&ujd)) {
      switch(GetLastError()) {
      case ERROR_JOURNAL_DELETE_IN_PROGRESS:
         // The system is deleting a journal. We need to wait for it to finish
         // before trying to query it again.
         AddText(hwndOut,  TEXT("Waiting for Delete to finish\r\n"));
         InvalidateRect(hwndOut, NULL, FALSE);
         UpdateWindow(hwndOut);
         g_Globals.m_cj.Delete(0, USN_DELETE_FLAG_NOTIFY);
         AddText(hwndOut,  TEXT("Delete finished\r\n"));
         break;

      case ERROR_JOURNAL_NOT_ACTIVE:
         // The journal is not active on the volume. We need to create it and
         // then query for its information again
         AddText(hwndOut,  TEXT("Journal not active - creating new one\r\n"));
         g_Globals.m_cj.Create(0x800000, 0x100000);
         break;

      default:
         // Some other error happened while querying the journal information.
         // There is nothing we can do from here
         AddText(hwndOut,  TEXT("Unable to query journal\r\n"));
         AddText(hwndOut,  TEXT("MONITORING STOPPED!\r\n"));
         g_Globals.m_fUpToDate = FALSE;
         fOk = FALSE;
         break;
      }
   }
   if (!fOk) {
      // We were not able to query the volume for journal information
      return;
   }

   // Start processing records at the start of the journal
   g_Globals.m_cj.SeekToUsn(ujd.FirstUsn, 0xFFFFFFFF, FALSE, ujd.UsnJournalID);

   // Make sure the user is willing to perform a rescan of all the directories
   // to populate the directory database
   int id = MessageBox(hwnd,
      TEXT("Full rescan needed to build directory database\r\n")
      TEXT("Possible Reasons:\r\n1) No cached data\r\n")
      TEXT("2) Journal ID has changed\r\n")
      TEXT("3) Some records were purged before we processed them\r\n")
      TEXT("\r\nContinue?"), TEXT("Perform Full Rescan"), MB_YESNO);

   if (id == IDYES) {
      // Use 'method 2' to populate the database
//    g_Globals.m_db.PopulateMethod1(g_Globals.m_cj);
      g_Globals.m_db.PopulateMethod2(g_Globals.m_cj);

      g_Globals.m_fUpToDate = TRUE;

      // Process all available records (but don't output them to screen since
      // this could be very time consuming).
      ProcessAvailableRecords(hwnd, FALSE);
   } else {
      // The user did not want to spend the time to populate the directory
      // database. There's nothing else we can do.
      AddText(hwndOut, TEXT("No Longer monitoring the journal\r\n"));
      g_Globals.m_fUpToDate = FALSE;
   }
}


//////////////////////////////// End of File //////////////////////////////////
