//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CJTest.rc
//
#define IDD_CJTEST                      101
#define IDR_CJTEST                      102
#define IDC_RESULTS                     1011
#define ID_JRNLINFO                     40001
#define ID_DELETEJRNL                   40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
