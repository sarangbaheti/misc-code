/******************************************************************************
Module name: PathDB.cpp
Written by: Jeffrey Cooperstein & Jeffrey Richter
******************************************************************************/


#include "stdafx.h"
#include "PathDB.h"


///////////////////////////////////////////////////////////////////////////////


BOOL CPathDB::Add(DWORDLONG Index, LPCTSTR szName, DWORDLONG ParentIndex) {

  DWORD dwOffset;
  if (mapIndexToOffset.Lookup(Index, dwOffset)) {
     return(FALSE); // Index already in database
  }
  rgszNames.Add(szName);
  rgParentIndex.Add(ParentIndex);
  mapIndexToOffset[Index] = rgszNames.GetSize() - 1;
  return(TRUE);
}


///////////////////////////////////////////////////////////////////////////////


BOOL CPathDB::Empty() {

   rgszNames.RemoveAll();
   rgParentIndex.RemoveAll();
   mapIndexToOffset.RemoveAll();
   return(TRUE);
}


///////////////////////////////////////////////////////////////////////////////


BOOL CPathDB::Get(DWORDLONG Index, CString &sz) {

   sz = TEXT("");
   do {
      DWORD dwOffset;
      if (!mapIndexToOffset.Lookup(Index, dwOffset)) {
         return(FALSE); // did not find all the parents
      }
      sz = rgszNames[dwOffset] + 
         ((sz.GetLength() != 0) ? TEXT("\\") : TEXT("")) + sz;
      Index = rgParentIndex[dwOffset];
   } while (Index != 0);
   return(TRUE);
}


///////////////////////////////////////////////////////////////////////////////


BOOL CPathDB::Change(DWORDLONG Index, LPCTSTR szName, DWORDLONG ParentIndex) {

   DWORD dwOffset;
   if (!mapIndexToOffset.Lookup(Index, dwOffset)) {
      return(FALSE); // not found
   }
   rgszNames[dwOffset] = szName;
   rgParentIndex[dwOffset] = ParentIndex;
   return(TRUE);
}


///////////////////////////////////////////////////////////////////////////////


BOOL CPathDB::Delete(DWORDLONG Index) {

   DWORD dwOffset;
   if (!mapIndexToOffset.Lookup(Index, dwOffset)) {
      return(FALSE); // not found
   }
   // NOTE: We loose memory in the rgszNames and rgParentIndex array
   // since we cannot shift the rest of the offsets down
   // We 'could' be more efficient here.

   // At the least, lets free the memory used by the string.
   rgszNames[dwOffset].Empty();
   mapIndexToOffset.RemoveKey(Index);
   return(TRUE);
}


///////////////////////////////////////////////////////////////////////////////


BOOL CPathDB::StreamToFile(LPCTSTR pszFile, CChangeJrnl &cj) { 

   // Save current state information to a file
   TCHAR cDriveLetter = cj.GetDriveLetter();
   DWORDLONG UsnJournalID = cj.GetCurUsnJrnlID();
   USN usn = cj.GetCurUsn();

   HANDLE hFile = CreateFile(pszFile, GENERIC_WRITE, 0, NULL,
      CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

   if (INVALID_HANDLE_VALUE == hFile) {
      return(FALSE);
   }

   BOOL fOk = TRUE;
   POSITION pos = mapIndexToOffset.GetStartPosition();
   DWORDLONG Index;
   DWORD dwOffset;
   DWORD dwWritten;
   fOk = fOk && WriteFile(hFile, &cDriveLetter, sizeof(cDriveLetter),
      &dwWritten, NULL);

   fOk = fOk && WriteFile(hFile, &UsnJournalID, sizeof(UsnJournalID),
      &dwWritten, NULL);

   fOk = fOk && WriteFile(hFile, &usn, sizeof(usn), &dwWritten, NULL);
   while ((pos != 0) && fOk) {
      mapIndexToOffset.GetNextAssoc(pos, Index, dwOffset);
      fOk = fOk && WriteFile(hFile, &Index, sizeof(Index),
         &dwWritten, NULL);

      fOk = fOk && WriteFile(hFile, &rgParentIndex[dwOffset],
         sizeof(rgParentIndex[dwOffset]), &dwWritten, NULL);

      DWORD dwLen = rgszNames[dwOffset].GetLength();
      fOk = fOk && WriteFile(hFile, &dwLen, sizeof(dwLen), &dwWritten, NULL);

      fOk = fOk && WriteFile(hFile, (LPCTSTR)rgszNames[dwOffset],
         dwLen * sizeof(rgszNames[dwOffset][0]), &dwWritten, NULL);
   }
   Index = -1;
   fOk = fOk && WriteFile(hFile, &Index, sizeof(Index), &dwWritten, NULL);
   CloseHandle(hFile);
   return(fOk);
}


///////////////////////////////////////////////////////////////////////////////


BOOL CPathDB::StreamFromFile(LPCTSTR pszFile, TCHAR *pcDriveLetter,
   DWORDLONG *pUsnJournalID, USN *pUsn) {

   // Load state information from a file
   HANDLE hFile = CreateFile(pszFile, GENERIC_READ, 0, NULL,
      OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN, NULL);
   if (INVALID_HANDLE_VALUE == hFile) {
      return(FALSE);
   }

   BOOL fOk = TRUE;
   POSITION pos = mapIndexToOffset.GetStartPosition();
   DWORD dwWritten;
   fOk = fOk && ReadFile(hFile, pcDriveLetter, sizeof(*pcDriveLetter),
      &dwWritten, NULL);

   fOk = fOk && ReadFile(hFile, pUsnJournalID, sizeof(*pUsnJournalID),
      &dwWritten, NULL);

   fOk = fOk && ReadFile(hFile, pUsn, sizeof(*pUsn), &dwWritten, NULL);

   while (fOk) {
      DWORDLONG Index;
      DWORDLONG ParentIndex;
      DWORD dwLen;
      fOk = fOk && ReadFile(hFile, &Index, sizeof(Index), &dwWritten, NULL);
      if (-1 == Index) {
         break;
      }
      fOk = fOk && ReadFile(hFile, &ParentIndex, sizeof(ParentIndex),
         &dwWritten, NULL);

      fOk = fOk && ReadFile(hFile, &dwLen, sizeof(dwLen),
         &dwWritten, NULL);

      LPTSTR psz = new TCHAR[dwLen+1];
      psz[dwLen] = 0;
      fOk = fOk && ReadFile(hFile, psz, dwLen * sizeof(TCHAR), 
         &dwWritten, NULL);

      Add(Index, psz, ParentIndex);
      delete[] psz;
   }
   CloseHandle(hFile);
   return(fOk);
}


///////////////////////////////////////////////////////////////////////////////


void CPathDB::PopulateMethod1(CChangeJrnl &cj) {

   Empty();

   // Fill the database by walking all directories on the volume. The function
   // RecursePath uses FindFirstFile/FindNextFile to walk the volume, and
   // GetFileInformationByHandle to get the file reference numbers of every
   // directory
   TCHAR szCurrentPath[_MAX_PATH];
   wsprintf(szCurrentPath, TEXT("%c:"), cj.GetDriveLetter());
   RecursePath(szCurrentPath, szCurrentPath, 0, 0);
}


///////////////////////////////////////////////////////////////////////////////


void CPathDB::PopulateMethod2(CChangeJrnl &cj) {

   Empty();

   // Enumerate the MFT for all entries. Store the file reference numbers of
   // any directories in the database.
   USN_JOURNAL_DATA ujd;
   cj.Query(&ujd);

   // Get the FRN of the root directory
   // This had BETTER work, or we can't do anything
   TCHAR szRoot[_MAX_PATH];
   wsprintf(szRoot, TEXT("%c:\\"), cj.GetDriveLetter());
   HANDLE hDir = CreateFile(szRoot, 0, FILE_SHARE_READ | FILE_SHARE_WRITE,
      NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);

   BY_HANDLE_FILE_INFORMATION fi;
   GetFileInformationByHandle(hDir, &fi);
   CloseHandle(hDir);
   DWORDLONG IndexRoot = (((DWORDLONG) fi.nFileIndexHigh) << 32) 
      | fi.nFileIndexLow;
   wsprintf(szRoot, TEXT("%c:"), cj.GetDriveLetter());
   Add(IndexRoot, szRoot, 0);

   MFT_ENUM_DATA med;
   med.StartFileReferenceNumber = 0;
   med.LowUsn = 0;
   med.HighUsn = ujd.NextUsn;

   // Process MFT in 64k chunks
   BYTE pData[sizeof(DWORDLONG) + 0x10000];
   DWORDLONG fnLast = 0;
   DWORD cb;
   while (DeviceIoControl(cj, FSCTL_ENUM_USN_DATA, &med, sizeof(med),
      pData, sizeof(pData), &cb, NULL) != FALSE) {

      PUSN_RECORD pRecord = (PUSN_RECORD) &pData[sizeof(USN)];
      while ((PBYTE) pRecord < (pData + cb)) {
         if (0 != (pRecord->FileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {

            CString sz((LPCWSTR)
               ((PBYTE) pRecord + pRecord->FileNameOffset),
               pRecord->FileNameLength / sizeof(WCHAR));

            Add(pRecord->FileReferenceNumber, sz,
               pRecord->ParentFileReferenceNumber);
         }
         pRecord = (PUSN_RECORD) ((PBYTE) pRecord + pRecord->RecordLength);
      }
      med.StartFileReferenceNumber = * (DWORDLONG *) pData;
   }
}


///////////////////////////////////////////////////////////////////////////////


void CPathDB::RecursePath(LPCTSTR pszPath, LPCTSTR pszFile,
   DWORDLONG ParentIndex, DWORD dwVolumeSerialNumber) {

   // Enumerate the directores in the current path and store the file reference
   // numbers in the database. Call this function recursively to enumerate into
   // the subdirectores.

   CString szPath2(pszPath);
   szPath2 += TEXT("\\");
   HANDLE hDir = CreateFile(szPath2, 0, FILE_SHARE_READ | FILE_SHARE_WRITE,
      NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);

   // NOTE: If we cannot get a handle to this, there is no need to recurs into
   // it (even though it might be possible). Example - we couldn't open it, but
   // FindFirst(...) succeeds for some reason. We don't care about any extra
   // information we can get by FindFirst inside this directory since we won't
   // have the FileIndex of this directory. Therefore, any objects under this
   // directory will not be able to have their names fully resolved (ie: when
   // we walk up the parent id's for an object below this one, we won't be able
   // to find this id)
   if (INVALID_HANDLE_VALUE == hDir) {
      return;
   }

   BY_HANDLE_FILE_INFORMATION fi;
   GetFileInformationByHandle(hDir, &fi);
   CloseHandle(hDir);

   if (0 == dwVolumeSerialNumber) {
      dwVolumeSerialNumber = fi.dwVolumeSerialNumber;
   }

   if (fi.nNumberOfLinks != 1) {
      ASSERT(FALSE);
   }

   if (dwVolumeSerialNumber != fi.dwVolumeSerialNumber) {
      // We've wondered onto another volume - This should only
      // happen if we recursed into a reparse point, but we check
      // for that below!
      ASSERT(FALSE);
      return;
   }

   LARGE_INTEGER index;
   index.LowPart = fi.nFileIndexLow;
   index.HighPart = fi.nFileIndexHigh;

   if (!Add(index.QuadPart, pszFile, ParentIndex)) {
      // Duplicate - The FRN for this directory was already
      // in our database. This shouldn't happen, but if it
      // does, there's no need to recurse into sub-directories
      return;
   }

   TCHAR szTempPath[_MAX_PATH];
   lstrcpy(szTempPath, pszPath);
   lstrcat(szTempPath, TEXT("\\*.*"));

   WIN32_FIND_DATA fd;
   HANDLE hSearch = FindFirstFile(szTempPath, &fd);
   if (INVALID_HANDLE_VALUE == hSearch) {
      // Something went wrong trying to enumerate the files/directories
      // in the current directory
      return;
   }

   do {
      TCHAR szTempRecursePath[_MAX_PATH];
      lstrcpy(szTempRecursePath, pszPath);
      lstrcat(szTempRecursePath, TEXT("\\"));
      lstrcat(szTempRecursePath, fd.cFileName);
      if (   (0 != (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
          && (0 != lstrcmp(fd.cFileName, TEXT(".")))
          && (0 != lstrcmp(fd.cFileName, TEXT("..")))
          && (0 == (fd.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT)) ) {

         RecursePath(szTempRecursePath, fd.cFileName, index.QuadPart,
            dwVolumeSerialNumber);
      }
   } while (FindNextFile(hSearch, &fd) != FALSE);

   FindClose(hSearch);
}


///////////////////////////////// End Of File /////////////////////////////////
