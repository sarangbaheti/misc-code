/******************************************************************************
Module name: PathDB.h
Written by: Jeffrey Cooperstein & Jeffrey Richter
******************************************************************************/

#pragma once

///////////////////////////////////////////////////////////////////////////////


#include "ChangeJrnl.h"


///////////////////////////////////////////////////////////////////////////////


class CPathDB {
public:
   BOOL Add(DWORDLONG Index, LPCTSTR szName, DWORDLONG ParentIndex);
   BOOL Get(DWORDLONG Index, CString &sz);
   BOOL Change(DWORDLONG Index, LPCTSTR szName, DWORDLONG ParentIndex);
   BOOL Delete(DWORDLONG Index);
   BOOL StreamToFile(LPCTSTR pszFile,CChangeJrnl &cj);
   BOOL StreamFromFile(LPCTSTR pszFile, TCHAR *pcDriveLetter,
      DWORDLONG *pUsnJournalID, USN *pUsn);

   void PopulateMethod1(CChangeJrnl &cj);
   void PopulateMethod2(CChangeJrnl &cj);

protected:
   CStringArray rgszNames;
   CArray<DWORDLONG, DWORDLONG&> rgParentIndex;
   CMap<DWORDLONG, DWORDLONG&, DWORD, DWORD> mapIndexToOffset;
   BOOL Empty();
   void RecursePath(LPCTSTR pszPath, LPCTSTR pszFile, DWORDLONG ParentIndex,
      DWORD dwVolumeSerialNumber);
};


//////////////////////////////// End of File //////////////////////////////////
