////////////////
// Standard MFC main frame window
//
class CMainFrame : public CFrameWnd {
public:
	virtual ~CMainFrame();

protected:
	CStatusBar	m_wndStatusBar;
	CToolBar		m_wndToolBar;
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
