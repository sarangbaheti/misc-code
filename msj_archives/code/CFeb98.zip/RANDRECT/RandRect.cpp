////////////////////////////////////////////////////////////////
// RANDRECT 1998 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// RANDRECT illustrates how to use CS_OWNDC in and MFC app.
// Compiles with VC++ 5.0 or later, under Windows 95.

#include "StdAfx.h"
#include "RandRect.h"
#include "MainFrm.h"
#include "Doc.h"
#include "View.h"
#include "TraceWin.h"

#ifndef _DEBUG
#include "PixieDlg.h"
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BEGIN_MESSAGE_MAP(CMyApp, CWinApp)
	//{{AFX_MSG_MAP(CMyApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

IMPLEMENT_DYNAMIC(CMyApp, CWinApp)

CMyApp::CMyApp()
{
}

CMyApp theApp;

BOOL CMyApp::InitInstance()
{
//	SetRegistryKey("MSJ");		// Save settings in registry "MSJ", not INI file
//	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	PxlTraceInit(); // initialize TraceWin tracing (see TraceWin.h)

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CMyDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CMyView));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	return TRUE;
}

//////////////////
// Idle loop: draw random rectangles
//
BOOL CMyApp::OnIdle(LONG lCount)
{
	// Get view window
	CFrameWnd* pFrame = (CFrameWnd*)m_pMainWnd;
	ASSERT_KINDOF(CFrameWnd, pFrame);
	ASSERT_VALID(pFrame);
	CWnd* pWnd = pFrame->GetActiveView();
	ASSERT_VALID(pWnd);

	// get client area rectangle
	CRect rcClient;
	pWnd->GetClientRect(&rcClient);

	// create randome rectangle
	CRect rc(
		rand() % rcClient.Width(),
		rand() % rcClient.Height(),
		rand() % rcClient.Width(),
		rand() % rcClient.Height());

	// Now paint the rectangle
	CClientDC dc(pWnd);
	CBrush b( RGB(rand()&255, rand()&255, rand()&255));
	CBrush* pOldBrush = dc.SelectObject(&b);
	dc.Rectangle(&rc);
	dc.SelectObject(pOldBrush);

	return TRUE;			// tell MFC to keep calling idle function
}

//////////////////
// Custom about dialog.
//
void CMyApp::OnAppAbout()
{
#ifdef _DEBUG
	CDialog(IDD_ABOUTBOX).DoModal();
#else
	static DLGLINK links[] = {
		{ IDC_STATICURLPD,  NULL },
		{ IDC_STATICURLMSJ,  _T("http://www.microsoft.com/msj") },
	};
	const NUMLINKS = sizeof(links)/sizeof(links[0]);
	CPixieDlg(IDD_ABOUTBOX, links, NUMLINKS).DoModal();
#endif
}
