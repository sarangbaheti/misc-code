////////////////
// Standard MFC view
//
class CMyView : public CView {
public:
	virtual ~CMyView();
	CMyDoc* GetDocument() { return (CMyDoc*)m_pDocument; }

	//{{AFX_VIRTUAL(CMyView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

protected:
	DECLARE_DYNCREATE(CMyView)
	CMyView();

	//{{AFX_MSG(CMyView)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
