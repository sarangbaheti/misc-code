////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "StdAfx.h"
#include "PixieDlg.h"
#include "StatLink.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////
// Implementation for CPixieDlg -- special dialog with various pixie features
//
IMPLEMENT_DYNAMIC(CPixieDlg, CDialog)

//////////////////
// Create dialog: add hyperlinks and single dib allowed
//
// arLinks	Array of DLGLINKs. Each entry specifies the ID of a static control
//          and a hpyerlink. Clicking the control navigates the link. If the
//          target text is NULL, CPixieDlg uses the window (static) text.
//
// nLinks	size of array
//
// nIDBmp	ID of a bitmap and a static control for a DIB. CPixieDlg will
//          display the bitmap even on 256 color systems (handles palette msgs).
//
// lpszLinkBmp
//				optional target hyperlink for bitmap. CLicking bitmap
//          navigates link.
//
CPixieDlg::CPixieDlg(UINT nID, DLGLINK* arLinks, UINT nLinks) : CDialog(nID)
{
	m_arLinks  = arLinks;
	m_nLinks   = nLinks;
}

CPixieDlg::~CPixieDlg()
{
}

//////////////////
// Initialize dialog: hook up (subclass) all the CStaticLink's
//
BOOL CPixieDlg::OnInitDialog()
{
	for (UINT i=0; i < m_nLinks; i++) {
		CStaticLink* pStaticLink = new CStaticLink(m_arLinks[i].text, TRUE);
		ASSERT(pStaticLink);

#ifdef _DEBUG
		// sanity-checking: window must exist and be a static control
		HWND hwnd = ::GetDlgItem(m_hWnd, m_arLinks[i].nID);
		ASSERT(hwnd);
		TCHAR classname[16];
		GetClassName(hwnd, classname, sizeof(classname));
		ASSERT(_tcscmp(classname, _T("Static")) ==0);
#endif

		// hook it up to MFC
		VERIFY(pStaticLink->SubclassDlgItem(m_arLinks[i].nID, this));
	}
	return CDialog::OnInitDialog();
}
