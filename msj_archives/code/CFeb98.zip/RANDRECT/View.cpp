////////////////////////////////////////////////////////////////
// RANDRECT 1998 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "StdAfx.h"
#include "RandRect.h"
#include "Doc.h"
#include "View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CMyView, CView)

BEGIN_MESSAGE_MAP(CMyView, CView)
	//{{AFX_MSG_MAP(CMyView)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CMyView::CMyView()
{
}

CMyView::~CMyView()
{
}

void CMyView::OnDraw(CDC* pDC)
{
	CMyDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
}

const LPCTSTR MYCLASSNAME = _T("RandRectView");

//////////////////
// Handle pre-creation: register new class like MFC class,
// but with private DC style turned on.
//
BOOL CMyView::PreCreateWindow(CREATESTRUCT& cs)
{
	if (CView::PreCreateWindow(cs)) {
		static BOOL bRegistered = FALSE;		// flag for first-time init

		if (!bRegistered) {
			// This is the first time a view is being created.
			// Need to register the view class.
			//
			TRACE("CMyView::PreCreateWindow, MFC classname = %s\n", cs.lpszClass);
			WNDCLASSEX wc;
			wc.cbSize = sizeof(WNDCLASSEX);

			// Get class information for MFC default view.
			// The classname is in cs.lpszClass
			GetClassInfoEx(AfxGetInstanceHandle(), cs.lpszClass, &wc);

			// Modify name and style
			wc.lpszClassName = MYCLASSNAME;
			wc.style |= CS_OWNDC;

			// Register new class
			VERIFY(RegisterClassEx(&wc));
		}
		cs.lpszClass = MYCLASSNAME;
		return TRUE;
	}
	return FALSE;
}
