////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// File name utilities
//
#ifndef __FILENAME_H
#define __FILENAME_H

#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <io.h>

#ifndef BOOL
typedef int BOOL;
#endif

#ifndef LPCSTR
typedef const char* LPCSTR;
#endif

//#define MAX_PATH 256

//////////////////
// Class for manipulating a filename
//
class CFileName {
private:
	static char g_lpszPathSep[2];
	static char g_lpszDriveSep[2];
	static char g_lpszExtSep[2];
	static const char* g_lpszBadChars;

protected:
	char* m_path;		// full path name
	char* m_path2;		// copy used for pieces below
	LPCSTR m_dir;		// directory
	LPCSTR m_name;		// name (without extension)
	LPCSTR m_ext;		// extension
	int	 m_err;		// error, if any

	int  Validate(LPCSTR name); // check for valid fine name
	void CommonConstruct();		 // common constructor
	void CommonDestruct();		 // common destructor

public:
	CFileName();
   CFileName(LPCSTR path);
   CFileName(LPCSTR dir, LPCSTR name, LPCSTR ext, char drv=0);
   CFileName(const CFileName& fn2);
   ~CFileName();

	CFileName& operator=(const CFileName&);
	CFileName& operator=(LPCSTR path);

	char Drive() const;
	LPCSTR Name() const	{ assert(m_name); return m_name; }
	LPCSTR Dir() const	{ assert(m_dir);  return m_dir; }
	LPCSTR Ext() const	{ assert(m_ext);  return m_ext; }
	LPCSTR Path() const	{ assert(m_path); return m_path; }

	enum { E_OK=0, E_TOO_LONG, E_BAD_CHAR };
	int  Error() const   { return m_err; }

	operator LPCSTR()	const { return Path(); }

	int Build(LPCSTR dir, LPCSTR name, LPCSTR ext, char drv=0);
	int Parse(LPCSTR path);

	static void Initialize(const char* lpszForbid,
		char cPathSep, char cDriveSep, char cExtSep);
};

//////////////////
// Class to to navigate files that match a spec with wildcards
//
class CFileSpec : public _finddata_t {
	char	m_filespec[_MAX_PATH];
	char	m_fullpath[_MAX_PATH];
	long	m_hfile;		// handle from findfirst

public:
	CFileSpec() {
		m_hfile = -1;
	}

	~CFileSpec() {
		if (m_hfile!=-1)
			_findclose(m_hfile);
	}

	BOOL First(const char* filespec) {
		if (m_hfile!=-1)
			_findclose(m_hfile);
		strcpy(m_filespec, filespec);
		return (m_hfile=_findfirst((char*)filespec, this)) != -1;
	}

	BOOL Next() {
		return m_hfile!=-1 && _findnext(m_hfile, this)==0;
	}

	const char* GetPathName() {
		strcpy(m_fullpath, m_filespec);
		char *p = m_fullpath + strlen(m_fullpath);
		while (p-->m_fullpath && *p!='\\')
			*p=0;
		strcat(m_fullpath, name);
		return m_fullpath;
	}
};

#endif // _FILENAME_H
