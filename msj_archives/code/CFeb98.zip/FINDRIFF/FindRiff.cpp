////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// 
// This program extracts RIFF files (avi and wav) from an EXE or DLL.
// To build: 
//		cl findriff.cpp

#include <stdio.h>
#include "FileName.h"

char buf[1024];

const char RIFF[] = "RIFF";				 // RIFF tag
const char AVI [] = "AVI ";				 // AVI tag
const char WAVE[] = "WAVE";				 // WAV tag

//////////////////
// This function opens a file and searches it for RIFF files
//
int FindRiff(const char* lpFileName)
{
	FILE *fp = fopen(lpFileName, "rb");
	if (fp==NULL) {
		fprintf(stderr, "Couldn't open file '%s'\n", lpFileName);
		return 0;
	}

	int c;				// char read
	int nFound = 0;	// number of RIFF files found in this file
	int iMatch = 0;	// offset into RIFF[] of char I'm looking for next
	
	while ((c = fgetc(fp)) != EOF) {

		if (c == RIFF[iMatch]) {			 // if match:

			if (++iMatch >= 4) {				 // if all match:

				// found a RIFF file!
				long pos = ftell(fp);		 // remember pos

				// read size as next four bytes, in proper order LSB to MSB
				unsigned int b1 = fgetc(fp);
				unsigned int b2 = fgetc(fp);
				unsigned int b3 = fgetc(fp);
				unsigned int b4 = fgetc(fp);
				unsigned long size = b1 | b2<<8 | b3<<16 | b4<<24;

				// read 4-character type
				char type[4];
				fread(type, 1, 4, fp);

				if (strncmp(type, AVI, 4)==0 || strncmp(type, WAVE, 4)==0) {

					// found "AVI " or "WAVE "

					// generate new filename
					char newfilename[16];
					static int uniqueid = 0;

					sprintf(newfilename, "FILE%04d.%s", uniqueid++,
						strncmp(type, AVI, 4)==0 ? "AVI" : "WAV");

					// create new file
					FILE* fpNew = fopen(newfilename, "wb");
					if (fpNew==NULL) {
						fprintf(stderr, "Error creating file %s\n", newfilename);

					} else {
						// Copy from source to new file. Size of file is size of
						// chunk data plus 8 = size of header (ID + size field)
						// 
						printf("Creating %s\n", newfilename);
						fseek(fp, pos-4, SEEK_SET);
						size += 8;
						while (size-- > 0)
							fputc(fgetc(fp), fpNew);
						fclose(fpNew);
						nFound++;
					}
				}
				iMatch = 0;
			}
		} else {
			iMatch = 0;
		}
	}
	fclose(fp);
	return nFound;
}

//////////////////
// Main entry point
//
int main(int argc, char* argv[])
{
	if (argc < 2) {
		printf("FindRiff written 10-20-97 by Paul Dilascia\n");
		printf("Purpose: to find RIFF (AVI/WAV) resources in EXEs and DLLs\n");
		printf("Usage:   FindRiff <filespec>\n");
		printf("         findriff will create new files in the current directory,\n");
		printf("         using the names FILE0000.AVI, FILE0001.AVI, etc.\n");
		return 1;
	}

	// Do for each file in the file spec
	int totalFound = 0;
	for (int i=1; i < argc; i++) {
		CFileSpec spec;
		int nProcessed = 0;
		for (BOOL bMore = spec.First(argv[i]); bMore; bMore=spec.Next()) {
			if ((spec.attrib & ~_A_ARCH)==0) {
				int nFound = FindRiff(spec.GetPathName());
				printf("%d files found in %s\n", nFound, spec.GetPathName());
				nProcessed++;
				totalFound += nFound;
			}
		}
		if (nProcessed==0) {
			fprintf(stderr, "No files found to match '%s' \n", argv[i]);
		}
	}
	if (totalFound > 0) {
		printf("Warning: it may be illegal to copy audio/video clips--check with vendor before using!\n");
	}
	return 0;
}

