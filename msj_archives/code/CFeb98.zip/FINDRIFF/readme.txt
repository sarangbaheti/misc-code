To build FindRiff, type

	cl findriff.cpp

Make sure your PATH includes the VC 5.0 compiler, and your LIB and
INCLUDE variables are set up properly.
