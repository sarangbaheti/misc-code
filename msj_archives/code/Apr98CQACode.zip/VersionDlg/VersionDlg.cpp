////////////////////////////////////////////////////////////////
// VersionDlg 1998 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// VersionDlg illustrates how to use CModuleVersion and DllGetVersion to
// read the version info for a DLL/EXE. The only interesting function
// for the purpose of CModuleVersion is OnChangedModule, which is called
// when the user enters a new module name into the edit control.
//

#include "stdafx.h"
#include "resource.h"
#include "ModulVer.h"
#include "StatLink.h"
#include "TraceWin.h"
//#include <shlwapi.h> // if you have the Nov 1997 SDK installed

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVersionDialog dialog
//
class CVersionDialog : public CDialog {
public:
	CVersionDialog(CWnd* pParent = NULL);
	CString	m_sModuleName;  // module name typed by user

protected:
	CStaticLink	m_wndLink1;  // web link
	CStaticLink	m_wndLink2;	 // web link
	CStaticLink	m_wndLink3;	 // web link

	virtual void DoDataExchange(CDataExchange* pDX);
	virtual BOOL OnInitDialog();
	virtual void OnOK();

	afx_msg void OnChangedModule();
	DECLARE_MESSAGE_MAP()
};

////////////////////////////////////////////////////////////////
// CMyApp
//
class CMyApp : public CWinApp {
public:
	CMyApp() { }
	virtual BOOL InitInstance();
} theApp;

/////////////////
// Initialize: just run the dialog and quit.
//
BOOL CMyApp::InitInstance()
{
	PxlTraceInit();			// initialize TraceWin
	CVersionDialog dlg;		// create dialog..
	dlg.DoModal();				// ..run it
	return FALSE;				// ..and quit
}

//////////////////////////////////////////////////////////////////
// CVersionDialog
//
BEGIN_MESSAGE_MAP(CVersionDialog, CDialog)
	ON_EN_CHANGE(IDC_EDIT_MODULE,  OnChangedModule)
END_MESSAGE_MAP()

CVersionDialog::CVersionDialog(CWnd* pParent) : CDialog(IDD_VERSION, pParent)
{
}

/////////////////
// Initialize dialog: subclass static hyperlinks
//
BOOL CVersionDialog::OnInitDialog()
{
	m_wndLink1.SubclassDlgItem(IDC_STATICPD,  this,
		_T("http://pobox.com/~dilascia"));
	m_wndLink2.SubclassDlgItem(IDC_STATICMSJ, this,
		_T("http://www.microsoft.com/msj"));
	m_wndLink3.SubclassDlgItem(IDC_ICONMSJ, this,
		_T("http://www.microsoft.com/msj"));

	return CDialog::OnInitDialog();
}

/////////////////
// When user pressed Enter, don't exit
//
void CVersionDialog::OnOK()
{
	return; // (don't exit)
}

//////////////////
// Standard MFC DDX data exchange for edit control
//
void CVersionDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_MODULE, m_sModuleName);
}

//////////////////
// User changed the module name: vet version info if I can.
//
void CVersionDialog::OnChangedModule() 
{
	UpdateData(TRUE);			// get dialog data (module name)
	
	CString s;
	CModuleVersion ver;

	// 1st get version using File version API
	// 
	if (ver.GetFileVersionInfo(m_sModuleName)) {
		// display file version from VS_FIXEDFILEINFO struct
		s.Format("Version: %d.%d.%d.%d\n",
			HIWORD(ver.dwFileVersionMS), LOWORD(ver.dwFileVersionMS),
			HIWORD(ver.dwFileVersionLS), LOWORD(ver.dwFileVersionLS));

		// display a bunch of string values
		static LPCTSTR Keys[] = {
			_T("CompanyName"),
				_T("FileDescription"),
				_T("FileVersion"),
				_T("InternalName"),
				_T("LegalCopyright"),
				_T("OriginalFilename"),
				_T("ProductName"),
				_T("ProductVersion"),
				NULL
		};

		for (int i=0; Keys[i]; i++) {
			CString temp;
			temp.Format("%s:\t%s\n", Keys[i], ver.GetValue(Keys[i]));
			s += temp;
		}
	}
	// set static text
	GetDlgItem(IDC_STATICINFO)->SetWindowText(s);

	// 2nd get version using DllGetVersion API
	//
	s.Empty();
	DLLVERSIONINFO dvi;
	if (ver.DllGetVersion(m_sModuleName, dvi)) {
		s.Format(_T("DLL Version = %d.%02d\nBuild# = %d\n"), 
			dvi.dwMajorVersion, 
			dvi.dwMinorVersion, 
			dvi.dwBuildNumber);

		s +=_T("Platform is ");
		if (dvi.dwPlatformID == DLLVER_PLATFORM_WINDOWS)
			s +=_T("Windows");
		else if (dvi.dwPlatformID == DLLVER_PLATFORM_NT)
			s +=_T("Windows NT");
		else 
			s += _T("unrecognized");

	} else {
		s += _T("This file does not implement DllGetVersion.");
	}

	// set static text
	GetDlgItem(IDC_STATICINFO2)->SetWindowText(s);
}
