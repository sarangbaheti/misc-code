//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VersionDlg.rc
//
#define IDR_MAINFRAME                   2
#define IDD_VERSION                     102
#define IDI_ICONMSJ                     103
#define IDB_BITMAPMSJ                   105
#define IDC_EDIT_MODULE                 1013
#define IDC_STATICINFO                  1014
#define IDC_STATICPD                    1015
#define IDC_STATICMSJ                   1016
#define IDC_STATICINFO2                 1017
#define IDC_ICONMSJ                     1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
