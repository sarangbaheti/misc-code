/******************************************************************************
Module name: SndMsgBg.C
Written by: Jeffrey Richter
******************************************************************************/


#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include "resource.h"


///////////////////////////////////////////////////////////////////////////////


// Declare the semaphore that guards access to shared data.
HANDLE g_hSem;
// The code that accesses the shared data has been removed
// from this sample application in order to keep the source 
// code easier to read.


// This is the user-defined message that is sent to 
// the dialog box procedure.  NOTE: Because our window is a 
// dialog box, this message must be >= (WM_USER + 100) so that
// it does not conflict with any DM_* messages.
#define UM_INCNUM    (WM_USER + 100)


///////////////////////////////////////////////////////////////////////////////


DWORD WINAPI OtherWindowThread (PVOID pvThreadParm) {

   // Create an unowned dialog box controlled by its own thread.
   DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_NUMBER),
      NULL, NULL);

   return(0);  // Never executes
}


///////////////////////////////////////////////////////////////////////////////


DWORD WINAPI IncrementThread (PVOID pvThreadParm) {
   HWND hwnd = (HWND) pvThreadParm;

   while (TRUE) {
      Sleep(250);    // Sleep for 1/4 of a second.

      // Originally, I had the call to PostMessage below:
      // PostMessage(hwnd, UM_INCNUM, 0, 0);

      // However, I would prefer to use SendMessage here.
      // But, if I use SendMessage instead of PostMessage, 
      // the primary thread and the IncrementThread thread
      // deadlock and the number value stops incrementing.
      SendMessage(hwnd, UM_INCNUM, 0, 0);
   }

   return(0);  // Never executes
}


///////////////////////////////////////////////////////////////////////////////


BOOL SndMsgBug_OnInitDialog (HWND hwnd, HWND hwndFocus, LPARAM lParam) {

   DWORD dwThreadId;

   // The semaphore must be created before any 
   // threads that might attempt to use it.
   g_hSem = CreateSemaphore(NULL, 1, 1, NULL);
   CreateThread(NULL, 0, OtherWindowThread, NULL, 0, &dwThreadId);
   CreateThread(NULL, 0, IncrementThread, (PVOID) hwnd, 0, &dwThreadId);
   return(TRUE);
}


///////////////////////////////////////////////////////////////////////////////


void SndMsgBug_OnCommand (HWND hwnd, int id, HWND hwndCtl, UINT codeNotify) {

   switch (id) {
      case IDCANCEL:					 // Allows dialog box to close
         EndDialog(hwnd, id);
         break;
   }   
}


///////////////////////////////////////////////////////////////////////////////

void SndMsgBug_OnMouseMove (HWND hwnd, int x, int y, UINT keyFlags) {

   if (keyFlags & MK_LBUTTON) {
      // Only increment the number if the primary mouse button is down.
      SendMessage(hwnd, UM_INCNUM, 0, 0);
   }
}
        

///////////////////////////////////////////////////////////////////////////////


BOOL WINAPI SndMsgBug_DlgProc (HWND hwnd, UINT uMsg, 
   WPARAM wParam, LPARAM lParam) {

   HWND hwndNum = FindWindow(NULL, __TEXT("Number Value"));
   UINT uNum;

   switch (uMsg) {

      case UM_INCNUM:
         WaitForSingleObject(g_hSem, INFINITE);

         // The code below performs the actions shown and also
         // accesses the shared data protected by the semaphore.

         // NOTE: For this sample application, the accesses to 
         // the shared data have been removed in order to keep
         // the source code easier to read and understand.

         if (IsWindow(hwndNum)) {
#if ORIGINAL_CODE
            // JMR: This is the original source code.
            BOOL fTranslated;
            uNum = GetDlgItemInt(hwndNum, IDC_NUMBER,
               &fTranslated, FALSE);
            SetDlgItemInt(hwndNum, IDC_NUMBER, uNum + 1, FALSE);               
#else
            // JMR: This is the new code that corrects the problem.
            {
            HWND hwndNumVal = GetDlgItem(hwndNum, IDC_NUMBER);
            char szNum[20];

            // Get the number as a string
            SendMessageTimeout(hwndNumVal, WM_GETTEXT, 
               sizeof(szNum), (LPARAM) szNum, 
               SMTO_BLOCK, INFINITE, NULL);

            // Convert the string number to an integer, add 1, and
            // convert the integer back to a string.
            uNum = atoi(szNum) + 1;
            _ultoa(uNum, szNum, 10);

            // Set the number as a string.
            SendMessageTimeout(hwndNumVal, WM_SETTEXT, 
               0, (LPARAM) szNum, SMTO_BLOCK, INFINITE, NULL);
            }
#endif
         }
         ReleaseSemaphore(g_hSem, 1, NULL);
         break;

		// Standard Window's messages
      HANDLE_MSG(hwnd, WM_INITDIALOG, SndMsgBug_OnInitDialog);
      HANDLE_MSG(hwnd, WM_COMMAND,    SndMsgBug_OnCommand);
      HANDLE_MSG(hwnd, WM_MOUSEMOVE,  SndMsgBug_OnMouseMove);
   }

   return(FALSE);						 // We didn't process the message.
}


///////////////////////////////////////////////////////////////////////////////


int WINAPI WinMain (HINSTANCE hinstExe, HINSTANCE hinstPrev, 
   LPSTR lpszCmdLine, int nCmdShow) {

   DialogBox(hinstExe, MAKEINTRESOURCE(IDD_SNDMSGBUG),
      NULL, SndMsgBug_DlgProc);

   // NOTE: The code to properly terminate the threads and 
   // close the semaphore is NOT shown in order to keep the 
   // sample's source code easier to read and understand.
	return(0);
}


//////////////////////////////// End of File //////////////////////////////////
