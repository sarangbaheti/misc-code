//==================================================
// ModuleList - Matt Pietrek 1998
// Microsoft Systems Journal, September 1998
// FILE: ModuleList.CPP
//==================================================
#include <windows.h>
#include <COMMCTRL.H>
#pragma hdrstop
#include "ModuleList.h"
#include "ModuleListClasses.h"
#include "ModuleListOSCode.h"

// Helper function prototypes
void    Handle_WM_INITDIALOG(HWND hDlg);
void    Handle_WM_COMMAND(HWND hWndDlg, WPARAM wParam, LPARAM lParam );
void    Handle_WM_CLOSE( HWND hDlg );
void    Handle_WM_SIZE(HWND hWndDlg, WPARAM wParam, LPARAM lParam );
BOOL    CALLBACK ModuleListDlgProc(HWND,UINT,WPARAM,LPARAM);
void    GetSetPositionInfoFromRegistry( BOOL fSave, POINT *lppt );
void    PopulateTree( HWND hWndTree );

HTREEITEM AddTreeviewSubItem(   HWND hWndTree,
                                HTREEITEM hTreeItem,
                                LPTSTR pszItemText,
                                BOOL fItemData = FALSE,
                                LPARAM itemData = 0 );

BOOL GetFileDescription( PSTR pszFileName, PSTR pszDesc, unsigned cbDesc );
                                
// ======================= String literals ===============================
char gszRegistryKey[] = "Software\\WheatyProductions\\ModuleList";

char gszMBTitle[] =  "ModuleList, by Matt Pietrek - MSJ September 1998" ;

char gszAboutText[] =   "ModuleList shows all of the loaded DLLs in the "
                        "system.  Each DLL node contains the filename, the "
                        "load address, the directory where the DLL was loaded "
                        "from, and the number of processes using the DLL.";
                        
    
// =========================== Global Variables =============================

HWND g_hWndTree = 0;    // HWND of the TreeView control
HWND g_hDlg = 0;        // HWND of the dialog

ModuleList          g_ModuleList;           // List of all loaded modules
ProcessIdToNameMap  g_ProcessIdToNameMap;   // List of all process names & IDs

// ============================== Start of code ===============================

int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    LPSTR lpszCmdLine, int nCmdShow )
{
    InitCommonControls();   // Needed for the TreeView control
    
    // Bring up the user interface
    DialogBox(  hInstance, MAKEINTRESOURCE(IDD_MODULELIST),
                0, (DLGPROC)ModuleListDlgProc );
    return 0;
}

BOOL
CALLBACK ModuleListDlgProc( HWND hDlg,UINT msg,WPARAM wParam,LPARAM lParam )
{
    //
    // The dialog procedure for the main window
    //
    switch ( msg )
    {
        case WM_INITDIALOG:
            Handle_WM_INITDIALOG( hDlg ); return TRUE;
        case WM_CLOSE:
            Handle_WM_CLOSE( hDlg ); break;
        case WM_SIZE:
            Handle_WM_SIZE( hDlg, wParam, lParam ); break;
        case WM_COMMAND:
            Handle_WM_COMMAND( hDlg, wParam, lParam ); break;
        // let everything else fall through
    }
    return FALSE;
}

//============================================================================
// Walk through the list of objects, adding each object name to the root of
// the treeview
//============================================================================

void PopulateTree( HWND hWndTree )
{
    // Empty the TreeView
    TreeView_DeleteAllItems( hWndTree );

    // Empty out the data structures (if necessary)
    g_ModuleList.Clear();
    g_ProcessIdToNameMap.Clear();

    // Populate the data structures.  Try using the Toolhelp32 APIs first
    BOOL fModListOK;
    
    fModListOK = PopulateModuleList_ToolHelp32(
                                    g_ModuleList, g_ProcessIdToNameMap );
    if ( !fModListOK )
    {
        // ToolHelp32 didn't work (probably wasn't present).  Try PSAPI.DLL 
        fModListOK = PopulateModuleList_PSAPI(
                            g_ModuleList, g_ProcessIdToNameMap );

        if ( !fModListOK )  // PSAPI.DLL probably wasn't found
            return;
    }

    // Enumerate the module list, adding the info for each DLL to the TreeView

    PModuleInstance pModInst = 0;   // 0 begins the enumeration
    
    while ( pModInst = g_ModuleList.Enumerate(pModInst) )
    {
        // Make a copy of the full DLL path that we can slice and dice
        char szFullModuleName[MAX_PATH+128];
        lstrcpy( szFullModuleName, pModInst->m_pszName );
        
        PSTR pszBaseName = strrchr( szFullModuleName, '\\' );
        *pszBaseName = 0;   // Separate base name from path
        pszBaseName++;      // Advanced past the null separator we just added
        strupr( pszBaseName );

        // Create the top level string for the DLL, then add it to the TreeView
        char szModuleDescription[MAX_PATH+128];     
        wsprintf( szModuleDescription, "%s  (%s)",
                pszBaseName, szFullModuleName );

        HTREEITEM hTreeItem = AddTreeviewSubItem(   g_hWndTree,
                                                    NULL,
                                                    szModuleDescription );

        // Create and add a subitem string describing the load address and
        // DLL reference count
        char szOtherModuleInfo[MAX_PATH+128];       
        wsprintf( szOtherModuleInfo, "* Load address:%08X  Reference count:%u",
                pModInst->m_hModule, pModInst->GetNumberOfProcessReferences() );

        AddTreeviewSubItem( g_hWndTree, hTreeItem, szOtherModuleInfo );

        //
        // Try to retrieve the file description from the file's version
        // resource.  If found, add it as another subitem
        //
        char szFileDesc[1024];  
        if ( GetFileDescription(pModInst->m_pszName,
                                szFileDesc, sizeof(szFileDesc)) )
        {
            char szBuffer[ sizeof(szFileDesc) + 64 ];
            wsprintf( szBuffer, "* Description: %s", szFileDesc );
            AddTreeviewSubItem( g_hWndTree, hTreeItem, szBuffer );
        }

        // Iterate through each process that references the DLL, and add it
        // as a subitem             
        int enumHandle = 0;     // Passing 0 begins the enumeration
        DWORD pid;              // -1 means end of pid list
        
        while ( -1 != (pid = pModInst->EnumerateProcessReferences(enumHandle)))
        {
            char szProcessInfo[MAX_PATH+128];
            
            wsprintf( szProcessInfo, "%s", g_ProcessIdToNameMap.Lookup(pid) );

            AddTreeviewSubItem( g_hWndTree, hTreeItem, szProcessInfo );
        }
    }
}


void Handle_WM_INITDIALOG(HWND hDlg)
{
    // Get the window coordinates where the program was last running,
    // and move the window to that spot.
    POINT pt;
    GetSetPositionInfoFromRegistry( FALSE, &pt );

    SetWindowPos(hDlg, 0, pt.x, pt.y, 0, 0,
                 SWP_NOSIZE | SWP_NOREDRAW | SWP_NOZORDER | SWP_NOACTIVATE);

    g_hDlg = hDlg;
    g_hWndTree = GetDlgItem(hDlg, IDC_TREE1);
    
    PopulateTree( g_hWndTree );    
}

void Handle_WM_COMMAND(HWND hWndDlg, WPARAM wParam, LPARAM lParam )
{
    WORD wNotifyCode = HIWORD(wParam); // notification code 
    WORD wID = LOWORD(wParam);         // item, control, or accelerator id
    HWND hwndCtl = (HWND) lParam;      // handle of control
    
    if ( IDC_BUTTON_REFRESH == wID )
    {
        if ( BN_CLICKED == wNotifyCode )
            PopulateTree( g_hWndTree );         
    }
    else if ( IDC_BUTTON_ABOUT == wID )
    {
        if ( BN_CLICKED == wNotifyCode )
            MessageBox( hWndDlg, gszAboutText, gszMBTitle, MB_OK );
    }
}

void Handle_WM_CLOSE( HWND hDlg )
{
    // Save off the window's X,Y coordinates for next time
    RECT rect;
    if ( GetWindowRect( hDlg, &rect ) )
        GetSetPositionInfoFromRegistry( TRUE, (LPPOINT)&rect );
  
    EndDialog(hDlg, 0);
}

void Handle_WM_SIZE(HWND hWndDlg, WPARAM wParam, LPARAM lParam )
{
    RECT tvRect, dlgRect;
    POINT pt;
    
    WORD nClientWidth = LOWORD(lParam);
    WORD nClientHeight= HIWORD(lParam);
    
    GetClientRect( hWndDlg, &dlgRect );     // Get size of dialog
    GetWindowRect( g_hWndTree, &tvRect );   // Get screen position of child
    
    pt.x = tvRect.left;     // Get the X,Y coordinates for the top left
    pt.y = tvRect.top;      // and reuse them in the resized client 
    ScreenToClient( hWndDlg, &pt ); // Calculate screen X,Y of child window
        
    WORD tvWidth = nClientWidth - ( pt.x * 2);  // Equal spacing on all borders
    WORD tvHeight= nClientHeight - (WORD)(pt.y + pt.x);
    MoveWindow( g_hWndTree, pt.x, pt.y, tvWidth, tvHeight, TRUE );  
}

void GetSetPositionInfoFromRegistry( BOOL fSave, POINT *lppt )
{
    //
    // Function that saves or restores the coordinates of a dialog box
    // in the system registry.  Handles the case where there's nothing there.
    //
    HKEY hKey;
    DWORD dataSize, err, disposition;
    char szKeyName[] = "DlgCoordinates";
    
    if ( !fSave )               // In case the key's not there yet, we'll
        lppt->x = lppt->y = 0;  // return 0,0 for the coordinates

    // Open the registry key (or create it if the first time being used)
    err = RegCreateKeyEx( HKEY_CURRENT_USER, gszRegistryKey, 0, 0,
                         REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS,
                         0, &hKey, &disposition );
    if ( ERROR_SUCCESS != err )
        return;

    if ( fSave )            // Save out coordinates
    {
        RegSetValueEx(hKey,szKeyName, 0, REG_BINARY,(PBYTE)lppt,sizeof(*lppt));
    }
    else                    // read in coordinates
    {
        dataSize = sizeof(*lppt);
        RegQueryValueEx( hKey, szKeyName, 0, 0, (PBYTE)lppt, &dataSize );
    }

    RegCloseKey( hKey );
}

HTREEITEM AddTreeviewSubItem(   HWND hWndTree,
                                HTREEITEM hTreeItem,
                                LPTSTR pszItemText,
                                BOOL fItemData,
                                LPARAM itemData )
{
    TVINSERTSTRUCT tvi;
    
    tvi.hParent = hTreeItem;
    tvi.hInsertAfter = TVI_SORT;
    tvi.item.mask = TVIF_TEXT;
    tvi.item.pszText = pszItemText;
    tvi.item.cchTextMax = lstrlen( pszItemText );
    if ( fItemData )
    {
        tvi.item.mask |= TVIF_PARAM;
        tvi.item.lParam = itemData;
    }

    return TreeView_InsertItem( hWndTree, &tvi );
}

BOOL GetFileDescription( PSTR pszFileName, PSTR pszDesc, unsigned cbDesc )
{
    //
    // Give a filename, trys to extract the FileDescription version resource
    //
    BYTE verInfo[8192];
    DWORD cbVerInfo = sizeof(verInfo);
    
    if ( !GetFileVersionInfo(pszFileName, 0, cbVerInfo, verInfo) )
        return FALSE;

    PSTR pszVerRetVal;
    UINT cbReturn;
    BOOL fFound;

    // Try first with the 1252 codepage.  To do so, we need to format a
    // string with the 1252 codepage (Windows Multilingual)
    char szQueryStr[0x100];
    wsprintf( szQueryStr, "\\StringFileInfo\\%04X%04X\\FileDescription",
                GetUserDefaultLangID(), 1252 );

    fFound = VerQueryValue( verInfo, szQueryStr,
                            (LPVOID *)&pszVerRetVal, &cbReturn );
    if ( !fFound )
    {
        // Hmm... 1252 wasn't found.  Try the 1200 codepage
        wsprintf( szQueryStr, "\\StringFileInfo\\%04X%04X\\FileDescription",
                    GetUserDefaultLangID(), 1200 );
        fFound = VerQueryValue( verInfo, szQueryStr,
                                (LPVOID *)&pszVerRetVal, &cbReturn );
    }

    if ( fFound )   // If we found the string, copy it to the return buffer
    {
        lstrcpyn( pszDesc, pszVerRetVal, min(cbReturn+1, cbDesc) );
        return TRUE;
    }
        
    return FALSE;       
}
