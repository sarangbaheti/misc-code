#define IDD_MODULELIST                  1
#define IDC_TREE1                       1000
#define IDC_BUTTON_REFRESH              1001
#define IDC_BUTTON_ABOUT                1002
