// Test.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <comdef.h>
#include "windows.h"
#include "stdio.h"
#include <string>
using namespace std;

#include "perfsrvexe.h"
#include "perfsrvexe_i.c"

_COM_SMARTPTR_TYPEDEF(IPerfSrvObject,IID_IPerfSrvObject);

IPerfSrvObjectPtr		m_PerfServ;

int main(int argc, char* argv[])
{

/*****************************************************
	The following example shows how to get an active
	PO that Perfmon is displaying and change its value.
	This example is based on the test.dat file that
	has come with the example files. If you run the
	program after perfmon is monitoring the CO, you
	should see it's value jump to the value of 50,
	or whatever value you set the "myValue" variable
	to.
*****************************************************/

	CLSID clsid;
	HRESULT hr;
	hr = CoInitializeEx(0,COINIT_MULTITHREADED); 
	hr = CLSIDFromString(L"PerfSrvExe.PerfSrvObject",&clsid);

	_bstr_t	poName("MyPO");

	hr = m_PerfServ.CreateInstance(clsid,NULL);

	long pNumCounters;
	hr = m_PerfServ->Load(L"E:\\com\\atl\\pm\\test.dat",L"");
	hr = m_PerfServ->GetNumPOs(&pNumCounters);

	m_PerfServ->FindFirst(poName);
	IPerfPerformanceObject* pTemp = NULL;
	hr = m_PerfServ->GetCurrentPO(&pTemp);
	
	_bstr_t coName("YourCounterObject");

	hr = pTemp->FindFirst(coName);

	IPerfCounterObject* pCOTemp = NULL;
	hr = pTemp->GetCurrentCO(&pCOTemp);
	long myValue = 50;
	_variant_t coValue(myValue);

	pCOTemp->get_m_value(&coValue);
	coValue = myValue;
	pCOTemp->put_m_value(coValue);

	pCOTemp->Release();
	pTemp->Release();
	
	m_PerfServ = NULL;

	CoUninitialize();
  return 0;
}

