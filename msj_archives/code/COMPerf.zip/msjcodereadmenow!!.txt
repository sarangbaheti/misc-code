Hello everyone, 

I hope everything is in order, I got a call at the last minute saying the article was running, so I was 
left in a panic to get everything package up nicely for you.
As it stands, the zip file you just unzipped should have the following files:

Items:
	1) PerfSrvExe folder
	2) PerfWin32 folder
	3) POCOMain folder
	4) Testtwo folder
	5) vbregexam folder
	6) test.dat file

PerfSrvExe folder

	This folder contains all the project code for the main OOP server component that is responsible for 
maintain PO and CO information. It should be relatively bug free, but I have not had time to go through it 
with a fine toothcomb.

PerfWin32 folder

	This folder contains all the code for the PerfWin32 DLL that is loaded up by Perfmon. Currently it 
handles only one .DAT file, however I have designed PerfSrvExe to handle multiple ones, I just haven't 
gotten around to implementing it yet. This should not cause problems though, one .DAT file can handle 
everything.

POCOMain folder

	This program is the begins to a client front end that will let you define, edit and delete existing PO 
and CO information in a given .DAT file. It is currently not completed but it does allow you to design and 
save new .DAT files and view existing ones.

TestTwo Folder

	This is just a quick console app that shows you an example of how to change the value of a given 
CO that is being monitored by Perfmon, really simple.

VBRegExam folder

	This is a VB example of how to register new PO and CO information that you have designed 
through POCOMain. I am currently enhancing the whole Perfmon registry stuff so that it becomes a lot 
more efficient, but for now you'll have to register each PO separately.

Test.dat file
	
	This file is a test file that has a PO and a CO already set up for you.

Getting started:
NOTE: Remember to back up your PerfLib section before playing around!! It's located under the 
key: HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Perflib

1)	Compile items 1 and 2
2)	Place PerfWin32.dll into the winnt\system32 directory.
3)	Register the proxy-stub DLL for item 1
4)	Compile item 5 and set the .DAT path to where ever it is you have it. Also change directory 
location for where it is you want the .H and .INI files to be created.
5)	Run item 5. It should register the MyPO PO into the registry under the following key: 
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\MyPO.
There should be a Linkage key and a Performance key defined with a bunch of other entries. 
More importantly is the "First Counter","Last Counter","First Help","Last Help" keys. If 
these are there, everything worked okay. If not, oh boy.
6)	Run Perfmon, you should and look through the different PO's. You should find one that says 
MyPO. When selected it will have a CO named YourCounterObject.

Good luck and have fun!! I can be reached at kenk@lightwizardproductions.com if you have any 
questions or want to give me pointers!! I like the pointers part, I look to learn from everyone I can! 

Thanks everyone, take care.

	Ken Knudsen
