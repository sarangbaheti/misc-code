// POCOMainDlg.h : header file
//

#if !defined(AFX_POCOMAINDLG_H__9B0B63D9_D5C9_11D2_8B75_00104BF19EF5__INCLUDED_)
#define AFX_POCOMAINDLG_H__9B0B63D9_D5C9_11D2_8B75_00104BF19EF5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CPOCOMainDlg dialog

//#import "PerfSrvExe.tlb" no_namespace no_implementation
#include "perfsrvexe.h"

_COM_SMARTPTR_TYPEDEF(IPerfSrvObject,IID_IPerfSrvObject);
_COM_SMARTPTR_TYPEDEF(IPerfParentObject,IID_IPerfParentObject);
_COM_SMARTPTR_TYPEDEF(IPerfPerformanceObject,IID_IPerfPerformanceObject);
_COM_SMARTPTR_TYPEDEF(IPerfCounterObject,IID_IPerfCounterObject);

class CPOCOMainDlg : public CDialog
{

private:
	void CleanUp();
public:
	CPOCOMainDlg(CWnd* pParent = NULL);	// standard constructor

	BOOL	m_isPerfObject;

	IPerfSrvObjectPtr	m_PerfSrv;
//functions
	void LoadDataFile(const char* pFileName);

// Dialog Data
	//{{AFX_DATA(CPOCOMainDlg)
	enum { IDD = IDD_POCOMAIN_DIALOG };
	CEdit	m_nameString;
	CEdit	m_helpString;
	CTreeCtrl	m_treeView;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPOCOMainDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CPOCOMainDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnPOCOCounter();
	afx_msg void OnPOCOObject();
	afx_msg void OnClose();
	virtual void OnOK();
	afx_msg void OnAddpoco();
	afx_msg void OnDelete();
	afx_msg void OnLoadfile();
	afx_msg void OnSavefile();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_POCOMAINDLG_H__9B0B63D9_D5C9_11D2_8B75_00104BF19EF5__INCLUDED_)
