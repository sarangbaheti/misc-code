// POCOMainDlg.cpp : implementation file
//

#include "stdafx.h"
#include "POCOMain.h"
#include "POCOMainDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
//#include "perfsrvexe_i.c"
//#import "PerfSrvExe.tlb" no_namespace implementation_only 
#include "perfsrvexe_i.c"

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPOCOMainDlg dialog

CPOCOMainDlg::CPOCOMainDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPOCOMainDlg::IDD, pParent), m_PerfSrv(NULL)
{
	//{{AFX_DATA_INIT(CPOCOMainDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CPOCOMainDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPOCOMainDlg)
	DDX_Control(pDX, IDC_POCOName, m_nameString);
	DDX_Control(pDX, IDC_POCOHelp, m_helpString);
	DDX_Control(pDX, IDC_POCOView, m_treeView);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPOCOMainDlg, CDialog)
	//{{AFX_MSG_MAP(CPOCOMainDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_POCOCounter, OnPOCOCounter)
	ON_BN_CLICKED(IDC_POCOObject, OnPOCOObject)
	ON_WM_CLOSE()
	ON_BN_CLICKED(ID_ADDPOCO, OnAddpoco)
	ON_BN_CLICKED(ID_DELETE, OnDelete)
	ON_BN_CLICKED(IDC_LOADFILE, OnLoadfile)
	ON_BN_CLICKED(IDC_SAVEFILE, OnSavefile)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPOCOMainDlg message handlers

BOOL CPOCOMainDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	HRESULT hr;
	hr = CoInitializeEx(0,COINIT_MULTITHREADED); 

	CLSID clsid;
	
	hr = CLSIDFromString(L"PerfSrvExe.PerfSrvObject",&clsid);
	hr = m_PerfSrv.CreateInstance(clsid,NULL);
	
//	GetDlgItem(IDC_POCOObject,this->m_hWnd)->SetValue(1);
//	::SetValue(
	CButton rButton;
	rButton.Attach(::GetDlgItem(this->m_hWnd,IDC_POCOObject));
	rButton.SetCheck(1);
	rButton.Detach();
	return TRUE;  // return TRUE
}

void CPOCOMainDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPOCOMainDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPOCOMainDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CPOCOMainDlg::OnPOCOCounter() 
{
	m_isPerfObject = FALSE;
}

void CPOCOMainDlg::OnPOCOObject() 
{
	m_isPerfObject = TRUE;
}

void CPOCOMainDlg::OnClose() 
{
	CleanUp();
	CDialog::OnClose();
}

void CPOCOMainDlg::OnOK() 
{
	CleanUp();	
	CDialog::OnOK();
}
void CPOCOMainDlg::CleanUp()
{
	if(m_PerfSrv != NULL)
	{
		m_PerfSrv->Clear();
		m_PerfSrv = NULL;
	}

	CoUninitialize();
}

void CPOCOMainDlg::OnAddpoco() 
{
	CString name;
	CString help;
	HRESULT hr;

	m_nameString.GetWindowText(name);
	m_helpString.GetWindowText(help);

	HTREEITEM treeItem = m_treeView.GetSelectedItem();	

	HTREEITEM theParent = m_treeView.GetParentItem( treeItem );
	if(theParent == NULL)
	{
		//then this is the parent
		theParent = treeItem;
	}

	_bstr_t bName(name);
	_bstr_t bHelp(help);
	if(m_isPerfObject) //this is a Performance Object we are creating
	{

		hr = m_PerfSrv->AddPO(bName,bHelp);
		m_treeView.InsertItem((char*)bName,0,0,TVI_ROOT,TVI_LAST);

	}
	else
	{
		CString poName = m_treeView.GetItemText(theParent);
		_bstr_t bPOName(poName);
		hr = m_PerfSrv->FindFirst(bPOName);
		if(FAILED(hr))
		{
			AfxMessageBox("Not a Valid PO.");
			return;
		}
		IPerfPerformanceObject* pTemp = NULL;
		
		hr = m_PerfSrv->GetCurrentPO(&pTemp);		
		hr = pTemp->AddCounter(_variant_t(bName),_variant_t(bHelp));
		
		m_treeView.InsertItem((char*)bName,0,0,theParent,TVI_LAST);
		m_treeView.RedrawWindow();

		pTemp->Release();
	}

}

void CPOCOMainDlg::OnDelete() 
{
	AfxMessageBox("Delete is currently coded");
//	HTREEITEM treeItem = m_treeView.GetSelectedItem( );
//	m_treeView.DeleteItem(treeItem);
}

void CPOCOMainDlg::OnLoadfile() 
{
	char szFileTypes[] = "POCO DAT Files (*.dat)|*.dat||";
	CFileDialog fileDlg(TRUE,"dat","*.dat",OFN_FILEMUSTEXIST|OFN_HIDEREADONLY,szFileTypes,this);

	if(fileDlg.DoModal() == IDOK)
	{
		CString fileName;
		fileName = fileDlg.GetPathName();
		LoadDataFile((LPCTSTR)fileName);
		SetWindowText(fileName);
	}
}

void CPOCOMainDlg::OnSavefile() 
{
	if(m_PerfSrv == NULL)
	{
		return;
	}
	char szFileTypes[] = "POCO DAT Files (*.dat)|*.dat||";
	CFileDialog fileDlg(false,"dat","*.dat",OFN_FILEMUSTEXIST|OFN_HIDEREADONLY,szFileTypes,this);

	if(fileDlg.DoModal() == IDOK)
	{
		CString fileName;
		fileName = fileDlg.GetPathName();
		HRESULT hr = m_PerfSrv->Save(_bstr_t((LPCTSTR)fileName),NULL);
		SetWindowText(fileName);
	}
	
}
void CPOCOMainDlg::LoadDataFile(const char* pFileName)
{
	//Set default to Performance Object Creation	
	m_isPerfObject	= TRUE;

	//Load up PerfServExe
	HRESULT hr;
	long numPO;
	
	_bstr_t bPathName(pFileName);

	m_PerfSrv->Clear();
	m_treeView.DeleteAllItems( );
	
	hr = m_PerfSrv->GetNumPOs(&numPO);

	m_PerfSrv->Load(bPathName,NULL);
	
	hr = m_PerfSrv->GetNumPOs(&numPO);

	hr = m_PerfSrv->MoveFirst();
	for(int x=0;x<numPO;x++)
	{
		HTREEITEM parent;
		IPerfPerformanceObjectPtr	pPerfObject;
		hr = m_PerfSrv->GetCurrentPO(&pPerfObject);
		
		IPerfParentObjectPtr	pParent;
		hr = pPerfObject->GetParent(&pParent);
		BSTR poName;
		pParent->get_m_name(&poName);

		_bstr_t poTemp(poName);

		parent = m_treeView.InsertItem((char*)poTemp,0,0,TVI_ROOT,TVI_LAST);

		long numCO;

		hr = pPerfObject->get_m_numCounters(&numCO);
		pPerfObject->MoveFirst();
		for(int y=0;y<numCO;y++)
		{
			IPerfCounterObjectPtr	pPerfCounter;
			hr = pPerfObject->GetCurrentCO(&pPerfCounter);

			IPerfParentObjectPtr	pParentCO;
			hr = pPerfCounter->GetParent(&pParentCO);

			BSTR coName;
			pParentCO->get_m_name(&coName);

			_bstr_t coTemp(coName);

			m_treeView.InsertItem((char*)coTemp,0,0,parent,TVI_LAST);
			hr = pPerfObject->MoveNext();
			if(FAILED(hr)) break;
		}
		hr = m_PerfSrv->MoveNext();
		
	}
}
