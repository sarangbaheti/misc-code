========================================================================
					Outstanding Fixme's for PerfWin32
========================================================================

	1)	Get rid of PerfObject and PerfCounter globals. They are not needed. 
		Instance's are contained within the data structure.

	2)	Put better error handling through out the code.

	3) Put entry into registry that tells perfmon where to look for the PO/CO data
		file that it needs to load.