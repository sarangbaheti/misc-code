// PerfWin32.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include <comdef.h>
#include <winperf.h>
#include "PerfWin32.h"

#define SAFE_CALL(retVal) {if (FAILED(retVal)) return false;};

//Note: If I have these in the header file, CreateInstance freeze's, check 
//on problem later

IGlobalInterfaceTable*	g_pGit;
DWORD	g_PerfCookie;

IPerfSrvObjectPtr		g_PerfServ;
PERFDATASTRUCT			g_objectMap;
POLIST					g_poMap; //change to g_poList
POLIST::iterator		g_curPOMap;

CriticalSection		g_critSection;

static BOOL g_isLoaded = false;

_bstr_t g_bAppName;
long g_appCount = 0;
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		{
			int t = 0;
			HRESULT hr = S_OK;

			hr = CoInitializeEx(0,COINIT_MULTITHREADED);

			g_PerfServ.Detach();
			CLSID clsid;

			hr = CoCreateInstance(CLSID_StdGlobalInterfaceTable,0,CLSCTX_INPROC_SERVER,
									IID_IGlobalInterfaceTable,(void**)&g_pGit);

			hr = CLSIDFromString(L"PerfSrvExe.PerfSrvObject",&clsid);
			
			hr = g_PerfServ.CreateInstance(clsid,NULL);

			hr = g_pGit->RegisterInterfaceInGlobal(g_PerfServ,IID_IPerfSrvObject,&g_PerfCookie);

			if(FAILED(hr)) 
			{
				CoUninitialize();
				return false;
			}			
			break;
		}
		case DLL_THREAD_ATTACH:
		{
			HRESULT hr = CoInitializeEx(0,COINIT_MULTITHREADED);

			if(FAILED(hr)) 
			{
				CoUninitialize();
				return false;
			}			

			break;
		}
		case DLL_THREAD_DETACH:
		{
			CoUninitialize();
			break;
		}
		case DLL_PROCESS_DETACH:
		{
			g_pGit->RevokeInterfaceFromGlobal(g_PerfCookie);
			g_pGit->Release();
			g_PerfServ = NULL;
			CoUninitialize();
			break;
		}
    }
    return TRUE;
}

CPerfWin32::CPerfWin32()
{ 
	int t = 0;
}
CPerfWin32::~CPerfWin32()
{ 
	int t = 0;
}
DWORD CPerfWin32::OpenPerfData(LPWSTR lpDeviceNames)
{
	HRESULT hr = S_OK;

	if(Init(lpDeviceNames) == false)
	{
		return E_FAIL;
	}

	return S_OK;
}
DWORD CPerfWin32::GetPerfData(LPWSTR lpValueName,
						LPVOID *lppData,
						LPDWORD lpcbTotalBytes,
						LPDWORD lpNumObjectTypes,PONUMLIST& sizeArray)
{
	PERFDATASTRUCT::iterator	iter;
	int loopCounter = 0;

	long numItems = sizeArray.size();

	PPERF_DATA_STRUCT tempDS = new PERF_DATA_STRUCT[numItems];
	long poIndexNum = 0;
	POLIST::iterator	iterPOList;

	long sizeNeeded = 0;
	
	PONUMLIST::iterator tempList = sizeArray.begin(); 

	for(int y=0;y<numItems;y++)
	{
		poIndexNum = (*tempList);
		iterPOList = g_poMap.find(poIndexNum);

		if(iterPOList == g_poMap.end())
		{
			return 0;
		}

		g_bAppName = (*iterPOList).second;
	
		iter = g_objectMap.find(g_bAppName);

		if(iter == g_objectMap.end())
		{
			return 0;
		}

		tempDS[y] = *(*iter).second;

		sizeNeeded += tempDS[y].objectType.TotalByteLength;

		tempList++;
	}

	if(*lpcbTotalBytes < sizeNeeded)
	{
		*lpcbTotalBytes = (DWORD)0;
		*lpNumObjectTypes = (DWORD)0;
		return ERROR_MORE_DATA;
	}
	long numCounters = 0;
	for(loopCounter = 0;loopCounter<numItems;loopCounter++)
	{
		PERF_OBJECT_TYPE	*pObjectType = (PERF_OBJECT_TYPE*)*lppData;

		memmove(pObjectType,&tempDS[loopCounter].objectType,sizeof(PERF_OBJECT_TYPE));

		PERF_COUNTER_DEFINITION *pCounterDef = (PERF_COUNTER_DEFINITION*)(&pObjectType[1]);

		numCounters = tempDS[loopCounter].objectType.NumCounters;
		memmove(pCounterDef,tempDS[loopCounter].cntDefBlock,(sizeof(PERF_OBJECT_TYPE)*numCounters));

		PERF_COUNTER_BLOCK *pPerfCounterBlock = (PERF_COUNTER_BLOCK*)(&pCounterDef[numCounters]);

		memmove(pPerfCounterBlock,&tempDS[loopCounter].counterBlock,sizeof(PERF_COUNTER_BLOCK));

		LPDWORD	pCounterData = (LPDWORD)(&pPerfCounterBlock[1]);
		
		IPerfPerformanceObjectPtr	tempPO;
		IPerfCounterObject* pCOTemp = NULL;
		IPerfParentObject*	pCOParent = NULL;

		HRESULT hr = S_OK;
	
		hr = g_pGit->GetInterfaceFromGlobal(tempDS[loopCounter].dwPOCookie,
									IID_IPerfPerformanceObject,(void**)&tempDS[loopCounter].pPO);

		tempPO = tempDS[loopCounter].pPO;
		
		tempPO->MoveFirst();

		_variant_t coValue;
		for(int x = 0; x<numCounters;x++)
		{
			hr = tempPO->GetCurrentCO(&pCOTemp);

			hr = pCOTemp->get_m_value(&coValue);
			//Make call to Counter Collect Method
			*pCounterData = V_I4(&coValue.Detach());
			pCounterData++;

			pCOTemp->Release();

			if((x+1) != numCounters)
			{
				//Need to see why it throw exception.
				//It has to do with the map internal to PerfExe
				//If you move past the last item in the map, it 
				//throws an exception
				try
				{
					tempPO->MoveNext();
				}
				catch(...)
				{
				}
			}

		}

		*lppData = (PVOID)pCounterData;

		//Release temp PO holder
		tempPO = NULL;
	}
	*lpNumObjectTypes = numItems;
	*lpcbTotalBytes = sizeNeeded;

	delete[] tempDS;

	return ERROR_SUCCESS;

}
DWORD CPerfWin32::CollectPerfData(	LPWSTR lpValueName,
						LPVOID *lppData,
						LPDWORD lpcbTotalBytes,
						LPDWORD lpNumObjectTypes)
{
	g_critSection.Enter();

	_bstr_t myValue(lpValueName);

	long poIndexNum = 0;
	PONUMLIST	lsPoNum;

	int arrayCounter = 0;

	if(stricmp(myValue,"Global") == 0)
	{
		if(g_appCount == g_poMap.size())
		{
			g_appCount = 0;
		}
		if(g_appCount == 0)
		{
			g_curPOMap = g_poMap.begin();
		}
		poIndexNum = (*g_curPOMap).first;
		lsPoNum.push_back(poIndexNum);

		g_bAppName = (*g_curPOMap).second;
		g_curPOMap++;

		//increment global counter
		g_appCount++;
		
		GetPerfData(lpValueName,lppData,lpcbTotalBytes,lpNumObjectTypes,lsPoNum);

		g_critSection.Leave();

		return ERROR_SUCCESS;
	}
	else
	{
		_bstr_t spaceBstr(" ");
		LPWSTR space = spaceBstr;

		long strLength	= 0;
		size_t isAnother = 0;

		strLength = wcslen(lpValueName);
		wchar_t newValueName[255];
		//make more dynamic later on
		for(int x = 0; x<strLength;)
		{
			if(x > 3)
				int t = 0;
			lpValueName += isAnother;
			wcsncpy(newValueName,lpValueName,strLength);

			POLIST::iterator iterPOList;
			long poIndexNum = atol(_bstr_t(newValueName));
			iterPOList = g_poMap.find(poIndexNum);

			if(iterPOList != g_poMap.end())
			{
				lsPoNum.push_back(atol(_bstr_t(newValueName)));
			}

			isAnother = wcscspn( newValueName, space );
			if(isAnother == 0)
			{
				isAnother = strLength;
			}
			isAnother++;
			x += isAnother;

			arrayCounter++;
		}

	}

	GetPerfData(g_bAppName ,lppData,lpcbTotalBytes,lpNumObjectTypes,lsPoNum);

	g_critSection.Leave();

	return ERROR_SUCCESS;
}
DWORD CPerfWin32::ClosePerfData()
{
	PERFDATASTRUCT::iterator	iter;

	for(iter = g_objectMap.begin(); iter!= g_objectMap.end();iter++)
	{
		PPERF_DATA_STRUCT tempDS = (*iter).second;

		g_pGit->GetInterfaceFromGlobal(tempDS->dwPOCookie,IID_IPerfPerformanceObject,
										(void**)&tempDS->pPO);
		g_pGit->RevokeInterfaceFromGlobal(tempDS->dwPOCookie);
		tempDS->pPO = NULL;
	}

	return 0;
}
bool CPerfWin32::Init(LPWSTR pAppName)
{
	bool retVal = true;
	HRESULT hr = S_OK;
	g_bAppName = pAppName;

	hr = g_pGit->GetInterfaceFromGlobal(g_PerfCookie,IID_IPerfSrvObject,(void**)&g_PerfServ);

	USES_CONVERSION;
	if(!g_bAppName || strlen(OLE2A(pAppName)) < 1)
	{
		return false;
	}
	//Load up the data file
	//NOTE: The current implemenation of PerWin32 is only supporting 
	//one .DAT file. This means that all registered PO's in the 
	//registry must point to the same .DAT file in order to 
	//show up in the PM PO listing. I do have the PerfSrvExe implemented
	//as such to handle multiple .DAT files, however the coding is currently
	//centered around one .DAT file. Feel free to add in the support
	//for multiple ones. Please e-mail at kenk@lightwizardproductions.com
	//if you get things workings! Thanks.
	if(!g_isLoaded)
	{
		CRegKey	regKey;

		long regVal = 0;
		
		string regKeyName = "SYSTEM\\CurrentControlSet\\Services\\"+ g_bAppName+"\\performance";

		regVal = regKey.Open(HKEY_LOCAL_MACHINE,regKeyName.c_str());

		if(regVal != ERROR_SUCCESS)
		{
			return false;
		}
		DWORD dwCount;
		char filePath[MAX_PATH];
		regVal = regKey.QueryValue(filePath,"DataFile",&dwCount);

		if(regVal != ERROR_SUCCESS)
		{
			//write string to event log "DataFile" key missing for <name of PO>
			return FALSE;
		}

		_bstr_t bPath(filePath);
		_bstr_t bName("");
		hr = g_PerfServ->Load(bPath,bName);
		if(FAILED(hr))
		{
			ReportCOMError();
			return FALSE;
		}
		g_isLoaded = TRUE;
	}
	//Find the PO name in the list
	_bstr_t pocoName(pAppName);
	hr = g_PerfServ->FindFirst(pocoName);

	if(FAILED(hr))
	{
		ReportCOMError();
		return FALSE;
	}
	//error handle here

	IPerfPerformanceObjectPtr	pPerfObject;
	//Get the PO and fill the struct with info
	hr = g_PerfServ->GetCurrentPO(&pPerfObject);

	//GetNumCounters
	long numCounters;
	pPerfObject->get_m_numCounters(&numCounters);

	IPerfParentObjectPtr		pParentObj;
	hr = pPerfObject->GetParent(&pParentObj);

	BSTR bPocoName;
	BSTR bHelpString;

	hr = pParentObj->get_m_name(&bPocoName);

	long indexValue;
	pParentObj->get_m_indexValue(&indexValue);

	pParentObj->get_m_helpString(&bHelpString);

	long structLength = sizeof(PERF_OBJECT_TYPE)+(numCounters*sizeof(PERF_COUNTER_DEFINITION));

	PPERF_DATA_STRUCT tempDS= new PERF_DATA_STRUCT(structLength);

	_bstr_t boo(bPocoName);

	DWORD dwFirstCO;
	DWORD dwFirstHelp;

	CRegKey regKey;

	_bstr_t appKey("SYSTEM\\CurrentControlSet\\Services\\"+_bstr_t(pAppName)+"\\Performance");
	regKey.Open(HKEY_LOCAL_MACHINE,appKey);
	regKey.QueryValue(dwFirstCO,"First Counter");
	regKey.QueryValue(dwFirstHelp,"First Help");
	regKey.Close();

	tempDS->objectType.ObjectNameTitleIndex		= indexValue + dwFirstCO;
	tempDS->objectType.ObjectNameTitle			= NULL;
	tempDS->objectType.ObjectHelpTitleIndex		= indexValue + dwFirstHelp;
	tempDS->objectType.ObjectHelpTitle			= NULL;
	tempDS->objectType.NumCounters				= numCounters;

	//put items into list of PO's this DLL is handling
	g_poMap[tempDS->objectType.ObjectNameTitleIndex] = g_bAppName;

	tempDS->cntDefBlock = new PERF_COUNTER_DEFINITION[numCounters];

	hr = pPerfObject->MoveFirst();

	IPerfCounterObject* pCOTemp = NULL;
	IPerfParentObject*	pCOParent = NULL;
	long coIndex = 0;
	short dataType =0;

	long sizeofData = sizeof(PERF_COUNTER_BLOCK);

	for(int x=0;x<numCounters;x++)
	{
		hr = pPerfObject->GetCurrentCO(&pCOTemp);
		hr = pCOTemp->GetParent(&pCOParent);
			
		hr = pCOParent->get_m_indexValue(&coIndex);

		hr = pCOParent->get_m_name(&bPocoName);
		hr = pCOParent->get_m_helpString(&bHelpString);
		
		hr = pCOTemp->get_m_dataType(&dataType);

		tempDS->cntDefBlock[x].ByteLength = sizeof(PERF_COUNTER_DEFINITION);
		tempDS->cntDefBlock[x].CounterNameTitleIndex	= coIndex + dwFirstCO;
		tempDS->cntDefBlock[x].CounterNameTitle			= NULL;
		tempDS->cntDefBlock[x].CounterHelpTitleIndex	= coIndex + dwFirstHelp;
		tempDS->cntDefBlock[x].CounterHelpTitle			= NULL;
		tempDS->cntDefBlock[x].DefaultScale				= 0;
		tempDS->cntDefBlock[x].DetailLevel				= PERF_DETAIL_NOVICE;
		tempDS->cntDefBlock[x].CounterType				= PERF_COUNTER_RAWCOUNT;
		tempDS->cntDefBlock[x].CounterSize				= sizeof(DWORD);
		tempDS->cntDefBlock[x].CounterOffset			= sizeofData;

		tempDS->pPO = pPerfObject;
		//Register the reference so that any thread can now use it safely
		hr = g_pGit->RegisterInterfaceInGlobal(tempDS->pPO,IID_IPerfPerformanceObject,&tempDS->dwPOCookie);

		pCOParent->Release();
		pCOTemp->Release();
		
		sizeofData += sizeof(DWORD);

		hr = pPerfObject->MoveNext();
	}

	structLength += sizeofData;

	tempDS->counterBlock.ByteLength = sizeofData;
	tempDS->objectType.TotalByteLength = structLength;

	_bstr_t mapName(pAppName);
	g_objectMap[mapName] = tempDS;

	pPerfObject = NULL;
	pParentObj	= NULL;
	return retVal;
}
void CPerfWin32::ReportCOMError()
{
	HRESULT hr = S_OK;
	IErrorInfo* pInfo = NULL;
	char errDes[1024];

	USES_CONVERSION;

	hr = GetErrorInfo(0,&pInfo);
	if(hr == S_OK)
	{
		BSTR bSource = 0;
		BSTR bDesc = 0;

		pInfo->GetSource(&bSource);
		pInfo->GetDescription(&bDesc);

		wsprintf(errDes,"%s: %s\r\n",OLE2A(bSource),OLE2A(bDesc));
		OutputDebugString(errDes);

		SysFreeString(bSource);
		SysFreeString(bDesc);

		pInfo->Release();
	}
}


