
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the PERFWIN32_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// PERFWIN32_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#ifdef PERFWIN32_EXPORTS
#define PERFWIN32_API __declspec(dllexport)
#else
#define PERFWIN32_API __declspec(dllimport)
#endif

#pragma warning(disable:4786)
#pragma warning(disable:4251)

#include <map>
#include <list>
#include <string>
using namespace std;

#include "perfsrvexe.h"
#include "perfsrvexe_i.c"

_COM_SMARTPTR_TYPEDEF(IPerfSrvObject,IID_IPerfSrvObject);
_COM_SMARTPTR_TYPEDEF(IPerfParentObject,IID_IPerfParentObject);
_COM_SMARTPTR_TYPEDEF(IPerfPerformanceObject,IID_IPerfPerformanceObject);
_COM_SMARTPTR_TYPEDEF(IPerfCounterObject,IID_IPerfCounterObject);


typedef struct _PERF_DATA_STRUCT
{
	_PERF_DATA_STRUCT(){};

	_PERF_DATA_STRUCT(long sLength)
	{
		objectType.TotalByteLength	= sLength;
		objectType.DefinitionLength	= sLength;

		objectType.DefaultCounter	= 0;
		objectType.NumInstances		= 0;
		objectType.CodePage			= 0;
		objectType.PerfTime.LowPart	= 0;
		objectType.PerfTime.HighPart= 0;
		objectType.PerfFreq.LowPart	= 0;
		objectType.PerfFreq.HighPart= 0;
		objectType.DetailLevel		= PERF_DETAIL_NOVICE;
		objectType.HeaderLength		= sizeof(PERF_OBJECT_TYPE);

	};
	PERF_OBJECT_TYPE			objectType;
	PERF_COUNTER_DEFINITION*	cntDefBlock;
	PERF_COUNTER_BLOCK			counterBlock;
	long						m_sizeNeeded;
	IPerfPerformanceObjectPtr	pPO;
	DWORD						dwPOCookie;

}PERF_DATA_STRUCT, *PPERF_DATA_STRUCT;

typedef map<_bstr_t,PPERF_DATA_STRUCT> PERFDATASTRUCT;
typedef map<long, _bstr_t> POLIST;
typedef list<long> PONUMLIST;
// This class is exported from the PerfWin32.dll
class PERFWIN32_API CPerfWin32 {
public:
	CPerfWin32(void);
	~CPerfWin32(void);
	
	DWORD OpenPerfData(LPWSTR lpDeviceNames);
	DWORD CollectPerfData(	LPWSTR lpValueName,
							LPVOID *lppData,
							LPDWORD lpcbTotalBytes,
							LPDWORD lpNumObjectTypes);

	DWORD GetPerfData(	LPWSTR lpValueName,
							LPVOID *lppData,
							LPDWORD lpcbTotalBytes,
							LPDWORD lpNumObjectTypes,
							PONUMLIST&);
	
	DWORD ClosePerfData();
	
private:
	bool Init(LPWSTR pAppName);
	void ReportCOMError();
};
class CriticalSection
{
private:
	CRITICAL_SECTION	m_critSect;

public:
	CriticalSection()
	{
		InitializeCriticalSection(&m_critSect);
	}
	~CriticalSection()
	{
		DeleteCriticalSection(&m_critSect);
	}
	void Enter()
	{
		EnterCriticalSection(&m_critSect);
	}
	void Leave()
	{
		LeaveCriticalSection(&m_critSect);
	}
};