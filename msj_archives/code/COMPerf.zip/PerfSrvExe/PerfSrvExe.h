/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Jan 03 17:41:01 2000
 */
/* Compiler settings for I:\contracts\msj\february\PerfSrvExe\PerfSrvExe.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __PerfSrvExe_h__
#define __PerfSrvExe_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IPerfSrvObject_FWD_DEFINED__
#define __IPerfSrvObject_FWD_DEFINED__
typedef interface IPerfSrvObject IPerfSrvObject;
#endif 	/* __IPerfSrvObject_FWD_DEFINED__ */


#ifndef __IPerfParentObject_FWD_DEFINED__
#define __IPerfParentObject_FWD_DEFINED__
typedef interface IPerfParentObject IPerfParentObject;
#endif 	/* __IPerfParentObject_FWD_DEFINED__ */


#ifndef __IPerfPerformanceObject_FWD_DEFINED__
#define __IPerfPerformanceObject_FWD_DEFINED__
typedef interface IPerfPerformanceObject IPerfPerformanceObject;
#endif 	/* __IPerfPerformanceObject_FWD_DEFINED__ */


#ifndef __IPerfCounterObject_FWD_DEFINED__
#define __IPerfCounterObject_FWD_DEFINED__
typedef interface IPerfCounterObject IPerfCounterObject;
#endif 	/* __IPerfCounterObject_FWD_DEFINED__ */


#ifndef __IRegObject_FWD_DEFINED__
#define __IRegObject_FWD_DEFINED__
typedef interface IRegObject IRegObject;
#endif 	/* __IRegObject_FWD_DEFINED__ */


#ifndef __PerfSrvObject_FWD_DEFINED__
#define __PerfSrvObject_FWD_DEFINED__

#ifdef __cplusplus
typedef class PerfSrvObject PerfSrvObject;
#else
typedef struct PerfSrvObject PerfSrvObject;
#endif /* __cplusplus */

#endif 	/* __PerfSrvObject_FWD_DEFINED__ */


#ifndef __RegObject_FWD_DEFINED__
#define __RegObject_FWD_DEFINED__

#ifdef __cplusplus
typedef class RegObject RegObject;
#else
typedef struct RegObject RegObject;
#endif /* __cplusplus */

#endif 	/* __RegObject_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

/* interface __MIDL_itf_PerfSrvExe_0000 */
/* [local] */ 






extern RPC_IF_HANDLE __MIDL_itf_PerfSrvExe_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_PerfSrvExe_0000_v0_0_s_ifspec;

#ifndef __IPerfSrvObject_INTERFACE_DEFINED__
#define __IPerfSrvObject_INTERFACE_DEFINED__

/* interface IPerfSrvObject */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPerfSrvObject;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("34CC2AF5-CF4B-11D2-8B5B-00104BF19EF5")
    IPerfSrvObject : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetNumCounters( 
            /* [retval][out] */ long __RPC_FAR *pNumCounters) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddPO( 
            /* [in] */ BSTR name,
            /* [in] */ BSTR helpString) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE MoveFirst( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE MoveLast( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE MoveNext( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE MovePrevious( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetNumPOs( 
            /* [retval][out] */ long __RPC_FAR *pNumCounters) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetCurrentPO( 
            /* [retval][out] */ IPerfPerformanceObject __RPC_FAR *__RPC_FAR *pPO) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Save( 
            /* [in] */ BSTR path,
            /* [in] */ BSTR name) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Load( 
            /* [in] */ BSTR path,
            /* [in] */ BSTR name) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE FindFirst( 
            /* [in] */ BSTR poName) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Clear( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPerfSrvObjectVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IPerfSrvObject __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IPerfSrvObject __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IPerfSrvObject __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IPerfSrvObject __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IPerfSrvObject __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IPerfSrvObject __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IPerfSrvObject __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetNumCounters )( 
            IPerfSrvObject __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pNumCounters);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddPO )( 
            IPerfSrvObject __RPC_FAR * This,
            /* [in] */ BSTR name,
            /* [in] */ BSTR helpString);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *MoveFirst )( 
            IPerfSrvObject __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *MoveLast )( 
            IPerfSrvObject __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *MoveNext )( 
            IPerfSrvObject __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *MovePrevious )( 
            IPerfSrvObject __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetNumPOs )( 
            IPerfSrvObject __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pNumCounters);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetCurrentPO )( 
            IPerfSrvObject __RPC_FAR * This,
            /* [retval][out] */ IPerfPerformanceObject __RPC_FAR *__RPC_FAR *pPO);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Save )( 
            IPerfSrvObject __RPC_FAR * This,
            /* [in] */ BSTR path,
            /* [in] */ BSTR name);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Load )( 
            IPerfSrvObject __RPC_FAR * This,
            /* [in] */ BSTR path,
            /* [in] */ BSTR name);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindFirst )( 
            IPerfSrvObject __RPC_FAR * This,
            /* [in] */ BSTR poName);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Clear )( 
            IPerfSrvObject __RPC_FAR * This);
        
        END_INTERFACE
    } IPerfSrvObjectVtbl;

    interface IPerfSrvObject
    {
        CONST_VTBL struct IPerfSrvObjectVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPerfSrvObject_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPerfSrvObject_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPerfSrvObject_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPerfSrvObject_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPerfSrvObject_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPerfSrvObject_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPerfSrvObject_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPerfSrvObject_GetNumCounters(This,pNumCounters)	\
    (This)->lpVtbl -> GetNumCounters(This,pNumCounters)

#define IPerfSrvObject_AddPO(This,name,helpString)	\
    (This)->lpVtbl -> AddPO(This,name,helpString)

#define IPerfSrvObject_MoveFirst(This)	\
    (This)->lpVtbl -> MoveFirst(This)

#define IPerfSrvObject_MoveLast(This)	\
    (This)->lpVtbl -> MoveLast(This)

#define IPerfSrvObject_MoveNext(This)	\
    (This)->lpVtbl -> MoveNext(This)

#define IPerfSrvObject_MovePrevious(This)	\
    (This)->lpVtbl -> MovePrevious(This)

#define IPerfSrvObject_GetNumPOs(This,pNumCounters)	\
    (This)->lpVtbl -> GetNumPOs(This,pNumCounters)

#define IPerfSrvObject_GetCurrentPO(This,pPO)	\
    (This)->lpVtbl -> GetCurrentPO(This,pPO)

#define IPerfSrvObject_Save(This,path,name)	\
    (This)->lpVtbl -> Save(This,path,name)

#define IPerfSrvObject_Load(This,path,name)	\
    (This)->lpVtbl -> Load(This,path,name)

#define IPerfSrvObject_FindFirst(This,poName)	\
    (This)->lpVtbl -> FindFirst(This,poName)

#define IPerfSrvObject_Clear(This)	\
    (This)->lpVtbl -> Clear(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfSrvObject_GetNumCounters_Proxy( 
    IPerfSrvObject __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pNumCounters);


void __RPC_STUB IPerfSrvObject_GetNumCounters_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfSrvObject_AddPO_Proxy( 
    IPerfSrvObject __RPC_FAR * This,
    /* [in] */ BSTR name,
    /* [in] */ BSTR helpString);


void __RPC_STUB IPerfSrvObject_AddPO_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfSrvObject_MoveFirst_Proxy( 
    IPerfSrvObject __RPC_FAR * This);


void __RPC_STUB IPerfSrvObject_MoveFirst_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfSrvObject_MoveLast_Proxy( 
    IPerfSrvObject __RPC_FAR * This);


void __RPC_STUB IPerfSrvObject_MoveLast_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfSrvObject_MoveNext_Proxy( 
    IPerfSrvObject __RPC_FAR * This);


void __RPC_STUB IPerfSrvObject_MoveNext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfSrvObject_MovePrevious_Proxy( 
    IPerfSrvObject __RPC_FAR * This);


void __RPC_STUB IPerfSrvObject_MovePrevious_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfSrvObject_GetNumPOs_Proxy( 
    IPerfSrvObject __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pNumCounters);


void __RPC_STUB IPerfSrvObject_GetNumPOs_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfSrvObject_GetCurrentPO_Proxy( 
    IPerfSrvObject __RPC_FAR * This,
    /* [retval][out] */ IPerfPerformanceObject __RPC_FAR *__RPC_FAR *pPO);


void __RPC_STUB IPerfSrvObject_GetCurrentPO_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfSrvObject_Save_Proxy( 
    IPerfSrvObject __RPC_FAR * This,
    /* [in] */ BSTR path,
    /* [in] */ BSTR name);


void __RPC_STUB IPerfSrvObject_Save_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfSrvObject_Load_Proxy( 
    IPerfSrvObject __RPC_FAR * This,
    /* [in] */ BSTR path,
    /* [in] */ BSTR name);


void __RPC_STUB IPerfSrvObject_Load_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfSrvObject_FindFirst_Proxy( 
    IPerfSrvObject __RPC_FAR * This,
    /* [in] */ BSTR poName);


void __RPC_STUB IPerfSrvObject_FindFirst_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfSrvObject_Clear_Proxy( 
    IPerfSrvObject __RPC_FAR * This);


void __RPC_STUB IPerfSrvObject_Clear_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPerfSrvObject_INTERFACE_DEFINED__ */


#ifndef __IPerfParentObject_INTERFACE_DEFINED__
#define __IPerfParentObject_INTERFACE_DEFINED__

/* interface IPerfParentObject */
/* [unique][helpstring][uuid][dual][object] */ 


EXTERN_C const IID IID_IPerfParentObject;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("12514c50-cf5d-11d2-8b5b-00104bf19ef5")
    IPerfParentObject : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_m_name( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_m_name( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_m_helpString( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_m_helpString( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_m_indexValue( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_m_indexValue( 
            /* [in] */ long newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPerfParentObjectVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IPerfParentObject __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IPerfParentObject __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IPerfParentObject __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IPerfParentObject __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IPerfParentObject __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IPerfParentObject __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IPerfParentObject __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_m_name )( 
            IPerfParentObject __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_m_name )( 
            IPerfParentObject __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_m_helpString )( 
            IPerfParentObject __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_m_helpString )( 
            IPerfParentObject __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_m_indexValue )( 
            IPerfParentObject __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_m_indexValue )( 
            IPerfParentObject __RPC_FAR * This,
            /* [in] */ long newVal);
        
        END_INTERFACE
    } IPerfParentObjectVtbl;

    interface IPerfParentObject
    {
        CONST_VTBL struct IPerfParentObjectVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPerfParentObject_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPerfParentObject_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPerfParentObject_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPerfParentObject_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPerfParentObject_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPerfParentObject_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPerfParentObject_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPerfParentObject_get_m_name(This,pVal)	\
    (This)->lpVtbl -> get_m_name(This,pVal)

#define IPerfParentObject_put_m_name(This,newVal)	\
    (This)->lpVtbl -> put_m_name(This,newVal)

#define IPerfParentObject_get_m_helpString(This,pVal)	\
    (This)->lpVtbl -> get_m_helpString(This,pVal)

#define IPerfParentObject_put_m_helpString(This,newVal)	\
    (This)->lpVtbl -> put_m_helpString(This,newVal)

#define IPerfParentObject_get_m_indexValue(This,pVal)	\
    (This)->lpVtbl -> get_m_indexValue(This,pVal)

#define IPerfParentObject_put_m_indexValue(This,newVal)	\
    (This)->lpVtbl -> put_m_indexValue(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPerfParentObject_get_m_name_Proxy( 
    IPerfParentObject __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IPerfParentObject_get_m_name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IPerfParentObject_put_m_name_Proxy( 
    IPerfParentObject __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IPerfParentObject_put_m_name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPerfParentObject_get_m_helpString_Proxy( 
    IPerfParentObject __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IPerfParentObject_get_m_helpString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IPerfParentObject_put_m_helpString_Proxy( 
    IPerfParentObject __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IPerfParentObject_put_m_helpString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPerfParentObject_get_m_indexValue_Proxy( 
    IPerfParentObject __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IPerfParentObject_get_m_indexValue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IPerfParentObject_put_m_indexValue_Proxy( 
    IPerfParentObject __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IPerfParentObject_put_m_indexValue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPerfParentObject_INTERFACE_DEFINED__ */


#ifndef __IPerfPerformanceObject_INTERFACE_DEFINED__
#define __IPerfPerformanceObject_INTERFACE_DEFINED__

/* interface IPerfPerformanceObject */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IPerfPerformanceObject;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("36d61170-cf5d-11d2-8b5b-00104bf19ef5")
    IPerfPerformanceObject : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddCounter( 
            /* [in] */ VARIANT coName,
            /* [in] */ VARIANT coHelpString) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_m_numCounters( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE MoveFirst( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE MoveLast( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE MoveNext( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE MovePrevious( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetCurrentCO( 
            /* [retval][out] */ IPerfCounterObject __RPC_FAR *__RPC_FAR *pCO) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Write( 
            /* [in] */ LPUNKNOWN pStream) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Read( 
            /* [in] */ LPUNKNOWN pStream) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE FindFirst( 
            /* [in] */ BSTR coName) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetInfo( 
            /* [in] */ BSTR poName,
            /* [in] */ BSTR poHelp,
            /* [in] */ long poIndex) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetParent( 
            /* [retval][out] */ IPerfParentObject __RPC_FAR *__RPC_FAR *pParent) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPerfPerformanceObjectVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IPerfPerformanceObject __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IPerfPerformanceObject __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IPerfPerformanceObject __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IPerfPerformanceObject __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IPerfPerformanceObject __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IPerfPerformanceObject __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IPerfPerformanceObject __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddCounter )( 
            IPerfPerformanceObject __RPC_FAR * This,
            /* [in] */ VARIANT coName,
            /* [in] */ VARIANT coHelpString);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_m_numCounters )( 
            IPerfPerformanceObject __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *MoveFirst )( 
            IPerfPerformanceObject __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *MoveLast )( 
            IPerfPerformanceObject __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *MoveNext )( 
            IPerfPerformanceObject __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *MovePrevious )( 
            IPerfPerformanceObject __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetCurrentCO )( 
            IPerfPerformanceObject __RPC_FAR * This,
            /* [retval][out] */ IPerfCounterObject __RPC_FAR *__RPC_FAR *pCO);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Write )( 
            IPerfPerformanceObject __RPC_FAR * This,
            /* [in] */ LPUNKNOWN pStream);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Read )( 
            IPerfPerformanceObject __RPC_FAR * This,
            /* [in] */ LPUNKNOWN pStream);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindFirst )( 
            IPerfPerformanceObject __RPC_FAR * This,
            /* [in] */ BSTR coName);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetInfo )( 
            IPerfPerformanceObject __RPC_FAR * This,
            /* [in] */ BSTR poName,
            /* [in] */ BSTR poHelp,
            /* [in] */ long poIndex);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetParent )( 
            IPerfPerformanceObject __RPC_FAR * This,
            /* [retval][out] */ IPerfParentObject __RPC_FAR *__RPC_FAR *pParent);
        
        END_INTERFACE
    } IPerfPerformanceObjectVtbl;

    interface IPerfPerformanceObject
    {
        CONST_VTBL struct IPerfPerformanceObjectVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPerfPerformanceObject_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPerfPerformanceObject_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPerfPerformanceObject_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPerfPerformanceObject_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPerfPerformanceObject_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPerfPerformanceObject_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPerfPerformanceObject_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPerfPerformanceObject_AddCounter(This,coName,coHelpString)	\
    (This)->lpVtbl -> AddCounter(This,coName,coHelpString)

#define IPerfPerformanceObject_get_m_numCounters(This,pVal)	\
    (This)->lpVtbl -> get_m_numCounters(This,pVal)

#define IPerfPerformanceObject_MoveFirst(This)	\
    (This)->lpVtbl -> MoveFirst(This)

#define IPerfPerformanceObject_MoveLast(This)	\
    (This)->lpVtbl -> MoveLast(This)

#define IPerfPerformanceObject_MoveNext(This)	\
    (This)->lpVtbl -> MoveNext(This)

#define IPerfPerformanceObject_MovePrevious(This)	\
    (This)->lpVtbl -> MovePrevious(This)

#define IPerfPerformanceObject_GetCurrentCO(This,pCO)	\
    (This)->lpVtbl -> GetCurrentCO(This,pCO)

#define IPerfPerformanceObject_Write(This,pStream)	\
    (This)->lpVtbl -> Write(This,pStream)

#define IPerfPerformanceObject_Read(This,pStream)	\
    (This)->lpVtbl -> Read(This,pStream)

#define IPerfPerformanceObject_FindFirst(This,coName)	\
    (This)->lpVtbl -> FindFirst(This,coName)

#define IPerfPerformanceObject_SetInfo(This,poName,poHelp,poIndex)	\
    (This)->lpVtbl -> SetInfo(This,poName,poHelp,poIndex)

#define IPerfPerformanceObject_GetParent(This,pParent)	\
    (This)->lpVtbl -> GetParent(This,pParent)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfPerformanceObject_AddCounter_Proxy( 
    IPerfPerformanceObject __RPC_FAR * This,
    /* [in] */ VARIANT coName,
    /* [in] */ VARIANT coHelpString);


void __RPC_STUB IPerfPerformanceObject_AddCounter_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPerfPerformanceObject_get_m_numCounters_Proxy( 
    IPerfPerformanceObject __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IPerfPerformanceObject_get_m_numCounters_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfPerformanceObject_MoveFirst_Proxy( 
    IPerfPerformanceObject __RPC_FAR * This);


void __RPC_STUB IPerfPerformanceObject_MoveFirst_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfPerformanceObject_MoveLast_Proxy( 
    IPerfPerformanceObject __RPC_FAR * This);


void __RPC_STUB IPerfPerformanceObject_MoveLast_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfPerformanceObject_MoveNext_Proxy( 
    IPerfPerformanceObject __RPC_FAR * This);


void __RPC_STUB IPerfPerformanceObject_MoveNext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfPerformanceObject_MovePrevious_Proxy( 
    IPerfPerformanceObject __RPC_FAR * This);


void __RPC_STUB IPerfPerformanceObject_MovePrevious_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfPerformanceObject_GetCurrentCO_Proxy( 
    IPerfPerformanceObject __RPC_FAR * This,
    /* [retval][out] */ IPerfCounterObject __RPC_FAR *__RPC_FAR *pCO);


void __RPC_STUB IPerfPerformanceObject_GetCurrentCO_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfPerformanceObject_Write_Proxy( 
    IPerfPerformanceObject __RPC_FAR * This,
    /* [in] */ LPUNKNOWN pStream);


void __RPC_STUB IPerfPerformanceObject_Write_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfPerformanceObject_Read_Proxy( 
    IPerfPerformanceObject __RPC_FAR * This,
    /* [in] */ LPUNKNOWN pStream);


void __RPC_STUB IPerfPerformanceObject_Read_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfPerformanceObject_FindFirst_Proxy( 
    IPerfPerformanceObject __RPC_FAR * This,
    /* [in] */ BSTR coName);


void __RPC_STUB IPerfPerformanceObject_FindFirst_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfPerformanceObject_SetInfo_Proxy( 
    IPerfPerformanceObject __RPC_FAR * This,
    /* [in] */ BSTR poName,
    /* [in] */ BSTR poHelp,
    /* [in] */ long poIndex);


void __RPC_STUB IPerfPerformanceObject_SetInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPerfPerformanceObject_GetParent_Proxy( 
    IPerfPerformanceObject __RPC_FAR * This,
    /* [retval][out] */ IPerfParentObject __RPC_FAR *__RPC_FAR *pParent);


void __RPC_STUB IPerfPerformanceObject_GetParent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPerfPerformanceObject_INTERFACE_DEFINED__ */


#ifndef __IPerfCounterObject_INTERFACE_DEFINED__
#define __IPerfCounterObject_INTERFACE_DEFINED__

/* interface IPerfCounterObject */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IPerfCounterObject;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("4121ffe0-cf5d-11d2-8b5b-00104bf19ef5")
    IPerfCounterObject : public IDispatch
    {
    public:
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_m_value( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_m_value( 
            /* [in] */ VARIANT newVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_m_dataType( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_m_dataType( 
            /* [in] */ short newVal) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Write( 
            /* [in] */ LPUNKNOWN pStream) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Read( 
            /* [in] */ LPUNKNOWN pStream) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SetInfo( 
            /* [in] */ BSTR coName,
            /* [in] */ BSTR coHelp,
            /* [in] */ long coIndex) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE GetParent( 
            /* [retval][out] */ IPerfParentObject __RPC_FAR *__RPC_FAR *pParent) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPerfCounterObjectVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IPerfCounterObject __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IPerfCounterObject __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IPerfCounterObject __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IPerfCounterObject __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IPerfCounterObject __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IPerfCounterObject __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IPerfCounterObject __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_m_value )( 
            IPerfCounterObject __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_m_value )( 
            IPerfCounterObject __RPC_FAR * This,
            /* [in] */ VARIANT newVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_m_dataType )( 
            IPerfCounterObject __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_m_dataType )( 
            IPerfCounterObject __RPC_FAR * This,
            /* [in] */ short newVal);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Write )( 
            IPerfCounterObject __RPC_FAR * This,
            /* [in] */ LPUNKNOWN pStream);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Read )( 
            IPerfCounterObject __RPC_FAR * This,
            /* [in] */ LPUNKNOWN pStream);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetInfo )( 
            IPerfCounterObject __RPC_FAR * This,
            /* [in] */ BSTR coName,
            /* [in] */ BSTR coHelp,
            /* [in] */ long coIndex);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetParent )( 
            IPerfCounterObject __RPC_FAR * This,
            /* [retval][out] */ IPerfParentObject __RPC_FAR *__RPC_FAR *pParent);
        
        END_INTERFACE
    } IPerfCounterObjectVtbl;

    interface IPerfCounterObject
    {
        CONST_VTBL struct IPerfCounterObjectVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPerfCounterObject_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPerfCounterObject_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPerfCounterObject_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPerfCounterObject_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPerfCounterObject_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPerfCounterObject_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPerfCounterObject_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPerfCounterObject_get_m_value(This,pVal)	\
    (This)->lpVtbl -> get_m_value(This,pVal)

#define IPerfCounterObject_put_m_value(This,newVal)	\
    (This)->lpVtbl -> put_m_value(This,newVal)

#define IPerfCounterObject_get_m_dataType(This,pVal)	\
    (This)->lpVtbl -> get_m_dataType(This,pVal)

#define IPerfCounterObject_put_m_dataType(This,newVal)	\
    (This)->lpVtbl -> put_m_dataType(This,newVal)

#define IPerfCounterObject_Write(This,pStream)	\
    (This)->lpVtbl -> Write(This,pStream)

#define IPerfCounterObject_Read(This,pStream)	\
    (This)->lpVtbl -> Read(This,pStream)

#define IPerfCounterObject_SetInfo(This,coName,coHelp,coIndex)	\
    (This)->lpVtbl -> SetInfo(This,coName,coHelp,coIndex)

#define IPerfCounterObject_GetParent(This,pParent)	\
    (This)->lpVtbl -> GetParent(This,pParent)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IPerfCounterObject_get_m_value_Proxy( 
    IPerfCounterObject __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IPerfCounterObject_get_m_value_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IPerfCounterObject_put_m_value_Proxy( 
    IPerfCounterObject __RPC_FAR * This,
    /* [in] */ VARIANT newVal);


void __RPC_STUB IPerfCounterObject_put_m_value_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IPerfCounterObject_get_m_dataType_Proxy( 
    IPerfCounterObject __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB IPerfCounterObject_get_m_dataType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IPerfCounterObject_put_m_dataType_Proxy( 
    IPerfCounterObject __RPC_FAR * This,
    /* [in] */ short newVal);


void __RPC_STUB IPerfCounterObject_put_m_dataType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IPerfCounterObject_Write_Proxy( 
    IPerfCounterObject __RPC_FAR * This,
    /* [in] */ LPUNKNOWN pStream);


void __RPC_STUB IPerfCounterObject_Write_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IPerfCounterObject_Read_Proxy( 
    IPerfCounterObject __RPC_FAR * This,
    /* [in] */ LPUNKNOWN pStream);


void __RPC_STUB IPerfCounterObject_Read_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IPerfCounterObject_SetInfo_Proxy( 
    IPerfCounterObject __RPC_FAR * This,
    /* [in] */ BSTR coName,
    /* [in] */ BSTR coHelp,
    /* [in] */ long coIndex);


void __RPC_STUB IPerfCounterObject_SetInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IPerfCounterObject_GetParent_Proxy( 
    IPerfCounterObject __RPC_FAR * This,
    /* [retval][out] */ IPerfParentObject __RPC_FAR *__RPC_FAR *pParent);


void __RPC_STUB IPerfCounterObject_GetParent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPerfCounterObject_INTERFACE_DEFINED__ */


#ifndef __IRegObject_INTERFACE_DEFINED__
#define __IRegObject_INTERFACE_DEFINED__

/* interface IRegObject */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IRegObject;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("8EAD4FC1-F69B-11D2-8BC7-00104BF19EF5")
    IRegObject : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Register( 
            /* [in] */ BSTR poName,
            /* [in] */ BSTR bDatPath,
            /* [in] */ BSTR pLODCTRPath) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Unregister( 
            /* [in] */ BSTR poName) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CreateLODCTRFiles( 
            /* [in] */ BSTR bCreatePath,
            /* [in] */ BSTR bDatPath) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IRegObjectVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IRegObject __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IRegObject __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IRegObject __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IRegObject __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IRegObject __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IRegObject __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IRegObject __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Register )( 
            IRegObject __RPC_FAR * This,
            /* [in] */ BSTR poName,
            /* [in] */ BSTR bDatPath,
            /* [in] */ BSTR pLODCTRPath);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Unregister )( 
            IRegObject __RPC_FAR * This,
            /* [in] */ BSTR poName);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CreateLODCTRFiles )( 
            IRegObject __RPC_FAR * This,
            /* [in] */ BSTR bCreatePath,
            /* [in] */ BSTR bDatPath);
        
        END_INTERFACE
    } IRegObjectVtbl;

    interface IRegObject
    {
        CONST_VTBL struct IRegObjectVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IRegObject_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IRegObject_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IRegObject_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IRegObject_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IRegObject_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IRegObject_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IRegObject_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IRegObject_Register(This,poName,bDatPath,pLODCTRPath)	\
    (This)->lpVtbl -> Register(This,poName,bDatPath,pLODCTRPath)

#define IRegObject_Unregister(This,poName)	\
    (This)->lpVtbl -> Unregister(This,poName)

#define IRegObject_CreateLODCTRFiles(This,bCreatePath,bDatPath)	\
    (This)->lpVtbl -> CreateLODCTRFiles(This,bCreatePath,bDatPath)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRegObject_Register_Proxy( 
    IRegObject __RPC_FAR * This,
    /* [in] */ BSTR poName,
    /* [in] */ BSTR bDatPath,
    /* [in] */ BSTR pLODCTRPath);


void __RPC_STUB IRegObject_Register_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRegObject_Unregister_Proxy( 
    IRegObject __RPC_FAR * This,
    /* [in] */ BSTR poName);


void __RPC_STUB IRegObject_Unregister_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRegObject_CreateLODCTRFiles_Proxy( 
    IRegObject __RPC_FAR * This,
    /* [in] */ BSTR bCreatePath,
    /* [in] */ BSTR bDatPath);


void __RPC_STUB IRegObject_CreateLODCTRFiles_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IRegObject_INTERFACE_DEFINED__ */



#ifndef __PERFSRVEXELib_LIBRARY_DEFINED__
#define __PERFSRVEXELib_LIBRARY_DEFINED__

/* library PERFSRVEXELib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_PERFSRVEXELib;

EXTERN_C const CLSID CLSID_PerfSrvObject;

#ifdef __cplusplus

class DECLSPEC_UUID("34CC2AF6-CF4B-11D2-8B5B-00104BF19EF5")
PerfSrvObject;
#endif

EXTERN_C const CLSID CLSID_RegObject;

#ifdef __cplusplus

class DECLSPEC_UUID("8EAD4FC2-F69B-11D2-8BC7-00104BF19EF5")
RegObject;
#endif
#endif /* __PERFSRVEXELib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long __RPC_FAR *, unsigned long            , VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long __RPC_FAR *, VARIANT __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
