// RegObject.cpp : Implementation of CRegObject
#include "stdafx.h"
#include "PerfSrvExe.h"
#include "RegObject.h"
/////////////////////////////////////////////////////////////////////////////
// CRegObject
const string CRegObject::english	= "009";
const string CRegObject::define		= "#define ";
const string CRegObject::name		= "_name=";
const string CRegObject::help		= "_help=";
const string CRegObject::m_perfDLLName = "PerfWin32.dll";

STDMETHODIMP CRegObject::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IRegObject
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}
HRESULT CRegObject::FinalConstruct()
{	
	HRESULT hr = S_OK;

	return hr;
}
void CRegObject::FinalRelease()
{
}

STDMETHODIMP CRegObject::Register(BSTR poName,BSTR bDatPath,BSTR pLODCTRPath)
{
	HRESULT hr = S_OK;
	USES_CONVERSION;
	m_poName = poName;

	hdrFileName = m_poName + ".h";
	iniFileName = m_poName + ".ini";

	if(AddRegEntries(OLE2A(bDatPath)) == true)
	{
		AddPOCOData(OLE2A(bDatPath),OLE2A(pLODCTRPath));
	}
	else
	{
		ReportError repErr;
		return repErr.WriteCOMError(IDS_MAPNOTINITIALIZED,"Something Failed.");
	}

	return hr;
}

STDMETHODIMP CRegObject::Unregister(BSTR poName)
{
	HRESULT hr = S_OK;

	return hr;
}
void CRegObject::AppendRegStrings(CRegSettings& regPerfLib, 
	BOOL fCounter, PDWORD pdwIndex) {

	USES_CONVERSION;
}
bool CRegObject::AddRegEntries(char* pDataPath)
{
	CRegKey	regKey;

	bool retVal = true;
	long regVal = 0;
	
	string regKeyName = "SYSTEM\\CurrentControlSet\\Services\\"+ m_poName;

	regVal = regKey.Create(HKEY_LOCAL_MACHINE,regKeyName.c_str());

	if(regVal != ERROR_SUCCESS) 
	{
		return false;
	}

	CRegKey perfKey;

	regVal = perfKey.Create(HKEY_LOCAL_MACHINE,(regKeyName + "\\Performance").c_str());

	if(regVal != ERROR_SUCCESS) 
	{
		regKey.Close();
		return false;
	}
	
	perfKey.SetValue("ClosePerfData","Close");
	perfKey.SetValue("CollectPerfData","Collect");
	perfKey.SetValue("OpenPerfData","Open");
	perfKey.SetValue(m_perfDLLName.c_str(),"Library");
	perfKey.SetValue(pDataPath,"DataFile");
	
	CRegKey linkKey;

	string linkName = m_poName + "\\Linkage";
	regVal = linkKey.Create(HKEY_LOCAL_MACHINE,(regKeyName + "\\Linkage").c_str());
	
	if(regVal != ERROR_SUCCESS) 
	{
		regKey.Close();
		perfKey.Close();
		return false;
	}

	LPWSTR pTemp = (wchar_t*)m_poName;

	RegSetValueEx(linkKey.m_hKey,"Export",0,REG_BINARY,(LPBYTE)pTemp, (m_poName.length()*2)+1);

	return retVal;
}
/*************************************************************
AddPOCOData - Error checking needs to be done some more

	You'll have to excuse my hack here. This method uses an
	older method for creating the registry information needed
	for PO and CO. This function will create the .INI and .H
	files the given PO and CO's defined as part of the PO.
	This function will automatically register the individual
	PO that was passed with the LODCTR function.
	I'll be adding a new method later on that doesn't require the
	use of the lodctr function. See the RegSettings.h file
	created by Jeffrey Richter. I just haven't had time
	to change things over to use his method. If you figure
	it out, please let me know: 
	kenk@lightwizardproductions.com
*************************************************************/
bool CRegObject::AddPOCOData(char* pDataPath,char* pLODCTRPath)
{
	bool retVal = true;
	HRESULT hr = S_OK;

	USES_CONVERSION;

	CComObject<CPerfSrvObject>*	pPerfSrvObject;

	CComObject<CPerfSrvObject>::CreateInstance(&pPerfSrvObject);
	pPerfSrvObject->AddRef();

	_bstr_t bPath(pDataPath);
	_bstr_t bLODCTRPath(pLODCTRPath);
	hr = pPerfSrvObject->Load(bPath,NULL);	
	
	if(FAILED(hr))
	{
		pPerfSrvObject->Release();
		return FALSE;
	}

	hr = pPerfSrvObject->FindFirst(m_poName);

	if(FAILED(hr))
	{
		pPerfSrvObject->Release();
		return FALSE;
	}

	bLODCTRPath += "\\";
	HANDLE hFile = CreateFile(bLODCTRPath + hdrFileName.c_str(),GENERIC_WRITE,FILE_SHARE_WRITE,NULL,CREATE_ALWAYS,
					FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN,NULL);
	HANDLE iniFile = CreateFile(bLODCTRPath + iniFileName.c_str(),GENERIC_WRITE,FILE_SHARE_WRITE,NULL,CREATE_ALWAYS,
					FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN,NULL);

	if(hFile == INVALID_HANDLE_VALUE || iniFile == INVALID_HANDLE_VALUE)
	{
		pPerfSrvObject->Release();
		return FALSE;
	}

	string infoHdr = "[info]\r\n";
	string infoDrive = "drivername=";
	infoDrive += m_poName + "\r\n";
	
	string infoSymbol = "symbolfile=";
	infoSymbol += (hdrFileName + "\r\n").c_str();

	string infoLang = "[languages]\r\n";
	infoLang += (english + string("=English\r\n")).c_str();

	string infoText = "[text]\r\n";

	//Write info out to iniFile
	DWORD numWrite;
	string beginHdr = infoHdr + infoDrive + infoSymbol + infoLang + infoText;
	int isOKay = WriteFile(iniFile,beginHdr.c_str(),beginHdr.length(), &numWrite, NULL);

	//Call PO for Index value, Name and Help String
	IPerfPerformanceObject* poTemp = NULL;
	IPerfParentObject* parentTemp = NULL;

	hr = pPerfSrvObject->GetCurrentPO(&poTemp);

	hr = poTemp->GetParent(&parentTemp);

	long poIndex = 0;
	BSTR poName;
	BSTR poHelpString;
	
	hr = parentTemp->get_m_name(&poName);
	hr = parentTemp->get_m_helpString(&poHelpString);

	parentTemp->Release();

	_bstr_t objName(poName);
	char poIndexString[32];
	sprintf(poIndexString," %ld\r\n",poIndex);

	//PO Defines
	string defOut = define + string(objName + poIndexString);
	isOKay = WriteFile(hFile,defOut.c_str(),defOut.length(), &numWrite, NULL);

	//Write POName info
	string pEnglish = (string("_") +english);
	string pComplete = string(objName) + pEnglish + name + (string(objName)+"\r\n");

	isOKay = WriteFile(iniFile,pComplete.c_str(),pComplete.length(), &numWrite, NULL);

	//Write Help info
	_bstr_t objHelp(poHelpString);
	pComplete = string(objName) + pEnglish + help + (string(objHelp)+"\r\n");

	isOKay = WriteFile(iniFile,pComplete.c_str(),pComplete.length(), &numWrite, NULL);

	long numCounters = 0;

	hr = poTemp->get_m_numCounters(&numCounters);

	if(numCounters > 0)
	{
		
		hr = poTemp->MoveFirst();
		int x = 0;
		do
		{
			long coIndex = 0;
			IPerfCounterObject* coTemp;
			hr = poTemp->GetCurrentCO(&coTemp);
			hr = coTemp->GetParent(&parentTemp);

			hr = parentTemp->get_m_name(&poName);
			hr = parentTemp->get_m_helpString(&poHelpString);

			objName = poName;
			objHelp = poHelpString;
			hr = parentTemp->get_m_indexValue(&coIndex);

			//Counter Define
			sprintf(poIndexString," %ld\r\n",coIndex);
			string hString = define + string(objName + poIndexString); 
			isOKay = WriteFile(hFile,hString.c_str(),hString.length(), &numWrite, NULL);

			//Write COName info
			pComplete = string(objName) + pEnglish + name + (string(objName)+"\r\n");
			isOKay = WriteFile(iniFile,pComplete.c_str(),pComplete.length(), &numWrite, NULL);

			//Write Help info
			pComplete = string(objName) + pEnglish + help + (string(objHelp)+"\r\n");
			isOKay = WriteFile(iniFile,pComplete.c_str(),pComplete.length(), &numWrite, NULL);

			parentTemp->Release();
			coTemp->Release();
			//increment loop counter
			x++;
			if(x != numCounters)
			{
				poTemp->MoveNext();
			}

		}while(x<numCounters);
	}

	//run lodctr on ini file

	CloseHandle(hFile);
	CloseHandle(iniFile);
	
	poTemp->Release();

	hr = pPerfSrvObject->Release();

	WinExec(string("unlodctr " + bLODCTRPath + m_poName).c_str(),SW_HIDE);

	char dirPath[MAX_PATH];

	GetCurrentDirectory(MAX_PATH,dirPath);
	SetCurrentDirectory(bPath);
	WinExec((string("lodctr " + bLODCTRPath ) + iniFileName).c_str(),SW_HIDE);
	SetCurrentDirectory(dirPath);
	return retVal;
}
/*************************************************************
	You'll have to excuse my hack here. This method uses an
	older method for creating the registry information needed
	for PO and CO. This function will create the .INI and .H
	files for each of the PO's and CO's defined in a .DAT file.
	Once you have them, you can run lodctr on each one to register
	the information into the registry.
	I'll be adding a new method later on that doesn't require the
	use of the lodctr function.See the RegSettings.h file
	created by Jeffrey Richter. I just haven't had time
	to change things over to use his method. If you figure
	it out, please let me know: kenk@lightwizardproductions.com
*************************************************************/
STDMETHODIMP CRegObject::CreateLODCTRFiles(BSTR bCreatePath, BSTR bDatPath)
{
	HRESULT hr = S_OK;

	if(bCreatePath == NULL || bDatPath == NULL)
	{
		ReportError repErr;
		return repErr.WriteCOMError(IDS_GENERALERROR,"Paths cannot be NULL.");
	}

	USES_CONVERSION;

	CComObject<CPerfSrvObject>*	pPerfSrvObject;

	CComObject<CPerfSrvObject>::CreateInstance(&pPerfSrvObject);
	pPerfSrvObject->AddRef();

	_bstr_t bLocalDatPath(bDatPath);
	_bstr_t bLocalCreatePath(bCreatePath);
	hr = pPerfSrvObject->Load(bLocalDatPath,NULL);	

	if(FAILED(hr))
	{
		pPerfSrvObject->Release();
		ReportError repErr;
		return repErr.WriteCOMError(IDS_GENERALERROR,"Dat file could not be loaded.");
	}

	IPerfPerformanceObject* poTemp = NULL;
	IPerfParentObject* parentTemp = NULL;
	HANDLE hFile,iniFile;
	long numPOs = 0;

	hr = pPerfSrvObject->GetNumPOs(&numPOs);
	hr = pPerfSrvObject->MoveFirst();

	for(int x=0;x<numPOs && SUCCEEDED(hr);x++)
	{
		//now we append each PO name to path so create the .H and .INI files
		_bstr_t bLoopPath(bLocalCreatePath +"\\");
		//Call PO for Index value, Name and Help String

		hr = pPerfSrvObject->GetCurrentPO(&poTemp);

		hr = poTemp->GetParent(&parentTemp);
		long poIndex = 0;
		BSTR poName;
		BSTR poHelpString;
		
		hr = parentTemp->get_m_name(&poName);
		hr = parentTemp->get_m_helpString(&poHelpString);

		hr = parentTemp->Release();
		_bstr_t bPOName(poName);
		bLoopPath += bPOName;

		hFile = CreateFile(bLoopPath + hdrFileName.c_str(),GENERIC_WRITE,FILE_SHARE_WRITE,NULL,CREATE_ALWAYS,
						FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN,NULL);
		iniFile = CreateFile(bLoopPath + iniFileName.c_str(),GENERIC_WRITE,FILE_SHARE_WRITE,NULL,CREATE_ALWAYS,
						FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN,NULL);

		//general info for ini file
		string infoHdr = "[info]\r\n";
		string infoDrive = "drivername=";
		infoDrive += bPOName + "\r\n";
		
		string infoSymbol = "symbolfile=";
		infoSymbol += (hdrFileName + "\r\n").c_str();

		string infoLang = "[languages]\r\n";
		infoLang += (english + string("=English\r\n")).c_str();

		string infoText = "[text]\r\n";

		//Write info out to iniFile
		DWORD numWrite;
		string beginHdr = infoHdr + infoDrive + infoSymbol + infoLang + infoText;
		int isOKay = WriteFile(iniFile,beginHdr.c_str(),beginHdr.length(), &numWrite, NULL);

		//write out PO info
		char poIndexString[32];
		sprintf(poIndexString," %ld\r\n",poIndex);

		//PO Defines
		string defOut = define + string(bPOName + poIndexString);
		isOKay = WriteFile(hFile,defOut.c_str(),defOut.length(), &numWrite, NULL);

		//Write POName info
		string pEnglish = (string("_") +english);
		string pComplete = string(bPOName) + pEnglish + name + (string(bPOName)+"\r\n");

		isOKay = WriteFile(iniFile,pComplete.c_str(),pComplete.length(), &numWrite, NULL);

		//Write Help info
		_bstr_t bObjHelp(poHelpString);
		pComplete = string(bPOName) + pEnglish + help + (string(bObjHelp)+"\r\n");

		isOKay = WriteFile(iniFile,pComplete.c_str(),pComplete.length(), &numWrite, NULL);

		//write out the counter information
		long numCounters = 0;
		long coIndex = 0;
		BSTR coName,coHS;
		IPerfCounterObject* coTemp;

		hr = poTemp->get_m_numCounters(&numCounters);
		for(int y=0;y<numCounters && SUCCEEDED(hr);y++)
		{
			hr = poTemp->GetCurrentCO(&coTemp);
			hr = coTemp->GetParent(&parentTemp);

			hr = parentTemp->get_m_name(&coName);
			hr = parentTemp->get_m_helpString(&coHS);

			bPOName = coName; //reuse _bstr_t variables
			bObjHelp = coHS;
			hr = parentTemp->get_m_indexValue(&coIndex);
			//release the parent
			hr = parentTemp->Release();

			//Counter Define
			sprintf(poIndexString," %ld\r\n",coIndex);
			string hString = define + string(bPOName + poIndexString); 
			isOKay = WriteFile(hFile,hString.c_str(),hString.length(), &numWrite, NULL);

			//Write COName info
			pComplete = string(bPOName) + pEnglish + name + (string(bPOName)+"\r\n");
			isOKay = WriteFile(iniFile,pComplete.c_str(),pComplete.length(), &numWrite, NULL);

			//Write Help info
			pComplete = string(bPOName) + pEnglish + help + (string(bObjHelp)+"\r\n");
			isOKay = WriteFile(iniFile,pComplete.c_str(),pComplete.length(), &numWrite, NULL);

			coTemp->Release();
			//increment loop counter
			hr = poTemp->MoveNext();
		}

		//clean up
		CloseHandle(hFile);
		CloseHandle(iniFile);
		hr = poTemp->Release();

		//onto the next PO
		hr = pPerfSrvObject->MoveNext();
	}

	return hr;
}
