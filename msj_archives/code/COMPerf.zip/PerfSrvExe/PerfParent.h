// PerfParent.h: interface for the CPerfParent class.
//
//////////////////////////////////////////////////////////////////////


#ifndef __PERFPARENT_H_
#define __PERFPARENT_H_

//#include <comdef.h>

#include <comdef.h>
#include "atlcom.h"
#include <string>
#include <map>
using namespace std;

class IPerfPerformanceObjectImpl;
class IPerfCounterObjectImpl;

interface IPerfPerformanceObject;
interface IPerfCounterObject;
interface IPerfParentObject;

_COM_SMARTPTR_TYPEDEF(IPerfParentObject,IID_IPerfParentObject);

typedef map<_bstr_t,IPerfPerformanceObject*> POTYPE;
typedef map<_bstr_t,IPerfCounterObject*> COTYPE;

#include "resource.h"

#include "perfsrvexe.h"
#include <comdef.h>

class ReportError
{
public:
	ReportError(){}
	~ReportError(){}
	HRESULT WriteCOMError(UINT resID,LPSTR pComment)
	{
		char buf[256];
		char outBuf[256];
		HRESULT hr = E_FAIL;
		::LoadString(_Module.GetModuleInstance(),resID,buf,255);
		if(strlen(pComment) > 0)
		{
			sprintf(outBuf,buf,pComment);
		}
		else
		{
			strcpy(outBuf,buf);
		}
		AtlReportError(CLSID_PerfSrvObject,outBuf,IID_IPerfSrvObject,0);
		return hr;
	}
};

class ATL_NO_VTABLE IPerfParentImpl : 
	public IDispatchImpl<IPerfParentObject,&IID_IPerfParentObject>,
	public CComObjectRoot

{
protected:
	_bstr_t m_name;
	_bstr_t m_helpString;
	long m_indexValue;

public:
	IPerfParentImpl() {};

BEGIN_COM_MAP(IPerfParentImpl)
	COM_INTERFACE_ENTRY(IPerfParentObject)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()	

STDMETHOD(get_m_name)(/*[out, retval]*/ BSTR *pVal)
{
	_bstr_t pTemp(m_name);
	*pVal = pTemp.copy();
	return S_OK;
}
STDMETHOD(put_m_name)(/*[in]*/ BSTR newVal)
{
	m_name = newVal;
	return S_OK;
}
STDMETHOD(get_m_helpString)(/*[out, retval]*/ BSTR *pVal)
{
	_bstr_t pTemp(m_helpString);
	*pVal = pTemp.copy();
	return S_OK;
}
STDMETHOD(put_m_helpString)(/*[in]*/ BSTR newVal)
{
	m_helpString = newVal;
	return S_OK;
}
STDMETHOD(get_m_indexValue)(/*[out, retval]*/ long *pVal)
{
	*pVal = m_indexValue;
	return S_OK;
}
STDMETHOD(put_m_indexValue)(/*[in]*/ long newVal)
{
	m_indexValue = newVal;
	return S_OK;
}

};

class ATL_NO_VTABLE IPerfCounterObjectImpl : 
	public IDispatchImpl<IPerfCounterObject,&IID_IPerfCounterObject>,
	public ISupportErrorInfo,
	public CComObjectRoot
{


public:
	IPerfCounterObjectImpl() {};
	virtual ~IPerfCounterObjectImpl(){}; 

BEGIN_COM_MAP(IPerfCounterObjectImpl)
	COM_INTERFACE_ENTRY(IPerfCounterObject)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()	

private:
	_variant_t m_value;
	short m_dataType;
	CComObject<IPerfParentImpl>*  m_parentObject;
public:
	HRESULT FinalConstruct()
	{
		HRESULT hr = S_OK;
		hr = CComObject<IPerfParentImpl>::CreateInstance(&m_parentObject);

		if(FAILED(hr))
		{
			return hr;
		}
		m_parentObject->AddRef();
		return hr;
	}
	void FinalRelease()
	{
		m_parentObject->Release();
	}

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid)
	{
		return (InlineIsEqualGUID(IID_IPerfCounterObject,riid)) ? S_OK : S_FALSE;
	}

	STDMETHOD(GetParent)(/*[in,retval]*/IPerfParentObject** pParent)
	{
		HRESULT hr = S_OK;
		*pParent = m_parentObject;
		(*pParent)->AddRef();
		return hr;
	}
	
	STDMETHOD(SetInfo) (/*[in]*/ BSTR coName,/*[in]*/BSTR coHelp,/*[in]*/long coIndex)
	{
		HRESULT hr = S_OK;
		m_parentObject->put_m_name(coName);
		m_parentObject->put_m_helpString(coHelp);
		m_parentObject->put_m_indexValue(coIndex);
		return hr;
	}
	STDMETHOD(get_m_value)(/*[out, retval]*/ VARIANT *pVal)
	{
		_variant_t pTemp(m_value);
		*pVal = pTemp.Detach();
		return S_OK;
	}
	STDMETHOD(put_m_value)(/*[in]*/ VARIANT newVal)
	{
		m_value = newVal;
		return S_OK;
	}
	STDMETHOD(get_m_dataType)(/*[out, retval]*/ short *pVal)
	{
		*pVal = m_dataType;
		return S_OK;
	}
	STDMETHOD(put_m_dataType)(/*[in]*/ short newVal)
	{
		m_dataType = newVal;
		return S_OK;
	}
	STDMETHOD(Write) (/*[in]*/ LPUNKNOWN pStream)
	{
		IStreamPtr pIStream(pStream);

		ULONG cb = 0;
		BSTR bName;
		BSTR bHelp;
		
		m_parentObject->get_m_name(&bName);
		m_parentObject->get_m_helpString(&bHelp);

		CComVariant coName(bName);
		CComVariant coHelp(bHelp);

		coName.WriteToStream(pIStream);
		coHelp.WriteToStream(pIStream);
		
		//The next sections commented out are taken care
		//of automatically upon recreation because the
		//values are created during the AddCounter method
		//of the Performance Object class
//		long indexValue = 0;
//		short dataType = 0;

//		m_parentObject->get_m_indexValue(&indexValue);

//		pIStream->Write(&indexValue,sizeof(long),&cb);
//		pIStream->Write(&m_dataType,sizeof(short),&cb);

		SysFreeString(bName);
		SysFreeString(bHelp);

		return S_OK;
	}
	/************************************************
		Note: Read Method
			This method is not used yet...
	************************************************/
	STDMETHOD(Read) (/*[in]*/ LPUNKNOWN pStream)
	{
		HRESULT hr = S_OK;
		IStreamPtr pIStream(pStream);
//		ULONG cb;

		CComVariant	coName;
		CComVariant	coHelp;

		coName.ReadFromStream(pIStream);
		coHelp.ReadFromStream(pIStream);
		
//		pIStream->Read(&m_indexValue,sizeof(long),&cb);
//		pIStream->Read(&m_dataType,sizeof(short),&cb);
		
		return hr;
	}

};

class ATL_NO_VTABLE IPerfPerformanceObjectImpl : 
	public IDispatchImpl<IPerfPerformanceObject,&IID_IPerfPerformanceObject>,
	public CComObjectRoot
{
public:
	IPerfPerformanceObjectImpl() : m_bof(false),m_eof(false) {};
	virtual ~IPerfPerformanceObjectImpl(){}; 

BEGIN_COM_MAP(IPerfPerformanceObjectImpl)
	COM_INTERFACE_ENTRY(IPerfPerformanceObject)
END_COM_MAP()	

private:
	COTYPE	m_counterList;
	COTYPE::iterator	m_curCounter;
	bool m_bof;
	bool m_eof;

	CComObject<IPerfParentImpl>*  m_parentObject;

public:
	HRESULT FinalConstruct()
	{
		HRESULT hr = S_OK;
		hr = CComObject<IPerfParentImpl>::CreateInstance(&m_parentObject);
		if(FAILED(hr))
		{
			return hr;
		}
		m_parentObject->AddRef();
		return hr;
	}
	void FinalRelease()
	{
		COTYPE::iterator	iter;

		for(iter = m_counterList.begin();iter != m_counterList.end();iter++)
		{
			((*iter).second)->Release();
		}
		m_counterList.clear();
		m_curCounter = m_counterList.end();

		//Release the contained Parent class
		m_parentObject->Release();
	}

	STDMETHOD(FindFirst) (/*[in]*/ BSTR coName)
	{
		HRESULT hr = S_OK;

		_bstr_t	nameToFind(coName);

		m_curCounter = m_counterList.find(nameToFind);

		if(m_curCounter == m_counterList.end())
		{
			USES_CONVERSION;
			ReportError repErr;

			return repErr.WriteCOMError(IDS_NORECORDFOUND,OLE2A(coName));
		}

		return hr;	
	}
	STDMETHOD(Read) (/*[in]*/ LPUNKNOWN pStream)
	{
		HRESULT hr = S_OK;
		IStreamPtr pIStream(pStream);
		ULONG cb;

		CComVariant	poName;
		CComVariant	poHelp;

		poName.ReadFromStream(pIStream);
		poHelp.ReadFromStream(pIStream);
		
		long indexValue = 0;
		pIStream->Read(&indexValue,sizeof(long),&cb);

		m_parentObject->put_m_name(_bstr_t(poName));
		m_parentObject->put_m_helpString(_bstr_t(poHelp));
		m_parentObject->put_m_indexValue(indexValue);

		long numCounters = 0;

		pIStream->Read(&numCounters,sizeof(long),&cb);

		CComVariant coName;
		CComVariant coHelp;

		for(int x=0;x<numCounters;x++)
		{
			coName.ReadFromStream(pIStream);
			coHelp.ReadFromStream(pIStream);

			hr = AddCounterObject(coName,coHelp);
		}

		return hr;

	}
	STDMETHOD(Write) (/*[in]*/ LPUNKNOWN pStream)
	{
		IStreamPtr pIStream(pStream);
		ULONG cb;

		BSTR bName = 0;
		BSTR bHelpString = 0;
		m_parentObject->get_m_name(&bName);
		m_parentObject->get_m_helpString(&bHelpString);

		CComVariant poName(bName);
		CComVariant poHelp(bHelpString);

		poName.WriteToStream(pIStream);
		poHelp.WriteToStream(pIStream);

		long indexValue = 0;
		pIStream->Write(&indexValue,sizeof(long),&cb);

		long numCounters = m_counterList.size();

		pIStream->Write(&numCounters,sizeof(long),&cb);

		SysFreeString(bName);
		SysFreeString(bHelpString);

		return S_OK;
	}

	STDMETHOD(get_m_numCounters) (/*[out, retval]*/ long *pVal)
	{
		*pVal = m_counterList.size();
		return S_OK;
	}

	STDMETHOD(MoveFirst)()
	{
		HRESULT hr = S_OK;
		if(m_counterList.size() > 0)
		{
			m_bof = false;
			m_eof = false;
			m_curCounter = m_counterList.begin();
		}
		else
		{
			ReportError repErr;
			return repErr.WriteCOMError(IDS_MAPNOTINITIALIZED,"");
		}

		return hr;
	}
	STDMETHOD(MoveLast)()
	{
		HRESULT hr = S_OK;
		if(m_counterList.size() > 0)
		{
			m_bof = false;
			m_eof = false;
			m_curCounter = m_counterList.end();
			m_curCounter--;
		}
		else
		{
			ReportError repErr;
			return repErr.WriteCOMError(IDS_MAPNOTINITIALIZED,"");
		}
		return hr;
	}
	STDMETHOD(MoveNext)()
	{
		HRESULT hr = S_OK;
		ReportError repErr;

		if(m_eof)
		{
			return repErr.WriteCOMError(IDS_ENDOFMAP,"");
		}
		else
		{
			if(m_bof)
			{
				MoveFirst();
				m_bof = false;
			}
			else
			{
				m_curCounter++;
			}

			if(m_curCounter == m_counterList.end())
			{
				m_eof = true;
				return repErr.WriteCOMError(IDS_ENDOFMAP,"");
			}

		}
		return hr;
	}
	STDMETHOD(MovePrevious)()
	{
		HRESULT hr = S_OK;
		ReportError repErr;

		if(m_bof)
		{
			return repErr.WriteCOMError(IDS_BEGINOFMAP,"");
		}
		else
		{
			if(m_curCounter == m_counterList.begin() )
			{
				m_curCounter = m_counterList.begin();
				m_bof = true;
			}
			else
			{
				m_curCounter--;
				m_eof = false;
			}
		}
		return hr;
	}

	STDMETHOD(GetCurrentCO)(/*[out,retval]*/IPerfCounterObject** pCO)
	{
		HRESULT hr = S_OK;

		*pCO = (*m_curCounter).second;
		((*m_curCounter).second)->AddRef();
		return hr;
	}
	STDMETHOD(AddCounter)(/*[in]*/VARIANT coName,/*[in]*/VARIANT coHelpString)
	{
		return AddCounterObject(coName,coHelpString);
	}

	STDMETHOD(GetParent)(/*[in,retval]*/IPerfParentObject** pParent)
	{
		HRESULT hr = S_OK;
		*pParent = m_parentObject;
		(*pParent)->AddRef();
		return hr;
	}
	STDMETHOD(SetInfo)(/*[in]*/BSTR poName,/*[in]*/BSTR poHelp,/*[in]*/long poIndex)
	{
		HRESULT hr = S_OK;
		m_parentObject->put_m_name(poName);
		m_parentObject->put_m_helpString(poHelp);
		m_parentObject->put_m_indexValue(poIndex);
		return hr;
	}
	HRESULT AddCounterObject(VARIANT rName,VARIANT rHelpString)
	{
		HRESULT hr = S_OK;

		CComObject<IPerfCounterObjectImpl> *pNew = NULL;

		hr = CComObject<IPerfCounterObjectImpl>::CreateInstance(&pNew);
		pNew->AddRef();		
	
		_bstr_t	bName(rName);
		_bstr_t	bHelp(rHelpString);

		short indexValue = (m_counterList.size()*2)+2;

		pNew->SetInfo(bName,bHelp,indexValue);

		_variant_t vValue((long)5);
		pNew->put_m_value(vValue);
		
		pNew->put_m_dataType(0);

		m_counterList[_bstr_t(rName)] = pNew;

		m_curCounter = m_counterList.end();
		m_curCounter--;

		return hr;
	}
};
#endif // !defined(AFX_PERFPARENT_H__4C8E9F43_C847_11D2_8B3B_00104BF19EF5__INCLUDED_)
