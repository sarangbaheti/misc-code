// PerfSrvObject.h : Declaration of the CPerfSrvObject

#ifndef __PERFSRVOBJECT_H_
#define __PERFSRVOBJECT_H_

#include "resource.h"       // main symbols
#include "perfparent.h"
/////////////////////////////////////////////////////////////////////////////
// CPerfSrvObject
class ATL_NO_VTABLE CPerfSrvObject : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CPerfSrvObject, &CLSID_PerfSrvObject>,
	public ISupportErrorInfo,
	public IPersistStreamInitImpl<CPerfSrvObject>,
	public IDispatchImpl<IPerfSrvObject, &IID_IPerfSrvObject, &LIBID_PERFSRVEXELib>
{
public:
	static POTYPE	s_POMap;
	POTYPE& m_POMap;

	POTYPE::iterator	m_curPO;	
	CPerfSrvObject() : m_POMap(s_POMap), m_bof(false), m_eof(false),m_bRequiresLoad(TRUE)
	{
	}

	HRESULT FinalConstruct();
	void FinalRelease();

DECLARE_REGISTRY_RESOURCEID(IDR_PERFSRVOBJECT)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CPerfSrvObject)
	COM_INTERFACE_ENTRY(IPerfSrvObject)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY_IMPL(IPersistStreamInit)
	COM_INTERFACE_ENTRY_IMPL_IID(IID_IPersistStream,IPersistStreamInit)
END_COM_MAP()

BEGIN_PROP_MAP(CPerfSrvObject)
END_PROP_MAP();
// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

	STDMETHOD(Load) (LPSTREAM pStream);
	STDMETHOD(Save) (LPSTREAM pStream, BOOL bClearDirty);
private:
	bool m_bof;
	bool m_eof;

public:
	STDMETHOD(Save)(/*[in]*/BSTR path,/*[in]*/BSTR name);
	STDMETHOD(AddPO)(/*[in]*/BSTR name, /*[in]*/BSTR helpString);
	STDMETHOD(GetNumCounters)(/*[out,retval]*/long* pNumCounters);
	STDMETHOD(MoveFirst)();
	STDMETHOD(MoveLast)();
	STDMETHOD(MoveNext)();
	STDMETHOD(MovePrevious)();
	STDMETHOD(GetNumPOs)(/*[out,retval]*/long* pNumCounters);
	STDMETHOD(GetCurrentPO)(/*[out,retval]*/IPerfPerformanceObject** pPO);
public:
	STDMETHOD(Clear)();
	STDMETHOD(FindFirst)(/*[in]*/ BSTR poName);
	STDMETHOD(Load)(/*[in]*/BSTR path,/*[in]*/BSTR name);
	bool m_bRequiresLoad;
	bool m_bRequiresSave;
};
#endif //__PERFSRVOBJECT_H_
