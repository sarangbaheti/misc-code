// RegObject.h : Declaration of the CRegObject

#ifndef __REGOBJECT_H_
#define __REGOBJECT_H_

#include "resource.h"       // main symbols
#include "regsettings.h"
#include "perfsrvobject.h"

/////////////////////////////////////////////////////////////////////////////
// CRegObject
class ATL_NO_VTABLE CRegObject : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CRegObject, &CLSID_RegObject>,
	public ISupportErrorInfo,
	public IDispatchImpl<IRegObject, &IID_IRegObject, &LIBID_PERFSRVEXELib>
{
public:
	CRegObject()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_REGOBJECT)
DECLARE_NOT_AGGREGATABLE(CRegObject)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CRegObject)
	COM_INTERFACE_ENTRY(IRegObject)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

private:
	DWORD m_dwLastCounter;
	DWORD m_dwLastHelp;
	DWORD m_dwFirstCounter;
	DWORD m_dwFirstHelp;
	
	_bstr_t m_poName;
private:
	void AppendRegStrings(CRegSettings& regPerfLib,BOOL fCounter, PDWORD pdwIndex);


// IRegObject
public:
	STDMETHOD(CreateLODCTRFiles)(/*[in]*/ BSTR bCreatePath, /*[in]*/ BSTR bDatPath);
	STDMETHOD(Unregister)(/*[in]*/BSTR poName);
	STDMETHOD(Register)(/*[in]*/BSTR poName,/*[in]*/ BSTR bDatPath,/*[in]*/ BSTR pLODCTRPath);
	HRESULT FinalConstruct();
	void FinalRelease();

	string hdrFileName;
	string iniFileName;
	static const string m_perfDLLName;
	static const string english;
	static const string define;
	static const string name;
	static const string help;

//Member Variables
private:
	bool AddRegEntries(char* pDataPath);
	bool AddPOCOData(char* pDataPath,char* pLODCTRPath);


};

#endif //__REGOBJECT_H_
