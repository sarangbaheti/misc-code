///////////////////////////////////////////////////////////////////////////////////////////////////
//DispClient.h
//
//DESCRIPTION
//Declaration of the CDispClient class.
//
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __DISPCLIENT_H_
#define __DISPCLIENT_H_

#include "resource.h"       // main symbols
#include <mtx.h>

#define SafeRelease(pUnk) {if (pUnk){pUnk -> Release();pUnk = NULL; }}

interface IRDisp;

///////////////////////////////////////////////////////////////////////////////////////////////////
// CDispClient
class ATL_NO_VTABLE CDispClient : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CDispClient, &CLSID_CoDispClient>,
	public IObjectControl,
	public IDispatchImpl<IDispClient, &IID_IDispClient, &LIBID_CLIENTLib>
{
//memebers:
private:
	long m_ResourceID;
	IRDisp* m_ResourceDisp;

public:
	CDispClient();

DECLARE_REGISTRY_RESOURCEID(IDR_DISPCLIENT)
DECLARE_NOT_AGGREGATABLE(CDispClient)

BEGIN_COM_MAP(CDispClient)
	COM_INTERFACE_ENTRY(IDispClient)
	COM_INTERFACE_ENTRY(IObjectControl)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IObjectControl
public:
	STDMETHOD(Activate)();
	STDMETHOD_(BOOL, CanBePooled)();
	STDMETHOD_(void, Deactivate)();

// IDispClient
public:
	STDMETHOD(ResourceDisconnect)(/*[in]*/ long ResourceID);
	STDMETHOD(ConnectResource)(/*[in]*/ BSTR sAddress, /*[out]*/ long* lResourceID);
};

#endif //__DISPCLIENT_H_
