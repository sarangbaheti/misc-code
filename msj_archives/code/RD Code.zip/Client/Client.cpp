///////////////////////////////////////////////////////////////////////////////////////////////////
//Client.cpp : 
//
//DESCRIPTION
//Standard ATL implementation of DLL Exports.
//
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"
#include "initguid.h"
#include "Client.h"
#include "dlldatax.h"

#include "Client_i.c"
#include <initguid.h>
#include "DispClient.h"

#ifdef _MERGE_PROXYSTUB
extern "C" HINSTANCE hProxyDll;
#endif

CComModule _Module;

BEGIN_OBJECT_MAP(ObjectMap)
	OBJECT_ENTRY(CLSID_CoDispClient, CDispClient)
END_OBJECT_MAP()

///////////////////////////////////////////////////////////////////////////////////////////////////
//BOOL WINAPI DllMain(...)
//DESCRIPTION
//-  DLL Entry Point
//- Standard ATL implementation
//
extern "C"
BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	lpReserved;
#ifdef _MERGE_PROXYSTUB
	if (!PrxDllMain(hInstance, dwReason, lpReserved))
		return FALSE;
#endif
	if (dwReason == DLL_PROCESS_ATTACH)
	{
		_Module.Init(ObjectMap, hInstance);
		DisableThreadLibraryCalls(hInstance);
	}
	else if (dwReason == DLL_PROCESS_DETACH)
		_Module.Term();
	return TRUE;    // ok
}

///////////////////////////////////////////////////////////////////////////////////////////////////
//STDAPI DllCanUnloadNow(...)
//
//DESCRIPTION
//-Used to determine whether the DLL can be unloaded by OLE
//- Standard ATL implementation
//
STDAPI DllCanUnloadNow(void)
{
#ifdef _MERGE_PROXYSTUB
	if (PrxDllCanUnloadNow() != S_OK)
		return S_FALSE;
#endif
	return (_Module.GetLockCount()==0) ? S_OK : S_FALSE;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
//STDAPI DllGetClassObject(...)
//
//DESCRIPTION
//- Returns a class factory to create an object of the requested type
//- Standard ATL implementation
//
STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
#ifdef _MERGE_PROXYSTUB
	if (PrxDllGetClassObject(rclsid, riid, ppv) == S_OK)
		return S_OK;
#endif
	return _Module.GetClassObject(rclsid, riid, ppv);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
//STDAPI DllRegisterServer(...)
//
//DESCRIPTION
//- Adds entries to the system registry
//- Standard ATL implementation
//
STDAPI DllRegisterServer(void)
{
#ifdef _MERGE_PROXYSTUB
	HRESULT hRes = PrxDllRegisterServer();
	if (FAILED(hRes))
		return hRes;
#endif
	// registers object, typelib and all interfaces in typelib
	return _Module.RegisterServer(TRUE);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
//STDAPI DllUnregisterServer(...)
//
//DESCRIPTION
//- Removes entries from the system registry
//- Standard ATL implementation
//
STDAPI DllUnregisterServer(void)
{
#ifdef _MERGE_PROXYSTUB
	PrxDllUnregisterServer();
#endif
	_Module.UnregisterServer();
	return S_OK;
}