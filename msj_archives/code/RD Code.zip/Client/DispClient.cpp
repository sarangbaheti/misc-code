///////////////////////////////////////////////////////////////////////////////////////////////////
//DispClient.cpp
//
//DESCRIPTION
//This file contains an implementation of CDispClient class - MTS component that use custom 
//resource dispenser.
//
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#define _WIN32_WINNT 0x403

//disable warning C4786: symbol greater than 255 characters
#pragma warning(disable: 4786)

#include "stdafx.h"
#include "Client.h"
#include "DispClient.h"

#include "..\ResourceDisp\ResourceDisp.h"
#include "..\ResourceDisp\ResourceDisp_i.c"

///////////////////////////////////////////////////////////////////////////////////////////////////
//CDispClient::CDispClient()
//
//DESCRIPTION
//constructor
//
CDispClient::CDispClient()
{
	//initialize
	m_ResourceDisp = NULL;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
//HRESULT CDispClient::Activate(), implements IObjectControl::Activate()
//
//DESCRIPTION:
//implementation of MTS IObjectControl interface. This method is called by MTS just before
//object reference is returned to client.
//
//
HRESULT CDispClient::Activate()
{
	ATLTRACE(_T(" CDispClient::Activate()\n"));

	HRESULT hr;

	//initialize
	IClassFactory* pCF = NULL;

	m_ResourceID = NULL;

	//create instance of resource dispenser
	hr = CoGetClassObject(
			CLSID_CoRDisp, 
			CLSCTX_ALL, 
			NULL,
			IID_IClassFactory,
			(void**)&pCF);

	if (SUCCEEDED(hr))
	{
		hr = pCF->CreateInstance(0, IID_IRDisp, (void**)&m_ResourceDisp);
		pCF->Release();
		if (SUCCEEDED(hr))
		{
			return S_OK;
		}
		else
		{
			m_ResourceDisp = NULL;
		};
	};

	return hr;
} 

///////////////////////////////////////////////////////////////////////////////////////////////////
//HRESULT CDispClient::CanBePooled(), implements IObjectControl::CanBePooled()
//
//DESCRIPTION:
//This method is called by the MTS to find out whether object supports pooling.
//
BOOL CDispClient::CanBePooled()
{
	return TRUE;
} 

///////////////////////////////////////////////////////////////////////////////////////////////////
//HRESULT CDispClient::Deactivate(), implements IObjectControl::Deactivate()
//
//DESCRIPTION:
//This method is called by the MTS run-time environment whenever an object is deactivated.
//
void CDispClient::Deactivate()
{
	//Release Resources:
	SafeRelease(m_ResourceDisp);
	m_ResourceDisp = NULL;
} 


///////////////////////////////////////////////////////////////////////////////////////////////////
//HRESULT CDispClient::ConnectResource(), implements IDispClient::ConnectResource()
//
//DESCRIPTION:
//Method for connecting a resource by calling RD.
//
//
STDMETHODIMP CDispClient::ConnectResource(BSTR sAddress, long* lResourceID)
{
	HRESULT hr;

	*lResourceID = NULL;

	//call resource dispenser to get ResourceID
	if (m_ResourceDisp)
	{
		hr = m_ResourceDisp->Connect(sAddress, &m_ResourceID);

		if (SUCCEEDED(hr))
		{
			*lResourceID = m_ResourceID;
			ATLTRACE(_T("ResourceDisp.Connect returned handle\n"));
		}
		else
		{
			ATLTRACE(_T("ResourceDisp.Connect failed.\n"));
		};
	}
	else
	{
		return S_FALSE;
	};

	return hr;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
//HRESULT CDispClient::ResourceDisconnect(), implements IDispClient::ResourceDisconnect()
//
//DESCRIPTION:
//Method for disconnecting a resource by calling RD and commiting the changes.
//
STDMETHODIMP CDispClient::ResourceDisconnect(long lResourceID)
{
	HRESULT hr;
	IObjectContext* pObjectContext = NULL;

	//call resource dispenser
	if ( m_ResourceDisp )
	{
		hr = m_ResourceDisp->Disconnect(lResourceID);

		if (SUCCEEDED(hr))
		{
			ATLTRACE(_T("ResourceDisp Connect returned handle\n"));
		}
		else
		{
			ATLTRACE(_T("ResourceDisp Connect failed.\n"));
		};
	}
	else
	{
		return S_FALSE;
	};

	//Happy: ready to commit now
	hr = GetObjectContext(&pObjectContext);

	if (SUCCEEDED(hr))
	{
		pObjectContext->SetComplete();
		pObjectContext->Release();
	};

	return hr;
}