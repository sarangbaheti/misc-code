///////////////////////////////////////////////////////////////////////////////////////////////////
// RDisp.h : Declaration of the CRDisp
//
//DESCRIPTON
//Declaration of C++ resource dispenser class. Implements IIDispenserDriver,
//IRDisp, and IRDispAdmin interfaces.
//
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __RDISP_H_
#define __RDISP_H_

// disable warning C4786: symbol greater than 255 characters
#pragma warning(disable: 4786)

#include "StdAfx.h"
#include "resource.h"       // main symbols
#include <map>
#include <fstream>
using namespace std;

#include "..\include\mtxdm.h"


//create a map of ResourceIDs and their status
typedef map<long, bool> ResourceMap;


//interface IDispenserDriver;
//interface IHolder;

//utility for releasing pointers
#define SafeRelease(pUnk) {if (pUnk){pUnk -> Release();pUnk = NULL; }}

// CRDisp
class ATL_NO_VTABLE CRDisp : 
	public IDispenserDriver,
	public IRDisp,
	public IRDispAdmin,
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CRDisp, &CLSID_CoRDisp>
{
private:
	//data members
	IHolder * m_pHolder;
	IDispenserManager * m_pDispMan;
	IUnknown* m_pUnkMarshaler;
	ofstream m_fLog;
	long m_lResourceTimeout;

	//critical sections:
	//used to serialize access to instance data, namely ResourceMap
	CComAutoCriticalSection m_CS;

	//Set containing all resources
	ResourceMap m_ResourceMap;

public:
	const static RESTYPID m_DefaultResourceTypeID;
	const static long m_lDefaultTimeout;

//must be sigleton
DECLARE_CLASSFACTORY_SINGLETON(CRDisp);
DECLARE_PROTECT_FINAL_CONSTRUCT();
DECLARE_REGISTRY_RESOURCEID(IDR_RDISP);
DECLARE_NOT_AGGREGATABLE(CRDisp);

	//const/dest
	CRDisp();
	~CRDisp();
	HRESULT FinalConstruct();
	void FinalRelease();

//COM interface map
BEGIN_COM_MAP(CRDisp)
	COM_INTERFACE_ENTRY(IRDisp)
	COM_INTERFACE_ENTRY(IRDispAdmin)
	COM_INTERFACE_ENTRY(IDispenserDriver)
	COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler)
END_COM_MAP()

	//IRDisp
	STDMETHODIMP Connect(BSTR strConnectInfo, long* lResourceID);
	STDMETHODIMP Disconnect(long lResourceID);
	STDMETHODIMP ScheduleJob(long lResourceID, long lJobID);
	STDMETHODIMP CancelJob(long lResourceID, long lJobID);

	//IRDispAdmin
	STDMETHODIMP DestroyInactive(void);
	STDMETHODIMP SetTimeout(long lTimeout);
	STDMETHODIMP GetInventoryStatus( long* lSize, long* lInUse);

	//IDipenserDriver
	STDMETHODIMP CreateResource(const RESTYPID ResourceTypeID,
							    RESID* pResourceID,
							    TIMEINSECS* pSecsFreeBeforeDestroy);

	STDMETHODIMP RateResource(const RESTYPID ResourceTypeID,
							  const RESID ResourceID,
							  const BOOL fRequiresTransactionEnlistment,
							  RESOURCERATING* pRating);

	STDMETHODIMP EnlistResource(const RESID ResourceID, const TRANSID TransID);
	STDMETHODIMP ResetResource(const RESID ResourceID);
	STDMETHODIMP DestroyResource(const RESID ResourceID);
	STDMETHODIMP DestroyResourceS(const SRESID sResourceID);
};

#endif //__RDISP_H_