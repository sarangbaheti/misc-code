///////////////////////////////////////////////////////////////////////////////////////////////////
//RM.cpp - DLL exports
//
//DESCRIPTION
//This file contains template for implementing resource manager for
//hypothetical job scheduling system. The implementation details of how RM
//actually obtains connections and performs specific tasks are omitted.
//
///////////////////////////////////////////////////////////////////////////////////////////////////

// disable warning C4786: symbol greater than 255 characters
#pragma warning(disable: 4786)

#include "windows.h"
#include <fstream>
#include <cstdlib>
#include <ctime>

using namespace std;

#include "..\include\RM.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
//BOOL WINAPI DllMain(...)
//
//DESCRIPTION
//DLL main Entry Point.
//
//
extern "C"
BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	if (dwReason == DLL_PROCESS_ATTACH)
	{
		//no-op
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		//no-op
	};

	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
//bool RM_Connect(...)
//
//DESCRIPTION
//Creates a new connection and returns the handle to it.
//
//
extern "C"
bool RM_Connect(const char* szConnectionInfo, long* lConnectionHandle)
{
	//
	//Add your resoure manager code for creating
	//connections here.
	//

	//To fake the Res. ID - simply return random number
	//Nobody above the RM knows what this value exactly is anyway.
	//It is used only as opaque handle.
	srand((unsigned)time(NULL));
	*lConnectionHandle = rand();

	return true;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
//BOOL RM_Disconnect(...)
//
//DESCRIPTION
//Disconnects the connection.
//
//
extern "C"
bool RM_Disconnect(const long lConnectionHandle)
{
	//
	//Add your resoure manager code for closing
	//connections here.
	//

	return true;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
//BOOL RM_ResetConnection(...)
//
//DESCRIPTION
//Resets the active connection.
//
//
extern "C"
bool RM_ResetConnection(const long lConnectionHandle)
{
	//
	//Add your resoure manager code for resetting
	//connections here. The RM would typically maintain a
	//list of open connections. The RM would then locate the
	//conection in the list and make sure that all instance data
	//is released and tasks are terminated.
	//

	return true;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
//bool RM_ScheduleJob(...)
//
//DESCRIPTION
//Schedules a new job.
//
//
extern "C"
bool RM_ScheduleJob(const long lResourceID, const long lJobID)
{
	//
	//Add implementation code that would schedule job using given connection.
	//

	return true;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
//bool RM_Disconnect(...)
//
//DESCRIPTION
//Cancels existing job for a given resource.
//
//
extern "C"
bool RM_CancelJob(const long lResourceID, const long lJobID)
{

	//
	//Add implementation code that would attempt to cancel lJobID.
	//

	return true;
}