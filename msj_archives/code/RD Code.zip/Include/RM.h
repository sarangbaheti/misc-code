/////////////////////////////////////////////////////////////////////////////
//RM.h
//
//DESCRIPTION
//Definition of RM interface.
//

#ifndef RM_H
#define RM_H

extern "C"
{
	bool RM_Connect(const char* szConnectionInfo, long* lConnectionHandle);
	bool RM_Disconnect(const long lConnectionHandle);
	bool RM_ResetConnection(const long lConnectionHandle);
	bool RM_ScheduleJob(const long lResourceID, const long lJobID);
	bool RM_CancelJob(const long lResourceID, const long lJobID);
}

#endif