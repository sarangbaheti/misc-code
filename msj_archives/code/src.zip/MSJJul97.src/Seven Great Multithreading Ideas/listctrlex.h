// ListCtrlEx.h : interface of the CListCtrlEx class
//

#ifndef LISTCTRLEX_H
#define LISTCTRLEX_H

class CPageBase;

class CListCtrlEx : public CListCtrl
{
	DECLARE_DYNCREATE(CListCtrlEx)

// Construction
public:
	CListCtrlEx():m_bFullRowSel(TRUE), m_pOwner(NULL) {}

// Attributes
protected:
	BOOL m_bFullRowSel;
	CPageBase* m_pOwner;

// Functions
public:
	BOOL SetFullRowSel();
	void SetOwner(CPageBase* pOwner) {m_pOwner = pOwner;}

// Overrides
protected:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CListCtrlEx)
	public:
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
#ifdef _DEBUG
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	void RepaintSelectedItems();

// Implementation - list view colors
//	COLORREF m_clrText;
//	COLORREF m_clrTextBk;
//	COLORREF m_clrBkgnd;

// Generated message map functions
protected:
	//{{AFX_MSG(CListCtrlEx)
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif