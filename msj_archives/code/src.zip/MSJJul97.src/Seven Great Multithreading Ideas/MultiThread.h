// MultiThread.h : header file
// Copyright (C) 1997 by The Windward Group, All Rights Reserved

#ifndef MULTITHREAD_H
#define MULTITHREAD_H

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include <afxmt.h>

/////////////////////////////////////////////////////////////////////////////
class CMultiThread : public CWinThread
{
DECLARE_DYNCREATE(CMultiThread)
public:
	CMultiThread();
	virtual ~CMultiThread();

	BOOL CreateThread(DWORD dwCreateFlags = 0,	// masks CWinThread::CreateThread
				   UINT nStackSize = 0,
				   LPSECURITY_ATTRIBUTES lpSecurityAttrs = NULL,
				   UINT nMilliSecs = INFINITE); // upper time limit to wait

	BOOL InitInstance() {return TRUE;}
	void KillThread2();
	int Run();

protected:
	CEvent*		m_pWorkEvent;	// do work event
	CEvent*		m_pExitEvent;	// used to synchronize destruction
	int			m_nCycleTime;	// do work cycle time
	BOOL		m_bEndThread;	// end the thread ?

	virtual void StartWork() {}	// override to do startup
	virtual void DoWork() {}	// override to do work
	virtual void EndWork() {}	// override to do shutdown

	CEvent* GetEvent() const {return m_pWorkEvent;}	// cycle control event
	int GetCycleTime() const {return m_nCycleTime;}
	void SetCycleTime(int nMilliSecs) {m_nCycleTime = nMilliSecs;}
};
#endif
