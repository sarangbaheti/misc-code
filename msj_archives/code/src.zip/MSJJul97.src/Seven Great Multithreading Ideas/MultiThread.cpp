// MultiThread.cpp : implementation file
// Copyright (C) 1997 by The Windward Group, All Rights Reserved

#include "stdafx.h"
#include "MultiThread.h"

IMPLEMENT_DYNCREATE(CMultiThread, CWinThread)

/////////////////////////////////////////////////////////////////////////////
// CMultiThread

CMultiThread::CMultiThread()
{
	// Create a non-signaled, manual-reset event to synchronize destruction
	m_pExitEvent = new CEvent(FALSE, TRUE);
	ASSERT(m_pExitEvent);

	// Create a non-signaled, auto-reset event to wait on for work cycle
	m_pWorkEvent = new CEvent();
	ASSERT(m_pWorkEvent);
}

CMultiThread::~CMultiThread()
{
	delete m_pWorkEvent;
	delete m_pExitEvent;
}

BOOL CMultiThread::CreateThread(DWORD dwCreateFlags, UINT nStackSize, 
						   LPSECURITY_ATTRIBUTES lpSecurityAttrs, 
						   UINT nMilliSecs)
{
	m_nCycleTime = nMilliSecs;
	m_bEndThread = FALSE;

	// Start second thread
	return CWinThread::CreateThread(dwCreateFlags, nStackSize, lpSecurityAttrs);
}

void CMultiThread::KillThread2()
{
	// Start up the other thread so it can complete.
	// When it does, it will set the exit event and the object can be destructed.
	m_bEndThread = TRUE;
	m_pWorkEvent->SetEvent();
	CSingleLock csl(m_pExitEvent);
	csl.Lock();						// wait for 2nd thread to finish
	csl.Unlock();						
}

int CMultiThread::Run()
{
	CSingleLock csl(m_pWorkEvent);	// synch on the work event
	StartWork();																		// do derived startup
	while (!m_bEndThread)			// loop until we're done
	{
		csl.Lock(m_nCycleTime);		// wait for event or timeout
		csl.Unlock();			
		if (!m_bEndThread) DoWork();// and then do some work
	}

	EndWork();																		// do derived shutdown
	m_pExitEvent->SetEvent();		// set not waiting signal
	AfxEndThread(0, FALSE);			// end the thread, but do not delete it
	return 0;
}
