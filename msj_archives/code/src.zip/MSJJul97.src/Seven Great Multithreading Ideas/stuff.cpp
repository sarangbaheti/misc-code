// launch a Winscore app
CString CPageBase::LaunchApp(const CString& csAppName, const CString& csOpUnit, HCURSOR hCursor)
{
	CString csRet = "";
	CParamFile file;
	SOutputStrings strOut;

	if (csAppName.GetLength() && SetParameters(&file, csOpUnit))
	{
		STARTUPINFO si;
		PROCESS_INFORMATION pi;

		si.cb			= sizeof(STARTUPINFO);
		si.lpReserved	= NULL;
		si.lpDesktop	= NULL;
		si.lpTitle		= NULL;
		si.dwFlags		= 0;
		si.cbReserved2	= 0;
		si.lpReserved2	= NULL;

		if (CreateProcess(NULL,
				(LPTSTR)(LPCTSTR)(csAppName + CString(" ") + file.GetName()),
				NULL, NULL,	TRUE, CREATE_NEW_CONSOLE, NULL, NULL, &si, &pi))
		{
			Sleep(3000);	// to show launch cursor
			SetCursor(hCursor);

			if (WaitForSingleObject(pi.hProcess, INFINITE) != WAIT_FAILED)
			{
				CloseHandle(pi.hThread);
				CloseHandle(pi.hProcess);
				file.GetOutputStrings(strOut);
				strOut.csStatus.MakeLower();
				if (strOut.csStatus == fpvSuccess)
					csRet = CParamFile::Code2String(strOut.csRet1);
			}
		}
		else SetCursor(hCursor);
	}

	Sleep(1000);			// to wait for completion of file usage
	CKeyValues key;
	if (key.GetRemoveParamFile()) file.Remove();
	return csRet;
}

// launch completion handler
void CPageBase::LaunchDone(const CString& csAppName, LPARAM lParam)
{
	if (csAppName.GetLength()) AfxMessageBox(pLaunchText + csAppName);
	delete (reinterpret_cast<CLaunchThread*> (lParam));
}

void CUpdatesPage::OnBegin() 
{
	HCURSOR hCursorOld = SetCursor(AfxGetApp()->LoadCursor(IDC_PLEASEWAIT));

	// get selected OpUnit
	int row = m_lcOpUnitInfo.GetNextItem(-1, LVNI_ALL | LVNI_SELECTED);
	if (row > -1)
	{
		CString csOpUnit = m_lcOpUnitInfo.GetItemText(row, UC_ORGTP);
		csOpUnit += ",";
		csOpUnit += m_lcOpUnitInfo.GetItemText(row, UC_STRUCTUREELEMENT);
		csOpUnit += ",";
		csOpUnit += m_lcOpUnitInfo.GetItemText(row, UC_OPUNIT);

		// launch the app
		m_iLaunchCount++;
		CLaunchThread* pThread = new CLaunchThread;
		pThread->Set(GetSafeHwnd(), m_lcOpUnitInfo.GetSafeHwnd(), hCursorOld, 
 				 pLaunchName, csOpUnit);
		pThread->Go();
		m_lcOpUnitInfo.SetFocus();
	}
}

BOOL CUpdatesPage::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	if (wParam > 1)
	{					// message not sent by CLaunchThread
		CPropertyPage::OnCommand(wParam, lParam);
		return 0;
	}
						// message sent by CLaunchThread
	LaunchDone(!wParam ? pLaunchName : "", lParam);
	m_iLaunchCount--;
	m_lcOpUnitInfo.SetFocus();
	return CPropertyPage::OnCommand(0, lParam);
}

BOOL CSpcsView::CheckThreads() 
{
	BOOL bRet = TRUE;

	CRefreshThread* pThread1 = m_pPropSheet->GetStatusPage()->GetThread();
	CRefreshThread* pThread2 = m_pPropSheet->GetOfflinePage()->GetThread();

	if (pThread1->IsBusy() || pThread2->IsBusy() || 
		 m_pPropSheet->GetUpdatesPage()->IsLaunchActive() ||
		 m_pPropSheet->GetBrowserPage()->IsLaunchActive() || 
 		 m_pPropSheet->GetReaderPage()->IsLaunchActive()) bRet = FALSE;
	return bRet;
}
