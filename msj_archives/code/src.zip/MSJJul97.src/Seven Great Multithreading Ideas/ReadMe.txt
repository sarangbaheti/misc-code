These files contain the code from my article in MSJ. All code shown in the article 
is included, along with several additional files needed for compilation. This code 
is a small subset of files included in a large project. Several included files 
contain only part of a complete class. The examples will not link unless some
additional code is supplied.

All the included code was developed by The Windward Group. A number of the examples 
were developed for CTB/McGraw-Hill. Please observe the copyright notices in each file. 
This requires you, the reader, to recognize the owner of any code you use. You can use
these files, but you must leave the original copyright notice intact.
