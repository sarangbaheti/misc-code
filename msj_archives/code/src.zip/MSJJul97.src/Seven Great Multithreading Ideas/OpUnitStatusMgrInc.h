// OpUnitStatusMgrInc.h : header file (subset)
// Copyright (C) 1997 by CTB/McGraw-Hill, All Rights Reserved

#ifndef OPUNITSTATUSMGRINC_H
#define OPUNITSTATUSMGRINC_H


class COpUnitStatusRecord;
typedef COpUnitStatusRecord OUStatRec;

class COpUnitRecordSet
{
public:
	COpUnitRecordSet() {}

	// Information
	virtual int GetRecordCount(void) const = 0;

	// Iteration (creating a record on the fly)
	virtual OUStatRec* GetFirstRecord(void) = 0;
	virtual OUStatRec* GetNextRecord(void) = 0;
	virtual OUStatRec* GetPreviousRecord(void) = 0;
	virtual OUStatRec* GetLastRecord(void) = 0;

	// Iteration (requiring the client to have a created a record already)
	virtual BOOL GetFirstRecord(int nRowID, CListCtrl* pListCtrl) = 0;
	virtual BOOL GetNextRecord(int nRowID, CListCtrl* pListCtrl) = 0;
	virtual BOOL GetPreviousRecord(int nRowID, CListCtrl* pListCtrl) = 0;
	virtual BOOL GetLastRecord(int nRowID, CListCtrl* pListCtrl) = 0;

protected:
	virtual ~COpUnitRecordSet() {}
};
typedef COpUnitRecordSet OURecSet;


class COpUnitStatusMgr
{
public:
	enum Table
	{
		TABLE_ACTIVE = 0,
		TABLE_HISTORY,
		TABLE_ARCHIVED,
		TABLE_INCOMING,
	};

	COpUnitStatusMgr() {}
	virtual OURecSet* GetAllOrderedRecords(Table eTable, const CUIntArray& cuiaSortBy, CString& sFilter, BOOL bOnlyErrors=FALSE, BOOL bWantSGL=FALSE) const = 0;

protected:
	virtual ~COpUnitStatusMgr() {}
};

namespace OpUnitStatusRecordSQLParts
{
};

class CSPCSFactory
{
public:
	void ReleaseOpUnitStatusRecordSet(COpUnitRecordSet* pSet);
};

#endif