// JobMgrImp.cpp : implementation file (subset)
// Copyright (C) 1997 by CTB/McGraw-Hill, All Rights Reserved

/////////////////////////////////////////////////////////////////////////////
// internal thread step methods
/////////////////////////////////////////////////////////////////////////////
// do the operation
BOOL CJobMgrImp::DoTheOp()
{
	BOOL bRet = FALSE;

	if (SetParameters())		// set values in the shared parameter file
	{
		if (m_OpVals.bLocalOp)
		{	// local operations
			if (m_LocalOp.DoFunction(m_csIOFile))
			{	if (GetParameters()) bRet = TRUE;}
			else m_csError = errCreateProc;
		}

		else if (m_OpVals.csOp.GetLength())
		{						// other operations
			STARTUPINFO si;
			PROCESS_INFORMATION pi;

			si.cb			= sizeof(STARTUPINFO);
			si.lpReserved	= NULL;
			si.lpDesktop	= NULL;
			si.lpTitle		= NULL;
			si.dwFlags		= 0;
			si.cbReserved2	= 0;
			si.lpReserved2	= NULL;

			if (CreateProcess(NULL,
				(LPTSTR)(LPCTSTR)(m_OpVals.csOp + CString(" ") + m_csIOFile),
				NULL, NULL,	TRUE, CREATE_NEW_CONSOLE, NULL, NULL, &si, &pi))
			{
				if (WaitForSingleObject(pi.hProcess, INFINITE) != WAIT_FAILED)
				{
					if (GetParameters())
						bRet = TRUE;

					CloseHandle(pi.hThread);
					CloseHandle(pi.hProcess);
				}
				else m_csError = errWaitProc;
			}
			else m_csError = errCreateProc;
		}
		else bRet = TRUE;		// no operation
	}
	else m_csError = errParamFile;

	TraceWork();
	return bRet;
}
