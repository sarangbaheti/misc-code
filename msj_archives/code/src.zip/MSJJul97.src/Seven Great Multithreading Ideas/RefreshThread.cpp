// RefreshThread.cpp : implementation file
// Copyright (C) 1997 by CTB/McGraw-Hill, All Rights Reserved

#include "stdafx.h"
#include "RefreshThread.h"

/////////////////////////////////////////////////////////////////////////////
// CRefreshThread

void CRefreshThread::Set(HWND hActive, HWND hHistory, const CString& csFilter, 					 const CUIntArray& sortFields, BOOL bActive)
{
	m_hwndActive = hActive;
	m_hwndHistory = hHistory;
	m_csFilter = csFilter;
	m_bActiveTable = bActive;
	m_nRecord = 0;

	int size = sortFields.GetSize();
	m_cuiaSortFields.SetSize(size);
	for (int i = 0; i < size; i++)
		m_cuiaSortFields.SetAt(i, sortFields.GetAt(i));
}

BOOL CRefreshThread::Go()
{
	// kick off CThinThread with no loop delay
	return CreateThread(0, 0, NULL, 0);
}

void CRefreshThread::StartWork()
{
	// setup the listctrls
	m_LCActive.Attach(m_hwndActive);
	m_LCHistory.Attach(m_hwndHistory);

	m_LCActive.DeleteAllItems();
	m_LCHistory.DeleteAllItems();

	m_pRecSet = m_pStatMgr->GetAllOrderedRecords((m_bActiveTable ? 
		COpUnitStatusMgr::TABLE_ACTIVE : COpUnitStatusMgr::TABLE_ARCHIVED),
		m_cuiaSortFields, m_csFilter, FALSE, TRUE);

	// prepare the list control to consume mass quantities
	m_LCActive.SetItemCount(m_pRecSet->GetRecordCount());

	// insert the data from first database record directly into the list control
	if (m_pRecSet && m_pRecSet->GetFirstRecord(m_nRecord++, &m_LCActive));
	else m_bEndThread = TRUE;
}

void CRefreshThread::DoWork()
{
	if (!m_pRecSet->GetNextRecord(m_nRecord++, &m_LCActive))
		m_bEndThread = TRUE;
}

void CRefreshThread::EndWork()
{
	// release the record set
	m_pSPCSFactory->ReleaseOpUnitStatusRecordSet(m_pRecSet);

	// select first, repaint, and set focus
	SelectFirstItem(m_LCActive);
	UpdatesCompleted(m_LCActive, m_LCHistory);

	// cleanup the listctrls
	m_LCActive.Detach();
	m_LCHistory.Detach();
}
