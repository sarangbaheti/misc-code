// PageBase.h : header file (subset)
// Copyright (C) 1997 by CTB/McGraw-Hill, All Rights Reserved

#ifndef PAGEBASE_H
#define PAGEBASE_H

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include <afxmt.h>
#include "ListCtrlEx.h"
#include "OpUnitStatusMgrInc.h"

class CParamFile;

class CPageBase
{
public:
	CPageBase();
	virtual ~CPageBase();

protected:
	CSPCSFactory* m_pSPCSFactory;
	COpUnitStatusMgr* m_pStatMgr;

	CString LaunchApp(const CString& csApp, const CString& csOpUnit, HCURSOR hCursor);
	BOOL SetParameters(CParamFile* pFile, const CString& csOpUnit, LPCSTR pFunction=NULL);
	BOOL SetActiveState(const CString& csState, const CString& csOpUnit, int nEligibility=0);
	BOOL SetOUError(const CString& csOpUnit, int iError = 99);
	void LaunchDone(const CString& csAppName, LPARAM lParam);
	void BeginClientApp(HWND hWndSafe, CListCtrlEx& lcList, const CString& sAppName);
	virtual void SelectFirstItem(CListCtrlEx& lcSelect) const;
	void SelectItemRow(CListCtrlEx& lcSelect, int iCol, const CString& csItem) const;
	virtual void UpdatesCompleted(CListCtrlEx& lcPrep1, CListCtrlEx& lcPrep2) const;
	virtual void UpdatesCompleted(CListCtrlEx& lcPrep1) const;
};
#endif