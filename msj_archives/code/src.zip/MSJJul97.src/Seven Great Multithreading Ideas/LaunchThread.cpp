// LaunchThread.cpp : implementation file
// Copyright (C) 1997 by CTB/McGraw-Hill, All Rights Reserved

#include "stdafx.h"
#include "LaunchThread.h"

/////////////////////////////////////////////////////////////////////////////
// CLaunchThread

void CLaunchThread::Set(HWND hParent, HWND hList,  HCURSOR hc, const CString& csLaunchee, const CString& csOpUnit)
{
	m_hwndParent = hParent;
	m_hwndList = hList;
	m_hCursor = hc;
	m_csLaunchee = csLaunchee;
	m_csOpUnit = csOpUnit;
}

BOOL CLaunchThread::Go()
{
	// kick off CThinThread with no loop delay
	return CreateThread(0, 0, NULL, 0);
}

void CLaunchThread::DoWork()
{
	CString csResult = LaunchApp(m_csLaunchee, m_csOpUnit, m_hCursor);

	if (csResult.GetLength())
	{
		SetActiveState(csResult, m_csOpUnit);
		CListCtrlEx list;
		list.Attach(m_hwndList);
		SelectItemRow(list, 0, m_csOpUnit);
		list.Detach();
	}

	PostMessage(m_hwndParent, WM_COMMAND, (csResult.GetLength() ? 1 : 0), 
 			   reinterpret_cast<int> (this));
	m_bEndThread = TRUE;
}


