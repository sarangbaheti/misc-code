// HandlerThread.h : header file
// Copyright (C) 1997 by The Windward Group, All Rights Reserved

#ifndef HANDLERTHREAD_H
#define HANDLERTHREAD _H

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include <afxmt.h>
#include "ThinThread.h"

/////////////////////////////////////////////////////////////////////////////
class CRequestPacket : public CObject
{
public:
	int m_iPacketType;
	int m_iStatus;
	CString m_csInput;
	CString m_csOutput;
};

/////////////////////////////////////////////////////////////////////////////
class CRequestHandlerThread : public CThinThread
{
public:
	CRequestHandlerThread() {};
	virtual ~CRequestHandlerThread() {KillThread2();}

	void AddRequest(CRequestPacket* pPkt);
	BOOL Go() {return CreateThread(0, 0, NULL, 0);}
	void Set(HWND hParent, int ID);

protected:
	HWND m_hwndParent;
	int m_ID;
	CObList m_PktList;
	CCriticalSection m_CritSect;

	virtual void DoWork();		// do the work

	virtual void CheckInput() = 0;	// check packet input
	virtual void RetrieveData() = 0;	// get required data
	virtual void ProcessData() = 0;	// process the data
	virtual void UpdateState() = 0;	// update any state info
	virtual void LoadOutput() = 0; 	// load packet output
};
#endif
