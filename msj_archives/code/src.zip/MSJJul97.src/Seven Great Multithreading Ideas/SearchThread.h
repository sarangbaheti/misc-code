// SearchThread.h : header file
// Copyright (C) 1997 by The Windward Group, All Rights Reserved

#ifndef SEARCHTHREAD_H
#define SEARCHTHREAD_H

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include <afxmt.h>
#include "ThinThread.h"

/////////////////////////////////////////////////////////////////////////////
class CFileSearchThread : public CThinThread
{
public:
	CFileSearchThread() {};
	virtual ~CFileSearchThread() {KillThread2();}

	BOOL Go() {return CreateThread(0, 0, NULL, 0);}
	void Set(HWND hParent, int ID, const CString& csSearchRoot, 
			const CString& csSearchString);

protected:
	HWND m_hwndParent;
	int m_ID;
	CString m_csSearchRoot;
	CString m_csSearchString;

	virtual void DoWork();	// do the work
};
#endif
