// LaunchThread.h : header file
// Copyright (C) 1997 by CTB/McGraw-Hill, All Rights Reserved

#ifndef LAUNCHTHREAD_H
#define LAUNCHTHREAD_H

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include <afxmt.h>
#include "ThinThread.h"
#include "ListCtrlEx.h"
#include "OpUnitStatusMgrInc.h"
using namespace OpUnitStatusRecordSQLParts;
#include "PageBase.h"

/////////////////////////////////////////////////////////////////////////////
class CLaunchThread : public CThinThread, public CPageBase
{
public:
	CLaunchThread() {};
	virtual ~CLaunchThread(){KillThread2();}

	BOOL Go();
	void Set(HWND hParent, HWND hList, HCURSOR hc, const CString& csLaunchee, 
const CString& csOpUnit);

protected:
	HWND m_hwndParent;
	HWND m_hwndList;
	HCURSOR m_hCursor;
	CString m_csLaunchee;
	CString m_csOpUnit;
	CListCtrlEx m_LC;

	virtual void DoWork();	// do the work
};
#endif
