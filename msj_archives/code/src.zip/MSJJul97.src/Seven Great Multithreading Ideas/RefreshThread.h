// RefreshThread.h : header file
// Copyright (C) 1997 by CTB/McGraw-Hill, All Rights Reserved

#ifndef REFRESHTHREAD_H
#define REFRESHTHREAD_H

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include <afxmt.h>
#include "ThinThread.h"
#include "ListCtrlEx.h"
#include "OpUnitStatusMgrInc.h"
using namespace OpUnitStatusRecordSQLParts;
#include "PageBase.h"

/////////////////////////////////////////////////////////////////////////////
class CRefreshThread : public CThinThread, public CPageBase
{
public:
	CRefreshThread() {};
	virtual ~CRefreshThread() {KillThread2();}

	BOOL Go();
	void Set(HWND hActive, HWND hHistory, const CString& csFilter, const CUIntArray& sortFields, BOOL bActive=TRUE);

protected:
	HWND m_hwndActive;
	HWND m_hwndHistory;
	CString m_csFilter;
	CUIntArray m_cuiaSortFields;
	BOOL m_bActiveTable;
	CListCtrlEx m_LCActive;
	CListCtrlEx m_LCHistory;
	OURecSet* m_pRecSet;
	int m_nRecord;

	virtual void StartWork();	// start work
	virtual void DoWork();		// continue doing work
	virtual void EndWork();		// end work
};
#endif
