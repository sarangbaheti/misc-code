// HandlerThread.cpp : implementation file
// Copyright (C) 1997 by The Windward Group, All Rights Reserved

#include "stdafx.h"
#include "HandlerThread.h"

/////////////////////////////////////////////////////////////////////////////
// CRequestHandlerThread

void CRequestHandlerThread::Set(HWND hParent, int ID)
{
	m_hwndParent = hParent;
	m_ID = ID;
}
void CRequestHandlerThread::AddRequest(CRequestPacket* pPkt)
{
	CSingleLock csl(&m_CritSect);		// be safe
	csl.Lock();							// when accessing packet list
	m_PktList.AddTail(pPkt);			// put the packet on the list
	csl.Unlock();
	GetEvent()->SetEvent();				// notify internal thread
}

void CRequestHandlerThread::DoWork()
{
	while (!m_PktList.IsEmpty())		// get next packet
	{
		CSingleLock csl(&m_CritSect);	// be safe
		csl.Lock();						// when accessing packet list
		CRequestPacket* pPkt = dynamic_cast<CRequestPacket*> 									     (m_PktList.RemoveHead());
		csl.Unlock();
		
		CheckInput();
		RetrieveData();
		ProcessData();
		UpdateState();
		LoadOutput(); 
										// return packet to dispatcher
		PostMessage(m_hwndParent, WM_COMMAND, m_ID, reinterpret_cast<int> (pPkt));
	}
}
