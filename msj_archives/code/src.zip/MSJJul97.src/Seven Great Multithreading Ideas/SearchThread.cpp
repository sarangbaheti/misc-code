// SearchThread.cpp : implementation file
// Copyright (C) 1997 by The Windward Group, All Rights Reserved

#include "stdafx.h"
#include "SearchThread.h"
#include <direct.h>

/////////////////////////////////////////////////////////////////////////////
// CFileSearchThread

void CFileSearchThread::Set(HWND hParent, int ID, const CString& csSearchRoot, 
const CString& csSearchString)
{
	m_hwndParent = hParent;
	m_ID = ID;
	m_csSearchRoot = csSearchRoot;
	m_csSearchString = csSearchString;
}

void CFileSearchThread::DoWork()
{
	WIN32_FIND_DATA fd;

	_chdir(m_csSearchRoot);
	HANDLE hnd = FindFirstFile(m_csSearchString, &fd);
	if (hnd != INVALID_HANDLE_VALUE)
		PostMessage(m_hwndParent, WM_COMMAND, m_ID, reinterpret_cast<int> (this));
	m_bEndThread = TRUE;
}
