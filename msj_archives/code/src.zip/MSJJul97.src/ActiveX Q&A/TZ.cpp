////////////////////////////////////////////
//
// TZ.cpp - Copyright 1997, Don Box
//
// A multi-singleton implementation of ITimeOfDay
// that supports multiple time zones using composite 
// monikers.
//
// Usage: 
//   Dim tod as ITimeOfDay
//   Set tod = GetObject("clsid:8C54EFA2-B85F-11d0-8C3E-0080C73925BA:!Eastern")
//   MsgBox tod.GetCurrentTimeOfDay()
//


#define _WIN32_WINNT 0x402
#include <windows.h>
#include "TOD.h"
#include "TOD_i.c"
#include "TimeOfDay.h"

class TODClass : 
    public IOleItemContainer,
	public IExternalConnection,
    public ITimeOfDay
{
// this object supports four time zones
    TimeOfDay m_rgTimes[4];
public:
    TODClass(void) 
    {
// initialize the offsets to adjust for timezone shifts
        m_rgTimes[0].m_offset = 0;
        m_rgTimes[1].m_offset = 1/24.0;
        m_rgTimes[2].m_offset = 2/24.0;
        m_rgTimes[3].m_offset = 3/24.0;
    }

// IUnknown methods 
	STDMETHODIMP QueryInterface(REFIID riid, void ** ppv)
	{
        if (riid == IID_IUnknown || riid == IID_ITimeOfDay)
            *ppv = static_cast<ITimeOfDay*>(this);
        else if (riid == IID_IExternalConnection)
            *ppv = static_cast<IExternalConnection*>(this);
        else if (riid == IID_IParseDisplayName)
            *ppv = static_cast<IParseDisplayName*>(this);
        else if (riid == IID_IOleContainer)
            *ppv = static_cast<IOleContainer*>(this);
        else if (riid == IID_IOleItemContainer)
            *ppv = static_cast<IOleItemContainer*>(this);
        else
            return (*ppv = 0), E_NOINTERFACE;
        ((IUnknown*)*ppv)->AddRef();
        return S_OK;
    }
    STDMETHODIMP_(ULONG) AddRef(void) 
    { return 2;}
	STDMETHODIMP_(ULONG) Release(void)
    { return 1; }

// ITimeOfDay methods
	STDMETHODIMP GetCurrentTimeOfDay(DATE *pval)
    { 
// class object also implements ITimeOfDay (maps to 
// pacific time)
        return m_rgTimes[0].GetCurrentTimeOfDay(pval);
    }

// IExternalConnection methods
    STDMETHODIMP_(DWORD) AddConnection(DWORD extconn, DWORD) {
        extern void LockModule();// some module locking routine
        if (extconn&EXTCONN_STRONG) 
            LockModule(); 
        return 2;
    }
    STDMETHODIMP_(DWORD) ReleaseConnection(DWORD extconn, DWORD, BOOL) {
        extern void UnlockModule();// some module unlocking routine
        if (extconn&EXTCONN_STRONG) 
            UnlockModule();
        return 1;
    }

// IParseDisplayName methods
    STDMETHODIMP 
    ParseDisplayName( IBindCtx *pbc,
                      LPOLESTR pszDisplayName,
                      ULONG *pchEaten,
                      IMoniker **ppmkOut)
    {
// parse string as an item moniker, stripping off the leading "!"
        *pchEaten = wcslen(pszDisplayName);
        return CreateItemMoniker(OLESTR("!"), pszDisplayName + 1, ppmkOut);
    }

    // IOleContainer methods
    STDMETHODIMP 
    EnumObjects(DWORD grfFlags, IEnumUnknown **ppenum)
    {
        *ppenum = 0;
        return E_NOTIMPL;
    }


    STDMETHODIMP 
    LockContainer(BOOL fLock)
    {
        return E_NOTIMPL;
    }


    // IOleContainer methods
    STDMETHODIMP 
    GetObject(LPOLESTR pszItem, DWORD dwSpeedNeeded,
                           IBindCtx *pbc, REFIID riid, void **ppv)
    {

        if (_wcsicmp(pszItem, OLESTR("pacific")) == 0)
            return m_rgTimes[0].QueryInterface(riid, ppv);
        else if (_wcsicmp(pszItem, OLESTR("mountain")) == 0)
            return m_rgTimes[1].QueryInterface(riid, ppv);
        else if (_wcsicmp(pszItem, OLESTR("central")) == 0)
            return m_rgTimes[2].QueryInterface(riid, ppv);
        else if (_wcsicmp(pszItem, OLESTR("eastern")) == 0)
            return m_rgTimes[3].QueryInterface(riid, ppv);
        
        *ppv = 0;
        return MK_E_NOOBJECT;
    }

    STDMETHODIMP 
    GetObjectStorage(LPOLESTR pszItem, IBindCtx *pbc, REFIID riid, void **ppv)
    {
        *ppv = 0;
        return MK_E_NOSTORAGE;
    }

    STDMETHODIMP 
    IsRunning(LPOLESTR pszItem)
    {
        return E_NOTIMPL;
    }

};

HANDLE g_heventDone = CreateEvent(0, TRUE, FALSE, 0);
void LockModule()
{
    CoAddRefServerProcess();
}

void UnlockModule()
{
    if (CoReleaseServerProcess() == 0)
        SetEvent(g_heventDone);
}

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR szCmdParam, int)
{
    HRESULT hr = CoInitializeEx(0, COINIT_MULTITHREADED);
    if (FAILED(hr))
        return hr;
    if (strstr(szCmdParam, "/RegServer") == 0)
    {
        DWORD dwReg;
        TODClass todClassObject;
        hr = CoRegisterClassObject(CLSID_TimeOfDay,
                                   (IExternalConnection*)&todClassObject,
                                   CLSCTX_LOCAL_SERVER,
                                   REGCLS_MULTIPLEUSE,
                                   &dwReg);
        if (SUCCEEDED(hr))
        {
            WaitForSingleObject(g_heventDone, INFINITE);
            CoRevokeClassObject(dwReg);
        }
    }
    else
    {
// self-registration code
        char szFileName[MAX_PATH];
        GetModuleFileNameA(0, szFileName, MAX_PATH);
        OLECHAR wszFileName[MAX_PATH];
        mbstowcs(wszFileName, szFileName, MAX_PATH);
        ITypeLib *ptl = 0;
        hr = LoadTypeLib(wszFileName, &ptl);
        if (SUCCEEDED(hr))
        {
            hr = RegisterTypeLib(ptl, wszFileName, 0);
            ptl->Release();
        }
        RegSetValueA(HKEY_CLASSES_ROOT, "CLSID\\{8C54EFA2-B85F-11d0-8C3E-0080C73925BA}", REG_SZ, "TimeOfDay Object", 23);
        RegSetValueA(HKEY_CLASSES_ROOT, "CLSID\\{8C54EFA2-B85F-11d0-8C3E-0080C73925BA}\\LocalServer32", REG_SZ, szFileName, lstrlenA(szFileName));
    }
    CoUninitialize();
    return hr;
}
