////////////////////////////////////////////
//
// ATLColor.h - Copyright 1997, Don Box
//
// An ATL-based inplementation of IColor/IColorClass
//

#ifndef __COLOR_H_
#define __COLOR_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// Color
class Color : 
	public CComObjectRootEx<CComMultiThreadModelNoCS>,
	public IColor
{
BEGIN_COM_MAP(Color)
	COM_INTERFACE_ENTRY(IColor)
END_COM_MAP()
    short m_red; short m_green; short m_blue;
public:
// we need to explicitly lock/unlock module because CComObject<>
// will not work with classes that do not have default constructors

	Color(short r, short g, short b)
        : m_red(r), m_green(g), m_blue(b)
	{
		_Module.Lock();
	}

	~Color(void)
    {
		_Module.Unlock();
	}

// IUnknown methods (needed due to CComObject-incompatibility)
	STDMETHODIMP QueryInterface(REFIID iid, void ** ppvObject)
	{return _InternalQueryInterface(iid, ppvObject);}
    STDMETHODIMP_(ULONG) AddRef(void) 
    {return InternalAddRef();}
	STDMETHODIMP_(ULONG) Release(void){
		ULONG l = InternalRelease();
		if (l == 0)
			delete this;
		return l;
	}

// IColor methods
	STDMETHODIMP get_Red(/*[out, retval]*/ short *pval)
    { *pval = m_red; return S_OK; }
	STDMETHODIMP get_Green(/*[out, retval]*/ short *pval)
    { *pval = m_green; return S_OK; }
	STDMETHODIMP get_Blue(/*[out, retval]*/ short *pval)
    { *pval = m_blue; return S_OK; }
    
// ColorClass will act as the class object for our class
    class ColorClass : 
        public CComObjectRootEx<CComMultiThreadModelNoCS>,
        public IColorClass,
        public IExternalConnection
    {
    BEGIN_COM_MAP(ColorClass)
	    COM_INTERFACE_ENTRY(IColorClass)
	    COM_INTERFACE_ENTRY(IExternalConnection)
    END_COM_MAP()
    // IColorClass methods
        STDMETHODIMP CreateColor(short r, short g, short b,
                                  IColor **ppc) {
            if ((*ppc = new Color(r, g, b)) == 0)
                return E_OUTOFMEMORY;
            (*ppc)->AddRef();
            return S_OK;
        }

    // IExternalConnection methods
        STDMETHODIMP_(DWORD) AddConnection(DWORD extconn, DWORD) {
            if (extconn&EXTCONN_STRONG) _Module.Lock();
            return 2;
        }
        STDMETHODIMP_(DWORD) ReleaseConnection(DWORD extconn, DWORD, BOOL) {
            if (extconn&EXTCONN_STRONG) _Module.Unlock();
            return 1;
        }
    };
// make ColorClass our class object C++ class
DECLARE_CLASSFACTORY_EX(ColorClass)

DECLARE_REGISTRY_RESOURCEID(IDR_COLOR)
static const CLSID& WINAPI GetObjectCLSID() {return CLSID_Color;}
static LPCTSTR WINAPI GetObjectDescription() {return NULL;}
typedef CComFailCreator<E_FAIL>  _CreatorClass;
};

#endif //__COLOR_H_
