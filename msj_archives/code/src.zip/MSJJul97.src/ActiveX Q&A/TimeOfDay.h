////////////////////////////////////////////
//
// TimeOfDay.h - Copyright 1997, Don Box
//
// A singleton implementation of ITimeOfDay
//

#ifndef __TOD_H_
#define __TOD_H_

class TimeOfDay : 
    public ITimeOfDay,
	public IExternalConnection
{
public:
    double m_offset;

// IUnknown methods 
	STDMETHODIMP QueryInterface(REFIID riid, void **ppv)
	{
        if (riid == IID_IUnknown || riid == IID_ITimeOfDay)
            *ppv = static_cast<ITimeOfDay*>(this);
        else if (riid == IID_IExternalConnection)
            *ppv = static_cast<IExternalConnection*>(this);
        else
            return (*ppv = 0), E_NOINTERFACE;
        ((IUnknown*)*ppv)->AddRef();
        return S_OK;
    }
    STDMETHODIMP_(ULONG) AddRef(void) 
    { return 2;}
	STDMETHODIMP_(ULONG) Release(void)
    { return 1; }

// ITimeOfDay methods
	STDMETHODIMP GetCurrentTimeOfDay(DATE *pval)
    { 
        SYSTEMTIME st;
// convert system time to a date
        GetLocalTime(&st);
        SystemTimeToVariantTime(&st, pval);
// factor in timezone offsets
        *pval += m_offset;
        return S_OK;
    }

// IExternalConnection methods
    STDMETHODIMP_(DWORD) AddConnection(DWORD extconn, DWORD) {
        extern void LockModule();// some module locking routine
        if (extconn&EXTCONN_STRONG) 
            LockModule(); 
        return 2;
    }
    STDMETHODIMP_(DWORD) ReleaseConnection(DWORD extconn, DWORD, BOOL) {
        extern void UnlockModule();// some module unlocking routine
        if (extconn&EXTCONN_STRONG) 
            UnlockModule();
        return 1;
    }
};

#endif 
