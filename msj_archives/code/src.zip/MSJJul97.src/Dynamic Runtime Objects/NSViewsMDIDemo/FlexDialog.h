// This code is a part of the NanoSoft NSViews C++ Library.
// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "NSFlexDialog.h"

class CFlexDialog : public CNSFlexDialog
{
// Construction
public:
	CFlexDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFlexDialog)
	enum { IDD = IDD_DIALOG1 };
	CString	m_csCombo1;
	CString	m_csCombo2;
	CString	m_csCombo3;
	CString	m_csEdit1;
	CString	m_csList1;
	//}}AFX_DATA

	virtual BOOL OnApplyChanges(void* pSubject);
	virtual void SetSubject(void *pSubject);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFlexDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFlexDialog)
	afx_msg void OnButton1();
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeCombo1();
	afx_msg void OnEditchangeCombo2();
	afx_msg void OnSelchangeCombo2();
	afx_msg void OnEditchangeCombo3();
	afx_msg void OnSelchangeCombo3();
	afx_msg void OnChangeEdit1();
	afx_msg void OnSelchangeList1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
