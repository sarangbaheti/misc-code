// This code is a part of the NanoSoft NSViews C++ Library.
// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "NSFlexFormView.h"

class CFlexFormView : public CNSFlexFormView
{
protected:
	CFlexFormView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CFlexFormView)

// Form Data
public:
	//{{AFX_DATA(CFlexFormView)
	enum { IDD = IDD_FORM1 };
	CString	m_csEdit1;
	CString	m_csList1;
	CString	m_csCombo1;
	CString	m_csCombo2;
	CString	m_csCombo3;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFlexFormView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CFlexFormView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CFlexFormView)
	afx_msg void OnChangeEdit1();
	afx_msg void OnSelchangeCombo1();
	afx_msg void OnEditchangeCombo2();
	afx_msg void OnEditchangeCombo3();
	afx_msg void OnSelchangeList1();
	afx_msg void OnSelchangeCombo2();
	afx_msg void OnSelchangeCombo3();
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	void UpdateDocumentData();

};
