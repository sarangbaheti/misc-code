// This code is a part of the NanoSoft NSViews C++ Library.
// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "NSViewsDemo.h"
#include "FlexPropertyPage3.h"
#include "NSViewsDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CFlexPropertyPage3, CNSFlexPropertyPage)

BEGIN_MESSAGE_MAP(CFlexPropertyPage3, CNSFlexPropertyPage)
	//{{AFX_MSG_MAP(CFlexPropertyPage3)
	ON_BN_CLICKED(IDC_BUTTON_1, OnButton1)
	ON_CBN_SELCHANGE(IDC_COMBO_1, OnSelchangeCombo1)
	ON_CBN_EDITCHANGE(IDC_COMBO_2, OnEditchangeCombo2)
	ON_CBN_SELCHANGE(IDC_COMBO_2, OnSelchangeCombo2)
	ON_CBN_EDITCHANGE(IDC_COMBO_3, OnEditchangeCombo3)
	ON_CBN_SELCHANGE(IDC_COMBO_3, OnSelchangeCombo3)
	ON_EN_CHANGE(IDC_EDIT_1, OnChangeEdit1)
	ON_LBN_SELCHANGE(IDC_LIST_1, OnSelchangeList1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CFlexPropertyPage3::CFlexPropertyPage3() :
	CNSFlexPropertyPage(CFlexPropertyPage3::IDD)
{
	CNSFlexHorizontalConstraint FillLeftHalf    (0.0f,  0.5f);
	CNSFlexHorizontalConstraint CenterInLeftHalf(0.25f, 0.25f);
	CNSFlexHorizontalConstraint FillRightHalf   (0.5f,  1.0f);

	AddFlexConstraint(IDC_STATIC_5, FillLeftHalf, NSFlexExpandDown);
	AddFlexConstraint(IDC_LIST_1,   FillLeftHalf, NSFlexExpandDown); 
	AddFlexConstraint(IDC_BUTTON_1, CenterInLeftHalf, NSFlexShiftDown); 
	AddFlexConstraint(IDC_STATIC_1, FillRightHalf, NSFlexVerticallyFixed);
	AddFlexConstraint(IDC_COMBO_1,  FillRightHalf, NSFlexVerticallyFixed); 
	AddFlexConstraint(IDC_STATIC_2, FillRightHalf, NSFlexVerticallyFixed); 
	AddFlexConstraint(IDC_COMBO_2,  FillRightHalf, NSFlexExpandDown); 
	AddFlexConstraint(IDC_STATIC_3, FillRightHalf, NSFlexShiftDown); 
	AddFlexConstraint(IDC_COMBO_3,  FillRightHalf, NSFlexShiftDown); 
	AddFlexConstraint(IDC_STATIC_4, FillRightHalf, NSFlexShiftDown); 
	AddFlexConstraint(IDC_EDIT_1,   FillRightHalf, NSFlexShiftDown); 

	//{{AFX_DATA_INIT(CFlexPropertyPage3)
	m_csCombo1 = _T("");
	m_csCombo2 = _T("");
	m_csCombo3 = _T("");
	m_csEdit1 = _T("");
	m_csList1 = _T("");
	//}}AFX_DATA_INIT
}

CFlexPropertyPage3::~CFlexPropertyPage3()
{

}

void CFlexPropertyPage3::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFlexPropertyPage3)
	DDX_CBString(pDX, IDC_COMBO_1, m_csCombo1);
	DDX_CBString(pDX, IDC_COMBO_2, m_csCombo2);
	DDX_CBString(pDX, IDC_COMBO_3, m_csCombo3);
	DDX_Text(pDX, IDC_EDIT_1, m_csEdit1);
	DDX_LBString(pDX, IDC_LIST_1, m_csList1);
	//}}AFX_DATA_MAP
}

void CFlexPropertyPage3::OnButton1() 
{
	AfxMessageBox("Button pressed");
}

BOOL CFlexPropertyPage3::OnInitDialog() 
{
	CListBox* pList = (CListBox*)GetDlgItem(IDC_LIST_1);

	pList->AddString("CNSFlexConstraint");
	pList->AddString("CNSFlexConstraintList");
	pList->AddString("CNSFlexDialog");
	pList->AddString("CNSFlexFormView");
	pList->AddString("CNSFlexHorizontalConstraint");
	pList->AddString("CNSFlexMDIChildWnd");
	pList->AddString("CNSFlexPropertyPage");
	pList->AddString("CNSFlexPropertySheet");
	pList->AddString("CNSFlexPropertySheetView");
	pList->AddString("CNSFlexVerticalConstraint");

	CNSFlexPropertyPage::OnInitDialog();
	
	return TRUE;  
}

void CFlexPropertyPage3::UpdateDocumentData()
{
	CNSViewsDemoDoc* pDoc = (CNSViewsDemoDoc*)GetDocument();
	ASSERT(pDoc);

	pDoc->m_csEdit1 = m_csEdit1;
	pDoc->m_csList1 = m_csList1;
	pDoc->m_csCombo1 = m_csCombo1;
	pDoc->m_csCombo2 = m_csCombo2;
	pDoc->m_csCombo3 = m_csCombo3;
}

void CFlexPropertyPage3::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	CNSViewsDemoDoc* pDoc = (CNSViewsDemoDoc*)GetDocument();
	ASSERT(pDoc);

	m_csEdit1 = pDoc->m_csEdit1;
	m_csList1 = pDoc->m_csList1;
	m_csCombo1 = pDoc->m_csCombo1;
	m_csCombo2 = pDoc->m_csCombo2;
	m_csCombo3 = pDoc->m_csCombo3;

	UpdateData(FALSE);
}

void CFlexPropertyPage3::OnSelchangeCombo1() 
{
	CNSViewsDemoDoc*  pDoc = (CNSViewsDemoDoc*)GetDocument();
	UpdateData();
	UpdateDocumentData();
	pDoc->SetModifiedFlag();
	pDoc->UpdateAllViews(GetView());
}

void CFlexPropertyPage3::OnEditchangeCombo2() 
{
	CNSViewsDemoDoc*  pDoc = (CNSViewsDemoDoc*)GetDocument();
	UpdateData();
	UpdateDocumentData();
	pDoc->SetModifiedFlag();
	pDoc->UpdateAllViews(GetView());
}

void CFlexPropertyPage3::OnSelchangeCombo2() 
{
	CNSViewsDemoDoc*  pDoc = (CNSViewsDemoDoc*)GetDocument();

	// UpdateData(); Why doesn't this work? Try following...
	// begin workaround
	CString cs;
	CComboBox* pCombo = (CComboBox*)GetDlgItem(IDC_COMBO_2);
	pCombo->GetLBText(pCombo->GetCurSel(),cs);
	m_csCombo2 = cs;
	// end workaround

	UpdateDocumentData();
	pDoc->SetModifiedFlag();
	pDoc->UpdateAllViews(GetView());
}

void CFlexPropertyPage3::OnEditchangeCombo3() 
{
	CNSViewsDemoDoc*  pDoc = (CNSViewsDemoDoc*)GetDocument();
	UpdateData();
	UpdateDocumentData();
	pDoc->SetModifiedFlag();
	pDoc->UpdateAllViews(GetView());
}

void CFlexPropertyPage3::OnSelchangeCombo3() 
{
	CNSViewsDemoDoc*  pDoc = (CNSViewsDemoDoc*)GetDocument();

	// UpdateData(); Why doesn't this work? Try following...
	// begin workaround
	CString cs;
	CComboBox* pCombo = (CComboBox*)GetDlgItem(IDC_COMBO_3);
	pCombo->GetLBText(pCombo->GetCurSel(),cs);
	m_csCombo3 = cs;
	// end workaround

	UpdateDocumentData();
	pDoc->SetModifiedFlag();
	pDoc->UpdateAllViews(GetView());
}

void CFlexPropertyPage3::OnChangeEdit1() 
{
	CNSViewsDemoDoc*  pDoc = (CNSViewsDemoDoc*)GetDocument();
	UpdateData();
	UpdateDocumentData();
	pDoc->SetModifiedFlag();
	pDoc->UpdateAllViews(GetView());
}

void CFlexPropertyPage3::OnSelchangeList1() 
{
	CNSViewsDemoDoc*  pDoc = (CNSViewsDemoDoc*)GetDocument();
	UpdateData();
	UpdateDocumentData();
	pDoc->SetModifiedFlag();
	pDoc->UpdateAllViews(GetView());
}



