// This code is a part of the NanoSoft NSViews C++ Library.
// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "NSViewsDemo.h"
#include "FlexPropertyPage2.h"
#include "NSViewsDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CFlexPropertyPage2, CNSFlexPropertyPage)

BEGIN_MESSAGE_MAP(CFlexPropertyPage2, CNSFlexPropertyPage)
	//{{AFX_MSG_MAP(CFlexPropertyPage2)
	ON_EN_CHANGE(IDC_EDIT_1, OnChangeEdit1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CFlexPropertyPage2::CFlexPropertyPage2() :
	CNSFlexPropertyPage(CFlexPropertyPage2::IDD)
{
	AddFlexConstraint(IDC_EDIT_1, NSFlexExpandRight, NSFlexExpandDown);

	//{{AFX_DATA_INIT(CFlexPropertyPage2)
	m_csEdit1 = _T("");
	//}}AFX_DATA_INIT
}

CFlexPropertyPage2::~CFlexPropertyPage2()
{

}

void CFlexPropertyPage2::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFlexPropertyPage2)
	DDX_Text(pDX, IDC_EDIT_1, m_csEdit1);
	//}}AFX_DATA_MAP
}

void CFlexPropertyPage2::OnChangeEdit1() 
{
	SetModified();
}
