// This code is a part of the NanoSoft NSViews C++ Library.
// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "NSViewsDemo.h"
#include "FlexPropertyPage1.h"
#include "NSViewsDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Here is an example of a more complex constraint derived from one of
// the base constraints.
class CHorizontalFixToCenterOfConstraint : public CNSFlexHorizontalConstraint
{
  public:

	// Constructors.
	// Takes the id of a control that will be used later (in Init) to set
    // the values of m_fLeft and m_fRight.
	CHorizontalFixToCenterOfConstraint(UINT nIDofControlToCenterOn);
	CHorizontalFixToCenterOfConstraint(const CHorizontalFixToCenterOfConstraint& ref);

	const CHorizontalFixToCenterOfConstraint& operator=(
		CHorizontalFixToCenterOfConstraint& ref);

	// The "make a copy of me" virtual operation.
	// Must be overridden by derived types.
	virtual CNSFlexHorizontalConstraint* CopyMe() const;

	// Destructor.
	virtual ~CHorizontalFixToCenterOfConstraint();

	// Overridden to set the constraint values for derived types.
	virtual void Init(const CWnd* m_pContainer, int nWidth);
	
  private:
	
    UINT m_nIDofControlToCenterOn;
};


CHorizontalFixToCenterOfConstraint::CHorizontalFixToCenterOfConstraint(
	UINT nIDofControlToCenterOn) :
		CNSFlexHorizontalConstraint(0.0f, 0.0f),
        m_nIDofControlToCenterOn(nIDofControlToCenterOn)
{
}

CHorizontalFixToCenterOfConstraint::CHorizontalFixToCenterOfConstraint(
    const CHorizontalFixToCenterOfConstraint& ref) :
        CNSFlexHorizontalConstraint(ref)
{
    m_nIDofControlToCenterOn = ref.m_nIDofControlToCenterOn;
}

const CHorizontalFixToCenterOfConstraint&
    CHorizontalFixToCenterOfConstraint::operator=(
	    CHorizontalFixToCenterOfConstraint& ref)
{
    *((CNSFlexHorizontalConstraint*)this) =
        ref; // Take care of base class stuff
    m_nIDofControlToCenterOn = ref.m_nIDofControlToCenterOn;
	return(*this);
}

CNSFlexHorizontalConstraint* CHorizontalFixToCenterOfConstraint::CopyMe() const
{
	return new CHorizontalFixToCenterOfConstraint(*this);
}

CHorizontalFixToCenterOfConstraint::~CHorizontalFixToCenterOfConstraint()
{
}

void CHorizontalFixToCenterOfConstraint::Init(
	const CWnd* pContainerWnd, int nWidth)
{
    // Find the center of the control and use nWidth to compute
    // the values for m_fLeft and m_fRight so that the constrained control
    // will be attached to the center of our specified control.
    ASSERT(pContainerWnd);
    CWnd* pCenterOnWnd = pContainerWnd->GetDlgItem(m_nIDofControlToCenterOn);
    ASSERT(pCenterOnWnd);

    CRect rectCenterOnWnd;
	pCenterOnWnd->GetWindowRect(rectCenterOnWnd);
    pContainerWnd->ScreenToClient(rectCenterOnWnd);

    float fFixed = (float)(rectCenterOnWnd.TopLeft().x +
                           rectCenterOnWnd.BottomRight().x) / 2.0f;
    fFixed /= (float)nWidth;

    SetLeft(fFixed);
    SetRight(fFixed);
}

	
IMPLEMENT_DYNCREATE(CFlexPropertyPage1, CNSFlexPropertyPage)

BEGIN_MESSAGE_MAP(CFlexPropertyPage1, CNSFlexPropertyPage)
	//{{AFX_MSG_MAP(CFlexPropertyPage1)
	ON_BN_CLICKED(IDC_BUTTON_1, OnButton1)
	ON_CBN_SELCHANGE(IDC_COMBO_1, OnSelchangeCombo1)
	ON_CBN_EDITCHANGE(IDC_COMBO_2, OnEditchangeCombo2)
	ON_CBN_SELCHANGE(IDC_COMBO_2, OnSelchangeCombo2)
	ON_CBN_EDITCHANGE(IDC_COMBO_3, OnEditchangeCombo3)
	ON_CBN_SELCHANGE(IDC_COMBO_3, OnSelchangeCombo3)
	ON_EN_CHANGE(IDC_EDIT_1, OnChangeEdit1)
	ON_LBN_SELCHANGE(IDC_LIST_1, OnSelchangeList1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CFlexPropertyPage1::CFlexPropertyPage1() :
	CNSFlexPropertyPage(CFlexPropertyPage1::IDD)
{
	CNSFlexHorizontalConstraint FillLeftHalf    (0.0f,  0.5f);
//	CNSFlexHorizontalConstraint CenterInLeftHalf(0.25f, 0.25f);
    CHorizontalFixToCenterOfConstraint CenterOnList1(IDC_LIST_1);
	CNSFlexHorizontalConstraint FillRightHalf   (0.5f,  1.0f);

	AddFlexConstraint(IDC_STATIC_5, FillLeftHalf, NSFlexExpandDown);
	AddFlexConstraint(IDC_LIST_1,   FillLeftHalf, NSFlexExpandDown); 
//	AddFlexConstraint(IDC_BUTTON_1, CenterInLeftHalf, NSFlexShiftDown); 
	AddFlexConstraint(IDC_BUTTON_1, CenterOnList1, NSFlexShiftDown); 
	AddFlexConstraint(IDC_STATIC_1, FillRightHalf, NSFlexVerticallyFixed);
	AddFlexConstraint(IDC_COMBO_1,  FillRightHalf, NSFlexVerticallyFixed); 
	AddFlexConstraint(IDC_STATIC_2, FillRightHalf, NSFlexVerticallyFixed); 
	AddFlexConstraint(IDC_COMBO_2,  FillRightHalf, NSFlexExpandDown); 
	AddFlexConstraint(IDC_STATIC_3, FillRightHalf, NSFlexShiftDown); 
	AddFlexConstraint(IDC_COMBO_3,  FillRightHalf, NSFlexShiftDown); 
	AddFlexConstraint(IDC_STATIC_4, FillRightHalf, NSFlexShiftDown); 
	AddFlexConstraint(IDC_EDIT_1,   FillRightHalf, NSFlexShiftDown); 

	//{{AFX_DATA_INIT(CFlexPropertyPage1)
	m_csCombo1 = _T("");
	m_csCombo2 = _T("");
	m_csCombo3 = _T("");
	m_csEdit1 = _T("");
	m_csList1 = _T("");
	//}}AFX_DATA_INIT
}

CFlexPropertyPage1::~CFlexPropertyPage1()
{

}

void CFlexPropertyPage1::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFlexPropertyPage1)
	DDX_CBString(pDX, IDC_COMBO_1, m_csCombo1);
	DDX_CBString(pDX, IDC_COMBO_2, m_csCombo2);
	DDX_CBString(pDX, IDC_COMBO_3, m_csCombo3);
	DDX_Text(pDX, IDC_EDIT_1, m_csEdit1);
	DDX_LBString(pDX, IDC_LIST_1, m_csList1);
	//}}AFX_DATA_MAP
}

void CFlexPropertyPage1::OnButton1() 
{
	AfxMessageBox("Button pressed");
}

BOOL CFlexPropertyPage1::OnInitDialog() 
{
	CListBox* pList = (CListBox*)GetDlgItem(IDC_LIST_1);

	pList->AddString("CNSFlexConstraint");
	pList->AddString("CNSFlexConstraintList");
	pList->AddString("CNSFlexDialog");
	pList->AddString("CNSFlexFormView");
	pList->AddString("CNSFlexHorizontalConstraint");
	pList->AddString("CNSFlexMDIChildWnd");
	pList->AddString("CNSFlexPropertyPage");
	pList->AddString("CNSFlexPropertySheet");
	pList->AddString("CNSFlexPropertySheetView");
	pList->AddString("CNSFlexVerticalConstraint");

	CNSFlexPropertyPage::OnInitDialog();
	
	return TRUE;  
}

void CFlexPropertyPage1::OnSelchangeCombo1() 
{
	SetModified();
}

void CFlexPropertyPage1::OnEditchangeCombo2() 
{
	SetModified();
}

void CFlexPropertyPage1::OnSelchangeCombo2() 
{
	SetModified();
}

void CFlexPropertyPage1::OnEditchangeCombo3() 
{
	SetModified();
}

void CFlexPropertyPage1::OnSelchangeCombo3() 
{
	SetModified();
}

void CFlexPropertyPage1::OnChangeEdit1() 
{
	SetModified();
}

void CFlexPropertyPage1::OnSelchangeList1() 
{
	SetModified();
}



