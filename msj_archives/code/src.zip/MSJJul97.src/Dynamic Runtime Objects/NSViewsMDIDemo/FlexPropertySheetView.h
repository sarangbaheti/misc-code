// This code is a part of the NanoSoft NSViews C++ Library.
// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "NSFlexPropertySheetView.h"

#include "FlexPropertyPage3.h"
#include "FlexPropertyPage4.h"

class CFlexPropertySheetView : public CNSFlexPropertySheetView
{
protected:
	CFlexPropertySheetView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CFlexPropertySheetView)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFlexPropertySheetView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CFlexPropertySheetView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CFlexPropertySheetView)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:

	CFlexPropertyPage3 m_FlexPropertyPage3;
	CFlexPropertyPage4 m_FlexPropertyPage4;
};

/////////////////////////////////////////////////////////////////////////////
