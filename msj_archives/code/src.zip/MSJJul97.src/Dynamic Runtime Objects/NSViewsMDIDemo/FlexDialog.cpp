// This code is a part of the NanoSoft NSViews C++ Library.
// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "NSViewsDemo.h"
#include "FlexDialog.h"
#include "NSViewsDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BEGIN_MESSAGE_MAP(CFlexDialog, CNSFlexDialog)
	//{{AFX_MSG_MAP(CFlexDialog)
	ON_BN_CLICKED(IDC_BUTTON_1, OnButton1)
	ON_CBN_SELCHANGE(IDC_COMBO_1, OnSelchangeCombo1)
	ON_CBN_EDITCHANGE(IDC_COMBO_2, OnEditchangeCombo2)
	ON_CBN_SELCHANGE(IDC_COMBO_2, OnSelchangeCombo2)
	ON_CBN_EDITCHANGE(IDC_COMBO_3, OnEditchangeCombo3)
	ON_CBN_SELCHANGE(IDC_COMBO_3, OnSelchangeCombo3)
	ON_EN_CHANGE(IDC_EDIT_1, OnChangeEdit1)
	ON_LBN_SELCHANGE(IDC_LIST_1, OnSelchangeList1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CFlexDialog::CFlexDialog(CWnd* pParent /*=NULL*/)
	: CNSFlexDialog(CFlexDialog::IDD, pParent)
{
	CNSFlexHorizontalConstraint FillLeftHalf    (0.0f,  0.5f);
	CNSFlexHorizontalConstraint CenterInLeftHalf(0.25f, 0.25f);
	CNSFlexHorizontalConstraint FillRightHalf   (0.5f,  1.0f);

	AddFlexConstraint(IDC_STATIC_5, FillLeftHalf, NSFlexExpandDown);
	AddFlexConstraint(IDC_LIST_1,   FillLeftHalf, NSFlexExpandDown); 
	AddFlexConstraint(IDC_BUTTON_1, CenterInLeftHalf, NSFlexShiftDown); 
	AddFlexConstraint(IDC_STATIC_1, FillRightHalf, NSFlexVerticallyFixed);
	AddFlexConstraint(IDC_COMBO_1,  FillRightHalf, NSFlexVerticallyFixed); 
	AddFlexConstraint(IDC_STATIC_2, FillRightHalf, NSFlexVerticallyFixed); 
	AddFlexConstraint(IDC_COMBO_2,  FillRightHalf, NSFlexExpandDown); 
	AddFlexConstraint(IDC_STATIC_3, FillRightHalf, NSFlexShiftDown); 
	AddFlexConstraint(IDC_COMBO_3,  FillRightHalf, NSFlexShiftDown); 
	AddFlexConstraint(IDC_STATIC_4, FillRightHalf, NSFlexShiftDown); 
	AddFlexConstraint(IDC_EDIT_1,   FillRightHalf, NSFlexShiftDown); 

	AddFlexConstraint(IDOK,         NSFlexShiftRight, NSFlexShiftDown); 
	AddFlexConstraint(IDCANCEL,     NSFlexShiftRight, NSFlexShiftDown);
	AddFlexConstraint(ID_APPLY_NOW, NSFlexShiftRight, NSFlexShiftDown);

	//{{AFX_DATA_INIT(CFlexDialog)
	m_csCombo1 = _T("");
	m_csCombo2 = _T("");
	m_csCombo3 = _T("");
	m_csEdit1 = _T("");
	m_csList1 = _T("");
	//}}AFX_DATA_INIT
}

void CFlexDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFlexDialog)
	DDX_CBString(pDX, IDC_COMBO_1, m_csCombo1);
	DDX_CBString(pDX, IDC_COMBO_2, m_csCombo2);
	DDX_CBString(pDX, IDC_COMBO_3, m_csCombo3);
	DDX_Text(pDX, IDC_EDIT_1, m_csEdit1);
	DDX_LBString(pDX, IDC_LIST_1, m_csList1);
	//}}AFX_DATA_MAP
}

void CFlexDialog::OnButton1() 
{
	AfxMessageBox("Button pressed");
}

void CFlexDialog::SetSubject(void *pSubject)
{
	CNSFlexDialog::SetSubject(pSubject);

	CNSViewsDemoDoc* pDoc = (CNSViewsDemoDoc*)pSubject;

	m_csEdit1 = pDoc->m_csEdit1;
	m_csList1 = pDoc->m_csList1;
	m_csCombo1 = pDoc->m_csCombo1;
	m_csCombo2 = pDoc->m_csCombo2;
	m_csCombo3 = pDoc->m_csCombo3;
}

BOOL CFlexDialog::OnInitDialog() 
{
	CListBox* pList = (CListBox*)GetDlgItem(IDC_LIST_1);

	pList->AddString("CNSFlexConstraint");
	pList->AddString("CNSFlexConstraintList");
	pList->AddString("CNSFlexDialog");
	pList->AddString("CNSFlexFormView");
	pList->AddString("CNSFlexHorizontalConstraint");
	pList->AddString("CNSFlexMDIChildWnd");
	pList->AddString("CNSFlexPropertyPage");
	pList->AddString("CNSFlexPropertySheet");
	pList->AddString("CNSFlexPropertySheetView");
	pList->AddString("CNSFlexVerticalConstraint");

	CNSFlexDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CFlexDialog::OnApplyChanges(void* pSubject)
{
	CNSViewsDemoDoc* pDoc = (CNSViewsDemoDoc*)pSubject;

	pDoc->m_csEdit1 = m_csEdit1;
	pDoc->m_csList1 = m_csList1;
	pDoc->m_csCombo1 = m_csCombo1;
	pDoc->m_csCombo2 = m_csCombo2;
	pDoc->m_csCombo3 = m_csCombo3;

	pDoc->SetModifiedFlag();
	pDoc->UpdateAllViews(NULL);

	return TRUE;
}

void CFlexDialog::OnSelchangeCombo1() 
{
	SetModified();	
}

void CFlexDialog::OnEditchangeCombo2() 
{
	SetModified();	
}

void CFlexDialog::OnSelchangeCombo2() 
{
	SetModified();	
}

void CFlexDialog::OnEditchangeCombo3() 
{
	SetModified();	
}

void CFlexDialog::OnSelchangeCombo3() 
{
	SetModified();	
}

void CFlexDialog::OnChangeEdit1() 
{
	SetModified();	
}

void CFlexDialog::OnSelchangeList1() 
{
	SetModified();	
}
