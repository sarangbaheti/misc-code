// This code is a part of the NanoSoft NSViews C++ Library.
// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "nsviewsdemo.h"
#include "FlexPropertySheetView.h"
#include "FlexPropertySheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CFlexPropertySheetView, CNSFlexPropertySheetView)

BEGIN_MESSAGE_MAP(CFlexPropertySheetView, CNSFlexPropertySheetView)
	//{{AFX_MSG_MAP(CFlexPropertySheetView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CFlexPropertySheetView::CFlexPropertySheetView()
{
	GetFlexPropertySheet()->AddPage(&m_FlexPropertyPage3);
	GetFlexPropertySheet()->AddPage(&m_FlexPropertyPage4);
}

CFlexPropertySheetView::~CFlexPropertySheetView()
{

}

void CFlexPropertySheetView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

#ifdef _DEBUG

void CFlexPropertySheetView::AssertValid() const
{
	CView::AssertValid();
}

void CFlexPropertySheetView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

#endif //_DEBUG
