// This code is a part of the NanoSoft NSViews C++ Library.
// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "NSViewsDemo.h"
#include "NSViewsDemoDoc.h"
#include "FlexDialog.h"
#include "FlexPropertySheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CNSViewsDemoDoc, CDocument)

BEGIN_MESSAGE_MAP(CNSViewsDemoDoc, CDocument)
	//{{AFX_MSG_MAP(CNSViewsDemoDoc)
	ON_COMMAND(ID_DEMO_FLEXIBLE_DIALOG, OnDemoFlexibleDialog)
	ON_COMMAND(ID_DEMO_FLEXIBLE_FORM_VIEW, OnDemoFlexibleFormView)
	ON_COMMAND(ID_DEMO_FLEXIBLE_PROPERTY_SHEET, OnDemoFlexiblePropertySheet)
	ON_COMMAND(ID_DEMO_FLEXIBLE_PROPERTY_SHEET_VIEW, OnDemoFlexiblePropertySheetView)
	ON_COMMAND(ID_DEMO_INTRODUCTION, OnDemoIntroduction)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CNSViewsDemoDoc::CNSViewsDemoDoc()
{
	m_csIntroduction  = "Grab an edge or corner of the NSViews Introduction window and make it larger.  Notice how the controls are repositioned as the window is resized.  The Microsoft Foundation Class Library (MFC) doesn�t provide \"flexible\" dialogs and views with this kind of control repositioning behavior, but the NSViews C++ Library makes it a snap to include in your MFC application.";
	m_csIntroduction += "\r\n\r\n";
	m_csIntroduction += "The NSViews C++ Library is an MFC extension class library that provides support for four types of flexible modal dialogs and modeless views that incorporate control repositioning:  (1) Flexible Dialogs, (2) Flexible Property Sheets, (3) Flexible Form Views, and (4) Flexible Property Sheet Views:";
	m_csIntroduction += "\r\n\r\n";
	m_csIntroduction += "(1)  Flexible Dialogs:  CNSFlexDialog (derived from MFC CDialog) provides support for control repositioning and a convenient way to handle OK and Apply buttons for modal dialogs.";
	m_csIntroduction += "\r\n\r\n";
	m_csIntroduction += "(2)  Flexible Property Sheets:  CNSFlexPropertySheet (derived from MFC CPropertySheet) and  the associated CNSFlexPropertyPage (derived from MFC CPropertyPage) provide support for control repositioning and a convenient way to handle OK and Apply buttons for modal property sheets.";
	m_csIntroduction += "\r\n\r\n";
	m_csIntroduction += "(3)  Flexible Form Views:  CNSFlexFormView (derived from MFC CFormView) and the associated frame window CNSFlexMDIChildWnd (derived from MFC CMDIChildWnd) provide support for control repositioning for modeless dialog views.";
	m_csIntroduction += "\r\n\r\n";
	m_csIntroduction += "(4)  Flexible Property Sheet Views:  MFC support for modeless property sheet views is conspicuously absent.  CNSFlexPropertySheetView (derived from MFC CScrollView) and the associated CNSFlexPropertySheet, CNSFlexPropertyPage, and CNSFlexMDIChildWnd provide support for control repositioning in modeless property sheet views - an extremely useful extension to the MFC view classes.";
	m_csIntroduction += "\r\n\r\n";
	m_csIntroduction += "The four buttons below bring up samples of each of the four types of flexible modal dialogs and modeless views.  Check them out and imagine how they might work in your application.  The control repositioning behavior gets addictive.  Once you try it in your application, there�s a good chance that you�ll be tugging at the corners of everybody�s windows and will feel a little let down by the ones that don�t do what yours do.";
	m_csIntroduction += "\r\n\r\n";
	m_csIntroduction += "The code was written by Mike Knewtson and Ed Smetak of NanoSoft Corporation.  All of the source code for the library is available free of charge courtesy of NanoSoft Corporation.  Visit NanoSoft�s web site to download a copy.";

	m_csIntroduction += "\r\n\r\n";
	m_csIntroduction += "SEE OUR ARTICLE DESCRIBING THE NSViews C++ LIBRARY:";
	m_csIntroduction += "\r\n\r\n";
	m_csIntroduction += "     Dialogisthenics";
	m_csIntroduction += "\r\n";
	m_csIntroduction += "     by Ed Smetak and Mike Knewtson";
	m_csIntroduction += "\r\n";
	m_csIntroduction += "     Windows Tech Journal, February 1997, pp 20-26";
	
	m_csIntroduction += "\r\n\r\n";
	m_csIntroduction += "NSViews C++ Library authors:";
	m_csIntroduction += "\r\n\r\n";
	m_csIntroduction += "     Michael A. Knewtson, Principal Engineering Consultant";
	m_csIntroduction += "\r\n";
	m_csIntroduction += "     e-mail:  knewtson@nanocorp.com";
	m_csIntroduction += "\r\n\r\n";
	m_csIntroduction += "     Edward C. Smetak, Vice President of Engineering Software Consulting";
	m_csIntroduction += "\r\n";
	m_csIntroduction += "     e-mail:  ecsmetak@nanocorp.com";
	m_csIntroduction += "\r\n\r\n";
	m_csIntroduction += "NanoSoft Corporation:";
	m_csIntroduction += "\r\n\r\n";
	m_csIntroduction += "     http://www.nanocorp.com";
	m_csIntroduction += "\r\n\r\n";
	m_csIntroduction += "     3040 Post Oak Blvd., Suite 1430";
	m_csIntroduction += "\r\n";
	m_csIntroduction += "     Houston, Texas 77056";
	m_csIntroduction += "\r\n\r\n";
	m_csIntroduction += "     (713) 961-3061 - Fax 961-4028";
}

CNSViewsDemoDoc::~CNSViewsDemoDoc()
{

}

BOOL CNSViewsDemoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	m_csEdit1 = "Flexible views are cool!";
	m_csList1 = "CNSFlexDialog";
	m_csCombo1 = "NSFlexDialog.h";
	m_csCombo2 = "NSFlexHorizontallyFixed";
	m_csCombo3 = "NSFlexDialog.cpp";

	m_csTab2Edit1 = "Flexible views are cool!";

	return TRUE;
}

void CNSViewsDemoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		ar << m_csEdit1;
		ar << m_csList1;
		ar << m_csCombo1;
		ar << m_csCombo2;
		ar << m_csCombo3;
		ar << m_csTab2Edit1;
	}
	else
	{
		ar >> m_csEdit1;
		ar >> m_csList1;
		ar >> m_csCombo1;
		ar >> m_csCombo2;
		ar >> m_csCombo3;
		ar >> m_csTab2Edit1;
	}
}

#ifdef _DEBUG

void CNSViewsDemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CNSViewsDemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}

#endif //_DEBUG

void CNSViewsDemoDoc::OnDemoFlexibleDialog() 
{
	CFlexDialog FlexDialog;
	FlexDialog.SetSubject(this);
	FlexDialog.DoModal();
}

void CNSViewsDemoDoc::OnDemoFlexibleFormView() 
{
	CNSViewsDemoApp* pNSViewsDemoApp = (CNSViewsDemoApp*)AfxGetApp();
	CMultiDocTemplate* pMultiDocTemplate = pNSViewsDemoApp->m_pFlexFormViewDocTemplate;
	CFrameWnd* pFrameWnd = pMultiDocTemplate->CreateNewFrame(this,NULL);
	pMultiDocTemplate->InitialUpdateFrame(pFrameWnd,this);
}

void CNSViewsDemoDoc::OnDemoFlexiblePropertySheet() 
{
	CFlexPropertySheet FlexPropertySheet;
	FlexPropertySheet.SetSubject(this);
	FlexPropertySheet.DoModal();
}

void CNSViewsDemoDoc::OnDemoFlexiblePropertySheetView() 
{
	CNSViewsDemoApp* pNSViewsDemoApp = (CNSViewsDemoApp*)AfxGetApp();
	CMultiDocTemplate* pMultiDocTemplate = pNSViewsDemoApp->m_pFlexPropertySheetViewDocTemplate;
	CFrameWnd* pFrameWnd = pMultiDocTemplate->CreateNewFrame(this,NULL);
	pMultiDocTemplate->InitialUpdateFrame(pFrameWnd,this);
}

void CNSViewsDemoDoc::OnDemoIntroduction() 
{
	CNSViewsDemoApp* pNSViewsDemoApp = (CNSViewsDemoApp*)AfxGetApp();
	CMultiDocTemplate* pMultiDocTemplate = pNSViewsDemoApp->m_pIntroViewDocTemplate;
	CFrameWnd* pFrameWnd = pMultiDocTemplate->CreateNewFrame(this,NULL);
	pMultiDocTemplate->InitialUpdateFrame(pFrameWnd,this);
}
