// This code is a part of the NanoSoft NSViews C++ Library.
// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "NSViewsDemo.h"
#include "FlexPropertyPage1.h"
#include "FlexPropertyPage2.h"
#include "FlexPropertySheet.h"
#include "NSViewsDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CFlexPropertySheet, CNSFlexPropertySheet)

BEGIN_MESSAGE_MAP(CFlexPropertySheet, CNSFlexPropertySheet)
	//{{AFX_MSG_MAP(CFlexPropertySheet)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CFlexPropertySheet::CFlexPropertySheet()
	:CNSFlexPropertySheet("Flexible Property Sheet (CNSFlexPropertySheet)",
	NULL,1)
{
	m_pFlexPropertyPage1 = new CFlexPropertyPage1;
	m_pFlexPropertyPage2 = new CFlexPropertyPage2;

	AddPage(m_pFlexPropertyPage1);
	AddPage(m_pFlexPropertyPage2);
}

CFlexPropertySheet::~CFlexPropertySheet()
{
	delete m_pFlexPropertyPage1;
	delete m_pFlexPropertyPage2;
}

void CFlexPropertySheet::SetSubject(void *pSubject)
{
	CNSFlexPropertySheet::SetSubject(pSubject);

	CNSViewsDemoDoc* pDoc = (CNSViewsDemoDoc*)pSubject;

	m_pFlexPropertyPage1->m_csList1 = pDoc->m_csList1;
	m_pFlexPropertyPage1->m_csCombo1 = pDoc->m_csCombo1;
	m_pFlexPropertyPage1->m_csCombo2 = pDoc->m_csCombo2;
	m_pFlexPropertyPage1->m_csCombo3 = pDoc->m_csCombo3;
	m_pFlexPropertyPage1->m_csEdit1 = pDoc->m_csEdit1;

	m_pFlexPropertyPage2->m_csEdit1 = pDoc->m_csTab2Edit1;
}

BOOL CFlexPropertySheet::OnApplyChanges(void* pSubject)
{
	CNSViewsDemoDoc* pDoc = (CNSViewsDemoDoc*)pSubject;

	pDoc->m_csList1 = m_pFlexPropertyPage1->m_csList1;
	pDoc->m_csCombo1 = m_pFlexPropertyPage1->m_csCombo1;
	pDoc->m_csCombo2 = m_pFlexPropertyPage1->m_csCombo2;
	pDoc->m_csCombo3 = m_pFlexPropertyPage1->m_csCombo3;
	pDoc->m_csEdit1 = m_pFlexPropertyPage1->m_csEdit1;

	pDoc->m_csTab2Edit1 = m_pFlexPropertyPage2->m_csEdit1;

	pDoc->SetModifiedFlag();
	pDoc->UpdateAllViews(NULL);

	return TRUE;
}

