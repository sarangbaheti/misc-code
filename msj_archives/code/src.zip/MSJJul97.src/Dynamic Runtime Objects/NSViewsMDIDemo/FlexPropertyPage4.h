// This code is a part of the NanoSoft NSViews C++ Library.
// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "NSFlexPropertyPage.h"

class CFlexPropertyPage4 : public CNSFlexPropertyPage
{
	DECLARE_DYNCREATE(CFlexPropertyPage4)

// Construction
public:
	CFlexPropertyPage4();
	~CFlexPropertyPage4();

// Dialog Data
	//{{AFX_DATA(CFlexPropertyPage4)
	enum { IDD = IDD_PROPERTYPAGE2 };
	CString	m_csEdit1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CFlexPropertyPage4)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);

// Implementation
protected:

	void UpdateDocumentData();

	// Generated message map functions
	//{{AFX_MSG(CFlexPropertyPage4)
	afx_msg void OnChangeEdit1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
