// This code is a part of the NanoSoft NSViews C++ Library.
// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "NSFlexPropertyPage.h"

class CFlexPropertyPage1 : public CNSFlexPropertyPage
{
	DECLARE_DYNCREATE(CFlexPropertyPage1)

// Construction
public:
	CFlexPropertyPage1();
	~CFlexPropertyPage1();

// Dialog Data
	//{{AFX_DATA(CFlexPropertyPage1)
	enum { IDD = IDD_PROPERTYPAGE1 };
	CString	m_csCombo1;
	CString	m_csCombo2;
	CString	m_csCombo3;
	CString	m_csEdit1;
	CString	m_csList1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CFlexPropertyPage1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFlexPropertyPage1)
	afx_msg void OnButton1();
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeCombo1();
	afx_msg void OnEditchangeCombo2();
	afx_msg void OnSelchangeCombo2();
	afx_msg void OnEditchangeCombo3();
	afx_msg void OnSelchangeCombo3();
	afx_msg void OnChangeEdit1();
	afx_msg void OnSelchangeList1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
