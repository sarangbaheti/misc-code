// This code is a part of the NanoSoft NSViews C++ Library.
// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "NSViewsDemo.h"
#include "FlexFormView.h"
#include "NSViewsDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CFlexFormView, CNSFlexFormView)

BEGIN_MESSAGE_MAP(CFlexFormView, CNSFlexFormView)
	//{{AFX_MSG_MAP(CFlexFormView)
	ON_EN_CHANGE(IDC_EDIT_1, OnChangeEdit1)
	ON_CBN_SELCHANGE(IDC_COMBO_1, OnSelchangeCombo1)
	ON_CBN_EDITCHANGE(IDC_COMBO_2, OnEditchangeCombo2)
	ON_CBN_EDITCHANGE(IDC_COMBO_3, OnEditchangeCombo3)
	ON_LBN_SELCHANGE(IDC_LIST_1, OnSelchangeList1)
	ON_CBN_SELCHANGE(IDC_COMBO_2, OnSelchangeCombo2)
	ON_CBN_SELCHANGE(IDC_COMBO_3, OnSelchangeCombo3)
	ON_BN_CLICKED(IDC_BUTTON_1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CFlexFormView::CFlexFormView()
	: CNSFlexFormView(CFlexFormView::IDD)
{
	CNSFlexHorizontalConstraint FillLeftHalf    (0.0f,  0.5f);
	CNSFlexHorizontalConstraint CenterInLeftHalf(0.25f, 0.25f);
	CNSFlexHorizontalConstraint FillRightHalf   (0.5f,  1.0f);

	AddFlexConstraint(IDC_STATIC_5, FillLeftHalf, NSFlexExpandDown);
	AddFlexConstraint(IDC_LIST_1,   FillLeftHalf, NSFlexExpandDown); 
	AddFlexConstraint(IDC_BUTTON_1, CenterInLeftHalf, NSFlexShiftDown); 
	AddFlexConstraint(IDC_STATIC_1, FillRightHalf, NSFlexVerticallyFixed);
	AddFlexConstraint(IDC_COMBO_1,  FillRightHalf, NSFlexVerticallyFixed); 
	AddFlexConstraint(IDC_STATIC_2, FillRightHalf, NSFlexVerticallyFixed); 
	AddFlexConstraint(IDC_COMBO_2,  FillRightHalf, NSFlexExpandDown); 
	AddFlexConstraint(IDC_STATIC_3, FillRightHalf, NSFlexShiftDown); 
	AddFlexConstraint(IDC_COMBO_3,  FillRightHalf, NSFlexShiftDown); 
	AddFlexConstraint(IDC_STATIC_4, FillRightHalf, NSFlexShiftDown); 
	AddFlexConstraint(IDC_EDIT_1,   FillRightHalf, NSFlexShiftDown); 

	//{{AFX_DATA_INIT(CFlexFormView)
	m_csEdit1 = _T("");
	m_csList1 = _T("");
	m_csCombo1 = _T("");
	m_csCombo2 = _T("");
	m_csCombo3 = _T("");
	//}}AFX_DATA_INIT
}

CFlexFormView::~CFlexFormView()
{

}

void CFlexFormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFlexFormView)
	DDX_Text(pDX, IDC_EDIT_1, m_csEdit1);
	DDX_LBString(pDX, IDC_LIST_1, m_csList1);
	DDX_CBString(pDX, IDC_COMBO_1, m_csCombo1);
	DDX_CBString(pDX, IDC_COMBO_2, m_csCombo2);
	DDX_CBString(pDX, IDC_COMBO_3, m_csCombo3);
	//}}AFX_DATA_MAP
}

#ifdef _DEBUG

void CFlexFormView::AssertValid() const
{
	CFormView::AssertValid();
}

void CFlexFormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

#endif //_DEBUG

void CFlexFormView::OnSelchangeCombo1() 
{
	UpdateData();
	UpdateDocumentData();
	GetDocument()->SetModifiedFlag();
	GetDocument()->UpdateAllViews(this);
}

void CFlexFormView::OnEditchangeCombo2() 
{
	UpdateData();
	UpdateDocumentData();
	GetDocument()->SetModifiedFlag();
	GetDocument()->UpdateAllViews(this);
}

void CFlexFormView::OnSelchangeCombo2() 
{
	// UpdateData(); Why doesn't this work? Try following...
	// begin workaround
	CString cs;
	CComboBox* pCombo = (CComboBox*)GetDlgItem(IDC_COMBO_2);
	pCombo->GetLBText(pCombo->GetCurSel(),cs);
	m_csCombo2 = cs;
	// end workaround

	UpdateDocumentData();
	GetDocument()->SetModifiedFlag();
	GetDocument()->UpdateAllViews(this);
}

void CFlexFormView::OnEditchangeCombo3() 
{
	UpdateData();
	UpdateDocumentData();
	GetDocument()->SetModifiedFlag();
	GetDocument()->UpdateAllViews(this);
}

void CFlexFormView::OnSelchangeCombo3() 
{
	// UpdateData(); Why doesn't this work? Try following...
	// begin workaround
	CString cs;
	CComboBox* pCombo = (CComboBox*)GetDlgItem(IDC_COMBO_3);
	pCombo->GetLBText(pCombo->GetCurSel(),cs);
	m_csCombo3 = cs;
	// end workaround

	UpdateDocumentData();
	GetDocument()->SetModifiedFlag();
	GetDocument()->UpdateAllViews(this);
}

void CFlexFormView::OnSelchangeList1() 
{
	UpdateData();
	UpdateDocumentData();
	GetDocument()->SetModifiedFlag();
	GetDocument()->UpdateAllViews(this);
}

void CFlexFormView::OnChangeEdit1() 
{
	UpdateData();
	UpdateDocumentData();
	GetDocument()->SetModifiedFlag();
	GetDocument()->UpdateAllViews(this);
}

void CFlexFormView::OnInitialUpdate() 
{
	CListBox* pList = (CListBox*)GetDlgItem(IDC_LIST_1);

	pList->AddString("CNSFlexConstraint");
	pList->AddString("CNSFlexConstraintList");
	pList->AddString("CNSFlexDialog");
	pList->AddString("CNSFlexFormView");
	pList->AddString("CNSFlexHorizontalConstraint");
	pList->AddString("CNSFlexMDIChildWnd");
	pList->AddString("CNSFlexPropertyPage");
	pList->AddString("CNSFlexPropertySheet");
	pList->AddString("CNSFlexPropertySheetView");
	pList->AddString("CNSFlexVerticalConstraint");

	CNSFlexFormView::OnInitialUpdate();
}

void CFlexFormView::OnButton1() 
{
	AfxMessageBox("Button pressed");
}

void CFlexFormView::UpdateDocumentData()
{
	CNSViewsDemoDoc* pDoc = (CNSViewsDemoDoc*)GetDocument();
	ASSERT(pDoc);

	pDoc->m_csEdit1 = m_csEdit1;
	pDoc->m_csList1 = m_csList1;
	pDoc->m_csCombo1 = m_csCombo1;
	pDoc->m_csCombo2 = m_csCombo2;
	pDoc->m_csCombo3 = m_csCombo3;
}

void CFlexFormView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	CNSViewsDemoDoc* pDoc = (CNSViewsDemoDoc*)GetDocument();
	ASSERT(pDoc);

	m_csEdit1 = pDoc->m_csEdit1;
	m_csList1 = pDoc->m_csList1;
	m_csCombo1 = pDoc->m_csCombo1;
	m_csCombo2 = pDoc->m_csCombo2;
	m_csCombo3 = pDoc->m_csCombo3;

	UpdateData(FALSE);
}
