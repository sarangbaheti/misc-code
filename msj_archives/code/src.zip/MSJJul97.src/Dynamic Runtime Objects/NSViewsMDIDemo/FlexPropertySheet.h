// This code is a part of the NanoSoft NSViews C++ Library.
// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "NSFlexPropertySheet.h"

class CFlexPropertyPage1;
class CFlexPropertyPage2;

class CFlexPropertySheet : public CNSFlexPropertySheet
{
	DECLARE_DYNAMIC(CFlexPropertySheet)

  public:

	CFlexPropertySheet();
	virtual ~CFlexPropertySheet();

	// ClassWizard
	//{{AFX_VIRTUAL(CFlexPropertySheet)
	//}}AFX_VIRTUAL

	virtual BOOL OnApplyChanges(void *pSubject);
	virtual void SetSubject(void *pSubject);

  protected:


	// ClassWizard
	//{{AFX_MSG(CFlexPropertySheet)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

  private:

	CFlexPropertyPage1* m_pFlexPropertyPage1;
	CFlexPropertyPage2* m_pFlexPropertyPage2;

};
