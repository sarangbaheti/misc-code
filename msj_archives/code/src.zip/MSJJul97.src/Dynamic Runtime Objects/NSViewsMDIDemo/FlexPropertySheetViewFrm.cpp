// This code is a part of the NanoSoft NSViews C++ Library.
// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "NSViewsDemo.h"
#include "FlexPropertySheetViewFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CFlexPropertySheetViewFrm, CNSFlexMDIChildWnd)

BEGIN_MESSAGE_MAP(CFlexPropertySheetViewFrm, CNSFlexMDIChildWnd)
	//{{AFX_MSG_MAP(CFlexPropertySheetViewFrm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CFlexPropertySheetViewFrm::CFlexPropertySheetViewFrm()
{
	
}

CFlexPropertySheetViewFrm::~CFlexPropertySheetViewFrm()
{

}

BOOL CFlexPropertySheetViewFrm::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CMDIChildWnd::PreCreateWindow(cs);
}

#ifdef _DEBUG

void CFlexPropertySheetViewFrm::AssertValid() const
{
	CMDIChildWnd::AssertValid();
}

void CFlexPropertySheetViewFrm::Dump(CDumpContext& dc) const
{
	CMDIChildWnd::Dump(dc);
}

#endif //_DEBUG

void CFlexPropertySheetViewFrm::OnUpdateFrameTitle(BOOL bAddToTitle)
{
	CMDIChildWnd::OnUpdateFrameTitle(bAddToTitle);

	CString csTitle;
	GetWindowText(csTitle);

	SetWindowText("Flexible Property Sheet View (CNSFlexPropertySheetView) - "
		+ csTitle);
}
