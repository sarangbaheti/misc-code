// This code is a part of the NanoSoft NSViews C++ Library.
// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "NSFlexPropertyPage.h"

class CFlexPropertyPage2 : public CNSFlexPropertyPage
{
	DECLARE_DYNCREATE(CFlexPropertyPage2)

// Construction
public:
	CFlexPropertyPage2();
	~CFlexPropertyPage2();

// Dialog Data
	//{{AFX_DATA(CFlexPropertyPage2)
	enum { IDD = IDD_PROPERTYPAGE2 };
	CString	m_csEdit1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CFlexPropertyPage2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFlexPropertyPage2)
	afx_msg void OnChangeEdit1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
