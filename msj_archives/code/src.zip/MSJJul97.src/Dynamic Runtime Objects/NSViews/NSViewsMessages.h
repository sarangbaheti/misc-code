// This code is a part of the NanoSoft NSViews C++ Library.
// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __NSViewsMessages_h__
#define __NSViewsMessages_h__

#define WM_PAGESETACTIVE     (WM_USER + 0x1000)
#define WM_SETMINTRACKSIZE   (WM_USER + 0x1001)

#endif
