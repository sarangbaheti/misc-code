// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "OVCoreAfxExt.h"

class CObjectBroker;
class CViewBroker;

class AFX_EXT_OVCORE CObjectDoc : public COleDocument
{

	DECLARE_DYNCREATE(CObjectDoc)

  public:

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CObjectDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void OnChangedViewList();
	//}}AFX_VIRTUAL

	virtual ~CObjectDoc();

#ifdef _DEBUG
	virtual void AssertValid() const;
#endif

#ifdef _DEBUG
	virtual void Dump(CDumpContext& dc) const;
#endif

	CObjectBroker* GetObjectBroker() const;

	CViewBroker* GetViewBroker() const;

	virtual void WindowNew(); 

  private:

	CObjectBroker* m_pObjectBroker;

	CViewBroker* m_pViewBroker;

  protected:

	CObjectDoc();

	//{{AFX_MSG(CObjectDoc)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
  
};

