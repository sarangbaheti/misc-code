// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "MultiDocTemplateEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CMultiDocTemplateEx, CMultiDocTemplate);

CMultiDocTemplateEx::CMultiDocTemplateEx(UINT nIDResource, 
	CRuntimeClass* pDocClass, CRuntimeClass* pFrameClass, 
	CRuntimeClass* pViewClass) : CMultiDocTemplate(nIDResource,
	pDocClass,pFrameClass,pViewClass)
{
	m_pDefaultFrameClass = pFrameClass;
	m_pDefaultViewClass = pViewClass;
}

CMultiDocTemplateEx::~CMultiDocTemplateEx()
{

}

CFrameWnd* CMultiDocTemplateEx::CreateNewFrame(CDocument* pDoc, 
	CFrameWnd* pOther)
{
	m_pFrameClass = m_pDefaultFrameClass;
	m_pViewClass = m_pDefaultViewClass;

	return CMultiDocTemplate::CreateNewFrame(pDoc,pOther);
}

CFrameWnd* CMultiDocTemplateEx::CreateNewFrame(CDocument* pDoc, 
	CRuntimeClass* pFrameClass, CRuntimeClass* pViewClass)
{
	if (pFrameClass)
		m_pFrameClass = pFrameClass;
	else
		m_pFrameClass = m_pDefaultFrameClass;

	if (pViewClass)
		m_pViewClass = pViewClass;
	else
		m_pViewClass = m_pDefaultViewClass;

	return CMultiDocTemplate::CreateNewFrame(pDoc,NULL);
}
