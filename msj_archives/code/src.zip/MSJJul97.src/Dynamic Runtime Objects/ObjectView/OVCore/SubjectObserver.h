// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __SubjectObserver_h__
#define __SubjectObserver_h__

#include "OVCoreAfxExt.h"

class CSubject;

class AFX_EXT_OVCORE CObserver
{

  public:

	CObserver();

	~CObserver();

	virtual void SubjectChanged(CSubject* pSubject, 
		LPARAM lHint, void* pHint) = 0;

};

class AFX_EXT_OVCORE CSubject
{

  public:

	CSubject();

	~CSubject();

	void AttachToSubject(CObserver* pObserver);

	void DetachFromSubject(CObserver* pObserver);

	BOOL IsObserver(CObserver* pObserver) const;

	void NotifyObservers(LPARAM lHint, void* pHint);

  private:

	CPtrList m_listObservers;

};

#endif
