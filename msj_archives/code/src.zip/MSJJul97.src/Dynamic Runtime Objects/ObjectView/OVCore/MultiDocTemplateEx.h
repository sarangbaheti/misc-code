// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __MultiDocTemplateEx_h__
#define __MultiDocTemplateEx_h__

#include "OVCoreAfxExt.h"

class AFX_EXT_OVCORE CMultiDocTemplateEx : public CMultiDocTemplate
{

    DECLARE_DYNAMIC(CMultiDocTemplateEx)

  public:

	CMultiDocTemplateEx(UINT nIDResource, CRuntimeClass* pDocClass, 
		CRuntimeClass* pFrameClass, CRuntimeClass* pViewClass);

	~CMultiDocTemplateEx();

	virtual CFrameWnd* CreateNewFrame(CDocument* pDoc, CFrameWnd* pOther);

	virtual CFrameWnd* CreateNewFrame(CDocument* pDoc, 
		CRuntimeClass* pFrameClass, CRuntimeClass* pViewClass);

  private:

	CRuntimeClass* m_pDefaultFrameClass;
	CRuntimeClass* m_pDefaultViewClass; 

};

#endif
