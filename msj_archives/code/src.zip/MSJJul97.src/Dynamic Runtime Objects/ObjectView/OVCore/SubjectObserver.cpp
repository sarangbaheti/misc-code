// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "SubjectObserver.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CObserver::CObserver()
{

}

CObserver::~CObserver()
{

}

CSubject::CSubject()
{

}

CSubject::~CSubject()
{
	ASSERT(m_listObservers.GetCount() == 0);
}

void CSubject::AttachToSubject(CObserver* pObserver)
{
	m_listObservers.AddHead(pObserver);
}

void CSubject::DetachFromSubject(CObserver* pObserver)
{
	POSITION pos = m_listObservers.Find(pObserver);
	ASSERT(pos);
	m_listObservers.RemoveAt(pos);
}

BOOL CSubject::IsObserver(CObserver* pObserver) const
{
	POSITION pos = m_listObservers.Find(pObserver);

	return (pos != NULL);
}

void CSubject::NotifyObservers(LPARAM lHint, void* pHint)
{
	for (POSITION pos = m_listObservers.GetHeadPosition(); pos; )
	{
		CObserver* pObserver = (CObserver*)m_listObservers.GetNext(pos);
		pObserver->SubjectChanged(this,lHint,pHint);
	}
}
