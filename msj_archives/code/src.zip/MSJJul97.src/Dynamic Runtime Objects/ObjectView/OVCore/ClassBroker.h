// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __ClassBroker_h__
#define __ClassBroker_h__

#include "OVCoreAfxExt.h"

class AFX_EXT_OVCORE CClassInfo
{

  friend class CClassBroker;

  public:

	REFCLSID GetClassID() const;

	REFCLSID GetClassCategory() const;

	const CString& GetDescription() const;

	CRuntimeClass* GetObjectClass() const;

	CRuntimeClass* GetFrameClass() const;

	CRuntimeClass* GetViewClass() const;

	BOOL LoadLibrary();

	void FreeLibrary();

	BOOL IsLibraryLoaded() const;

  private:

	CClassInfo(REFCLSID rclsidClassID, REFCLSID rclsidClassCategory,
		LPCTSTR pszDescription, CRuntimeClass* pObjectClass, 
		CRuntimeClass* pFrameClass, CRuntimeClass* pViewClass, 
		LPCTSTR pszModuleFileName);

	virtual ~CClassInfo();

  private:

	CLSID m_clsidClassID;

	CLSID m_clsidClassCategory;

	CString m_csDescription;

	CRuntimeClass* m_pObjectClass;

	CRuntimeClass* m_pFrameClass;

	CRuntimeClass* m_pViewClass;

	CString m_csModuleFileName;

	HMODULE m_hModule;

	ULONG m_nRefCount;

};

class AFX_EXT_OVCORE CClassBroker
{

  public:

	static void AddClassInfo(REFCLSID rclsidClassID,
		REFCLSID rclsidClassCategory, LPCTSTR pszDescription,
		CRuntimeClass* pObjectClass, CRuntimeClass* pFrameClass, 
		CRuntimeClass* pViewClass, LPCTSTR pszModuleFileName);

	static void FreeMemory();

	static CClassInfo* GetClassInfo(REFCLSID rclsid);

	static POSITION GetHeadPosition();

	static CClassInfo* GetNext(POSITION& rPosition);

	static void LoadDLLModules();

  private:

	static CPtrList m_listClasses;

};

#endif

