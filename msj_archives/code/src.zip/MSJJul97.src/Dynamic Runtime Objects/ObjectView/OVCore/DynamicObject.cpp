// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "DynamicObject.h"
#include "ObjectBroker.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CDynamicObject,CObject,1)

CDynamicObject::CDynamicObject()
{
	m_nRefCount = 0;
	m_pObjectInfo = NULL;
}

CDynamicObject::~CDynamicObject()
{
	ASSERT(m_nRefCount == 0);
}

ULONG CDynamicObject::AddRef()
{
	ASSERT(m_pObjectInfo);
	ASSERT(m_nRefCount >= 0);

	m_nRefCount++;
	return m_nRefCount;
}

ULONG CDynamicObject::Release()
{
	ASSERT(m_pObjectInfo);
	ASSERT(m_nRefCount > 0);

	if (--m_nRefCount > 0)
		return m_nRefCount;
	else
	{
		m_pObjectInfo->StoreObject(TRUE);
		return 0;	
	}
}

CObjectBroker* CDynamicObject::GetObjectBroker() const
{
	ASSERT(m_pObjectInfo);
	ASSERT(m_pObjectInfo->GetObjectBroker());

	return m_pObjectInfo->GetObjectBroker();
}

CObjectInfo* CDynamicObject::GetObjectInfo() const
{
	ASSERT(m_pObjectInfo);

	return m_pObjectInfo;
}

void CDynamicObject::SetObjectInfo(CObjectInfo* pObjectInfo)
{
	ASSERT(m_pObjectInfo == NULL);
	ASSERT(pObjectInfo->IsKindOf(RUNTIME_CLASS(CObjectInfo)));

	m_pObjectInfo = pObjectInfo;
}

void CDynamicObject::OnSerializedObjectFromArchive()
{
		
}

void CDynamicObject::OnCreatedNewObject()
{
		
}
