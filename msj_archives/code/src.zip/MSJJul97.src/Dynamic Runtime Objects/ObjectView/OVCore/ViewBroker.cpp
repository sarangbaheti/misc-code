// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "ViewBroker.h"
#include "ObjectBroker.h"
#include "ClassBroker.h"
#include "MultiDocTemplateEx.h"
#include "ObjectInfoMessage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CViewBroker::CViewBroker(CDocument* pDocument, CObjectBroker* pObjectBroker)
{
	m_pDocument = pDocument;
	m_pObjectBroker = pObjectBroker;
	m_pObjectBroker->AttachToSubject(this);
}

CViewBroker::~CViewBroker()
{
	m_pObjectBroker->DetachFromSubject(this);

	ASSERT(m_mapViewInfo.IsEmpty());
}

CString CViewBroker::GetObjectKey(CView* pView) const
{
	CString csKey;
	CViewInfo* pViewInfo;

	for (POSITION posInfo = m_mapViewInfo.GetStartPosition(); posInfo; )
	{
		m_mapViewInfo.GetNextAssoc(posInfo,csKey,(void*&)pViewInfo);

		CPtrList& PtrList = pViewInfo->m_listViews;
		POSITION posView = PtrList.Find(pView);

		if(posView)
			break;
	}

	return csKey;
}

void CViewBroker::OpenDuplicateView(LPCTSTR pszObjectKey)
{
	CObjectInfo* pObjectInfo = m_pObjectBroker->
		GetObjectInfoByKey(pszObjectKey);
	ASSERT(pObjectInfo);

	CClassInfo* pClassInfo = 
		CClassBroker::GetClassInfo(pObjectInfo->GetClassID());
	ASSERT(pClassInfo);

	CMultiDocTemplateEx* pDocTemplate = 
		(CMultiDocTemplateEx*)m_pDocument->GetDocTemplate();

	CFrameWnd* pFrameWnd = pDocTemplate->CreateNewFrame(
		m_pDocument,pClassInfo->GetFrameClass(),
		pClassInfo->GetViewClass());
	ASSERT(pFrameWnd);

	CView* pView =
		(CView*)pFrameWnd->GetDescendantWindow(AFX_IDW_PANE_FIRST,TRUE);
	ASSERT(pView->IsKindOf(pClassInfo->GetViewClass()));

	CViewInfo* pViewInfo = NULL;
	m_mapViewInfo.Lookup(pszObjectKey,(void*&)pViewInfo);
	ASSERT(pViewInfo);
	pViewInfo->m_listViews.AddTail(pView);

	ObjectInfoMessage structObjectInfoMessage;
	structObjectInfoMessage.pObjectBroker = m_pObjectBroker;
	structObjectInfoMessage.pszObjectKey = pszObjectKey;
	VERIFY(pView->SendMessage(WM_OBJECTINFO,0,(LPARAM)&structObjectInfoMessage));

	SetWindowTitles();
	pDocTemplate->InitialUpdateFrame(pFrameWnd,m_pDocument);
}

void CViewBroker::OpenView(LPCTSTR pszObjectKey)
{
	CViewInfo* pViewInfo;
	if (m_mapViewInfo.Lookup(pszObjectKey,(void*&)pViewInfo))
	{
		CView* pView = (CView*)pViewInfo->m_listViews.GetHead();
		CMDIChildWnd* pFrameWindow = (CMDIChildWnd*)pView->GetParent();
		if (pFrameWindow->IsIconic())
			pFrameWindow->MDIRestore();
		pFrameWindow->MDIActivate();
		return;
	}

	pViewInfo = new CViewInfo();
	m_mapViewInfo.SetAt(pszObjectKey,pViewInfo);

	OpenDuplicateView(pszObjectKey);
}

void CViewBroker::SetWindowTitles()
{
	CString csKey;
	CViewInfo* pViewInfo;

	for (POSITION posInfo = m_mapViewInfo.GetStartPosition(); posInfo; )
	{
		m_mapViewInfo.GetNextAssoc(posInfo,csKey,(void*&)pViewInfo);

		CObjectBroker* pObjectBroker = m_pObjectBroker;
		ASSERT(pObjectBroker);

		CObjectInfo* pObjectInfo = 
			pObjectBroker->GetObjectInfoByKey(csKey);
		ASSERT(pObjectInfo);

		CString csTitle = CClassBroker::GetClassInfo(pObjectInfo->
			GetClassID())->GetDescription();
		csTitle += " - ";
		csTitle += pObjectInfo->GetName();

		CPtrList& PtrList = pViewInfo->m_listViews;
		ASSERT(!PtrList.IsEmpty());

		BOOL bAddCount = PtrList.GetCount() > 1;
		int nCount = 1;

		for (POSITION posView = PtrList.GetHeadPosition(); posView; nCount++)
		{
			CView* pView = (CView*)PtrList.GetNext(posView);

			CString csCount;

			if(bAddCount)
				csCount.Format(" : %d",nCount);

			pView->GetParent()->SetWindowText(csTitle + csCount);
		}

	}
}

void CViewBroker::SubjectChanged(CSubject* pSubject,	
	LPARAM lHint, void* pHint)
{
	ASSERT(pSubject == m_pObjectBroker);

	if (lHint == OBJECT_BROKER_ABOUT_TO_REMOVE_OBJECT)
	{
		CString csRemovingKey = *((CString*)pHint);
		CString csKey;

		CViewInfo* pViewInfo;

		for (POSITION posInfo = m_mapViewInfo.GetStartPosition(); posInfo; )
		{
			m_mapViewInfo.GetNextAssoc(posInfo,csKey,(void*&)pViewInfo);

			if (csKey == csRemovingKey)
			{
				CPtrList& PtrList = pViewInfo->m_listViews;
				ASSERT(!PtrList.IsEmpty());

				for (BOOL bNotDone = TRUE; bNotDone; )
				{
					if (PtrList.GetCount() == 1)
						bNotDone = FALSE;

					CView* pView = (CView*)PtrList.GetHead();
					ASSERT(pView);

					CMDIChildWnd* pMDIChildWnd = 
						(CMDIChildWnd*)pView->GetParent();
					ASSERT(pMDIChildWnd);

					pMDIChildWnd->MDIDestroy(); 
					// MDIDestroy() will trigger CViewBroker::ViewClosing()
				}

				return;
			}
		}

		return;
	}

	else if (lHint == OBJECT_BROKER_RENAMED_OBJECT)
	{
		SetWindowTitles();

		return;
	}

}

void CViewBroker::DocViewListChanged()
{
	CString csKey;
	CViewInfo* pViewInfo;

	for (POSITION posInfo = m_mapViewInfo.GetStartPosition(); posInfo; )
	{
		m_mapViewInfo.GetNextAssoc(posInfo,csKey,(void*&)pViewInfo);

		CPtrList& PtrList = pViewInfo->m_listViews;

		for (POSITION posView = PtrList.GetHeadPosition(); posView; )
		{
			CView* pView = (CView*)PtrList.GetNext(posView);

			CView* pDocView = NULL;

			for (POSITION posDocView = m_pDocument->GetFirstViewPosition(); posDocView; )
			{
				if (m_pDocument->GetNextView(posDocView) == pView)
				{
					pDocView = pView;
					break;
				}
			}

			if (!pDocView)
			{
				ViewClosing(pView);
				return;
			}

		}

	}
}

void CViewBroker::ViewClosing(CView* pView)
{
	CString csKey;
	CViewInfo* pViewInfo;

	for (POSITION posInfo = m_mapViewInfo.GetStartPosition(); posInfo; )
	{
		m_mapViewInfo.GetNextAssoc(posInfo,csKey,(void*&)pViewInfo);

		CPtrList& PtrList = pViewInfo->m_listViews;
		ASSERT(!PtrList.IsEmpty());

		POSITION posView = PtrList.Find(pView);

		if(posView)
		{
			PtrList.RemoveAt(posView);
			if (PtrList.IsEmpty())
			{
				m_mapViewInfo.RemoveKey(csKey);
				delete pViewInfo;
			}

			break;
		}
	}

	SetWindowTitles();
}

