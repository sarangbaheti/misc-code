// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __ChildFrm_h__
#define __ChildFrm_h__

#include "OVCoreAfxExt.h"

class AFX_EXT_OVCORE CChildFrame : public CMDIChildWnd
{

	DECLARE_DYNCREATE(CChildFrame)

  public:

	CChildFrame();

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChildFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

	virtual ~CChildFrame();

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

  protected:
	//{{AFX_MSG(CChildFrame)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

};

#endif
