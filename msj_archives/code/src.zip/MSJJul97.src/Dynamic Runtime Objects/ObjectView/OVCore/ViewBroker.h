// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __ViewBroker_h__
#define __ViewBroker_h__

#include "OVCoreAfxExt.h"
#include "SubjectObserver.h"

class CObjectBroker;

class AFX_EXT_OVCORE CViewInfo
{

  public:

	CPtrList m_listViews;

};

class AFX_EXT_OVCORE CViewBroker : public CObserver
{

  public:

	CViewBroker(CDocument* pDocument, CObjectBroker* pObjectBroker);

	virtual ~CViewBroker();

	void DocViewListChanged();

	CString GetObjectKey(CView* pView) const;

	void OpenDuplicateView(LPCTSTR pszObjectKey);

	void OpenView(LPCTSTR pszObjectKey);

	virtual void SubjectChanged(CSubject* pSubject,	LPARAM lHint, void* pHint);

	void ViewClosing(CView* pView);

  private:

	void SetWindowTitles();
  
  private:

	CDocument* m_pDocument;

	CObjectBroker* m_pObjectBroker;

	CMapStringToPtr m_mapViewInfo;

};

#endif

