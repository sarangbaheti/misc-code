// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "ClassBroker.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CPtrList CClassBroker::m_listClasses;

CClassInfo::CClassInfo(REFCLSID rclsidClassID, REFCLSID rclsidClassCategory,
	LPCTSTR pszDescription, CRuntimeClass* pObjectClass, 
	CRuntimeClass* pFrameClass, CRuntimeClass* pViewClass, 
	LPCTSTR pszModuleFileName)
{
	m_hModule = NULL;
	m_nRefCount = 0;

	m_clsidClassID = rclsidClassID;
	m_clsidClassCategory = rclsidClassCategory;

	m_csDescription = pszDescription;
	ASSERT(m_csDescription.GetLength() > 0);
	m_pObjectClass = pObjectClass;
	ASSERT(m_pObjectClass);
	m_pFrameClass = pFrameClass;
	ASSERT(m_pFrameClass);
	m_pViewClass = pViewClass;
	ASSERT(m_pViewClass);
	m_csModuleFileName = pszModuleFileName;
	ASSERT(!m_csModuleFileName.IsEmpty());
}

CClassInfo::~CClassInfo()
{

}

REFCLSID CClassInfo::GetClassID() const
{
	return m_clsidClassID;
}

REFCLSID CClassInfo::GetClassCategory() const
{
	return m_clsidClassCategory;
}

const CString& CClassInfo::GetDescription() const
{
	return m_csDescription;
}

CRuntimeClass* CClassInfo::GetObjectClass() const
{
	return m_pObjectClass;
}

CRuntimeClass* CClassInfo::GetFrameClass() const
{
	return m_pFrameClass;
}
 
CRuntimeClass* CClassInfo::GetViewClass() const
{
	return m_pViewClass;
}

BOOL CClassInfo::LoadLibrary()
{
	if (m_nRefCount == 0)
	{
		ASSERT(m_hModule == NULL);
		m_hModule = AfxLoadLibrary(m_csModuleFileName);

		if (m_hModule)
		{
			m_nRefCount = 1;

			typedef void (WINAPI* CLASSINFO)(CLSID&,CLSID&,CString&,
				CRuntimeClass*&,CRuntimeClass*&,CRuntimeClass*&);

			CLASSINFO pClassInfo =
				(CLASSINFO)GetProcAddress(m_hModule,"ClassInfo");

			ASSERT(pClassInfo);

			CLSID clsidClassID;
			CLSID clsidClassCategory;
			CString csDescription;
			CRuntimeClass* pObjectClass;
			CRuntimeClass* pFrameClass;
			CRuntimeClass* pViewClass;

			(*pClassInfo)(clsidClassID,clsidClassCategory,csDescription,
				pObjectClass,pFrameClass,pViewClass);

			m_pObjectClass = pObjectClass;
			m_pFrameClass = pFrameClass;
			m_pViewClass = pViewClass;

			return TRUE;
		}
		else
		{
			ASSERT(FALSE);
			return FALSE;
		}
	}
	else
	{
		m_nRefCount++;
		return TRUE;
	}
}

void CClassInfo::FreeLibrary()
{
	ASSERT(m_nRefCount > 0);
	ASSERT(m_hModule);

	if (--m_nRefCount == 0)
	{
		BOOL bOK = AfxFreeLibrary(m_hModule);
		ASSERT(bOK);
		m_hModule = NULL;
	}
}

BOOL CClassInfo::IsLibraryLoaded() const
{
	return (m_hModule != NULL);
}

void CClassBroker::AddClassInfo(REFCLSID rclsidClassID,
		REFCLSID rclsidClassCategory, LPCTSTR pszDescription,
		CRuntimeClass* pObjectClass, CRuntimeClass* pFrameClass, 
		CRuntimeClass* pViewClass, LPCTSTR pszModuleFileName)
{
	CClassInfo* pClassInfo = new CClassInfo(rclsidClassID,
		rclsidClassCategory,pszDescription,pObjectClass,
		pFrameClass,pViewClass,pszModuleFileName);
	
	m_listClasses.AddHead(pClassInfo);
}

void CClassBroker::FreeMemory()
{
	for (POSITION pos = m_listClasses.GetHeadPosition(); pos; )
	{
		CClassInfo* pClassInfo = 
			(CClassInfo*) m_listClasses.GetNext(pos);

		ASSERT(pClassInfo->IsLibraryLoaded() == FALSE);
		
		delete pClassInfo;
	}
}

CClassInfo* CClassBroker::GetClassInfo(REFCLSID rclsid)
{
	for (POSITION pos = m_listClasses.GetHeadPosition(); pos; )
	{
		CClassInfo* pClassInfo = 
			(CClassInfo*) m_listClasses.GetNext(pos);

		if (pClassInfo->GetClassID() == rclsid)
			return pClassInfo;
	}

	return NULL;
}

POSITION CClassBroker::GetHeadPosition()
{
	return m_listClasses.GetHeadPosition();
}

CClassInfo* CClassBroker::GetNext(POSITION& rPosition)
{
	return (CClassInfo*)m_listClasses.GetNext(rPosition);
}

void CClassBroker::LoadDLLModules()
{
	char szBuffer[MAX_PATH], szDrive[3], szPath[MAX_PATH];
	GetModuleFileName(AfxGetInstanceHandle(),szBuffer,MAX_PATH);
	_splitpath(szBuffer,szDrive,szPath,NULL,NULL);
	CString csPath = szDrive;
	csPath += szPath;
	CString csDLLSearch = csPath + "*.dll";
	WIN32_FIND_DATA FileData;
	HANDLE hFind;

	for (BOOL bOK = ((hFind = FindFirstFile(csDLLSearch,&FileData))
		!= INVALID_HANDLE_VALUE); bOK; bOK = FindNextFile(hFind,&FileData))
	{
		CString csDLL = csPath;
		csDLL += FileData.cFileName;

		HMODULE hModule = AfxLoadLibrary(csDLL);
		ASSERT(hModule);

		typedef void (WINAPI* CLASSINFO)(CLSID&,CLSID&,CString&,
			CRuntimeClass*&,CRuntimeClass*&,CRuntimeClass*&);

		CLASSINFO pClassInfo =
			(CLASSINFO)GetProcAddress(hModule,"ClassInfo");

		if (pClassInfo)
		{
			CLSID clsidClassID;
			CLSID clsidClassCategory;
			CString csDescription;
			CRuntimeClass* pObjectClass;
			CRuntimeClass* pFrameClass;
			CRuntimeClass* pViewClass;

			(*pClassInfo)(clsidClassID,clsidClassCategory,csDescription,
				pObjectClass,pFrameClass,pViewClass);

			if (GetClassInfo(clsidClassID))
				AfxMessageBox(
					"CClassBroker::LoadDLLModules - Duplicate class ID");
			else
				AddClassInfo(clsidClassID,clsidClassCategory,csDescription,
					pObjectClass,pFrameClass,pViewClass,csDLL);
		}

		AfxFreeLibrary(hModule);
	}
}
