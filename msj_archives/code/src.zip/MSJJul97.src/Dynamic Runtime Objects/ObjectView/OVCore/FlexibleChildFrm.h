// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __FlexibleChildFrm_h__
#define __FlexibleChildFrm_h__

#include "OVCoreAfxExt.h"
#include "NSFlexMDIChildWnd.h"

class AFX_EXT_OVCORE CFlexibleChildFrame : public CNSFlexMDIChildWnd
{

	DECLARE_DYNCREATE(CFlexibleChildFrame)

  public:

	CFlexibleChildFrame();

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFlexibleChildFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

	virtual ~CFlexibleChildFrame();

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

  protected:
	//{{AFX_MSG(CFlexibleChildFrame)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

};

#endif
