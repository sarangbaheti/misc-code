// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __ObjectInfoMessage_h__
#define __ObjectInfoMessage_h__

#define WM_OBJECTINFO  (WM_USER + 0x1000)

class CObjectBroker;

typedef struct 
{
	CObjectBroker* pObjectBroker;
	LPCSTR pszObjectKey;

} ObjectInfoMessage;

#endif
