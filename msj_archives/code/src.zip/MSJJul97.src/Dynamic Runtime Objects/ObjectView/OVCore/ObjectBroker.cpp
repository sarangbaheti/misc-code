// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "ObjectBroker.h"
#include "ClassBroker.h"
#include "DynamicObject.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CObjectInfo,CObject,1)

CObjectInfo::CObjectInfo()
{
	m_pDynamicObject = NULL;
}

CObjectInfo::~CObjectInfo()
{
	ASSERT(m_pDynamicObject == NULL);
	CClassInfo* pClassInfo = GetClassInfo();
	ASSERT(pClassInfo);
	pClassInfo->FreeLibrary();
}

void CObjectInfo::StoreObject(BOOL bFreeMemory)
{
	LPSTORAGE pObjectStorage = GetObjectBroker()->GetObjectStorage();

	COleStreamFile StreamFile;
	if (StreamFile.OpenStream(pObjectStorage,GetStream())== FALSE)
		VERIFY(StreamFile.CreateStream(pObjectStorage,GetStream()));

	CArchive Archive(&StreamFile,CArchive::store|CArchive::bNoFlushOnDelete);
	Archive.m_bForceFlat = FALSE;

	Archive << m_pDynamicObject;

	Archive.Close();
	StreamFile.Close();
	pObjectStorage->Commit(STGC_DEFAULT);
	pObjectStorage->Release();

	if (bFreeMemory)
	{
		delete m_pDynamicObject;
		m_pDynamicObject = NULL;
	}
}

REFCLSID CObjectInfo::GetClassID() const
{
	return m_clsid;
}

CClassInfo* CObjectInfo::GetClassInfo() const
{
	return CClassBroker::GetClassInfo(m_clsid);
}

const CString& CObjectInfo::GetKey() const
{
	return m_csKey;
}

const CString& CObjectInfo::GetName() const
{
	return m_csName;
}

const CString& CObjectInfo::GetStream() const
{
	return m_csStream;
}

CObjectBroker* CObjectInfo::GetObjectBroker() const
{
	return m_pObjectBroker;
}

CDynamicObject* CObjectInfo::GetObject()
{
	if (m_pDynamicObject)
	{
		m_pDynamicObject->AddRef();
		return m_pDynamicObject;
	}

	LPSTORAGE pObjectStorage = GetObjectBroker()->GetObjectStorage();

	COleStreamFile StreamFile;
	VERIFY(StreamFile.OpenStream(pObjectStorage,GetStream()));

	CArchive Archive(&StreamFile,CArchive::load|CArchive::bNoFlushOnDelete);
	Archive.m_bForceFlat = FALSE;

	Archive >> m_pDynamicObject;

	Archive.Close();
	StreamFile.Close();
	pObjectStorage->Release();
	
	ASSERT(m_pDynamicObject);
	ASSERT(m_pDynamicObject->IsKindOf(RUNTIME_CLASS(CDynamicObject)));

	m_pDynamicObject->SetObjectInfo(this);
	m_pDynamicObject->AddRef();
	m_pDynamicObject->OnSerializedObjectFromArchive();

	return m_pDynamicObject;
}

void CObjectInfo::Serialize(CArchive& archive)
{
	CObject::Serialize(archive);

	if (archive.IsStoring())
	{
		archive.Write(&m_clsid,sizeof(CLSID));	
		archive << m_csKey;
		archive << m_csName;
		archive << m_csStream;

		if (m_pDynamicObject)
			StoreObject(FALSE);
	}
	else
	{
		archive.Read(&m_clsid,sizeof(CLSID));
		archive >> m_csKey;
		archive >> m_csName;
		archive >> m_csStream;

		CClassInfo* pClassInfo = GetClassInfo();
		ASSERT(pClassInfo); // a runtime DLL is probably missing
		pClassInfo->LoadLibrary();
	}
}

BOOL CObjectInfo::SetClassID(REFCLSID rclsid)
{
	ASSERT(m_pDynamicObject == NULL);

	m_clsid = rclsid;

	CClassInfo* pClassInfo = GetClassInfo();
	if (pClassInfo == NULL)
		return FALSE;

	pClassInfo->LoadLibrary();

	CRuntimeClass* pObjectClass = pClassInfo->GetObjectClass();
	ASSERT(pObjectClass);

	if (!pObjectClass->IsDerivedFrom(RUNTIME_CLASS(CDynamicObject)))
		return FALSE;
	
	m_pDynamicObject = 
		(CDynamicObject*)pObjectClass->CreateObject();

	ASSERT(m_pDynamicObject);
	ASSERT(m_pDynamicObject->IsKindOf(RUNTIME_CLASS(CDynamicObject)));

	m_pDynamicObject->SetObjectInfo(this);
	m_pDynamicObject->OnCreatedNewObject();

	StoreObject(TRUE);

	return TRUE;
}

void CObjectInfo::SetKey(LPCTSTR pszKey)
{
	ASSERT(m_csKey.IsEmpty());
	m_csKey = pszKey;
}

void CObjectInfo::SetName(LPCTSTR pszName)
{
	m_csName = pszName;
}

void CObjectInfo::SetStream(LPCTSTR pszStream)
{
	m_csStream = pszStream;
}

void CObjectInfo::SetObjectBroker(CObjectBroker* pObjectBroker)
{
	m_pObjectBroker = pObjectBroker;
}

CObjectBroker::CObjectBroker(LPCSTR pszDefaultObjectName, 
	LPCSTR pszObjectStorageName)
{
	m_pRootStorage = NULL;

	m_csDefaultObjectName = pszDefaultObjectName;
	m_csObjectStorageName = pszObjectStorageName;
}

CObjectBroker::~CObjectBroker()
{
	CString csKey;
	CObjectInfo* pObjectInfo;

	for (POSITION pos = m_mapObjectsByKey.GetStartPosition(); pos; )
	{
		m_mapObjectsByKey.GetNextAssoc(pos,csKey,(CObject*&)pObjectInfo);
		delete pObjectInfo;
	}
}

BOOL CObjectBroker::Add(REFCLSID rclsid, CString& rcsKey)
{
	CString csName, csStream;

	GenerateUniqueKey(rcsKey);
	GenerateUniqueName(csName);
	GenerateUniqueStream(csStream);
	
	CObjectInfo* pObjectInfo = new CObjectInfo;

	pObjectInfo->SetKey(rcsKey);
	pObjectInfo->SetName(csName);
	pObjectInfo->SetStream(csStream);
	pObjectInfo->SetObjectBroker(this);

	if(!pObjectInfo->SetClassID(rclsid))
	{
		delete pObjectInfo;
		return FALSE;
	}

	m_mapObjectsByKey.SetAt(rcsKey,pObjectInfo);
	m_mapObjectsByName.SetAt(csName,pObjectInfo);
	m_mapObjectsByStream.SetAt(csStream,pObjectInfo);

	NotifyObservers(OBJECT_BROKER_ADDED_OBJECT,&rcsKey);

	return TRUE;
}

void CObjectBroker::GenerateUniqueKey(CString& rcsKey)
{
	GUID guid;
	CoCreateGuid(&guid);

	LPOLESTR polestrRawKey = SysAllocStringLen(NULL,38);
	int nLength = StringFromGUID2(guid,polestrRawKey,39);
	ASSERT(nLength == 39);
	CString csRawKey = polestrRawKey;
	SysFreeString(polestrRawKey);

	rcsKey = csRawKey.Mid(1, 8)  +
			 csRawKey.Mid(10,4)  +
			 csRawKey.Mid(15,4)  +
			 csRawKey.Mid(20,4)  +
			 csRawKey.Mid(25,12);
}

void CObjectBroker::GenerateUniqueName(CString& rcsName)
{
	CObject* pObject;
	int nExtension = 0;
	do
	{
		rcsName.Format("%s%d",m_csDefaultObjectName,++nExtension);

	} while (m_mapObjectsByName.Lookup(rcsName,pObject)); 
}

void CObjectBroker::GenerateUniqueStream(CString& rcsStream)
{
	CObject* pObject;
	int nStream = 0;
	do
	{
		rcsStream.Format("%d",++nStream);

	} while (m_mapObjectsByStream.Lookup(rcsStream,pObject)); 
}

CObjectInfo* CObjectBroker::GetObjectInfoByKey(LPCTSTR pszKey) const
{
	CObjectInfo* pObjectInfo;
	if (m_mapObjectsByKey.Lookup(pszKey,(CObject*&)pObjectInfo))
		return pObjectInfo;
	else
		return NULL;
}

CObjectInfo* CObjectBroker::GetObjectInfoByName(LPCTSTR pszName) const
{
	CObjectInfo* pObjectInfo;
	if (m_mapObjectsByName.Lookup(pszName,(CObject*&)pObjectInfo))
		return pObjectInfo;
	else
		return NULL;
}

void CObjectBroker::GetNextAssoc(POSITION& rNextPosition, CString& rcsKey, 
		CObjectInfo*& rValue ) const
{
	m_mapObjectsByKey.GetNextAssoc(rNextPosition,rcsKey,(CObject*&)rValue);
}

POSITION CObjectBroker::GetStartPosition() const
{
	return m_mapObjectsByKey.GetStartPosition();
}

BOOL CObjectBroker::Remove(LPCTSTR pszKey)
{
	CString csKey = pszKey;
	CObjectInfo* pInfoObject = GetObjectInfoByKey(pszKey);

	if (!pInfoObject)
		return FALSE;

	NotifyObservers(OBJECT_BROKER_ABOUT_TO_REMOVE_OBJECT,&csKey);

	m_mapObjectsByKey.RemoveKey(pszKey);
	m_mapObjectsByName.RemoveKey(pInfoObject->GetName());
	m_mapObjectsByStream.RemoveKey(pInfoObject->GetStream());

	BSTR bstrObjectStream = pInfoObject->GetStream().AllocSysString();

	LPSTORAGE pObjectStorage = GetObjectStorage();
	HRESULT hr = pObjectStorage->DestroyElement(bstrObjectStream);
	ASSERT(SUCCEEDED(hr));

	SysFreeString(bstrObjectStream);
	pObjectStorage->Release();

	delete pInfoObject;

	NotifyObservers(OBJECT_BROKER_REMOVED_OBJECT,&csKey);

	return TRUE;
}

void CObjectBroker::Serialize(CArchive& archive)
{
	CObject::Serialize(archive);

	m_mapObjectsByKey.Serialize(archive);

	if (archive.IsStoring())
	{

	}
	else
	{
		CString csKey;
		CObjectInfo* pObjectInfo;

		for (POSITION pos = m_mapObjectsByKey.GetStartPosition(); pos; )
		{
			m_mapObjectsByKey.GetNextAssoc(pos,csKey,
				(CObject*&)pObjectInfo);
			m_mapObjectsByName.SetAt(pObjectInfo->GetName(),
				pObjectInfo);
			m_mapObjectsByStream.SetAt(pObjectInfo->GetStream(),
				pObjectInfo);
			pObjectInfo->SetObjectBroker(this);
		}
	}
}

BOOL CObjectBroker::SetName(LPCTSTR pszKey, LPCTSTR pszName)
{
	CString csKey = pszKey;
	CObjectInfo* pObjectInfo = GetObjectInfoByKey(pszKey);

	if (!pObjectInfo)
		return FALSE;

	CObjectInfo* pExistingInfoObject = GetObjectInfoByName(pszName);

	if (pExistingInfoObject && pExistingInfoObject != pObjectInfo)
		return FALSE;

	m_mapObjectsByName.RemoveKey(pObjectInfo->GetName());
	m_mapObjectsByName.SetAt(pszName,pObjectInfo);

	pObjectInfo->SetName(pszName);

	NotifyObservers(OBJECT_BROKER_RENAMED_OBJECT,&csKey);

	return TRUE;
}

void CObjectBroker::SetRootStorage(LPSTORAGE pRootStorage)
{
	if (m_pRootStorage == pRootStorage)
		return;

	BSTR bstrObjectStorage = m_csObjectStorageName.AllocSysString();

	if (m_pRootStorage == NULL)
	{
		LPSTORAGE pObjectStorage = NULL;

		m_pRootStorage = pRootStorage;

		if (FAILED(m_pRootStorage->OpenStorage(bstrObjectStorage,
			NULL,STGM_SHARE_EXCLUSIVE|STGM_READWRITE,
			NULL,0,&pObjectStorage)))

			m_pRootStorage->CreateStorage(bstrObjectStorage,
				STGM_SHARE_EXCLUSIVE|STGM_READWRITE,
				0,0,&pObjectStorage);
					
		pObjectStorage->Release();
	}
	else
	{

		m_pRootStorage->MoveElementTo(bstrObjectStorage,
			pRootStorage,bstrObjectStorage,STGMOVE_COPY);
		m_pRootStorage = pRootStorage;
	}

	SysFreeString(bstrObjectStorage);
}

LPSTORAGE CObjectBroker::GetObjectStorage()
{
	BSTR bstrObjectStorage = m_csObjectStorageName.AllocSysString();

	LPSTORAGE pObjectStorage = NULL;

	HRESULT hr = m_pRootStorage->OpenStorage(bstrObjectStorage,
		NULL,STGM_SHARE_EXCLUSIVE|STGM_READWRITE|STGM_TRANSACTED,
		NULL,0,&pObjectStorage);
	ASSERT(SUCCEEDED(hr));

	SysFreeString(bstrObjectStorage);

	return pObjectStorage;
}
