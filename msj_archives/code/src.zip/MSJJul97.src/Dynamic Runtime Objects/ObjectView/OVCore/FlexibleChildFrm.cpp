// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "FlexibleChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CFlexibleChildFrame, CNSFlexMDIChildWnd)

BEGIN_MESSAGE_MAP(CFlexibleChildFrame, CNSFlexMDIChildWnd)
	//{{AFX_MSG_MAP(CFlexibleChildFrame)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CFlexibleChildFrame::CFlexibleChildFrame()
{
	
}

CFlexibleChildFrame::~CFlexibleChildFrame()
{

}

BOOL CFlexibleChildFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if (CNSFlexMDIChildWnd::PreCreateWindow(cs) == 0)
		return FALSE;

	cs.style&=~(LONG)FWS_ADDTOTITLE;

	return TRUE;
}

#ifdef _DEBUG

void CFlexibleChildFrame::AssertValid() const
{
	CNSFlexMDIChildWnd::AssertValid();
}

void CFlexibleChildFrame::Dump(CDumpContext& dc) const
{
	CNSFlexMDIChildWnd::Dump(dc);
}

#endif //_DEBUG

