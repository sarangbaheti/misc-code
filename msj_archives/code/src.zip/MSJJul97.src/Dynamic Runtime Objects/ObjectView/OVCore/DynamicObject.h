// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __DynamicObject_h__
#define __DynamicObject_h__

#include "OVCoreAfxExt.h"

class CObjectBroker;
class CObjectInfo;

class AFX_EXT_OVCORE CDynamicObject : public CObject
{

  DECLARE_SERIAL(CDynamicObject);

  friend CObjectInfo;

  public:

	CDynamicObject();

	virtual ~CDynamicObject();

	ULONG AddRef();

	ULONG Release();

	CObjectBroker* GetObjectBroker() const;

	CObjectInfo* GetObjectInfo() const;

  public:

	virtual void OnCreatedNewObject();

	virtual void OnSerializedObjectFromArchive();

  private:

	void SetObjectInfo(CObjectInfo* pObjectInfo);

  private:

	ULONG m_nRefCount;

	CObjectInfo* m_pObjectInfo;

};

#endif
