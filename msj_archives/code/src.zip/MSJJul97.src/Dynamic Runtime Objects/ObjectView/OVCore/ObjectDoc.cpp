// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "ObjectApp.h"
#include "ObjectDoc.h"
#include "ObjectBroker.h"
#include "ClassBroker.h"
#include "ViewBroker.h"
#include "MultiDocTemplateEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CObjectDoc, COleDocument)

BEGIN_MESSAGE_MAP(CObjectDoc, COleDocument)
	//{{AFX_MSG_MAP(CObjectDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CObjectDoc::CObjectDoc()
{
	m_pObjectBroker = new CObjectBroker("Instance ","OBJECTS");
	m_pViewBroker = new CViewBroker(this,m_pObjectBroker);

	EnableCompoundFile();
}

CObjectDoc::~CObjectDoc()
{
	delete m_pViewBroker;
	delete m_pObjectBroker;
}

#ifdef _DEBUG

void CObjectDoc::AssertValid() const
{
	COleDocument::AssertValid();
}

#endif

#ifdef _DEBUG

void CObjectDoc::Dump(CDumpContext& dc) const
{
	COleDocument::Dump(dc);
}

#endif

CObjectBroker* CObjectDoc::GetObjectBroker() const
{
	return m_pObjectBroker;
}

CViewBroker* CObjectDoc::GetViewBroker() const
{
	return m_pViewBroker;	
}

BOOL CObjectDoc::OnNewDocument()
{
	if (!COleDocument::OnNewDocument())
		return FALSE;

	m_pObjectBroker->SetRootStorage(m_lpRootStg);

	return TRUE;
}

void CObjectDoc::Serialize(CArchive& ar)
{
	COleDocument::Serialize(ar);

	m_pObjectBroker->SetRootStorage(m_lpRootStg);
	m_pObjectBroker->Serialize(ar);
}

void CObjectDoc::WindowNew() 
{
	CFrameWnd* pFrameWnd = 
		((CFrameWnd*)(AfxGetApp()->m_pMainWnd))->GetActiveFrame();
	ASSERT(pFrameWnd);

	CView* pView = pFrameWnd->GetActiveView();
	ASSERT(pView);

	CString csObjectKey = m_pViewBroker->GetObjectKey(pView);
	ASSERT(!csObjectKey.IsEmpty());

	m_pViewBroker->OpenDuplicateView(csObjectKey);
}


void CObjectDoc::OnChangedViewList() 
{
	m_pViewBroker->DocViewListChanged();
	
	COleDocument::OnChangedViewList();
}
