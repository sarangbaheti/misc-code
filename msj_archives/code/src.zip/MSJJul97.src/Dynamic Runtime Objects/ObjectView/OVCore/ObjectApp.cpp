// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "ObjectApp.h"
#include "ClassBroker.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BEGIN_MESSAGE_MAP(CObjectApp, CWinApp)
	//{{AFX_MSG_MAP(CObjectApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CObjectApp::CObjectApp()
{

}

CObjectApp::~CObjectApp()
{
	CClassBroker::FreeMemory();
}

BOOL CObjectApp::InitInstance()
{
	if (CWinApp::InitInstance() == FALSE)
		return FALSE;

	CClassBroker::LoadDLLModules();

	return TRUE;
}
