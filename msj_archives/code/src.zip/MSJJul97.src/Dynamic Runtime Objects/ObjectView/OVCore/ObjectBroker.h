// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __ObjectBroker_h__
#define __ObjectBroker_h__

#include "OVCoreAfxExt.h"
#include "SubjectObserver.h"

#define OBJECT_BROKER_ADDED_OBJECT           1L
#define OBJECT_BROKER_ABOUT_TO_REMOVE_OBJECT 2L
#define OBJECT_BROKER_REMOVED_OBJECT         3L
#define OBJECT_BROKER_RENAMED_OBJECT         4L

class CObjectBroker;
class CClassInfo;
class CDynamicObject;

class AFX_EXT_OVCORE CObjectInfo : public CObject
{

  DECLARE_SERIAL(CObjectInfo);

  friend CObjectBroker;
  friend CDynamicObject;

  public:

	REFCLSID GetClassID() const;

	const CString& GetKey() const;

	const CString& GetName() const;

	const CString& GetStream() const;

	CObjectBroker* GetObjectBroker() const;

	CClassInfo* GetClassInfo() const;

	CDynamicObject* GetObject();

  private:

	CObjectInfo();

	virtual ~CObjectInfo();

	void StoreObject(BOOL bFreeMemory);

	BOOL SetClassID(REFCLSID rclsid);

	void SetKey(LPCTSTR pszKey);

	void SetName(LPCTSTR pszName);

	void SetStream(LPCTSTR pszStream);

	void SetObjectBroker(CObjectBroker* pObjectBroker);

	virtual void Serialize(CArchive& archive);  	

  private:

	CLSID m_clsid;

	CString m_csKey;

	CString m_csName;

	CString m_csStream;

	CObjectBroker* m_pObjectBroker;

	CDynamicObject* m_pDynamicObject;

};

class AFX_EXT_OVCORE CObjectBroker : public CObject, public CSubject
{

  public:

	CObjectBroker(LPCSTR pszDefaultObjectName, LPCSTR pszObjectStorageName);

	virtual ~CObjectBroker();

	BOOL Add(REFCLSID rclsid, CString& rcsKey);

	CObjectInfo* GetObjectInfoByKey(LPCTSTR pszKey) const;

	CObjectInfo* GetObjectInfoByName(LPCTSTR pszName) const;

	void GetNextAssoc(POSITION& rNextPosition, CString& rcsKey, 
		CObjectInfo*& rValue ) const;

	POSITION GetStartPosition() const;

	LPSTORAGE GetObjectStorage();

	BOOL Remove(LPCTSTR pszKey);

	virtual void Serialize(CArchive& archive); 
	
	BOOL SetName(LPCTSTR pszKey, LPCTSTR pszName);

	void SetRootStorage(LPSTORAGE pRootStorage);

  private:

	void GenerateUniqueKey(CString& rcsKey);

	void GenerateUniqueName(CString& rcsName);

	void GenerateUniqueStream(CString& rcsStream);


  private:

	CMapStringToOb m_mapObjectsByKey;

	CMapStringToOb m_mapObjectsByName;

	CMapStringToOb m_mapObjectsByStream;

	CString m_csDefaultObjectName;
	CString m_csObjectStorageName;

	LPSTORAGE m_pRootStorage;

};

#endif
