// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __ObjectView_h__
#define __ObjectView_h__

#include "ObjectApp.h"

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h" 

class CObjectViewApp : public CObjectApp
{

  public:

	CObjectViewApp();

	virtual ~CObjectViewApp();

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CObjectViewApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CObjectViewApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

};

#endif
