// AddInstanceDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAddInstanceDlg dialog

class CClassInfo;

class CAddInstanceDlg : public CDialog
{
// Construction
public:
	CAddInstanceDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAddInstanceDlg)
	enum { IDD = IDD_ADD_INSTANCE };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	CClassInfo* m_pClassInfo;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAddInstanceDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAddInstanceDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeObjects();
	afx_msg void OnDblclkObjects();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
