// NameInstanceDlg.cpp : implementation file
//

#include "stdafx.h"
#include "objectview.h"
#include "NameInstanceDlg.h"
#include "ObjectBroker.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNameInstanceDlg dialog


CNameInstanceDlg::CNameInstanceDlg(CObjectBroker* pObjectBroker, LPCSTR pszKey, CWnd* pParent /*=NULL*/)
	: CDialog(CNameInstanceDlg::IDD, pParent)
{
	m_csKey = pszKey;
	m_pObjectBroker = pObjectBroker;

	//{{AFX_DATA_INIT(CNameInstanceDlg)
	m_csName = 	pObjectBroker->GetObjectInfoByKey(m_csKey)->GetName();
	//}}AFX_DATA_INIT
}


void CNameInstanceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNameInstanceDlg)
	DDX_Text(pDX, IDC_NAME, m_csName);
	//}}AFX_DATA_MAP

	if (pDX->m_bSaveAndValidate)
	{
		if (m_csName != m_pObjectBroker->GetObjectInfoByKey(m_csKey)->
			GetName() && m_pObjectBroker->GetObjectInfoByName(m_csName))
		{
			AfxMessageBox("Duplicate name");
			pDX->Fail();
			return;
		}

	}
}


BEGIN_MESSAGE_MAP(CNameInstanceDlg, CDialog)
	//{{AFX_MSG_MAP(CNameInstanceDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNameInstanceDlg message handlers
