// AddInstanceDlg.cpp : implementation file
//

#include "stdafx.h"
#include "objectview.h"
#include "AddInstanceDlg.h"
#include "ClassBroker.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddInstanceDlg dialog


CAddInstanceDlg::CAddInstanceDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAddInstanceDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAddInstanceDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CAddInstanceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddInstanceDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddInstanceDlg, CDialog)
	//{{AFX_MSG_MAP(CAddInstanceDlg)
	ON_LBN_SELCHANGE(IDC_OBJECTS, OnSelchangeObjects)
	ON_LBN_DBLCLK(IDC_OBJECTS, OnDblclkObjects)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddInstanceDlg message handlers

BOOL CAddInstanceDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_pClassInfo = NULL;
	
	CListBox* pListBox = (CListBox*)GetDlgItem(IDC_OBJECTS);

	for (POSITION pos = CClassBroker::GetHeadPosition(); pos; )
	{
		CClassInfo* pClassInfo = CClassBroker::GetNext(pos);

		int nIndex = pListBox->AddString(pClassInfo->GetDescription());
		pListBox->SetItemDataPtr(nIndex,pClassInfo);
	}

	if(pListBox->SetCurSel(0) != LB_ERR)
		OnSelchangeObjects();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CAddInstanceDlg::OnSelchangeObjects() 
{
	CListBox* pListBox = (CListBox*)GetDlgItem(IDC_OBJECTS);

	m_pClassInfo = (CClassInfo*)pListBox->GetItemDataPtr(
		pListBox->GetCurSel());
	
}

void CAddInstanceDlg::OnDblclkObjects() 
{
	EndDialog(IDOK);	
}
