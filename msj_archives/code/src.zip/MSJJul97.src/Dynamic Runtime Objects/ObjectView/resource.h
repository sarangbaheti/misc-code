//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ObjectView.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_COMDEMO_FORM                101
#define IDD_COMBROKER_FORM              101
#define IDD_OBJECTBROKER_FORM           101
#define IDR_MAINFRAME                   128
#define IDR_OBVIEWTYPE                  129
#define IDD_ADD_INSTANCE                130
#define IDD_NAME_INSTANCE               131
#define IDC_COMOBJECTS                  1000
#define IDC_OBJECTS                     1000
#define IDC_ADD                         1001
#define IDC_REMOVE                      1002
#define IDC_VIEW                        1003
#define IDC_NAME                        1004
#define ID_WINDOW_OBJECTBROKER          32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
