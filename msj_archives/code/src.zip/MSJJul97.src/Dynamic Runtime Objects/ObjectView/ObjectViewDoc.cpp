// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "ObjectView.h"
#include "ObjectViewDoc.h"
#include "ObjectBroker.h"
#include "ViewBroker.h"
#include "MultiDocTemplateEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CObjectViewDoc, CObjectDoc)

BEGIN_MESSAGE_MAP(CObjectViewDoc, CObjectDoc)
	//{{AFX_MSG_MAP(CObjectViewDoc)
	ON_COMMAND(ID_WINDOW_OBJECTBROKER, OnWindowObjectBroker)
	ON_COMMAND(ID_WINDOW_NEW, OnWindowNew)
	ON_UPDATE_COMMAND_UI(ID_WINDOW_NEW, OnUpdateWindowNew)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CObjectViewDoc::CObjectViewDoc()
{
	m_pObjectBrokerWnd = NULL;
}

CObjectViewDoc::~CObjectViewDoc()
{

}

#ifdef _DEBUG

void CObjectViewDoc::AssertValid() const
{
	CObjectDoc::AssertValid();
}

#endif

#ifdef _DEBUG

void CObjectViewDoc::Dump(CDumpContext& dc) const
{
	CObjectDoc::Dump(dc);
}

#endif

BOOL CObjectViewDoc::OnNewDocument()
{
	if (!CObjectDoc::OnNewDocument())
		return FALSE;

	return TRUE;
}

void CObjectViewDoc::Serialize(CArchive& ar)
{
	CObjectDoc::Serialize(ar);
}

void CObjectViewDoc::OnWindowObjectBroker() 
{
	if (m_pObjectBrokerWnd)
	{
		if (m_pObjectBrokerWnd->IsIconic())
			m_pObjectBrokerWnd->MDIRestore();

		m_pObjectBrokerWnd->MDIActivate();
		return;
	}

	CObjectViewApp* pApp = (CObjectViewApp*)AfxGetApp();
	CMultiDocTemplateEx* pDocTemplate = (CMultiDocTemplateEx*)GetDocTemplate();
	m_pObjectBrokerWnd = (CMDIChildWnd*)pDocTemplate->
		CreateNewFrame(this,NULL);
	pDocTemplate->InitialUpdateFrame(m_pObjectBrokerWnd,this);
}

void CObjectViewDoc::OnUpdateWindowNew(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!(((CFrameWnd*)(AfxGetApp()->m_pMainWnd))->
		GetActiveFrame() ==	m_pObjectBrokerWnd));
}

void CObjectViewDoc::OnWindowNew() 
{
	WindowNew();
}

