// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __RotorDriver_h__
#define __RotorDriver_h__

#include "SubjectObserver.h"
#include "DynamicObject.h"

class CThreadMessageWnd;
class CTriggerThreadInfo;
class CGenericRotor;

#define ROTOR_DRIVER_PARAMETERS_CHANGED     1L
#define ROTOR_DRIVER_POSITION_CHANGED       2L
#define ROTOR_DRIVER_STARTED                3L
#define ROTOR_DRIVER_STOPPED                4L
#define ROTOR_DRIVER_ROTOR_CHANGED          5L
#define ROTOR_DRIVER_SELECTED_ROTOR_CHANGED 6L

class CRotorDriver : public CDynamicObject, public CSubject, public CObserver
{

  DECLARE_SERIAL(CRotorDriver);

  friend CThreadMessageWnd;

  public:

	CRotorDriver();

	virtual ~CRotorDriver();

	void DrawRotor(CDC *pDC, int nRadius, int nAngle) const;

	BOOL GetRotateClockwise() const;

	int GetRotationIncrement() const;

	const CString& GetRotorKey() const;

	int GetRotorPosition() const;

	int GetUpdateInterval() const;

	BOOL IsRotorGoing() const;

	virtual void Serialize(CArchive& archive); 

	void SetRotateClockwise(BOOL bRotateClockwise);

	void SetRotationIncrement(int nRotationIncrement);

	void SetRotorKey(LPCSTR pszRotorKey);

	void SetUpdateInterval(int nUpdateInterval);

	virtual void SubjectChanged(CSubject* pSubject,	LPARAM lHint, void* pHint);

	void StartRotor();

	void StopRotor();

  protected:

	virtual void OnCreatedNewObject();

	virtual void OnSerializedObjectFromArchive();

  private:

	void AttachToRotor();

	void AttachToObjectBroker();

	void DetachFromRotor();

	void DetachFromObjectBroker();

	void Trigger();

  private:

	CWinThread* m_pTriggerThread;

	CTriggerThreadInfo* m_pTriggerThreadInfo;

	BOOL m_bRotorIsGoing;

	int m_nRotationIncrement;

	int m_nUpdateInterval;

	int m_nRotorPosition;

	BOOL m_bRotateClockwise;

	CString m_csRotorKey;

	CGenericRotor* m_pRotor;

};

#endif
