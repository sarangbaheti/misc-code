// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "ThreadMessageWnd.h"
#include "RotorDriver.h"
#include "Trigger.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CThreadMessageWnd::CThreadMessageWnd(CRotorDriver* pRotorDriver)
{
	m_pRotorDriver = pRotorDriver;
}

CThreadMessageWnd::~CThreadMessageWnd()
{

}

BEGIN_MESSAGE_MAP(CThreadMessageWnd, CWnd)
	//{{AFX_MSG_MAP(CThreadMessageWnd)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_TRIGGER,OnTrigger)
END_MESSAGE_MAP()

LRESULT CThreadMessageWnd::OnTrigger(WPARAM wParam, LPARAM lParam)
{
	m_pRotorDriver->Trigger();
	return 1;
}
