#define WM_TRIGGER  (WM_USER + 0x1000)

class CThreadMessageWnd;

class CTriggerThreadInfo 
{

  public:

	CThreadMessageWnd* m_pThreadMessageWnd;

	int m_nUpdateInterval;

	HANDLE m_hEventKillTriggerThread;
	HANDLE m_hEventTriggerThreadKilled;
	HANDLE m_hEventStartInterval;

};
