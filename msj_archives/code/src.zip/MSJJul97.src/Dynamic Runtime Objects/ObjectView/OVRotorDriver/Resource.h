//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OVRotorDriver.rc
//
#define IDD_PROPERTIES                  510
#define IDD_ROTOR_DRIVER_FORM           511
#define IDC_LOCATOR                     1000
#define IDC_ROTORS                      1000
#define IDC_PROPERTIES                  1002
#define IDC_UPDATE                      1003
#define IDC_ROTATION                    1004
#define IDC_ROTOR                       1005
#define IDC_UPDATE_LABEL                1006
#define IDC_ROTATION_LABEL              1007
#define IDC_START                       1008
#define IDC_ROTOR_LABEL                 1009
#define IDC_CLOCKWISE                   1010
#define IDC_COUNTERCLOCK                1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
