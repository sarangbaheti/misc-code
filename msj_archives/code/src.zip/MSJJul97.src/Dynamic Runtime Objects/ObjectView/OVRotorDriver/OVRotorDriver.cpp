// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include <afxdllx.h>
#include "RotorDriver.h"
#include "RotorDriverView.h"
#include "FlexibleChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static AFX_EXTENSION_MODULE OVRotorDriverDLL = { NULL, NULL };

extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	if (dwReason == DLL_PROCESS_ATTACH)
	{
		TRACE0("OVROTORDRIVER.DLL Initializing!\n");
		
		// Extension DLL one-time initialization
		AfxInitExtensionModule(OVRotorDriverDLL, hInstance);

		// Insert this DLL into the resource chain
		new CDynLinkLibrary(OVRotorDriverDLL);
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		TRACE0("OVROTORDRIVER.DLL Terminating!\n");

        AfxTermExtensionModule(OVRotorDriverDLL);
	}
	return 1;   // ok
}

extern "C" void WINAPI ClassInfo(CLSID& clsidClassID, 
	CLSID& clsidClassCategory, CString& csDescription,
	CRuntimeClass*& pObjectClass, CRuntimeClass*& pFrameClass,
	CRuntimeClass*& pViewClass)
{
	// ID: {E87BEED3-6735-11d0-A23E-0040052E01FC}
	CLSID clsidID = { 0xe87beed3, 0x6735, 0x11d0, 
		{ 0xa2, 0x3e, 0x0, 0x40, 0x5, 0x2e, 0x1, 0xfc } };

	// CATEGORY: {42B72BA1-90D2-11d0-A264-0040052E01FC}
	CLSID clsidCategory = { 0x42b72ba1, 0x90d2, 0x11d0, 
		{ 0xa2, 0x64, 0x0, 0x40, 0x5, 0x2e, 0x1, 0xfc } };

	clsidClassID = clsidID;
	clsidClassCategory = clsidCategory;

	csDescription = "Rotor Driver";

	pObjectClass = RUNTIME_CLASS(CRotorDriver);
	pFrameClass = RUNTIME_CLASS(CFlexibleChildFrame);
	pViewClass = RUNTIME_CLASS(CRotorDriverView);
}
