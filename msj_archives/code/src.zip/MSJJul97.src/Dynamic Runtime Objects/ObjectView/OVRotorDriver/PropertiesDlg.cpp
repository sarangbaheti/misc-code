// PropertiesDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Resource.h"
#include "PropertiesDlg.h"
#include "RotorDriver.h"
#include "ObjectBroker.h"
#include "Rotor.h"
#include "ClassBroker.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropertiesDlg dialog


CPropertiesDlg::CPropertiesDlg(CRotorDriver* pRotorDriver, CWnd* pParent /*=NULL*/)
	: CDialog(CPropertiesDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPropertiesDlg)
	m_nClockwise = !pRotorDriver->GetRotateClockwise();
	m_nUpdateInterval = pRotorDriver->GetUpdateInterval();
	m_nRotationIncrement = pRotorDriver->GetRotationIncrement();
	//}}AFX_DATA_INIT

	m_pRotorDriver = pRotorDriver;
}


void CPropertiesDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropertiesDlg)
	DDX_Radio(pDX, IDC_CLOCKWISE, m_nClockwise);
	DDX_Text(pDX, IDC_ROTATION, m_nRotationIncrement);
	DDV_MinMaxInt(pDX, m_nRotationIncrement, 1, 359);
	DDX_Text(pDX, IDC_UPDATE, m_nUpdateInterval);
	DDV_MinMaxInt(pDX, m_nUpdateInterval, 0, 10000);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropertiesDlg, CDialog)
	//{{AFX_MSG_MAP(CPropertiesDlg)
	ON_CBN_SELCHANGE(IDC_ROTORS, OnSelchangeRotors)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropertiesDlg message handlers

BOOL CPropertiesDlg::OnInitDialog() 
{
	// ROTOR CLASS CATEGORY: {A8D09C01-90C4-11d0-A264-0040052E01FC}
	CLSID clsidRotorClassCategory = { 0xa8d09c01, 0x90c4, 0x11d0, 
		{ 0xa2, 0x64, 0x0, 0x40, 0x5, 0x2e, 0x1, 0xfc } };

	CComboBox* pRotors = (CComboBox*)GetDlgItem(IDC_ROTORS);
	
	CObjectBroker* pObjectBroker = m_pRotorDriver->GetObjectBroker();

	for (POSITION pos = pObjectBroker->GetStartPosition(); pos; )
	{
		CString csKey;
		CObjectInfo* pObjectInfo;

		pObjectBroker->GetNextAssoc(pos,csKey,pObjectInfo);

		CClassInfo* pClassInfo = CClassBroker::GetClassInfo(
			pObjectInfo->GetClassID());

		if (pClassInfo->GetClassCategory() == clsidRotorClassCategory)
		{
			int nIndex = pRotors->AddString(pObjectInfo->GetName());
			pRotors->SetItemDataPtr(nIndex,pObjectInfo);
			if (m_pRotorDriver->GetRotorKey() == pObjectInfo->GetKey())
			{
				pRotors->SetCurSel(nIndex);
				m_csRotorKey = pObjectInfo->GetKey();
			}
		}

	}

	pRotors->InsertString(0,"<None>");
	if (pRotors->GetCurSel() == CB_ERR)
		pRotors->SetCurSel(0);

	CDialog::OnInitDialog();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPropertiesDlg::OnSelchangeRotors() 
{
	CComboBox* pRotors = (CComboBox*)GetDlgItem(IDC_ROTORS);

	int nIndex = pRotors->GetCurSel();
	if (nIndex == 0)
		m_csRotorKey.Empty();
	else
		m_csRotorKey = ((CObjectInfo*)(pRotors->GetItemDataPtr(nIndex)))->
			GetKey();
}
