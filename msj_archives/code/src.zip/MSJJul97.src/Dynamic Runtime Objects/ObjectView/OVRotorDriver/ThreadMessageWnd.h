// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __ThreadMessageWnd_h__
#define __ThreadMessageWnd_h__

class CRotorDriver;

class CThreadMessageWnd : public CWnd
{

  public:

	CThreadMessageWnd(CRotorDriver* pRotorDriver);

	virtual ~CThreadMessageWnd();

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CThreadMessageWnd)
	//}}AFX_VIRTUAL

  protected:

	//{{AFX_MSG(CThreadMessageWnd)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

    afx_msg LRESULT OnTrigger(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()

  private:

	CRotorDriver* m_pRotorDriver;

};

#endif

