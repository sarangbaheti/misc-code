// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __RotorDriverView_h__
#define __RotorDriverView_h__

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "Resource.h"
#include "NSFlexFormView.h"
#include "SubjectObserver.h"

class CRotorDriver;
class CObjectBroker;

class CRotorDriverView : public CNSFlexFormView, public CObserver
{

	DECLARE_DYNCREATE(CRotorDriverView)

  public:

	int SetupDC(CDC *pdc);

	void DrawGrid(CDC *pdc, int nRadius);
	
	void SetControls();

	virtual void SubjectChanged(CSubject* pSubject, LPARAM lHint, void* pHint);

	//{{AFX_DATA(CRotorDriverView)
	enum { IDD = IDD_ROTOR_DRIVER_FORM };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRotorDriverView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX); 
	virtual void OnDraw(CDC* pDC);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

  protected:

	CRotorDriverView(); 

	virtual ~CRotorDriverView();

#ifdef _DEBUG

	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;

#endif

	// Generated message map functions
	//{{AFX_MSG(CRotorDriverView)
	afx_msg void OnProperties();
	afx_msg void OnStart();
	//}}AFX_MSG

    afx_msg LRESULT OnObjectInfo(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()

  private:

	CRotorDriver* m_pRotorDriver;

	CObjectBroker* m_pObjectBroker;

	BOOL m_bNeedControlsUpdate;

};

#endif

