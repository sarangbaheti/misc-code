// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "RotorDriver.h"
#include "Trigger.h"
#include "ThreadMessageWnd.h"
#include "ObjectBroker.h"
#include "GenericRotor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

UINT TriggerThreadProc(LPVOID pParam)
{
	CTriggerThreadInfo* pTriggerThreadInfo = (CTriggerThreadInfo*)pParam;

	while (TRUE)
	{

		if (WaitForSingleObject(pTriggerThreadInfo->m_hEventStartInterval,
			INFINITE)!= WAIT_OBJECT_0)
			break;

		if (WaitForSingleObject(pTriggerThreadInfo->m_hEventKillTriggerThread,
			0) == WAIT_OBJECT_0)
			break; 

		Sleep(pTriggerThreadInfo->m_nUpdateInterval);

		pTriggerThreadInfo->m_pThreadMessageWnd->PostMessage(WM_TRIGGER);
	}

	SetEvent(pTriggerThreadInfo->m_hEventTriggerThreadKilled);

	return 0;
}

IMPLEMENT_SERIAL(CRotorDriver,CDynamicObject,1)

CRotorDriver::CRotorDriver()
{
	m_bRotorIsGoing = FALSE;
	m_nRotationIncrement = 30;
	m_nUpdateInterval = 1000;
	m_nRotorPosition = 0;
	m_bRotateClockwise = TRUE;

	m_pRotor = NULL;

	m_pTriggerThreadInfo = new CTriggerThreadInfo;

	m_pTriggerThreadInfo->m_pThreadMessageWnd =
		new CThreadMessageWnd(this);

	BOOL bret = m_pTriggerThreadInfo->m_pThreadMessageWnd->
		CreateEx(NULL,AfxRegisterWndClass(NULL),NULL,NULL,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		CW_USEDEFAULT,NULL,NULL);
	ASSERT(bret);

	m_pTriggerThreadInfo->m_hEventKillTriggerThread =
		CreateEvent(NULL, FALSE, FALSE, NULL); 
	m_pTriggerThreadInfo->m_hEventTriggerThreadKilled = 
		CreateEvent(NULL, FALSE, FALSE, NULL);
	m_pTriggerThreadInfo->m_hEventStartInterval = 
		CreateEvent(NULL, FALSE, FALSE, NULL);
}

CRotorDriver::~CRotorDriver()
{
	DWORD dwExitCode;
	if (GetExitCodeThread(m_pTriggerThread->m_hThread, &dwExitCode) &&
		dwExitCode == STILL_ACTIVE)
	{
		SetEvent(m_pTriggerThreadInfo->m_hEventKillTriggerThread);
		SetEvent(m_pTriggerThreadInfo->m_hEventStartInterval);
		WaitForSingleObject(
			m_pTriggerThreadInfo->m_hEventTriggerThreadKilled,INFINITE);
	}

	delete m_pTriggerThreadInfo->m_pThreadMessageWnd;
	delete m_pTriggerThreadInfo;

	DetachFromRotor();
	DetachFromObjectBroker();
}

void CRotorDriver::Serialize(CArchive& archive)
{

	if (archive.IsStoring())
	{
		archive << m_bRotorIsGoing;
		archive << m_nRotationIncrement;
		archive << m_nUpdateInterval;
		archive << m_nRotorPosition;
		archive << m_bRotateClockwise;
		archive << m_csRotorKey;
	}
	else
	{
		archive >> m_bRotorIsGoing;
		archive >> m_nRotationIncrement;
		archive >> m_nUpdateInterval;
		archive >> m_nRotorPosition;
		archive >> m_bRotateClockwise;
		archive >> m_csRotorKey;
	}

}

void CRotorDriver::OnCreatedNewObject()
{
	AttachToObjectBroker();
	AttachToRotor();

	m_pTriggerThreadInfo->m_nUpdateInterval = m_nUpdateInterval;

	m_pTriggerThread =
	AfxBeginThread(TriggerThreadProc,m_pTriggerThreadInfo);
	ASSERT(m_pTriggerThread);
}

void CRotorDriver::OnSerializedObjectFromArchive()
{
	AttachToObjectBroker();
	AttachToRotor();

	m_pTriggerThreadInfo->m_nUpdateInterval = m_nUpdateInterval;

	m_pTriggerThread =
	AfxBeginThread(TriggerThreadProc,m_pTriggerThreadInfo);
	ASSERT(m_pTriggerThread);

	if (m_bRotorIsGoing)
		SetEvent(m_pTriggerThreadInfo->m_hEventStartInterval);
}

void CRotorDriver::AttachToObjectBroker()
{
	GetObjectBroker()->AttachToSubject(this);
}

void CRotorDriver::DetachFromObjectBroker()
{
	GetObjectBroker()->DetachFromSubject(this);
}

void CRotorDriver::AttachToRotor()
{
	DetachFromRotor();

	CObjectInfo* pObjectInfo = 
		GetObjectBroker()->GetObjectInfoByKey(m_csRotorKey);

	if (pObjectInfo)
	{
		m_pRotor = (CGenericRotor*)pObjectInfo->GetObject();
		m_pRotor->AttachToSubject(this);
	}
	else
	{
		m_csRotorKey.Empty();
	}
}

void CRotorDriver::DetachFromRotor()
{
	if (m_pRotor)
	{
		m_pRotor->DetachFromSubject(this);
		m_pRotor->Release();
		m_pRotor = NULL;
	}
}

BOOL CRotorDriver::GetRotateClockwise() const
{
	return m_bRotateClockwise;
}

int CRotorDriver::GetRotationIncrement() const
{
	return m_nRotationIncrement;
}

int CRotorDriver::GetUpdateInterval() const
{
	return m_nUpdateInterval;
}

BOOL CRotorDriver::IsRotorGoing() const
{
	return m_bRotorIsGoing;
}

int CRotorDriver::GetRotorPosition() const
{
	return m_nRotorPosition;
}

const CString& CRotorDriver::GetRotorKey() const
{
	return m_csRotorKey;
}

void CRotorDriver::SetRotationIncrement(int nRotationIncrement)
{
	ASSERT(nRotationIncrement > 0 && nRotationIncrement < 360);

	m_nRotationIncrement = nRotationIncrement;

	NotifyObservers(ROTOR_DRIVER_PARAMETERS_CHANGED,NULL);
}

void CRotorDriver::SetUpdateInterval(int nUpdateInterval)
{
	ASSERT(nUpdateInterval >= 0);

	m_nUpdateInterval = nUpdateInterval;

	m_pTriggerThreadInfo->m_nUpdateInterval = m_nUpdateInterval;

	NotifyObservers(ROTOR_DRIVER_PARAMETERS_CHANGED,NULL);
}

void CRotorDriver::StartRotor()
{
	if (m_bRotorIsGoing)
		return;

	m_bRotorIsGoing = TRUE;

	NotifyObservers(ROTOR_DRIVER_STARTED,NULL);

	SetEvent(m_pTriggerThreadInfo->m_hEventStartInterval);
}

void CRotorDriver::StopRotor()
{
	if (!m_bRotorIsGoing)
		return;

	m_bRotorIsGoing = FALSE;

	NotifyObservers(ROTOR_DRIVER_STOPPED,NULL);
}

void CRotorDriver::Trigger()
{
	if (m_bRotateClockwise)
		m_nRotorPosition -= m_nRotationIncrement;
	else
		m_nRotorPosition += m_nRotationIncrement;

	if (m_nRotorPosition >= 360)
		m_nRotorPosition -= 360;
	if (m_nRotorPosition < 0)
		m_nRotorPosition += 360;

	NotifyObservers(ROTOR_DRIVER_POSITION_CHANGED,NULL);

	if (m_bRotorIsGoing)
		SetEvent(m_pTriggerThreadInfo->m_hEventStartInterval);
}

void CRotorDriver::SetRotateClockwise(BOOL bRotateClockwise)
{
	m_bRotateClockwise = bRotateClockwise;

	NotifyObservers(ROTOR_DRIVER_PARAMETERS_CHANGED,NULL);
}

void CRotorDriver::SetRotorKey(LPCSTR pszRotorKey)
{
	m_csRotorKey = pszRotorKey;

	AttachToRotor();

	NotifyObservers(ROTOR_DRIVER_SELECTED_ROTOR_CHANGED,NULL);
}

void CRotorDriver::SubjectChanged(CSubject* pSubject, LPARAM lHint, void* pHint)
{
	if (pSubject == m_pRotor)
	{
		switch(lHint)
		{
			case ROTOR_CHANGED:
				NotifyObservers(ROTOR_DRIVER_ROTOR_CHANGED,NULL);
				return;
		}

		ASSERT(FALSE);
	}

	if (pSubject == GetObjectBroker())
	{
		switch(lHint)
		{
			case OBJECT_BROKER_ABOUT_TO_REMOVE_OBJECT:
				if (m_csRotorKey == *((CString*)pHint))
					SetRotorKey("");
				return;
			
			case OBJECT_BROKER_ADDED_OBJECT:
			case OBJECT_BROKER_REMOVED_OBJECT:
			case OBJECT_BROKER_RENAMED_OBJECT:
				return;
		}

		ASSERT(FALSE);
	}

	ASSERT(FALSE);
}

#define OUTSIDE_TO_INSIDE_RADIUS 0.9

void CRotorDriver::DrawRotor(CDC *pDC, int nRadius, int nAngle) const
{
	if (m_pRotor)
	{
		m_pRotor->DrawRotor(pDC,nRadius,nAngle);
		return;
	}
	else
	{
		CPen OutlinePen;
		OutlinePen.CreatePen(PS_SOLID,0,RGB(0,0,0));

		CBrush ExteriorBrush;
		ExteriorBrush.CreateSolidBrush(RGB(255,255,255));

		CPen* pPreviousPen = pDC->SelectObject(&OutlinePen);
		CBrush* pPreviousBrush = pDC->SelectObject(&ExteriorBrush);

		nRadius = (int)(OUTSIDE_TO_INSIDE_RADIUS*nRadius);

		pDC->Ellipse(-nRadius,nRadius,nRadius,-nRadius);

		pDC->SelectObject(pPreviousPen);
		pDC->SelectObject(pPreviousBrush);

	}
}

