// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "RotorDriverView.h"
#include "RotorDriver.h"
#include "ObjectBroker.h"
#include "ObjectInfoMessage.h"
#include "math.h"
#include "PropertiesDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CRotorDriverView, CNSFlexFormView)

BEGIN_MESSAGE_MAP(CRotorDriverView, CNSFlexFormView)
	//{{AFX_MSG_MAP(CRotorDriverView)
	ON_BN_CLICKED(IDC_PROPERTIES, OnProperties)
	ON_BN_CLICKED(IDC_START, OnStart)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_OBJECTINFO,OnObjectInfo)
END_MESSAGE_MAP()

CRotorDriverView::CRotorDriverView()
	: CNSFlexFormView(CRotorDriverView::IDD)
{
	//{{AFX_DATA_INIT(CRotorDriverView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_pRotorDriver = NULL;
	m_pObjectBroker = NULL;

	AddFlexConstraint(IDC_LOCATOR,        
		NSFlexExpandRight,   NSFlexExpandDown);
	AddFlexConstraint(IDC_UPDATE,         
		NSFlexHorizontallyFixed, NSFlexShiftDown); 
	AddFlexConstraint(IDC_ROTOR_LABEL,        
		NSFlexHorizontallyFixed, NSFlexShiftDown); 
	AddFlexConstraint(IDC_ROTOR,        
		NSFlexHorizontallyFixed, NSFlexShiftDown); 
	AddFlexConstraint(IDC_UPDATE_LABEL,   
		NSFlexHorizontallyFixed, NSFlexShiftDown); 
	AddFlexConstraint(IDC_ROTATION,       
		NSFlexHorizontallyFixed, NSFlexShiftDown);
	AddFlexConstraint(IDC_ROTATION_LABEL, 
		NSFlexHorizontallyFixed, NSFlexShiftDown); 
	AddFlexConstraint(IDC_PROPERTIES,     
		NSFlexHorizontallyFixed, NSFlexShiftDown); 
	AddFlexConstraint(IDC_START,          
		NSFlexHorizontallyFixed, NSFlexShiftDown); 
}

CRotorDriverView::~CRotorDriverView()
{
	m_pRotorDriver->DetachFromSubject(this);
	m_pObjectBroker->DetachFromSubject(this);
	m_pRotorDriver->Release();
}

void CRotorDriverView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRotorDriverView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

#ifdef _DEBUG
void CRotorDriverView::AssertValid() const
{
	CNSFlexFormView::AssertValid();
}

void CRotorDriverView::Dump(CDumpContext& dc) const
{
	CNSFlexFormView::Dump(dc);
}
#endif //_DEBUG

LRESULT CRotorDriverView::OnObjectInfo(WPARAM wParam, LPARAM lParam)
{
	ObjectInfoMessage* pObjectInfoMessage = (ObjectInfoMessage*)(lParam);

	m_pObjectBroker = pObjectInfoMessage->pObjectBroker;

	CObjectInfo* pObjectInfo = 
		m_pObjectBroker->GetObjectInfoByKey(pObjectInfoMessage->pszObjectKey);
	ASSERT(pObjectInfo);

	m_pRotorDriver = (CRotorDriver*)pObjectInfo->GetObject();
	ASSERT(m_pRotorDriver);
	ASSERT(m_pRotorDriver->IsKindOf(RUNTIME_CLASS(CRotorDriver)));

	m_pRotorDriver->AttachToSubject(this);
	m_pObjectBroker->AttachToSubject(this);

	return 1;
}

void CRotorDriverView::OnInitialUpdate() 
{
	m_bNeedControlsUpdate = FALSE;

	CNSFlexFormView::OnInitialUpdate();

	CWnd* pLocatorWnd = GetDlgItem(IDC_LOCATOR);
	pLocatorWnd->ShowWindow(SW_HIDE);
	
	SetControls();
}

void CRotorDriverView::SubjectChanged(CSubject* pSubject, 
	LPARAM lHint, void* pHint)
{

	if(pSubject == m_pRotorDriver)
	{

		switch(lHint)
		{

		  case ROTOR_DRIVER_PARAMETERS_CHANGED:
		  case ROTOR_DRIVER_STARTED:
		  case ROTOR_DRIVER_STOPPED:
			m_bNeedControlsUpdate = TRUE;
			return;

		  case ROTOR_DRIVER_SELECTED_ROTOR_CHANGED:
			m_bNeedControlsUpdate = TRUE;
		  case ROTOR_DRIVER_ROTOR_CHANGED:
		  case ROTOR_DRIVER_POSITION_CHANGED:
			CDC* pDC = GetDC();
			int nRadius = SetupDC(pDC);
			m_pRotorDriver->DrawRotor(pDC,nRadius,m_pRotorDriver->GetRotorPosition());
			ReleaseDC(pDC);
			return;

		}

		ASSERT(FALSE);
	}

	if(pSubject == m_pObjectBroker)
	{

		switch(lHint)
		{

		  case OBJECT_BROKER_ADDED_OBJECT:
		  case OBJECT_BROKER_ABOUT_TO_REMOVE_OBJECT:
		  case OBJECT_BROKER_REMOVED_OBJECT:
			return;

		  case OBJECT_BROKER_RENAMED_OBJECT:
			m_bNeedControlsUpdate = TRUE;
			return;

		}

		ASSERT(FALSE);
	}

	ASSERT(FALSE);
}

void CRotorDriverView::OnDraw(CDC* pDC) 
{
	CNSFlexFormView::OnDraw(pDC);

	int nRadius = SetupDC(pDC);
	DrawGrid(pDC,nRadius);
	m_pRotorDriver->DrawRotor(pDC,nRadius,m_pRotorDriver->GetRotorPosition());
}

int CRotorDriverView::SetupDC(CDC *pdc)
{
	CWnd* pLocatorWnd = GetDlgItem(IDC_LOCATOR);

	CRect rectMM_TEXT_Locator;
	pLocatorWnd->GetWindowRect(&rectMM_TEXT_Locator);
	ScreenToClient(rectMM_TEXT_Locator);
	CPoint pointMM_TEXT_Center = rectMM_TEXT_Locator.CenterPoint();

	pdc->SetMapMode(MM_HIMETRIC);
	pdc->SetViewportOrg(pointMM_TEXT_Center.x,
		pointMM_TEXT_Center.y);

	CSize sizeMM_HIMETRICLocator = rectMM_TEXT_Locator.Size();
	pdc->DPtoHIMETRIC(&sizeMM_HIMETRICLocator);

	int nRadius = min(sizeMM_HIMETRICLocator.cx,
		sizeMM_HIMETRICLocator.cy) / 2;

	return nRadius;
}

#define DEGREES_TO_RADIANS 0.01745
#define OUTSIDE_TO_INSIDE_RADIUS 0.9

void CRotorDriverView::DrawGrid(CDC *pdc, int nRadius)
{
	CPen OutlinePen;
	OutlinePen.CreatePen(PS_SOLID,0,RGB(0,0,0));

	CBrush ExteriorBrush1;
	ExteriorBrush1.CreateSolidBrush(RGB(0,0,255));

	CBrush ExteriorBrush2;
	ExteriorBrush2.CreateSolidBrush(RGB(255,255,0));

	CBrush InteriorBrush;
	InteriorBrush.CreateSolidBrush(RGB(255,255,255));

	CPen* pPreviousPen = pdc->SelectObject(&OutlinePen);
	CBrush* pPreviousBrush = pdc->SelectObject(&ExteriorBrush1);

	for (int ii = 0; ii <= 11; ii++)
	{
		double dAngle1 = DEGREES_TO_RADIANS*(ii*2*15.0);
		double dAngle2 = DEGREES_TO_RADIANS*((ii*2+1)*15.0);

		int nX1 = (int)(nRadius*cos(dAngle1));
		int nY1 = (int)(nRadius*sin(dAngle1));
		int nX2 = (int)(nRadius*cos(dAngle2));
		int nY2 = (int)(nRadius*sin(dAngle2));

		pdc->Pie(-nRadius,nRadius,nRadius,-nRadius,nX1,nY1,nX2,nY2);
	}

	pdc->SelectObject(&ExteriorBrush2);

	for (ii = 0; ii <= 11; ii++)
	{
		double dAngle1 = DEGREES_TO_RADIANS*((ii*2+1)*15.0);
		double dAngle2 = DEGREES_TO_RADIANS*((ii*2+2)*15.0);

		int nX1 = (int)(nRadius*cos(dAngle1));
		int nY1 = (int)(nRadius*sin(dAngle1));
		int nX2 = (int)(nRadius*cos(dAngle2));
		int nY2 = (int)(nRadius*sin(dAngle2));

		pdc->Pie(-nRadius,nRadius,nRadius,-nRadius,nX1,nY1,nX2,nY2);
	}

	pdc->SelectObject(&InteriorBrush);
	int nInsideRadius = (int)(OUTSIDE_TO_INSIDE_RADIUS * nRadius);
	pdc->Ellipse(-nInsideRadius,nInsideRadius,nInsideRadius,-nInsideRadius);

	pdc->SelectObject(pPreviousPen);
	pdc->SelectObject(pPreviousBrush);
}

void CRotorDriverView::OnProperties() 
{
	CPropertiesDlg dlgProperties(m_pRotorDriver);

	if (dlgProperties.DoModal() == IDOK)
	{
		m_pRotorDriver->SetRotateClockwise(!dlgProperties.m_nClockwise);
		m_pRotorDriver->SetRotationIncrement(dlgProperties.m_nRotationIncrement);
		m_pRotorDriver->SetUpdateInterval(dlgProperties.m_nUpdateInterval);
		m_pRotorDriver->SetRotorKey(dlgProperties.m_csRotorKey);

		GetDocument()->SetModifiedFlag();
		GetDocument()->UpdateAllViews(NULL);
	}
}

void CRotorDriverView::SetControls()
{
	CEdit* pNameEdit = (CEdit*)GetDlgItem(IDC_ROTOR);
	CString csRotorKey = m_pRotorDriver->GetRotorKey();
	if (csRotorKey.IsEmpty())
	{
		pNameEdit->SetWindowText("<None>");
	}
	else
	{
		CObjectInfo* pObjectInfo = m_pObjectBroker->GetObjectInfoByKey(csRotorKey);
		pNameEdit->SetWindowText(pObjectInfo->GetName());
	}

	CButton* pStartButton = (CButton*)GetDlgItem(IDC_START);
	if (m_pRotorDriver->IsRotorGoing())
		pStartButton->SetWindowText("&Stop");
	else
		pStartButton->SetWindowText("&Start");

	CEdit* pRotationEdit = (CEdit*)GetDlgItem(IDC_ROTATION);
	CString csEditText;
	csEditText.Format("%d ",m_pRotorDriver->GetRotationIncrement());
	if (m_pRotorDriver->GetRotateClockwise())
		csEditText += "CW";
	else
		csEditText += "CCW";
	pRotationEdit->SetWindowText(csEditText);

	CEdit* pIntervalEdit = (CEdit*)GetDlgItem(IDC_UPDATE);
	csEditText.Format("%d",m_pRotorDriver->GetUpdateInterval());
	pIntervalEdit->SetWindowText(csEditText);

	m_bNeedControlsUpdate = FALSE;
}

void CRotorDriverView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	if (m_bNeedControlsUpdate)
		SetControls();
}

void CRotorDriverView::OnStart() 
{
	if (m_pRotorDriver->IsRotorGoing())
		m_pRotorDriver->StopRotor();
	else
		m_pRotorDriver->StartRotor();

	GetDocument()->SetModifiedFlag();
	GetDocument()->UpdateAllViews(NULL);
}


