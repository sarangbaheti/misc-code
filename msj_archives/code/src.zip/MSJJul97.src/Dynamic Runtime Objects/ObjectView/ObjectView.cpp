// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "ObjectView.h"
#include "MainFrm.h"
#include "ObjectViewDoc.h"
#include "MultiDocTemplateEx.h"
#include "ClassBroker.h"
#include "FlexibleChildFrm.h"
#include "ObjectBrokerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CObjectViewApp theApp;

BEGIN_MESSAGE_MAP(CObjectViewApp, CObjectApp)
	//{{AFX_MSG_MAP(CObjectViewApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

CObjectViewApp::CObjectViewApp()
{

}

CObjectViewApp::~CObjectViewApp()
{

}

BOOL CObjectViewApp::InitInstance()
{
	if (CObjectApp::InitInstance() == FALSE)
		return FALSE;

#ifdef _AFXDLL
	Enable3dControls();		
#else
	Enable3dControlsStatic();
#endif

	LoadStdProfileSettings();  

	CMultiDocTemplateEx* pDocTemplate = new CMultiDocTemplateEx(
		IDR_OBVIEWTYPE,
		RUNTIME_CLASS(CObjectViewDoc),
		RUNTIME_CLASS(CFlexibleChildFrame), 
		RUNTIME_CLASS(CObjectBrokerView));
	AddDocTemplate(pDocTemplate);

	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;

	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();

	return TRUE;
}

class CAboutDlg : public CDialog
{

  public:

	CAboutDlg();

	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX); // DDX/DDV support
	//}}AFX_VIRTUAL

  protected:

	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CObjectViewApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}
