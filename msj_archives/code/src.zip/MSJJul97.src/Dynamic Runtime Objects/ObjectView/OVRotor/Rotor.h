// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __Rotor_h__
#define __Rotor_h__

#include "GenericRotor.h"
#include "SubjectObserver.h"
#include "DynamicObject.h"

class CRotor : public CGenericRotor
{

  DECLARE_SERIAL(CRotor);

  public:

	CRotor();

	virtual ~CRotor();

	virtual void DrawRotor(CDC *pDC, int nRadius, int nAngle) const;

	int GetNumRotors() const;

	CString GetRotorName(int nIndex) const;

	int GetSelectedRotor() const;

	void SelectRotor(int nIndex);

	virtual void Serialize(CArchive& archive);

  private:

	void DrawPointer(CDC *pDC, int nRadius, int nAngle) const;

	void DrawRectangle(CDC *pDC, int nRadius, int nAngle) const;

	void DrawTriangle(CDC *pDC, int nRadius, int nAngle) const;
	
  private:

	CStringArray m_csarrayRotorNames;

	int m_nSelectedRotor;

};

#endif
