// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "RotorView.h"
#include "ObjectBroker.h"
#include "ObjectInfoMessage.h"
#include "Rotor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CRotorView, CNSFlexFormView)

BEGIN_MESSAGE_MAP(CRotorView, CNSFlexFormView)
	//{{AFX_MSG_MAP(CRotorView)
	ON_LBN_SELCHANGE(IDC_ROTORS, OnSelchangeRotors)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_OBJECTINFO,OnObjectInfo)
END_MESSAGE_MAP()

CRotorView::CRotorView()
	: CNSFlexFormView(CRotorView::IDD)
{
	//{{AFX_DATA_INIT(CRotorView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_pRotor = NULL;

	AddFlexConstraint(IDC_ROTORS,        
		NSFlexHorizontallyFixed,NSFlexExpandDown);
	AddFlexConstraint(IDC_LOCATOR,         
		NSFlexExpandRight,NSFlexExpandDown); 
}

CRotorView::~CRotorView()
{
	m_pRotor->DetachFromSubject(this);
	m_pRotor->Release();
}

void CRotorView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRotorView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

#ifdef _DEBUG
void CRotorView::AssertValid() const
{
	CNSFlexFormView::AssertValid();
}

void CRotorView::Dump(CDumpContext& dc) const
{
	CNSFlexFormView::Dump(dc);
}
#endif //_DEBUG

LRESULT CRotorView::OnObjectInfo(WPARAM wParam, LPARAM lParam)
{
	ObjectInfoMessage* pObjectInfoMessage = (ObjectInfoMessage*)(lParam);

	CObjectBroker* pObjectBroker = pObjectInfoMessage->pObjectBroker;

	CObjectInfo* pObjectInfo = 
		pObjectBroker->GetObjectInfoByKey(pObjectInfoMessage->pszObjectKey);
	ASSERT(pObjectInfo);

	m_pRotor = (CRotor*)pObjectInfo->GetObject();
	ASSERT(m_pRotor);
	ASSERT(m_pRotor->IsKindOf(RUNTIME_CLASS(CRotor)));

	m_pRotor->AttachToSubject(this);

	return 1;
}

void CRotorView::OnInitialUpdate() 
{
	CListBox* pRotorsList = (CListBox*)GetDlgItem(IDC_ROTORS);
	for (int ii = 0; ii < m_pRotor->GetNumRotors(); ii++)
	{
		int nIndex = pRotorsList->AddString(m_pRotor->GetRotorName(ii));
		pRotorsList->SetItemData(nIndex,ii);
	}

	CWnd* pLocatorWnd = GetDlgItem(IDC_LOCATOR);
	pLocatorWnd->ShowWindow(SW_HIDE);

	m_bNeedUpdate = TRUE;

	CNSFlexFormView::OnInitialUpdate();
}

void CRotorView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	if (!m_bNeedUpdate)
		return;

	CListBox* pRotorsList = (CListBox*)GetDlgItem(IDC_ROTORS);
	for (int ii = 0; ii < m_pRotor->GetNumRotors(); ii++)
	{
		if ((int)pRotorsList->GetItemData(ii) == 
			m_pRotor->GetSelectedRotor())
		{
			pRotorsList->SetCurSel(ii);
			break;
		}
	}

	Invalidate();

	m_bNeedUpdate = FALSE;
}

void CRotorView::SubjectChanged(CSubject* pSubject, 
	LPARAM lHint, void* pHint)
{
	ASSERT(pSubject == m_pRotor);

	switch(lHint)
	{

		case ROTOR_CHANGED:
			m_bNeedUpdate = TRUE;
			break;

		default:
			ASSERT(FALSE);

	}

}

void CRotorView::OnDraw(CDC* pDC) 
{
	CNSFlexFormView::OnDraw(pDC);

	m_pRotor->DrawRotor(pDC,SetupDC(pDC),0);
}

int CRotorView::SetupDC(CDC *pdc)
{
	CWnd* pLocatorWnd = GetDlgItem(IDC_LOCATOR);

	CRect rectMM_TEXT_Locator;
	pLocatorWnd->GetWindowRect(&rectMM_TEXT_Locator);
	ScreenToClient(rectMM_TEXT_Locator);
	CPoint pointMM_TEXT_Center = rectMM_TEXT_Locator.CenterPoint();

	pdc->SetMapMode(MM_HIMETRIC);
	pdc->SetViewportOrg(pointMM_TEXT_Center.x,
		pointMM_TEXT_Center.y);

	CSize sizeMM_HIMETRICLocator = rectMM_TEXT_Locator.Size();
	pdc->DPtoHIMETRIC(&sizeMM_HIMETRICLocator);

	int nRadius = min(sizeMM_HIMETRICLocator.cx,
		sizeMM_HIMETRICLocator.cy) / 2;

	return nRadius;
}

void CRotorView::OnSelchangeRotors() 
{
	CListBox* pRotorsList = (CListBox*)GetDlgItem(IDC_ROTORS);
	int nRotor = pRotorsList->GetItemData(pRotorsList->GetCurSel());

	m_pRotor->SelectRotor(nRotor);

	GetDocument()->SetModifiedFlag();
	GetDocument()->UpdateAllViews(NULL);
}
