// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "Rotor.h"
#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CRotor,CGenericRotor,1)

#define NUM_ROTORS      3

#define ROTOR_POINTER   0
#define ROTOR_RECTANGLE 1
#define ROTOR_TRIANGLE  2

CRotor::CRotor()
{
	m_csarrayRotorNames.SetSize(NUM_ROTORS);

	m_csarrayRotorNames[ROTOR_POINTER]   = "Pointer";
	m_csarrayRotorNames[ROTOR_RECTANGLE] = "Rectangle";
	m_csarrayRotorNames[ROTOR_TRIANGLE]  = "Triangle";

	m_nSelectedRotor = ROTOR_TRIANGLE;
}

CRotor::~CRotor()
{

}

int CRotor::GetNumRotors() const
{
	return m_csarrayRotorNames.GetSize();
}

CString CRotor::GetRotorName(int nIndex) const
{
	ASSERT(nIndex >= 0 && nIndex <= NUM_ROTORS);
	return m_csarrayRotorNames[nIndex];
}

int CRotor::GetSelectedRotor() const
{
	return m_nSelectedRotor;
}

void CRotor::SelectRotor(int nIndex)
{
	ASSERT(nIndex >= 0 && nIndex <= NUM_ROTORS);
	m_nSelectedRotor = nIndex;

	NotifyObservers(ROTOR_CHANGED,NULL);
}

void CRotor::Serialize(CArchive& archive)
{
	CDynamicObject::Serialize(archive);

	if (archive.IsStoring())
	{
		archive << m_nSelectedRotor;
	}
	else
	{
		archive >> m_nSelectedRotor;
	}

}

void CRotor::DrawRotor(CDC *pDC, int nRadius, int nAngle) const
{
	switch (m_nSelectedRotor)
	{
		case ROTOR_POINTER:
			DrawPointer(pDC,nRadius,nAngle);
			break;

		case ROTOR_RECTANGLE:
			DrawRectangle(pDC,nRadius,nAngle);
			break;

		case ROTOR_TRIANGLE:
			DrawTriangle(pDC,nRadius,nAngle);
			break;
	}

}

#define DEGREES_TO_RADIANS 0.01745
#define OUTSIDE_TO_INSIDE_RADIUS 0.9

void CRotor::DrawPointer(CDC *pDC, int nRadius, int nAngle) const
{
	CPen OutlinePen;
	OutlinePen.CreatePen(PS_SOLID,0,RGB(0,0,0));

	CBrush ExteriorBrush;
	ExteriorBrush.CreateSolidBrush(RGB(255,255,255));

	CBrush InteriorBrush;
	InteriorBrush.CreateSolidBrush(RGB(0,0,0));

	CPen* pPreviousPen = pDC->SelectObject(&OutlinePen);
	CBrush* pPreviousBrush = pDC->SelectObject(&ExteriorBrush);

	nRadius = (int)(OUTSIDE_TO_INSIDE_RADIUS*nRadius);

	pDC->Ellipse(-nRadius,nRadius,nRadius,-nRadius);

	nRadius = (int)(0.95*nRadius);

	CPoint arrayPoint[4];

	double nAngle1 = nAngle*DEGREES_TO_RADIANS;
	double nAngle2 = (nAngle+10.0)*DEGREES_TO_RADIANS;
	double nAngle3 = (nAngle-10.0)*DEGREES_TO_RADIANS;

	arrayPoint[0].x = (int)(nRadius*cos(nAngle1));
	arrayPoint[0].y = (int)(nRadius*sin(nAngle1));
	arrayPoint[1].x = (int)(nRadius*cos(nAngle2)*0.7);
	arrayPoint[1].y = (int)(nRadius*sin(nAngle2)*0.7);
	arrayPoint[2].x = 0;
	arrayPoint[2].y = 0;
	arrayPoint[3].x = (int)(nRadius*cos(nAngle3)*0.7);
	arrayPoint[3].y = (int)(nRadius*sin(nAngle3)*0.7);

	pDC->SelectObject(&InteriorBrush);
	pDC->Polygon(arrayPoint,4);

	nRadius /= 10;
	pDC->Ellipse(-nRadius,nRadius,nRadius,-nRadius);

	pDC->SelectObject(pPreviousPen);
	pDC->SelectObject(pPreviousBrush);
}

void CRotor::DrawRectangle(CDC *pDC, int nRadius, int nAngle) const
{
	CPen OutlinePen;
	OutlinePen.CreatePen(PS_SOLID,0,RGB(0,0,0));

	CBrush ExteriorBrush;
	ExteriorBrush.CreateSolidBrush(RGB(255,255,255));

	CBrush InteriorBrush;
	InteriorBrush.CreateSolidBrush(RGB(255,255,0));

	CPen* pPreviousPen = pDC->SelectObject(&OutlinePen);
	CBrush* pPreviousBrush = pDC->SelectObject(&ExteriorBrush);

	nRadius = (int)(OUTSIDE_TO_INSIDE_RADIUS*nRadius);

	pDC->Ellipse(-nRadius,nRadius,nRadius,-nRadius);

	nRadius = (int)(0.95*nRadius);

	CPoint arrayPoint[4];

	double nAngle1 = (nAngle+30.0)*DEGREES_TO_RADIANS;
	double nAngle2 = (nAngle+150.0)*DEGREES_TO_RADIANS;
	double nAngle3 = (nAngle+210.0)*DEGREES_TO_RADIANS;
	double nAngle4 = (nAngle+330.0)*DEGREES_TO_RADIANS;

	arrayPoint[0].x = (int)(nRadius*cos(nAngle1));
	arrayPoint[0].y = (int)(nRadius*sin(nAngle1));
	arrayPoint[1].x = (int)(nRadius*cos(nAngle2));
	arrayPoint[1].y = (int)(nRadius*sin(nAngle2));
	arrayPoint[2].x = (int)(nRadius*cos(nAngle3));
	arrayPoint[2].y = (int)(nRadius*sin(nAngle3));
	arrayPoint[3].x = (int)(nRadius*cos(nAngle4));
	arrayPoint[3].y = (int)(nRadius*sin(nAngle4));

	pDC->SelectObject(&InteriorBrush);
	pDC->Polygon(arrayPoint,4);

		LOGFONT LogFont;
	memset(&LogFont,0,sizeof(LogFont));
	lstrcpy(LogFont.lfFaceName, "Arial"); 
	LogFont.lfWeight = FW_BOLD;
	LogFont.lfEscapement = -nAngle*10;
	LogFont.lfItalic = TRUE;
	LogFont.lfHeight = (int)(nRadius * 0.3);

	CFont NewFont;
	NewFont.CreateFontIndirect(&LogFont);
	CFont* pPreviousFont = pDC->SelectObject(&NewFont);

	TEXTMETRIC TextMetric;
	pDC->GetTextMetrics(&TextMetric);

	double dY = TextMetric.tmHeight/2.0;
	double dX = -TextMetric.tmAveCharWidth*4.5;

	double dTextAngle = 3.1415926535 - atan(dY/-dX);
	double dTextRadius = sqrt(dY*dY + dX*dX);

	nAngle1 = nAngle*DEGREES_TO_RADIANS;

	dX = dTextRadius*cos(dTextAngle+nAngle1);
	dY = dTextRadius*sin(dTextAngle+nAngle1);

	pDC->SetBkMode(TRANSPARENT); 
	pDC->TextOut((int)dX,(int)dY,"NanoSoft",8);

	pDC->SelectObject(pPreviousFont);
	pDC->SelectObject(pPreviousPen);
	pDC->SelectObject(pPreviousBrush);
}

void CRotor::DrawTriangle(CDC *pDC, int nRadius, int nAngle) const
{
	CPen OutlinePen;
	OutlinePen.CreatePen(PS_SOLID,0,RGB(0,0,0));

	CBrush ExteriorBrush;
	ExteriorBrush.CreateSolidBrush(RGB(255,255,255));

	CBrush InteriorBrush;
	InteriorBrush.CreateSolidBrush(RGB(255,0,0));

	CPen* pPreviousPen = pDC->SelectObject(&OutlinePen);
	CBrush* pPreviousBrush = pDC->SelectObject(&ExteriorBrush);

	nRadius = (int)(OUTSIDE_TO_INSIDE_RADIUS*nRadius);

	pDC->Ellipse(-nRadius,nRadius,nRadius,-nRadius);

	nRadius = (int)(0.95*nRadius);

	CPoint arrayPoint[3];

	double nAngle1 = nAngle*DEGREES_TO_RADIANS;
	double nAngle2 = (nAngle+150.0)*DEGREES_TO_RADIANS;
	double nAngle3 = (nAngle+210.0)*DEGREES_TO_RADIANS;

	arrayPoint[0].x = (int)(nRadius*cos(nAngle1));
	arrayPoint[0].y = (int)(nRadius*sin(nAngle1));
	arrayPoint[1].x = (int)(nRadius*cos(nAngle2));
	arrayPoint[1].y = (int)(nRadius*sin(nAngle2));
	arrayPoint[2].x = (int)(nRadius*cos(nAngle3));
	arrayPoint[2].y = (int)(nRadius*sin(nAngle3));

	pDC->SelectObject(&InteriorBrush);
	pDC->Polygon(arrayPoint,3);

	LOGFONT LogFont;
	memset(&LogFont,0,sizeof(LogFont));
	lstrcpy(LogFont.lfFaceName, "Arial"); 
	LogFont.lfWeight = FW_BOLD;
	LogFont.lfEscapement = -nAngle*10;
	LogFont.lfItalic = TRUE;
	LogFont.lfHeight = (int)(nRadius * 0.3);

	CFont NewFont;
	NewFont.CreateFontIndirect(&LogFont);
	CFont* pPreviousFont = pDC->SelectObject(&NewFont);

	TEXTMETRIC TextMetric;
	pDC->GetTextMetrics(&TextMetric);

	double dY = TextMetric.tmHeight/2.0;
	double dX = -TextMetric.tmAveCharWidth*8.0*0.75;

	double dTextAngle = 3.1415926535 - atan(dY/-dX);
	double dTextRadius = sqrt(dY*dY + dX*dX);

	dX = dTextRadius*cos(dTextAngle+nAngle1);
	dY = dTextRadius*sin(dTextAngle+nAngle1);

	pDC->SetBkMode(TRANSPARENT); 
	pDC->TextOut((int)dX,(int)dY,"NanoSoft",8);

	pDC->SelectObject(pPreviousFont);
	pDC->SelectObject(pPreviousPen);
	pDC->SelectObject(pPreviousBrush);
}

