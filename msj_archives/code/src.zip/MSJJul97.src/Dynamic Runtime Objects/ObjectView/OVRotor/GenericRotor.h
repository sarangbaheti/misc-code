// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __GenericRotor_h__
#define __GenericRotor_h__

#include "OVRotorAfxExt.h"
#include "SubjectObserver.h"
#include "DynamicObject.h"

#define ROTOR_CHANGED 1L

class AFX_EXT_OVROTOR CGenericRotor : public CDynamicObject, public CSubject
{

  DECLARE_SERIAL(CGenericRotor);

  public:

	virtual void DrawRotor(CDC *pDC, int nRadius, int nAngle) const;

};

#endif
