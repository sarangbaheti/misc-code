// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "GenericRotor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CGenericRotor,CDynamicObject,1)

void CGenericRotor::DrawRotor(CDC *pDC, int nRadius, int nAngle) const
{

}

