// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include <afxdllx.h>
#include "Rotor.h"
#include "RotorView.h"
#include "FlexibleChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static AFX_EXTENSION_MODULE OVRotorDLL = { NULL, NULL };

extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	if (dwReason == DLL_PROCESS_ATTACH)
	{
		TRACE0("OVROTOR.DLL Initializing!\n");
		
		// Extension DLL one-time initialization
		AfxInitExtensionModule(OVRotorDLL, hInstance);

		// Insert this DLL into the resource chain
		new CDynLinkLibrary(OVRotorDLL);
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		TRACE0("OVROTOR.DLL Terminating!\n");

        AfxTermExtensionModule(OVRotorDLL);
	}
	return 1;   // ok
}

extern "C" void WINAPI ClassInfo(CLSID& clsidClassID, 
	CLSID& clsidClassCategory, CString& csDescription,
	CRuntimeClass*& pObjectClass, CRuntimeClass*& pFrameClass,
	CRuntimeClass*& pViewClass)
{
	// ID: {4423E281-664E-11d0-8945-2AFFD5000000}
	CLSID clsidID = { 0x4423e281, 0x664e, 0x11d0, 
		{ 0x89, 0x45, 0x2a, 0xff, 0xd5, 0x0, 0x0, 0x0 } };

	// CATEGORY: {A8D09C01-90C4-11d0-A264-0040052E01FC}
	CLSID clsidCategory = { 0xa8d09c01, 0x90c4, 0x11d0, 
		{ 0xa2, 0x64, 0x0, 0x40, 0x5, 0x2e, 0x1, 0xfc } };

	clsidClassID = clsidID;
	clsidClassCategory = clsidCategory;

	csDescription = "Rotor";

	pObjectClass = RUNTIME_CLASS(CRotor);
	pFrameClass = RUNTIME_CLASS(CFlexibleChildFrame);
	pViewClass = RUNTIME_CLASS(CRotorView);
}
