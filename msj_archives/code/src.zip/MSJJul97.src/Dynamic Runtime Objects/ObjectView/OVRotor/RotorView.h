// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __RotorView_h__
#define __RotorThreadView_h__

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "Resource.h"
#include "NSFlexFormView.h"
#include "SubjectObserver.h"

class CRotor;

class CRotorView : public CNSFlexFormView, public CObserver
{

	DECLARE_DYNCREATE(CRotorView)

  public:

	int SetupDC(CDC *pdc);

	virtual void SubjectChanged(CSubject* pSubject, LPARAM lHint, void* pHint);

	//{{AFX_DATA(CRotorView)
	enum { IDD = IDD_ROTOR_FORM };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRotorView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX); 
	virtual void OnDraw(CDC* pDC);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

  protected:

	CRotorView(); 

	virtual ~CRotorView();

#ifdef _DEBUG

	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;

#endif

	// Generated message map functions
	//{{AFX_MSG(CRotorView)
	afx_msg void OnSelchangeRotors();
	//}}AFX_MSG

    afx_msg LRESULT OnObjectInfo(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()

  private:

	CRotor* m_pRotor;

	BOOL m_bNeedUpdate;

};

#endif

