// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __OVRotorAfxExt_h__
#define __OVRotorAfxExt_h__

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#pragma warning(disable: 4275)
#pragma warning(disable: 4251)

#ifdef BUILD_OVROTOR
#define AFX_EXT_OVROTOR AFX_CLASS_EXPORT
#else
#define AFX_EXT_OVROTOR AFX_CLASS_IMPORT
#endif

#endif
