// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "Resource.h"
#include "NSFlexFormView.h"

class CSimpleObject;

class CSimpleView : public CNSFlexFormView
{

  public:

	//{{AFX_DATA(CSimpleView)
	enum { IDD = IDD_SIMPLEVIEW };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSimpleView)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

  protected:

	CSimpleView();           
	DECLARE_DYNCREATE(CSimpleView)
	virtual ~CSimpleView();

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CSimpleView)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

    afx_msg LRESULT OnObjectInfo(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()

  private:

	CSimpleObject* m_pSimpleObject;

};

