// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "SimpleObject.h"
#include "ObjectBroker.h"
#include "ObjectInfoMessage.h"
#include "SimpleView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CSimpleView, CNSFlexFormView)

BEGIN_MESSAGE_MAP(CSimpleView, CNSFlexFormView)
	//{{AFX_MSG_MAP(CSimpleView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_OBJECTINFO,OnObjectInfo)
END_MESSAGE_MAP()

CSimpleView::CSimpleView()
	: CNSFlexFormView(CSimpleView::IDD)
{
	//{{AFX_DATA_INIT(CSimpleView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CSimpleView::~CSimpleView()
{
	m_pSimpleObject->Release();
}

LRESULT CSimpleView::OnObjectInfo(WPARAM wParam, LPARAM lParam)
{
	ObjectInfoMessage* pObjectInfoMessage = (ObjectInfoMessage*)(lParam);

	CObjectBroker* pObjectBroker = pObjectInfoMessage->pObjectBroker;

	CObjectInfo* pObjectInfo = 
		pObjectBroker->GetObjectInfoByKey(pObjectInfoMessage->pszObjectKey);
	ASSERT(pObjectInfo);

	m_pSimpleObject = (CSimpleObject*)pObjectInfo->GetObject();
	ASSERT(m_pSimpleObject);
	ASSERT(m_pSimpleObject->IsKindOf(RUNTIME_CLASS(CSimpleObject)));

	return 1;
}

void CSimpleView::DoDataExchange(CDataExchange* pDX)
{
	CNSFlexFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSimpleView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

#ifdef _DEBUG
void CSimpleView::AssertValid() const
{
	CNSFlexFormView::AssertValid();
}

void CSimpleView::Dump(CDumpContext& dc) const
{
	CNSFlexFormView::Dump(dc);
}
#endif //_DEBUG

