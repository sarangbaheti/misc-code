// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __SimpleObject_h__
#define __SimpleObject_h__

#include "DynamicObject.h"

class CSimpleObject : public CDynamicObject
{

  DECLARE_SERIAL(CSimpleObject);

  public:

	CSimpleObject();

	virtual ~CSimpleObject();

	virtual void Serialize(CArchive& archive);

};

#endif
