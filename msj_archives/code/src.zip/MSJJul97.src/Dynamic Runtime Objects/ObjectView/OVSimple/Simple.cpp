// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include <afxdllx.h>
#include "SimpleObject.h"
#include "SimpleView.h"
#include "FlexibleChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static AFX_EXTENSION_MODULE SimpleDLL = { NULL, NULL };

extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	if (dwReason == DLL_PROCESS_ATTACH)
	{
		TRACE0("SIMPLE.DLL Initializing!\n");
		
		// Extension DLL one-time initialization
		AfxInitExtensionModule(SimpleDLL, hInstance);

		// Insert this DLL into the resource chain
		new CDynLinkLibrary(SimpleDLL);
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		TRACE0("SIMPLE.DLL Terminating!\n");

        AfxTermExtensionModule(SimpleDLL);
	}
	return 1;   // ok
}

extern "C" void WINAPI ClassInfo(CLSID& clsidClassID, 
	CLSID& clsidClassCategory, CString& csDescription,
	CRuntimeClass*& pObjectClass, CRuntimeClass*& pFrameClass,
	CRuntimeClass*& pViewClass)
{
	// ID: {34E338C1-86E1-11d0-8984-00008609452B}
	CLSID clsidID = { 0x34e338c1, 0x86e1, 0x11d0, 
		{ 0x89, 0x84, 0x0, 0x0, 0x86, 0x9, 0x45, 0x2b } };

	// CATEGORY: {8CEDC521-90AF-11d0-A263-2AC81B000000}
	CLSID clsidCategory = { 0x8cedc521, 0x90af, 0x11d0,
		{ 0xa2, 0x63, 0x2a, 0xc8, 0x1b, 0x0, 0x0, 0x0 } };

	clsidClassID = clsidID;
	clsidClassCategory = clsidCategory;

	csDescription = "Simple Object";

	pObjectClass = RUNTIME_CLASS(CSimpleObject);
	pFrameClass = RUNTIME_CLASS(CFlexibleChildFrame);
	pViewClass = RUNTIME_CLASS(CSimpleView);
}

