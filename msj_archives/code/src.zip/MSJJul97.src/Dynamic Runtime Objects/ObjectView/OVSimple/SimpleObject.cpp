// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "SimpleObject.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CSimpleObject,CDynamicObject,1)

CSimpleObject::CSimpleObject()
{

}

CSimpleObject::~CSimpleObject()
{

}

void CSimpleObject::Serialize(CArchive& archive)
{
	CDynamicObject::Serialize(archive);
}

