// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "ObjectView.h"
#include "ObjectViewDoc.h"
#include "ObjectBrokerView.h"
#include "ObjectBroker.h"
#include "ViewBroker.h"
#include "AddInstanceDlg.h"
#include "NameInstanceDlg.h"
#include "ClassBroker.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CObjectBrokerView, CNSFlexFormView)

BEGIN_MESSAGE_MAP(CObjectBrokerView, CNSFlexFormView)
	//{{AFX_MSG_MAP(CObjectBrokerView)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_BN_CLICKED(IDC_NAME, OnName)
	ON_BN_CLICKED(IDC_REMOVE, OnRemove)
	ON_BN_CLICKED(IDC_VIEW, OnView)
	ON_LBN_DBLCLK(IDC_OBJECTS, OnDblclkObjects)
	ON_LBN_SELCHANGE(IDC_OBJECTS, OnSelchangeObjects)
	//}}AFX_MSG_MAP
	// Standard printing commands
	//ON_COMMAND(ID_FILE_PRINT, CNSFlexFormView::OnFilePrint)
	//ON_COMMAND(ID_FILE_PRINT_DIRECT, CNSFlexFormView::OnFilePrint)
	//ON_COMMAND(ID_FILE_PRINT_PREVIEW, CNSFlexFormView::OnFilePrintPreview)
END_MESSAGE_MAP()

CObjectBrokerView::CObjectBrokerView()
	: CNSFlexFormView(CObjectBrokerView::IDD)
{
	//{{AFX_DATA_INIT(CObjectBrokerView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// TODO: add construction code here

	m_bNeedUpdate = FALSE;

	AddFlexConstraint(IDC_OBJECTS, NSFlexExpandRight, NSFlexExpandDown);
	AddFlexConstraint(IDC_ADD,     NSFlexShiftRight,  NSFlexVerticallyFixed); 
	AddFlexConstraint(IDC_REMOVE,  NSFlexShiftRight,  NSFlexVerticallyFixed); 
	AddFlexConstraint(IDC_VIEW,    NSFlexShiftRight,  NSFlexVerticallyFixed);
	AddFlexConstraint(IDC_NAME,    NSFlexShiftRight,  NSFlexVerticallyFixed); 
}

CObjectBrokerView::~CObjectBrokerView()
{
	GetDocument()->m_pObjectBrokerWnd = NULL;
	CObjectBroker* pObjectBroker = GetDocument()->GetObjectBroker();

	// Normally we wouldn't have to check if we are an observer of the
	// object broker before detaching, but there is a bit of a bug in MFC
	// regarding the MRU file list. If the file doesn't exist, the view gets
	// constructed, but OnInitialUpdate never gets called, so in our case,
	// we would never get registered as an observer of the object broker.
	if (pObjectBroker->IsObserver(this))
		pObjectBroker->DetachFromSubject(this);
}

void CObjectBrokerView::DoDataExchange(CDataExchange* pDX)
{
	CNSFlexFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CObjectBrokerView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BOOL CObjectBrokerView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CNSFlexFormView::PreCreateWindow(cs);
}

BOOL CObjectBrokerView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CObjectBrokerView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CObjectBrokerView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CObjectBrokerView::OnPrint(CDC* pDC, CPrintInfo*)
{
	// TODO: add code to print the controls
}

#ifdef _DEBUG

void CObjectBrokerView::AssertValid() const
{
	CNSFlexFormView::AssertValid();
}

void CObjectBrokerView::Dump(CDumpContext& dc) const
{
	CNSFlexFormView::Dump(dc);
}

CObjectViewDoc* CObjectBrokerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CObjectViewDoc)));
	return (CObjectViewDoc*)m_pDocument;
}

#endif //_DEBUG

void CObjectBrokerView::OnInitialUpdate() 
{
	CNSFlexFormView::OnInitialUpdate();

	GetParent()->SetWindowText("Object Broker");
	GetDocument()->m_pObjectBrokerWnd = (CMDIChildWnd*)GetParent();
	CObjectBroker* pObjectBroker = GetDocument()->GetObjectBroker();

	POSITION pos = pObjectBroker->GetStartPosition();
	if (pos)
	{
		CObjectInfo* pObjectInfo;
		pObjectBroker->GetNextAssoc(pos,m_csSelectedObjectKey,
			pObjectInfo); 
	}
	SetControls();

	pObjectBroker->AttachToSubject(this);
}

void CObjectBrokerView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	if (!m_bNeedUpdate)
		return;

	SetControls();
	m_bNeedUpdate = FALSE;
}

void CObjectBrokerView::SubjectChanged(CSubject* pSubject, 
	LPARAM lHint, void* pHint)
{
	CObjectBroker* pObjectBroker = GetDocument()->GetObjectBroker();
	ASSERT(pSubject == pObjectBroker);

	switch (lHint)
	{
	  case OBJECT_BROKER_ADDED_OBJECT:
		// nothing needs to be done
		break;
	  case OBJECT_BROKER_ABOUT_TO_REMOVE_OBJECT:
		// nothing needs to be done
		break;
	  case OBJECT_BROKER_REMOVED_OBJECT:
		if (m_csSelectedObjectKey == *((CString*)pHint))
		{
			POSITION pos = pObjectBroker->GetStartPosition();
			if (pos)
			{
				CObjectInfo* pObjectInfo;
				pObjectBroker->GetNextAssoc(pos,m_csSelectedObjectKey,
					pObjectInfo); 
			}
			else
				m_csSelectedObjectKey.Empty();
		}
		break;
	  case OBJECT_BROKER_RENAMED_OBJECT:
		// nothing needs to be done
		break;
	  default:
		ASSERT(FALSE);
	}

	m_bNeedUpdate = TRUE;	
}

void CObjectBrokerView::SetControls()
{
	CObjectBroker* pObjectBroker = GetDocument()->GetObjectBroker();
	CListBox* pObjectsList = (CListBox*)GetDlgItem(IDC_OBJECTS);
	CString csKey;
	CObjectInfo* pObjectInfo;

	pObjectsList->ResetContent();

	for (POSITION pos = pObjectBroker->GetStartPosition(); pos; )
	{
		pObjectBroker->GetNextAssoc(pos,csKey,pObjectInfo); 

		CString csName = CClassBroker::GetClassInfo(
			pObjectInfo->GetClassID())->GetDescription();
		csName += " - ";
		csName += pObjectInfo->GetName();

		int nIndex = pObjectsList->AddString(csName);
		pObjectsList->SetItemDataPtr(nIndex,pObjectInfo);
	}

	CButton* pRemove = (CButton*)GetDlgItem(IDC_REMOVE);
	CButton* pName = (CButton*)GetDlgItem(IDC_NAME);
	CButton* pView = (CButton*)GetDlgItem(IDC_VIEW);

	if (m_csSelectedObjectKey.IsEmpty())
	{
		pRemove->EnableWindow(FALSE);
		pName->EnableWindow(FALSE);
		pView->EnableWindow(FALSE);
	}
	else
	{
		pRemove->EnableWindow(TRUE);
		pName->EnableWindow(TRUE);
		pView->EnableWindow(TRUE);

		CObjectInfo* pSelectedObject = 
			pObjectBroker->GetObjectInfoByKey(m_csSelectedObjectKey); 

		for (int ii = 0; ii < pObjectsList->GetCount(); ii++)
		{
			if (pObjectsList->GetItemDataPtr(ii) == pSelectedObject)
			{
				pObjectsList->SetCurSel(ii);
				break;
			}
		}
	}
}

void CObjectBrokerView::OnAdd() 
{
	CAddInstanceDlg dlg;

	if (dlg.DoModal() == IDOK)
	{
		CClassInfo* pClassInfo = dlg.m_pClassInfo;

		if (!pClassInfo)
			return;

		CLSID clsid = dlg.m_pClassInfo->GetClassID();

		CObjectBroker* pObjectBroker = GetDocument()->GetObjectBroker();
		pObjectBroker->Add(clsid,m_csSelectedObjectKey);

		GetDocument()->SetModifiedFlag();
		GetDocument()->UpdateAllViews(NULL);
	}
}

void CObjectBrokerView::OnName() 
{
	CObjectBroker* pObjectBroker = GetDocument()->GetObjectBroker();

	CNameInstanceDlg dlg(pObjectBroker,m_csSelectedObjectKey);

	if (dlg.DoModal() == IDOK)
	{
		pObjectBroker->SetName(m_csSelectedObjectKey,dlg.m_csName);

		GetDocument()->SetModifiedFlag();
		GetDocument()->UpdateAllViews(NULL);
	}
}

void CObjectBrokerView::OnRemove() 
{
	CObjectBroker* pObjectBroker = GetDocument()->GetObjectBroker();
	VERIFY(pObjectBroker->Remove(m_csSelectedObjectKey));

	GetDocument()->SetModifiedFlag();
	GetDocument()->UpdateAllViews(NULL);
}

void CObjectBrokerView::OnView() 
{
	GetDocument()->GetViewBroker()->OpenView(m_csSelectedObjectKey);
}

void CObjectBrokerView::OnDblclkObjects() 
{
	OnView();
}

void CObjectBrokerView::OnSelchangeObjects() 
{
	CObjectBroker* pObjectBroker = GetDocument()->GetObjectBroker();
	CListBox* pObjectsList = (CListBox*)GetDlgItem(IDC_OBJECTS);
	CObjectInfo* pObjectInfo = (CObjectInfo*)
		pObjectsList->GetItemDataPtr(pObjectsList->GetCurSel());
	m_csSelectedObjectKey = pObjectInfo->GetKey();
}
