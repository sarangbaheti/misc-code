// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __ObjectBrokerView_h__
#define __ObjectBrokerView_h__

#include "NSFlexFormView.h"
#include "SubjectObserver.h"

class CObjectBrokerView : public CNSFlexFormView, public CObserver
{

	DECLARE_DYNCREATE(CObjectBrokerView)

  public:

	//{{AFX_DATA(CObjectBrokerView)
	enum{ IDD = IDD_OBJECTBROKER_FORM };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	CObjectViewDoc* GetDocument();

	virtual void SubjectChanged(CSubject* pSubject, LPARAM lHint, 
		void* pHint); 

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CObjectBrokerView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo*);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

	virtual ~CObjectBrokerView();

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

  protected:
  
	CObjectBrokerView();

	//{{AFX_MSG(CObjectBrokerView)
	afx_msg void OnAdd();
	afx_msg void OnName();
	afx_msg void OnRemove();
	afx_msg void OnView();
	afx_msg void OnDblclkObjects();
	afx_msg void OnSelchangeObjects();
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

  private:

	void SetControls();

	BOOL m_bNeedUpdate;
	CString m_csSelectedObjectKey;

};

#ifndef _DEBUG  // debug version in BrokerView.cpp
inline CObjectViewDoc* CObjectBrokerView::GetDocument()
   { return (CObjectViewDoc*)m_pDocument; }
#endif

#endif
