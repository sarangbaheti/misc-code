
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

ObjectView Version 1.00 (including OVCore and example runtime DLLs)

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

MFC Developers:

All of the source code for ObjectView is yours free of charge in accordance 
with the license terms found in LICENSE.txt courtesy of NanoSoft 
Corporation.

We think that the design concepts demonstrated in ObjectView solve a host of
common problems associated with complicated aplication architectures.  
Hopefully, these ideas will help you make your own application richer, more 
robust, and more extensible.  Feel free to contact us:


        Edward C. Smetak (Ed)

            Vice President of Engineering Software Consulting
            NanoSoft Corporation
            e-mail: ecsmetak@nanocorp.com or 
                    ecsmetak@neosoft.com

        NanoSoft Corporation
 
            3040 Post Oak Blvd., Suite 1430
            Houston, Texas  77056
            (713) 961-3061 - Fax 961-4028
            http://www.nanocorp.com 
            e-mail: info@nanocorp.com  


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

IMPORTANT NOTES

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(1) You will need the NanoSoft NSViews C++ Library to compile this code.  
    NSViews is also provided free of charge by NanoSoft and can be 
    downloaded from http://www.nanocorp.com.  The NSViews directory needs
    to be located at the same level as the ObjectView directory in order
    for the ObjectView code to compile and link (unless you want to alter
    the project settings).  Don't forget to put the NSViews.dll somewhere
    (either in your path or copied into the ObjectView\Debug or 
	ObjectView\Release directory) where ObjectView can find it.

(2) We have built and tested the code under Visual C++ Version 4.2 and 5.0
	running under Windows 95 and Windows NT 4.0.  The .mak files were all
	constructed under Version 4.2, but if you are running Version 5.0, they
	will be converted with no errors.
	
(3) You should build the various DLLs and EXE in the following order:

	1. NSViews\NSViews.mak  (NSViews.dll)

	2. ObjectView\OVCore\OVCore.mak  (OVCore.dll)

	3. ObjectView\ObjectView.mak  (ObjectView.exe)

	4. ObjectView\OVSimple\Simple.mak  (Simple.dll)

	5. ObjectView\OVRotor\OVRotor.mak  (OVRotor.dll)

	6. ObjectView\OVRotorDriver\OVRotorDriver.mak  (OVRotorDriver.dll)

	7. ObjectView\OVUserRotor\OVUserRotor.mak  (OVUserRotor.dll)
	
	All of the DLL projects under the ObjectView directory include a
	custom build step to copy the DLL to the ObjectView\Debug or the
	ObjectView\Release directory as required.  But, as previously stated,
	the NSViews.dll must be copied manually or put somewhere in your path.
	
(4) Regarding NSViews, there's a good article called "Dialogisthenics" by
    Ed Smetak and Mike Knewtson in the February 1997 issue of Windows Tech
	Journal. 

(5) Regarding ObjectView, there's a good article called "Using Dynamic
    Objects to Build Extensible MFC Apps" by Ed Smetak and Jean Caputo in
	the July 1997 issue of Microsoft Systems Journal (MSJ).

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

ObjectView Revision Notes

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Version 1.00 - 4/12/97

  Original code.


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
