// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "UserRotor.h"
#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CUserRotor,CGenericRotor,1)

CUserRotor::CUserRotor()
{

}

CUserRotor::~CUserRotor()
{

}

#define DEGREES_TO_RADIANS 0.01745
#define OUTSIDE_TO_INSIDE_RADIUS 0.9

void CUserRotor::DrawRotor(CDC *pDC, int nRadius, int nAngle) const
{
	CPen OutlinePen;
	OutlinePen.CreatePen(PS_SOLID,0,RGB(0,0,0));

	CBrush ExteriorBrush;
	ExteriorBrush.CreateSolidBrush(RGB(255,255,255));

	CBrush InteriorBrush;
	InteriorBrush.CreateSolidBrush(RGB(255,0,0));

	CPen* pPreviousPen = pDC->SelectObject(&OutlinePen);
	CBrush* pPreviousBrush = pDC->SelectObject(&ExteriorBrush);

	nRadius = (int)(OUTSIDE_TO_INSIDE_RADIUS*nRadius);

	pDC->Ellipse(-nRadius,nRadius,nRadius,-nRadius);

	nRadius = (int)(0.95*nRadius);

	CPoint arrayPoint[4];

	double nAngle1 = nAngle*DEGREES_TO_RADIANS;
	double nAngle2 = (nAngle+10.0)*DEGREES_TO_RADIANS;
	double nAngle3 = (nAngle-10.0)*DEGREES_TO_RADIANS;

	arrayPoint[0].x = (int)(nRadius*cos(nAngle1));
	arrayPoint[0].y = (int)(nRadius*sin(nAngle1));
	arrayPoint[1].x = (int)(nRadius*cos(nAngle2)*0.7);
	arrayPoint[1].y = (int)(nRadius*sin(nAngle2)*0.7);
	arrayPoint[2].x = 0;
	arrayPoint[2].y = 0;
	arrayPoint[3].x = (int)(nRadius*cos(nAngle3)*0.7);
	arrayPoint[3].y = (int)(nRadius*sin(nAngle3)*0.7);

	pDC->SelectObject(&InteriorBrush);
	pDC->Polygon(arrayPoint,4);

	LOGFONT LogFont;
	memset(&LogFont,0,sizeof(LogFont));
	lstrcpy(LogFont.lfFaceName, "Arial"); 
	LogFont.lfWeight = FW_BOLD;
	LogFont.lfEscapement = -nAngle*10;
	LogFont.lfItalic = TRUE;
	LogFont.lfHeight = (int)(nRadius * 0.23);

	CFont NewFont;
	NewFont.CreateFontIndirect(&LogFont);
	CFont* pPreviousFont = pDC->SelectObject(&NewFont);

	TEXTMETRIC TextMetric;
	pDC->GetTextMetrics(&TextMetric);

	double dY = TextMetric.tmHeight/2.0;
	double dX = -TextMetric.tmAveCharWidth*10.0;

	double dTextAngle = 3.1415926535 - atan(dY/-dX);
	double dTextRadius = sqrt(dY*dY + dX*dX);

	nAngle1 = nAngle*DEGREES_TO_RADIANS;

	dX = dTextRadius*cos(dTextAngle+nAngle1);
	dY = dTextRadius*sin(dTextAngle+nAngle1);

	pDC->SetBkMode(TRANSPARENT); 
	pDC->TextOut((int)dX,(int)dY,"NanoSoft",8);

	pDC->SelectObject(pPreviousFont);
	pDC->SelectObject(pPreviousPen);
	pDC->SelectObject(pPreviousBrush);
}

