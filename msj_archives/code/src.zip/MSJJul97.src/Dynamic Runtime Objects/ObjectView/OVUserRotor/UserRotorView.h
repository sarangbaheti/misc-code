// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __RotorView_h__
#define __RotorThreadView_h__

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CUserRotor;

class CUserRotorView : public CView
{

	DECLARE_DYNCREATE(CUserRotorView)

  public:

	int SetupDC(CDC *pdc);

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUserRotorView)
	protected:
	virtual void OnDraw(CDC* pDC);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

  protected:

	CUserRotorView(); 

	virtual ~CUserRotorView();

	// Generated message map functions
	//{{AFX_MSG(CUserRotorView)
	//}}AFX_MSG

    afx_msg LRESULT OnObjectInfo(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()

  private:

	CUserRotor* m_pRotor;

};

#endif

