// OVUserRotor.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include <afxdllx.h>
#include "UserRotor.h"
#include "UserRotorView.h"
#include "FlexibleChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static AFX_EXTENSION_MODULE OVUserRotorDLL = { NULL, NULL };

extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	if (dwReason == DLL_PROCESS_ATTACH)
	{
		TRACE0("OVUSERROTOR.DLL Initializing!\n");
		
		// Extension DLL one-time initialization
		AfxInitExtensionModule(OVUserRotorDLL, hInstance);

		// Insert this DLL into the resource chain
		new CDynLinkLibrary(OVUserRotorDLL);
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		TRACE0("OVUSERROTOR.DLL Terminating!\n");

        AfxTermExtensionModule(OVUserRotorDLL);
	}
	return 1;   // ok
}

extern "C" void WINAPI ClassInfo(CLSID& clsidClassID, 
	CLSID& clsidClassCategory, CString& csDescription,
	CRuntimeClass*& pObjectClass, CRuntimeClass*& pFrameClass,
	CRuntimeClass*& pViewClass)
{
	// ID: {08EA0501-90EF-11d0-A264-0040052E01FC}
	CLSID clsidID = { 0x8ea0501, 0x90ef, 0x11d0, 
		{ 0xa2, 0x64, 0x0, 0x40, 0x5, 0x2e, 0x1, 0xfc } };

	// CATEGORY: {A8D09C01-90C4-11d0-A264-0040052E01FC}
	CLSID clsidCategory = { 0xa8d09c01, 0x90c4, 0x11d0, 
		{ 0xa2, 0x64, 0x0, 0x40, 0x5, 0x2e, 0x1, 0xfc } };

	clsidClassID = clsidID;
	clsidClassCategory = clsidCategory;

	csDescription = "User Rotor";

	pObjectClass = RUNTIME_CLASS(CUserRotor);
	pFrameClass = RUNTIME_CLASS(CFlexibleChildFrame);
	pViewClass = RUNTIME_CLASS(CUserRotorView);
}
