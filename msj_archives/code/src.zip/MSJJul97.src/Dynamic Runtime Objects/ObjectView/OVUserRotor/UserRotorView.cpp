// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "stdafx.h"
#include "UserRotorView.h"
#include "ObjectBroker.h"
#include "ObjectInfoMessage.h"
#include "UserRotor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CUserRotorView, CView)

BEGIN_MESSAGE_MAP(CUserRotorView, CView)
	//{{AFX_MSG_MAP(CUserRotorView)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_OBJECTINFO,OnObjectInfo)
END_MESSAGE_MAP()

CUserRotorView::CUserRotorView()
{
	m_pRotor = NULL;
}

CUserRotorView::~CUserRotorView()
{
	m_pRotor->Release();
}

LRESULT CUserRotorView::OnObjectInfo(WPARAM wParam, LPARAM lParam)
{
	ObjectInfoMessage* pObjectInfoMessage = (ObjectInfoMessage*)(lParam);

	CObjectBroker* pObjectBroker = pObjectInfoMessage->pObjectBroker;

	CObjectInfo* pObjectInfo = 
		pObjectBroker->GetObjectInfoByKey(pObjectInfoMessage->pszObjectKey);
	ASSERT(pObjectInfo);

	m_pRotor = (CUserRotor*)pObjectInfo->GetObject();
	ASSERT(m_pRotor);
	ASSERT(m_pRotor->IsKindOf(RUNTIME_CLASS(CUserRotor)));

	return 1;
}

void CUserRotorView::OnDraw(CDC* pDC) 
{
	m_pRotor->DrawRotor(pDC,SetupDC(pDC),0);
}

int CUserRotorView::SetupDC(CDC *pdc)
{
	CRect rectMM_TEXT_Locator;
	GetClientRect(&rectMM_TEXT_Locator);

	CPoint pointMM_TEXT_Center = rectMM_TEXT_Locator.CenterPoint();

	pdc->SetMapMode(MM_HIMETRIC);
	pdc->SetViewportOrg(pointMM_TEXT_Center.x,
		pointMM_TEXT_Center.y);

	CSize sizeMM_HIMETRICLocator = rectMM_TEXT_Locator.Size();
	pdc->DPtoHIMETRIC(&sizeMM_HIMETRICLocator);

	int nRadius = min(sizeMM_HIMETRICLocator.cx,
		sizeMM_HIMETRICLocator.cy) / 2;

	return nRadius;
}

void CUserRotorView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	
}
