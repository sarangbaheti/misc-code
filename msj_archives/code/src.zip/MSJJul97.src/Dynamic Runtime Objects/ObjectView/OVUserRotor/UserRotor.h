// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#ifndef __Rotor_h__
#define __Rotor_h__

#include "GenericRotor.h"

class CUserRotor : public CGenericRotor
{

  DECLARE_SERIAL(CUserRotor);

  public:

	CUserRotor();

	virtual ~CUserRotor();

	virtual void DrawRotor(CDC *pDC, int nRadius, int nAngle) const;

};

#endif
