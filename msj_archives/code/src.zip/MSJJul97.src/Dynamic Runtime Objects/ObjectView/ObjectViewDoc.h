// Copyright (C) 1996 NanoSoft Corporation. All rights reserved.

#include "ObjectDoc.h"

class CObjectViewDoc : public CObjectDoc
{

	DECLARE_DYNCREATE(CObjectViewDoc)

  public:

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CObjectViewDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

	virtual ~CObjectViewDoc();

#ifdef _DEBUG
	virtual void AssertValid() const;
#endif

#ifdef _DEBUG
	virtual void Dump(CDumpContext& dc) const;
#endif

  public:

	CMDIChildWnd* m_pObjectBrokerWnd;

  protected:

	CObjectViewDoc();

	//{{AFX_MSG(CObjectViewDoc)
	afx_msg void OnWindowObjectBroker();
	afx_msg void OnWindowNew();
	afx_msg void OnUpdateWindowNew(CCmdUI* pCmdUI);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

};

