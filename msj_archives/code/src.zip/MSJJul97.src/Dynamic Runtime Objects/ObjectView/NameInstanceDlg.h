// NameInstanceDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNameInstanceDlg dialog

class CObjectBroker;

class CNameInstanceDlg : public CDialog
{
// Construction
public:
	CNameInstanceDlg(CObjectBroker* pObjectBroker, LPCSTR pszKey, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CNameInstanceDlg)
	enum { IDD = IDD_NAME_INSTANCE };
	CString	m_csName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNameInstanceDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNameInstanceDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:

	CString m_csKey;
	CObjectBroker* m_pObjectBroker;
};
