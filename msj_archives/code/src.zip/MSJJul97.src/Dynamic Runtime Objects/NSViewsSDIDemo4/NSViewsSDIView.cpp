// NSViewsSDIView.cpp : implementation of the CNSViewsSDIView class
//

#include "stdafx.h"
#include "NSViewsSDI.h"

#include "NSViewsSDIDoc.h"
#include "NSViewsSDIView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNSViewsSDIView

IMPLEMENT_DYNCREATE(CNSViewsSDIView, CNSFlexFormView)

BEGIN_MESSAGE_MAP(CNSViewsSDIView, CNSFlexFormView)
	//{{AFX_MSG_MAP(CNSViewsSDIView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CNSFlexFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CNSFlexFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CNSFlexFormView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNSViewsSDIView construction/destruction

CNSViewsSDIView::CNSViewsSDIView()
	: CNSFlexFormView(CNSViewsSDIView::IDD)
{
	//{{AFX_DATA_INIT(CNSViewsSDIView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// TODO: add construction code here

	AddFlexConstraint(IDC_CALENDAR1,NSFlexExpandRight,NSFlexExpandDown);
	AddFlexConstraint(IDC_BUTTON1,NSFlexShiftRight,NSFlexVerticallyFixed);
	AddFlexConstraint(IDC_BUTTON2,NSFlexShiftRight,NSFlexVerticallyFixed);
}

CNSViewsSDIView::~CNSViewsSDIView()
{
}

void CNSViewsSDIView::DoDataExchange(CDataExchange* pDX)
{
	CNSFlexFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNSViewsSDIView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BOOL CNSViewsSDIView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CNSFlexFormView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CNSViewsSDIView printing

BOOL CNSViewsSDIView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CNSViewsSDIView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CNSViewsSDIView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CNSViewsSDIView::OnPrint(CDC* pDC, CPrintInfo*)
{
	// TODO: add code to print the controls
}

/////////////////////////////////////////////////////////////////////////////
// CNSViewsSDIView diagnostics

#ifdef _DEBUG
void CNSViewsSDIView::AssertValid() const
{
	CNSFlexFormView::AssertValid();
}

void CNSViewsSDIView::Dump(CDumpContext& dc) const
{
	CNSFlexFormView::Dump(dc);
}

CNSViewsSDIDoc* CNSViewsSDIView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CNSViewsSDIDoc)));
	return (CNSViewsSDIDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CNSViewsSDIView message handlers
