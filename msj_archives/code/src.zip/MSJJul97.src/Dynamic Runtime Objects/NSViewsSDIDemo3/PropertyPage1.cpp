// PropertyPage1.cpp : implementation file
//

#include "stdafx.h"
#include "NSViewsSDI.h"
#include "PropertyPage1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropertyPage1 property page

IMPLEMENT_DYNCREATE(CPropertyPage1, CNSFlexPropertyPage)

CPropertyPage1::CPropertyPage1() : CNSFlexPropertyPage(CPropertyPage1::IDD)
{
	//{{AFX_DATA_INIT(CPropertyPage1)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	AddFlexConstraint(IDC_CALENDAR1,NSFlexExpandRight,NSFlexExpandDown);
	AddFlexConstraint(IDC_BUTTON1,NSFlexShiftRight,NSFlexVerticallyFixed);
	AddFlexConstraint(IDC_BUTTON2,NSFlexShiftRight,NSFlexVerticallyFixed);
}

CPropertyPage1::~CPropertyPage1()
{
}

void CPropertyPage1::DoDataExchange(CDataExchange* pDX)
{
	CNSFlexPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropertyPage1)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropertyPage1, CNSFlexPropertyPage)
	//{{AFX_MSG_MAP(CPropertyPage1)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropertyPage1 message handlers

void CPropertyPage1::OnButton1() 
{
	// call GetDocument and UpdateAllViews just to make sure they work
	GetDocument()->UpdateAllViews(NULL,1000); 
}

void CPropertyPage1::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint)
{
	// throw in this empty shell just to make sure it works	
}
