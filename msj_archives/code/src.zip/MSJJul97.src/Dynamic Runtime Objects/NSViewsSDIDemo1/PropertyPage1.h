// PropertyPage1.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropertyPage1 dialog

#include "NSFlexPropertyPage.h"

class CPropertyPage1 : public CNSFlexPropertyPage
{
	DECLARE_DYNCREATE(CPropertyPage1)

// Construction
public:
	CPropertyPage1();
	~CPropertyPage1();

    virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);  

// Dialog Data
	//{{AFX_DATA(CPropertyPage1)
	enum { IDD = IDD_DIALOG1 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropertyPage1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropertyPage1)
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
