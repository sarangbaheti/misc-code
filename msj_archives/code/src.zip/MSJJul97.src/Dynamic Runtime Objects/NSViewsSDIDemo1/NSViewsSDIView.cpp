// NSViewsSDIView.cpp : implementation of the CNSViewsSDIView class
//

#include "stdafx.h"
#include "NSViewsSDI.h"

#include "NSViewsSDIDoc.h"
#include "NSViewsSDIView.h"
#include "NSFlexPropertySheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNSViewsSDIView

IMPLEMENT_DYNCREATE(CNSViewsSDIView, CNSFlexPropertySheetView)

BEGIN_MESSAGE_MAP(CNSViewsSDIView, CNSFlexPropertySheetView)
	//{{AFX_MSG_MAP(CNSViewsSDIView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CNSFlexPropertySheetView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CNSFlexPropertySheetView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CNSFlexPropertySheetView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNSViewsSDIView construction/destruction

CNSViewsSDIView::CNSViewsSDIView()
{
	GetFlexPropertySheet()->AddPage(&m_FlexPropertyPage1);
	GetFlexPropertySheet()->AddPage(&m_FlexPropertyPage2);
}

CNSViewsSDIView::~CNSViewsSDIView()
{
}

BOOL CNSViewsSDIView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CNSFlexPropertySheetView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CNSViewsSDIView drawing

void CNSViewsSDIView::OnDraw(CDC* pDC)
{
	CNSViewsSDIDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

void CNSViewsSDIView::OnInitialUpdate()
{
	CNSFlexPropertySheetView::OnInitialUpdate();
	CSize sizeTotal;
	// TODO: calculate the total size of this view
	sizeTotal.cx = sizeTotal.cy = 100;
	SetScrollSizes(MM_TEXT, sizeTotal);

	GetParentFrame()->RecalcLayout(FALSE);
}

/////////////////////////////////////////////////////////////////////////////
// CNSViewsSDIView printing

BOOL CNSViewsSDIView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CNSViewsSDIView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CNSViewsSDIView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CNSViewsSDIView diagnostics

#ifdef _DEBUG
void CNSViewsSDIView::AssertValid() const
{
	CNSFlexPropertySheetView::AssertValid();
}

void CNSViewsSDIView::Dump(CDumpContext& dc) const
{
	CNSFlexPropertySheetView::Dump(dc);
}

CNSViewsSDIDoc* CNSViewsSDIView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CNSViewsSDIDoc)));
	return (CNSViewsSDIDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CNSViewsSDIView message handlers
