// PropertyPage2.cpp : implementation file
//

#include "stdafx.h"
#include "NSViewsSDI.h"
#include "PropertyPage2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropertyPage2 property page

IMPLEMENT_DYNCREATE(CPropertyPage2, CNSFlexPropertyPage)

CPropertyPage2::CPropertyPage2() : CNSFlexPropertyPage(CPropertyPage2::IDD)
{
	//{{AFX_DATA_INIT(CPropertyPage2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	AddFlexConstraint(IDC_EDIT1,NSFlexExpandRight,NSFlexExpandDown);
}

CPropertyPage2::~CPropertyPage2()
{
}

void CPropertyPage2::DoDataExchange(CDataExchange* pDX)
{
	CNSFlexPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropertyPage2)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropertyPage2, CNSFlexPropertyPage)
	//{{AFX_MSG_MAP(CPropertyPage2)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropertyPage2 message handlers
