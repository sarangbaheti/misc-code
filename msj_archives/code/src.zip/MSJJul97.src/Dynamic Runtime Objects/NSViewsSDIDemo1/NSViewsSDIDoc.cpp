// NSViewsSDIDoc.cpp : implementation of the CNSViewsSDIDoc class
//

#include "stdafx.h"
#include "NSViewsSDI.h"

#include "NSViewsSDIDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNSViewsSDIDoc

IMPLEMENT_DYNCREATE(CNSViewsSDIDoc, CDocument)

BEGIN_MESSAGE_MAP(CNSViewsSDIDoc, CDocument)
	//{{AFX_MSG_MAP(CNSViewsSDIDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNSViewsSDIDoc construction/destruction

CNSViewsSDIDoc::CNSViewsSDIDoc()
{
	// TODO: add one-time construction code here

}

CNSViewsSDIDoc::~CNSViewsSDIDoc()
{
}

BOOL CNSViewsSDIDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CNSViewsSDIDoc serialization

void CNSViewsSDIDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CNSViewsSDIDoc diagnostics

#ifdef _DEBUG
void CNSViewsSDIDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CNSViewsSDIDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CNSViewsSDIDoc commands
