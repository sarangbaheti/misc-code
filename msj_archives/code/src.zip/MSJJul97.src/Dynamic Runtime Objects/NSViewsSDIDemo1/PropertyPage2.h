// PropertyPage2.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropertyPage2 dialog

#include "NSFlexPropertyPage.h"

class CPropertyPage2 : public CNSFlexPropertyPage
{
	DECLARE_DYNCREATE(CPropertyPage2)

// Construction
public:
	CPropertyPage2();
	~CPropertyPage2();

// Dialog Data
	//{{AFX_DATA(CPropertyPage2)
	enum { IDD = IDD_DIALOG2 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropertyPage2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropertyPage2)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
