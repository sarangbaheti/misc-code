// NSViewsSDIView.h : interface of the CNSViewsSDIView class
//
/////////////////////////////////////////////////////////////////////////////

#include "NSFlexPropertySheetView.h"
#include "PropertyPage1.h"
#include "PropertyPage2.h"

class CNSViewsSDIView : public CNSFlexPropertySheetView
{
protected: // create from serialization only
	CNSViewsSDIView();
	DECLARE_DYNCREATE(CNSViewsSDIView)

// Attributes
public:
	CNSViewsSDIDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNSViewsSDIView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CNSViewsSDIView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CNSViewsSDIView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:

	CPropertyPage1 m_FlexPropertyPage1;
	CPropertyPage2 m_FlexPropertyPage2;
};

#ifndef _DEBUG  // debug version in NSViewsSDIView.cpp
inline CNSViewsSDIDoc* CNSViewsSDIView::GetDocument()
   { return (CNSViewsSDIDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
