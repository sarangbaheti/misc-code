// NSViewsSDIView.h : interface of the CNSViewsSDIView class
//
/////////////////////////////////////////////////////////////////////////////

#include "NSFlexFormView.h"

class CNSViewsSDIView : public CNSFlexFormView
{
protected: // create from serialization only
	CNSViewsSDIView();
	DECLARE_DYNCREATE(CNSViewsSDIView)

public:
	//{{AFX_DATA(CNSViewsSDIView)
	enum{ IDD = IDD_NSVIEWSSDI_FORM };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	CNSViewsSDIDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNSViewsSDIView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo*);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CNSViewsSDIView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CNSViewsSDIView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in NSViewsSDIView.cpp
inline CNSViewsSDIDoc* CNSViewsSDIView::GetDocument()
   { return (CNSViewsSDIDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
