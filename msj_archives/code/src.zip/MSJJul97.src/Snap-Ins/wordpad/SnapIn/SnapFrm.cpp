// Copyright (c) 1997, Microsoft Systems Journal
// Author: Steve Zimmerman
//
// SnapFrm.cpp : implementation file
//

#include "stdafx.h"
#include "..\resource.h"
#include <comcat.h>
#include <afxtempl.h>

#include "ISnapIn.h"
#include "SnapFrm.h"
#include "SnapIn.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSnapInFrame

IMPLEMENT_DYNAMIC(CSnapInFrame, CFrameWnd)

CSnapInFrame::~CSnapInFrame()
{
	for (int nLoop = 0; nLoop < m_snapIn.GetSize(); nLoop++)
		delete m_snapIn[nLoop];
}

int CSnapInFrame::CreateSnapInBar()
{
	EnableDocking(CBRS_ALIGN_ANY);
	m_snapInBar.Create(this, WS_CHILD|WS_VISIBLE|CBRS_TOP,
		ID_VIEW_SNAPINBAR);

	HDC screenDC = ::GetDC(NULL);
	BOOL bLargeIcons = GetDeviceCaps(screenDC, LOGPIXELSX) >= 120;
	::ReleaseDC(NULL, screenDC);
	if (bLargeIcons)
		m_snapInBar.SetSizes(CSize(31,30), CSize(24,24));
	else
		m_snapInBar.SetSizes(CSize(23,22), CSize(16,16));

	m_snapInBar.SetBarStyle(m_snapInBar.GetBarStyle() |
		CBRS_TOOLTIPS |	CBRS_FLYBY | CBRS_SIZE_DYNAMIC);
	m_snapInBar.EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_snapInBar);
	return bLargeIcons ? 24 : 16;
}

#define VIEW_MENU_POSITION		2
#define TOOLS_MENU_POSITION		5

int CSnapInFrame::AddMenuEntries()
{
	CMenu* pSubMenu = GetMenu()->GetSubMenu(VIEW_MENU_POSITION);
	ASSERT(pSubMenu);
	pSubMenu->InsertMenu(0, MF_BYPOSITION|MF_STRING|MF_CHECKED,
		ID_VIEW_SNAPINBAR, _T("Snap-&In Bar"));

	HMENU hMenu = ::CreateMenu();
	GetMenu()->InsertMenu(TOOLS_MENU_POSITION, MF_BYPOSITION|MF_POPUP,
		(UINT) hMenu, _T("&Tools"));

	return TOOLS_MENU_POSITION;
}	

void CSnapInFrame::HideSnapInBar()
{
	CControlBar* pBar = GetControlBar(ID_VIEW_SNAPINBAR);
	if (pBar != NULL)
		ShowControlBar(pBar, FALSE, FALSE);
}

void CSnapInFrame::OnStateChange(int nMsg)
{
	for (int nLoop = 0; nLoop < m_snapIn.GetSize(); nLoop++)
	{
		ISnapIn* pInt = m_snapIn[nLoop]->Interface();
		pInt->OnStateChange(GetSnapInContext(nMsg));
	}
}

BOOL CSnapInFrame::GetNextSnapInClsID(ICatInformation** ppCatInfo,
	IEnumCLSID** ppEnum, CLSID* pClsID)
{
	ASSERT(ppCatInfo && ppEnum);
	
	// We get a pointer to ICatInformation so that we can find all
	// of the compatible SnapIns in the registry.
	
	if (*ppCatInfo == NULL)
	{
		HRESULT hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr, NULL,
			CLSCTX_INPROC_SERVER, IID_ICatInformation, (LPVOID*) ppCatInfo);
		if (hr != S_OK)
			return FALSE;
	}

	// We only enumerate the SnapIns that support CATID_ISnapIn
	// and are compatible with this application.

	if (*ppEnum == NULL)
	{
		CATID* pCatIDs;
		int reqCatIDs = GetSupportedCategories(&pCatIDs);

		CATID snapInCatID = CATID_ISnapIn;
		HRESULT hr = (*ppCatInfo)->EnumClassesOfCategories(1, &snapInCatID,
			reqCatIDs, pCatIDs, ppEnum);
		if (hr != S_OK)
		{
			(*ppCatInfo)->Release();
			return FALSE;
		}

		(*ppEnum)->Reset();
	}

	ULONG lFetched;
	if ((*ppEnum)->Next(1, pClsID, &lFetched) != S_OK)
	{
		(*ppEnum)->Release();
		(*ppCatInfo)->Release();
		return FALSE;
	}

	return TRUE;
}

BEGIN_MESSAGE_MAP(CSnapInFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CSnapInFrame)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
	ON_UPDATE_COMMAND_UI(ID_VIEW_SNAPINBAR, OnUpdateViewSnapInBar)
	ON_COMMAND_EX(ID_VIEW_SNAPINBAR, OnViewSnapInBarCheck)
	ON_UPDATE_COMMAND_UI_RANGE(ID_TOOLS_START, ID_TOOLS_END, OnUpdateSnapIn)
	ON_COMMAND_RANGE(ID_TOOLS_START, ID_TOOLS_END, OnSnapIn)
	ON_NOTIFY_EX_RANGE(TTN_NEEDTEXTW, 0, 0xFFFF, OnToolTipText)
	ON_NOTIFY_EX_RANGE(TTN_NEEDTEXTA, 0, 0xFFFF, OnToolTipText)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSnapInFrame message handlers

int CSnapInFrame::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	int nBmpSize = CreateSnapInBar();

	CLSID clsID;
	IEnumCLSID* pEnum = NULL;
	ICatInformation* pCatInfo = NULL;

	int nSubMenu;
	int nIndex = 0;
	while (GetNextSnapInClsID(&pCatInfo, &pEnum, &clsID))
	{
		CSnapIn* pSnapIn = new CSnapIn(clsID, nIndex + ID_TOOLS_START);
		if (!pSnapIn->Interface() ||
			!pSnapIn->Interface()->SupportsInterface(GetSnapInContext(0)))
		{
			delete pSnapIn;
			continue;
		}

		if (m_snapIn.GetSize() == 0)
			nSubMenu = AddMenuEntries();

		ASSERT(GetMenu()->GetSubMenu(nSubMenu));
		if (pSnapIn->AddMenuItem(GetMenu()->GetSubMenu(nSubMenu)))
			pSnapIn->AddToolbarButton(m_snapInBar, nBmpSize);
		m_snapIn.Add(pSnapIn);
		nIndex++;
	}

	return 0;
}

void CSnapInFrame::ActivateFrame(int nCmdShow) 
{
	if (m_snapIn.GetSize() == 0)
		HideSnapInBar();
	
	CFrameWnd::ActivateFrame(nCmdShow);
}

void CSnapInFrame::GetMessageString(UINT nID, CString& rMessage) const
{
	if (nID < ID_TOOLS_START || nID > ID_TOOLS_END)
	{
		CFrameWnd::GetMessageString (nID, rMessage);
		return;
	}

	CSnapIn* pSnapIn = m_snapIn[nID - ID_TOOLS_START];
	HINSTANCE myInst = AfxGetResourceHandle();
	AfxSetResourceHandle(pSnapIn->Interface()->GetResourceInstance());
	nID = pSnapIn->Interface()->GetMessageTextID();
	CFrameWnd::GetMessageString(nID, rMessage);
	AfxSetResourceHandle(myInst);
}

void CSnapInFrame::OnUpdateViewSnapInBar(CCmdUI* pCmdUI)
{
	CControlBar* pBar = GetControlBar(ID_VIEW_SNAPINBAR);
	if (pBar != NULL)
	{
		pCmdUI->SetCheck((pBar->GetStyle() & WS_VISIBLE) != 0);
		return;
	}
	pCmdUI->ContinueRouting();
}

BOOL CSnapInFrame::OnViewSnapInBarCheck(UINT nID)
{
	CControlBar* pBar = GetControlBar(ID_VIEW_SNAPINBAR);
	if (pBar != NULL)
	{
		ShowControlBar(pBar, (pBar->GetStyle() & WS_VISIBLE) == 0, FALSE);
		return TRUE;
	}
	return FALSE;
}

void CSnapInFrame::OnUpdateSnapIn(CCmdUI* pCmdUI)
{
	CSnapIn* pSnapIn = m_snapIn[pCmdUI->m_nID - ID_TOOLS_START];
	pCmdUI->Enable(pSnapIn->Interface()->
		IsEnabled(GetSnapInContext(0)));
}

void CSnapInFrame::OnSnapIn(UINT nID)
{
	CSnapIn* pSnapIn = m_snapIn[nID - ID_TOOLS_START];
	pSnapIn->Interface()->OnCommand(GetSnapInContext(0));
}

BOOL CSnapInFrame::OnToolTipText(UINT nID, NMHDR* pNMHDR, LRESULT* pResult)
{
	if (pNMHDR->idFrom < ID_TOOLS_START || pNMHDR->idFrom > ID_TOOLS_END)
		return CFrameWnd::OnToolTipText(nID, pNMHDR, pResult);

	CSnapIn* pSnapIn = m_snapIn[pNMHDR->idFrom - ID_TOOLS_START];
	HINSTANCE myInst = AfxGetResourceHandle();
	AfxSetResourceHandle(pSnapIn->Interface()->GetResourceInstance());
	pNMHDR->idFrom = pSnapIn->Interface()->GetMessageTextID();
	BOOL bResult = CFrameWnd::OnToolTipText(nID, pNMHDR, pResult);
	AfxSetResourceHandle(myInst);
	
	return bResult;
}
