// Copyright (c) 1997, Microsoft Systems Journal
// Author: Steve Zimmerman
//
// SnapFrm.h : header file
//

class CSnapIn;
class CSnapInManager;
interface ICatInformation;
interface IEnumCLSID;

class CSnapInFrame : public CFrameWnd
{
protected:
	DECLARE_DYNAMIC(CSnapInFrame);
	CTypedPtrArray<CPtrArray, CSnapIn*> m_snapIn;
	CToolBar m_snapInBar;

	void HideSnapInBar();

	virtual ~CSnapInFrame();
	virtual int CreateSnapInBar();
	virtual int AddMenuEntries();
	virtual BOOL GetNextSnapInClsID(ICatInformation** ppCatInfo,
		IEnumCLSID** ppEnum, CLSID* pClsID);
	virtual IUnknown* GetSnapInContext(int nMsg) = 0;
	virtual int GetSupportedCategories(GUID** ppCatIDs) = 0;

	//{{AFX_MSG(CSnapInFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	afx_msg void OnUpdateViewSnapInBar(CCmdUI* pCmdUI);
	afx_msg BOOL OnViewSnapInBarCheck(UINT nID);
	afx_msg void OnUpdateSnapIn(CCmdUI* pCmdUI);
	afx_msg void OnSnapIn(UINT nID);
	afx_msg BOOL OnToolTipText(UINT, NMHDR* pNMHDR, LRESULT* pResult);

public:
	void OnStateChange(int nMsg);

	//{{AFX_VIRTUAL(CSnapInFrame)
	public:
	virtual void ActivateFrame(int nCmdShow = -1);
	//}}AFX_VIRTUAL
	virtual void GetMessageString(UINT nID, CString& rMessage) const;
};

// These must be defined in order for CSnapInFrame to
// compile correctly. However, you may define them as
// you wish in resource.h if these values conflict
// with yours.

#ifndef ID_VIEW_SNAPINBAR
#define ID_VIEW_SNAPINBAR               59999
#define ID_TOOLS_START					60000
#define ID_TOOLS_END					60100
#endif