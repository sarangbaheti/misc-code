// Copyright (c) 1997, Microsoft Systems Journal
// Author: Steve Zimmerman
//

interface ISnapIn;

class CSnapIn
{
	CLSID m_clsID;
	ISnapIn* m_pInt;
	UINT m_nCommandID;

public:
	CSnapIn(const CLSID& strClassID, UINT nCmdID);
	~CSnapIn();
	BOOL AddToolbarButton(CToolBar& toolBar, UINT nSize);
	BOOL AddMenuItem(CMenu*);

	ISnapIn* Interface()	{ return m_pInt; }

	// Copy constructor and assignment operator are not
	// currently supported.

	CSnapIn(const CSnapIn& other);
	CSnapIn& CSnapIn::operator=(const CSnapIn&);
};
