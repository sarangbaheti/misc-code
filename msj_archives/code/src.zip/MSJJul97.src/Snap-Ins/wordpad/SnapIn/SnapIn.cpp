// Copyright (c) 1997, Microsoft Systems Journal
// Author: Steve Zimmerman
//

#include "stdafx.h"
#include "initguid.h"
#include "ISnapIn.h"
#include "SnapIn.h"

///////////////////////////////////////////////////////////////////

CSnapIn::CSnapIn(const CLSID& clsID, UINT nCmdID)
: m_pInt(NULL), m_nCommandID(nCmdID)
{
	// We create an instance of the SnapIn specified by clsID

	CoCreateInstance(clsID, NULL, CLSCTX_INPROC_SERVER,
		IID_ISnapIn, (LPVOID*) &m_pInt);
}

CSnapIn::~CSnapIn()
{
	if (m_pInt)
		m_pInt->Release();
}
	
BOOL CSnapIn::AddToolbarButton(CToolBar& toolBar, UINT nSize)
{
	ASSERT(m_pInt);
	if (m_pInt->GetBitmapID(nSize) == -1)
		return FALSE;

	CToolBarCtrl& controlBar = toolBar.GetToolBarCtrl();

	TBADDBITMAP tbab;
	tbab.hInst = m_pInt->GetResourceInstance();
	tbab.nID = m_pInt->GetBitmapID(nSize);

	TBBUTTON tbButton;
	tbButton.fsState = TBSTATE_ENABLED;
	tbButton.fsStyle = TBSTYLE_BUTTON;
	tbButton.idCommand = m_nCommandID;
	tbButton.iBitmap =
		controlBar.SendMessage(TB_ADDBITMAP, 1, (LPARAM)&tbab);

	VERIFY( controlBar.AddButtons(1, &tbButton) );
	return TRUE;
}

BOOL CSnapIn::AddMenuItem(CMenu* pMenu)
{
	ASSERT(m_pInt && pMenu);
	if (m_pInt->GetMenuTextID() == -1)
		return FALSE;

	CString strMenuItem;
	HINSTANCE myInst = AfxGetResourceHandle();
	AfxSetResourceHandle(m_pInt->GetResourceInstance());
	strMenuItem.LoadString(m_pInt->GetMenuTextID());
	AfxSetResourceHandle(myInst);

	pMenu->AppendMenu(MF_STRING, m_nCommandID, strMenuItem);
	return TRUE;
}
