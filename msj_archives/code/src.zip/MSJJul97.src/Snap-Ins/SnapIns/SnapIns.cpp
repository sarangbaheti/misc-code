// Copyright (c) 1997, Microsoft Systems Journal
// Author: Steve Zimmerman
//
// SnapIns.cpp : Implementation of DLL Exports.

// You will need the NT SUR Beta 2 SDK or VC 4.2 in order to build this 
// project.  This is because you will need MIDL 3.00.15 or higher and new
// headers and libs.  If you have VC 4.2 installed, then everything should
// already be configured correctly.

// Note: Proxy/Stub Information
//		To build a separate proxy/stub DLL, 
//		run nmake -f SnapInsps.mak in the project directory.

#include "stdafx.h"
#include "resource.h"
#include "initguid.h"
#include "comcat.h"

#include "ISnapIn.h"
#include "IRichDoc.h"
#include "RichDoc.h"
#include "WordCount.h"
#include "RemoveDup.h"
#include "Correct.h"

HRESULT RegisterComponentCategory(CATID catid, TCHAR* catDescription,
	BOOL bRegister = TRUE);
HRESULT RegisterClassReqCategory(const CLSID* rclsid, CATID rgcatid,
	BOOL bRegister = TRUE);
HRESULT RegisterClassImplCategory(const CLSID* rclsid, CATID rgcatid,
	BOOL bRegister = TRUE);

#define IID_DEFINED

CComModule _Module;

BEGIN_OBJECT_MAP(ObjectMap)
	OBJECT_ENTRY(CLSID_CWordCount, CWordCount)
	OBJECT_ENTRY(CLSID_CRemoveDup, CRemoveDup)
	OBJECT_ENTRY(CLSID_CAutoCorrect, CAutoCorrect)	
END_OBJECT_MAP()

class CMyApp : public CWinApp
{
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
};

CMyApp theApp;

BOOL CMyApp::InitInstance()
{
	_Module.Init(ObjectMap, m_hInstance);
	return CWinApp::InitInstance();
}

int CMyApp::ExitInstance()
{
	_Module.Term();
	return CWinApp::ExitInstance();
}

/////////////////////////////////////////////////////////////////////////////
// Used to determine whether the DLL can be unloaded by OLE

STDAPI DllCanUnloadNow(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return (AfxDllCanUnloadNow()==S_OK && _Module.GetLockCount()==0) ? S_OK : S_FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// Returns a class factory to create an object of the requested type

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
	return _Module.GetClassObject(rclsid, riid, ppv);
}

/////////////////////////////////////////////////////////////////////////////
// DllRegisterServer - Adds entries to the system registry

STDAPI DllRegisterServer(void)
{
	// First we register the ISnapIn and IRichDocContext
	// interfaces as special categories. For simplicity,
	// I just use the CLSIDs as the CATIDs. In your code,
	// you should register ISnapIn (and IRichDocContext if
	// you happen to use it) using the same text description
	// given here. We can't unregister these categories
	// since another module might require them.

	RegisterComponentCategory(CATID_ISnapIn, _T("Snap-Ins"));
	RegisterComponentCategory(CATID_IRichDocContext,
		_T("Snap-Ins that support the IRichDocContext interface"));

	// Now we register each control as implementing ISnapIn
	// and requiring that its container support IRichDocContext

	_ATL_OBJMAP_ENTRY* pEntry = _Module.m_pObjMap;
	while (pEntry->pclsid != NULL)
	{
		RegisterClassImplCategory(pEntry->pclsid, CATID_ISnapIn);
		RegisterClassReqCategory(pEntry->pclsid, CATID_IRichDocContext);
		pEntry++;
	}

	// register all the other stuff
	
	return _Module.RegisterServer(FALSE);	// No typelib
}

/////////////////////////////////////////////////////////////////////////////
// DllUnregisterServer - Removes entries from the system registry

STDAPI DllUnregisterServer(void)
{
	_Module.UnregisterServer();
	return S_OK;
}

HRESULT RegisterComponentCategory(CATID catid,
	TCHAR* catDescription, BOOL bRegister)
{
	ICatRegister* pcr = NULL;
	HRESULT hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr, 
		NULL, CLSCTX_INPROC_SERVER, IID_ICatRegister, (void**)&pcr);
	if (FAILED(hr))
		return hr;

	// Make sure the HKCR\Component Categories\{..catid...}
	// key is registered

	CATEGORYINFO catinfo;
	catinfo.catid = catid;
	catinfo.lcid = 0x0409; // English is all for now

	// Make sure the provided description is not too long.
	// Only copy the first 127 characters if it is

	USES_CONVERSION;
	int len = min(_tcslen(catDescription), 127);
	wcsncpy(catinfo.szDescription, T2W(catDescription), len);
	catinfo.szDescription[len] = 0;

	if (bRegister)
		hr = pcr->RegisterCategories(1, &catinfo);
	else 
		hr = pcr->UnRegisterCategories(1, &catid);

	pcr->Release();
	return hr;
}

HRESULT RegisterClassReqCategory(const CLSID* pclsid,
	CATID rgcatid, BOOL bRegister)
{
	_ASSERTE(pclsid);
	
	ICatRegister* pcr = NULL;
	HRESULT hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr, 
		NULL, CLSCTX_INPROC_SERVER, IID_ICatRegister, (void**)&pcr);
	if (FAILED(hr))
		return hr;

	return bRegister ? pcr->RegisterClassReqCategories(*pclsid, 1, &rgcatid)
		: pcr->UnRegisterClassReqCategories(*pclsid, 1, &rgcatid);
}

HRESULT RegisterClassImplCategory(const CLSID* pclsid,
	CATID rgcatid, BOOL bRegister)
{
	_ASSERTE(pclsid);

	ICatRegister* pcr = NULL;
	HRESULT hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr, 
		NULL, CLSCTX_INPROC_SERVER, IID_ICatRegister, (void**)&pcr);
	if (FAILED(hr))
		return hr;

	return bRegister ? pcr->RegisterClassImplCategories(*pclsid, 1, &rgcatid)
		: pcr->UnRegisterClassImplCategories(*pclsid, 1, &rgcatid);
}
