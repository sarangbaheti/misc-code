// Copyright (c) 1997, Microsoft Systems Journal
// Author: Steve Zimmerman
//
// WordCount.h : Declaration of the CWordCount


#include "resource.h"       // main symbols

DEFINE_GUID(CLSID_CWordCount,
	0xD6152CD7, 0x8402, 0x11D0, 0xA2, 0xA8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00);

interface IRichDocContext;

class CWordCount : 
	public ISnapIn,
	public CRichDocHelper,
	public CComObjectRoot,
	public CComCoClass<CWordCount,&CLSID_CWordCount>
{
public:
	CWordCount() {}
BEGIN_COM_MAP(CWordCount)
	COM_INTERFACE_ENTRY(ISnapIn)
END_COM_MAP()
//DECLARE_NOT_AGGREGATABLE(CWordCount) 
// Remove the comment from the line above if you don't want your object to 
// support aggregation.  The default is to support it

DECLARE_REGISTRY(CWordCount, _T("SnapIns.WordCount.1"),
	_T("SnapIns.WordCount"), IDS_WORDCOUNT_DESC, THREADFLAGS_BOTH)

// ISnapIn
public:
	STDMETHOD_(BOOL, SupportsInterface)(THIS_ IUnknown* lpUnk);
	STDMETHOD_(HINSTANCE, GetResourceInstance) (THIS_);
	STDMETHOD_(int, GetMenuTextID)(THIS_);
	STDMETHOD_(int, GetMessageTextID)(THIS_);
	STDMETHOD_(int, GetBitmapID)(THIS_ UINT nSize);
	STDMETHOD_(BOOL, IsEnabled)(THIS_ IUnknown* lpUnk);
	STDMETHOD_(void, OnStateChange)(THIS_ IUnknown* lpUnk);
	STDMETHOD_(void, OnCommand)(THIS_ IUnknown* lpUnk);
};
