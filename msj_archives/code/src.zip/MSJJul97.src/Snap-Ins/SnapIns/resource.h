//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SnapIns.rc
//
#define IDS_WORDCOUNT_DESC              1
#define IDS_REMOVEDUP_DESC              2
#define IDS_AUTOCORRECT_DESC            3
#define IDC_REMOVE                      201
#define IDC_LIST_WORD                   202
#define IDC_ADD                         203
#define IDC_LIST_REPLACE                204
#define IDC_EDIT_WORD                   205
#define IDC_EDIT_REPLACE                206
#define IDB_AUTOCORRECT_SMALL           210
#define IDB_AUTOCORRECT_LARGE           211
#define IDB_REMOVE_LARGE                212
#define IDD_AUTOCORRECT                 212
#define IDB_REMOVE_SMALL                213
#define IDS_AUTOCORRECT_MESSAGE         32778
#define IDS_REMOVE_MESSAGE              32779
#define IDS_AUTOCORRECT_MENU            32780
#define IDS_REMOVE_MENU                 32781

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        213
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         206
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
