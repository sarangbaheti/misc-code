// Copyright (c) 1997, Microsoft Systems Journal
// Author: Steve Zimmerman
//
// RemoveDup.cpp : Implementation of CSnapInsApp and DLL registration.

#include "stdafx.h"
#include <richedit.h>
#include "ISnapIn.h"
#include "IRichDoc.h"
#include "RichDoc.h"
#include "RemoveDup.h"

STDMETHODIMP_(BOOL) CRemoveDup::SupportsInterface(IUnknown* lpUnk)
{
	return IsValidContainer(lpUnk);
}

STDMETHODIMP_(HINSTANCE) CRemoveDup::GetResourceInstance()
{
	return _Module.GetResourceInstance();
}

STDMETHODIMP_(int) CRemoveDup::GetMenuTextID()
{
	return IDS_REMOVE_MENU;
}

STDMETHODIMP_(int) CRemoveDup::GetMessageTextID()
{
	return IDS_REMOVE_MESSAGE;
}

STDMETHODIMP_(int) CRemoveDup::GetBitmapID(UINT nSize)
{
	switch(nSize)
	{
		case 16:
			return IDB_REMOVE_SMALL;
		case 24:
			return IDB_REMOVE_LARGE;
		default:
			return -1;
	}
}

STDMETHODIMP_(BOOL) CRemoveDup::IsEnabled(IUnknown* lpUnk)
{
	IRichDocContext* lpContext;
	HWND hWnd = GetRichEditControl(lpUnk, &lpContext);
	lpContext->Release();
	return ::SendMessage(hWnd, WM_GETTEXTLENGTH, NULL, NULL);
}

STDMETHODIMP_(void) CRemoveDup::OnStateChange(IUnknown* lpUnk)
{
}

STDMETHODIMP_(void) CRemoveDup::OnCommand(IUnknown* lpUnk)
{
	IRichDocContext* lpContext;
	HWND hWnd = GetRichEditControl(lpUnk, &lpContext);

	char sBuffer[200];
	TEXTRANGE txtRange;
	BOOL bFoundRepeat = FALSE;
	txtRange.lpstrText = sBuffer;
	
	char sLast[100];
	UINT nNext = 0, nLast = 1;
	while (nNext != nLast)
	{	
		nLast = nNext;
		UINT nNextWord = SendMessage(hWnd, EM_FINDWORDBREAK,
			WB_MOVEWORDRIGHT, nLast);
		UINT nNextBreak = SendMessage(hWnd, EM_FINDWORDBREAK,
			WB_RIGHTBREAK, nLast);
		nNext = min(nNextWord, nNextBreak);
		if (nNext == nLast)
			continue;

		txtRange.chrg.cpMin = nLast;
		txtRange.chrg.cpMax = nNext;
		SendMessage(hWnd, EM_GETTEXTRANGE, 0, (LPARAM) &txtRange);
		_ASSERTE(!strchr(sBuffer, ' '));
		if (stricmp(sLast, sBuffer) != 0)
			strcpy(sLast, sBuffer);
		else
		{
			bFoundRepeat = TRUE;
			SendMessage(hWnd, EM_SETSEL, nLast, nNext);
			wsprintf(sBuffer, "The word '%s' appears twice in a row.\n"
				"Delete repeated word?", sLast);
			if (MessageBox(NULL, sBuffer,
				"Repeated Word", MB_YESNO) == IDYES)
			{
				SendMessage(hWnd, EM_SETSEL, nLast-1, nNext);
				SendMessage(hWnd, EM_REPLACESEL, TRUE, (LPARAM)"");
				nNext = nLast - 1;
			}
		}

		nLast = nNext;
		nNext = SendMessage(hWnd, EM_FINDWORDBREAK,
			WB_RIGHT, nLast);
	}

	SendMessage(hWnd, EM_SETSEL, (WPARAM)-1, 0);
	if (!bFoundRepeat)
	{
		MessageBox(NULL, "No repeated words were found.",
			"Remove Repeats", MB_OK);
	}

	lpContext->Release();
}
