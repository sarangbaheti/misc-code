// Copyright (c) 1997, Microsoft Systems Journal
// Author: Steve Zimmerman
//
// CorrectDlg.h : header file
//

class CCorrectDlg : public CDialog
{
protected:
	CStringArray m_strGood;
	CStringArray m_strBad;
	HICON m_hIcon;
	int m_nWordTop;
	int m_nReplaceTop;

	//{{AFX_DATA(CCorrectDlg)
	enum { IDD = IDD_AUTOCORRECT };
	CButton	m_btnOK;
	CEdit	m_editWord;
	CButton	m_btnRemove;
	CListBox	m_listWord;
	CListBox	m_listReplace;
	CButton	m_btnAdd;
	CString	m_strReplace;
	CString	m_strWord;
	//}}AFX_DATA
	//{{AFX_MSG(CCorrectDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeEdit();
	afx_msg void OnAdd();
	afx_msg void OnSelchangeListReplace();
	afx_msg void OnSelchangeListWord();
	afx_msg void OnRemove();
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

public:
	CCorrectDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CCorrectDlg();
	BOOL FindMatch(LPCTSTR lpWord, LPCTSTR* lppReplace);

	//{{AFX_VIRTUAL(CCorrectDlg)
	public:
	virtual void Serialize(CArchive& ar);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL
};
