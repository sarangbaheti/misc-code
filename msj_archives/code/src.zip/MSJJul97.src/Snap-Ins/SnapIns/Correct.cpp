// Copyright (c) 1997, Microsoft Systems Journal
// Author: Steve Zimmerman
//
// Correct.cpp : Implementation of CSnapInsApp and DLL registration.

#include "stdafx.h"
#include <richedit.h>
#include "ISnapIn.h"
#include "IRichDoc.h"

#include "RichDoc.h"
#include "Correct.h"
#include "CorrectDlg.h"

CAutoCorrect::CAutoCorrect()
{
	m_dlgBox = new CCorrectDlg;
}

CAutoCorrect::~CAutoCorrect()
{
	delete m_dlgBox;
}

STDMETHODIMP_(BOOL) CAutoCorrect::SupportsInterface(IUnknown* lpUnk)
{
	return IsValidContainer(lpUnk);
}

STDMETHODIMP_(HINSTANCE) CAutoCorrect::GetResourceInstance()
{
	return _Module.GetResourceInstance();
}

STDMETHODIMP_(int) CAutoCorrect::GetMenuTextID()
{
	return IDS_AUTOCORRECT_MENU;
}

STDMETHODIMP_(int) CAutoCorrect::GetMessageTextID()
{
	return IDS_AUTOCORRECT_MESSAGE;
}

STDMETHODIMP_(int) CAutoCorrect::GetBitmapID(UINT nSize)
{
	switch(nSize)
	{
		case 16:
			return IDB_AUTOCORRECT_SMALL;
		case 24:
			return IDB_AUTOCORRECT_LARGE;
		default:
			return -1;
	}
}

STDMETHODIMP_(BOOL) CAutoCorrect::IsEnabled(IUnknown* lpUnk)
{
	return TRUE;
}

STDMETHODIMP_(void) CAutoCorrect::OnStateChange(IUnknown* lpUnk)
{
	IRichDocContext* lpContext;
	HWND hWnd = GetRichEditControl(lpUnk, &lpContext);

	char sBuffer[200];
	TEXTRANGE txtRange;
	txtRange.lpstrText = sBuffer;

	DWORD dwStart, dwEnd;
	SendMessage(hWnd, EM_GETSEL, NULL, (LPARAM) &dwEnd);
	dwStart = SendMessage(hWnd, EM_FINDWORDBREAK, WB_LEFT, dwEnd);
	
	txtRange.chrg.cpMin = dwStart;
	txtRange.chrg.cpMax = dwEnd;
	SendMessage(hWnd, EM_GETTEXTRANGE, 0, (LPARAM) &txtRange);

	int nChar = _tcslen(sBuffer);
	if (nChar && (_istpunct(sBuffer[--nChar]) || _istspace(sBuffer[nChar])))
	{
		LPCTSTR sReplace;
		sBuffer[nChar] = 0;
		if (m_dlgBox->FindMatch(sBuffer, &sReplace))
		{
			SendMessage(hWnd, EM_SETSEL, dwStart, dwEnd-1);
			SendMessage(hWnd, EM_REPLACESEL, TRUE, (LPARAM)sReplace);
			SendMessage(hWnd, EM_SETSEL, (WPARAM)dwEnd, dwEnd);
		}
	}

	lpContext->Release();
}

STDMETHODIMP_(void) CAutoCorrect::OnCommand(IUnknown* lpUnk)
{
	if (IsValidContainer(lpUnk))
	{
		AFX_MANAGE_STATE(AfxGetStaticModuleState());	
		m_dlgBox->DoModal();
	}
}
