// Copyright (c) 1997, Microsoft Systems Journal
// Author: Steve Zimmerman
//
// RichDoc.h: interface for the CRichDocHelper class.
//
//////////////////////////////////////////////////////////////////////

class CRichDocHelper  
{
public:
	BOOL IsValidContainer(IUnknown* pUnk);
	HWND GetRichEditControl(IUnknown* pUnk, IRichDocContext** ppRichDoc);
};
