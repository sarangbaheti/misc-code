// Copyright (c) 1997, Microsoft Systems Journal
// Author: Steve Zimmerman
//
// IRichDocContext Interface Definition:
// {305BB760-8993-11D0-A2C4-000000000000}

DEFINE_GUID(IID_IRichDocContext, 
	0x305bb760, 0x8993, 0x11d0, 0xa2, 0xc4, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0);

#define CATID_IRichDocContext IID_IRichDocContext

DECLARE_INTERFACE_(IRichDocContext, IUnknown)
{
    STDMETHOD_(HWND, GetRichEditCtrl)() PURE;
    STDMETHOD_(void, SetStatusText)(LPCTSTR) PURE;
};
