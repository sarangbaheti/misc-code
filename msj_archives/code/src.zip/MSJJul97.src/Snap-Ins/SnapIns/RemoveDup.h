// Copyright (c) 1997, Microsoft Systems Journal
// Author: Steve Zimmerman
//
// RemoveDup.h : Declaration of the CRemoveDup


#include "resource.h"       // main symbols

DEFINE_GUID(CLSID_CRemoveDup,
	0xD6152CE1, 0x8402, 0x11D0, 0xA2, 0xA8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00);

class CRemoveDup : 
	public ISnapIn,
	public CRichDocHelper,
	public CComObjectRoot,
	public CComCoClass<CRemoveDup,&CLSID_CRemoveDup>
{
public:
	CRemoveDup() {}
BEGIN_COM_MAP(CRemoveDup)
	COM_INTERFACE_ENTRY(ISnapIn)
END_COM_MAP()
//DECLARE_NOT_AGGREGATABLE(CRemoveDup) 
// Remove the comment from the line above if you don't want your object to 
// support aggregation.  The default is to support it

DECLARE_REGISTRY(CRemoveDup, _T("SnapIns.RemoveDup.1"),
	_T("SnapIns.RemoveDup"), IDS_REMOVEDUP_DESC, THREADFLAGS_BOTH)

// ISnapIn
public:
	STDMETHOD_(BOOL, SupportsInterface)(THIS_ IUnknown* lpUnk);
	STDMETHOD_(HINSTANCE, GetResourceInstance) (THIS_);
	STDMETHOD_(int, GetMenuTextID)(THIS_);
	STDMETHOD_(int, GetMessageTextID)(THIS_);
	STDMETHOD_(int, GetBitmapID)(THIS_ UINT nSize);
	STDMETHOD_(BOOL, IsEnabled)(THIS_ IUnknown* lpUnk);
	STDMETHOD_(void, OnStateChange)(THIS_ IUnknown* lpUnk);
	STDMETHOD_(void, OnCommand)(THIS_ IUnknown* lpUnk);
};
