// Copyright (c) 1997, Microsoft Systems Journal
// Author: Steve Zimmerman
//
// CorrectDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "CorrectDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CCorrectDlg::CCorrectDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCorrectDlg::IDD, pParent)
{
	// Right now, the Auto-Correct file is stored in the same
	// directory as the calling application, meaning that each
	// app will have its own file.

	CFile theFile;

	TCHAR sFileName[_MAX_PATH];
	GetModuleFileName(AfxGetInstanceHandle(), sFileName, _MAX_PATH);
	TCHAR* pFileExt = strchr(sFileName, _T('.'));
	_tcscpy(pFileExt, _T(".acf")); // auto-correct file

	if (theFile.Open(sFileName, CFile::modeRead))
	{
		CArchive archive(&theFile, CArchive::load);
		Serialize(archive);
	}
	
	m_nWordTop = m_nReplaceTop = 0;

	//{{AFX_DATA_INIT(CCorrectDlg)
	//}}AFX_DATA_INIT
}

CCorrectDlg::~CCorrectDlg()
{
	CFile theFile;

	TCHAR sFileName[_MAX_PATH];
	GetModuleFileName(AfxGetInstanceHandle(), sFileName, _MAX_PATH);
	TCHAR* pFileExt = strchr(sFileName, _T('.'));
	_tcscpy(pFileExt, _T(".acf"));

	if (theFile.Open(sFileName, CFile::modeCreate|CFile::modeWrite))
	{
		CArchive archive(&theFile, CArchive::store);
		Serialize(archive);
	}
}

BOOL CCorrectDlg::FindMatch(LPCTSTR lpWord, LPCTSTR* lppReplace)
{
	for (int nLoop = 0; nLoop < m_strBad.GetSize(); nLoop++)
	{
		CString temp = m_strBad[nLoop];
		if (m_strBad[nLoop].Compare(lpWord) == 0)
		{
			*lppReplace = m_strGood[nLoop];
			return TRUE;
		}
	}

	return FALSE;
}

void CCorrectDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCorrectDlg)
	DDX_Control(pDX, IDOK, m_btnOK);
	DDX_Control(pDX, IDC_EDIT_WORD, m_editWord);
	DDX_Control(pDX, IDC_REMOVE, m_btnRemove);
	DDX_Control(pDX, IDC_LIST_WORD, m_listWord);
	DDX_Control(pDX, IDC_LIST_REPLACE, m_listReplace);
	DDX_Control(pDX, IDC_ADD, m_btnAdd);
	DDX_Text(pDX, IDC_EDIT_REPLACE, m_strReplace);
	DDX_Text(pDX, IDC_EDIT_WORD, m_strWord);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCorrectDlg, CDialog)
	//{{AFX_MSG_MAP(CCorrectDlg)
	ON_EN_CHANGE(IDC_EDIT_WORD, OnChangeEdit)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_LBN_SELCHANGE(IDC_LIST_REPLACE, OnSelchangeListReplace)
	ON_LBN_SELCHANGE(IDC_LIST_WORD, OnSelchangeListWord)
	ON_BN_CLICKED(IDC_REMOVE, OnRemove)
	ON_WM_DESTROY()
	ON_WM_SYSCOMMAND()
	ON_WM_QUERYDRAGICON()
	ON_EN_CHANGE(IDC_EDIT_REPLACE, OnChangeEdit)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCorrectDlg message handlers

BOOL CCorrectDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	for (int nLoop = 0; nLoop < m_strGood.GetSize(); nLoop++)
	{
		int index = m_listWord.AddString(m_strBad[nLoop]);
		m_listReplace.InsertString(index, m_strGood[nLoop]);
	}
	
	OnChangeEdit();
	m_btnRemove.EnableWindow(FALSE);
	SetTimer(1, 1, NULL);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCorrectDlg::OnChangeEdit()
{
	UpdateData(TRUE);
	if (m_strWord.GetLength() && m_strReplace.GetLength())
	{
		m_btnAdd.EnableWindow(TRUE);
		m_btnOK.SetButtonStyle(BS_PUSHBUTTON, TRUE);
		SendMessage(DM_SETDEFID, IDC_ADD, 0);
		m_btnAdd.SetButtonStyle(BS_DEFPUSHBUTTON, TRUE);
	}
	else
	{
		m_btnAdd.EnableWindow(FALSE);
		m_btnAdd.SetButtonStyle(BS_PUSHBUTTON, TRUE);
		SendMessage(DM_SETDEFID, IDOK, 0);
		m_btnOK.SetButtonStyle(BS_DEFPUSHBUTTON, TRUE);
	}
}
 
void CCorrectDlg::OnAdd() 
{
	// Check to see if the mispelled word already exists

	for (int nIndex = 0; nIndex < m_listWord.GetCount(); nIndex++)
	{
		CString sText;
		m_listWord.GetText(nIndex, sText);
		if (sText == m_strWord)
		{
			m_listWord.DeleteString(nIndex);
			m_listReplace.DeleteString(nIndex);
		}
	}
	
	nIndex = m_listWord.AddString(m_strWord);
	m_listReplace.InsertString(nIndex, m_strReplace);
	m_strWord.Empty();
	m_strReplace.Empty();
	UpdateData(FALSE);
	OnChangeEdit();
	m_editWord.SetFocus();
}

void CCorrectDlg::OnSelchangeListReplace() 
{
	m_btnRemove.EnableWindow(TRUE);
	int nIndex = m_listReplace.GetCurSel();
	m_listReplace.GetText(nIndex, m_strReplace);
	m_listWord.SetCurSel(nIndex);
	m_listWord.GetText(nIndex, m_strWord);

	UpdateData(FALSE);
	OnChangeEdit();
	m_editWord.SetFocus();
	m_editWord.SetSel(0, -1);
}

void CCorrectDlg::OnSelchangeListWord() 
{
	m_btnRemove.EnableWindow(TRUE);
	int nIndex = m_listWord.GetCurSel();
	m_listWord.GetText(nIndex, m_strWord);
	m_listReplace.SetCurSel(nIndex);
	m_listReplace.GetText(nIndex, m_strReplace);

	UpdateData(FALSE);
	OnChangeEdit();
	m_editWord.SetFocus();
	m_editWord.SetSel(0, -1);
}

void CCorrectDlg::OnRemove() 
{
	ASSERT( m_listWord.GetCurSel() == m_listReplace.GetCurSel() );

	int index = m_listWord.GetCurSel();
	m_listWord.DeleteString(index);
	m_listReplace.DeleteString(index);
	if (m_listWord.GetCount() == 0)
		m_btnRemove.EnableWindow(FALSE);
}

void CCorrectDlg::Serialize(CArchive& ar) 
{
	if (ar.IsStoring())
	{
		ar << m_strBad.GetSize();
		for (int nLoop = 0; nLoop < m_strGood.GetSize(); nLoop++)
		{
			ar << m_strBad[nLoop];
			ar << m_strGood[nLoop];
		}
	}
	else
	{
		int nCount;
		CString text;
		ar >> nCount;
		for (int nLoop = 0; nLoop < nCount; nLoop++)
		{
			ar >> text;
			m_strBad.Add(text);
			ar >> text;
			m_strGood.Add(text);
		}
	}
}

void CCorrectDlg::OnDestroy() 
{
	m_strGood.RemoveAll();
	m_strBad.RemoveAll();
	for (int nLoop = 0; nLoop < m_listWord.GetCount(); nLoop++)
	{
		CString text;
		m_listWord.GetText(nLoop, text);
		m_strBad.Add(text);
		m_listReplace.GetText(nLoop, text);
		m_strGood.Add(text);
	}

	CDialog::OnDestroy();
}

void CCorrectDlg::OnTimer(UINT nIDEvent) 
{
	if (m_nWordTop != m_listWord.GetTopIndex())
	{
		m_nWordTop = m_listWord.GetTopIndex();
		m_listReplace.SetTopIndex(m_nWordTop);
		m_nReplaceTop = m_nWordTop;
	}
	else if (m_nReplaceTop != m_listReplace.GetTopIndex())
	{
		m_nReplaceTop = m_listReplace.GetTopIndex();
		m_listWord.SetTopIndex(m_nReplaceTop);
		m_nWordTop = m_nReplaceTop;
	}

	CDialog::OnTimer(nIDEvent);
}
