// Copyright (c) 1997, Microsoft Systems Journal
// Author: Steve Zimmerman
//
// RichDoc.cpp: implementation of the CRichDocHelper class.
//

#include "stdafx.h"
#include "IRichDoc.h"
#include "RichDoc.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

HWND CRichDocHelper::GetRichEditControl(
	IUnknown* pUnk, IRichDocContext** ppRichDoc)
{
	_ASSERTE(pUnk);
	if (!pUnk || pUnk->QueryInterface(IID_IRichDocContext,
		(LPVOID*) ppRichDoc) != S_OK)
		return NULL;

	HWND hWnd = (*ppRichDoc)->GetRichEditCtrl();
	_ASSERTE(IsWindow(hWnd));
	return hWnd;
}

BOOL CRichDocHelper::IsValidContainer(IUnknown* pUnk)
{
	CComQIPtr<IRichDocContext, &IID_IRichDocContext> pRichDoc(pUnk);
	return pRichDoc != NULL;
}