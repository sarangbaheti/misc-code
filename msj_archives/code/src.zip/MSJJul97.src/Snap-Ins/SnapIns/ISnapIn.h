// Copyright (c) 1997, Microsoft Systems Journal
// Author: Steve Zimmerman
//

// ISnapIn Interface Definition:
// {6AE74760-83C6-11D0-A2A7-000000000000}

DEFINE_GUID(IID_ISnapIn,
	0x6ae74760, 0x83c6, 0x11d0, 0xa2, 0xa7, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0);

#define CATID_ISnapIn IID_ISnapIn

DECLARE_INTERFACE_(ISnapIn, IUnknown)
{
	STDMETHOD_(BOOL, SupportsInterface)(THIS_ IUnknown* lpUnk) PURE;
	STDMETHOD_(HINSTANCE, GetResourceInstance) (THIS_) PURE;
	STDMETHOD_(int, GetMenuTextID)(THIS_) PURE;
	STDMETHOD_(int, GetMessageTextID)(THIS_) PURE;
	STDMETHOD_(int, GetBitmapID)(THIS_ UINT nSize) PURE;
	STDMETHOD_(BOOL, IsEnabled)(THIS_ IUnknown* lpUnk) PURE;
	STDMETHOD_(void, OnStateChange)(THIS_ IUnknown* lpUnk) PURE;
	STDMETHOD_(void, OnCommand)(THIS_ IUnknown* lpUnk) PURE;
};
