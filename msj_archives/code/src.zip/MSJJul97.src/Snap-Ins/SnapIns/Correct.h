// Copyright (c) 1997, Microsoft Systems Journal
// Author: Steve Zimmerman
//
// Correct.h : Declaration of the CAutoCorrect


#include "resource.h"       // main symbols

DEFINE_GUID(CLSID_CAutoCorrect,
	0xD6152CDF, 0x8402, 0x11D0, 0xA2, 0xA8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00);

interface IRichDocContext;
class CCorrectDlg;

class CAutoCorrect : 
	public ISnapIn,
	public CRichDocHelper,
	public CComObjectRoot,
	public CComCoClass<CAutoCorrect,&CLSID_CAutoCorrect>
{
public:
	CAutoCorrect();
	~CAutoCorrect();

BEGIN_COM_MAP(CAutoCorrect)
	COM_INTERFACE_ENTRY(ISnapIn)
END_COM_MAP()
//DECLARE_NOT_AGGREGATABLE(CAutoCorrect) 
// Remove the comment from the line above if you don't want your object to 
// support aggregation.  The default is to support it

DECLARE_REGISTRY(CAutoCorrect, _T("SnapIns.AutoCorrect.1"),
	_T("SnapIns.AutoCorrect"), IDS_AUTOCORRECT_DESC, THREADFLAGS_BOTH)

protected:
	CCorrectDlg* m_dlgBox;

// ISnapIn
public:
	STDMETHOD_(BOOL, SupportsInterface)(THIS_ IUnknown* lpUnk);
	STDMETHOD_(HINSTANCE, GetResourceInstance) (THIS_);
	STDMETHOD_(int, GetMenuTextID)(THIS_);
	STDMETHOD_(int, GetMessageTextID)(THIS_);
	STDMETHOD_(int, GetBitmapID)(THIS_ UINT nSize);
	STDMETHOD_(BOOL, IsEnabled)(THIS_ IUnknown* lpUnk);
	STDMETHOD_(void, OnStateChange)(THIS_ IUnknown* lpUnk);
	STDMETHOD_(void, OnCommand)(THIS_ IUnknown* lpUnk);
};
