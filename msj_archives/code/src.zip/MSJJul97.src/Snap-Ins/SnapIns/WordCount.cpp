// Copyright (c) 1997, Microsoft Systems Journal
// Author: Steve Zimmerman
//
// WordCount.cpp : Implementation of CSnapInsApp and DLL registration.

#include "stdafx.h"
#include <richedit.h>
#include "ISnapIn.h"
#include "IRichDoc.h"
#include "RichDoc.h"
#include "WordCount.h"

STDMETHODIMP_(BOOL) CWordCount::SupportsInterface(IUnknown* lpUnk)
{
	return IsValidContainer(lpUnk);
}

STDMETHODIMP_(HINSTANCE) CWordCount::GetResourceInstance()
{
	return NULL;
}

STDMETHODIMP_(int) CWordCount::GetMenuTextID()
{
	return -1;
}

STDMETHODIMP_(int) CWordCount::GetMessageTextID()
{
	return -1;
}

STDMETHODIMP_(int) CWordCount::GetBitmapID(UINT nSize)
{
	return -1;
}

STDMETHODIMP_(BOOL) CWordCount::IsEnabled(IUnknown* lpUnk)
{
	return FALSE;
}

STDMETHODIMP_(void) CWordCount::OnStateChange(IUnknown* lpUnk)
{
	IRichDocContext* lpContext;
	HWND hWnd = GetRichEditControl(lpUnk, &lpContext);

	UINT nWords = 0;
	UINT nNext = 0, nLast = 1;
	while (nNext != nLast)
	{	
		nLast = nNext;
		nNext = SendMessage(hWnd, EM_FINDWORDBREAK,
			WB_RIGHT, nLast);
		if (nNext != nLast)
			nWords++;
	}

	TCHAR sBuffer[20];
	wsprintf(sBuffer, _T("Total words: %d"), nWords);
	lpContext->SetStatusText(sBuffer);
	lpContext->Release();
}

STDMETHODIMP_(void) CWordCount::OnCommand(IUnknown* lpUnk)
{
	// This is a hidden SnapIn so OnCommand should never
	// get called;

	_ASSERTE(FALSE);
}
