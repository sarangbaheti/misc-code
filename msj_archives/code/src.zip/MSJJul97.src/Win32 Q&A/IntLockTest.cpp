/*************************************************************
Module name: IntLockTest.h
Notices: Written 1997 by Jeffrey Richter
Description: Tests CWhenZero class.
*************************************************************/


#define STRICT
#include <Windows.h>
#include <assert.h>
#include "Interlocked.h"


//////////////////////////////////////////////////////////////


// Set to TRUE when worker threads should terminate cleanly.
BOOL g_fQuit = FALSE;


//////////////////////////////////////////////////////////////


DWORD WINAPI WorkerThread (LPVOID p) {
   CWhenZero<BYTE>& bVal = * (CWhenZero<BYTE> *) p;

   // Should worker thread terminate?
   while (!g_fQuit) {

      // Wait for something to do
      WaitForSingleObject(bVal.GetNotZeroHandle(), INFINITE);

      // If we should quit, quit
      if (g_fQuit) continue;

      // Do something
      MessageBox(NULL, __TEXT("We have something to do"), 
         __TEXT("Worker thread"), MB_OK);

      bVal--;     // We're done

      // Wait for all worker threads to stop
      WaitForSingleObject(bVal, INFINITE);
   }

   MessageBox(NULL, __TEXT("Worker is terminating"), 
      __TEXT("Worker thread"), MB_OK);
   return(0);
}


//////////////////////////////////////////////////////////////


int WINAPI WinMain (HINSTANCE hinst, 
   HINSTANCE hinstPrev, LPSTR lp, int n) {

   // Initialize to indicate that NO worker threads have anything to do
   CWhenZero<BYTE> bVal = 0;

   // Create the worker threads
   const int nMaxThreads = 2;
   HANDLE hThreads[nMaxThreads];
   for (int nThread = 0; nThread < nMaxThreads; nThread++) {
      DWORD dwThreadId;
      hThreads[nThread] = CreateThread(NULL, 0, 
         WorkerThread, (PVOID) &bVal, 0, &dwThreadId);
   }

   do {

      // Find out if there is more work to be done 
      // or if the process should terminate
      n = MessageBox(NULL, 
         __TEXT("Yes: Give worker threads something to do\nNo: Quit"), 
         __TEXT("Primary thread"), MB_YESNO);

      // Set the flag so that the worker threads will see
      // that there is no more work to do.
      if (n == IDNO) g_fQuit = TRUE;

      bVal = nMaxThreads;  // Wake the worker threads

      if (n == IDYES) {
         // There is work to do, wait for the worker 
         // threads to finish
         WaitForSingleObject(bVal, INFINITE);
      }

   } while (n == IDYES);

   // There is no more work to do, the process wants to die.
   // Wait for the worker threads to terminate
   WaitForMultipleObjects(nMaxThreads, hThreads, TRUE, INFINITE);

   // Close the worker thread handles.
   for (nThread = 0; nThread < nMaxThreads; nThread++)
      CloseHandle(hThreads[nThread]);

   // Tell the user that the process is dying
   MessageBox(NULL, 
      __TEXT("Primary thread is terminating"), 
      __TEXT("Primary thread"), MB_OK);

   return(0);
}


//////////////////////// End Of File /////////////////////////
