//==================================
// PerfShow - Matt Pietrek 1995
// FILE: PERFSHOW.C
//==================================
#include <windows.h>
#pragma hdrstop
#include "perfshow.h"

#ifndef HKEY_DYN_DATA
#define HKEY_DYN_DATA               (( HKEY ) 0x80000006 )
#endif

// Helper functions
void Handle_WM_COMMAND(HWND hWndDlg, WPARAM wParam, LPARAM lParam);
void Handle_WM_INITDIALOG(HWND hWndDlg);
BOOL CALLBACK PerfShowDlgProc(HWND, UINT, WPARAM, LPARAM);
void UpdatePerformanceKeysListbox( HWND hWndDlg );
void GetPerformanceKeyCharacteristic(
        PSTR pszKey,
        PSTR pszCharacteristic,
        PSTR pszOutBuffer,
        DWORD cbOutBuffer );

// ====================== Global Variables =============================
HWND HWndLB = 0;

// ======================= Start of code ===============================

int PASCAL WinMain( HANDLE hInstance, HANDLE hPrevInstance,
                    LPSTR lpszCmdLine, int nCmdShow )
{
    DialogBox(hInstance, "PerfShowDlg", 0, (DLGPROC)PerfShowDlgProc);
    return 0;
}

void UpdatePerformanceKeysListbox( HWND hWndDlg )
{
    LONG errCode;
    HKEY hKey;
    unsigned i;

    SendMessage( HWndLB, LB_RESETCONTENT, 0, 0 );
    
    errCode = RegOpenKeyEx( HKEY_DYN_DATA, "PerfStats\\StatData",
                            0, KEY_ALL_ACCESS, &hKey );
    if ( errCode != ERROR_SUCCESS )
    {
        SendMessage( HWndLB, LB_ADDSTRING, 0,
                        (LPARAM)"Couldn't open PerfStats\\StatData" );
        return;
    }

    // Enumerate through all the values of the PerfStats\StatData key
    for ( i=0; i < 0xFFFFFFFF; i++ )
    {
        char szValueName[260], szLBContents[512];
        DWORD cchValueName;
        DWORD dwValue, dwValueType, dwValueValueSize;
        
        cchValueName = sizeof(szValueName);
        dwValueValueSize = sizeof(dwValue);

        errCode = RegEnumValue( hKey, i, szValueName, &cchValueName, 0,
                                &dwValueType, (PBYTE)&dwValue,
                                &dwValueValueSize);
        if ( errCode != ERROR_SUCCESS )
            break;

        // Format the value's name and it's DWORD value, then add it
        // to the top listbox.
        wsprintf( szLBContents, "%s %u (0x%X)", szValueName, dwValue, dwValue );
        SendMessage( HWndLB, LB_ADDSTRING, 0, (LPARAM)szLBContents );
    }
        
    RegCloseKey( hKey );

    // Set the selection to the first item in the listbox, and force
    // the bottom edit control to be filled.
    SendMessage( HWndLB, LB_SETCURSEL, 0, 0 );
    PostMessage( hWndDlg, WM_COMMAND,
                 MAKEWPARAM(IDC_LISTBOX_KEYS, LBN_SELCHANGE), (LPARAM)HWndLB );
    SetFocus( HWndLB );
}

//
// Used to get the "Name" or "Description" value for a performance value
//
void GetPerformanceKeyCharacteristic( PSTR pszKey, PSTR pszCharacteristic,
                                        PSTR pszOutBuffer, DWORD cbOutBuffer )
{
    char szEnumKey[512];
    DWORD dwType, errCode;
    HKEY hKey;

    pszOutBuffer[0] = 0;
    
    lstrcpy(szEnumKey, "System\\CurrentControlSet\\control\\PerfStats\\Enum\\");
    lstrcat( szEnumKey, pszKey );
    
    errCode = RegOpenKeyEx( HKEY_LOCAL_MACHINE, szEnumKey,
                            0, KEY_ALL_ACCESS, &hKey );
    if ( errCode != ERROR_SUCCESS )
        return;

    RegQueryValueEx( hKey, pszCharacteristic, 0, &dwType,
                    (PBYTE)pszOutBuffer, &cbOutBuffer );

    RegCloseKey( hKey );
}

// ================= Start of user interface code ========================

//
// Dialog proc for the main dialog
//
BOOL CALLBACK PerfShowDlgProc(HWND hWndDlg, UINT msg,
                              WPARAM wParam, LPARAM lParam )
{
    switch ( msg )
    {
        case WM_COMMAND:
            Handle_WM_COMMAND(hWndDlg, wParam, lParam); return TRUE;
        case WM_INITDIALOG:
            Handle_WM_INITDIALOG(hWndDlg); return TRUE;
        case WM_CLOSE:
            EndDialog(hWndDlg, 0); return FALSE;
    }
    return FALSE;
}

//
// Handle the dialog's WM_COMMAND messages
//
void Handle_WM_COMMAND(HWND hWndDlg, WPARAM wParam, LPARAM lParam)
{
    switch ( LOWORD(wParam) )
    {
        case IDC_REFRESH: UpdatePerformanceKeysListbox( hWndDlg ); break;
        case IDC_LISTBOX_KEYS:
            if ( HIWORD(wParam) == LBN_SELCHANGE )
            {
                DWORD lbSelectedIndex;
                PSTR p;
                char szKey[256], szDescription[512], szName[512];
                char szEditText[1024];

                // Get the currently selected text in the top listbox
                lbSelectedIndex = SendMessage(HWndLB, LB_GETCURSEL, 0, 0);
                SendMessage(HWndLB, LB_GETTEXT, lbSelectedIndex,(LPARAM)szKey);

                // Strip off everything after the first space character
                p = szKey;
                while ( *p && (*p != ' ') )
                    p++;
                *p = 0;

                // Get the Name and Description for the newly selected
                // performance value and put it in the bottom edit control

                GetPerformanceKeyCharacteristic(szKey, "Name",
                                                szName, sizeof(szName) );

                GetPerformanceKeyCharacteristic(szKey,
                                                "Description",
                                                szDescription, 
                                                sizeof(szDescription) );
                wsprintf( szEditText,
                          "Name: %s\r\n\r\nDescription: %s",
                          szName, szDescription );

                SetDlgItemText( hWndDlg, IDC_EDIT_DESCRIPTION, szEditText );
            }
    }
    return;
}

void Handle_WM_INITDIALOG(HWND hWndDlg)
{
    HWndLB = GetDlgItem( hWndDlg, IDC_LISTBOX_KEYS );
    
    UpdatePerformanceKeysListbox( hWndDlg );    
}
