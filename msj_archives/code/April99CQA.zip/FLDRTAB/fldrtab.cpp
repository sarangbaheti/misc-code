////////////////////////////////////////////////////////////////
// FLDRTAB Copyright 1996 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// FLDRTAB illustrates xxxx
// Compiles with

#include "stdafx.h"
#include "ftab.h"
#include "StatLink.h"
#include "tracewin.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

class CApp : public CWinApp {
public:
	virtual BOOL InitInstance();
} theApp;

// dialog for main app window
class CMyDialog : public CDialog {
public:
	CMyDialog(CWnd* pParent = NULL);
protected:
	CFolderTabCtrl m_wndFolderTab;		 // the folder tab control
	CStatic			m_wndStaticInfo;		 // report selection here

	// these two for web links
	CStaticLink		m_wndLink1;
	CStaticLink		m_wndLink2;

	virtual BOOL	OnInitDialog();
	DECLARE_MESSAGE_MAP()
	afx_msg void OnChangedTab(NMFOLDERTAB* nmtab, LRESULT* pRes);
};

BEGIN_MESSAGE_MAP(CMyDialog, CDialog)
	ON_NOTIFY(FTN_TABCHANGED, IDC_FOLDERTAB, OnChangedTab)
END_MESSAGE_MAP()

CMyDialog::CMyDialog(CWnd* pParent /*=NULL*/) 
	: CDialog(IDD_DIALOG1, pParent)
{
}

BOOL CMyDialog::OnInitDialog()
{
	if (!CDialog::OnInitDialog())
		return FALSE;

	// hook info control
	m_wndStaticInfo.SubclassDlgItem(IDC_STATICINFO, this);

	// Create folder tab and load it. Control is created in same position
	// as static control with IDC_FOLDERTAB, which will be deleted.
	// This is just a trick so I can design the dialog with the resource editor.
	//
	m_wndFolderTab.CreateFromStatic(IDC_FOLDERTAB, this);
	m_wndFolderTab.Load(IDR_FOLDERTABS); // Load strings

	// initialize static web links
	m_wndLink1.SubclassDlgItem(IDC_STATICMSJ, this,
		_T("http://www.microsoft.com/msj"));
	m_wndLink2.SubclassDlgItem(IDC_STATICPD, this,
		_T("http://pobox.com/~askpd"));

	return TRUE;
}

void CMyDialog::OnChangedTab(NMFOLDERTAB* nmtab, LRESULT* pRes)
{
	CString s;
	s.Format(_T("Selected item %d: %s"), nmtab->iItem,
		nmtab->pItem->GetText());
	m_wndStaticInfo.SetWindowText(s);	
}

BOOL CApp::InitInstance()
{
	PxlTraceInit();		// TraceWin tracing
	CMyDialog dlg;			// create dialog object
	m_pMainWnd = &dlg;	// make MFC happy
	dlg.DoModal();			// run it
	return FALSE;			// bye
}
