#include "ftab.h"

class CMyDialog : public CDialog {
public:
	CMyDialog(CWnd* pParent = NULL);
	enum { IDD = IDD_DIALOG1 };
protected:
	CFolderTabCtrl m_wndFolderTab;
	CStatic			m_wndStaticInfo;
	virtual BOOL OnInitDialog();
	virtual void DoDataExchange(CDataExchange* pDX);
	DECLARE_MESSAGE_MAP()
	afx_msg void OnChangedTab(NMFOLDERTAB* nmtab, LRESULT* pRes);
};
