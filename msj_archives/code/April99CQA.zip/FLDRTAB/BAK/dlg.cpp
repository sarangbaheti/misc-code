#include "stdafx.h"
#include "fldrtab.h"
#include "dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BEGIN_MESSAGE_MAP(CMyDialog, CDialog)
	ON_NOTIFY(FTN_TABCHANGED, IDC_FOLDERTAB, OnChangedTab)
END_MESSAGE_MAP()

CMyDialog::CMyDialog(CWnd* pParent /*=NULL*/) 
	: CDialog(CMyDialog::IDD, pParent)
{
}

void CMyDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BOOL CMyDialog::OnInitDialog()
{
	if (CDialog::OnInitDialog()) {
		m_wndStaticInfo.SubclassDlgItem(IDC_STATICINFO, this);

		CStatic wndStatic;
		VERIFY(wndStatic.SubclassDlgItem(IDC_FOLDERTAB, this));
		CRect rc;
		wndStatic.GetWindowRect(&rc);
		ScreenToClient(&rc);
		wndStatic.DestroyWindow();

		rc.bottom = rc.top + GetSystemMetrics(SM_CYHSCROLL);
		VERIFY(m_wndFolderTab.Create(WS_CHILD|WS_VISIBLE, rc, this,
			IDC_FOLDERTAB));

		m_wndFolderTab.Load(IDR_FOLDERTABS);
		return TRUE;
	}
	return FALSE;
}

void CMyDialog::OnChangedTab(NMFOLDERTAB* nmtab, LRESULT* pRes)
{
	CString s;
	s.Format(_T("Selected item %d: %s"), nmtab->iItem, nmtab->pItem->m_sText);
	m_wndStaticInfo.SetWindowText(s);	
}
