////////////////////////////////////////////////////////////////
// Copyright 1998 Paul DiLascia
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// 
#ifndef FTAB_H
#define FTAB_H

// style flags
#define FTS_FULLBORDER	0x1				 // draw full border

struct FOLDERTAB {							 // public info for one folder tab
	CString	m_sText;							 // tab text
	FOLDERTAB(LPCTSTR lpszText) : m_sText(lpszText) { }
};

enum { FTN_TABCHANGED = 1 };				 // notification: tab changed

struct NMFOLDERTAB : public NMHDR {		 // notification struct
	int iItem;									 // item index
	const FOLDERTAB* pItem;					 // ptr to data, if any
};


//////////////////
// Folder tab control, similar to tab control
//
class CFolderTabCtrl : public CWnd {
protected:
	CPtrList		m_lsTabs;					 // array of FOLDERTABs
	DWORD			m_dwFtabStyle;				 // folder tab style flags
	int			m_iCurItem;					 // current selected tab
	CFont			m_fontNormal;				 // current font, normal ntab
	CFont			m_fontSelected;			 // current font, selected tab
	int			m_nDesiredWidth;			 // exact fit width

	// helpers
	void InvalidateTab(int iTab, BOOL bErase=TRUE);
	void DrawTabs(CDC& dc, const CRect& rc);
	struct MYFOLDERTAB* GetTab(int iPos);

public:
	CFolderTabCtrl();
	virtual ~CFolderTabCtrl();

	virtual BOOL Create(DWORD dwWndStyle, const RECT& rc,
		CWnd* pParent, UINT nID, DWORD dwFtabStyle=0);
	virtual BOOL Load(UINT nIDRes);

	FOLDERTAB* GetItem(int iPos)			{ return (FOLDERTAB*)GetTab(iPos); }
	int	GetSelectedItem()					{ return m_iCurItem; }
	int	GetTabCount()						{ return m_lsTabs.GetCount(); }
	int	GetDesiredWidth()					{ return m_nDesiredWidth; }
	BOOL  AddItem(LPCTSTR lpszText);
	BOOL  RemoveItem(int iPos);
	void	RecomputeLayout();
	int	HitTest(CPoint pt);
	int	SelectItem(int iTab);
	void	SetFonts(CFont& fontNormal, CFont& fontSelected);

protected:
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	DECLARE_DYNAMIC(CFolderTabCtrl);
	DECLARE_MESSAGE_MAP()
};

#endif // FTAB_H
