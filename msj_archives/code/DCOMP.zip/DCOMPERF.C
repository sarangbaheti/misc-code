/* THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
 * ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
 * PARTICULAR PURPOSE.
 *
 * Copyright (C) 1994  Microsoft Corporation.  All Rights Reserved.
 *
 *  MODULE:   dcomperf.c
 *
 *  PURPOSE:
 *	  contains code interfacing with the PerfMon sample for the Distributed
 *    Compression server
 *
 *  FUNCTIONS:
 *
 *  COMMENTS:					
 */

#ifndef	UNICODE
#define UNICODE			// needed because of PerfMon code
#define _UNICODE
#endif

#include	"dcomp.h"
#include	"dcomps.h"
#include	"perfmon.h"

#include	<math.h>
#include	"counters.h"
#include	"graph.h"
#include	"line.h"
#include	"perfdata.h"
#include	"perfmops.h"
#include	"pmemory.h"
#include	"status.h"
#include	"system.h"
#include	"utils.h"

#define		DEFAULT_SCALE		0						// copied from addline.c

PPERFINSTANCEDEF	ParentInstance(PPERFINSTANCEDEF pInstance);	// defined in addline.c
void				VisualIncrement (PLINEVISUAL pVisual);		// defined in addline.c
COLORREF			LineColor (int iColorIndex);				// defined in addline.c
int					LineWidth (int iWidthIndex);				// defined in addline.c
int					LineStyle (int iStyleIndex);				// defined in addline.c


typedef	FLOAT	(*PVALNEXTFUNC)(struct _LINESTRUCT *lnParam);


BOOL DCompGraphAddOneChartLine
(
	PPERFSYSTEM			pSystem,
	PPERFOBJECT			pObject,
	LPTSTR				lpszObject,
	PPERFCOUNTERDEF		pCounter,
	LPTSTR				lpszCounter,
	PPERFINSTANCEDEF	pInstance,                     
	LPTSTR				lpszInstance,
	PVALNEXTFUNC		valNext
);

PPERFSYSTEM
DCompGraphGetComputer (
    PPERFDATA *ppPerfData,
    PPERFSYSTEM *ppSystemFirst
);

PPERFOBJECT		DCompGraphGetObject
(
	PPERFDATA	pPerfData,
	PPERFSYSTEM	pSysInfo,
	LPTSTR		lpszObject
);

PPERFCOUNTERDEF		DCompGraphGetCounter
(
	PPERFOBJECT	pObject,
	PPERFSYSTEM	pSystem,
	LPTSTR		lpszCounterName
);

PPERFINSTANCEDEF	DCompGraphGetInstance
(
	PPERFOBJECT pObject,
	LPTSTR lpszInstance
);

FLOAT	ServerValNext(struct _LINESTRUCT *lnParam);
FLOAT	IdleValNext(struct _LINESTRUCT *lnParam);
FLOAT	SumValNext(struct _LINESTRUCT *lnParam);
FLOAT	ThresholdValNext(struct _LINESTRUCT *lnParam);


static PPERFDATA  pPerfData ;

TCHAR	gszIdleProcName[]   = TEXT("Idle");
TCHAR	gszThresholdName[]  = TEXT("Threshold");

#define	PROC_SUM_FMT		TEXT("Ave(%s + Idle)")
TCHAR	gszProcSumName[_MAX_FNAME + ArrayLength(PROC_SUM_FMT)];

FLOAT	geServerAveVal = 0.0F;
FLOAT	geIdleAveVal = 0.0F;
FLOAT	geCurrentThreshold;

#define	ACCEPTING		TEXT("Accepting new bunches")
#define	NOT_ACCEPTING	TEXT("Not accepting new bunches")

static struct tagDCOMPGRAPHLINE
{
	LPTSTR 			lpszObject;
	LPTSTR			lpszCounter;
	LPTSTR			lpszInstance;
	PVALNEXTFUNC	valNext;
} gaDCompGraphTable[] =
{
	{TEXT("Process"),	TEXT("% Processor Time"),	NULL,				ServerValNext},
	{TEXT("Process"),	TEXT("% Processor Time"),	gszIdleProcName,	IdleValNext},
	{TEXT("Process"),	TEXT("% Processor Time"),	gszThresholdName,	ThresholdValNext},
	{TEXT("Process"),	TEXT("% Processor Time"),	gszProcSumName,		SumValNext}
};


// hi-jack these buffers to display our 'Busy' status
extern TCHAR          szStatusFormat  [] ;
extern TCHAR          szCurrentActivity [] ;
extern int            szStatusLineLen ;
extern TCHAR          szStatusLine [] ;


//
//  FUNCTION: DCompGraphInitialize
//
//  PURPOSE:
//    set up the monitoring chart with the lines we want for distributed
//    compression sample
//
//  PARAMETERS:
//
//  RETURN VALUE:
//    non-zero on success
//
//  COMMENTS:
//    This short-circuits the Add To Chart dialog of the PerfMon Sample
//
//    Note: the string returned by GetAppBaseName is used to match a process
//    instance in DCompGraphGetInstance.  This match fails if the executable
//    file has been renamed after being built - even changing the case of
//    characters affects this.
//

BOOL		DCompGraphInitialize(void)
{
	int					i ;

 	PPERFSYSTEM			pSystem;
	PPERFOBJECT			pObject;
	PPERFCOUNTERDEF		pCounter;
	PPERFINSTANCEDEF	pInstance;

	pPerfData = MemoryAllocate(STARTING_SYSINFO_SIZE);

	// Computer

	pSystem = DCompGraphGetComputer(&pPerfData, &(pGraphs->pSystemFirst));
	if (!pSystem)
		return (FALSE) ;


	// Busy threshold value, scaled according to number of active processors
	// in the computer

	geCurrentThreshold = (FLOAT) (gdwBusyThreshold * gdwNumActiveProcessors);


	// Prepare titles of server and "sum" lines

#ifdef	UNICODE
	GetAppBaseName(NULL, &gaDCompGraphTable[0].lpszInstance);
#else
	GetAppBaseName(&gaDCompGraphTable[0].lpszInstance, NULL);
#endif
	_stprintf(gszProcSumName, PROC_SUM_FMT, gaDCompGraphTable[0].lpszInstance);


	// Graph lines

	for (i = 0; i < ArrayLength(gaDCompGraphTable); i++)
	{
		// object

		pObject = DCompGraphGetObject(pPerfData, pSystem, gaDCompGraphTable[i].lpszObject);
		if (!pObject)
			return (FALSE) ;

		// counter

		pCounter = DCompGraphGetCounter(pObject, pSystem, gaDCompGraphTable[i].lpszCounter);
		if (!pCounter)
			return (FALSE) ;

		// instance

		pInstance = DCompGraphGetInstance(pObject, gaDCompGraphTable[i].lpszInstance);
//		if (!pInstance)
//			return (FALSE) ;


		if (!DCompGraphAddOneChartLine (pSystem, pObject, gaDCompGraphTable[i].lpszObject, pCounter,
									gaDCompGraphTable[i].lpszCounter, pInstance, gaDCompGraphTable[i].lpszInstance, gaDCompGraphTable[i].valNext))
		{
			return(FALSE);
		}
	}


	// Size the graph: vertical percentage axis is scaled according to number
	// of active processors in the computer

	pGraphs->gOptions.iVertMax = gdwNumActiveProcessors * 100;
	SizeGraphComponents (hWndGraph) ;

	return(TRUE);
}


//
//  FUNCTION: DCompGraphAddOneChartLine
//
//  PURPOSE:
//    add one line to the chart
//
//  PARAMETERS:
//
//  RETURN VALUE:
//    non-zero on success
//
//  COMMENTS:
//

BOOL DCompGraphAddOneChartLine
(
	PPERFSYSTEM			pSystem,
	PPERFOBJECT			pObject,
	LPTSTR				lpszObject,
	PPERFCOUNTERDEF		pCounter,
	LPTSTR				lpszCounter,
	PPERFINSTANCEDEF	pInstance,                     
	LPTSTR				lpszInstance,
	PVALNEXTFUNC		valNext
)
{
	PLINE				pLine ;
	int					iCounterIndex ;
	int					j ;

	PPERFINSTANCEDEF	pInstanceParent = NULL;
	PERF_COUNTER_BLOCK	*pCounterBlock ;
	TCHAR				szInstanceParent [256] ;
	TCHAR				szObjectParent [PerfObjectLen+1] ;


	//=============================//
	// Allocate the line           //
	//=============================//

	pLine = LineAllocate () ;
	if (!pLine)
	{
		return (FALSE) ;
	}


	//=============================//
	// Set line's data values      //
	//=============================//

	pLine->iLineType = LineTypeChart ;
	pLine->lnSystemName = StringAllocate (LocalComputerName) ;

	pLine->lnObject = *pObject ;
	pLine->lnObjectName = StringAllocate (lpszObject) ;

	pLine->lnCounterDef = *pCounter ;
	pLine->lnCounterName = StringAllocate (lpszCounter) ;


	if (pObject->NumInstances > 0 && pInstance)
	{
		pLine->lnInstanceDef = *pInstance ;          
		pLine->lnInstanceName = StringAllocate (lpszInstance) ;

		pLine->lnUniqueID = pInstance->UniqueID ;

		if (pInstance->ParentObjectTitleIndex)
		{
			szObjectParent[0] = (TCHAR)'\0';
			QueryPerformanceName (pSystem,
								  pInstance->ParentObjectTitleIndex,
								  0,  PerfObjectLen, szObjectParent, FALSE) ;
			pLine->lnParentObjName = StringAllocate (szObjectParent) ;
		}

	//	pInstanceParent = ParentInstance (pInstance) ;	// ignore parent instanecs
	if (pInstanceParent)
		{
			GetInstanceName (pInstanceParent, szInstanceParent) ;
			if (pInstance->ParentObjectTitleIndex)
			{
				pLine->lnPINName = StringAllocate (szInstanceParent) ;
			}
		}
	}  // if
	else if (!pInstance)
	{
		// This is because from the DComp sample we want some special lines drawn
		pLine->lnInstanceName = StringAllocate (lpszInstance) ;
	}

	pLine->lnCounterType = pCounter->CounterType;
	pLine->lnCounterLength = pCounter->CounterSize;

	pLine->lnOldTime = pPerfData->PerfTime ;
	pLine->lnNewTime = pPerfData->PerfTime ;

	for (j = 0 ; j < 2 ; j++)
	{
		pLine->lnaCounterValue[j].LowPart = 0 ;
		pLine->lnaCounterValue[j].HighPart = 0 ;
	}


	//=============================//
	// Chart-related Values        //
	//=============================//

	pLine->iScaleIndex = DEFAULT_SCALE;

	// use the default scale
	pLine->eScale = (FLOAT) pow ((double)10.0,
							(double)pCounter->DefaultScale) ;

	if (pObject->NumInstances > 0 && pInstance)
	{
		pCounterBlock = (PERF_COUNTER_BLOCK *) ( (PBYTE) pInstance +
												pInstance->ByteLength);
	}
	else
	{
		pCounterBlock = (PERF_COUNTER_BLOCK *) ( (PBYTE) pObject +
											pObject->DefinitionLength);
	}

	if (pLine->lnCounterLength <= 4)
		pLine->lnaOldCounterValue[0].LowPart =
							* ( (DWORD FAR *) ( (PBYTE)pCounterBlock +
							pCounter[0].CounterOffset));
	else
	{
		pLine->lnaOldCounterValue[0] =
							* ( (LARGE_INTEGER *) ( (PBYTE)pCounterBlock +
							pCounter[0].CounterOffset));
	}

	// Get second counter, only if we are not at
	// the end of the counters; some computations
	// require a second counter

	iCounterIndex = CounterIndex (pCounter, pObject) ;
	if ((UINT) iCounterIndex < pObject->NumCounters - 1 &&
													iCounterIndex != -1)
	{
		if (pLine->lnCounterLength <= 4)
					pLine->lnaOldCounterValue[1].LowPart =
							* ( (DWORD FAR *) ( (PBYTE)pCounterBlock +
							pCounter[1].CounterOffset));
		else
			pLine->lnaOldCounterValue[1] =
							* ( (LARGE_INTEGER *) ( (PBYTE)pCounterBlock +
							pCounter[1].CounterOffset));
	}

	pLine->valNext = valNext;

	pLine->lnaOldCounterValue[0] = pLine->lnaCounterValue[0];
	pLine->lnaOldCounterValue[1] = pLine->lnaCounterValue[1];

	//=============================//
	// Visual Values               //
	//=============================//

	pLine->Visual.iColorIndex = pGraphs->Visual.iColorIndex;
	pLine->Visual.crColor = LineColor (pLine->Visual.iColorIndex) ;

	pLine->Visual.iWidthIndex = pGraphs->Visual.iWidthIndex;
	pLine->Visual.iWidth = LineWidth (pLine->Visual.iWidthIndex) ;

	pLine->Visual.iStyleIndex = pGraphs->Visual.iStyleIndex;
	pLine->Visual.iStyle = LineStyle (pLine->Visual.iStyleIndex) ;

	pGraphs->Visual = pLine->Visual ;
	VisualIncrement (&(pGraphs->Visual)) ;

	pLine->hPen = LineCreatePen (NULL, &(pLine->Visual), FALSE) ;

	//=============================//
	// Insert the line!            //
	//=============================//

	if (InsertLine (pLine) == FALSE)
	{
		// no insert occurred due to either line already existed
		// or error detected.
		LineFree (pLine) ;
	}
	else
	{
		if (pSystem->lpszValue)
		{
			if (strsame(pSystem->lpszValue, TEXT("Global ")))
			{
				// take out the "Global " string
				*(pSystem->lpszValue) = 0 ;
			}
			AppendObjectToValueList (
							pLine->lnObject.ObjectNameTitleIndex,
							pSystem->lpszValue) ;
		}
	}

	return(TRUE);
}


//
//  FUNCTION: DCompGraphGetComputer
//
//  PURPOSE:
//    get the monitoring data for the local computer
//
//  PARAMETERS:
//
//  RETURN VALUE:
//    non-zero on success
//
//  COMMENTS:
//

PPERFSYSTEM
DCompGraphGetComputer
(
    PPERFDATA *ppPerfData,
    PPERFSYSTEM *ppSystemFirst
)
/*
   Effect:        Load the objects, etc. for the local computer
                  and set pSystem and ppPerfdata to the values for this
                  system.
*/
{
    PPERFSYSTEM    pSystem;
    TCHAR          tempBuffer [LongTextLen] ;
    DWORD          dwBufferSize ;
    LPTSTR         pBuffer = NULL ;


	pSystem = SystemGet (*ppSystemFirst, LocalComputerName) ;
	if (!pSystem) {
	    pSystem = SystemAdd (ppSystemFirst, LocalComputerName) ;
	}

    if (pSystem) {
		if (pSystem->lpszValue) {
		   // save the previous lpszValue string before 
		   // SetSystemValueNameToGlobal screw it up
		   dwBufferSize = MemorySize (pSystem->lpszValue) ;
		   if (dwBufferSize <= sizeof(tempBuffer)) {
		      pBuffer = tempBuffer ;
		   } else {
		      pBuffer = MemoryAllocate (dwBufferSize) ;
		   }
		   memcpy (pBuffer, pSystem->lpszValue, dwBufferSize) ;
		}

		SetSystemValueNameToGlobal (pSystem);
		UpdateSystemData (pSystem, ppPerfData) ;

		if (pSystem->lpszValue) {
		   // retore the previous lpszValue string
		   memcpy (pSystem->lpszValue, pBuffer, dwBufferSize) ;
		   if (pBuffer != tempBuffer) {
		      MemoryFree (pBuffer) ;
		   }
		}
    }
    return (pSystem) ;

}


//
//  FUNCTION: DCompGraphGetObject
//
//  PURPOSE:
//    Return pointer to the object named lpszObject in pPerfData, or NULL if
//    not found.  Look up the object's name in the registry strings associated
//    with pSysInfo.
//
//  PARAMETERS:
//
//  RETURN VALUE:
//    pointer to the object, or NULL if not found
//
//  COMMENTS:
//

PPERFOBJECT		DCompGraphGetObject
(
	PPERFDATA	pPerfData,
	PPERFSYSTEM	pSysInfo,
	LPTSTR		lpszObject
)
{
	UINT           i ;
	PPERFOBJECT    pObject;
	TCHAR          szObject[PerfObjectLen + 1];

	pObject = FirstObject (pPerfData);

	for (i = 0, pObject = FirstObject (pPerfData);
	     i < pPerfData->NumObjectTypes;
	     i++, pObject = NextObject (pObject))
	{
		strclr (szObject);
		QueryPerformanceName (pSysInfo, pObject->ObjectNameTitleIndex, 
							  0, PerfObjectLen, szObject, FALSE) ;

		if (strsame(szObject, lpszObject))
		{
			return(pObject);
		}
	}

	return (NULL);
}


//
//  FUNCTION: DCompGraphGetCounter
//
//  PURPOSE:
//    Return pointer to the counter object named lpszCounterName in pPerfData,
//    or NULL if not found.  Look up the object's name in the registry strings
//    associated with pSystem.
//
//  PARAMETERS:
//
//  RETURN VALUE:
//    pointer to the object, or NULL if not found
//
//  COMMENTS:
//

PPERFCOUNTERDEF		DCompGraphGetCounter
(
	PPERFOBJECT	pObject,
	PPERFSYSTEM	pSystem,
	LPTSTR		lpszCounterName
)
{

	TCHAR			szCounterName [256] ;
	PPERFCOUNTERDEF	pCounter ;
	UINT			i ;

	if (!pObject)
		return (NULL) ;

	for (i = 0, pCounter = FirstCounter (pObject) ;
						i < pObject->NumCounters ;
						i++, pCounter = NextCounter (pCounter))
	{
		szCounterName[0] = TEXT('\0') ;
		QueryPerformanceName (pSystem, 
		                     pCounter->CounterNameTitleIndex, 
		                     0, sizeof (szCounterName) / sizeof(TCHAR),
		                     szCounterName,
		                     FALSE) ;

		// 
		if (strsame(szCounterName, lpszCounterName))
		{
			return(pCounter);
		}
	}

	return(NULL);
}


//
//  FUNCTION: DCompGraphGetInstance
//
//  PURPOSE:
//    Return pointer to the instance object named lpszInstance in pPerfData,
//    or NULL if not found.
//
//  PARAMETERS:
//
//  RETURN VALUE:
//    pointer to the object, or NULL if not found
//
//  COMMENTS:
//

PPERFINSTANCEDEF	DCompGraphGetInstance
(
	PPERFOBJECT			pObject,
	LPTSTR				lpszInstance
)
{
	PPERFINSTANCEDEF	pInstance, pInstanceParent = NULL;
	TCHAR				szInstance[256], szInstanceParent[256];
	TCHAR				szCompositeName[256];
	TCHAR				szInstCompositeName[256];
                           
	LONG				iInstance;

	if ((!pObject) || (pObject->NumInstances <= 0))
	{
		return(NULL);
	}

	szInstCompositeName[0] = TEXT('\0');

	for (iInstance = 0, pInstance = FirstInstance (pObject) ;
		 iInstance < pObject->NumInstances; 
		 iInstance++, pInstance = NextInstance (pInstance))
	{
		GetInstanceName (pInstance, szInstance) ;
//		pInstanceParent = ParentInstance (pInstance) ;	// ignore parent instances

		if (pInstanceParent)
		{
			GetInstanceName (pInstanceParent, szInstanceParent);
			TSPRINTF (szCompositeName, TEXT("%s ==> %s"), 
												szInstanceParent, szInstance);
		}
		else
			lstrcpy (szCompositeName, szInstance) ;

		if (strsame(szCompositeName, lpszInstance))
		{
			return(pInstance);
		}
	}

	return (NULL);
}


//
//  FUNCTION: ServerValNext
//
//  PURPOSE:
//    Function for getting the next value for the server process chart line.
//
//  PARAMETERS:
//    lnParam - pointer to the chart line structure
//
//  RETURN VALUE:
//    the next monitoring value
//
//  COMMENTS:
//

FLOAT	ServerValNext(struct _LINESTRUCT *lnParam)
{	geServerAveVal = lnParam->lnAveValue;

	return(CounterEntry(lnParam));
}


//
//  FUNCTION: IdleValNext
//
//  PURPOSE:
//    Function for getting the next value for the idle process chart line.
//
//  PARAMETERS:
//    lnParam - pointer to the chart line structure
//
//  RETURN VALUE:
//    the next monitoring value
//
//  COMMENTS:
//

FLOAT	IdleValNext(struct _LINESTRUCT *lnParam)
{
	geIdleAveVal = lnParam->lnAveValue;

	return(CounterEntry(lnParam));
}


//
//  FUNCTION: SumValNext
//
//  PURPOSE:
//    Function for getting the next value for the chart line of the averaged
//    sum of the server and idle processes.
//
//  PARAMETERS:
//    lnParam - pointer to the chart line structure
//
//  RETURN VALUE:
//    the next monitoring value
//
//  COMMENTS:
//    Assumes ServerValNext and IdleValNext have been called first.
//    As a side-effect, update the global flag gfServerComputerBusy and the
//    monitoring window's status line
//

FLOAT	SumValNext(struct _LINESTRUCT *lnParam)
{
	FLOAT	eAve = geServerAveVal + geIdleAveVal;

	gfServerComputerBusy = (eAve < geCurrentThreshold);

	_tcscpy(szStatusFormat, (gfServerComputerBusy ? NOT_ACCEPTING : ACCEPTING));
 	StatusLineReady (hWndStatus) ;
//	szStatusLineLen = lstrlen (szStatusLine) ;

	return(eAve);	// means the average is 1 tick behind
}


//
//  FUNCTION: ThresholdValNext
//
//  PURPOSE:
//    Function for getting the next value for the busy threshold chart line
//
//  PARAMETERS:
//    lnParam - pointer to the chart line structure
//
//  RETURN VALUE:
//    the next monitoring value - always the same fixed value
//
//  COMMENTS:
//

FLOAT	ThresholdValNext(struct _LINESTRUCT *lnParam)
{
//	lnParam->bFirstTime = 1 ;

	return(geCurrentThreshold);
}
