/* THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
 * ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
 * PARTICULAR PURPOSE.
 *
 * Copyright (C) 1993, 1994  Microsoft Corporation.  All Rights Reserved.
 *
 *  MODULE:   RegDB.c
 *
 *  Borrowed for the Distributed Compression sample from the Regmpad sample.
 */

/* RegDB.c -- Implements the semantics of the registry interface for this
 *            application. The visible interfaces and data structures are
 *            defined in RegDB.h.

 * Adapted for the Distributed Compression sample from the Regmpad sample.
 */
/*
 *
                                Overview
                                --------

The NT Registry is an object database consisting of keys and values. Keys
have names and may contain other keys and values. A value is a name paired
with a data object and a data type. The keys in the registry are analogous
to the directories in a file system. In that vein the values are analogous
to files.

Access to a key and its associated set of values is mediated by a key handle.
Four key handles are given as predefined constants. Those handles correspond
to the roots of key trees which have special signifigance. Handles for the
other keys in the registry database may be constructed via the Registry's
Open and Create interfaces using an existing key handle and a relative path
string.

The predefined key handles are:


    HKEY_LOCAL_MACHINE -- This handle refers to a tree of keys and values
                          which characterize the state of the local machine.
                          It contains state information global to everyone
                          who uses the machine.

    HKEY_CLASSES_ROOT  -- This handle refers to a subtree within
                          HKEY_LOCAL_MACHINE. It defines the associations
                          between file extensions and document types as well
                          as the command strings for shell and DDE/OLE actions.

    HKEY_USERS         -- This handle refers to a tree of information about
                          the people who use this machine. The top level of
                          the tree consists of a .DEFAULT key and one or more
                          entries for specific people. The specific entries
                          are created dynamically and are initially based on
                          the content of the .DEFAULT key. The key names for
                          the specific entries are SIDs which define the
                          permissions given to the corresponding people.

    HKEY_CURRENT_USER  -- This handle refers to a specific user key within
                          HKEY_USERS. It denotes the information tree for
                          the currently active user id.


DComp Service user permissions
------------------------------

When a service called <Service Name> is first installed, the Service Control
Manager creates a key called "System\CurrentControlSet\Services\<Service Name>"
in HKEY_LOCAL_MACHINE.

The Distributed Compression server application creates a key called
UserPermissions inside this ...\Services\DCompService key when it is run for the
first time after installation.  The key UserPermissions carries its own
security descriptor including a DACL, and a copy of the key's DACL is used as
the DACL of the named pipe and LPC endpoints which the server uses to listen
for requests.  By editing the permissions of this key (using the registry
editor, for example), administrators on a specific computer can control access
to the DComp Service.  The UserPermissions key has no other function.

Note - this method is crude because key permissions have different meanings
       from pipe/endpoint permissions.  The key permissions are re-mapped to
       file permissions in the function ConvKeyACLToPipeACL.
*/

#include	"dcomp.h"
#include	"dcomps.h"


HANDLE	hmtxRegGlobal = NULL;	// Mutex for serializing Local Machine Data.
HKEY	hkGlobal      = NULL;	// Key Handle for global registry data

BOOL RunningAsAdministrator(void)
{
   BOOL  fAdmin;
   HANDLE htkThread;
   TOKEN_GROUPS *ptg = NULL;
   DWORD cbTokenGroups;
   DWORD iGroup;
   SID_IDENTIFIER_AUTHORITY	SystemSidAuthority = SECURITY_NT_AUTHORITY;
   PSID psidAdmin;

   // This function returns TRUE if the user identifier associated with this
   // process is a member of the the Administrators group.

   // First we must open a handle to the access token for this thread.

   if (!OpenThreadToken(GetCurrentThread(), TOKEN_QUERY, FALSE, &htkThread))
      if (GetLastError() == ERROR_NO_TOKEN)
      {
         // If the thread does not have an access token, we'll examine the
         // access token associated with the process.

         if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &htkThread))
         return FALSE;
      }
      else return FALSE;

   // Then we must query the size of the group information associated with
   // the token. Note that we expect a FALSE result from GetTokenInformation
   // because we've given it a NULL buffer. On exit cbTokenGroups will tell
   // the size of the group information.

   if (GetTokenInformation(htkThread, TokenGroups, NULL, 0, &cbTokenGroups))
      return FALSE;

   // Here we verify that GetTokenInformation failed for lack of a large
   // enough buffer.

   if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
      return FALSE;

   // Now we allocate a buffer for the group information.
   // Since _alloca allocates on the stack, we don't have
   // to explicitly deallocate it. That happens automatically
   // when we exit this function.

   if (!(ptg = _alloca(cbTokenGroups))) return FALSE;

   // Now we ask for the group information again.
   // This may fail if an administrator has added this account
   // to an additional group between our first call to
   // GetTokenInformation and this one.

   if (!GetTokenInformation(htkThread, TokenGroups, ptg, cbTokenGroups,
                                       &cbTokenGroups
                           )
      )
      return FALSE;

   // Now we must create a System Identifier for the Admin group.

   if (!AllocateAndInitializeSid
          (&SystemSidAuthority, 2, SECURITY_BUILTIN_DOMAIN_RID,
                                   DOMAIN_ALIAS_RID_ADMINS,
                                   0, 0, 0, 0, 0, 0,
                                   &psidAdmin
          )
      )
      return FALSE;

   // Finally we'll iterate through the list of groups for this access
   // token looking for a match against the SID we created above.

   fAdmin = FALSE;

   for (iGroup = 0; iGroup < ptg->GroupCount; iGroup++)
      if (EqualSid(ptg->Groups[iGroup].Sid, psidAdmin))
      {
         fAdmin = TRUE;

         break;
      }

   // Before we exit we must explicity deallocate the SID
   // we created.

   FreeSid(psidAdmin);

   return(fAdmin);
}


BOOL InstallApp(LPTSTR pszPathBuff)
{
	// This function attempts to install global data for this
	// application in the HKEY_LOCAL_MACHINE portion of the
	// registry database.

	// The parameter pszPathBuff refers to a null terminated
	// string which defines where the new key should be located
	// in the LOCAL_MACHINE tree.

	// We requires that the current user have administrative
	// privileges. That requirement insures that the owner
	// tag for the global registry entries will be the
	// Administrator group and not a particular user id.

	// We also assume that hmtxRegGlobal is held when this function is called.

	// First we'll see whether this user has admin privileges...
	// Only administrators can install this application...

	if (!RunningAsAdministrator())
	{
		Eprintf(
			TEXT("Must be administrator to install user permissions key\n"));
		return FALSE;
	}

	// Call StoreAppConfig with configuration data.

	return(StoreAppConfig(pszPathBuff));
}


//
//  FUNCTION: WriteDefaultKeyValues
//
//  PURPOSE: write the default key values used by the application
//
//  PARAMETERS:
//    hk - handle to the (open) key to write the values in. 
//
//  RETURN VALUE:
//    Non-zero on success, zero on failure.
//
//  COMMENTS:
//    The default values are contained in the global table gakvConfig.
//

BOOL	WriteDefaultKeyValues(HKEY hk)
{
	LONG			l;
	LONG			lResult;

	for (l = 0; gakvConfig[l].lpszValueName != NULL; l++)
	{

		lResult = RegSetValueEx
				  (
					hk,
					gakvConfig[l].lpszValueName,
					0,
					gakvConfig[l].fdwType,
					*gakvConfig[l].lplpbData,
					gakvConfig[l].cbData
				  );

		if (lResult != ERROR_SUCCESS) return(FALSE);
	}

	return(TRUE);
}


BOOL StoreAppConfig(LPTSTR pszPathBuff)
{
	// This function attempts to install global data for this application in
	// the HKEY_LOCAL_MACHINE portion of the registry database. It is called
	// from InstallApp.

	// The parameter pszPathBuff refers to a null terminated string which
	// defines where the main key for the service should be located in the
	// LOCAL_MACHINE tree.  We are going to add some values to this key, and
	// create the UserPermissions subkey.

	// Normally the application is installed as a service before being run, so
	// we expect the main key to have already been created by the CreateService
	// API, with default permissions.
	
	// However, if the application's first run is in debug mode, the main key
	// won't already exist and we'll create it here.  In this case, the new
	// main key for the service will have the same permissions as the
	// UserPermissions subkey.  If the app is subsequently installed as a
	// service, CreateService will not alter this, so the main service key will
	// end up retaining its non-default permissions.

	// We assume that hmtxRegGlobal is held when this function is called.


	HKEY				hkGlobal    = NULL;
	HKEY				hkUserPerms = NULL;
	BOOL				fInstalled  = FALSE;
	LONG				lResult;
	DWORD				dwDisposition;
	SECURITY_ATTRIBUTES	sa;
	TCHAR				abPathBuffer[MAX_PATH];


	// First we'll set up the security attributes we're going to
	// use with the application's UserPermissions key.

	sa.nLength              = sizeof(SECURITY_ATTRIBUTES);
	sa.bInheritHandle       = FALSE;

	if ((sa.lpSecurityDescriptor = CreateEndpointSD()) == NULL)
	{
		Eprintf(TEXT("Couldn't generate default endpoint DACL to install\n"));
		goto security_failure;			
	}


	// Now we'll attempt to open (or create) the application's main key:

	//    System\CurrentControlSet\Services\<Service Name>

	lResult = RegCreateKeyEx(HKEY_LOCAL_MACHINE, pszPathBuff, 0,
	                       NULL,
	                       REG_OPTION_NON_VOLATILE,
	                       KEY_ALL_ACCESS,
	                       &sa, &hkGlobal, &dwDisposition
	                      );

	if (lResult != ERROR_SUCCESS) goto registry_access_error;

	if (   dwDisposition != REG_CREATED_NEW_KEY
	   && dwDisposition != REG_OPENED_EXISTING_KEY
	  ) goto registry_access_error;


	// Now we'll construct a relative path to the UserPermissions subkey we're
	// going to create:

	//    System\CurrentControlSet\Services\<Service Name>\UserPermissions

	_tcscpy(abPathBuffer, pszPathBuff);
	_tcscat(abPathBuffer, TEXT("\\UserPermissions"));


	// Now we'll attempt to create the key with the security attributes...

	lResult = RegCreateKeyEx(HKEY_LOCAL_MACHINE, abPathBuffer, 0,
	                       TEXT("DComp Service user permissions"),
	                       REG_OPTION_NON_VOLATILE,
	                       KEY_ALL_ACCESS,
	                       &sa, &hkUserPerms, &dwDisposition
	                      );

	if (lResult != ERROR_SUCCESS) goto registry_access_error;

	// Usually the disposition value will indicate that we've created a
	// new key. Sometimes it may instead state that we've opened an existing
	// key. This can happen when installation is incomplete and interrupted,
	// say by loss of electrical power.

	if (   dwDisposition != REG_CREATED_NEW_KEY
	   && dwDisposition != REG_OPENED_EXISTING_KEY
	  ) goto registry_access_error;

	
	// Now we'll write the default key values used by the application

	if (!WriteDefaultKeyValues(hkGlobal))
	{
		goto registry_access_error;
	}


	// Finally we'll write out the REG_INSTALLED flag. Note that its
	// value is unimportant. Only its existence matters.

	fInstalled = TRUE;

	lResult = RegSetValueEx(hkGlobal, REG_INSTALLED, 0, REG_DWORD,
	                      (LPBYTE) &fInstalled, sizeof(fInstalled)
	                     );

	if (lResult != ERROR_SUCCESS) goto registry_access_error;

	RegCloseKey(hkGlobal);
	RegCloseKey(hkUserPerms);

	return TRUE;

registry_access_error:

	Eprintf(TEXT("Registry Access Error!"));

	// We've constructed some, but not all of the global key state.
	// So we must remove any keys we created. The Defaults key must
	// be deleted first before the Global key can be deleted.

	if (hkGlobal) RegDeleteKey(HKEY_LOCAL_MACHINE, pszPathBuff);
	if (hkUserPerms) RegDeleteKey(HKEY_LOCAL_MACHINE, abPathBuffer);

	goto clean_up_after_failure;

security_failure:

	Eprintf(TEXT("Security Error During Installation!"));

clean_up_after_failure:

	if (sa.lpSecurityDescriptor) FreeEndpointSD(sa.lpSecurityDescriptor);

	return FALSE;
}

BOOL CreateAppKeys(void)
{
	long lResult;
	BOOL fSuccess;
	TCHAR abPathBuffer[MAX_PATH];
	TCHAR abMutexName [MAX_PATH];

	BOOL  fInstalled = FALSE;
	DWORD dwType, cbData;

	// Here we're constructing a registry key handle for user permissions
	// data. This data is kept in the HKEY_LOCAL_MACHINE tree.

	// The registry handle is returned in the global variable hkGlobal.
	// In addition a global mutex handle (hmtxRegGlobal) is created. The
	// mutex is used to serialize registry accesses among instances of this
	// application at start-up.  That serialization is necessary to insure
	// that a complete registry environment is present when the application
	// starts.

	// (Note that multiple instances of a Service process are not normally
	// allowed.)

	// Note that individual registry reads and writes do not need to be
	// serialized -- only collections of reads and writes which must be
	// consistent with each other.

	// Note also the use of the registry value REG_INSTALLED. It is the
	// last value written to the HKEY_LOCAL_MACHINE registry tree during the
	// installation sequence.  Whenever this application starts, it looks for
	// REG_INSTALLED as a sign that the registry has been properly setup. If
	// it doesn't find it, we assume that either setup hasn't been done or has
	// been done incompletely.

	// First we'll construct a relative path to the key we're going to
	// open. The path has the structure:

	//    System\CurrentControlSet\Services\<Service Name>

	_stprintf
	(
		abPathBuffer,
		TEXT("System\\CurrentControlSet\\Services\\%s"),
	    SZSERVICENAME
	);

	// Since two instance of this application could be running simultaneously,
	// we use a named mutex to serialize registry accesses.

	_stprintf
	(
		abMutexName,
		TEXT("System/CurrentControlSet/Services/%s"),
		SZSERVICENAME
	);

	if (!(hmtxRegGlobal = CreateMutex(NULL, FALSE, abMutexName)))
															goto failure_exit;


	// First we'll attempt to open a key to the global data...

	for (lResult = ~ERROR_SUCCESS; lResult != ERROR_SUCCESS; )
	{
	  // We serialize the code in this loop via hmtxRegGlobal.

	  lResult = WaitForSingleObject(hmtxRegGlobal, 0xFFFFFFFF);

	  if (   lResult != WAIT_ABANDONED
	      && lResult != WAIT_OBJECT_0
	     ) goto failure_exit;

	  lResult = RegOpenKeyEx(HKEY_LOCAL_MACHINE, abPathBuffer, 0, KEY_READ,
	                                            &hkGlobal
	                       );

	  // Note that we also look for the REG_INSTALLED flag.

	  cbData = sizeof(fInstalled);

	  if (   ERROR_SUCCESS != lResult
	      || ERROR_SUCCESS != RegQueryValueEx(hkGlobal, REG_INSTALLED, 0,
	                                          &dwType, (LPBYTE) &fInstalled,
	                                          &cbData
	                                         )
	     )
	  {
	     hkGlobal = NULL;

	     // If we can't open the global key, this probably means that the
	     // application hasn't been installed yet. So we'll try to install it.

	     // If the installation succeeds, we'll try opening the global key
	     // again. Otherwise we'll just fail.

	     fSuccess = InstallApp(abPathBuffer);

	     ReleaseMutex(hmtxRegGlobal);

	     if (fSuccess) continue;
	     else goto failure_exit;
	  }

	  ReleaseMutex(hmtxRegGlobal);
	}


	return TRUE;

failure_exit:

	// When we're exiting because of a failure, we must clean up
	// by closing any handles we've created along the way.

	if (hmtxRegGlobal) CloseHandle(hmtxRegGlobal);

	if (hkGlobal) RegCloseKey(hkGlobal);

	return FALSE;
}


//
//  FUNCTION: GetKeyDACLSD
//
//  PURPOSE: get an SD (security descriptor) containing the DACL (discretionary
//     access control list) from a registry key
//
//  PARAMETERS:
//    hkMainKey  - handle to an open key (typically a predefined reserved
//                 handle value such as HKEY_LOCAL_MACHINE
//    lpszSubKey - points to a null-terminated string containing the name of
//                 the subkey of interest
//
//  RETURN VALUE:
//    Pointer to a security descriptor containing the DACL, or NULL on failure.
//
//  COMMENTS:
//    This function needs to generate an SD in absolute format because the
//    function RPC 'UseProtseq...' API's apparently require this format.
//
//    GetKeyDACLSD allocates memory for the security descriptor.  Caller should
//    free it using FreeKeyDACLSD.
//

PSECURITY_DESCRIPTOR	GetKeyDACLSD(HKEY hkMainKey, LPTSTR lpszSubKey)
{
	LONG					lResult;
	PSECURITY_DESCRIPTOR	pSecDesc = NULL;
	DWORD					cbSecDesc;
	PSECURITY_DESCRIPTOR	pAbsSD = NULL;
	PACL					paclDiscretionary;
	DWORD					cbsdAbsolute = 0;
	DWORD					cbDacl = 0;
	DWORD					cbSacl = 0;
	DWORD					cbsidOwner = 0;
	DWORD					cbsidPrimaryGroup = 0;


	// Open the key

	lResult = RegOpenKeyEx(hkMainKey, lpszSubKey, 0, KEY_READ, &hkGlobal);
	if (lResult != ERROR_SUCCESS)
	{
		Eprintf(
			TEXT("Couldn't open registry key ...\\%s, error code %ld\n"),
			lpszSubKey,
			lResult);
		goto failure_exit;
	}


	// Find the size of the SD containing the DACL

	cbSecDesc = 0;
	lResult = RegGetKeySecurity(hkGlobal, DACL_SECURITY_INFORMATION,
															NULL, &cbSecDesc);
	if (lResult != ERROR_INSUFFICIENT_BUFFER)
	{
		Eprintf(
			TEXT("Couldn't get size of registry key SD, error code %ld\n"),
			lResult);
		goto failure_exit;
	}


	// Get the SD
	
	if ((pSecDesc = (PSECURITY_DESCRIPTOR) midl_user_allocate(cbSecDesc))
																	== NULL)
	{
		Eprintf(TEXT("Couldn't allocate memory for registry key SD\n"));
		goto failure_exit;
	}

	lResult = RegGetKeySecurity(hkGlobal, DACL_SECURITY_INFORMATION,
														pSecDesc, &cbSecDesc);
	if (lResult != ERROR_SUCCESS)
	{
		Eprintf(
			TEXT("Couldn't get registry key SD, error code %ld\n"),
			lResult);
		goto failure_exit;
	}


	// Convert it to absolute form: find sizes of buffers and allocate them

	lResult = MakeAbsoluteSD(
				pSecDesc,
				NULL, &cbsdAbsolute,
				NULL, &cbDacl,
				NULL, &cbSacl,
				NULL, &cbsidOwner,
				NULL, &cbsidPrimaryGroup);

	if (lResult)
	{
		Eprintf(TEXT("Couldn't get size of absolute SD\n"), lResult);
		goto failure_exit;
	}
				
	if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
	{
		Eprintf(
			TEXT("Couldn't get size of absolute SD, error code %ld\n"),
			GetLastError());
		goto failure_exit;
	}

	if ((pAbsSD = (PSECURITY_DESCRIPTOR) midl_user_allocate(cbsdAbsolute))
																	== NULL)
	{
		Eprintf(
			TEXT("Couldn't allocate memory for absolute registry key SD\n"));
		goto failure_exit;
	}

	if ((paclDiscretionary = (PACL) midl_user_allocate(cbDacl)) == NULL)
	{
		Eprintf(
			TEXT("Couldn't allocate memory for registry key DACL\n"));
		goto failure_exit;
	}


	// Do the conversion

	cbSacl = cbsidOwner = cbsidPrimaryGroup = 0;
	lResult = MakeAbsoluteSD(
				pSecDesc,
				pAbsSD, &cbsdAbsolute,
				paclDiscretionary, &cbDacl,
				NULL, &cbSacl,
				NULL, &cbsidOwner,
				NULL, &cbsidPrimaryGroup);
				
	if (!lResult)
	{
		Eprintf(
			TEXT("Couldn't make absolute SD, error code %ld\n"),
			GetLastError());
		goto failure_exit;
	}


	// Success: free the self-relative version and return the absolute version
						
	midl_user_free(pSecDesc);
	return(pAbsSD);


	// Here on failure

failure_exit:

	if (hkGlobal)          RegCloseKey(hkGlobal);

	if (pSecDesc)          midl_user_free(pSecDesc);
	if (pAbsSD)            midl_user_free(pAbsSD);
	if (paclDiscretionary) midl_user_free(paclDiscretionary);

	return(NULL);
}


//
//  FUNCTION: FreeKeyDACLSD
//
//  PURPOSE: frees an SD containing a DACL, previously allocated by using the
//     GetKeyDACLSD function
//
//  PARAMETERS:
//    pAbsSD - Points to the SD to free. 
//
//  RETURN VALUE:
//
//  COMMENTS:
//    Assumes only the DACL component of the SD has a dynamically-allocated
//    buffer
//

void		FreeKeyDACLSD(PSECURITY_DESCRIPTOR pAbsSD)
{
	PACL	pACL;
	BOOL	fDaclPresent;
	BOOL	fDaclDefaulted;

	if (!GetSecurityDescriptorDacl(pAbsSD, &fDaclPresent, &pACL,
															&fDaclDefaulted))
	{
		Eprintf(TEXT("GetSecurityDescriptorDacl failed, error code %lu\n"),
															GetLastError());
	}

	if (fDaclPresent)
	{
		midl_user_free(pACL);
	}

	if (pAbsSD) midl_user_free(pAbsSD);
}


//
//  FUNCTION: ReadAppKeyValues
//
//  PURPOSE: get the application's configuration key values from the main
//    application key in HKEY_LOCAL_MACHINE
//
//  PARAMETERS:
//
//  RETURN VALUE:
//    Non-zero on success, zero on failure.
//
//  COMMENTS:
//    Expect to execute this only once, on startup.  If a key value cannot be
//    read, its default value is left intact.
//

void	ReadAppKeyValues(void)
{
	LONG			l;
	TCHAR			abPathBuffer[MAX_PATH];
	LPBYTE			lpbBuf;
	DWORD			cbData;
	HKEY			hk;


	// Construct a relative path to the key we're going to
	// read. The path has the structure:
	//    System\CurrentControlSet\Services\<Service Name>

	_stprintf
	(
		abPathBuffer,
		TEXT("System\\CurrentControlSet\\Services\\%s"),
	    SZSERVICENAME
	);


	// Open the key

	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, abPathBuffer, 0, KEY_READ, &hk)
															!= ERROR_SUCCESS)
	{
		Eprintf(
			TEXT("Could not open application key")
			TEXT(" - using default configuration\n"));
		return;
	}


	// Walk through the key value table
		
	for (l = 0; gakvConfig[l].lpszValueName != NULL; l++)
	{
		// Check the size of the value

		if (RegQueryValueEx(hk, (LPTSTR) gakvConfig[l].lpszValueName,
									0, NULL, NULL, &cbData) != ERROR_SUCCESS)
		{
			// Error - leave the default value intact

			continue;
		}


		// Allocate some memory for the value

		if ((lpbBuf = (LPBYTE) midl_user_allocate(cbData)) == NULL)
		{
			continue;
		}


		// Try to read the value

		if (RegQueryValueEx(hk, (LPTSTR) gakvConfig[l].lpszValueName,
									0, NULL, lpbBuf, &cbData) != ERROR_SUCCESS)
		{
			midl_user_free(lpbBuf);
			continue;
		}


		// Copy value into the existing variable if it has enough space.
		// Otherwise substitute the allocated buffer for the existing one.

		if (gakvConfig[l].cbData >= cbData)
		{
			memcpy((LPVOID) *gakvConfig[l].lplpbData, lpbBuf, cbData);
			midl_user_free(lpbBuf);
		}
		else
		{
			*gakvConfig[l].lplpbData = lpbBuf;
		}

		gakvConfig[l].cbData = cbData;
	}

	RegCloseKey(hk);	
}
