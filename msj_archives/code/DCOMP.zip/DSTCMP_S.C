
#include <string.h>
#include "dstcmp.h"

extern const MIDL_FORMAT_STRING __MIDLFormatString;

extern const MIDL_FORMAT_STRING __MIDLProcFormatString;
static RPC_PROTSEQ_ENDPOINT __RpcProtseqEndpoint[] = 
    {
    {(unsigned char *) "ncalrpc", (unsigned char *) "DistComp"},
    {(unsigned char *) "ncacn_np", (unsigned char *) "\\pipe\\DistComp"}
    };


extern RPC_DISPATCH_TABLE DistComp_v1_0_DispatchTable;

static const RPC_SERVER_INTERFACE DistComp___RpcServerInterface =
    {
    sizeof(RPC_SERVER_INTERFACE),
    {{0x6de3bb40,0xe6ac,0x11cd,{0x8a,0x0b,0x00,0xaa,0x00,0x4a,0x2e,0x32}},{1,0}},
    {{0x8A885D04,0x1CEB,0x11C9,{0x9F,0xE8,0x08,0x00,0x2B,0x10,0x48,0x60}},{2,0}},
    &DistComp_v1_0_DispatchTable,
    2,
    __RpcProtseqEndpoint,
    0,
    0
    };
RPC_IF_HANDLE DistComp_v1_0_s_ifspec = (RPC_IF_HANDLE)& DistComp___RpcServerInterface;

extern const MIDL_STUB_DESC DistComp_StubDesc;

void __RPC_STUB
DistComp_RPCControl(
    PRPC_MESSAGE _pRpcMessage )
{
    LONG _RetVal;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t hHandle;
    LONG lCommand;
    
NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &DistComp_StubDesc);
    hHandle = _pRpcMessage->Handle;
    RpcTryFinally
        {
        NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[0] );
        
        lCommand = *(( LONG __RPC_FAR * )_StubMsg.Buffer)++;
        
        
        _RetVal = RPCControl(hHandle,lCommand);
        
        _StubMsg.BufferLength = 4U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, 0 );
        
        *(( LONG __RPC_FAR * )_StubMsg.Buffer)++ = _RetVal;
        
        }
    RpcFinally
        {
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
DistComp_RPCRecompressVideo(
    PRPC_MESSAGE _pRpcMessage )
{
    LONG _RetVal;
    MIDL_STUB_MESSAGE _StubMsg;
    LONG ( __RPC_FAR *alIndex )[  ];
    handle_t hHandle;
    LONG lBunchId;
    LONG lBunchLen;
    LONG lComDataLen;
    LONG lRecDataLen;
    LONG lStreamFormatSize;
    BYTE ( __RPC_FAR *lpbComData )[  ];
    LPBITMAPINFO lpbComFormat;
    BYTE ( __RPC_FAR *lpbRecData )[  ];
    LPBITMAPINFO lpbRecFormat;
    LPBITMAPINFO lpbUncFormat;
    
NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &DistComp_StubDesc);
    hHandle = _pRpcMessage->Handle;
    lpbComFormat = 0;
    lpbUncFormat = 0;
    lpbRecFormat = 0;
    alIndex = 0;
    lpbRecData = 0;
    lpbComData = 0;
    RpcTryFinally
        {
        NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDLProcFormatString.Format[6] );
        
        lBunchId = *(( LONG __RPC_FAR * )_StubMsg.Buffer)++;
        
        lBunchLen = *(( LONG __RPC_FAR * )_StubMsg.Buffer)++;
        
        lStreamFormatSize = *(( LONG __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&lpbComFormat,
                              (PFORMAT_STRING) &__MIDLFormatString.Format[0],
                              (unsigned char)0 );
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&lpbUncFormat,
                              (PFORMAT_STRING) &__MIDLFormatString.Format[0],
                              (unsigned char)0 );
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&lpbRecFormat,
                              (PFORMAT_STRING) &__MIDLFormatString.Format[0],
                              (unsigned char)0 );
        
        NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR * __RPC_FAR *)&alIndex,
                                      (PFORMAT_STRING) &__MIDLFormatString.Format[70],
                                      (unsigned char)0 );
        
        lRecDataLen = *(( LONG __RPC_FAR * )_StubMsg.Buffer)++;
        
        lComDataLen = *(( LONG __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR * __RPC_FAR *)&lpbComData,
                                      (PFORMAT_STRING) &__MIDLFormatString.Format[90],
                                      (unsigned char)0 );
        
        lpbRecData = _StubMsg.pfnAllocate(lRecDataLen * 1);
        
        _RetVal = RPCRecompressVideo(
                             hHandle,
                             lBunchId,
                             lBunchLen,
                             lStreamFormatSize,
                             lpbComFormat,
                             lpbUncFormat,
                             lpbRecFormat,
                             *alIndex,
                             lRecDataLen,
                             *lpbRecData,
                             lComDataLen,
                             *lpbComData);
        
        _StubMsg.BufferLength = 4U + 7U + 11U;
        _StubMsg.MaxCount = lBunchLen + 1;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)*alIndex,
                                      (PFORMAT_STRING) &__MIDLFormatString.Format[70] );
        
        _StubMsg.MaxCount = lRecDataLen;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)*lpbRecData,
                                      (PFORMAT_STRING) &__MIDLFormatString.Format[80] );
        
        _StubMsg.BufferLength += 16;
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, 0 );
        
        _StubMsg.MaxCount = lBunchLen + 1;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)*alIndex,
                                    (PFORMAT_STRING) &__MIDLFormatString.Format[70] );
        
        _StubMsg.MaxCount = lRecDataLen;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)*lpbRecData,
                                    (PFORMAT_STRING) &__MIDLFormatString.Format[80] );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *)(((long)_StubMsg.Buffer + 3) & ~ 0x3);
        *(( LONG __RPC_FAR * )_StubMsg.Buffer)++ = _RetVal;
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lStreamFormatSize;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)lpbComFormat,
                        &__MIDLFormatString.Format[0] );
        
        _StubMsg.MaxCount = lStreamFormatSize;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)lpbUncFormat,
                        &__MIDLFormatString.Format[0] );
        
        _StubMsg.MaxCount = lStreamFormatSize;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)lpbRecFormat,
                        &__MIDLFormatString.Format[0] );
        
        if ( lpbRecData )
            _StubMsg.pfnFree( lpbRecData );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}


static const MIDL_STUB_DESC DistComp_StubDesc = 
    {
    (void __RPC_FAR *)& DistComp___RpcServerInterface,
    MIDL_user_allocate,
    MIDL_user_free,
    0,
    0,
    0,
    0,
    0,
    __MIDLFormatString.Format,
    0, /* -error bounds_check flag */
    0x10001, /* Ndr library version */
    0, /* Reserved */
    0, /* Reserved */
    0  /* Reserved */
    };

static RPC_DISPATCH_FUNCTION DistComp_table[] =
    {
    DistComp_RPCControl,
    DistComp_RPCRecompressVideo,
    0
    };
RPC_DISPATCH_TABLE DistComp_v1_0_DispatchTable = 
    {
    2,
    DistComp_table
    };

static const MIDL_FORMAT_STRING __MIDLProcFormatString =
    {
        0,
        {
			0x4e,		/* FC_IN_PARAM_BASETYPE */
			0xf,		/* FC_IGNORE */
/*  2 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/*  4 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/*  6 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0xf,		/* FC_IGNORE */
/*  8 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/* 10 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/* 12 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/* 14 */	
			0x4d,		/* FC_IN_PARAM */
			0x1,		/* 1 */
/* 16 */	0x0, 0x0,	/* Type Offset=0 */
/* 18 */	
			0x4d,		/* FC_IN_PARAM */
			0x1,		/* 1 */
/* 20 */	0x0, 0x0,	/* Type Offset=0 */
/* 22 */	
			0x4d,		/* FC_IN_PARAM */
			0x1,		/* 1 */
/* 24 */	0x0, 0x0,	/* Type Offset=0 */
/* 26 */	
			0x50,		/* FC_IN_OUT_PARAM */
			0x1,		/* 1 */
/* 28 */	0x46, 0x0,	/* Type Offset=70 */
/* 30 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/* 32 */	
			0x51,		/* FC_OUT_PARAM */
			0x1,		/* 1 */
/* 34 */	0x50, 0x0,	/* Type Offset=80 */
/* 36 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/* 38 */	
			0x4d,		/* FC_IN_PARAM */
			0x1,		/* 1 */
/* 40 */	0x5a, 0x0,	/* Type Offset=90 */
/* 42 */	0x53,		/* FC_RETURN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */

			0x0
        }
    };

static const MIDL_FORMAT_STRING __MIDLFormatString =
    {
        0,
        {
			0x11, 0x0,	/* FC_RP */
/*  2 */	0x36, 0x0,	/* Offset= 54 (56) */
/*  4 */	
			0x15,		/* FC_STRUCT */
			0x3,		/* 3 */
/*  6 */	0x28, 0x0,	/* 40 */
/*  8 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 10 */	0x8,		/* FC_LONG */
			0x6,		/* FC_SHORT */
/* 12 */	0x6,		/* FC_SHORT */
			0x38,		/* FC_ALIGNM4 */
/* 14 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 16 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 18 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 20 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 22 */	
			0x15,		/* FC_STRUCT */
			0x0,		/* 0 */
/* 24 */	0x4, 0x0,	/* 4 */
/* 26 */	0x2,		/* FC_CHAR */
			0x2,		/* FC_CHAR */
/* 28 */	0x2,		/* FC_CHAR */
			0x2,		/* FC_CHAR */
/* 30 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 32 */	
			0x1d,		/* FC_SMFARRAY */
			0x0,		/* 0 */
/* 34 */	0x4, 0x0,	/* 4 */
/* 36 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 38 */	0xf0, 0xff,	/* Offset= -16 (22) */
/* 40 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 42 */	
			0x15,		/* FC_STRUCT */
			0x3,		/* 3 */
/* 44 */	0x2c, 0x0,	/* 44 */
/* 46 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 48 */	0xd4, 0xff,	/* Offset= -44 (4) */
/* 50 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 52 */	0xec, 0xff,	/* Offset= -20 (32) */
/* 54 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 56 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 58 */	0x2c, 0x0,	/* 44 */
/* 60 */	0x28,		/* 40 */
			0x0,		/*  */
#ifndef _ALPHA_
/* 62 */	0xc, 0x0,	/* Stack offset= 12 */
#else
			0x18, 0x0,	/* Stack offset= 24 */
#endif
/* 64 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 66 */	0xe8, 0xff,	/* Offset= -24 (42) */
/* 68 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 70 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 72 */	0x4, 0x0,	/* 4 */
/* 74 */	0x28,		/* 40 */
			0x57,		/* FC_ADD_1 */
#ifndef _ALPHA_
/* 76 */	0x8, 0x0,	/* Stack offset= 8 */
#else
			0x10, 0x0,	/* Stack offset= 16 */
#endif
/* 78 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 80 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 82 */	0x1, 0x0,	/* 1 */
/* 84 */	0x28,		/* 40 */
			0x0,		/*  */
#ifndef _ALPHA_
/* 86 */	0x20, 0x0,	/* Stack offset= 32 */
#else
			0x40, 0x0,	/* Stack offset= 64 */
#endif
/* 88 */	0x2,		/* FC_CHAR */
			0x5b,		/* FC_END */
/* 90 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 92 */	0x1, 0x0,	/* 1 */
/* 94 */	0x28,		/* 40 */
			0x0,		/*  */
#ifndef _ALPHA_
/* 96 */	0x28, 0x0,	/* Stack offset= 40 */
#else
			0x50, 0x0,	/* Stack offset= 80 */
#endif
/* 98 */	0x2,		/* FC_CHAR */
			0x5b,		/* FC_END */

			0x0
        }
    };
