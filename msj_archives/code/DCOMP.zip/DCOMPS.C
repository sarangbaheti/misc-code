/* THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
 * ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
 * PARTICULAR PURPOSE.
 *
 * Copyright (C) 1994  Microsoft Corporation.  All Rights Reserved.
 *
 *  MODULE:   dcomps.c
 *
 *  PURPOSE:
 *	  contains server-side code for the Distributed Compression sample
 *
 *  FUNCTIONS:
 *	  ServiceStart (DWORD dwArgc, LPTSTR *lpszArgv)
 *	  ServiceStop(void)
 *	  StartPerfMonThread(void)
 *    MessageBoxThread(LPVOID dummy)
 *    GetHardwareInfo(void)
 *
 *  COMMENTS:
 *    This file contains the "real" start point for the sample server.  It is
 *    started up by the generic service code in service.c.
 *    Parts of this code were adapted from the nhello sample.
 */


#define		DEFINE_GLOBALS
#include	"dcomp.h"
#include	"dcomps.h"


RPC_STATUS		StartPerfMonThread(void);
DWORD WINAPI	MessageBoxThread(LPVOID dummy);
void			GetHardwareInfo(void);


//
//  FUNCTION: ServiceStart
//
//  PURPOSE:
//    start the server processing threads and listen for RPC calls
//
//  PARAMETERS:
//    dwArgc   - number of command line arguments
//    lpszArgv - array of command line arguments
//
//  RETURN VALUE:
//
//  COMMENTS:
//

VOID ServiceStart (DWORD dwArgc, LPTSTR *lpszArgv)
{
    RPC_STATUS				status;
    RPC_STATUS				temp_status;
    RPC_BINDING_VECTOR		*pBindingVector = NULL;
    LPTSTR					pszEntryName   = DCOMP_RPC_EXPORT_NAME;
    unsigned char			*pszSecurity    = NULL;
    unsigned int			cMinCalls       = 1;
    unsigned int			cMaxCalls       = 20;
    unsigned int			fDontWait       = 0;
    unsigned int			fNameSyntaxType = RPC_C_NS_SYNTAX_DEFAULT;
    BOOL					bRegistered = FALSE;
    BOOL					bEndpoint = FALSE;
    BOOL					bExported = FALSE;
    BOOL					bProto = FALSE;
    DWORD					i;
    PSECURITY_DESCRIPTOR	pSD = NULL;
	BOOL					bUsedKeySD = FALSE;
	PACL					pACL;
	BOOL					fDaclPresent;
	BOOL					fDaclDefaulted;
	TCHAR					abPathBuffer[MAX_PATH];
	HANDLE					hMessageBox;
	DWORD					dwIDMessageBox;
	HKEY					hkComputerKey;


    // allow the user to override settings with command line switches

    for (i = 1; i < dwArgc; i++) {
        if ((*(lpszArgv[i]) == '-') || (*(lpszArgv[i]) == '/')) {
            switch (tolower(*((lpszArgv[i])+1))) {
            case 'm':
                cMaxCalls = (unsigned int) _ttoi(lpszArgv[++i]);
                break;
            case 'n':
                cMinCalls = (unsigned int) _ttoi(lpszArgv[++i]);
                break;
            case 'f':
                fDontWait = (unsigned int) _ttoi(lpszArgv[++i]);
                break;
            case 'a':
                pszEntryName = lpszArgv[++i];
				Eprintf(TEXT("Entry name reset to \"%s\"\n"), pszEntryName);
                break;
            case 't':
                fNameSyntaxType = (unsigned int) _ttoi(lpszArgv[++i]);
                break;
            }
        }
    }


	// NT-only initialisations

 	if (gdwOSPlatformId == VER_PLATFORM_WIN32_NT)
	{
		// Initialize registry and configuration values.  If this fails, we use
		// defaults for configuration.

		if (!CreateAppKeys())
		{
			Dprintf(
				TEXT("Couldn't initialize")
				TEXT(" registry application configuration keys\n"));
		}


		// Read application configuration values
		
		ReadAppKeyValues();


		// Redirect debug output to the path specified in the registry.  Up to
		// now, this has been redirected to the application's default path.

		if (_tcslen(gpszDbgOutFile) > 0)
		{
			_tfreopen(gpszDbgOutFile, TEXT("w+"), stdout);
			_tfreopen(gpszDbgOutFile, TEXT("w+"), stderr);
		}


		// Initialize ACL for the server endpoints

		// Connect to the computer which has the permissions in its registry

		// Construct the full computer name

		_stprintf(abPathBuffer, TEXT("\\\\%s"), gpszUserPermsCmptr);


		// Try to connect to remote computer

        try
        {
			status = RegConnectRegistry(abPathBuffer, HKEY_LOCAL_MACHINE,
															&hkComputerKey);
        }
        finally
        {
			if (status != ERROR_SUCCESS)
			{
				// Failed - use the local computer

				hkComputerKey = HKEY_LOCAL_MACHINE;
			}
        }


		// Now construct a relative path to the key we're going to
		// read the security from. The path has the structure:
		//
		//    System\CurrentControlSet\Services\<Service Name>\UserPermissions
		//

		_stprintf
		(
			abPathBuffer,
			TEXT("System\\CurrentControlSet\\Services\\%s\\UserPermissions"),
		    SZSERVICENAME
		);

		if ((pSD = GetKeyDACLSD(hkComputerKey, abPathBuffer)) == NULL)
		{
			// Couldn't read DACL from the registry key so use a default one

			Dprintf(TEXT("Couldn't read endpoint DACL from registry key\n"));
			if ((pSD = CreateEndpointSD()) == NULL)
			{
				Eprintf(TEXT("Couldn't generate default endpoint DACL\n"));
				goto cleanup;			
			}
		}
		else
		{
			bUsedKeySD = TRUE;
		}

		RegCloseKey(hkComputerKey);	


	    // Must report status to the service control manager frequently while
	    // starting up the service

	    if (!ReportStatusToSCMgr(
	        SERVICE_START_PENDING, // service state
	        NO_ERROR,              // exit code
	        3000))                 // wait hint
	        goto cleanup;


		// Read the DACL from the key's security descriptor

		if (!GetSecurityDescriptorDacl(pSD, &fDaclPresent, &pACL,
															&fDaclDefaulted))
		{
			Eprintf(
				TEXT("GetSecurityDescriptorDacl failed, error code %lu\n"),
															GetLastError());
	        goto cleanup;
		}

	
		// Convert the DACL permissions to named pipe style

		if (fDaclPresent)
		{
			if (!ConvKeyACLToPipeACL(pACL))
			{
				Eprintf(
					TEXT("Failed to generate ACL for endpoints\n"), status);
		        goto cleanup;
			}
		}


		// Initialize debug feature used in function RPCControl
		InitializeSecurityDiagnostics();
	}


	// General initializations

	// Hardware info
	GetHardwareInfo();


	// Initialize use of LRPC endpoint defined in the MIDL code
    status = RpcServerUseProtseqIf(TEXT("ncalrpc"),
    									cMaxCalls, DIST_COMP_S_IF_SPEC, pSD);
	if (status != RPC_S_OK)
	{
		Eprintf(
			TEXT("RpcServerUseProtseqIf(\"ncalrpc\", ...) failed:")
			TEXT(" error code %d\n"),
			status);
        goto cleanup;
	}


 	if (gdwOSPlatformId == VER_PLATFORM_WIN32_NT)
	{
		// Initialize use of named pipe endpoint defined in the MIDL code
		// (NT only)

	    status = RpcServerUseProtseqIf(TEXT("ncacn_np"),
	    								cMaxCalls, DIST_COMP_S_IF_SPEC, pSD);
		if (status != RPC_S_OK)
		{
			Eprintf(
				TEXT("RpcServerUseProtseqIf(\"ncacn_np\", ...) failed:")
				TEXT(" error code %d\n"),
				status);
	        goto cleanup;
		}
	}


	// Tidy away the security data (NT only)

 	if (gdwOSPlatformId == VER_PLATFORM_WIN32_NT)
	{
		if (bUsedKeySD)
		{
			FreeKeyDACLSD(pSD);
		}
		else
		{
			FreeEndpointSD(pSD);
		}
	}

    if (!ReportStatusToSCMgr(
        SERVICE_START_PENDING, // service state
        NO_ERROR,              // exit code
        30000))                // wait hint  - Inq can take quite a while
        goto cleanup;


    // Inquire bindings

    status = RpcServerInqBindings(&pBindingVector);
	if (status != RPC_S_OK)
	{
		Eprintf(TEXT("RpcServerInqBindings failed: error code %d\n"), status);
        goto cleanup;
	}

    if (!ReportStatusToSCMgr(
        SERVICE_START_PENDING, // service state
        NO_ERROR,              // exit code
        45000))                // wait hint  - Inq can take quite a while
        goto cleanup;
 

    // Register endpoints in the local endpoint-map database

    status = RpcEpRegister(DIST_COMP_S_IF_SPEC,
                           pBindingVector,
                           NULL,
                           NULL);
	if (status != RPC_S_OK)
	{
		Eprintf(TEXT("RpcEpRegister failed: error code %d\n"), status);
        goto cleanup;
	}
    else
    { 
        bEndpoint = TRUE;
	}

    if (!ReportStatusToSCMgr(
        SERVICE_START_PENDING, // service state
        NO_ERROR,              // exit code
        45000))                // wait hint
        goto cleanup;


    // Export bindings to NameService

	if (gdwOSPlatformId == VER_PLATFORM_WIN32_NT)
	{
	    status = RpcNsBindingExport(fNameSyntaxType,  // name syntax type
	                                pszEntryName,     // nsi entry name
	                                DIST_COMP_S_IF_SPEC,
	                                pBindingVector,   // set in previous call
	                                NULL);            // UUID vector 
		if (status != RPC_S_OK)
		{
			Eprintf(TEXT("RpcNsBindingExport failed: error code %d\n"), status);
	        goto cleanup;
		}
	    else 
		{
	        bExported = TRUE;
		}
	}

    if (!ReportStatusToSCMgr(
        SERVICE_START_PENDING, // service state
        NO_ERROR,              // exit code
        30000))                 // wait hint
        goto cleanup;
 

    // Register interface with the RPC run-time library

	status = RpcServerRegisterIf(DIST_COMP_S_IF_SPEC, // interface to register
	                             NULL,   // MgrTypeUuid
	                             NULL);  // MgrEpv; null means use default
	if (status != RPC_S_OK)
	{
		Eprintf(TEXT("RpcServerRegisterIf failed: error code %d\n"), status);
        goto cleanup;
	}
	else
	{
	    bRegistered = TRUE;
	}


	// Start up the performance-monitoring processing thread, if enabled in
	// registry

	if (gdwPerfMonEna)
	{
	 	status = StartPerfMonThread();
	    if(status) 
	    {
	        Eprintf(TEXT("Failed to start PerfMon thread\n"));
	    }
	}


	// Start up message box allowing the user to terminate the server
	// (debug mode only)

	if (bDebug)
	{
		hMessageBox = CreateThread(NULL, 0, MessageBoxThread, NULL, 0,
															&dwIDMessageBox);
		if (hMessageBox == NULL)
	    {
	        Eprintf(TEXT("Failed to start Message Box thread\n"));
	        goto cleanup;
	    }
	}

    // Prepare to start listening.  At this point the service is initialized

    if (!ReportStatusToSCMgr(
        SERVICE_RUNNING, // service state
        NO_ERROR,        // exit code
        0))              // wait hint
        goto cleanup;


    Eprintf( TEXT("Listening for requests\n"));
    status = RpcServerListen(cMinCalls,
                             cMaxCalls,
                             fDontWait );  // wait flag
	if (status != RPC_S_OK)
	{
		Eprintf(TEXT("RpcServerListen failed: error code %d\n"), status);
        goto cleanup;
	}

    if (fDontWait) {
        Eprintf(TEXT("Calling RpcMgmtWaitServerListen\n"));
        status = RpcMgmtWaitServerListen();  //  wait operation
        Eprintf(TEXT("RpcMgmtWaitServerListen returned: 0x%x\n"), status);
    }


  cleanup:

    if ( bExported )
    {
        ReportStatusToSCMgr(
            SERVICE_STOP_PENDING,  // service state
            NO_ERROR,              // exit code
            3000);                 // wait hint  

        temp_status = RpcNsBindingUnexport(RPC_C_NS_SYNTAX_DEFAULT,  // name syntax type
                                           pszEntryName,     // nsi entry name
                                           DIST_COMP_S_IF_SPEC,
                                           NULL);            // UUID vector 
		if (temp_status != RPC_S_OK)
		{
			Eprintf(TEXT("RpcNsBindingUnexport returned error code %d\n"), status);
		}
    }


    if ( bEndpoint )
    {
        ReportStatusToSCMgr(
            SERVICE_STOP_PENDING,  // service state
            NO_ERROR,              // exit code
            3000);                 // wait hint  

        temp_status = RpcEpUnregister(DIST_COMP_S_IF_SPEC,
                                      pBindingVector,
                                      NULL);
		if (temp_status != RPC_S_OK)
		{
			Eprintf(TEXT("RpcEpUnregister returned error code %d\n"), status);
		}
    }

    if ( pBindingVector )
    {
        ReportStatusToSCMgr(
            SERVICE_STOP_PENDING,  // service state
            NO_ERROR,              // exit code
            3000);                 // wait hint  

        temp_status = RpcBindingVectorFree(&pBindingVector);
		if (temp_status != RPC_S_OK)
		{
			Eprintf(TEXT("RpcBindingVectorFree returned error code %d\n"), status);
		}
    }
    
    if ( bRegistered )
    {
        ReportStatusToSCMgr(
            SERVICE_STOP_PENDING,  // service state
            NO_ERROR,              // exit code
            3000);                 // wait hint  


        temp_status = RpcServerUnregisterIf(DIST_COMP_S_IF_SPEC, // interface to register
                                     NULL,   // MgrTypeUuid
                                     1);     // wait for outstanding calls
		if (temp_status != RPC_S_OK)
		{
			Eprintf(TEXT("RpcServerUnregisterIf returned error code %d\n"), status);
		}
    }

    ReportStatusToSCMgr(
        SERVICE_STOP_PENDING,  // service state
        NO_ERROR,              // exit code
        3000);                 // wait hint  
}


//
//  FUNCTION: ServiceStop
//
//  PURPOSE:
//    stop the service in response to a message from the Service Manager
//
//  PARAMETERS:
//
//  RETURN VALUE:
//
//  COMMENTS:
//

void ServiceStop(void)
{
    RPC_STATUS status;

    ReportStatusToSCMgr(
        SERVICE_STOP_PENDING,  // service state
        NO_ERROR,              // exit code
        3000);                 // wait hint

    status = RpcMgmtIsServerListening( NULL );
	if (status != RPC_S_OK)
	{
		Eprintf(TEXT("RpcServerUnregisterIf returned error code %d\n"), status);
	}

    if ( status == RPC_S_OK )
        RpcMgmtStopServerListening( NULL );
        
}


//
//  FUNCTION: StartPerfMonThread
//
//  PURPOSE:
//    spin off a thread (running CodePerfMonStartcLoop()) to do performance
//    monitoring
//
//  PARAMETERS:
//
//  RETURN VALUE:
//
//  COMMENTS:
//    Input and output queues are serviced by RPC calls from the client.
//


RPC_STATUS StartPerfMonThread(void)
{
	// create the PerfMon thread

	hPerfMon = CreateThread(NULL, 0, PerfMonStart, NULL, 0, &dwIDPerfMon);
	
	return(hPerfMon == NULL ? 1 : 0);
}


//
//  FUNCTION: MessageBoxThread
//
//  PURPOSE:
//    display a message box allowing the user to terminate the server in debug
//    mode
//
//  PARAMETERS:
//
//  RETURN VALUE:
//
//  COMMENTS:
//    If the MessageBox returns for any reason, the server is terminated. 
//

DWORD WINAPI MessageBoxThread(LPVOID dummy)
{
	MessageBox
	(
		NULL,
		TEXT("Click on 'OK' when you want to stop \n")
		TEXT("the Distributed Compression Server  "),
		TEXT("DComp Server Stop Button"), 
		MB_OK | MB_ICONEXCLAMATION
	);

   ServiceStop();
   return(0);
}


//
//  FUNCTION: GetHardwareInfo
//
//  PURPOSE:
//    get information about the hardware configuration of the local computer
//
//  PARAMETERS:
//
//  RETURN VALUE:
//
//  COMMENTS:
//    The system information is placed in the global SYSTEM_INFO structure
//    gsiSysInfo.  Also the number of active processors is placed in global
//    gdwNumActiveProcessors
//

void		GetHardwareInfo(void)
{
	DWORD		l;
	DWORD		dwMask;


	// Display the "hardware information" header

	Dprintf(TEXT("Hardware information:\n"));


	// Copy the hardware information to the SYSTEM_INFO structure

	GetSystemInfo(&gsiSysInfo);


	// Count the active processors

	gdwNumActiveProcessors = 0;
	for (l = 0, dwMask = 1;
						l < gsiSysInfo.dwNumberOfProcessors; l++, dwMask <<= 1)
	{
		if (gsiSysInfo.dwActiveProcessorMask & dwMask)
		{
			gdwNumActiveProcessors += 1;
		}
	}


	// Display the contents of the SYSTEM_INFO structure

	Dprintf(
		TEXT("OEM ID: %u\n")
		TEXT("Number of Processors: %u\n")
		TEXT("Page size: %u\n")
		TEXT("Processor Type: %u\n")
		TEXT("Minimum app address: %lx\n")
		TEXT("Maximum app address: %lx\n")
		TEXT("Active processor mask: %u\n")
		TEXT("Allocation Granularity: %u\n")
		TEXT("Number of active processors: %u\n"),
		gsiSysInfo.dwOemId,
		gsiSysInfo.dwNumberOfProcessors,
		gsiSysInfo.dwPageSize,
		gsiSysInfo.dwProcessorType,
		gsiSysInfo.lpMinimumApplicationAddress,
		gsiSysInfo.lpMaximumApplicationAddress,
		gsiSysInfo.dwActiveProcessorMask,
		gsiSysInfo.dwAllocationGranularity,
		gdwNumActiveProcessors);
}


