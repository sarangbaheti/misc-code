/* THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
 * ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
 * PARTICULAR PURPOSE.
 *
 * Copyright (C) 1994  Microsoft Corporation.  All Rights Reserved.
 *
 *  MODULE:   funcs_s.c
 *
 *  PURPOSE:
 *    general-purpose functions for the distributed recompression server
 *
 *  FUNCTIONS:
 *    midl_user_allocate(size_t len)
 *    midl_user_free(void __RPC_FAR * ptr)
 *    Eprintf(LPTSTR szFmt, ...)
 *    Dprintf(LPTSTR szFmt, ...)
 *    RPCControl(handle_t hHandle, LONG lCommand)
 *    DispMemStatus(void)
 *    ClearDown(LPVOID *Buf)
 *    GetOSPlatformId(void)
 *    DisplaySid(PSID psid)
 *    ShowCurrentUserTokenInfo(void)
 *    InitializeSecurityDiagnostics(void)
 *    CreateEndpointSD(void)
 *    FreeEndpointSD(PSECURITY_DESCRIPTOR pAbsSD)
 *    ConvKeyACLToPipeACL(PACL pACL)
 *    GetAppBaseName(LPSTR *lplpszName, LPWSTR *lplpwszName)
 *
 *  COMMENTS:
 */

#include	"dcomp.h"
#include	"dcomps.h"


//
//  FUNCTION: midl_user_allocate
//
//  PURPOSE: memory allocation routine for the application 
//
//  PARAMETERS:
//    len - size of memory block to allocate, in bytes
//
//  RETURN VALUE:
//    Pointer to the allocated space, or NULL if the requested memory could not
//    be allocated
//
//  COMMENTS:
//    Required by RPC
//

void __RPC_FAR * __RPC_USER midl_user_allocate(size_t len)
{
	void __RPC_FAR * __RPC_USER ptr;

	if ((ptr = LocalAlloc(LMEM_FIXED, len)) == NULL)
	{
		Eprintf(TEXT("Server couldn't allocate %u bytes\n"), len, ptr);
	}
	else
	{
		Dprintf(TEXT("Server allocated %u bytes at 0x%08.8lx\n"), len, ptr);
	}
	return(ptr);
}


//
//  FUNCTION: midl_user_free
//
//  PURPOSE: memory free routine for the application 
//
//  PARAMETERS:
//    ptr - pointer to the memory block to be freed
//
//  RETURN VALUE:
//
//  COMMENTS:
//    Required by RPC
//

void __RPC_USER midl_user_free(void __RPC_FAR * ptr)
{
	if (LocalFree(ptr) == NULL)
	{
		Dprintf(TEXT("Server freed memory at 0x%08.8lx\n"), ptr);
	}
	else
	{
		Eprintf(
			TEXT("Server couldn't free memory at 0x%08.8lx: error code %lu\n"),
														ptr, GetLastError());
	}
}


//
//  FUNCTION: Eprintf
//
//  PURPOSE: formatted print to standard error
//
//  PARAMETERS:
//    As for printf
//
//  RETURN VALUE:
//    As for printf
//
//  COMMENTS:
//    Critical section csStderr is used to serialise access to stderr
//

int			Eprintf(LPTSTR szFmt, ...)
{
	int			retval;
	va_list		vl;

	EnterCriticalSection(&csStderr);
	va_start(vl, szFmt);
	retval = _vftprintf(stderr, szFmt, vl);
	va_end(vl);
	fflush(stderr);
	LeaveCriticalSection(&csStderr);
	return(retval);
}


//
//  FUNCTION: Dprintf
//
//  PURPOSE: debug formatted print to standard error
//
//  PARAMETERS:
//    As for printf
//
//  RETURN VALUE:
//    As for printf
//
//  COMMENTS:
//    Only prints if global flag gfDebug is TRUE (non-zero).
//    Critical section csStderr is used to serialise access to stderr.
//

int			Dprintf(LPTSTR szFmt, ...)
{
	int			retval = 0;
	va_list		vl;

	if (gfDebug)
	{
		EnterCriticalSection(&csStderr);
		va_start(vl, szFmt);
		retval = _vftprintf(stderr, szFmt, vl);
		va_end(vl);
		fflush(stderr);
		LeaveCriticalSection(&csStderr);
	}
	return(retval);
}


//
//  FUNCTION: RPCControl
//
//  PURPOSE: multi-purpose RPC call allowing client to control server
//
//  PARAMETERS:
//    hHandle  - RPC binding handle - unreferenced in this function
//    lCommand - specifies which command to execute
//
//  RETURN VALUE:
//    Depends on lCommand - normally zero for success, non-zero for error 
//
//  COMMENTS:
//

LONG RPCControl(handle_t hHandle, LONG lCommand)
{
    RPC_STATUS	status;

	if (gfDebug)
	{
		// Display the client's access token data for debug purposes

		status = RpcImpersonateClient(hHandle);
		if (status != RPC_S_OK)
		{
			Eprintf(TEXT("RpcImpersonateClient() failed: error code %d\n"),
																	status);
		}
		else
		{
			ShowCurrentUserTokenInfo();
		}

		status = RpcRevertToSelf();
		if (status != RPC_S_OK)
		{
			Eprintf(TEXT("RpcRevertToSelf() failed: error code %d\n"), status);
		}
	}

	// Perform the requested command

	switch(lCommand)
	{
		// Just used to see if server is present

		case RPCCTL_HELLO:
			return(RPCCTL_OK);

		// Clear down processing queues

		case RPCCTL_QUERYCPUS:
			return(gdwNumActiveProcessors);

		// Checkpoint and display local heap for debug purposes

		case RPCCTL_HEAPSTATUS:
			DispMemStatus();
			return(RPCCTL_OK);

		// Unknown command code

		default:
			return(RPCCTL_UNKNOWN);
			break;
	}
}


//
//  FUNCTION: DispMemStatus
//
//  PURPOSE: heap display routine for debugging only
//
//  PARAMETERS:
//
//  RETURN VALUE:
//
//  COMMENTS:
//
			
void		DispMemStatus(void)
{
	HANDLE				hProcHeap;
	PROCESS_HEAP_ENTRY	entry;
	size_t				stTotal;
	static size_t		stPrev = 0UL;
	DWORD				dwStatus;


	if ((hProcHeap = GetProcessHeap()) == NULL)
	{
		Eprintf(TEXT("DispMemStatus(): Couldn't get process heap handle\n"));
	}

	if (!HeapLock(hProcHeap))
	{
		Eprintf(TEXT("DispMemStatus(): Couldn't lock process heap\n"));
	}

	EnterCriticalSection(&csStderr);
 	Eprintf(TEXT("\nHeap:\n"));
	stTotal = 0UL;

	entry.lpData = NULL;
	while (HeapWalk(hProcHeap, &entry))
	{
		if ((entry.wFlags & PROCESS_HEAP_ENTRY_BUSY)
							&& !(entry.wFlags & PROCESS_HEAP_ENTRY_MOVEABLE))
		{
			Dprintf(
				TEXT("Address: %#08.8lx  Length: %10lu  Flags: 0x%08.8lx\n"),
									entry.lpData, entry.cbData, entry.wFlags);
			stTotal += entry.cbData;
		}
	}

	if ((dwStatus = GetLastError()) != ERROR_NO_MORE_ITEMS)
	{
		Eprintf(TEXT("Problem encountered walking heap: error code %lu\n"),
																	dwStatus);
	}
	else
	{
	 	Eprintf(TEXT("\nTotal: %lu  Change: %+ld\n\n"),
	 							stTotal, (signed) stTotal - (signed) stPrev);
		stPrev = stTotal;
	}

	if (!HeapUnlock(hProcHeap))
	{
		Eprintf(
			TEXT("DispMemStatus(): Couldn't error unlocking process heap\n"));
	}

	LeaveCriticalSection(&csStderr);
}


//
//  FUNCTION: ClearDown
//
//  PURPOSE:
//    free memory pointed to by input pointer (if non-NULL), and set pointer
//    to NULL
//
//  PARAMETERS:
//    Buf - pointer to pointer to memory to be freed
//
//  RETURN VALUE:
//
//  COMMENTS:
//

void		ClearDown(LPVOID *Buf)
{
	Dprintf(TEXT("ClearDown - 0x%08.8lx->0x%08.8lx\n"), Buf, *Buf);
	if (*Buf != NULL)
	{
		midl_user_free(*Buf);
		Dprintf(TEXT("ClearDown - freed memory at 0x%08.8lx\n"), *Buf);
		*Buf = NULL;
	}
}


//
//  FUNCTION: GetOSPlatformId
//
//  PURPOSE: Get current operating system platform ID from system
//
//  PARAMETERS:
//
//  RETURN VALUE:
//    Platform ID if successful
//	  	  -1      if unsuccessful
//
//  COMMENTS:
//	  Platform IDs defined include:
//
//		Value						Platform
//
//		VER_PLATFORM_WIN32s			Win32s on Windows 3.1 
//		VER_PLATFORM_WIN32_WINDOWS	Win32 on Chicago
//		VER_PLATFORM_WIN32_NT		Windows NT 
//

DWORD		GetOSPlatformId(void)
{
	OSVERSIONINFO	osversioninfo;

	osversioninfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	if (!GetVersionEx(&osversioninfo))
	{
		Eprintf(TEXT("Couldn't get operating system version info\n"));
		return((DWORD) -1);
	}

	Dprintf(TEXT("Operating system platform ID is %lu\n"),
												osversioninfo.dwPlatformId);

	return(osversioninfo.dwPlatformId);
}


//
//  FUNCTION: DisplaySid
//
//  PURPOSE: display a Security Identifier (SID) for debugging
//
//  PARAMETERS:
//    psid - Points to the SID structure to display
//
//  RETURN VALUE:
//
//  COMMENTS:
//

void		DisplaySid(PSID psid)
{
	int			i;

	if(IsValidSid(psid))
	{
		EnterCriticalSection(&csStderr);
		Eprintf(TEXT("S-%u"), ((PISID) psid)->Revision);
		Eprintf(TEXT("-%d"), ((PISID) psid)->IdentifierAuthority.Value[5]);
		for (i = 0; i < ((PISID) psid)->SubAuthorityCount; i++)
		{
			Eprintf(TEXT("-%lu"), ((PISID) psid)->SubAuthority[i]);
		}
		LeaveCriticalSection(&csStderr);
	}
}


//
//  FUNCTION: ShowCurrentUserTokenInfo
//
//  PURPOSE: display the information from the current thread's access token
//
//  PARAMETERS:
//
//  RETURN VALUE:
//
//  COMMENTS:
//

void		ShowCurrentUserTokenInfo(void)
{
	HANDLE		htkThread;


	// First we must open a handle to the access token for this thread.

	if (!OpenThreadToken(GetCurrentThread(), TOKEN_QUERY, FALSE, &htkThread))
	{
		if (GetLastError() == ERROR_NO_TOKEN)
		{
			// If the thread does not have an access token, we'll examine the
			// access token associated with the process.

			if (!OpenProcessToken(GetCurrentProcess(),
													TOKEN_QUERY, &htkThread))
			{
				Eprintf(
					TEXT("Failed to get current thread token")
					TEXT(" or current process token\n"));
				return;
			}
		}
		else
		{
			Eprintf(TEXT("Failed to get current thread token\n"));
			return;
		}
	}

	ExamineAccessToken(htkThread);
}


//
//  FUNCTION: InitializeSecurityDiagnostics
//
//  PURPOSE:
//    initialize environment for security diagnostics from the check_sd sample
//
//  PARAMETERS:
//
//  RETURN VALUE:
//
//  COMMENTS:
//

void		InitializeSecurityDiagnostics(void)
{
   /**************************************************************************\
   *
   * Set up the well-known SID(s) in global variables, and enable the privilege
   *   needed in the access token to work with SACL(s)
   *
   \**************************************************************************/

	InitializeWellKnownSIDs();

	SetPrivilegeInAccessToken();
}


//
//  FUNCTION: CreateEndpointSD
//
//  PURPOSE: create default security descriptor to control access the LPC and
//    named pipe endpoints
//
//  PARAMETERS:
//
//  RETURN VALUE:
//    Pointer to a security descriptor, or NULL on failure.
//
//  COMMENTS:
//    N.B. CreateEndpointSD creates ACE's using standard permissions for
//    registry keys.  These are not adequate as named pipe permissions, so they
//    are re-mapped elsewhere as file/pipe permissions, using
//    ConvKeyACLToPipeACL.  See also GetKeyDACLSD.
//
//    CreateEndpointSD allocates memory for the security descriptor.  Caller
//    should free it using FreeEndpointSD.
//

PSECURITY_DESCRIPTOR	CreateEndpointSD(void)
{
	PSECURITY_DESCRIPTOR	pSD;
	PSID					psidGuests      = NULL;
	PSID					psidAdmins      = NULL;
	PSID					psidEveryone    = NULL;
	PACL					paclEndpoint    = NULL;
	DWORD					dwCode;

	SID_IDENTIFIER_AUTHORITY	SystemSidAuthority = SECURITY_NT_AUTHORITY;
	SID_IDENTIFIER_AUTHORITY	WorldSidAuthority
												= SECURITY_WORLD_SID_AUTHORITY;


    pSD = (PSECURITY_DESCRIPTOR) midl_user_allocate(
    										SECURITY_DESCRIPTOR_MIN_LENGTH);
    if (pSD == NULL)
	{
	    Eprintf(TEXT("Couldn't allocate memory for security descriptor\n"));
        goto clean_up_after_failure;
	}

    if (!InitializeSecurityDescriptor(pSD, SECURITY_DESCRIPTOR_REVISION))
	{
		dwCode = GetLastError();
		Eprintf(
			TEXT("InitializeSecurityDescriptor failed,")
			TEXT(" error code %lu(0x%08.8lx)\n"),
			dwCode, dwCode);
        goto clean_up_after_failure;
	}


	// Start with a System Identifier (SID) to represent
	// the Guests group.

	if (!AllocateAndInitializeSid
	      (&SystemSidAuthority, 2, SECURITY_BUILTIN_DOMAIN_RID,
	                               DOMAIN_ALIAS_RID_GUESTS,
	                               0, 0, 0, 0, 0, 0,
	                               &psidGuests
	      )
	  )
	  goto security_failure;


	// Here we're creating a System Identifier (SID) to represent
	// the Admin group.

	if (!AllocateAndInitializeSid
	      (&SystemSidAuthority, 2, SECURITY_BUILTIN_DOMAIN_RID,
	                               DOMAIN_ALIAS_RID_ADMINS,
	                               0, 0, 0, 0, 0, 0,
	                               &psidAdmins
	      )
	  )
	  goto security_failure;


	// Now we'll construct a System Identifier which represents
	// all users.

	if (!AllocateAndInitializeSid
	      (&WorldSidAuthority, 1, SECURITY_WORLD_RID,
	       0, 0, 0, 0, 0, 0, 0,
	       &psidEveryone
	      )
	  )
	  goto security_failure;

	if (!InitializeSecurityDescriptor(pSD,
	                                 SECURITY_DESCRIPTOR_REVISION1
	                                )
	  )
	  goto security_failure;

	// Finally we must allocate and construct the discretionary
	// access control list (DACL) for the key.

	if (!(paclEndpoint = (PACL) midl_user_allocate(ACL_BUFFER_SIZE)))
	  goto memory_limited;

	if (!InitializeAcl(paclEndpoint, ACL_BUFFER_SIZE, ACL_REVISION2))
	  goto security_failure;

	// Our DACL will contain two access control entries (ACEs), one which
	// allows members of the Admin group complete access to the key and one
	// which gives read access to everyone.

	if (!AddAccessDeniedAce(paclEndpoint, ACL_REVISION2, KEY_ALL_ACCESS,
																psidGuests))
	  goto security_failure;

	if (!AddAccessAllowedAce(paclEndpoint, ACL_REVISION2, KEY_ALL_ACCESS,
																psidAdmins))
	  goto security_failure;

	if (!AddAccessAllowedAce(paclEndpoint, ACL_REVISION2, KEY_READ,
																psidEveryone))
	  goto security_failure;

	// We must bind this DACL to the security descriptor...

	if (!SetSecurityDescriptorDacl(pSD, TRUE, paclEndpoint, FALSE))
	  goto security_failure;


	// Success

	return(pSD);



memory_limited:
							 
	Eprintf(TEXT("Memory Limit -- Cannot complete this operation!\n"));
	goto clean_up_after_failure;

security_failure:

	Eprintf(TEXT("Security error during service startup, error code %lu\n"),
															GetLastError());

clean_up_after_failure:

	if (psidGuests     ) FreeSid(psidGuests     );
	if (psidAdmins     ) FreeSid(psidAdmins     );
	if (psidEveryone   ) FreeSid(psidEveryone   );

	if (pSD         ) midl_user_free(pSD         );
	if (paclEndpoint) midl_user_free(paclEndpoint);

	return(NULL);
}


//
//  FUNCTION: FreeEndpointSD
//
//  PURPOSE: frees a security descriptor previously allocated by using the
//    CreateEndpointSD function
//
//  PARAMETERS:
//    pSecDesc - Points to the SD to free. 
//
//  RETURN VALUE:
//
//  COMMENTS:
//    Assumes only the DACL component of the SD has a dynamically-allocated
//    buffer
//

void		FreeEndpointSD(PSECURITY_DESCRIPTOR pAbsSD)
{
	PACL	pACL;
	BOOL	fDaclPresent;
	BOOL	fDaclDefaulted;

	if (!GetSecurityDescriptorDacl(pAbsSD, &fDaclPresent, &pACL,
															&fDaclDefaulted))
	{
		Eprintf(TEXT("GetSecurityDescriptorDacl failed, error code %lu\n"),
															GetLastError());
	}

	if (fDaclPresent)
	{
		midl_user_free(pACL);
	}

	if (pAbsSD) midl_user_free(pAbsSD);
}


//
//  FUNCTION: ConvKeyACLToPipeACL
//
//  PURPOSE: converts the permissions in a registry key ACL to equivalent
//    permissions for a named pipe
//
//  PARAMETERS:
//    pACL - pointer to the ACL
//
//  RETURN VALUE:
//    Non-zero on success
//    Zero     on failure for any reason
//
//  COMMENTS:
//    In this sample code, the required security for the server's endpoints is
//    stored on a registry key so it can conveniently be edited with the
//    registry editor utility.  However, keys do not have enough access mask
//    bits defined to create a suitable mask for a named pipe.  In Windows NT,
//    pipes are treated as files for security purposes.
//
//    The access mask of each ACE in the ACL is converted as follows:
//        If the access mask is exactly equal to KEY_ALL_ACCESS,
//            the mask is set to FILE_ALL_ACCESS
//            (Note: this applies for all ACE types - these permisions may be
//             being allowed, denied, audited etc. )
//
//        Otherwise,
//            the mask is set to (FILE_GENERIC_READ | FILE_GENERIC_WRITE) and
//            the ACE type is set to ACCESS_ALLOWED_ACE_TYPE.
//
//    You can control access to the server by setting the permissions on the as
//    follows: use the Security/Permissions dialog of the registry editor to
//    edit the permissions of the
//
//        System\CurrentControlSet\Services\DCompService\UserPermissions
//
//    in the HKEY_LOCAL_MACHINE tree.
//        You MUST give use Full Control permission (KEY_ALL_ACCESS) to the
//            Administrators group of the local machine: this is how the
//            LocalSystem account gets permission to create the named pipe.
//        To deny access to a user or group, highlight the name and select
//            Special Access from the Type of Access list.  In the Special
//            Access dialog, make sure none of the check-boxes are checked.
//        To allow users or groups to use the server, give them Read
//            permission.
//

BOOL		ConvKeyACLToPipeACL(PACL pACL)
{
	DWORD			dwAceIndex = 0;
	PACE_HEADER		lpvAceHdr;
	PACCESS_MASK	lpAccessMask;

	while (GetAce(pACL, dwAceIndex++, &lpvAceHdr))
	{
		// This switch statement is a bit unnecessary since all the known types
		// of ACE currently have the same shape

		switch(lpvAceHdr->AceType)
		{
			case ACCESS_ALLOWED_ACE_TYPE:
				lpAccessMask = &((PACCESS_ALLOWED_ACE) lpvAceHdr)->Mask;
				break;

			case ACCESS_DENIED_ACE_TYPE:
				lpAccessMask = &((PACCESS_DENIED_ACE) lpvAceHdr)->Mask;
				break;

			case SYSTEM_AUDIT_ACE_TYPE:
				lpAccessMask = &((PSYSTEM_AUDIT_ACE) lpvAceHdr)->Mask;
				break;

			case SYSTEM_ALARM_ACE_TYPE:
				lpAccessMask = &((PSYSTEM_ALARM_ACE) lpvAceHdr)->Mask;
				break;

			default:
				Eprintf(TEXT("Unknown ACE type %u in ConvKeyACLToPipeACL\n"),
														lpvAceHdr->AceType); 
				return(FALSE);
		}

		Dprintf(TEXT("ACE %lu: Access mask 0x%08.8lx\n"),
												dwAceIndex - 1, *lpAccessMask);

		if (*lpAccessMask == KEY_ALL_ACCESS)
		{
			*lpAccessMask = FILE_ALL_ACCESS;
		}
		else
		{
			*lpAccessMask = (FILE_GENERIC_READ | FILE_GENERIC_WRITE);
			lpvAceHdr->AceType = ACCESS_ALLOWED_ACE_TYPE;
		}
	}

	if (GetLastError() != ERROR_INVALID_PARAMETER)
	{
		Eprintf(TEXT("Error %lu in ConvKeyACLToPipeACL\n"), GetLastError()); 
		return(FALSE);
	}

	return(TRUE);
}


//
//  FUNCTION: GetAppBaseName
//
//  PURPOSE:
//    get the name of the executable file out of which the current process
//    is running, in ANSI and UNICODE formats
//
//  PARAMETERS:
//    lplpszName  - address of pointer to a buffer to receive the ANSI version
//                  of the name
//    lplpwszName - address of pointer to a buffer to receive the UNICODE
//                  version of the name
//
//  RETURN VALUE:
//
//  COMMENTS:
//    The strings found contain the part of the filename before the dot, and
//    without any path specification, and have the same case as the real file
//    in the file system.  This is important as these strings are used for
//    finding performance-monitoring counter instances for this process.
//
//    GetAppBaseName allocates memory needed for the name strings, and writes
//    the addresses of the strings into the pointer variables pointed to by the
//    function paramaters.
//
//    If either string is not required, set the relevant input parameter can
//    be NULL.
//

void		GetAppBaseName(LPSTR *lplpszName, LPWSTR *lplpwszName)
{
	CHAR		szPath[_MAX_PATH];
	CHAR		sz[_MAX_FNAME];
	LONG		lSizeOfWsz;

	GetModuleFileNameA(NULL, szPath, sizeof szPath);
	_splitpath(szPath, NULL, NULL, sz, NULL);

	if ((lplpszName != NULL)
				&& (*lplpszName = midl_user_allocate(strlen(sz) + 1)) != NULL)
	{
		strcpy(*lplpszName, sz);
	}

	lSizeOfWsz = (strlen(sz) + 1) * sizeof (WCHAR);

	if ((lplpwszName != NULL)
				&& (*lplpwszName = midl_user_allocate(lSizeOfWsz)) != NULL)
	{
		MultiByteToWideChar(CP_ACP, 0UL,
								sz, strlen(sz) + 1, *lplpwszName, lSizeOfWsz);
	}
}
