/* THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
 * ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
 * PARTICULAR PURPOSE.
 *
 * Copyright (C) 1993, 1994  Microsoft Corporation.  All Rights Reserved.
 *
 *  MODULE:   check_sd.c
 *
 *  Borrowed for the Distributed Compression sample from the check_sd sample.
 *  Used as a debug aid in displaying the security information of calling
 *  clients.
 */

/******************************************************************************\
*       This is a part of the Microsoft Source Code Samples.
*       This source code is only intended as a supplement to
*       Microsoft Development Tools and/or WinHelp documentation.
*       See these sources for detailed information regarding the
*       Microsoft samples programs.
\******************************************************************************/

/****************************************************************************\
*
* MODULE:       check_sd.c
*
*               In the Win32 .hlp file, if you click on Search, goto "Security
*                 Overview", then choose from the list of topics under
*                 Security Overview the sub-topic "Allowing Access", you'll
*                 find the comment
*
*                 Note:  It is fine to write code like this that builds
*                   security descriptors from scratch.  It is, however, a good
*                   practice for people who write code that builds or
*                   manipulates security descriptors to first write code that
*                   explores the default security descriptors that Windows NT
*                   places on objects.  For example, if Windows NT by default
*                   includes in a DACL an ACE granting the Local Logon SID
*                   certain access, it's good to know that, so that a decision
*                   not to grant any access to the Local Logon SID would be a
*                   conscious decision
*
* PURPOSE:      The comment in the .hlp file is accurate, however, for many
*                 people this task of examining the SD is easier if there is
*                 sample code to start from.  So, the purpose of this sample
*                 is to assist people by providing sample code people can
*                 start from as they examine SD(s).  This sample as is
*                 examines the SD on files, and this code can be modified to
*                 examine the SD on other objects
*
*               This sample is not a supported utility
*
* TO RUN:       Type Check_sd to check the SD on the \\.\A:  device
*
*               Type Check_sd d:\a.fil to check the SD on the d:\a.fil file.
*                 In this case d:  must be formatted NTFS, because only NTFS
*                 files have SD(s)
*
\****************************************************************************/

/****************************************************************************\
*  INCLUDES, DEFINES
\****************************************************************************/

#include	"dcomp.h"
#include	"dcomps.h"

#define PERR(api) Eprintf(TEXT("\n%s: Error %d from %s on line %d\n"),  \
    __FILE__, GetLastError(), api, __LINE__);
#define PMSG(msg) Eprintf(TEXT("\n%s line %d: %s\n"),  \
    __FILE__, __LINE__, msg);

/****************************************************************************\
* GLOBAL VARIABLES AND TYPEDEFS
\****************************************************************************/

typedef enum _KINDS_OF_ACCESSMASKS_DECODED {
    FileAccessMask,
    ProcessAccessMask,
    WindowStationAccessMask,
    RegKeyAccessMask,
    ServiceAccessMask,
    DefaultDaclInAccessTokenAccessMask
    } KINDS_OF_ACCESSMASKS_DECODED, * PKINDS_OF_ACCESSMASKS_DECODED;

// These hold the well-known SIDs

PSID psidNullSid;
PSID psidWorldSid;
PSID psidLocalSid;
PSID psidCreatorOwnerSid;
PSID psidCreatorGroupSid;
PSID psidNtAuthoritySid;
PSID psidDialupSid;
PSID psidNetworkSid;
PSID psidBatchSid;
PSID psidInteractiveSid;
PSID psidLogonIdsSid; // But the X and Y values are bogus at first!!! (See below)
PSID psidServiceSid;
PSID psidLocalSystemSid;
PSID psidBuiltinDomainSid;

/****************************************************************************\
* FUNCTION PROTOTYPES
\****************************************************************************/

VOID ExamineAccessToken(HANDLE hAccessToken);
BOOL ExamineSD    (PSECURITY_DESCRIPTOR psdSD,
                   KINDS_OF_ACCESSMASKS_DECODED kamKindOfMask);
BOOL ExamineACL   (PACL paclACL,              LPTSTR lpszOldIndent,
                   KINDS_OF_ACCESSMASKS_DECODED kamKindOfMask);
VOID ExamineMask  (ACCESS_MASK amMask,        LPTSTR lpszOldIndent,
                   KINDS_OF_ACCESSMASKS_DECODED kamKindOfMask);
BOOL LookupSIDName(PSID psidSID,              LPTSTR lpszOldIndent);
BOOL SIDStringName(PSID psidSID, LPTSTR lpszSIDStringName);
BOOL SetPrivilegeInAccessToken(VOID);
VOID InitializeWellKnownSIDs(VOID);
VOID DisplayHelp(VOID);





/****************************************************************************\
*
* FUNCTION: ExamineSD
*
\****************************************************************************/

BOOL ExamineSD    (PSECURITY_DESCRIPTOR psdSD,
                   KINDS_OF_ACCESSMASKS_DECODED kamKindOfMask)
{

  PACL                        paclDACL;
  PACL                        paclSACL;
  BOOL                        bHasDACL        = FALSE;
  BOOL                        bHasSACL        = FALSE;
  BOOL                        bDaclDefaulted  = FALSE;
  BOOL                        bSaclDefaulted  = FALSE;
  BOOL                        bOwnerDefaulted = FALSE;
  BOOL                        bGroupDefaulted = FALSE;
  PSID                        psidOwner;
  PSID                        psidGroup;
  SECURITY_DESCRIPTOR_CONTROL sdcSDControl;
  DWORD                       dwSDRevision;
  DWORD                       dwSDLength;

  if (!IsValidSecurityDescriptor(psdSD))
  { PERR("IsValidSecurityDescriptor");
    return(FALSE);
  }

  dwSDLength = GetSecurityDescriptorLength(psdSD);

  if (!GetSecurityDescriptorDacl(psdSD,
                                 (LPBOOL)&bHasDACL,
                                 (PACL *)&paclDACL,
                                 (LPBOOL)&bDaclDefaulted))
  { PERR("GetSecurityDescriptorDacl");
    return(FALSE);
  }

  if (!GetSecurityDescriptorSacl(psdSD,
                                 (LPBOOL)&bHasSACL,
                                 (PACL *)&paclSACL,
                                 (LPBOOL)&bSaclDefaulted))
  { PERR("GetSecurityDescriptorSacl");
    return(FALSE);
  }

  if (!GetSecurityDescriptorOwner(psdSD,
                                  (PSID *)&psidOwner,
                                  (LPBOOL)&bOwnerDefaulted))
  { PERR("GetSecurityDescriptorOwner");
    return(FALSE);
  }

  if (!GetSecurityDescriptorGroup(psdSD,
                                  (PSID *)&psidGroup,
                                  (LPBOOL)&bGroupDefaulted))
  { PERR("GetSecurityDescriptorGroup");
    return(FALSE);
  }

  if (!GetSecurityDescriptorControl(psdSD,
                                    (PSECURITY_DESCRIPTOR_CONTROL)&sdcSDControl,
                                    (LPDWORD)&dwSDRevision))
  { PERR("GetSecurityDescriptorControl");
    return(FALSE);
  }

  Eprintf(TEXT("\nSD is valid.  SD is %d bytes long.  SD revision is %d == "),dwSDLength,dwSDRevision);

  switch (dwSDRevision)
  {
    case      SECURITY_DESCRIPTOR_REVISION1 :
    { Eprintf(TEXT("SECURITY_DESCRIPTOR_REVISION1"));
      break;
    }
    default :
    { Eprintf(TEXT("! SD Revision is an IMPOSSIBLE SD revision!!! Perhaps a new revision was added..."));
      return(FALSE);
    }
  }

  if (SE_SELF_RELATIVE & sdcSDControl)
    Eprintf(TEXT("\nSD is in self-relative format (all SDs returned by the system are)"));

  if (NULL == psidOwner)
  { Eprintf(TEXT("\nSD's Owner is NULL, so SE_OWNER_DEFAULTED is ignored"));
  }
  else
  { Eprintf(TEXT("\nSD's Owner is Not NULL"));
    if (bOwnerDefaulted )
    { Eprintf(TEXT("\nSD's Owner-Defaulted flag is TRUE"));
    }
    else
    { Eprintf(TEXT("\nSD's Owner-Defaulted flag is FALSE"));
    }
    if(!LookupSIDName(psidOwner,TEXT("")))
    { PERR("LookupSIDName failed");
    }
  }

  /**************************************************************************\
  *
  * The other use for psidGroup is for Macintosh client support
  *
  \**************************************************************************/

  if (NULL == psidGroup)
  { Eprintf(TEXT("\nSD's Group is NULL, so SE_GROUP_DEFAULTED is ignored"));
    Eprintf(TEXT("\nSD's Group being NULL is typical, GROUP in SD(s) is mainly for POSIX compliance"));
  }
  else
  { if (bGroupDefaulted)
    { Eprintf(TEXT("\nSD's Group-Defaulted flag is TRUE"));
    }
    else
    { Eprintf(TEXT("\nSD's Group-Defaulted flag is FALSE"));
    }
    if(!LookupSIDName(psidGroup,TEXT("")))
    { PERR("LookupSIDName failed");
    }
  }

  if   (SE_DACL_PRESENT & sdcSDControl)
  { Eprintf(TEXT("\nSD's DACL is Present"));
    if (bDaclDefaulted)
    { Eprintf(TEXT("\nSD's DACL-Defaulted flag is TRUE"));
    }
    else
    { Eprintf(TEXT("\nSD's DACL-Defaulted flag is FALSE"));
    }

    if (NULL == paclDACL)
    { Eprintf(TEXT("\nSD has a NULL DACL explicitly specified      (allows all access to Everyone)"));
      Eprintf(TEXT("\n    This does not apply to this SD, but for comparison,"));
      Eprintf(TEXT("\n    a non-NULL DACL pointer to a 0-length ACL allows  no access to   anyone"));
    }
    else if(!ExamineACL(paclDACL,TEXT(""),kamKindOfMask))
    {  PERR("ExamineACL failed");
    }
  }
  else
  { Eprintf(TEXT("\nSD's DACL is Not Present, so SE_DACL_DEFAULTED is ignored"));
    Eprintf(TEXT("\nSD has no DACL at all (allows all access to Everyone)"));
  }

  if   (SE_SACL_PRESENT & sdcSDControl)
  { Eprintf(TEXT("\nSD's SACL is Present"));
    if (bSaclDefaulted)
    { Eprintf(TEXT("\nSD's SACL-Defaulted flag is TRUE"));
    }
    else
    { Eprintf(TEXT("\nSD's SACL-Defaulted flag is FALSE"));
    }

    if (NULL == paclSACL)
    { Eprintf(TEXT("\nSD has a NULL SACL explicitly specified"));
    }
    else if(!ExamineACL(paclSACL,TEXT(""),kamKindOfMask))
    {  PERR("ExamineACL failed");
    }
  }
  else
  { Eprintf(TEXT("\nSD's SACL is Not Present, so SE_SACL_DEFAULTED is ignored"));
    Eprintf(TEXT("\nSD has no SACL at all (or we did not request to see it)"));
  }
}

/****************************************************************************\
*
* FUNCTION: ExamineACL
*
\****************************************************************************/

BOOL ExamineACL   (PACL paclACL,              LPTSTR lpszOldIndent,
                   KINDS_OF_ACCESSMASKS_DECODED kamKindOfMask)
{
  #define                          SZ_INDENT_BUF 80
  TCHAR                tcIndentBuf[SZ_INDENT_BUF] = TEXT("");
  ACL_SIZE_INFORMATION                      asiAclSize;
  ACL_REVISION_INFORMATION                  ariAclRevision;
  DWORD                dwBufLength;
  DWORD                dwAcl_i;
  ACCESS_ALLOWED_ACE   *paaAllowedAce;

  _tcscpy(tcIndentBuf,lpszOldIndent);
  _tcscat(tcIndentBuf,TEXT("  "));

  if (!IsValidAcl(paclACL))
  { PERR("IsValidAcl");
    return(FALSE);
  }

  dwBufLength = sizeof(asiAclSize);

  if (!GetAclInformation(paclACL,
                         (LPVOID)&asiAclSize,
                         (DWORD)dwBufLength,
                         (ACL_INFORMATION_CLASS)AclSizeInformation))
  { PERR("GetAclInformation");
    return(FALSE);
  }

  dwBufLength = sizeof(ariAclRevision);

  if (!GetAclInformation(paclACL,
                         (LPVOID)&ariAclRevision,
                         (DWORD)dwBufLength,
                         (ACL_INFORMATION_CLASS)AclRevisionInformation))
  { PERR("GetAclInformation");
    return(FALSE);
  }

  Eprintf(TEXT("\n%sACL has %d ACE(s), %d bytes used, %d bytes free"),tcIndentBuf,
     asiAclSize.AceCount,
     asiAclSize.AclBytesInUse,
     asiAclSize.AclBytesFree);

  Eprintf(TEXT("\n%sACL revision is %d == "),tcIndentBuf,ariAclRevision.AclRevision);

  switch (ariAclRevision.AclRevision)
  {
    case      ACL_REVISION1 :
    { Eprintf(TEXT("ACL_REVISION1"));
      break;
    }
    case      ACL_REVISION2 :
    { Eprintf(TEXT("ACL_REVISION2"));
      break;
    }
    default :
    { Eprintf(TEXT("\n%sACL Revision is an IMPOSSIBLE ACL revision!!! Perhaps a new revision was added..."),tcIndentBuf);
      return(FALSE);
    }
  }

  for (dwAcl_i = 0; dwAcl_i < asiAclSize.AceCount;  dwAcl_i++)
  {
    if (!GetAce(paclACL,
                dwAcl_i,
                (LPVOID *)&paaAllowedAce))
    { PERR("GetAce");
      return(FALSE);
    }

    Eprintf(TEXT("\n%sACE %d size %d"),tcIndentBuf,dwAcl_i,paaAllowedAce->Header.AceSize);

    { DWORD dwAceFlags = paaAllowedAce->Header.AceFlags;

      Eprintf(TEXT("\n%sACE %d flags 0x%.2x"),tcIndentBuf,dwAcl_i,dwAceFlags);

      if (dwAceFlags)
      {
        DWORD dwExtraBits;
        TCHAR tcIndentBitsBuf[SZ_INDENT_BUF] = TEXT("");

        _tcscpy(tcIndentBitsBuf,tcIndentBuf);
        _tcscat(tcIndentBitsBuf,TEXT("            "));

        if ((dwAceFlags  & OBJECT_INHERIT_ACE        ) == OBJECT_INHERIT_ACE        )
        { Eprintf(TEXT("\n%s0x01 OBJECT_INHERIT_ACE        "),tcIndentBitsBuf);
        }
        if ((dwAceFlags  & CONTAINER_INHERIT_ACE     ) == CONTAINER_INHERIT_ACE     )
        { Eprintf(TEXT("\n%s0x02 CONTAINER_INHERIT_ACE     "),tcIndentBitsBuf);
        }
        if ((dwAceFlags  & NO_PROPAGATE_INHERIT_ACE  ) == NO_PROPAGATE_INHERIT_ACE  )
        { Eprintf(TEXT("\n%s0x04 NO_PROPAGATE_INHERIT_ACE  "),tcIndentBitsBuf);
        }
        if ((dwAceFlags  & INHERIT_ONLY_ACE          ) == INHERIT_ONLY_ACE          )
        { Eprintf(TEXT("\n%s0x08 INHERIT_ONLY_ACE          "),tcIndentBitsBuf);
        }
        if ((dwAceFlags  & VALID_INHERIT_FLAGS       ) == VALID_INHERIT_FLAGS       )
        { Eprintf(TEXT("\n%s0x0F VALID_INHERIT_FLAGS       "),tcIndentBitsBuf);
        }
        if ((dwAceFlags  & SUCCESSFUL_ACCESS_ACE_FLAG) == SUCCESSFUL_ACCESS_ACE_FLAG)
        { Eprintf(TEXT("\n%s0x40 SUCCESSFUL_ACCESS_ACE_FLAG"),tcIndentBitsBuf);
        }
        if ((dwAceFlags  & FAILED_ACCESS_ACE_FLAG    ) == FAILED_ACCESS_ACE_FLAG    )
        { Eprintf(TEXT("\n%s0x80 FAILED_ACCESS_ACE_FLAG    "),tcIndentBitsBuf);
        }

        dwExtraBits = dwAceFlags & ( ~( OBJECT_INHERIT_ACE
                                      | CONTAINER_INHERIT_ACE
                                      | NO_PROPAGATE_INHERIT_ACE
                                      | INHERIT_ONLY_ACE
                                      | VALID_INHERIT_FLAGS
                                      | SUCCESSFUL_ACCESS_ACE_FLAG
                                      | FAILED_ACCESS_ACE_FLAG) );
        if (dwExtraBits)
        { Eprintf(TEXT("\n%sExtra AceFlag bits     == 0x%.8x <-This is a problem, should be all 0s"),tcIndentBuf,dwExtraBits);
        }
      }
    }

    switch (paaAllowedAce->Header.AceType)
    {
      case                       ACCESS_ALLOWED_ACE_TYPE :
      { Eprintf(TEXT("\n%sACE %d is an ACCESS_ALLOWED_ACE_TYPE"),tcIndentBuf,dwAcl_i);
        break;
      }
      case                       ACCESS_DENIED_ACE_TYPE :
      { Eprintf(TEXT("\n%sACE %d is an ACCESS_DENIED_ACE_TYPE"),tcIndentBuf,dwAcl_i);
        break;
      }
      case                       SYSTEM_AUDIT_ACE_TYPE :
      { Eprintf(TEXT("\n%sACE %d is a  SYSTEM_AUDIT_ACE_TYPE"),tcIndentBuf,dwAcl_i);
        break;
      }
      case                       SYSTEM_ALARM_ACE_TYPE :
      { Eprintf(TEXT("\n%sACE %d is a  SYSTEM_ALARM_ACE_TYPE"),tcIndentBuf,dwAcl_i);
        break;
      }
      default :
      { Eprintf(TEXT("\n%sACE %d is an IMPOSSIBLE ACE_TYPE!!! Run debugger, examine value!"),tcIndentBuf,dwAcl_i);
        return(FALSE);
      }
    }

    Eprintf(TEXT("\n%sACE %d mask               == 0x%.8x"),tcIndentBuf,dwAcl_i,paaAllowedAce->Mask);

    ExamineMask(paaAllowedAce->Mask,tcIndentBuf,kamKindOfMask);

    if(!LookupSIDName((PSID)&(paaAllowedAce->SidStart),tcIndentBuf))
    { PERR("LookupSIDName failed");
    }
  }
}

/****************************************************************************\
*
* FUNCTION: ExamineMask
*
\****************************************************************************/

VOID ExamineMask  (ACCESS_MASK amMask,        LPTSTR lpszOldIndent,
                   KINDS_OF_ACCESSMASKS_DECODED kamKindOfMask)
{
  #define STANDARD_RIGHTS_ALL_THE_BITS 0x00FF0000L
  #define GENERIC_RIGHTS_ALL_THE_BITS  0xF0000000L
  TCHAR tcIndentBuf[SZ_INDENT_BUF]     = TEXT("");
  TCHAR tcIndentBitsBuf[SZ_INDENT_BUF] = TEXT("");
  DWORD dwGenericBits;
  DWORD dwStandardBits;
  DWORD dwSpecificBits;
  DWORD dwAccessSystemSecurityBit;
  DWORD dwExtraBits;

  _tcscpy(tcIndentBuf,    lpszOldIndent);
  _tcscat(tcIndentBuf,    TEXT("  "));
  _tcscpy(tcIndentBitsBuf,lpszOldIndent);
  _tcscat(tcIndentBitsBuf,TEXT("                            "));

  dwStandardBits            = (amMask & STANDARD_RIGHTS_ALL_THE_BITS);
  dwSpecificBits            = (amMask & SPECIFIC_RIGHTS_ALL         );
  dwAccessSystemSecurityBit = (amMask & ACCESS_SYSTEM_SECURITY      );
  dwGenericBits             = (amMask & GENERIC_RIGHTS_ALL_THE_BITS );

  /**************************************************************************\
  *
  * Print then decode the standard rights bits
  *
  \**************************************************************************/

  Eprintf(TEXT("\n%sStandard Rights        == 0x%.8x"),tcIndentBuf,dwStandardBits);

  if (dwStandardBits)
  {
    if ((dwStandardBits    & DELETE                  ) == DELETE                  )
    { Eprintf(TEXT("\n%s0x00010000 DELETE                  "),tcIndentBitsBuf);
    }
    if ((dwStandardBits    & READ_CONTROL            ) == READ_CONTROL            )
    { Eprintf(TEXT("\n%s0x00020000 READ_CONTROL            "),tcIndentBitsBuf);
    }
    if ((dwStandardBits    & STANDARD_RIGHTS_READ    ) == STANDARD_RIGHTS_READ    )
    { Eprintf(TEXT("\n%s0x00020000 STANDARD_RIGHTS_READ    "),tcIndentBitsBuf);
    }
    if ((dwStandardBits    & STANDARD_RIGHTS_WRITE   ) == STANDARD_RIGHTS_WRITE   )
    { Eprintf(TEXT("\n%s0x00020000 STANDARD_RIGHTS_WRITE   "),tcIndentBitsBuf);
    }
    if ((dwStandardBits    & STANDARD_RIGHTS_EXECUTE ) == STANDARD_RIGHTS_EXECUTE )
    { Eprintf(TEXT("\n%s0x00020000 STANDARD_RIGHTS_EXECUTE "),tcIndentBitsBuf);
    }
    if ((dwStandardBits    & WRITE_DAC               ) == WRITE_DAC               )
    { Eprintf(TEXT("\n%s0x00040000 WRITE_DAC               "),tcIndentBitsBuf);
    }
    if ((dwStandardBits    & WRITE_OWNER             ) == WRITE_OWNER             )
    { Eprintf(TEXT("\n%s0x00080000 WRITE_OWNER             "),tcIndentBitsBuf);
    }
    if ((dwStandardBits    & SYNCHRONIZE             ) == SYNCHRONIZE             )
    { Eprintf(TEXT("\n%s0x00100000 SYNCHRONIZE             "),tcIndentBitsBuf);
    }
    if ((dwStandardBits    & STANDARD_RIGHTS_REQUIRED) == STANDARD_RIGHTS_REQUIRED)
    { Eprintf(TEXT("\n%s0x000F0000 STANDARD_RIGHTS_REQUIRED"),tcIndentBitsBuf);
    }
    if ((dwStandardBits    & STANDARD_RIGHTS_ALL     ) == STANDARD_RIGHTS_ALL     )
    { Eprintf(TEXT("\n%s0x001F0000 STANDARD_RIGHTS_ALL     "),tcIndentBitsBuf);
    }

    dwExtraBits = dwStandardBits & ( ~( DELETE
                                      | READ_CONTROL
                                      | STANDARD_RIGHTS_READ
                                      | STANDARD_RIGHTS_WRITE
                                      | STANDARD_RIGHTS_EXECUTE
                                      | WRITE_DAC
                                      | WRITE_OWNER
                                      | SYNCHRONIZE
                                      | STANDARD_RIGHTS_REQUIRED
                                      | STANDARD_RIGHTS_ALL) );
    if (dwExtraBits)
    { Eprintf(TEXT("\n%sExtra standard bits    == 0x%.8x <-This is a problem, should be all 0s"),tcIndentBuf,dwExtraBits);
    }
  }

  /**************************************************************************\
  *
  * Print then decode the specific rights bits
  *
  \**************************************************************************/

  Eprintf(TEXT("\n%sSpecific Rights        == 0x%.8x"),tcIndentBuf,dwSpecificBits);

  if (dwSpecificBits)
  {
    if      (FileAccessMask          == kamKindOfMask)
    {
      if ((dwSpecificBits    & FILE_READ_DATA           ) == FILE_READ_DATA           )
      { Eprintf(TEXT("\n%s0x00000001 FILE_READ_DATA            (file & pipe)     "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & FILE_LIST_DIRECTORY      ) == FILE_LIST_DIRECTORY      )
      { Eprintf(TEXT("\n%s0x00000001 FILE_LIST_DIRECTORY       (directory)       "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & FILE_WRITE_DATA          ) == FILE_WRITE_DATA          )
      { Eprintf(TEXT("\n%s0x00000002 FILE_WRITE_DATA           (file & pipe)     "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & FILE_ADD_FILE            ) == FILE_ADD_FILE            )
      { Eprintf(TEXT("\n%s0x00000002 FILE_ADD_FILE             (directory)       "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & FILE_APPEND_DATA         ) == FILE_APPEND_DATA         )
      { Eprintf(TEXT("\n%s0x00000004 FILE_APPEND_DATA          (file)            "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & FILE_ADD_SUBDIRECTORY    ) == FILE_ADD_SUBDIRECTORY    )
      { Eprintf(TEXT("\n%s0x00000004 FILE_ADD_SUBDIRECTORY     (directory)       "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & FILE_CREATE_PIPE_INSTANCE) == FILE_CREATE_PIPE_INSTANCE)
      { Eprintf(TEXT("\n%s0x00000004 FILE_CREATE_PIPE_INSTANCE (named pipe)      "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & FILE_READ_EA             ) == FILE_READ_EA             )
      { Eprintf(TEXT("\n%s0x00000008 FILE_READ_EA              (file & directory)"),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & FILE_WRITE_EA            ) == FILE_WRITE_EA            )
      { Eprintf(TEXT("\n%s0x00000010 FILE_WRITE_EA             (file & directory)"),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & FILE_EXECUTE             ) == FILE_EXECUTE             )
      { Eprintf(TEXT("\n%s0x00000020 FILE_EXECUTE              (file)            "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & FILE_TRAVERSE            ) == FILE_TRAVERSE            )
      { Eprintf(TEXT("\n%s0x00000020 FILE_TRAVERSE             (directory)       "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & FILE_DELETE_CHILD        ) == FILE_DELETE_CHILD        )
      { Eprintf(TEXT("\n%s0x00000040 FILE_DELETE_CHILD         (directory)       "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & FILE_READ_ATTRIBUTES     ) == FILE_READ_ATTRIBUTES     )
      { Eprintf(TEXT("\n%s0x00000080 FILE_READ_ATTRIBUTES      (all)             "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & FILE_WRITE_ATTRIBUTES    ) == FILE_WRITE_ATTRIBUTES    )
      { Eprintf(TEXT("\n%s0x00000100 FILE_WRITE_ATTRIBUTES     (all)             "),tcIndentBitsBuf);
      }

      if (((dwStandardBits | dwSpecificBits   )
           & FILE_ALL_ACCESS     ) == FILE_ALL_ACCESS     )
      { Eprintf(TEXT("\n%s0x001F01FF FILE_ALL_ACCESS      == (STANDARD_RIGHTS_REQUIRED | SYNCHRONIZE | 0x1FF)"),tcIndentBitsBuf);
      }
      if (((dwStandardBits | dwSpecificBits   )
           & FILE_GENERIC_READ   ) == FILE_GENERIC_READ   )
      { Eprintf(TEXT("\n%s0x00120089 FILE_GENERIC_READ    == (STANDARD_RIGHTS_READ | FILE_READ_DATA | FILE_READ_ATTRIBUTES | FILE_READ_EA | SYNCHRONIZE)"),tcIndentBitsBuf);
      }
      if (((dwStandardBits | dwSpecificBits   )
           & FILE_GENERIC_WRITE  ) == FILE_GENERIC_WRITE  )
      { Eprintf(TEXT("\n%s0x00120116 FILE_GENERIC_WRITE   == (STANDARD_RIGHTS_WRITE | FILE_WRITE_DATA | FILE_WRITE_ATTRIBUTES | FILE_WRITE_EA | FILE_APPEND_DATA | SYNCHRONIZE)"),tcIndentBitsBuf);
      }
      if (((dwStandardBits | dwSpecificBits   )
           & FILE_GENERIC_EXECUTE) == FILE_GENERIC_EXECUTE)
      { Eprintf(TEXT("\n%s0x001200A0 FILE_GENERIC_EXECUTE == (STANDARD_RIGHTS_EXECUTE | FILE_READ_ATTRIBUTES | FILE_EXECUTE | SYNCHRONIZE)"),tcIndentBitsBuf);
      }

      dwExtraBits = dwSpecificBits & ( ~( FILE_READ_DATA
                                        | FILE_LIST_DIRECTORY
                                        | FILE_WRITE_DATA
                                        | FILE_ADD_FILE
                                        | FILE_APPEND_DATA
                                        | FILE_ADD_SUBDIRECTORY
                                        | FILE_CREATE_PIPE_INSTANCE
                                        | FILE_READ_EA
                                        | FILE_WRITE_EA
                                        | FILE_EXECUTE
                                        | FILE_TRAVERSE
                                        | FILE_DELETE_CHILD
                                        | FILE_READ_ATTRIBUTES
                                        | FILE_WRITE_ATTRIBUTES
                                        | (FILE_ALL_ACCESS      & SPECIFIC_RIGHTS_ALL)
                                        | (FILE_GENERIC_READ    & SPECIFIC_RIGHTS_ALL)
                                        | (FILE_GENERIC_WRITE   & SPECIFIC_RIGHTS_ALL)
                                        | (FILE_GENERIC_EXECUTE & SPECIFIC_RIGHTS_ALL) ) );
      if (dwExtraBits)
      { Eprintf(TEXT("\n%sExtra specific bits    == 0x%.8x <-This is a problem, should be all 0s"),tcIndentBuf,dwExtraBits);
      }
    }
    else if (ProcessAccessMask       == kamKindOfMask)
    {
      if ((dwSpecificBits    & PROCESS_TERMINATE        ) == PROCESS_TERMINATE        )
      { Eprintf(TEXT("\n%s0x00000001 PROCESS_TERMINATE        "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & PROCESS_CREATE_THREAD    ) == PROCESS_CREATE_THREAD    )
      { Eprintf(TEXT("\n%s0x00000002 PROCESS_CREATE_THREAD    "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & PROCESS_VM_OPERATION     ) == PROCESS_VM_OPERATION     )
      { Eprintf(TEXT("\n%s0x00000008 PROCESS_VM_OPERATION     "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & PROCESS_VM_READ          ) == PROCESS_VM_READ          )
      { Eprintf(TEXT("\n%s0x00000010 PROCESS_VM_READ          "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & PROCESS_VM_WRITE         ) == PROCESS_VM_WRITE         )
      { Eprintf(TEXT("\n%s0x00000020 PROCESS_VM_WRITE         "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & PROCESS_DUP_HANDLE       ) == PROCESS_DUP_HANDLE       )
      { Eprintf(TEXT("\n%s0x00000040 PROCESS_DUP_HANDLE       "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & PROCESS_CREATE_PROCESS   ) == PROCESS_CREATE_PROCESS   )
      { Eprintf(TEXT("\n%s0x00000080 PROCESS_CREATE_PROCESS   "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & PROCESS_SET_INFORMATION  ) == PROCESS_SET_INFORMATION  )
      { Eprintf(TEXT("\n%s0x00000200 PROCESS_SET_INFORMATION  "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & PROCESS_QUERY_INFORMATION) == PROCESS_QUERY_INFORMATION)
      { Eprintf(TEXT("\n%s0x00000400 PROCESS_QUERY_INFORMATION"),tcIndentBitsBuf);
      }

      if (((dwStandardBits | dwSpecificBits )
           & PROCESS_ALL_ACCESS) == PROCESS_ALL_ACCESS)
      { Eprintf(TEXT("\n%s0x001F0FFF PROCESS_ALL_ACCESS == (STANDARD_RIGHTS_REQUIRED | SYNCHRONIZE | 0x00000FFF) "),tcIndentBitsBuf);
      }

      dwExtraBits = dwSpecificBits & ( ~( PROCESS_TERMINATE
                                        | PROCESS_CREATE_THREAD
                                        | PROCESS_VM_OPERATION
                                        | PROCESS_VM_READ
                                        | PROCESS_VM_WRITE
                                        | PROCESS_DUP_HANDLE
                                        | PROCESS_CREATE_PROCESS
                                        | PROCESS_SET_INFORMATION
                                        | PROCESS_QUERY_INFORMATION
                                        | (PROCESS_ALL_ACCESS & SPECIFIC_RIGHTS_ALL) ) );
      if (dwExtraBits)
      { Eprintf(TEXT("\n%sExtra specific bits    == 0x%.8x <-This is a problem, should be all 0s"),tcIndentBuf,dwExtraBits);
      }
    }
    else if (WindowStationAccessMask == kamKindOfMask)
    {
      if ((dwSpecificBits    & WINSTA_ENUMDESKTOPS     ) == WINSTA_ENUMDESKTOPS     )
      { Eprintf(TEXT("\n%s0x00000001 WINSTA_ENUMDESKTOPS     "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & WINSTA_READATTRIBUTES   ) == WINSTA_READATTRIBUTES   )
      { Eprintf(TEXT("\n%s0x00000002 WINSTA_READATTRIBUTES   "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & WINSTA_ACCESSCLIPBOARD  ) == WINSTA_ACCESSCLIPBOARD  )
      { Eprintf(TEXT("\n%s0x00000004 WINSTA_ACCESSCLIPBOARD  "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & WINSTA_CREATEDESKTOP    ) == WINSTA_CREATEDESKTOP    )
      { Eprintf(TEXT("\n%s0x00000008 WINSTA_CREATEDESKTOP    "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & WINSTA_WRITEATTRIBUTES  ) == WINSTA_WRITEATTRIBUTES  )
      { Eprintf(TEXT("\n%s0x00000010 WINSTA_WRITEATTRIBUTES  "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & WINSTA_ACCESSGLOBALATOMS) == WINSTA_ACCESSGLOBALATOMS)
      { Eprintf(TEXT("\n%s0x00000020 WINSTA_ACCESSGLOBALATOMS"),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & WINSTA_EXITWINDOWS      ) == WINSTA_EXITWINDOWS      )
      { Eprintf(TEXT("\n%s0x00000040 WINSTA_EXITWINDOWS      "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & WINSTA_ENUMERATE        ) == WINSTA_ENUMERATE        )
      { Eprintf(TEXT("\n%s0x00000100 WINSTA_ENUMERATE        "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & WINSTA_READSCREEN       ) == WINSTA_READSCREEN       )
      { Eprintf(TEXT("\n%s0x00000200 WINSTA_READSCREEN       "),tcIndentBitsBuf);
      }

      dwExtraBits = dwSpecificBits & ( ~( WINSTA_ENUMDESKTOPS
                                        | WINSTA_READATTRIBUTES
                                        | WINSTA_ACCESSCLIPBOARD
                                        | WINSTA_CREATEDESKTOP
                                        | WINSTA_WRITEATTRIBUTES
                                        | WINSTA_ACCESSGLOBALATOMS
                                        | WINSTA_EXITWINDOWS
                                        | WINSTA_ENUMERATE
                                        | WINSTA_READSCREEN) );
      if (dwExtraBits)
      { Eprintf(TEXT("\n%sExtra specific bits    == 0x%.8x <-This is a problem, should be all 0s"),tcIndentBuf,dwExtraBits);
      }
    }
    else if (RegKeyAccessMask        == kamKindOfMask)
    {
      if ((dwSpecificBits    & KEY_QUERY_VALUE       ) == KEY_QUERY_VALUE       )
      { Eprintf(TEXT("\n%s0x00000001 KEY_QUERY_VALUE       "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & KEY_SET_VALUE         ) == KEY_SET_VALUE         )
      { Eprintf(TEXT("\n%s0x00000002 KEY_SET_VALUE         "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & KEY_CREATE_SUB_KEY    ) == KEY_CREATE_SUB_KEY    )
      { Eprintf(TEXT("\n%s0x00000004 KEY_CREATE_SUB_KEY    "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & KEY_ENUMERATE_SUB_KEYS) == KEY_ENUMERATE_SUB_KEYS)
      { Eprintf(TEXT("\n%s0x00000008 KEY_ENUMERATE_SUB_KEYS"),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & KEY_NOTIFY            ) == KEY_NOTIFY            )
      { Eprintf(TEXT("\n%s0x00000010 KEY_NOTIFY            "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & KEY_CREATE_LINK       ) == KEY_CREATE_LINK       )
      { Eprintf(TEXT("\n%s0x00000020 KEY_CREATE_LINK       "),tcIndentBitsBuf);
      }

      if (((dwStandardBits | dwSpecificBits   )
           & KEY_READ      ) == KEY_READ      )
      { Eprintf(TEXT("\n%s0x00020019 KEY_READ       == ((STANDARD_RIGHTS_READ | KEY_QUERY_VALUE | KEY_ENUMERATE_SUB_KEYS | KEY_NOTIFY) & (~SYNCHRONIZE))"),tcIndentBitsBuf);
      }
      if (((dwStandardBits | dwSpecificBits   )
           & KEY_WRITE     ) == KEY_WRITE     )
      { Eprintf(TEXT("\n%s0x00020006 KEY_WRITE      == ((STANDARD_RIGHTS_WRITE | KEY_SET_VALUE | KEY_CREATE_SUB_KEY) & (~SYNCHRONIZE))"),tcIndentBitsBuf);
      }
      if (((dwStandardBits | dwSpecificBits   )
           & KEY_EXECUTE   ) == KEY_EXECUTE   )
      { Eprintf(TEXT("\n%s0x00020019 KEY_EXECUTE    == ((KEY_READ) & (~SYNCHRONIZE))"),tcIndentBitsBuf);
      }
      if (((dwStandardBits | dwSpecificBits   )
           & KEY_ALL_ACCESS) == KEY_ALL_ACCESS)
      { Eprintf(TEXT("\n%s0x000F003F KEY_ALL_ACCESS == ((STANDARD_RIGHTS_ALL | KEY_QUERY_VALUE | KEY_SET_VALUE | KEY_CREATE_SUB_KEY | KEY_ENUMERATE_SUB_KEYS | KEY_NOTIFY | KEY_CREATE_LINK) & (~SYNCHRONIZE))"),tcIndentBitsBuf);
      }

      dwExtraBits = dwSpecificBits & ( ~( KEY_QUERY_VALUE
                                        | KEY_SET_VALUE
                                        | KEY_CREATE_SUB_KEY
                                        | KEY_ENUMERATE_SUB_KEYS
                                        | KEY_NOTIFY
                                        | KEY_CREATE_LINK
                                        | (KEY_READ       & SPECIFIC_RIGHTS_ALL)
                                        | (KEY_WRITE      & SPECIFIC_RIGHTS_ALL)
                                        | (KEY_EXECUTE    & SPECIFIC_RIGHTS_ALL)
                                        | (KEY_ALL_ACCESS & SPECIFIC_RIGHTS_ALL) ) );
      if (dwExtraBits)
      { Eprintf(TEXT("\n%sExtra specific bits    == 0x%.8x <-This is a problem, should be all 0s"),tcIndentBuf,dwExtraBits);
      }
    }
    else if (ServiceAccessMask       == kamKindOfMask)
    {
      if ((dwSpecificBits    & SERVICE_QUERY_CONFIG        ) == SERVICE_QUERY_CONFIG        )
      { Eprintf(TEXT("\n%s0x00000001 SERVICE_QUERY_CONFIG        "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & SERVICE_CHANGE_CONFIG       ) == SERVICE_CHANGE_CONFIG       )
      { Eprintf(TEXT("\n%s0x00000002 SERVICE_CHANGE_CONFIG       "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & SERVICE_QUERY_STATUS        ) == SERVICE_QUERY_STATUS        )
      { Eprintf(TEXT("\n%s0x00000004 SERVICE_QUERY_STATUS        "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & SERVICE_ENUMERATE_DEPENDENTS) == SERVICE_ENUMERATE_DEPENDENTS)
      { Eprintf(TEXT("\n%s0x00000008 SERVICE_ENUMERATE_DEPENDENTS"),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & SERVICE_START               ) == SERVICE_START               )
      { Eprintf(TEXT("\n%s0x00000010 SERVICE_START               "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & SERVICE_STOP                ) == SERVICE_STOP                )
      { Eprintf(TEXT("\n%s0x00000020 SERVICE_STOP                "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & SERVICE_PAUSE_CONTINUE      ) == SERVICE_PAUSE_CONTINUE      )
      { Eprintf(TEXT("\n%s0x00000040 SERVICE_PAUSE_CONTINUE      "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & SERVICE_INTERROGATE         ) == SERVICE_INTERROGATE         )
      { Eprintf(TEXT("\n%s0x00000080 SERVICE_INTERROGATE         "),tcIndentBitsBuf);
      }
      if ((dwSpecificBits    & SERVICE_USER_DEFINED_CONTROL) == SERVICE_USER_DEFINED_CONTROL)
      { Eprintf(TEXT("\n%s0x00000100 SERVICE_USER_DEFINED_CONTROL"),tcIndentBitsBuf,tcIndentBitsBuf);
      }

      if (((dwStandardBits | dwSpecificBits )
           & SERVICE_ALL_ACCESS) == SERVICE_ALL_ACCESS)
      { Eprintf(TEXT("\n%s0x000F01FF SERVICE_ALL_ACCESS == (STANDARD_RIGHTS_REQUIRED | SERVICE_QUERY_CONFIG | SERVICE_CHANGE_CONFIG | "), tcIndentBitsBuf );
        Eprintf(TEXT("%s"), TEXT("SERVICE_QUERY_STATUS | SERVICE_ENUMERATE_DEPENDENTS | SERVICE_START | SERVICE_STOP | SERVICE_PAUSE_CONTINUE | SERVICE_INTERROGATE | SERVICE_USER_DEFINED_CONTROL)") );
      }

      dwExtraBits = dwSpecificBits & ( ~( SERVICE_QUERY_CONFIG
                                        | SERVICE_CHANGE_CONFIG
                                        | SERVICE_QUERY_STATUS
                                        | SERVICE_ENUMERATE_DEPENDENTS
                                        | SERVICE_START
                                        | SERVICE_STOP
                                        | SERVICE_PAUSE_CONTINUE
                                        | SERVICE_INTERROGATE
                                        | SERVICE_USER_DEFINED_CONTROL
                                        | (SERVICE_ALL_ACCESS & SPECIFIC_RIGHTS_ALL) ) );
      if (dwExtraBits)
      { Eprintf(TEXT("\n%sExtra specific bits    == 0x%.8x <-This is a problem, should be all 0s"),tcIndentBuf,dwExtraBits);
      }
    }
    else if (DefaultDaclInAccessTokenAccessMask == kamKindOfMask)
    {
      Eprintf(TEXT("\n%sSpecific bits in default Dacl(s) in token not broken down into defines"),tcIndentBitsBuf);
    }
    else
    { Eprintf(TEXT("\n%sYou will need to write some code (such as that directly"),tcIndentBuf);
      Eprintf(TEXT("\n%s  above the code that wrote out this message) to decode"),tcIndentBuf);
      Eprintf(TEXT("\n%s  this kind of access mask"),tcIndentBuf);
    }
  }

  /**************************************************************************\
  *
  * Print then decode the ACCESS_SYSTEM_SECURITY bit
  *
  \**************************************************************************/

  Eprintf(TEXT("\n%sAccess System Security == 0x%.8x"),tcIndentBuf,dwAccessSystemSecurityBit);

  /**************************************************************************\
  *
  * Print then decode the generic rights bits, which will rarely be on
  *
  * Generic bits are nearly always mapped by Windows NT before it tries to do
  *   anything with them.  You can ignore the fact that generic bits are
  *   special in any way, although it helps to keep track of what the mappings
  *   are so that you don't have any surprises
  *
  * The only time the generic bits are not mapped immediately is if they are
  *   placed in an inheritable ACE in an ACL, or in an ACL that will be
  *   assigned by default (such as the default DACL in an access token).  In
  *   that case they're mapped when the child object is created (or when the
  *   default DACL is used at object creation time)
  *
  \**************************************************************************/

  Eprintf(TEXT("\n%sGeneric  Rights        == 0x%.8x"),tcIndentBuf,dwGenericBits);

  if (dwGenericBits)
  {
    if ((dwGenericBits     & GENERIC_READ   ) == GENERIC_READ   )
    { Eprintf(TEXT("\n%s0x80000000 GENERIC_READ   "),tcIndentBitsBuf);
    }
    if ((dwGenericBits     & GENERIC_WRITE  ) == GENERIC_WRITE  )
    { Eprintf(TEXT("\n%s0x40000000 GENERIC_WRITE  "),tcIndentBitsBuf);
    }
    if ((dwGenericBits     & GENERIC_EXECUTE) == GENERIC_EXECUTE)
    { Eprintf(TEXT("\n%s0x20000000 GENERIC_EXECUTE"),tcIndentBitsBuf);
    }
    if ((dwGenericBits     & GENERIC_ALL    ) == GENERIC_ALL    )
    { Eprintf(TEXT("\n%s0x10000000 GENERIC_ALL    "),tcIndentBitsBuf);
    }

    dwExtraBits = dwGenericBits & ( ~( GENERIC_READ
                                     | GENERIC_WRITE
                                     | GENERIC_EXECUTE
                                     | GENERIC_ALL) );
    if (dwExtraBits)
    { Eprintf(TEXT("\n%sExtra generic bits     == 0x%.8x <-This is a problem, should be all 0s"),tcIndentBuf,dwExtraBits);
    }
  }
}

/****************************************************************************\
*
* FUNCTION: LookupSIDName
*
\****************************************************************************/

BOOL LookupSIDName(PSID psidSID, LPTSTR lpszOldIndent)
{
  TCHAR        tcIndentBuf    [SZ_INDENT_BUF]    = TEXT("");
  #define                      SZ_ACCT_NAME_BUF  60
  TCHAR        tcNameBuf      [SZ_ACCT_NAME_BUF] = TEXT("");
  DWORD        dwNameLength  = SZ_ACCT_NAME_BUF;
  #define                      SZ_DMN_NAME_BUF   60
  TCHAR        tcDomainNmBuf  [SZ_DMN_NAME_BUF]  = TEXT("");
  DWORD        dwDNameLength = SZ_DMN_NAME_BUF;
  #define                      SZ_SID_STRING_BUF 150
  TCHAR        tcSIDStringBuf [SZ_SID_STRING_BUF] = TEXT("");
  SID_NAME_USE peAcctNameUse = SidTypeInvalid;
  DWORD        dwLookupStatus;
  BOOL         bGotBadLookupThatIsNotLocalLogonSID;

  _tcscpy(tcIndentBuf,lpszOldIndent);
  _tcscat(tcIndentBuf,TEXT("  "));

  if (!IsValidSid(psidSID))
  { PERR("IsValidSid");
    return(FALSE);
  }

  if (!SIDStringName(psidSID,tcSIDStringBuf))
  { PERR("SIDStringName");
    return(FALSE);
  }

  if (!LookupAccountSid(
         (LPTSTR)TEXT(""),         // Look on local machine
         psidSID,
         (LPTSTR)&tcNameBuf,
         (LPDWORD)&dwNameLength,
         (LPTSTR)&tcDomainNmBuf,
         (LPDWORD)&dwDNameLength,
         (PSID_NAME_USE)&peAcctNameUse))
  {
    dwLookupStatus = GetLastError();

    /************************************************************************\
    *
    * Got a bad Lookup, so check is SID the Local Logon SID?
    *
    * The problem is that LookupAccountSid api will find all the well-known
    *   SIDs except the Local Logon SID.  The last two sub-authorities are
    *   always different, so to check to see if the SID we're looking at is
    *   the Local Logon SID, we take the psidLogonIdsSid variable we built at
    *   initialization time, and blast into it's last two sub-authorities the
    *   last two sub-authorities that we have.  Then compare for EqualSid
    *
    \************************************************************************/

    // Must have same number of sub authorities

    bGotBadLookupThatIsNotLocalLogonSID = FALSE;  // Assume the best :)

    if ( ( *(GetSidSubAuthorityCount(psidLogonIdsSid))) !=
         ( *(GetSidSubAuthorityCount(psidSID        )))    )
    { // Not same number of sub-authorities, so can't be a match
      bGotBadLookupThatIsNotLocalLogonSID = TRUE;
    }
    else
    {
      // Force the last two sub-authorities to match
      *(GetSidSubAuthority( psidLogonIdsSid, 1 )) =
      *(GetSidSubAuthority( psidSID        , 1 ));
      *(GetSidSubAuthority( psidLogonIdsSid, 2 )) =
      *(GetSidSubAuthority( psidSID        , 2 ));

      /**********************************************************************\
      *
      * EqualPrefixSid could be used instead if we want to blast in all but
      *   the last sub-authority.  For demonstration purposes, as long as we
      *   did one of the two previous assignment statements, we may as well to
      *   the other and use EqualSID
      *
      \**********************************************************************/

      if (EqualSid(psidSID,psidLogonIdsSid))
      { Eprintf(TEXT("\n%sSID is the Local Logon SID   %s"),tcIndentBuf,tcSIDStringBuf);
      }
      else
      { bGotBadLookupThatIsNotLocalLogonSID = TRUE;
      }
    }
    if (bGotBadLookupThatIsNotLocalLogonSID)
    {
      /**********************************************************************\
      *
      * ERROR_NONE_MAPPED means account unknown.  RegEdt32.exe will show
      *   1332-error-type accounts as Account Unknown, so we will also
      *
      \**********************************************************************/

      if (ERROR_NONE_MAPPED == dwLookupStatus)
      { Eprintf(TEXT("\n%sSID domain == %s, Name == %s    (Account Unknown)  %s"),tcIndentBuf,tcDomainNmBuf,tcNameBuf,tcSIDStringBuf);
      }
      else
      { SetLastError(dwLookupStatus);
        PERR("LookupAccountSid");
        return(FALSE);
      }
    }
  }
  else
  { // Got good Lookup, so SID Is NOT the Local Logon SID
    Eprintf(TEXT("\n%sSID domain == %s, Name == %s   %s"),tcIndentBuf,tcDomainNmBuf,tcNameBuf,tcSIDStringBuf);

    /************************************************************************\
    *
    * For demonstration purposes see which well-known SID it might be
    * For demonstration purposes do a silly search demonstrating
    *   no two well-known SIDs are equal
    *
    \************************************************************************/

    if (EqualSid(psidSID,psidNullSid))
    { Eprintf(TEXT("\n%sSID is the Null SID"),tcIndentBuf);
    }
    if (EqualSid(psidSID,psidWorldSid))
    { Eprintf(TEXT("\n%sSID is the World SID"),tcIndentBuf);
    }
    if (EqualSid(psidSID,psidLocalSid))
    { Eprintf(TEXT("\n%sSID is the Local SID"),tcIndentBuf);
    }
    if (EqualSid(psidSID,psidCreatorOwnerSid))
    { Eprintf(TEXT("\n%sSID is the CreatorOwner SID"),tcIndentBuf);
    }
    if (EqualSid(psidSID,psidCreatorGroupSid))
    { Eprintf(TEXT("\n%sSID is the CreatorGroup SID"),tcIndentBuf);
    }
    if (EqualSid(psidSID,psidNtAuthoritySid))
    { Eprintf(TEXT("\n%sSID is the NtAuthority SID"),tcIndentBuf);
    }
    if (EqualSid(psidSID,psidDialupSid))
    { Eprintf(TEXT("\n%sSID is the DialUp SID"),tcIndentBuf);
    }
    if (EqualSid(psidSID,psidNetworkSid))
    { Eprintf(TEXT("\n%sSID is the Network SID"),tcIndentBuf);
    }
    if (EqualSid(psidSID,psidBatchSid))
    { Eprintf(TEXT("\n%sSID is the Batch SID"),tcIndentBuf);
    }
    if (EqualSid(psidSID,psidInteractiveSid))
    { Eprintf(TEXT("\n%sSID is the Interactive SID"),tcIndentBuf);
    }
    if (EqualSid(psidSID,psidServiceSid))
    { Eprintf(TEXT("\n%sSID is the Service SID"),tcIndentBuf);
    }
    if (EqualSid(psidSID,psidLocalSystemSid))
    { Eprintf(TEXT("\n%sSID is the LocalSystem SID"),tcIndentBuf);
    }
    if (EqualSid(psidSID,psidBuiltinDomainSid))
    { Eprintf(TEXT("\n%sSID is the Builtin Domain SID"),tcIndentBuf);
    }
  }

  switch (peAcctNameUse)
  { case                      SidTypeUser           :
      Eprintf(TEXT("\n%sSID type is SidTypeUser")          ,tcIndentBuf);
      break;
    case                      SidTypeGroup          :
      Eprintf(TEXT("\n%sSID type is SidTypeGroup")         ,tcIndentBuf);
      break;
    case                      SidTypeDomain         :
      Eprintf(TEXT("\n%sSID type is SidTypeDomain")        ,tcIndentBuf);
      break;
    case                      SidTypeAlias          :
      Eprintf(TEXT("\n%sSID type is SidTypeAlias")         ,tcIndentBuf);
      break;
    case                      SidTypeWellKnownGroup :
      Eprintf(TEXT("\n%sSID type is SidTypeWellKnownGroup"),tcIndentBuf);
      break;
    case                      SidTypeDeletedAccount :
      Eprintf(TEXT("\n%sSID type is SidTypeDeletedAccount"),tcIndentBuf);
      break;
    case                      SidTypeInvalid        :
      Eprintf(TEXT("\n%sSID type is SidTypeInvalid")       ,tcIndentBuf);
      break;
    case                      SidTypeUnknown        :
      Eprintf(TEXT("\n%sSID type is SidTypeUnknown")       ,tcIndentBuf);
      break;
    default                   :
      Eprintf(TEXT("\n%sSID type is IMPOSSIBLE!!!!  Run debugger, see value!"),tcIndentBuf);
      break;
  }
}

/****************************************************************************\
*
* FUNCTION: SIDStringName
*
\****************************************************************************/

BOOL SIDStringName(PSID psidSID, LPTSTR lpszSIDStringName)
{
  /**************************************************************************\
  *
  * Unfortunately there is no api to return the SID Revision, and the number
  *   of bytes in the Identifier Authority must be expressed as a define
  *   (since the == operator won't operate on structures so mempcy has to be
  *   used for the identifier authority compares)
  *
  \**************************************************************************/

  DWORD dwNumSubAuthorities;
  DWORD dwLen;
  DWORD dwSubAuthorityI;
  #define BytesInIdentifierAuthority  6
  SID_IDENTIFIER_AUTHORITY siaSidAuthority;
  SID_IDENTIFIER_AUTHORITY siaNullSidAuthority    = SECURITY_NULL_SID_AUTHORITY;
  SID_IDENTIFIER_AUTHORITY siaWorldSidAuthority   = SECURITY_WORLD_SID_AUTHORITY;
  SID_IDENTIFIER_AUTHORITY siaLocalSidAuthority   = SECURITY_LOCAL_SID_AUTHORITY;
  SID_IDENTIFIER_AUTHORITY siaCreatorSidAuthority = SECURITY_CREATOR_SID_AUTHORITY;
  SID_IDENTIFIER_AUTHORITY siaNtAuthority         = SECURITY_NT_AUTHORITY;

  dwLen = _stprintf(lpszSIDStringName,TEXT("S-%d-"),SID_REVISION);

  if (SID_REVISION != ((PISID)psidSID)->Revision)
  { dwLen += _stprintf(lpszSIDStringName+dwLen,TEXT("bad_revision==%d"),((PISID)psidSID)->Revision);
  }

  siaSidAuthority = *(GetSidIdentifierAuthority(psidSID));

  if      (0==memcmp(&siaSidAuthority,&siaNullSidAuthority   ,BytesInIdentifierAuthority))
  { dwLen += _stprintf(lpszSIDStringName+dwLen,TEXT("0"));
  }
  else if (0==memcmp(&siaSidAuthority,&siaWorldSidAuthority  ,BytesInIdentifierAuthority))
  { dwLen += _stprintf(lpszSIDStringName+dwLen,TEXT("1"));
  }
  else if (0==memcmp(&siaSidAuthority,&siaLocalSidAuthority  ,BytesInIdentifierAuthority))
  { dwLen += _stprintf(lpszSIDStringName+dwLen,TEXT("2"));
  }
  else if (0==memcmp(&siaSidAuthority,&siaCreatorSidAuthority,BytesInIdentifierAuthority))
  { dwLen += _stprintf(lpszSIDStringName+dwLen,TEXT("3"));
  }
  else if (0==memcmp(&siaSidAuthority,&siaNtAuthority        ,BytesInIdentifierAuthority))
  { dwLen += _stprintf(lpszSIDStringName+dwLen,TEXT("5"));
  }
  else
  { dwLen += _stprintf(lpszSIDStringName+dwLen,TEXT("UnknownAuthority!"));
  }

  dwNumSubAuthorities = (DWORD)( *(GetSidSubAuthorityCount(psidSID)) );

  for (dwSubAuthorityI=0; dwSubAuthorityI<dwNumSubAuthorities; dwSubAuthorityI++)
  { dwLen += _stprintf(lpszSIDStringName+dwLen,TEXT("-%d"),*(GetSidSubAuthority(psidSID,dwSubAuthorityI)));
  }

  return(TRUE);
}

/****************************************************************************\
*
* FUNCTION: ExamineAccessToken
*
\****************************************************************************/

VOID ExamineAccessToken(HANDLE hAccessToken)
{
	TOKEN_INFORMATION_CLASS ticInfoClass;
	#define                               SZ_TOK_INFO_BUF  2000
	TCHAR                   tcTokInfoBuf [SZ_TOK_INFO_BUF] = TEXT("");
	DWORD                   dwTokInfoBufSz;
	PTOKEN_USER             ptuTokenUser         = (PTOKEN_USER         )&tcTokInfoBuf;
	PTOKEN_GROUPS           ptgTokenGroups       = (PTOKEN_GROUPS       )&tcTokInfoBuf;
	PTOKEN_PRIVILEGES       ptpTokenPrivileges   = (PTOKEN_PRIVILEGES   )&tcTokInfoBuf;
	PTOKEN_OWNER            ptoTokenOwner        = (PTOKEN_OWNER        )&tcTokInfoBuf;
	PTOKEN_PRIMARY_GROUP    ptgTokenPrimaryGroup = (PTOKEN_PRIMARY_GROUP)&tcTokInfoBuf;
	PTOKEN_DEFAULT_DACL     ptdTokenDefaultDacl  = (PTOKEN_DEFAULT_DACL )&tcTokInfoBuf;
	PTOKEN_SOURCE           ptsTokenSource       = (PTOKEN_SOURCE       )&tcTokInfoBuf;
	PTOKEN_TYPE             pttTokenType         = (PTOKEN_TYPE         )&tcTokInfoBuf;
	PSECURITY_IMPERSONATION_LEVEL psilSecurityImpersonationLevel = (PSECURITY_IMPERSONATION_LEVEL)&tcTokInfoBuf;
	PTOKEN_STATISTICS       ptsTokenStatistics   = (PTOKEN_STATISTICS   )&tcTokInfoBuf;
	DWORD                   dwGroupI;
	DWORD                   dwPrivilegeI;
	#define                               SZ_PRIV_INFO_BUF  250
	TCHAR                   tcPrivInfoBuf[SZ_PRIV_INFO_BUF] = TEXT("");
	DWORD                   dwPrivInfoBufSz;
	DWORD                   dwExtraBits;
	TCHAR                   tcIndentBitsBuf[SZ_INDENT_BUF]  = TEXT("");

	_tcscpy(tcIndentBitsBuf,TEXT(""));
	_tcscat(tcIndentBitsBuf,TEXT("                                  "));

	ticInfoClass   = TokenUser;
	dwTokInfoBufSz = SZ_TOK_INFO_BUF;

	if (!GetTokenInformation(hAccessToken,
	                         ticInfoClass,
	                         tcTokInfoBuf,
	                         (DWORD)SZ_TOK_INFO_BUF,
	                         &dwTokInfoBufSz))
	{ PERR("GetTokenInformation");
	  return;
	}

	Eprintf(TEXT("\nToken's User SID"));
	Eprintf(TEXT("\n    (this is a SID that is used to compare to SIDs in DACL(s) and SACL(s)"));

	if(!LookupSIDName( (*ptuTokenUser).User.Sid,TEXT("")))
	{ PERR("LookupSIDName failed");
	}

	Eprintf(TEXT("\nToken's User SID Attributes == 0x%.8x"),(*ptuTokenUser).User.Attributes);
	Eprintf(TEXT("\n    These should always be 0 - see \\mstools\\h\\winnt.h right after"));
	Eprintf(TEXT("\n      the defines such as SE_GROUP_LOGON_ID - there are no user"));
	Eprintf(TEXT("\n      attributes yet defined"));



	ticInfoClass   = TokenGroups;
	dwTokInfoBufSz = SZ_TOK_INFO_BUF;

	if (!GetTokenInformation(hAccessToken,
	                         ticInfoClass,
	                         tcTokInfoBuf,
	                         (DWORD)SZ_TOK_INFO_BUF,
	                         &dwTokInfoBufSz))
	{ PERR("GetTokenInformation");
	  return;
	}

	Eprintf(TEXT("\nToken groups (%d)"),(*ptgTokenGroups).GroupCount);
	Eprintf(TEXT("\n    (these SID(s) also are used to compare to SIDs in DACL(s) and SACL(s)"));

	for (dwGroupI=0; dwGroupI<(*ptgTokenGroups).GroupCount; dwGroupI++)
	{
	  DWORD dwAttributeBits = (*ptgTokenGroups).Groups[dwGroupI].Attributes;
	  Eprintf(TEXT("\n  Token group (%d)"),dwGroupI);

	  if(!LookupSIDName( (*ptgTokenGroups).Groups[dwGroupI].Sid,TEXT("  ")))
	  { PERR("LookupSIDName failed");
	  }
	  Eprintf(TEXT("\n  Token's group (%d) attributes == 0x%.8x"),dwGroupI,dwAttributeBits);

	  if (dwAttributeBits)
	  {
	    if ((dwAttributeBits   & SE_GROUP_MANDATORY         ) == SE_GROUP_MANDATORY         )
	    { Eprintf(TEXT("\n%s0x00000001 SE_GROUP_MANDATORY         "),tcIndentBitsBuf);
	    }
	    if ((dwAttributeBits   & SE_GROUP_ENABLED_BY_DEFAULT) == SE_GROUP_ENABLED_BY_DEFAULT)
	    { Eprintf(TEXT("\n%s0x00000002 SE_GROUP_ENABLED_BY_DEFAULT"),tcIndentBitsBuf);
	    }
	    if ((dwAttributeBits   & SE_GROUP_ENABLED           ) == SE_GROUP_ENABLED           )
	    { Eprintf(TEXT("\n%s0x00000004 SE_GROUP_ENABLED           "),tcIndentBitsBuf);
	    }
	    if ((dwAttributeBits   & SE_GROUP_OWNER             ) == SE_GROUP_OWNER             )
	    { Eprintf(TEXT("\n%s0x00000008 SE_GROUP_OWNER             "),tcIndentBitsBuf);
	    }
	    if ((dwAttributeBits   & SE_GROUP_LOGON_ID          ) == SE_GROUP_LOGON_ID          )
	    { Eprintf(TEXT("\n%s0xC0000000 SE_GROUP_LOGON_ID          "),tcIndentBitsBuf);
	    }

	    dwExtraBits = dwAttributeBits & ( ~( SE_GROUP_MANDATORY
	                                       | SE_GROUP_ENABLED_BY_DEFAULT
	                                       | SE_GROUP_ENABLED
	                                       | SE_GROUP_OWNER
	                                       | SE_GROUP_LOGON_ID) );
	    if (0 != dwExtraBits)
	    { Eprintf(TEXT("\n          Extra attribute bits == 0x%.8x <-This is a problem, should be all 0s"),dwExtraBits);
	    }
	  }
	}



	ticInfoClass   = TokenPrivileges;
	dwTokInfoBufSz = SZ_TOK_INFO_BUF;

	if (!GetTokenInformation(hAccessToken,
	                         ticInfoClass,
	                         tcTokInfoBuf,
	                         (DWORD)SZ_TOK_INFO_BUF,
	                         &dwTokInfoBufSz))
	{ PERR("GetTokenInformation");
	  return;
	}

	Eprintf(TEXT("\nToken privileges (%d)"),(*ptpTokenPrivileges).PrivilegeCount);
	Eprintf(TEXT("\n  NOTE: Most token privileges are not enabled by default."));
	Eprintf(TEXT("\n    For example the privilege to reboot or logoff is not."));
	Eprintf(TEXT("\n    0x00000000 for attributes implies the privilege is not enabled."));
	Eprintf(TEXT("\n    Use care when enabling privileges.  Enable only those needed,"));
	Eprintf(TEXT("\n      and leave them enabled only for as long as they are needed."));

	for (dwPrivilegeI=0; dwPrivilegeI<(*ptpTokenPrivileges).PrivilegeCount; dwPrivilegeI++)
	{
	  LUID  luidTokenLuid   = (*ptpTokenPrivileges).Privileges[dwPrivilegeI].Luid;
	  DWORD dwAttributeBits = (*ptpTokenPrivileges).Privileges[dwPrivilegeI].Attributes;

	  dwPrivInfoBufSz = SZ_PRIV_INFO_BUF;

	  if (!LookupPrivilegeName(NULL,
	                           (PLUID)&luidTokenLuid,
	                           (LPTSTR)tcPrivInfoBuf,
	                           (LPDWORD)&dwPrivInfoBufSz))
	  { PERR("LookUpPrivilegeName");
	    return;
	  }

	  Eprintf(TEXT("\n  Token's privilege (%.2d) name       == %s"),dwPrivilegeI,tcPrivInfoBuf);

	  Eprintf(TEXT("\n  Token's privilege (%.2d) attributes == 0x%.8x"),dwPrivilegeI,dwAttributeBits);

	  if (dwAttributeBits)
	  {
	    if ((dwAttributeBits   & SE_PRIVILEGE_ENABLED_BY_DEFAULT) == SE_PRIVILEGE_ENABLED_BY_DEFAULT)
	    { Eprintf(TEXT("\n%s     0x00000001 SE_PRIVILEGE_ENABLED_BY_DEFAULT"),tcIndentBitsBuf);
	    }
	    if ((dwAttributeBits   & SE_PRIVILEGE_ENABLED           ) == SE_PRIVILEGE_ENABLED           )
	    { Eprintf(TEXT("\n%s     0x00000002 SE_PRIVILEGE_ENABLED           "),tcIndentBitsBuf);
	    }
	    if ((dwAttributeBits   & SE_PRIVILEGE_USED_FOR_ACCESS   ) == SE_PRIVILEGE_USED_FOR_ACCESS   )
	    { Eprintf(TEXT("\n%s     0x80000000 SE_PRIVILEGE_USED_FOR_ACCESS   "),tcIndentBitsBuf);
	    }

	    dwExtraBits = dwAttributeBits & ( ~( SE_PRIVILEGE_ENABLED_BY_DEFAULT
	                                       | SE_PRIVILEGE_ENABLED
	                                       | SE_PRIVILEGE_USED_FOR_ACCESS ) );
	    if (0 != dwExtraBits)
	    { Eprintf(TEXT("\n               Extra attribute bits == 0x%.8x <-This is a problem, should be all 0s"),dwExtraBits);
	    }
	  }
	}



	ticInfoClass   = TokenOwner;
	dwTokInfoBufSz = SZ_TOK_INFO_BUF;

	if (!GetTokenInformation(hAccessToken,
	                         ticInfoClass,
	                         tcTokInfoBuf,
	                         (DWORD)SZ_TOK_INFO_BUF,
	                         &dwTokInfoBufSz))
	{ PERR("GetTokenInformation");
	  return;
	}

	Eprintf(TEXT("\nToken's default-owner-SID for created objects"));
	Eprintf(TEXT("\n    (this is NOT a SID that is used to compare to SIDs in DACL(s) and SACL(s)"));

	if(!LookupSIDName((*ptoTokenOwner).Owner,TEXT("")))
	{ PERR("LookupSIDName failed");
	}



	ticInfoClass   = TokenPrimaryGroup;
	dwTokInfoBufSz = SZ_TOK_INFO_BUF;

	if (!GetTokenInformation(hAccessToken,
	                         ticInfoClass,
	                         tcTokInfoBuf,
	                         (DWORD)SZ_TOK_INFO_BUF,
	                         &dwTokInfoBufSz))
	{ PERR("GetTokenInformation");
	  return;
	}

	Eprintf(TEXT("\nToken's Primary Group SID"));
	Eprintf(TEXT("\n    (Current uses are Posix and Macintosh client support)"));

	if(!LookupSIDName((*ptgTokenPrimaryGroup).PrimaryGroup,TEXT("")))
	{ PERR("LookupSIDName failed");
	}



	ticInfoClass   = TokenDefaultDacl;
	dwTokInfoBufSz = SZ_TOK_INFO_BUF;

	if (!GetTokenInformation(hAccessToken,
	                         ticInfoClass,
	                         tcTokInfoBuf,
	                         (DWORD)SZ_TOK_INFO_BUF,
	                         &dwTokInfoBufSz))
	{ PERR("GetTokenInformation");
	  return;
	}

	if (NULL         == (*ptdTokenDefaultDacl).DefaultDacl)
	{ Eprintf(TEXT("\nToken has a NULL Default DACL explicitly specified (allows all access to"));
	  Eprintf(TEXT("\n    Everyone, only on objects that are created where the object's Dacl is"));
	  Eprintf(TEXT("\n    assigned by default from this default Dacl in this access token)"));
	}
	else
	{ Eprintf(TEXT("\nToken's default-DACL for created objects"));
	  if(!ExamineACL((*ptdTokenDefaultDacl).DefaultDacl,TEXT(""),DefaultDaclInAccessTokenAccessMask))
	  { PERR("ExamineACL failed");
	  }
	}



	ticInfoClass   = TokenSource;
	dwTokInfoBufSz = SZ_TOK_INFO_BUF;

	if (!GetTokenInformation(hAccessToken,
	                         ticInfoClass,
	                         tcTokInfoBuf,
	                         (DWORD)SZ_TOK_INFO_BUF,
	                         &dwTokInfoBufSz))
	{
		if (GetLastError() == ERROR_ACCESS_DENIED)
		{
			Eprintf(TEXT("\n\nAccess denied trying to get TokenSource\n"));
		}
		else
		{
		     PERR("GetTokenInformation");
	 	}
	}
	else
	{
	    Eprintf(TEXT("\nToken's Source"));
	    Eprintf(TEXT("\n  Source Name        == %.8s"),(*ptsTokenSource).SourceName);
	    Eprintf(TEXT("\n  Source Identifier  == 0x%.8x%.8x"),
	       (*ptsTokenSource).SourceIdentifier.HighPart,
	       (*ptsTokenSource).SourceIdentifier.LowPart);
	}



	ticInfoClass   = TokenType;
	dwTokInfoBufSz = SZ_TOK_INFO_BUF;

	if (!GetTokenInformation(hAccessToken,
	                         ticInfoClass,
	                         tcTokInfoBuf,
	                         (DWORD)SZ_TOK_INFO_BUF,
	                         &dwTokInfoBufSz))
	{ PERR("GetTokenInformation");
	  return;
	}

	switch (*pttTokenType)
	{ case  TokenPrimary       :
	    Eprintf(TEXT("\nToken's Type is TokenPrimary"));
	    break;
	  case  TokenImpersonation :
	    Eprintf(TEXT("\nToken's Type is TokenImpersonation"));
	    Eprintf(TEXT("\n    Hence the token's TokenImpersonationLevel can be examined"));

	    ticInfoClass   = TokenImpersonationLevel;
	    dwTokInfoBufSz = SZ_TOK_INFO_BUF;

	    if (!GetTokenInformation(hAccessToken,
	                             ticInfoClass,
	                             tcTokInfoBuf,
	                             (DWORD)SZ_TOK_INFO_BUF,
	                             &dwTokInfoBufSz))
	    { PERR("GetTokenInformation");
	      return;
	    }

	    switch (*psilSecurityImpersonationLevel)
	    { case                     SecurityAnonymous      :
	        Eprintf(TEXT("\n  Token is a SecurityAnonymous impersonation token"));
	        break;
	      case                     SecurityIdentification :
	        Eprintf(TEXT("\n  Token is a SecurityIdentification impersonation token"));
	        break;
	      case                     SecurityImpersonation  :
	        Eprintf(TEXT("\n  Token is a SecurityImpersonation impersonation token"));
	        break;
	      case                     SecurityDelegation     :
	        Eprintf(TEXT("\n  Token is a SecurityDelegation impersonation token"));
	        break;
	      default                   :
	        Eprintf(TEXT("\n  Token is an ILLEGAL KIND OF impersonation token!!! == 0x%.8x"),*psilSecurityImpersonationLevel);
	        break;
	    }
		break;

	  default                  :
	    Eprintf(TEXT("\nToken's Type is ILLEGAL!!! == 0x%.8x"),*pttTokenType);
	    break;
	}



	ticInfoClass   = TokenStatistics;
	dwTokInfoBufSz = SZ_TOK_INFO_BUF;

	if (!GetTokenInformation(hAccessToken,
	                         ticInfoClass,
	                         tcTokInfoBuf,
	                         (DWORD)SZ_TOK_INFO_BUF,
	                         &dwTokInfoBufSz))
	{ PERR("GetTokenInformation");
	  return;
	}

	Eprintf(TEXT("\nToken's Statistics"));
	Eprintf(TEXT("\n  TokenId            == 0x%.8x%.8x"),
	  (*ptsTokenStatistics).TokenId.HighPart,
	  (*ptsTokenStatistics).TokenId.LowPart);
	Eprintf(TEXT("\n  AuthenticationId   == 0x%.8x%.8x"),
	  (*ptsTokenStatistics).AuthenticationId.HighPart,
	  (*ptsTokenStatistics).AuthenticationId.LowPart);
	Eprintf(TEXT("\n  ExpirationTime     == (not supported in this release of Windows NT)"));
	Eprintf(TEXT("\n  TokenType          == See token type above"));
	Eprintf(TEXT("\n  ImpersonationLevel == See impersonation level above (only if TokenType is not TokenPrimary)"));
	Eprintf(TEXT("\n  DynamicCharged     == %ld"),(*ptsTokenStatistics).DynamicCharged    );
	Eprintf(TEXT("\n  DynamicAvailable   == %ld"),(*ptsTokenStatistics).DynamicAvailable  );
	Eprintf(TEXT("\n  GroupCount         == %d"),(*ptsTokenStatistics).GroupCount        );
	Eprintf(TEXT("\n  PrivilegeCount     == %d"),(*ptsTokenStatistics).PrivilegeCount    );
	Eprintf(TEXT("\n  ModifiedId         == 0x%.8x%.8x"),
	  (*ptsTokenStatistics).ModifiedId.HighPart,
	  (*ptsTokenStatistics).ModifiedId.LowPart);



	Eprintf(TEXT("\n\n"));
}

/****************************************************************************\
*
* FUNCTION: SetPrivilegeInAccessToken
*
\****************************************************************************/

BOOL SetPrivilegeInAccessToken(VOID)
{
  HANDLE           hProcess;
  HANDLE           hAccessToken;
  LUID             luidPrivilegeLUID;
  TOKEN_PRIVILEGES tpTokenPrivilege;

  hProcess = GetCurrentProcess();
  if (!hProcess)
  { PERR("GetCurrentProcess");
    return(FALSE);
  }

  if (!OpenProcessToken(hProcess,
                        TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
                        &hAccessToken))
  { PERR("OpenProcessToken");
    return(FALSE);
  }

  /**************************************************************************\
  *
  * Get LUID of SeSecurityPrivilege privilege
  *
  \**************************************************************************/

  if (!LookupPrivilegeValue(NULL,
                            TEXT("SeSecurityPrivilege"),
                            &luidPrivilegeLUID))
  { PERR("LookupPrivilegeValue");
    Eprintf(TEXT("\nThe above error means you need to log on as an Administrator"));
    return(FALSE);
  }

  /**************************************************************************\
  *
  * Enable the SeSecurityPrivilege privilege using the LUID just
  *   obtained
  *
  \**************************************************************************/

  tpTokenPrivilege.PrivilegeCount = 1;
  tpTokenPrivilege.Privileges[0].Luid = luidPrivilegeLUID;
  tpTokenPrivilege.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

  AdjustTokenPrivileges (hAccessToken,
                         FALSE,  // Do not disable all
                         &tpTokenPrivilege,
                         sizeof(TOKEN_PRIVILEGES),
                         NULL,   // Ignore previous info
                         NULL);  // Ignore previous info

  if ( GetLastError() != NO_ERROR )
  { PERR("AdjustTokenPrivileges");
    return(FALSE);
  }

  return(TRUE);
}

/****************************************************************************\
*
* FUNCTION: InitializeWellKnownSIDs
*
\****************************************************************************/

VOID InitializeWellKnownSIDs(VOID)
{
  DWORD dwSidWith0SubAuthorities;
  DWORD dwSidWith1SubAuthority;
  DWORD dwSidWith2SubAuthorities;
  DWORD dwSidWith3SubAuthorities;
  DWORD dwSidWith4SubAuthorities;

  SID_IDENTIFIER_AUTHORITY siaNullSidAuthority    = SECURITY_NULL_SID_AUTHORITY;
  SID_IDENTIFIER_AUTHORITY siaWorldSidAuthority   = SECURITY_WORLD_SID_AUTHORITY;
  SID_IDENTIFIER_AUTHORITY siaLocalSidAuthority   = SECURITY_LOCAL_SID_AUTHORITY;
  SID_IDENTIFIER_AUTHORITY siaCreatorSidAuthority = SECURITY_CREATOR_SID_AUTHORITY;
  SID_IDENTIFIER_AUTHORITY siaNtAuthority         = SECURITY_NT_AUTHORITY;

  //  These SID sizes need to be allocated

  dwSidWith0SubAuthorities = GetSidLengthRequired( 0 );
  dwSidWith1SubAuthority   = GetSidLengthRequired( 1 );
  dwSidWith2SubAuthorities = GetSidLengthRequired( 2 );
  dwSidWith3SubAuthorities = GetSidLengthRequired( 3 );
  dwSidWith4SubAuthorities = GetSidLengthRequired( 4 );

  //  Allocate and initialize the universal SIDs

  psidNullSid         = (PSID)LocalAlloc(LPTR,dwSidWith1SubAuthority);
  psidWorldSid        = (PSID)LocalAlloc(LPTR,dwSidWith1SubAuthority);
  psidLocalSid        = (PSID)LocalAlloc(LPTR,dwSidWith1SubAuthority);
  psidCreatorOwnerSid = (PSID)LocalAlloc(LPTR,dwSidWith1SubAuthority);
  psidCreatorGroupSid = (PSID)LocalAlloc(LPTR,dwSidWith1SubAuthority);

  InitializeSid( psidNullSid,         &siaNullSidAuthority,    1 );
  InitializeSid( psidWorldSid,        &siaWorldSidAuthority,   1 );
  InitializeSid( psidLocalSid,        &siaLocalSidAuthority,   1 );
  InitializeSid( psidCreatorOwnerSid, &siaCreatorSidAuthority, 1 );
  InitializeSid( psidCreatorGroupSid, &siaCreatorSidAuthority, 1 );

  *(GetSidSubAuthority( psidNullSid,         0 )) = SECURITY_NULL_RID;
  *(GetSidSubAuthority( psidWorldSid,        0 )) = SECURITY_WORLD_RID;
  *(GetSidSubAuthority( psidLocalSid,        0 )) = SECURITY_LOCAL_RID;
  *(GetSidSubAuthority( psidCreatorOwnerSid, 0 )) = SECURITY_CREATOR_OWNER_RID;
  *(GetSidSubAuthority( psidCreatorGroupSid, 0 )) = SECURITY_CREATOR_GROUP_RID;

  // Allocate and initialize the NT defined SIDs

  psidNtAuthoritySid   = (PSID)LocalAlloc(LPTR,dwSidWith0SubAuthorities);
  psidDialupSid        = (PSID)LocalAlloc(LPTR,dwSidWith1SubAuthority);
  psidNetworkSid       = (PSID)LocalAlloc(LPTR,dwSidWith1SubAuthority);
  psidBatchSid         = (PSID)LocalAlloc(LPTR,dwSidWith1SubAuthority);
  psidInteractiveSid   = (PSID)LocalAlloc(LPTR,dwSidWith1SubAuthority);
  psidLogonIdsSid      = (PSID)LocalAlloc(LPTR,dwSidWith3SubAuthorities);
  psidServiceSid       = (PSID)LocalAlloc(LPTR,dwSidWith1SubAuthority);
  psidLocalSystemSid   = (PSID)LocalAlloc(LPTR,dwSidWith1SubAuthority);
  psidBuiltinDomainSid = (PSID)LocalAlloc(LPTR,dwSidWith1SubAuthority);

  InitializeSid( psidNtAuthoritySid,   &siaNtAuthority, 0 );
  InitializeSid( psidDialupSid,        &siaNtAuthority, 1 );
  InitializeSid( psidNetworkSid,       &siaNtAuthority, 1 );
  InitializeSid( psidBatchSid,         &siaNtAuthority, 1 );
  InitializeSid( psidInteractiveSid,   &siaNtAuthority, 1 );
  InitializeSid( psidLogonIdsSid,      &siaNtAuthority, 3 );
  InitializeSid( psidServiceSid,       &siaNtAuthority, 1 );
  InitializeSid( psidLocalSystemSid,   &siaNtAuthority, 1 );
  InitializeSid( psidBuiltinDomainSid, &siaNtAuthority, 1 );

  *(GetSidSubAuthority( psidDialupSid,        0 )) = SECURITY_DIALUP_RID;
  *(GetSidSubAuthority( psidNetworkSid,       0 )) = SECURITY_NETWORK_RID;
  *(GetSidSubAuthority( psidBatchSid,         0 )) = SECURITY_BATCH_RID;
  *(GetSidSubAuthority( psidInteractiveSid,   0 )) = SECURITY_INTERACTIVE_RID;
  *(GetSidSubAuthority( psidLogonIdsSid,      0 )) = SECURITY_LOGON_IDS_RID;
  *(GetSidSubAuthority( psidLogonIdsSid,      1 )) = 0; // Bogus!
  *(GetSidSubAuthority( psidLogonIdsSid,      2 )) = 0; // Also bogus!
  *(GetSidSubAuthority( psidServiceSid,       0 )) = SECURITY_SERVICE_RID;
  *(GetSidSubAuthority( psidLocalSystemSid,   0 )) = SECURITY_LOCAL_SYSTEM_RID;
  *(GetSidSubAuthority( psidBuiltinDomainSid, 0 )) = SECURITY_BUILTIN_DOMAIN_RID;
}

/****************************************************************************\
*
* FUNCTION: DisplayHelp
*
\****************************************************************************/

VOID DisplayHelp(VOID)
{
  Eprintf(TEXT("\nTo run type CHECK_SD and 0 or 1 parameters.  Syntax:"));
  Eprintf(TEXT("\n  CHECK_SD"));
  Eprintf(TEXT("\n      or"));
  Eprintf(TEXT("\n  CHECK_SD filename"));
  Eprintf(TEXT("\n           filename is the name of the file that is passed"));
  Eprintf(TEXT("\n             to GetFileSecurity() to fetch the SD to examine"));
  Eprintf(TEXT("\nExamples:"));
  Eprintf(TEXT("\n  CHECK_SD            Checks the SD on A: (this is the default)"));
  Eprintf(TEXT("\n  CHECK_SD \\\\.\\A:     Checks the SD on A:"));
  Eprintf(TEXT("\n  CHECK_SD d:\\a.fil   Checks the SD on d:\a.fil"));
  Eprintf(TEXT("\n  CHECK_SD A:         Checks the SD on the A: root, but that"));
  Eprintf(TEXT("\n                        is not where the DACL is that controls"));
  Eprintf(TEXT("\n                        access to the floppy, so don't do this"));
}
