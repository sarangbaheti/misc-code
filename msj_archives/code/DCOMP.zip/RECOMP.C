#include <windows.h>
#include <vfw.h>

//
//  FUNCTION: FindVideoCompressor
//
//  PURPOSE:
//    emulates ICLocate	(just so it's clearer what's going on)
//
//  PARAMETERS:
//
//  RETURN VALUE:
//    Zero on success, non-zero on error
//
//  COMMENTS:
//    Based on WalkStuff() from the ICWalk sample
//

HIC FindVideoCompressor2
(
	LPBITMAPINFOHEADER	lpbihIn,
	LPBITMAPINFOHEADER	lpbihOut,
	WORD				wFlags
)
{
	HIC hic;
	int i;
	ICINFO    icinfo;


	// call ICInfo to enumerate compressors.
	for (i = 0; ICInfo(ICTYPE_VIDEO, i, &icinfo); i++)
	{
		hic = ICOpen(ICTYPE_VIDEO, icinfo.fccHandler, ICMODE_QUERY);

		if (hic)
		{
			if (ICCompressQuery(hic, lpbihIn, lpbihOut) == ICERR_OK)
			{
				    ICClose(hic);
					hic = ICOpen(ICTYPE_VIDEO, icinfo.fccHandler, wFlags);
					return(hic);
			}
		    ICClose(hic);
		}
	}

	return(NULL);
}


//
//  FUNCTION: Decompress
//
//  PURPOSE:
//    decompress the frames in a bunch using ICM calls
//
//  PARAMETERS:
//    lplInDataLen  - total length of the input video data
//    lBunchLen     - number of frames in the bunch
//    alIn[]        - array of indexes of frame starts in input video buffer
//    lpbiIn        - pointer to video format for input data
//    lpbInData[]   - pointer to the input video data buffer
//    lpbiOut       - pointer to video format for output data
//    lpbOutData[]  - pointer to buffer to receive the output video data
//
//  RETURN VALUE:
//    Zero on success, non-zero on error
//
//  COMMENTS:
//    Decompression of every frame is done into the same buffer, since some
//    decompressors rely on this.  Each frame is then moved to is own buffer
//    before decompressing the next frame.
//

Decompress
(
	LONG			lInDataLen,
	LONG			lBunchLen,
	LONG			alIn[],
	LPBITMAPINFO	lpbiIn,
	BYTE			lpbInData[],
	LPBITMAPINFO	lpbiOut,
	BYTE			lpbOutData[]
)
{
	LONG				l;                    // ???
	LONG				lBytes[25];  // Size of each frame

	HIC					hIC;                  // Handle to compressor
	LPBITMAPINFOHEADER	lpbihIn  = &lpbiIn->bmiHeader;
	LPBITMAPINFOHEADER	lpbihOut = &lpbiOut->bmiHeader;

	LPVOID				lpBuildFrame;         // Scratch frame pointer
	DWORD				dwFlags;

    LONG                lReturnCode=0;


	// Compute the length of each frame
	for(l = 0; l < lBunchLen - 1; l++)
	{
		lBytes[l] = alIn[l + 1] - alIn[l];
	}

	lBytes[l] = lInDataLen - alIn[l];		// l is now (lBunchLen - 1)

	// Open decompressor
	if((hIC = ICLocate(ICTYPE_VIDEO, lpbihIn->biCompression,
								lpbihIn, NULL, ICMODE_DECOMPRESS)) != NULL)
	{
		// Initialize compressor
		if(ICDecompressBegin(hIC, lpbiIn, lpbiOut) == ICERR_OK)
		{
			// Designate last buffer as working buffer for the decompressor
			lpBuildFrame = &lpbOutData[lpbihOut->biSizeImage * (lBunchLen - 1)];

			for(l = 0L; l < lBunchLen; l++)
			{
			    // Decompress the data
				dwFlags = (l == 0 ? 0UL : ICDECOMPRESS_NOTKEYFRAME) |
						  (lBytes[l] == 0 ? ICDECOMPRESS_NULLFRAME : 0UL) ;
								// N.B. assumes only one key frame in bunch
								// - need a better solution

				// Should use ICDecompressEx etc. - need lots more arguments.
		        if(ICDecompress(hIC, dwFlags,
			        			lpbihIn, &lpbInData[alIn[l]],
			        			lpbihOut,
			        			lpBuildFrame) != ICERR_OK)
			    {
					// Problem decompressing frame, bail out
					lReturnCode=1;
                    break;
		        }

				// Need to copy result to the right place if not last frame.
				// If a null frame, should copy the previous frame instead
				// - this is because decompressors apparently can't be trusted
				// to leave the output buffer alone when the frame is null.
				if(dwFlags & ICDECOMPRESS_NULLFRAME)
				{
					if(l > 0L)		// better hope first frame isn't null
					{
						memcpy
						(
							&lpbOutData[lpbihOut->biSizeImage * l],
							&lpbOutData[lpbihOut->biSizeImage * (l - 1)],
							lpbihOut->biSizeImage
						);
					}
				}
				else
				{
					if(l < (lBunchLen - 1))
					{
						memcpy(&lpbOutData[lpbihOut->biSizeImage * l],
										lpBuildFrame, lpbihOut->biSizeImage);
					}
				}
			} // End for(;;)
		    
		    // Clean up
		    if(ICDecompressEnd(hIC) != ICERR_OK)
			{
				// Uh oh, return failure
				lReturnCode=1;
			}
		}
		else
		{
			// ICDecompressBegin() failed, bail out
			lReturnCode=1;
		}
	}
	else
	{
		// Couldn't open decompressor, just return
		return 1L;
	}

	if(ICClose(hIC) != ICERR_OK)
	{
		// Error closing decompressor
		lReturnCode=1;
	}

	return lReturnCode;
}


//
//  FUNCTION: Compress
//
//  PURPOSE:
//    compress the frames in a bunch using ICM calls
//
//  PARAMETERS:
//    lBunchId      - unique bunch ID - frame number of first frame in bunch
//    lpbiIn        - pointer to video format for input data
//    lpbiOut       - pointer to video format for output data
//    alOut[]       - pointer to array to receive indexes of frame starts in
//                    output video buffer
//    lBunchLen     - no. of frames in the bunch
//    lpbInData[]   - pointer to the input video data buffer
//    dwRetFlags[]  - pointer to array to receive flag for each frame returned
//                    by the compressor
//    lplOutDataLen - pointer to variable to receive the total length of the
//                    output video data
//    lpbOutData[]  - pointer to buffer to receive the output video data
//
//  RETURN VALUE:
//    Zero on success, non-zero on error
//
//  COMMENTS:
//

Compress
(
	LONG			lBunchId,

	LPBITMAPINFO	lpbiIn,
	LPBITMAPINFO	lpbiOut,
	LONG			alOut[],
	LONG			lBunchLen,
	BYTE			lpbInData[],
	DWORD			dwRetFlags[],
	LONG			*lplOutDataLen,
	BYTE			lpbOutData[]
)
{
	LPBITMAPINFOHEADER	lpbihIn  = &lpbiIn->bmiHeader;
	LPBITMAPINFOHEADER	lpbihOut = &lpbiOut->bmiHeader;
	HIC					hIC;
	ICINFO				icinfo;

	LONG				l;
	DWORD				dwFlags;
	LPBITMAPINFOHEADER	lpbiPrev;
	LPVOID				lpPrev;
	DWORD				dwCkid=0;
	DWORD				dwSaveSizeImage = lpbihIn->biSizeImage;

    LONG iReturnCode=0;

#if 0
	// Open compressor
	if((hIC = ICLocate(ICTYPE_VIDEO, lpbihIn->biCompression,
								lpbihIn, NULL, ICMODE_DECOMPRESS)) != NULL)
#endif
	// Open compressor

//	if ((hIC = ICLocate(ICTYPE_VIDEO, 0, // lpbihOut->biCompression,
	if ((hIC = FindVideoCompressor2(
								lpbihIn, lpbihOut, ICMODE_COMPRESS)) != NULL)
	{
		// Initialize compressor
		if(ICCompressQuery(hIC, lpbihIn, lpbihOut) == ICERR_OK)
		{
 		    ICGetInfo(hIC, &icinfo, sizeof icinfo);

		    if(ICCompressBegin(hIC, lpbiIn, lpbiOut) == ICERR_OK)
		    {
			    // Set first frame offset to 0
			    alOut[0] = 0L;

			    // Walk through the frames in the bunch
			    for(l = 0L; l < lBunchLen; l++)
			    {
			        // Compress the data

				    dwFlags  = (l == 0 ? ICCOMPRESS_KEYFRAME : 0UL);
								// N.B. assumes only one key frame in bunch
				    lpbiPrev = (l == 0 || (icinfo.dwFlags & VIDCF_FASTTEMPORALC) ?
						    NULL : lpbihIn);
				    lpPrev   = (l == 0 || (icinfo.dwFlags & VIDCF_FASTTEMPORALC) ?
						    NULL : &lpbInData[lpbihIn->biSizeImage * (l - 1)]);

		            if(ICCompress(	hIC,
		        				    dwFlags,
		        				    lpbihOut,
		        				    &lpbOutData[alOut[l]],
		        				    lpbihIn,
		        				    &lpbInData[lpbihIn->biSizeImage * l],
								    &dwCkid,
								    &dwRetFlags[l],	// Note - these returned values
												// sometimes seem to be invalid
								    lBunchId + l,
								    0UL,
								    (DWORD) -1,
								    lpbiPrev,
								    lpPrev
			        		    ) != ICERR_OK)
			        {
					    // Problem compressing frame
					    iReturnCode=1;
                        break;
		            }

#if 0
				    if(l == (lBunchLen - 1))
				    {
					    *lplOutDataLen = alOut[l] + lpbihOut->biSizeImage;
				    }
				    else
#endif
				    {
					    alOut[l + 1] = alOut[l] + lpbihOut->biSizeImage;
				    }
			
			    } // end for(;;)

			    // Finish compression session and close compressor
		        if(ICCompressEnd(hIC) != ICERR_OK)
			    {
				    // Error ending compression
                    iReturnCode=1;
			    }
		    }
		    else
		    {
			    // ICCompressBegin failed, bail out
                iReturnCode=1;
		    }
	    }
        else
        {
            // ICCompressQuery failed, bail out
            iReturnCode=1;
        }
    }
	else
	{
		//Couldn't open compressor
		return 1L;
	}

	if(ICClose(hIC) != ICERR_OK)
	{
		// Error closing compressor
		iReturnCode=1;
	}

	return iReturnCode;
}

#if 0
Test()
{
    get data
    decompress
    recompress 
    send back
}
#endif


RPCRecompressVideo
(
	handle_t            hHandle,
    LONG				lBunchId,
	LONG				lBunchLen,   // Number of frames
	LONG                lStreamFormatSize,
	LPBITMAPINFO        lpbComFormat,
	LPBITMAPINFO		lpbUncFormat,
	LPBITMAPINFO    	lpbRecFormat,
	LONG				alIndex[],
	
	LONG                lRecDataLen,
	BYTE                lpbRecData[],

	LONG				lComDataLen, 
	BYTE				lpbComData[]
)
{
	BYTE *lpbUncData;
	LPBITMAPINFOHEADER lpbihUnc;

    DWORD dwRetFlags[25];
//    long lRecDataLen;


	// allocate output buffer
	lpbihUnc =  &lpbUncFormat->bmiHeader;
    lpbUncData= malloc(lpbihUnc->biSizeImage * lBunchLen);
    
    // Full size for safety
//    lpbRecData= malloc(lpbihUnc->biSizeImage * lBunchLen);

//	SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_IDLE);

    Decompress(lComDataLen,//    lplInDataLen  - total length of the input video data
               lBunchLen,  //    lBunchLen     - number of frames in the bunch
               alIndex,      //    alIn[]        - array of indexes of frame starts in input video buffer
               (LPBITMAPINFO)lpbComFormat,   //    lpbiIn        - pointer to video format for input data
               lpbComData, //    lpbInData[]   - pointer to the input video data buffer
               lpbUncFormat,//    lpbiOut       - pointer to video format for output data
               lpbUncData//    lpbOutData[]  - pointer to buffer to receive the output video data
              );

    Compress(lBunchId, //    lBunchId      - unique bunch ID - frame number of first frame in bunch
             lpbUncFormat, //    lpbiIn        - pointer to video format for input data
             lpbRecFormat,//    lpbiOut       - pointer to video format for output data
             alIndex, //    alOut[]       - pointer to array to receive indexes of frame starts in
                    //                    output video buffer
             lBunchLen,//    lBunchLen     - no. of frames in the bunch
             lpbUncData,//    lpbInData[]   - pointer to the input video data buffer
             dwRetFlags,//    dwRetFlags[]  - pointer to array to receive flag for each frame returned
                        //                    by the compressor
             
             &lRecDataLen,//    lplOutDataLen - pointer to variable to receive the total length of the
                            //                    output video data
             
             lpbRecData //    lpbOutData[]  - pointer to buffer to receive the output video data
            );
#if 0
    Decompress(lComDataLen,//    lplInDataLen  - total length of the input video data
               lBunchLen,  //    lBunchLen     - number of frames in the bunch
               alCom,      //    alIn[]        - array of indexes of frame starts in input video buffer
               (LPBITMAPINFO)lpbComFormat,   //    lpbiIn        - pointer to video format for input data
               lpbComData, //    lpbInData[]   - pointer to the input video data buffer
               lpbUncFormat,//    lpbiOut       - pointer to video format for output data
               lpbUncData//    lpbOutData[]  - pointer to buffer to receive the output video data
              );

    Compress(lBunchId, //    lBunchId      - unique bunch ID - frame number of first frame in bunch
             lpbUncFormat, //    lpbiIn        - pointer to video format for input data
             lpbRecFormat,//    lpbiOut       - pointer to video format for output data
             alRec, //    alOut[]       - pointer to array to receive indexes of frame starts in
                    //                    output video buffer
             lBunchLen,//    lBunchLen     - no. of frames in the bunch
             lpbUncData,//    lpbInData[]   - pointer to the input video data buffer
             dwRetFlags,//    dwRetFlags[]  - pointer to array to receive flag for each frame returned
                        //                    by the compressor
             lplRecDataLen,//    lplOutDataLen - pointer to variable to receive the total length of the
                            //                    output video data
             lpbRecData //    lpbOutData[]  - pointer to buffer to receive the output video data
            );
#endif        
    free(lpbUncData);
    
    return 0;
}



#if 0


extern HWND hWnd;

LONG		CompBunch
(
)
{
    HRESULT				hr;


}



extern HINSTANCE ghInstance;
extern HWND hWnd;


LONG		DecompBunch
(
	LONG			lBunchId,
)
{

                // JF added... Display data
                {
                    HDC hdc;
                    //PGETFRAME pGetFrame;
                    HDRAWDIB hDrawDib;
                    //LPBITMAPINFOHEADER lpbi;
                        

                    // Open the DIB draw routines

                    hdc = GetDC(hWnd);
                    hDrawDib = DrawDibOpen();
                    
                    SetWindowPos(hWnd,HWND_TOP,0,0,lpbihOut->biWidth, lpbihOut->biHeight,SWP_NOMOVE);

                    DrawDibDraw(hDrawDib,hdc, 0, 0, lpbihOut->biWidth, lpbihOut->biHeight,
//									   lpbi, NULL,
								       //lpbihIn, &lpbInData[alIn[l]],
  			        				   lpbihOut,lpBuildFrame,
								       0, 0, -1, -1,
    							       0 );

                    // Close the DIB draw routines
                    DrawDibClose(hDrawDib);
                    ReleaseDC(hWnd,hdc);
                }


//	DestroyWindow(hWnd);
	

 
}
#endif
