void StartRestrictedProcess() {
    // Create a job kernel object
    HANDLE hjob = CreateJobObject(NULL, NULL);

    // Place some restrictions on processes in the job

    // First, set some basic restrictions
    JOBOBJECT_BASIC_LIMIT_INFORMATION jobli = { 0 };

    // The process always runs in the idle priority class
    jobli.PriorityClass = IDLE_PRIORITY_CLASS;

    // The job cannot use more than 1 second of CPU time
    jobli.PerJobUserTimeLimit.QuadPart = 10000000;    // 1 second in 100-ns intervals

    // These are the only 2 restrictions I want placed on the job (process)
    jobli.LimitFlags = JOB_OBJECT_LIMIT_PRIORITY_CLASS | JOB_OBJECT_LIMIT_JOB_TIME;
    SetInformationJobObject(hjob, JobObjectBasicLimitInformation, &jobli, sizeof(jobli));


    // Second, set some UI restrictions
    JOBOBJECT_BASIC_UI_RESTRICTIONS jobuir;
    jobuir.UIRestrictionsClass  = JOB_OBJECT_UILIMIT_NONE;    // A fancy 0

    // The process can�t logoff the system
    jobuir.UIRestrictionsClass |= JOB_OBJECT_UILIMIT_EXITWINDOWS;

    // The process can�t access USER object (like other windows) in the system
    jobuir.UIRestrictionsClass |= JOB_OBJECT_UILIMIT_HANDLES

    SetInformationJobObject(hjob, JobObjectBasicUIRestrictions, &jobuir, sizeof(jobuir));


    // Spawn the process that is to be in the job
    // Note: You must first spawn the process and then place the process in the job.
    //        This means that the process�s thread must be initially suspended so that 
    //        it can�t execute any code outside of the job�s restrictions.
    STARTUPINFO si = { sizeof(si) };
    PROCESS_INFORMATION pi;
    CreateProcess(NULL, "CMD", NULL, NULL, FALSE, CREATE_SUSPENDED, NULL, NULL, &si, &pi);

    // Place the process in the job.
    // Note: if this process spawns any children, the children are 
    //        automatically associated with the same job
    AssignProcessToJobObject(hjob, pi.hProcess);

    // Now, we can allow the child process�s thread to execute code.
    ResumeThread(pi.hThread);
    CloseHandle(pi.hThread);

    // Wait for the process to terminate or for all the job�s allotted CPU time to be used
    HANDLE h[2];
    h[0] = pi.hProcess;
    h[1] = hjob;
    DWORD dw = WaitForMultipleObjects(2, h, FALSE, INFINITE);
    switch (dw � WAIT_OBJECT_0) {
        case 0:
            // The process has terminated�
            break;
        case 1:
            // All of the job�s allotted CPU time was used�
            break;
    }

    // Clean-up properly
    CloseHandle(pi.hProcess);
    CloseHandle(hjob);
}
