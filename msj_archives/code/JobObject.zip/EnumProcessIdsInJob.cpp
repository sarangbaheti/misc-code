void EnumProcessIdsInJob(HANDLE hjob) {

// I assume that there will never be more than 10 processes in this job
w    #define MAX_PROCESS_IDS    10

// Calculate the number of bytes needed for structure & process Ids
    DWORD cb = sizeof(JOBOBJECT_BASIC_PROCESS_ID_LIST) +
        (MAX_PROCESS_IDS � 1) * sizeof(DWORD);

// Allocate the block of memory
    PJOBOBJECT_BASIC_PROCESS_ID_LIST pjobpil = _alloca(cb);

// Tell the function the maximum number of processes that we allocated space for 
    pjobpil->NumberOfAssignedProcesses = MAX_PROCESS_IDS;

// Request the current set of process Ids
    QueryInformationJobObject(hjob, JobObjectBasicProcessIdList, pjobpil, cb, &cb);

// Enumerate the Process Ids
    for (int x = 0; x < pjobpil->NumberOfProcessIdsInList; x++) {
        // Use pjobpil->ProcessIdList[x]�
    }

// Since _alloca was used to allocate the memory, we don�t need to free it here
}
