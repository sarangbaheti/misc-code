////////////////////////////////////////////////////////////////
// GRAYSUB 1999 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// GRAYSUB illustrates how to gray a submenu item. 
// Compiles with VC++ 5.0 or later, under Windows 95.
//
#include "StdAfx.h"
#include "GraySub.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_COMMAND(ID_ENABLE_SUBMENU, OnEnableSubmenu)
	ON_UPDATE_COMMAND_UI(ID_ENABLE_SUBMENU, OnUpdateEnableSubmenu)
	ON_COMMAND(ID_FOO, OnFoo)
	ON_UPDATE_COMMAND_UI(ID_FOO, OnUpdateFoo)
	ON_COMMAND(ID_ENABLE_FOO, OnEnableFoo)
	ON_UPDATE_COMMAND_UI(ID_ENABLE_FOO, OnUpdateEnableFoo)
END_MESSAGE_MAP()

CMainFrame::CMainFrame()
{
	m_bEnableSubmenu = FALSE;
	m_bEnableFoo   = FALSE;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	return 0;
}

//////////////////
// Set initial window size to 200 x 200
//
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	BOOL bRet = CFrameWnd::PreCreateWindow(cs);
	cs.cx = cs.cy = 200;
	return bRet;
}

//////////////////
// Enable/Disable the submenu
//
void CMainFrame::OnEnableSubmenu()
{
	m_bEnableSubmenu = !m_bEnableSubmenu;
}

//////////////////
// Set text for File | Enable/Disable Submenu
//
void CMainFrame::OnUpdateEnableSubmenu(CCmdUI *pCmdUI)
{
	pCmdUI->SetText(m_bEnableSubmenu ?
		_T("&Disable Submenu") : _T("&Enable Submenu"));
}

//////////////////
// Handle File | Submenu | Foo
//
void CMainFrame::OnFoo()
{
	AfxMessageBox(_T("Foo to you too."));
}

//////////////////
// Update handler for File | Submenu | Foo handles updating
// of the command and the submenu item itself.
//
void CMainFrame::OnUpdateFoo(CCmdUI *pCmdUI)
{
	if (pCmdUI->m_pSubMenu) {
		// update submenu item (File | Submenu)
		UINT fGray = m_bEnableSubmenu ? 0 : MF_GRAYED;
		pCmdUI->m_pMenu->EnableMenuItem(pCmdUI->m_nIndex,
			MF_BYPOSITION|fGray);
	} else
		// update command item (File | Submenu | Foo)
		pCmdUI->Enable(m_bEnableFoo);
}

/////////////////
// Enable/Disable the File | Submenu | Foo command
//
void CMainFrame::OnEnableFoo()
{
	m_bEnableFoo = !m_bEnableFoo;
}

/////////////////
// Set text for File | Submenu | Enable/Disable Foo
//
void CMainFrame::OnUpdateEnableFoo(CCmdUI *pCmdUI)
{
	pCmdUI->SetText(m_bEnableFoo ?
		_T("&Disable Foo") : _T("&Enable Foo"));
}

