////////////////////////////////////////////////////////////////
// GRAYSUB 1999 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// See GRAYSUB.CPP for Description of program.
// 
#include "resource.h"       // main symbols

class CMyApp : public CWinApp {
public:
	DECLARE_DYNAMIC(CMyApp)
	CMyApp();
public:
	virtual BOOL InitInstance();
protected:
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};
