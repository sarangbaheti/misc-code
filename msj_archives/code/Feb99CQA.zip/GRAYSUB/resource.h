//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GraySub.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDC_MSJICON                     1001
#define IDC_PDURL                       1002
#define ID_ENABLE_SUBMENU               32774
#define ID_FOO                          32775
#define ID_ENABLE_FOO                   32776
#define ID_DISABLE_FOO                  32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
