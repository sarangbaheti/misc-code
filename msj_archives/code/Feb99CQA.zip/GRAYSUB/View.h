////////////////////////////////////////////////////////////////
// GRAYSUB 1999 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//

////////////////
// Standard MFC view
//
class CMyView : public CView {
public:
	virtual ~CMyView();
	CMyDoc* GetDocument() { return (CMyDoc*)m_pDocument; }
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
protected:
	DECLARE_DYNCREATE(CMyView)
	CMyView();
	DECLARE_MESSAGE_MAP()
};
