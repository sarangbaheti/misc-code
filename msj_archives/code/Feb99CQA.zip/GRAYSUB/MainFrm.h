////////////////////////////////////////////////////////////////
// GRAYSUB 1999 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//

////////////////
// Standard MFC main frame window
//
class CMainFrame : public CFrameWnd {
public:
	virtual ~CMainFrame();
protected:
	BOOL m_bEnableSubmenu;
	BOOL m_bEnableFoo;

	CMainFrame();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnEnableSubmenu();
	afx_msg void OnUpdateEnableSubmenu(CCmdUI *pCmdUI);
	afx_msg void OnFoo();
	afx_msg void OnUpdateFoo(CCmdUI *pCmdUI);
	afx_msg void OnEnableFoo();
	afx_msg void OnUpdateEnableFoo(CCmdUI *pCmdUI);
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNCREATE(CMainFrame)
};
