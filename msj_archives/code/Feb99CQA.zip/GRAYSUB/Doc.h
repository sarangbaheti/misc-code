////////////////////////////////////////////////////////////////
// GRAYSUB 1999 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//

////////////////
// Standard MFC doc class
//
class CMyDoc : public CDocument {
public:
	virtual ~CMyDoc();
public:
	virtual void Serialize(CArchive& ar);

protected:
	CMyDoc();
	DECLARE_DYNCREATE(CMyDoc)
	DECLARE_MESSAGE_MAP()
};
