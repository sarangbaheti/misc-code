//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TrayTest.rc
//
#define IDR_MAINFRAME                   2
#define IDR_TRAYICON                    3
#define IDD_ABOUTBOX                    100
#define IDI_MYICON                      101
#define IDI_MYICON2                     102
#define IDB_BITMAP1                     103
#define ID_TOGGLE_ICON                  32771
#define ID_VIEW_CLEAR                   32773
#define ID_VIEW_NOTIFICATIONS           32774
#define ID_APP_OPEN                     32775
#define ID_APP_SUSPEND                  32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
