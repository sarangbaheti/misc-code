/*----------------------------------------------------------------------
       John Robbins - Microsoft Systems Journal Bugslayer Column
----------------------------------------------------------------------*/

#include "WarningsOff.h"
#include <windows.h>
#include <tchar.h>
#include "WarningsOn.h"


