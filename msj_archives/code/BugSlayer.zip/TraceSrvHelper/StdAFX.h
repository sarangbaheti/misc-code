/*----------------------------------------------------------------------
  John Robbins - Microsoft Systems Journal Bugslayer Column - Feb '98
----------------------------------------------------------------------*/

#define _WIN32_DCOM

#include "WarningsOff.h"
#include <windows.h>
#include <tchar.h>
#include <ole2.h>

#include "BugSlayerUtil.h"
#include "WarningsOn.h"


