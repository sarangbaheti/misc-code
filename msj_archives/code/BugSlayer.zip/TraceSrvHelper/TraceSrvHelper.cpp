/*----------------------------------------------------------------------
  John Robbins - Microsoft Systems Journal Bugslayer Column - Feb '98

Conditional Compilation Used: (Other than standard _DEBUG)

USE_TRACESRV_INTERNALLY - If defined, then the internal calls to
                          OutputDebugString will be sent through the
                          ITrace interface.  This means that you can
                          use this module to test and debug itself.
                          The only code it enables is in the InternalODS
                          function.  Make sure to see the "Big Hairy
                          Note" right below all the include stuff.
----------------------------------------------------------------------*/

/*//////////////////////////////////////////////////////////////////////
                                Includes
//////////////////////////////////////////////////////////////////////*/
// The usual precompiled header.
#include "StdAFX.h"
// Bugslayer utility DLL.
#include "BugslayerUtil.h"
// The header for this file.
#include "TraceSrvHelper.h"
// The fast BSTR helper class.
#include "FastBSTR.h"
// The critical section header.
#include "CriticalSection.h"
// Include the main TraceSrv files.
#include "initguid.h"
#include "TraceSrv.h"
#include "TraceSrv_i.c"

// STL spews errors just including them!  Using one Bugslaying tool,
//  STL, conflicts with another, /W4.  I still use /WX so even with /W3
//  I need to shut off the following warnings.

// C++ language change: to explicitly specialize class template ''
//   use the following syntax:
#pragma warning ( disable : 4663 )
// '' : signed/unsigned mismatch
#pragma warning ( disable : 4018 )
// '' : unreferenced formal parameter
#pragma warning ( disable : 4100 )

// Those weird STL headers.  Does anyone actually know why it was so
//  important to drop ".h"?
#include <vector>
#include <algorithm>

// Because of the STL stuff, the standard namespace must be used.  I'd
//  like to get rid of it because it drags in a huge DLL just for a
//  single function, std::nothrow.
using namespace std ;

/*//////////////////////////////////////////////////////////////////////
                              TRACE Macros
//////////////////////////////////////////////////////////////////////*/
// BIG HAIRY NOTE:
//  The TRACE macros are redefined for this module only.  If this module
//  were to call the real TRACE, which ends up calling _CrtDbgReport in
//  MSVCRTD.DLL, recursion and stack overflow would result if
//  MSVCRTD.DLL is hook.  This module has the only "true" calls for all
//  six hooked functions so anything that could be called out of this
//  module has to be watched carefully.
#ifdef _DEBUG

// The internal ODS wrapper.
static void InternalODS ( const char * szFmt , ... ) ;

//lint -esym(750,TRACE0)
#   undef TRACE0
#   define TRACE0(fmt) InternalODS ( fmt )

//lint -esym(750,TRACE1)
#   undef TRACE1
#   define TRACE1(fmt,arg1) InternalODS ( fmt , arg1 )

//lint -esym(750,TRACE2)
#   undef TRACE2
#   define TRACE2(fmt,arg1,arg2) InternalODS ( fmt , arg1 , arg2 )

//lint -esym(750,TRACE3)
#   undef TRACE3
#   define TRACE3(fmt,arg1,arg2,arg3) InternalODS ( fmt  ,  \
                                                    arg1 ,  \
                                                    arg2 ,  \
                                                    arg3  )

//lint -esym(750,TRACE4)
#   undef TRACE4
#   define TRACE4(fmt,arg1,arg2,arg3,arg4) InternalODS ( fmt  , \
                                                         arg1 , \
                                                         arg2 , \
                                                         arg3 , \
                                                         arg4  )

#endif  // _DEBUG

/*//////////////////////////////////////////////////////////////////////
                             File Constants
//////////////////////////////////////////////////////////////////////*/
// The total number of functions that need to be hooked for TraceSrv to
//  work.
const int k_NUM_HOOKED_FUNCS        = 7 ;
// The initial size used for the BSTR wrapper class.
const int k_INITIAL_BSTR_SIZE       = 2048 ;
// The module where all the functions to hook are located.
const LPCTSTR   k_KERNEL            = _T ( "kernel32.dll" ) ;
// The initial size of the module array to allocate.
const int k_INITIAL_MODARRAYSIZE    = 250 ;

/*//////////////////////////////////////////////////////////////////////
                          File Only Prototypes
//////////////////////////////////////////////////////////////////////*/
// Determines if the HINSTANCE is a DLL that is hookable.
static BOOL IsHookableDLL ( HINSTANCE hInst ) ;
// Handles getting the loaded module list.
static HMODULE * AllocateLoadedModuleList ( LPUINT puiCount ) ;
// The function that does all the hooking.
static BOOL HookTraceSrvHelperFuncs ( UINT           uiCount    ,
                                      LPHOOKFUNCDESC paToHook   ,
                                      PROC *         paOrigAddr  ) ;

// The functions that are blasted in.  The hook handlers functions.
VOID WINAPI TSH_OutputDebugStringA ( LPCSTR lpOutputString );
VOID WINAPI TSH_OutputDebugStringW ( LPCWSTR lpOutputString);
HMODULE WINAPI TSH_LoadLibraryA ( LPCSTR lpLibFileName ) ;
HMODULE WINAPI TSH_LoadLibraryW ( LPCWSTR lpLibFileName ) ;
HMODULE WINAPI TSH_LoadLibraryExA ( LPCSTR lpLibFileName ,
                                    HANDLE hFile         ,
                                    DWORD  dwFlags        ) ;
HMODULE WINAPI TSH_LoadLibraryExW ( LPCWSTR lpLibFileName ,
                                    HANDLE  hFile         ,
                                    DWORD   dwFlags        ) ;
VOID WINAPI TSH_ExitProcess ( UINT uExitCode ) ;

/*//////////////////////////////////////////////////////////////////////
                         File Global Variables
//////////////////////////////////////////////////////////////////////*/
// The flag that indicates if the DLL is completely initialized.
static BOOL             g_bInitialized      = FALSE ;
// The flag that indicates running under NT.  This is so
//  IsHookableDLL does not call GetVersion each and every time.
static BOOL             g_bIsNT             = TRUE  ;
// The HINSTANCE for this DLL so it does not get hooked.
static HINSTANCE        g_hInstance         = NULL  ;
// The one and only ITrace interface pointer.
static ITrace *         g_lpTrace           = NULL  ;
// The fast BSTR class.
static CFastBSTR        g_cGlobalBSTR               ;
// The vector that will hold the HMODULES that have been patched.
static vector<HMODULE>  g_vHookedModules            ;
// The critical section that is used to protect all functions that are
//  called from outside this module.
static CCriticalSection g_cCritSec                  ;
// The master table of functions names and the hook functions.  This
//  is read only for this file.
static HOOKFUNCDESC g_stToHookFuncs[ k_NUM_HOOKED_FUNCS ] =
{
    { _T ( "ExitProcess"        ) , (PROC)TSH_ExitProcess        } ,
    { _T ( "LoadLibraryA"       ) , (PROC)TSH_LoadLibraryA       } ,
    { _T ( "LoadLibraryExA"     ) , (PROC)TSH_LoadLibraryExA     } ,
    { _T ( "LoadLibraryExW"     ) , (PROC)TSH_LoadLibraryExW     } ,
    { _T ( "LoadLibraryW"       ) , (PROC)TSH_LoadLibraryW       } ,
    { _T ( "OutputDebugStringA" ) , (PROC)TSH_OutputDebugStringA } ,
    { _T ( "OutputDebugStringW" ) , (PROC)TSH_OutputDebugStringW }
} ;
// The master pointer list of original functions.  This can be kept on
//  a global basis as the only way a function can be imported in a
//  program is to have it imported into the same place for any module.
PROC g_pOrigFuncs[ k_NUM_HOOKED_FUNCS ] =
    { NULL , NULL , NULL , NULL , NULL , NULL , NULL } ;

/*----------------------------------------------------------------------
FUNCTION        :   DllMain
DISCUSSION      :
    The standard DLL entry point.
PARAMETERS      :
    Standard.
RETURNS         :
    Standard.
----------------------------------------------------------------------*/
BOOL WINAPI DllMain ( HINSTANCE hInst           ,
                      DWORD     dwReason        ,
                      LPVOID    /*lpReserved*/   )
{
    switch ( dwReason )
    {
        case DLL_PROCESS_ATTACH :
            g_hInstance = hInst ;
            VERIFY ( DisableThreadLibraryCalls ( g_hInstance ) ) ;
            break ;
        case DLL_PROCESS_DETACH :
            break ;
        case DLL_THREAD_ATTACH  :
            break ;
        case DLL_THREAD_DETACH  :
            break;
        default                 :
            break ;
    }
    return ( TRUE ) ;
}

// Function is documented in TraceSrvHelper.h.
BOOL TSRVHELP_DLLINTERFACE InitTraceSrvHelper ( void )
{
    // Called externally, guard it with the critical section.
    CUseCriticalSection cs ( g_cCritSec ) ;

    // Just make sure the assumptions are correct.
    ASSERT ( NULL != g_hInstance ) ;

    // If the library has already been initialized, then just return
    //  TRUE.
    if ( TRUE == g_bInitialized )
    {
        SetLastErrorEx ( ERROR_ALREADY_INITIALIZED , SLE_ERROR ) ;
        return ( TRUE ) ;
    }

    // Get the OS version flag.
    OSVERSIONINFO stOSVI ;
    memset ( &stOSVI , NULL , sizeof ( OSVERSIONINFO ) ) ;
    stOSVI.dwOSVersionInfoSize = sizeof ( OSVERSIONINFO ) ;

    VERIFY ( GetVersionEx ( &stOSVI ) ) ;

    if ( VER_PLATFORM_WIN32_WINDOWS == stOSVI.dwPlatformId )
    {
        g_bIsNT = FALSE ;
    }

    // Initialize OLE before we do anything else.
    HRESULT hRet = CoInitializeEx ( NULL ,  COINIT_APARTMENTTHREADED ) ;
    DWORD dwErrorCode = GetLastError ( ) ;
    ASSERT ( SUCCEEDED ( hRet ) ) ;
    if ( FAILED ( hRet ) )
    {
        TRACE1 ( "Could not initialized OLE!!! - 0X%08X\n" , hRet ) ;
        SetLastError ( dwErrorCode ) ;
        return ( FALSE ) ;
    }

    // Now do all the work to crank up TraceSrv and get the ITrace
    //  interface.  TraceSrv has to be running before the hooking.
    IUnknown * lpUnknown ;

    hRet = CoCreateInstance ( CLSID_Trace           ,
                              NULL                  ,
                              CLSCTX_SERVER         ,
                              IID_IUnknown          ,
                              (LPVOID*)&lpUnknown    ) ;
    dwErrorCode = GetLastError ( ) ;
    ASSERT ( SUCCEEDED ( hRet ) ) ;
    if ( FAILED ( hRet ) )
    {
        TRACE1 ( "Could not get TraceSrv IUnknown - 0X%08X\n" , hRet ) ;
        SetLastError ( dwErrorCode ) ;
        return ( FALSE ) ;
    }

    hRet = lpUnknown->QueryInterface ( IID_ITrace          ,
                                       (LPVOID*)&g_lpTrace  ) ;
    dwErrorCode = GetLastError ( ) ;
    // The IUnknown is no longer needed.
    lpUnknown->Release ( ) ;
    ASSERT ( SUCCEEDED ( hRet ) ) ;
    if ( FAILED ( hRet ) )
    {
        TRACE1 ( "Could not get TraceSrv ITrace - 0X%08X\n" , hRet ) ;
        SetLastError ( dwErrorCode ) ;
        return ( FALSE ) ;
    }

    // Get the global BSTR wrapper class cranked up.
    g_cGlobalBSTR.Allocate ( k_INITIAL_BSTR_SIZE ) ;

    // Add this DLL to the list of DLLs that have been hooked so that
    //  it does not ever get hooked.  This DLL has the only non-hooked
    //  versions of the imported functions.
    g_vHookedModules.push_back ( g_hInstance ) ;

#ifdef _ALPHA_
    // Is the FX32 DLL in the process space?  If a debugger is present,
    //  then FX32 is not injected.
    HINSTANCE hInstTemp = GetModuleHandle ( "FX32AGNT.DLL" ) ;
    if ( NULL != hInstTemp )
    {
        g_vHookedModules.push_back ( hInstTemp ) ;
    }
#endif  // _ALPHA_

    // OK, everything is kopacetic so all of the functions can be
    //  hooked.
    BOOL bRet = HookTraceSrvHelperFuncs ( k_NUM_HOOKED_FUNCS ,
                                          g_stToHookFuncs    ,
                                          g_pOrigFuncs        ) ;
    ASSERT ( TRUE == bRet ) ;
    if ( FALSE == bRet )
    {
        g_lpTrace->Release ( ) ;
        g_lpTrace = NULL ;
        return ( FALSE ) ;
    }

    g_bInitialized = TRUE ;

    // All OK, Jumpmaster!
    SetLastError ( ERROR_SUCCESS ) ;
    return ( bRet ) ;
}

// Function is documented in TraceSrvHelper.h.
BOOL TSRVHELP_DLLINTERFACE ShutdownTraceSrvHelper ( void )
{
    // Called externally, guard it with the critical section.
    CUseCriticalSection cs ( g_cCritSec ) ;

    // Just make sure the assumptions are correct.
    ASSERT ( NULL != g_hInstance ) ;
    ASSERT ( TRUE == g_bInitialized ) ;

    // Don't call this if it has not been initialized.
    if ( FALSE == g_bInitialized )
    {
        return ( FALSE ) ;
    }

    // Get rid of the ITrace interface.
    if ( NULL != g_lpTrace )
    {
        g_lpTrace->Release ( ) ;
        g_lpTrace = NULL ;
    }

    // Get rid of the memory used by the BSTR class.
    g_cGlobalBSTR.Free ( ) ;

    // Make a copy of the g_stToHookFuncs.
    HOOKFUNCDESC stUnHook[ k_NUM_HOOKED_FUNCS ] ;
    memcpy ( stUnHook , g_stToHookFuncs , sizeof ( g_stToHookFuncs ) ) ;

    // Put in all the hooks.
    for ( UINT i = 0 ; i < k_NUM_HOOKED_FUNCS ; i++ )
    {
        stUnHook[ i ].pProc = g_pOrigFuncs[ i ] ;
    }

    PROC pProcRet[ k_NUM_HOOKED_FUNCS ] ;

    // Clear out the list of modules that have been hook.  This way
    //  the HookTraceSrvHelperFuncs will treat everything as fresh and
    //  unhook them.
    g_vHookedModules.clear ( );
    g_vHookedModules.push_back ( g_hInstance ) ;

#ifdef _ALPHA_
    // Is the FX32 DLL in the process space?  If a debugger is present,
    //  then FX32 is not injected.
    HINSTANCE hInstTemp = GetModuleHandle ( "FX32AGNT.DLL" ) ;
    if ( NULL != hInstTemp )
    {
        g_vHookedModules.push_back ( hInstTemp ) ;
    }
#endif  // _ALPHA_


    BOOL bRet = HookTraceSrvHelperFuncs ( k_NUM_HOOKED_FUNCS ,
                                          stUnHook           ,
                                          pProcRet            ) ;
    // Reset outselves to a known state.
    g_bInitialized = FALSE ;
    memset ( g_pOrigFuncs , NULL , sizeof (PROC) * k_NUM_HOOKED_FUNCS );
    g_vHookedModules.clear ( );

    // All OK, Jumpmaster!
    SetLastError ( ERROR_SUCCESS ) ;
    return ( bRet ) ;
}

/*----------------------------------------------------------------------
FUNCTION        :   HookTraceSrvHelperFuncs
DISCUSSION      :
    The function that gets all the loaded modules and then hooks the
functions needed to get all the tracing statements going to TraceSrv.
This function can also be used to "unhook" existing hooked functions.
PARAMETERS      :
    uiCount    - The number of items in paToHook and paOrigAddr arrays.
    paToHook   - The pointer to the array of function descriptors to
                 hook.
    paOrigAddr - The array that will hold the original addresses that
                 were hooked.
RETURNS         :
    TRUE  - Everything is hooked.
    FALSE - There was a problem.
----------------------------------------------------------------------*/
static BOOL HookTraceSrvHelperFuncs ( UINT           uiCount    ,
                                      LPHOOKFUNCDESC paToHook   ,
                                      PROC *         paOrigAddr  )
{

    // Get the loaded modules.

    // The pointer to the HMODULEs in this process.
    HMODULE * pModArray = NULL ;
    // The real number of entries in the module array returned from
    //  AllocateLoadedModuleList.
    UINT uiModCount = 0 ;

    // Now that the list of modules is in pModArray, run through the
    //  list hooking all the calls needed.
    pModArray = AllocateLoadedModuleList ( &uiModCount ) ;
    ASSERT ( NULL != pModArray ) ;

    if ( NULL == pModArray )
    {
        return ( FALSE ) ;
    }

    // Allocate the temporary proc array.
    PROC * pTempProcs = (PROC*)malloc ( sizeof ( PROC ) * uiCount ) ;
    ASSERT ( NULL != pTempProcs ) ;

    // Loop through each module and hook the functions.
    for ( UINT i = 0 ; i < uiModCount ; i++ )
    {
        ASSERT ( NULL != pModArray[ i ] ) ;

        // Is this a module that is hookable?
        if ( TRUE == IsHookableDLL ( pModArray [ i ] ) )
        {
#ifdef _DEBUG
            TCHAR szFile[ MAX_PATH ] ;
            GetModuleFileName ( pModArray[ i ] , szFile , MAX_PATH ) ;
            TRACE1 ( "Looking to hook: %s\n" , szFile ) ;
#endif

            // Clear the temporary proc holder.
            memset ( pTempProcs , NULL , sizeof ( PROC ) * uiCount ) ;

            UINT uiHooked = 0 ;

            HookImportedFunctionsByName ( pModArray [ i ]   ,
                                          k_KERNEL          ,
                                          uiCount           ,
                                          paToHook          ,
                                          pTempProcs        ,
                                          &uiHooked          ) ;
            // Stick the current module in the skip list no matter if
            //  it failed.
            g_vHookedModules.push_back ( pModArray [ i ] ) ;


#ifdef _DEBUG
            TRACE1 ( "    Hooked a total of %d functions\n" ,
                     uiHooked                                ) ;
#endif
            // Copy the hooked functions into the master list.
            for ( UINT j = 0 ; j < uiCount ; j++ )
            {
                if ( NULL != pTempProcs[ j ] )
                {
                    paOrigAddr[ j ] = pTempProcs[ j ] ;
                }
#ifdef _DEBUG
                TRACE2 ( "    %-20s : %s\n"      ,
                         paToHook[ j ].szFunc   ,
                         pTempProcs[ j ] ? "Hooked" : "not imported" ) ;
#endif
            }

        }
    }

    // Free the memory that was allocated earlier.
    free ( pModArray ) ;
    free ( pTempProcs ) ;

    // All OK, Jumpmaster!
    return ( TRUE ) ;
}

/*----------------------------------------------------------------------
FUNCTION        :   AllocateLoadedModuleList
DISCUSSION      :
    Hides the work to get the loaded module list for this process.  This
function returns a pointer to memory allocated with malloc and it us up
to the caller to call free to get rid of the memory.
PARAMETERS      :
    puiCount - The total elements in the returned array.
RETURNS         :
    NULL  - There was a problem.
    !NULL - The block of memory holding the HMODULEs.
----------------------------------------------------------------------*/
static HMODULE * AllocateLoadedModuleList ( LPUINT puiCount )
{
    ASSERT ( NULL != puiCount ) ;
    ASSERT ( FALSE == IsBadReadPtr ( puiCount , sizeof ( LPUINT ) ) ) ;
    if ( TRUE == IsBadReadPtr ( puiCount , sizeof ( LPUINT ) ) )
    {
        return ( NULL ) ;
    }

    // The HMODULE array.
    HMODULE * pModArray ;

    pModArray =
       (HMODULE*)malloc ( k_INITIAL_MODARRAYSIZE * sizeof ( HMODULE ) );

    ASSERT ( NULL != pModArray ) ;
    if ( NULL == pModArray )
    {
        return ( FALSE ) ;
    }

    // Bugslaying tip:  Set the memory to a known value that we can
    //  assert against later.
    memset ( pModArray ,
             NULL      ,
             k_INITIAL_MODARRAYSIZE * sizeof ( HMODULE ) ) ;

    // bRet holds BOOLEAN return values.
    BOOL bRet = GetLoadedModules ( GetCurrentProcessId ( ) ,
                                   k_INITIAL_MODARRAYSIZE  ,
                                   pModArray               ,
                                   puiCount                 ) ;
    // Save off the last error so that the assert can still fire and
    //  not change the value.
    DWORD dwLastError = GetLastError ( ) ;
    ASSERT ( TRUE == bRet ) ;

    // Check the return to see if we need to allocate a new buffer and
    //  try and load the values again.
    if ( FALSE == bRet )
    {
        // If the error was anything other than the buffer being too
        //  small, then there is serious trouble going on.
        ASSERT ( ERROR_INSUFFICIENT_BUFFER == dwLastError ) ;
        if ( ERROR_INSUFFICIENT_BUFFER != dwLastError )
        {
            return ( NULL ) ;
        }

        // Check that a decent value was returned for the real count.
        ASSERT ( *puiCount < k_INITIAL_MODARRAYSIZE ) ;
        if ( *puiCount >= k_INITIAL_MODARRAYSIZE )
        {
            return ( FALSE ) ;
        }

        // Get rid of the last buffer.
        free ( pModArray ) ;

        // Allocate a larger array.
        pModArray =
           (HMODULE*)malloc ( k_INITIAL_MODARRAYSIZE *
                                    ( sizeof ( HMODULE ) * 2 ) ) ;

        ASSERT ( NULL != pModArray ) ;
        if ( NULL == pModArray )
        {
            return ( FALSE ) ;
        }

        // Bugslaying tip:  Set the memory to a known value that we can
        //  assert against later.
        memset ( pModArray ,
                 NULL      ,
                 k_INITIAL_MODARRAYSIZE * sizeof ( HMODULE ) * 2 ) ;

        // Try one last time to get the module list.  If there are 512
        //  total DLLs in an executable, the user needs more than help
        //  tracing!
        bRet = GetLoadedModules ( GetCurrentProcessId ( ) ,
                                  k_INITIAL_MODARRAYSIZE  ,
                                  pModArray               ,
                                  puiCount                 ) ;

        // If it failed again, just bail now.
        ASSERT ( TRUE == bRet ) ;
        if ( FALSE == bRet )
        {
            free ( pModArray ) ;
            return ( NULL ) ;
        }
    }
    // All OK, Jumpmaster!
    return ( pModArray ) ;
}

/*----------------------------------------------------------------------
FUNCTION        :   IsHookableDLL
DISCUSSION      :
    Since there are DLLs that should not be hooked, this function helps
determine them.  As it stands now, it only is really concerned with
system DLLs and a minor few others.  If you want to implement a more
flexible scheme, for instance, one that reads in a list from an INI
file, this should be the only function that you need to change.
PARAMETERS      :
    hInst - The HINSTANCE to check.
RETURNS         :
    TRUE  - This is a DLL that can be hooked.
    FALSE - This DLL cannot be hooked.
----------------------------------------------------------------------*/
static BOOL IsHookableDLL ( HINSTANCE hInst )
{
    ASSERT ( NULL != hInst ) ;

    // TODO TODO
    //  Right now, this only looks for the bare minimum.  To speed up
    //  life this needs to get a little smarter and start skipping out
    //  on many of the system DLLs.

    // Do some minor checking to see if this is a valid HINSTANCE.
    //  To really make sure, I should actually look at the PE header.
    ASSERT ( FALSE == IsBadReadPtr ( hInst                       ,
                                     sizeof ( IMAGE_DOS_HEADER )  ) ) ;
    if ( TRUE == IsBadReadPtr ( hInst , sizeof ( IMAGE_DOS_HEADER ) ) )
    {
        return ( FALSE ) ;
    }

    // Is this a system DLL, which Windows95 will not let you patch
    //  since it is above the 2GB line?
    if ( ( FALSE == g_bIsNT ) && ( (DWORD)hInst >= 0x80000000 ) )
    {
        return ( FALSE ) ;
    }


    // Loop through the list of DLLs already processed.  If it is in
    //  there, then return FALSE so it is not patched.
    for ( vector<HMODULE>::iterator i = g_vHookedModules.begin ( ) ;
          i != g_vHookedModules.end ( )                            ;
          i++                                                       )
    {
        if ( hInst == *i )
        {
            return ( FALSE ) ;
        }
    }

    // Hook Away.
    return ( TRUE ) ;
}

/*----------------------------------------------------------------------
FUNCTION        :   InternalODS
DISCUSSION      :
    The internal OutputDebugString handler.  See the "Big Hairy Note"
in the TRACE macro section above.
PARAMETERS      :
    szFmt - The format string.
RETURNS         :
    None.
----------------------------------------------------------------------*/
#ifdef _DEBUG
static void InternalODS ( const char * szFmt , ... )
{
    char szBuff[ 1024 ] ;

    va_list vaList ;
    va_start ( vaList , szFmt ) ;
    int iLen = wvsprintf ( szBuff , szFmt , vaList ) ;
    va_end ( vaList ) ;

#ifdef USE_TRACESRV_INTERNALLY
    if ( NULL != g_lpTrace )
    {
        // Convert the ANSI string to a BSTR and call TraceSrv.
        MultiByteToWideChar ( CP_ACP                           ,
                              0                                ,
                              szBuff                           ,
                              iLen + 1                         ,
                              g_cGlobalBSTR.GetDataBuffer ( )  ,
                              (int)g_cGlobalBSTR.BufferSize ( ) ) ;
        g_cGlobalBSTR.GetStringByteLength ( ) ;
        g_lpTrace->FullTrace ( (BSTR)g_cGlobalBSTR           ,
                               (long)GetCurrentProcessId ( )  ) ;
    }
#endif

    OutputDebugStringA ( szBuff ) ;
}
#endif  // _DEBUG

/*//////////////////////////////////////////////////////////////////////
                   All the hook functions start here!
//////////////////////////////////////////////////////////////////////*/

VOID WINAPI TSH_ExitProcess ( UINT uExitCode )
{
    // If this library is still loaded after ExitProcess, it can get
    //  into states where the message loop and other supports are
    //  already gone so calling through ITrace just hangs the program.
    // To get around any problems, I just hook ExitProcess and shutdown
    //  as the last act of the EXE.  This means that there are some
    //  ODS that could be lost, primarily those that are in DllMain
    //  DLL_PROCESS_DETACH processing and in static destructor
    //  processing.  Serious bummer.
    if ( TRUE == g_bInitialized )
    {
        _CrtDumpMemoryLeaks ( ) ;
        ShutdownTraceSrvHelper ( ) ;
    }
    ExitProcess ( uExitCode ) ;
}

VOID WINAPI TSH_OutputDebugStringA ( LPCSTR lpOutputString )
{
    // Called externally, guard it with the critical section.
    CUseCriticalSection cs ( g_cCritSec ) ;

    if ( TRUE == g_bInitialized )
    {
        if ( NULL != g_lpTrace )
        {
            // Convert the ANSI string to a BSTR and call TraceSrv.
            MultiByteToWideChar ( CP_ACP                           ,
                                  0                                ,
                                  lpOutputString                   ,
                                  -1                               ,
                                  g_cGlobalBSTR.GetDataBuffer ( )  ,
                                  (int)g_cGlobalBSTR.BufferSize ( ) ) ;
            g_cGlobalBSTR.GetStringByteLength ( ) ;
            g_lpTrace->FullTrace ( (BSTR)g_cGlobalBSTR     ,
                                   (long)GetCurrentProcessId ( )  ) ;
        }
    }
    OutputDebugStringA ( lpOutputString ) ;
}

VOID WINAPI TSH_OutputDebugStringW ( LPCWSTR lpOutputString )
{
    // Called externally, guard it with the critical section.
    CUseCriticalSection cs ( g_cCritSec ) ;

    if ( TRUE == g_bInitialized )
    {
        if ( NULL != g_lpTrace )
        {
            // Copy the string and call TraceSrv.
            lstrcpyW ( g_cGlobalBSTR.GetDataBuffer ( ) , lpOutputString ) ;
            g_cGlobalBSTR.GetStringByteLength ( ) ;
            g_lpTrace->FullTrace ( (BSTR)g_cGlobalBSTR          ,
                                   (long)GetCurrentProcessId ( )  ) ;
        }
    }
    OutputDebugStringW ( lpOutputString ) ;
}

HMODULE WINAPI TSH_LoadLibraryA ( LPCSTR lpLibFileName )
{
    // Called externally, guard it with the critical section.
    CUseCriticalSection cs ( g_cCritSec ) ;

    // Just a reminder.
    TRACE1( "Hooked LoadLibraryA being called on %s\n" , lpLibFileName);

    HMODULE hRet = LoadLibraryA ( lpLibFileName ) ;

    if ( TRUE == g_bInitialized )
    {
        // Patch anything that this module might have.  We need to do
        //  all the modules again, because you never know what else this
        //  single module brought in.
        BOOL bRet = TRUE ;
        if ( NULL != hRet )
        {
            bRet = HookTraceSrvHelperFuncs ( k_NUM_HOOKED_FUNCS ,
                                             g_stToHookFuncs    ,
                                             g_pOrigFuncs        ) ;
            ASSERT ( TRUE == bRet ) ;
        }

        if ( FALSE == bRet )
        {
            // Since there is not much we can do here, just let the user
            //  know.
            MessageBox ( GetForegroundWindow ( )  ,
               _T("HookTraceSrvHelperFuncs failed in TSH_LoadLibraryA"),
                         _T ( "TraceSrvHelper!" )  ,
                         MB_OK  | MB_ICONSTOP       ) ;
        }
    }
    return ( hRet ) ;
}

HMODULE WINAPI TSH_LoadLibraryW ( LPCWSTR lpLibFileName )
{
    // Called externally, guard it with the critical section.
    CUseCriticalSection cs ( g_cCritSec ) ;

    // Just a reminder.
    TRACE0( "Hooked LoadLibraryW being called\n" );

    HMODULE hRet = LoadLibraryW ( lpLibFileName ) ;

    if ( TRUE == g_bInitialized )
    {
        // Patch anything that this module might have.  We need to do
        //  all the modules again, because you never know what else this
        //  single module brought in.
        BOOL bRet = TRUE ;
        if ( NULL != hRet )
        {
            bRet = HookTraceSrvHelperFuncs ( k_NUM_HOOKED_FUNCS ,
                                             g_stToHookFuncs    ,
                                             g_pOrigFuncs        ) ;
            ASSERT ( TRUE == bRet ) ;
        }

        if ( FALSE == bRet )
        {
            // Since there is not much we can do here, just let the user
            //  know.
            MessageBox ( GetForegroundWindow ( )  ,
                  _T("HookTraceSrvHelperFuncs failed in TSH_LoadLibraryW") ,
                         _T ( "TraceSrvHelper!" )  ,
                         MB_OK  | MB_ICONSTOP       ) ;
        }
    }
    return ( hRet ) ;
}


HMODULE WINAPI TSH_LoadLibraryExA ( LPCSTR lpLibFileName ,
                                    HANDLE hFile         ,
                                    DWORD  dwFlags        )
{
    // Called externally, guard it with the critical section.
    CUseCriticalSection cs ( g_cCritSec ) ;

    TRACE1 ( "TSH_LoadLibraryExA called on %s\n" , lpLibFileName ) ;

    // Always do the load.
    HMODULE hRet = LoadLibraryExA ( lpLibFileName , hFile , dwFlags ) ;

    if ( TRUE == g_bInitialized )
    {
        // If the dwFlags value is anything but LOAD_LIBRARY_AS_DATAFILE
        //  then I will patch away.
        if ( LOAD_LIBRARY_AS_DATAFILE != dwFlags )
        {
            // Patch anything that this module might have.  We need to
            //  do all the modules again, because you never know what
            //  else this single module brought in.
            BOOL bRet = TRUE ;
            if ( NULL != hRet )
            {
                bRet = HookTraceSrvHelperFuncs ( k_NUM_HOOKED_FUNCS ,
                                                 g_stToHookFuncs    ,
                                                 g_pOrigFuncs        ) ;
                ASSERT ( TRUE == bRet ) ;
            }

            if ( FALSE == bRet )
            {
                // Since there is not much we can do here, just let the
                //  user know.
                MessageBox ( GetForegroundWindow ( )  ,
             _T("HookTraceSrvHelperFuncs failed in TSH_LoadLibraryExA"),
                             _T ( "TraceSrvHelper!" )  ,
                             MB_OK  | MB_ICONSTOP       ) ;
            }
        }
    }
    return ( hRet ) ;
}

HMODULE WINAPI TSH_LoadLibraryExW ( LPCWSTR lpLibFileName ,
                                    HANDLE  hFile         ,
                                    DWORD   dwFlags        )
{
    // Called externally, guard it with the critical section.
    CUseCriticalSection cs ( g_cCritSec ) ;

    TRACE0 ( "TSH_LoadLibraryExW\n" ) ;

    // Always do the load.
    HMODULE hRet = LoadLibraryExW ( lpLibFileName , hFile , dwFlags ) ;

    if ( TRUE == g_bInitialized )
    {
        // If the dwFlags value is anything but LOAD_LIBRARY_AS_DATAFILE
        //  then I will patch away.
        if ( LOAD_LIBRARY_AS_DATAFILE != dwFlags )
        {
            BOOL bRet = TRUE ;
            if ( NULL != hRet )
            {
                bRet = HookTraceSrvHelperFuncs ( k_NUM_HOOKED_FUNCS ,
                                                 g_stToHookFuncs    ,
                                                 g_pOrigFuncs        ) ;
                ASSERT ( TRUE == bRet ) ;
            }

            if ( FALSE == bRet )
            {
                // Since there is not much we can do here, just let the
                //  user know.
                MessageBox ( GetForegroundWindow ( )  ,
             _T("HookTraceSrvHelperFuncs failed in TSH_LoadLibraryExW"),
                             _T ( "TraceSrvHelper!" )  ,
                             MB_OK  | MB_ICONSTOP       ) ;
            }
        }
    }
    return ( hRet ) ;
}

