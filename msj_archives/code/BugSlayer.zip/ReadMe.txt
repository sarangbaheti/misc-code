ReadMe for Feb. '98 BugSlayer Code:

If you have any questions (or debugging tips -- keep'em rollin' in!)
drop me an email at john@jprobbins.com.

Directories:

.\BugslayerUtil         - The common code library for all Bugslayer
                          columns.
.\BugslayerUtil\Tests   - Unit test for BugslayerUtil code.
.\CTest                 - A TraceSrvHelper test program.
.\Include               - The include directory for all shared headers.
.\StaticLinkTest        - A TraceSrvHelper test program.
.\TraceSrv              - The Trace Server Service from the Dec. '97
                          Bugslayer column.
.\TraceSrvHelper        - The automagical trace hooking code for the
                          Feb. '98 column.
.\TraceView             - The trace viewer for TraceSrv.  From the Dec.
                          '97 column.

To Build:

Since VC makefiles are a little problematic, I did not include the .MAK
files.  Open each of .DSW workspaces in order below and build them.  I
wanted to include a master project but for the life of me I cannot see
how to associate two different build targets together.  For example, I
cannot get the "TraceSrv UNICODE Debug" configuration to ever get built
with the "CTest Debug" configuration.  If you know how to do this, set
up a master project and send it to me.

All debug build items will be placed in the .\Output directory.  Release
build items go to the .\Release directory.  These same locations apply
to any and all BugslayerUtil unit tests as well.

Order   - BugSlayerUtil
          TraceSrv
          TraceSrvHelper
          CTest
          StaticLinkTest

