// StaticLinkTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "StaticLinkTest.h"
#include "StaticLinkTestDlg.h"

#include "TraceSrvHelper.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////////////
// CStaticLinkTestDlg dialog

CStaticLinkTestDlg::CStaticLinkTestDlg(CWnd* pParent /*=NULL*/)
: CDialog(CStaticLinkTestDlg::IDD, pParent)
{
    m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
    m_bIsHooked = FALSE ;

}

void CStaticLinkTestDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CStaticLinkTestDlg)
    DDX_Control(pDX, IDS_UNHOOK, m_btnUnHook);
    DDX_Control(pDX, IDC_HOOK, m_btnHook);
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CStaticLinkTestDlg, CDialog)
//{{AFX_MSG_MAP(CStaticLinkTestDlg)
ON_WM_PAINT()
ON_WM_QUERYDRAGICON()
ON_BN_CLICKED(IDC_HOOK, OnHook)
ON_BN_CLICKED(IDC_DOOUTPUTDS, OnDoODS)
ON_BN_CLICKED(IDC_LEAKMEMORY, OnLeakMemory)
ON_BN_CLICKED(IDS_UNHOOK, OnUnhook)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStaticLinkTestDlg message handlers

BOOL CStaticLinkTestDlg::OnInitDialog()
{
    CDialog::OnInitDialog();

    SetIcon(m_hIcon, TRUE);                 // Set big icon
    SetIcon(m_hIcon, FALSE);                // Set small icon

    // TODO: Add extra initialization here

    return TRUE;
}

void CStaticLinkTestDlg::OnPaint()
{
    if (IsIconic())
    {
        CPaintDC dc(this); // device context for painting

        SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

        // Center icon in client rectangle
        int cxIcon = GetSystemMetrics(SM_CXICON);
        int cyIcon = GetSystemMetrics(SM_CYICON);
        CRect rect;
        GetClientRect(&rect);
        int x = (rect.Width() - cxIcon + 1) / 2;
        int y = (rect.Height() - cyIcon + 1) / 2;

        // Draw the icon
        dc.DrawIcon(x, y, m_hIcon);
    }
    else
    {
        CDialog::OnPaint();
    }
}

HCURSOR CStaticLinkTestDlg::OnQueryDragIcon()
{
    return (HCURSOR) m_hIcon;
}

void CStaticLinkTestDlg::OnHook()
{
    m_btnUnHook.EnableWindow ( TRUE ) ;
    m_btnHook.EnableWindow ( FALSE ) ;
    m_bIsHooked = TRUE ;
    INITTRACESRVHELPER ( ) ;
}

void CStaticLinkTestDlg::OnUnhook()
{
    m_btnUnHook.EnableWindow ( FALSE ) ;
    m_btnHook.EnableWindow ( TRUE ) ;
    m_bIsHooked = TRUE ;
    SHUTDOWNTRACESRVHELPER ( ) ;
}

void CStaticLinkTestDlg::OnDoODS()
{
    for ( int i = 0 ; i < 6 ; i++ )
    {
        TRACE ( "StaticLinkTest i = %d\n" , i ) ;
    }
}

void CStaticLinkTestDlg::OnLeakMemory()
{
    char * pLeak = new char [ 20 ] ;
}

void CStaticLinkTestDlg::OnOK()
{
    CDialog::OnOK();
}
