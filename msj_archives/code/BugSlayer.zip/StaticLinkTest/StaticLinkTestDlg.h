// StaticLinkTestDlg.h : header file
//

#if !defined(AFX_STATICLINKTESTDLG)
#define AFX_STATICLINKTESTDLG_H

#if _MSC_VER >= 1000
    #pragma once
#endif // _MSC_VER >= 1000

////////////////////////////////////////////////////////////////////////
// CStaticLinkTestDlg dialog

class CStaticLinkTestDlg : public CDialog
{
// Construction
public:
    CStaticLinkTestDlg(CWnd* pParent = NULL);

// Dialog Data
    //{{AFX_DATA(CStaticLinkTestDlg)
    enum {IDD = IDD_STATICLINKTEST_DIALOG};
    CButton m_btnUnHook;
    CButton m_btnHook;
    // NOTE: the ClassWizard will add data members here
    //}}AFX_DATA

    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CStaticLinkTestDlg)
protected:
    virtual void DoDataExchange(CDataExchange* pDX);
    //}}AFX_VIRTUAL

// Implementation
protected:
    HICON m_hIcon;

    BOOL m_bIsHooked ;

    HINSTANCE m_hInst ;

    // Generated message map functions
    //{{AFX_MSG(CStaticLinkTestDlg)
    virtual BOOL OnInitDialog();
    afx_msg void OnPaint();
    afx_msg HCURSOR OnQueryDragIcon();
    afx_msg void OnHook();
    afx_msg void OnDoODS();
    afx_msg void OnLeakMemory();
    afx_msg void OnUnhook();
    virtual void OnOK();
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

#endif
