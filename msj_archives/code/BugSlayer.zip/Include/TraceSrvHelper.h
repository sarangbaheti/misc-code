/*----------------------------------------------------------------------
  John Robbins - Microsoft Systems Journal Bugslayer Column - Feb '98

    This is the only file that you need to include to get the
automagical TraceSrv hookup into your application.  After including this
file, the just call InitTraceSrvHelper function and from then on, all
of your normal OutputDebugString calls, no matter where they are called,
will be rerouted to TraceSrv.
    Instead of using the functions, InitTraceSrvHelper and
ShutdownTraceSrvHelper, directly, use the INITTRACESRVHELPER and
SHUTDOWNTRACESRVHELPER macros so they can compile away in _DEBUG builds.
----------------------------------------------------------------------*/

#ifndef _TRACESRVHELPER_H
#define _TRACESRVHELPER_H

/*//////////////////////////////////////////////////////////////////////
                            Special Defines
//////////////////////////////////////////////////////////////////////*/
// The defines that set up how the functions or classes are exported or
//  imported.
#ifndef TSRVHELP_DLLINTERFACE
#ifdef BUILDING_TSRVHELP_DLL
#define TSRVHELP_DLLINTERFACE __declspec ( dllexport )
#else
#define TSRVHELP_DLLINTERFACE __declspec ( dllimport )
#endif  // BUILDING_TSRVHELP_DLL
#endif  // TSRVHELP_DLLINTERFACE

// If the functions are not to be used in _DEBUG builds, you can use
//  these macros to make it happen.
#ifdef _DEBUG
#define INITTRACESRVHELPER()          InitTraceSrvHelper()
#define SHUTDOWNTRACESRVHELPER()      ShutdownTraceSrvHelper()
#else
#define INITTRACESRVHELPER()
#define SHUTDOWNTRACESRVHELPER()
#endif

/*//////////////////////////////////////////////////////////////////////
                      C Function Declaration Area
                                 START
//////////////////////////////////////////////////////////////////////*/
#ifdef __cplusplus
extern "C" {
#endif  // _cplusplus

/*----------------------------------------------------------------------
FUNCTION        :   InitTraceSrvHelper
DISCUSSION      :
    Initializes this library to reroute all calls to OutputDebugString
anywhere in you application to the TraceSrv DCOM server.
PARAMETERS      :
    None.
RETURNS         :
    TRUE  - The library was properly initialized or previously
            initialized.
    FALSE - There was a problem, check GetLastError.
----------------------------------------------------------------------*/
BOOL TSRVHELP_DLLINTERFACE InitTraceSrvHelper ( void ) ;

/*----------------------------------------------------------------------
FUNCTION        :   ShutdownTraceSrvHelper
DISCUSSION      :
    Shuts down the library and unhooks anything that was hooked.  If
this is not called, then it is called during DLL unload.
PARAMETERS      :
    None.
RETURNS         :
    TRUE  - The shutdown worked.
    FALSE - There was a serious problem and the system is probably
            unstable.
----------------------------------------------------------------------*/
BOOL TSRVHELP_DLLINTERFACE ShutdownTraceSrvHelper ( void ) ;


#ifdef __cplusplus
}
#endif  // _cplusplus

/*//////////////////////////////////////////////////////////////////////
                                  END
                      C Function Declaration Area
//////////////////////////////////////////////////////////////////////*/

#endif  // _TRACESRVHELPER_H



