// The C test program for TraceSrvHelper.

#include <windows.h>
#include <stdio.h>
#include "TraceSrvHelper.h"

// With fully optimized code, multiple calls to an imported function
//  will get enregistered.  Normally, this is a really good thing.
//  However, when you are testing code that hooks and unhooks items in
//  the import address table, this can get in the way.  To get around
//  the optimizer, I created these helper functions.

void MyODSA ( char * szStr )
{
    OutputDebugStringA ( szStr ) ;
}

void MyODSW ( wchar_t * szStr )
{
    OutputDebugStringW ( szStr ) ;
}

void main ( void )
{
    // Should not see this call in TraceView.
    MyODSA ( "Before InitTraceSrvHelper ( )\n" ) ;
    printf ( "MyODSA ( \"Before InitTraceSrvHelper ( )\\n\" ) ;\n" ) ;
    fflush ( stdout ) ;

    // Hook life as we know it.
    BOOL bRet = InitTraceSrvHelper ( ) ;
    printf ( "BOOL bRet = InitTraceSrvHelper ( ) ;\n" ) ;
    fflush ( stdout ) ;

    // Should see this in TraceView.
    MyODSA ( "After InitTraceSrvHelper ( )\n" ) ;
    printf ( "MyODSA ( \"After InitTraceSrvHelper ( )\\n\" ) ;\n" ) ;
    fflush ( stdout ) ;

    // Should see this in TraceView.
    MyODSW ( L"Wide OutputDebugStringW called!!\r\n" ) ;
    printf ( "MyODSW ( L\"Wide OutputDebugStringW called!!\\r\\n\" ) ;\n" ) ;
    fflush ( stdout ) ;

    // Should see this in TraceView if TraceSrvHelper compiled with
    //  USE_TRACESRV_INTERNALLY defined.
    LoadLibrary ( "CARDS.DLL" ) ;
    printf ( "LoadLibrary ( \"CARDS.DLL\" ) ;\n" ) ;
    fflush ( stdout ) ;

    // Should see this in TraceView if TraceSrvHelper compiled with
    //  USE_TRACESRV_INTERNALLY defined.
    LoadLibraryExW ( L"avicap32.dll" , 0 , 0 ) ;
    printf ( "LoadLibraryExW ( L\"avicap32.dll\" , 0 , 0 ) ;\n" ) ;
    fflush ( stdout ) ;

    // Unhook everything.
    bRet = ShutdownTraceSrvHelper ( ) ;
    printf ( "bRet = ShutdownTraceSrvHelper ( ) ;\n" ) ;
    fflush ( stdout ) ;

    // This should NOT be seen in TraceView.
    MyODSA ( "After ShutdownTraceSrvHelper ( )\n" ) ;
    printf ( "MyODSA ( \"After ShutdownTraceSrvHelper ( )\\n\" ) ;\n" ) ;
    fflush ( stdout ) ;
}
