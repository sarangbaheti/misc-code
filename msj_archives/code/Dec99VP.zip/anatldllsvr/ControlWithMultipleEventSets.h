// ControlWithMultipleEventSets.h : Declaration of the CControlWithMultipleEventSets

#ifndef __CONTROLWITHMULTIPLEEVENTSETS_H_
#define __CONTROLWITHMULTIPLEEVENTSETS_H_

#include "resource.h"       // main symbols
#include <atlctl.h>
#include "AnATLDLLSvrCP.h"


/////////////////////////////////////////////////////////////////////////////
// CControlWithMultipleEventSets
class ATL_NO_VTABLE CControlWithMultipleEventSets : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public IDispatchImpl<IControlWithMultipleEventSets, &IID_IControlWithMultipleEventSets, &LIBID_ANATLDLLSVRLib>,
	public CComControl<CControlWithMultipleEventSets>,
	public IPersistStreamInitImpl<CControlWithMultipleEventSets>,
	public IOleControlImpl<CControlWithMultipleEventSets>,
	public IOleObjectImpl<CControlWithMultipleEventSets>,
	public IOleInPlaceActiveObjectImpl<CControlWithMultipleEventSets>,
	public IViewObjectExImpl<CControlWithMultipleEventSets>,
	public IOleInPlaceObjectWindowlessImpl<CControlWithMultipleEventSets>,
	public IConnectionPointContainerImpl<CControlWithMultipleEventSets>,
	public IPersistStorageImpl<CControlWithMultipleEventSets>,
	public ISpecifyPropertyPagesImpl<CControlWithMultipleEventSets>,
	public IQuickActivateImpl<CControlWithMultipleEventSets>,
	public IDataObjectImpl<CControlWithMultipleEventSets>,
	public IProvideClassInfo2Impl<&CLSID_ControlWithMultipleEventSets, 
				&DIID__IControlWithMultipleEventsEvents, 
				&LIBID_ANATLDLLSVRLib>,
	public IPropertyNotifySinkCP<CControlWithMultipleEventSets>,
	public CComCoClass<CControlWithMultipleEventSets, &CLSID_ControlWithMultipleEventSets>,
	public CProxy_IControlWithMultipleEventsEvents< CControlWithMultipleEventSets >,
	public CProxy_IControlWithMultipleEventsMoreEvents< CControlWithMultipleEventSets >
{
public:
	CControlWithMultipleEventSets()
	{
		m_bWindowOnly = TRUE;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_CONTROLWITHMULTIPLEEVENTSETS)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CControlWithMultipleEventSets)
	COM_INTERFACE_ENTRY(IControlWithMultipleEventSets)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IViewObjectEx)
	COM_INTERFACE_ENTRY(IViewObject2)
	COM_INTERFACE_ENTRY(IViewObject)
	COM_INTERFACE_ENTRY(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceObject)
	COM_INTERFACE_ENTRY2(IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY(IOleControl)
	COM_INTERFACE_ENTRY(IOleObject)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY2(IPersist, IPersistStreamInit)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY(ISpecifyPropertyPages)
	COM_INTERFACE_ENTRY(IQuickActivate)
	COM_INTERFACE_ENTRY(IPersistStorage)
	COM_INTERFACE_ENTRY(IDataObject)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
END_COM_MAP()

BEGIN_PROP_MAP(CControlWithMultipleEventSets)
	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)
	// Example entries
	// PROP_ENTRY("Property Description", dispid, clsid)
	// PROP_PAGE(CLSID_StockColorPage)
END_PROP_MAP()

BEGIN_CONNECTION_POINT_MAP(CControlWithMultipleEventSets)
	CONNECTION_POINT_ENTRY(DIID__IControlWithMultipleEventsEvents)
	CONNECTION_POINT_ENTRY(DIID__IControlWithMultipleEventsMoreEvents)
	CONNECTION_POINT_ENTRY(IID_IPropertyNotifySink)
END_CONNECTION_POINT_MAP()

BEGIN_MSG_MAP(CControlWithMultipleEventSets)
	MESSAGE_HANDLER(WM_TIMER, OnTimer)
	MESSAGE_HANDLER(WM_CREATE, OnCreate)
	CHAIN_MSG_MAP(CComControl<CControlWithMultipleEventSets>)
	DEFAULT_REFLECTION_HANDLER()
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);



// IViewObjectEx
	DECLARE_VIEW_STATUS(VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE)

// IControlWithMultipleEventSets
public:

	HRESULT OnDraw(ATL_DRAWINFO& di)
	{
		RECT& rc = *(RECT*)di.prcBounds;
		Rectangle(di.hdcDraw, rc.left, rc.top, rc.right, rc.bottom);

		SetTextAlign(di.hdcDraw, TA_CENTER|TA_BASELINE);
		LPCTSTR pszText = _T("ATL 3.0 : ControlWithMultipleEventSets");
		TextOut(di.hdcDraw, 
			(rc.left + rc.right) / 2, 
			(rc.top + rc.bottom) / 2, 
			pszText, 
			lstrlen(pszText));

		return S_OK;
	}

	LRESULT OnTimer(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		// TODO : Add Code for message handler. Call DefWindowProc if necessary
		Fire_Event1();
		Fire_Event2();
		Fire_Event3();
		Fire_Event4();
		return 0;
	}
	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		SetTimer(1, 2000);
		return 0;
	}
};

#endif //__CONTROLWITHMULTIPLEEVENTSETS_H_
