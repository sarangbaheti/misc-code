// ControlWithMultipleEventSets.cpp : Implementation of CControlWithMultipleEventSets

#include "stdafx.h"
#include "AnATLDLLSvr.h"
#include "ControlWithMultipleEventSets.h"

/////////////////////////////////////////////////////////////////////////////
// CControlWithMultipleEventSets

