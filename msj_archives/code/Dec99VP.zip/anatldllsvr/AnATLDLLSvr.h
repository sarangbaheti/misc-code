/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Sep 13 08:54:27 1999
 */
/* Compiler settings for D:\AnATLDLLSvr\AnATLDLLSvr.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __AnATLDLLSvr_h__
#define __AnATLDLLSvr_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IControlWithMultipleEventSets_FWD_DEFINED__
#define __IControlWithMultipleEventSets_FWD_DEFINED__
typedef interface IControlWithMultipleEventSets IControlWithMultipleEventSets;
#endif 	/* __IControlWithMultipleEventSets_FWD_DEFINED__ */


#ifndef ___IControlWithMultipleEventsEvents_FWD_DEFINED__
#define ___IControlWithMultipleEventsEvents_FWD_DEFINED__
typedef interface _IControlWithMultipleEventsEvents _IControlWithMultipleEventsEvents;
#endif 	/* ___IControlWithMultipleEventsEvents_FWD_DEFINED__ */


#ifndef ___IControlWithMultipleEventsMoreEvents_FWD_DEFINED__
#define ___IControlWithMultipleEventsMoreEvents_FWD_DEFINED__
typedef interface _IControlWithMultipleEventsMoreEvents _IControlWithMultipleEventsMoreEvents;
#endif 	/* ___IControlWithMultipleEventsMoreEvents_FWD_DEFINED__ */


#ifndef __ControlWithMultipleEventSets_FWD_DEFINED__
#define __ControlWithMultipleEventSets_FWD_DEFINED__

#ifdef __cplusplus
typedef class ControlWithMultipleEventSets ControlWithMultipleEventSets;
#else
typedef struct ControlWithMultipleEventSets ControlWithMultipleEventSets;
#endif /* __cplusplus */

#endif 	/* __ControlWithMultipleEventSets_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IControlWithMultipleEventSets_INTERFACE_DEFINED__
#define __IControlWithMultipleEventSets_INTERFACE_DEFINED__

/* interface IControlWithMultipleEventSets */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IControlWithMultipleEventSets;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("1A6BFADE-6412-11D3-805E-90DF64000000")
    IControlWithMultipleEventSets : public IDispatch
    {
    public:
    };
    
#else 	/* C style interface */

    typedef struct IControlWithMultipleEventSetsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IControlWithMultipleEventSets __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IControlWithMultipleEventSets __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IControlWithMultipleEventSets __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IControlWithMultipleEventSets __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IControlWithMultipleEventSets __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IControlWithMultipleEventSets __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IControlWithMultipleEventSets __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } IControlWithMultipleEventSetsVtbl;

    interface IControlWithMultipleEventSets
    {
        CONST_VTBL struct IControlWithMultipleEventSetsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IControlWithMultipleEventSets_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IControlWithMultipleEventSets_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IControlWithMultipleEventSets_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IControlWithMultipleEventSets_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IControlWithMultipleEventSets_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IControlWithMultipleEventSets_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IControlWithMultipleEventSets_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IControlWithMultipleEventSets_INTERFACE_DEFINED__ */



#ifndef __ANATLDLLSVRLib_LIBRARY_DEFINED__
#define __ANATLDLLSVRLib_LIBRARY_DEFINED__

/* library ANATLDLLSVRLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_ANATLDLLSVRLib;

#ifndef ___IControlWithMultipleEventsEvents_DISPINTERFACE_DEFINED__
#define ___IControlWithMultipleEventsEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IControlWithMultipleEventsEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IControlWithMultipleEventsEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("174B9DAF-62D1-11D3-805D-06EA09000000")
    _IControlWithMultipleEventsEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IControlWithMultipleEventsEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _IControlWithMultipleEventsEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _IControlWithMultipleEventsEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _IControlWithMultipleEventsEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _IControlWithMultipleEventsEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _IControlWithMultipleEventsEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _IControlWithMultipleEventsEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _IControlWithMultipleEventsEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _IControlWithMultipleEventsEventsVtbl;

    interface _IControlWithMultipleEventsEvents
    {
        CONST_VTBL struct _IControlWithMultipleEventsEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IControlWithMultipleEventsEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IControlWithMultipleEventsEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IControlWithMultipleEventsEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IControlWithMultipleEventsEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IControlWithMultipleEventsEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IControlWithMultipleEventsEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IControlWithMultipleEventsEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IControlWithMultipleEventsEvents_DISPINTERFACE_DEFINED__ */


#ifndef ___IControlWithMultipleEventsMoreEvents_DISPINTERFACE_DEFINED__
#define ___IControlWithMultipleEventsMoreEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IControlWithMultipleEventsMoreEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IControlWithMultipleEventsMoreEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("174B9DAF-FFFF-11D3-805D-06EA09000000")
    _IControlWithMultipleEventsMoreEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IControlWithMultipleEventsMoreEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _IControlWithMultipleEventsMoreEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _IControlWithMultipleEventsMoreEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _IControlWithMultipleEventsMoreEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _IControlWithMultipleEventsMoreEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _IControlWithMultipleEventsMoreEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _IControlWithMultipleEventsMoreEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _IControlWithMultipleEventsMoreEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _IControlWithMultipleEventsMoreEventsVtbl;

    interface _IControlWithMultipleEventsMoreEvents
    {
        CONST_VTBL struct _IControlWithMultipleEventsMoreEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IControlWithMultipleEventsMoreEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IControlWithMultipleEventsMoreEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IControlWithMultipleEventsMoreEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IControlWithMultipleEventsMoreEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IControlWithMultipleEventsMoreEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IControlWithMultipleEventsMoreEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IControlWithMultipleEventsMoreEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IControlWithMultipleEventsMoreEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_ControlWithMultipleEventSets;

#ifdef __cplusplus

class DECLSPEC_UUID("174B9DAE-62D1-11D3-805D-06EA09000000")
ControlWithMultipleEventSets;
#endif
#endif /* __ANATLDLLSVRLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
