// ATLUseMultipleEventSets.cpp : Implementation of WinMain


#include "stdafx.h"
#include "resource.h"
#include <initguid.h>
#include "ATLUseMultipleEventSets.h"
#include "atlwin.h"
#include "ATLUseMultipleEventSets_i.c"

// include the event IIDs and interface defs
#include "\anatldllsvr\anatldllsvr.h"
#include "\anatldllsvr\anatldllsvr_i.c"


//DIID__IControlWithMultipleEventsMoreEvents

class EventSink1: 
	public IDispEventImpl<1, 
						EventSink1, 
						&DIID__IControlWithMultipleEventsEvents, 
						&LIBID_ANATLDLLSVRLib, 1, 0>
{ 
public:
	BEGIN_SINK_MAP(EventSink1)
		SINK_ENTRY_EX(1, 
						DIID__IControlWithMultipleEventsEvents, 
						1, 
						OnEvent1)
		SINK_ENTRY_EX(1, 
						DIID__IControlWithMultipleEventsEvents, 
						2, 
						OnEvent2)
	END_SINK_MAP()	

	void __stdcall OnEvent1()
	{
		OutputDebugString("Firing Event 1\n");
	}

	void __stdcall OnEvent2()
	{
		OutputDebugString("Firing Event 2\n");
	}
};

class EventSink2: 
	public IDispEventImpl<1, 
						EventSink2, 
						&DIID__IControlWithMultipleEventsMoreEvents, 
						&LIBID_ANATLDLLSVRLib, 1, 0>
{ 
public:
	BEGIN_SINK_MAP(EventSink2)
		SINK_ENTRY_EX(1, 
						DIID__IControlWithMultipleEventsMoreEvents, 
						1, 
						OnEvent3)
		SINK_ENTRY_EX(1, 
						DIID__IControlWithMultipleEventsMoreEvents, 
						2, 
						OnEvent4)
	END_SINK_MAP()	

	void __stdcall OnEvent3()
	{
		OutputDebugString("Firing Event 3\n");
	}

	void __stdcall OnEvent4()
	{
		OutputDebugString("Firing Event 4\n");
	}
};

class CMainWindow : public CWindowImpl<CMainWindow>
{
protected:
	CAxWindow m_HostWindow;

	EventSink1 m_EventSink1;
	EventSink2 m_EventSink2;
	IUnknown* m_pUnk;

public:
	CMainWindow()
	{
		m_pUnk = 0;
	}

BEGIN_MSG_MAP(CMainWindow)
  MESSAGE_HANDLER(WM_PAINT, OnPaint)
  MESSAGE_HANDLER(WM_CREATE, OnCreate)
  MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
  COMMAND_ID_HANDLER(ID_FILE_EXIT, OnFileExit)
END_MSG_MAP()

	DECLARE_WND_CLASS(NULL)

	LRESULT OnCreate(UINT uMsg, WPARAM wParam,
					LPARAM lParam, BOOL& bHandled)
	{
		RECT r;	

		GetClientRect(&r);
		
		HWND hWnd = NULL;
		
		hWnd = m_HostWindow.Create(m_hWnd, r,
			_TEXT("{174B9DAE-62D1-11D3-805D-06EA09000000}"),
			WS_CHILD | WS_VISIBLE);

		HRESULT hr;

		hr = m_HostWindow.QueryControl(IID_IUnknown, (void**)&m_pUnk);
		
		if(SUCCEEDED(hr))
		{
			hr = m_EventSink1.DispEventAdvise(m_pUnk);
			hr = m_EventSink2.DispEventAdvise(m_pUnk);
		}

		bHandled = TRUE;
		return 0;
	}

	LRESULT OnDestroy(UINT uMsg, WPARAM wParam,
					LPARAM lParam, BOOL& bHandled)
	{
		m_EventSink1.DispEventUnadvise(m_pUnk);
		m_EventSink2.DispEventUnadvise(m_pUnk);

		if(m_pUnk)
		{
			m_pUnk->Release();
		}
		PostQuitMessage(0);
		bHandled = TRUE;
		return 0;
	}
	
	LRESULT OnPaint(UINT uMsg, WPARAM wParam,
					LPARAM lParam, BOOL& bHandled)
	{
		PAINTSTRUCT ps;
		HDC hDC = BeginPaint(&ps);

		EndPaint(&ps);
		bHandled = TRUE;
		return 0;
	}

	LRESULT OnFileExit(WORD wNotifyCode, WORD wID,
						HWND hWndCtl, BOOL& bHandled)
	{
		bHandled = TRUE;
		return 0;
	}
};

CExeModule _Module;

/////////////////////////////////////////////////////////////////////////////
//
extern "C" int WINAPI _tWinMain(HINSTANCE hInstance, 
    HINSTANCE /*hPrevInstance*/, LPTSTR lpCmdLine, int /*nShowCmd*/)
{
    HRESULT hRes = CoInitialize(NULL);
    _ASSERTE(SUCCEEDED(hRes));
    _Module.Init(NULL, hInstance, &LIBID_ATLUSEMULTIPLEEVENTSETSLib);
    _Module.dwThreadID = GetCurrentThreadId();

	// Initialize the ATL control containment...
	//  Create the Window...
	AtlAxWinInit();

	RECT rcPos = { CW_USEDEFAULT };
	HMENU hMenu = LoadMenu(_Module.m_hInst,
		                   MAKEINTRESOURCE(IDR_MENU));
	CMainWindow wndMain;
	wndMain.Create(GetDesktopWindow(), rcPos, _T("Hi"),
					WS_VISIBLE | WS_OVERLAPPEDWINDOW, 0,	
					(UINT)hMenu);
	wndMain.ShowWindow(SW_SHOWNORMAL);
	wndMain.UpdateWindow();

    int nRet = 0;
    BOOL bRun = TRUE;

    if (bRun)
    {
        MSG msg;
        while (GetMessage(&msg, 0, 0, 0))
            DispatchMessage(&msg);

    }

    _Module.Term();
    CoUninitialize();
    return nRet;
}
