#if !defined(AFX_EVENTSINKIMPL_H__92215696_65A1_11D3_805F_CE8BAC000000__INCLUDED_)
#define AFX_EVENTSINKIMPL_H__92215696_65A1_11D3_805F_CE8BAC000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EventSinkImpl.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// EventSinkImpl command target

class EventSinkImpl : public CCmdTarget
{
	DECLARE_DYNCREATE(EventSinkImpl)

	EventSinkImpl();           // protected constructor used by dynamic creation


// Attributes
public:

// Operations
public:
	virtual ~EventSinkImpl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(EventSinkImpl)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(EventSinkImpl)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(EventSinkImpl)
	afx_msg void Event3();
	afx_msg void Event4();
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EVENTSINKIMPL_H__92215696_65A1_11D3_805F_CE8BAC000000__INCLUDED_)
