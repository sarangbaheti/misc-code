// EventSinkImpl.cpp : implementation file
//

#include "stdafx.h"

// include the event IIDs and interface defs
#include "\anatldllsvr\anatldllsvr_i.c"

#include "MFCUsemultipleeventsets.h"
#include "EventSinkImpl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// EventSinkImpl

IMPLEMENT_DYNCREATE(EventSinkImpl, CCmdTarget)

EventSinkImpl::EventSinkImpl()
{
	EnableAutomation();
}

EventSinkImpl::~EventSinkImpl()
{
}


void EventSinkImpl::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}


BEGIN_MESSAGE_MAP(EventSinkImpl, CCmdTarget)
	//{{AFX_MSG_MAP(EventSinkImpl)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(EventSinkImpl, CCmdTarget)
	//{{AFX_DISPATCH_MAP(EventSinkImpl)
	DISP_FUNCTION(EventSinkImpl, "Event3", Event3, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION(EventSinkImpl, "Event4", Event4, VT_EMPTY, VTS_NONE)
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IEventSinkImpl to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {92215695-65A1-11D3-805F-CE8BAC000000}
static const IID IID_IEventSinkImpl =
{ 0x92215695, 0x65a1, 0x11d3, { 0x80, 0x5f, 0xce, 0x8b, 0xac, 0x0, 0x0, 0x0 } };

BEGIN_INTERFACE_MAP(EventSinkImpl, CCmdTarget)
	INTERFACE_PART(EventSinkImpl, DIID__IControlWithMultipleEventsMoreEvents, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// EventSinkImpl message handlers

void EventSinkImpl::Event3() 
{
	OutputDebugString("Receiving Event3\n");
}

void EventSinkImpl::Event4() 
{
	OutputDebugString("Receiving Event4\n");
}
