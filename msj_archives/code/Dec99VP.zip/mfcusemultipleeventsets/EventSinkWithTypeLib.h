#include "stdafx.h"

#include "\anatldllsvr\anatldllsvr.h"
#include "\anatldllsvr\anatldllsvr_i.c"

class CEventSinkWithTypeLib
{
public:

	IDispatch* m_pDisp;
	ULONG m_cRef;
	ITypeInfo* m_pti;

	CEventSinkWithTypeLib()
	{
		m_pti = NULL;
		ITypeLib* ptl = NULL;
		HRESULT hr = LoadTypeLib(L"\anatldllsvr\anatldllsvr.tlb", &ptl);
		if(SUCCEEDED(hr))
		{
			hr = ptl->GetTypeInfoOfGuid(DIID__IControlWithMultipleEventsMoreEvents, &m_pti);
			hr = CreateStdDispatch(NULL, 
		}
		m_cRef = 0;
	}

	virtual ~CEventSinkWithTypeLib()
	{
		if(m_pti)
		{
			m_pti->Release();
		}
	}

	STDMETHODIMP QueryInterface(REFFID riid, void** ppv)
	{
		if(riid == IID_IUnknown |
			riid == IID_IDispatch |
			riid == DIID__IControlWithMultipleEventsMoreEvents)
		{
			*ppv = static_cast<IDispatch*>(this);
		} else
		{
			*ppv = 0;
		}

		if(*ppv)
		{
			((IUnknown*)(*ppv))->AddRef();
			return S_OK;
		} else
		{
			return E_NOINTERFACE
		}
	}
	STDMETHODIMP_(ULONG) AddRef()
	{
		m_cRef++;
		return m_cRef;
	}
	STDMETHODIMP_(ULONG) Release()
	{
		m_cRef--;
		if(!m_cRef)
		{
			delete this;
			return 0;
		} else
		{
			return m_cRef;
		}
	}

	STDMETHODIMP GetTypeInfoCount(UINT *pctinfo)
	{
		if(m_pti)
		{
			*pctinfo = 1;
		} else
		{
			*pctinfo = 0;
		}

		return S_OK;
	}

	STDMETHODIMP GetTypeInfo(UINT iTypeInfo, LCID, ITypeInfo** ppti)
	{
		if(iTypeInfo = 1)
		{
			*ppti = m_pti;
			m_pti->AddRef();
			return S_OK;
		} else
		{
			*ppti = 0;
			return E_FAIL;
		}
	}
};