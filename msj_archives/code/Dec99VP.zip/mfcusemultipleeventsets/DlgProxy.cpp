// DlgProxy.cpp : implementation file
//

#include "stdafx.h"
#include "MFCUsemultipleeventsets.h"
#include "DlgProxy.h"
#include "MFCUsemultipleeventsetsDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMFCUsemultipleeventsetsDlgAutoProxy

IMPLEMENT_DYNCREATE(CMFCUsemultipleeventsetsDlgAutoProxy, CCmdTarget)

CMFCUsemultipleeventsetsDlgAutoProxy::CMFCUsemultipleeventsetsDlgAutoProxy()
{
	EnableAutomation();
	
	// To keep the application running as long as an automation 
	//	object is active, the constructor calls AfxOleLockApp.
	AfxOleLockApp();

	// Get access to the dialog through the application's
	//  main window pointer.  Set the proxy's internal pointer
	//  to point to the dialog, and set the dialog's back pointer to
	//  this proxy.
	ASSERT (AfxGetApp()->m_pMainWnd != NULL);
	ASSERT_VALID (AfxGetApp()->m_pMainWnd);
	ASSERT_KINDOF(CMFCUsemultipleeventsetsDlg, AfxGetApp()->m_pMainWnd);
	m_pDialog = (CMFCUsemultipleeventsetsDlg*) AfxGetApp()->m_pMainWnd;
	m_pDialog->m_pAutoProxy = this;
}

CMFCUsemultipleeventsetsDlgAutoProxy::~CMFCUsemultipleeventsetsDlgAutoProxy()
{
	// To terminate the application when all objects created with
	// 	with automation, the destructor calls AfxOleUnlockApp.
	//  Among other things, this will destroy the main dialog
	if (m_pDialog != NULL)
		m_pDialog->m_pAutoProxy = NULL;
	AfxOleUnlockApp();
}

void CMFCUsemultipleeventsetsDlgAutoProxy::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}

BEGIN_MESSAGE_MAP(CMFCUsemultipleeventsetsDlgAutoProxy, CCmdTarget)
	//{{AFX_MSG_MAP(CMFCUsemultipleeventsetsDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CMFCUsemultipleeventsetsDlgAutoProxy, CCmdTarget)
	//{{AFX_DISPATCH_MAP(CMFCUsemultipleeventsetsDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IMFCUsemultipleeventsets to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {09468CF5-62F6-11D3-805D-06EA09000000}
static const IID IID_IMFCUsemultipleeventsets =
{ 0x9468cf5, 0x62f6, 0x11d3, { 0x80, 0x5d, 0x6, 0xea, 0x9, 0x0, 0x0, 0x0 } };

BEGIN_INTERFACE_MAP(CMFCUsemultipleeventsetsDlgAutoProxy, CCmdTarget)
	INTERFACE_PART(CMFCUsemultipleeventsetsDlgAutoProxy, IID_IMFCUsemultipleeventsets, Dispatch)
END_INTERFACE_MAP()

// The IMPLEMENT_OLECREATE2 macro is defined in StdAfx.h of this project
// {09468CF3-62F6-11D3-805D-06EA09000000}
IMPLEMENT_OLECREATE2(CMFCUsemultipleeventsetsDlgAutoProxy, "MFCUsemultipleeventsets.Application", 0x9468cf3, 0x62f6, 0x11d3, 0x80, 0x5d, 0x6, 0xea, 0x9, 0x0, 0x0, 0x0)

/////////////////////////////////////////////////////////////////////////////
// CMFCUsemultipleeventsetsDlgAutoProxy message handlers
