#include <windows.h>
#include <httpext.h>
#include <stdio.h> 
#include <stdarg.h>

#define REGKEY "System\\CurrentControlSet\\Services\\W3SVC\\SSI"
#define ISWHITE( ch )      ((ch) && ((ch) == ' ' || (ch) == '\t' ||  \
                            (ch) == '\n' || (ch) == '\r'))



CHAR cVarChar = '@', *lpDataDict  = NULL; // Even though it is a global, it can only be read from
                          // multiple threads.

DWORD GetValueFromTag (CHAR *szVal, CHAR *szTag, EXTENSION_CONTROL_BLOCK *pECB);

#ifdef _DEBUG
    void DebugOut (CHAR *lpszFmt, ...)
    {
	    CHAR szBuff[1024];

	    va_list vargs;
	    va_start (vargs,lpszFmt);
	    vsprintf (szBuff, lpszFmt, vargs);
	    va_end (vargs);
	    
	    OutputDebugString (szBuff);
	    return;
    }
#else
    void DebugOut (CHAR *lpszFmt, ...)
    {  
        return;
    }
#endif

BOOL   WINAPI   DllMain (HANDLE hInst, 
                        ULONG ul_reason_for_call,
                        LPVOID lpReserved)

{
    if (ul_reason_for_call == DLL_PROCESS_DETACH)
	{
            DebugOut ("DLL_PROCESS_DETACH for instance: 0x%X\n", hInst);
			LocalFree (lpDataDict);
	}
    return TRUE;
}



/****************************************************************************
*
*   FUNCTION: GetExtensionVersion
*   
*   PURPOSE:  Standart procedure which needs to be exported from the DLL.
*   
*   PARAMETRS: 
*             pVer - pointer to version information structure.
*
*   RETURN:   BOOL
*
*   COMMENTS: Will be called by the server.
*
****************************************************************************/

BOOL WINAPI GetExtensionVersion (HSE_VERSION_INFO *pVer)
{

    // We will open a dictinary file here and will read its
    // content into the global memory.
    //
    // If for any reason we can't do it, set the global pointer to 0;

    HANDLE hFileDict;
    DWORD dwSizeDict, dwError, dwRead;
    int i = 0;
    HKEY hKey;
    CHAR szDictFile [256], temp[2];

    pVer->dwExtensionVersion = MAKELONG(HSE_VERSION_MINOR, HSE_VERSION_MAJOR);
    lstrcpyn(pVer->lpszExtensionDesc,"HTTP SSI Application",
             HSE_MAX_EXT_DLL_NAME_LEN );


   	if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE,REGKEY,0,KEY_READ,&hKey))
	{
		// We don't care if we  can't read reg
        dwRead = sizeof (temp);
        if (RegQueryValueEx (hKey, "VariableCharacter", NULL, NULL, (LPBYTE) temp, &dwRead) == ERROR_SUCCESS)
            cVarChar = temp[0];

        dwRead = sizeof (szDictFile);
		if (RegQueryValueEx (hKey, "DictFile", NULL, NULL, (LPBYTE) szDictFile, &dwRead) != ERROR_SUCCESS)
        {
            DebugOut ("Can't get reg value DictFile, error: %d\n", GetLastError());
            return TRUE;
        }
 
	}
    else
    {
        DebugOut ("Could not read registry.\n, No data read, vachar is @\n");
        return TRUE;
    }
    RegCloseKey (hKey);

    Again:
    dwError = GetLastError();
    hFileDict = CreateFile(szDictFile, GENERIC_READ, 
          FILE_SHARE_READ | FILE_SHARE_WRITE, (LPSECURITY_ATTRIBUTES) NULL, 
         OPEN_EXISTING, FILE_ATTRIBUTE_READONLY,  (HANDLE) NULL);
    if  ( (hFileDict == INVALID_HANDLE_VALUE) && (dwError == ERROR_SHARING_VIOLATION))
    {
        DebugOut ("File: %s is locked (sharing). Still trying...\n", szDictFile);
    	Sleep (100);
        i++;
        if (i>3)
            goto Again;
        else
        {
            lpDataDict = NULL;
            return TRUE;
        }

    }
    else if ( (hFileDict == INVALID_HANDLE_VALUE) && (dwError != ERROR_SHARING_VIOLATION))
    {
        DebugOut ("Error opening: %s Error: %d\n", szDictFile);
        lpDataDict = NULL;
        return TRUE;
    }
    dwSizeDict = GetFileSize (hFileDict, NULL); 
    lpDataDict = (CHAR *) LocalAlloc (LPTR, dwSizeDict + 1 );

    i=0;
    AgainRead:
    if (!ReadFile (hFileDict, lpDataDict, dwSizeDict, &dwRead, NULL))
    {
        if  ( (dwError = GetLastError()) == ERROR_LOCK_VIOLATION)
        {                
            DebugOut ("File: %s is locked (lock). Still trying...\n", szDictFile);
            Sleep (100);
            if (i>3)
                goto AgainRead;
            else
            {
                lpDataDict = NULL;
                return TRUE;
            }
    
        }
        else
        {
            DebugOut ("Error opening: %s Error: %d\n",szDictFile,dwError);
            lpDataDict = NULL;
            return TRUE;
 
        }
    }   
    CloseHandle (hFileDict);
    lpDataDict [dwRead] = '\0';

    DebugOut ("Dictionary file %s is read into memory\n", szDictFile);
    return TRUE;
} // GetExtensionVersion()



/****************************************************************************
*
*   FUNCTION: HttpExtensionProc
*   
*   PURPOSE:  Standart procedure which needs to be exported from the DLL.
*   
*   PARAMETRS: 
*             pECB - pointer to version extension control block.
*
*   RETURN:   DWORD, status code.
*
*   COMMENTS: Will be called by the server.
*
****************************************************************************/

DWORD WINAPI HttpExtensionProc (EXTENSION_CONTROL_BLOCK *pECB)
{
    HANDLE hFile;
    DWORD dwLen=0, dwError, dwSize, dwRead;
    int i = 0;
    CHAR *lpData = NULL, *lpIncStart, *lpIncEnd,  *lpDataForDelete;
    CHAR szTagBuffer[256], szValueBuffer [256];
    CHAR szBuff [256];



    DebugOut ("Opening file: %s for HTML\n", pECB->lpszPathTranslated);

    Again:
 
    hFile = CreateFile(pECB->lpszPathTranslated, GENERIC_READ, 
         FILE_SHARE_READ | FILE_SHARE_WRITE, (LPSECURITY_ATTRIBUTES) NULL, 
         OPEN_EXISTING, FILE_ATTRIBUTE_READONLY,  (HANDLE) NULL);
    
    dwError = GetLastError();

    if  ( (hFile == INVALID_HANDLE_VALUE) && (dwError == ERROR_SHARING_VIOLATION))
    {
        DebugOut ("File: %s is locked (sharing). Still trying...\n", pECB->lpszPathTranslated);
    	Sleep (100);
        i++;
        if (i>3)
            goto Again;
        else
            return HSE_STATUS_ERROR;

    }
    else if ( (hFile == INVALID_HANDLE_VALUE) && (dwError != ERROR_SHARING_VIOLATION))
    {
        DebugOut ("Error opening: %s Error: %d\n", pECB->lpszPathTranslated,dwError);
        return HSE_STATUS_ERROR;
    }
     
    dwSize = GetFileSize (hFile, NULL);
    lpData = (CHAR *) LocalAlloc (LPTR, dwSize + 1 );

    i=0;
    AgainRead:
    if (!ReadFile (hFile, lpData, dwSize, &dwRead, NULL))
    {
        if  ( (dwError = GetLastError()) == ERROR_LOCK_VIOLATION)
        {                
            DebugOut ("File: %s is locked (lock). Still trying...\n", pECB->lpszPathTranslated);
            Sleep (100);
            if (i>3)
                goto AgainRead;
            else
                return HSE_STATUS_ERROR;

        }
        else
        {
            DebugOut ("Error opening: %s Error: %d\n", pECB->lpszPathTranslated,dwError);
            return HSE_STATUS_ERROR;
        }
    }
    CloseHandle (hFile);

    lpData[dwRead] = '\0';
    // we will loose lpData as we parse the file.
    // preserve its value for buffer deletion.

    lpDataForDelete = lpData;

   

    wsprintf ( szBuff, "Content-Type: text/html\r\n\r\n");
    dwLen = lstrlen ( szBuff );
    pECB -> ServerSupportFunction ( pECB -> ConnID,
    		                        HSE_REQ_SEND_RESPONSE_HEADER, 
                                    "200 OK",
                                    &dwLen, 
                                    (LPDWORD) szBuff );


    
    // this is a <!-- #TAG --> sample

    while ( (lpIncStart = strstr (lpData, "<!--")) != NULL )
    {
        // print stuff before <!--
        dwSize = (lpIncStart - lpData) / sizeof (CHAR);
        pECB -> WriteClient (pECB -> ConnID, lpData, &dwSize, 0);
        
         // find end of tag -->
        if ( (lpIncEnd = strstr (lpData, "-->")) == NULL )
        {
            // we did not find end of tag bail out
            DebugOut ("No --> found. Bailing out\n");
            dwSize = lstrlen (lpData);
            pECB -> WriteClient (pECB -> ConnID, lpData, &dwSize, 0);
            return HSE_STATUS_SUCCESS;
        }
        
         // move lpData to the beggining of the tag
        lpData = lpIncStart + lstrlen ("<!--");
        while ( ISWHITE( *lpData ) )
            lpData++;




        // start coping the tag buffer
        i = 0;
        while ( ( !ISWHITE (*lpData)) && (lpData != lpIncEnd) )
            szTagBuffer[i++] = *lpData++;
        szTagBuffer[i]='\0';
        DebugOut ("Tag found: %s\n", szTagBuffer);
        
        lpData= lpIncEnd + lstrlen ("-->");
        // output proper value here
        if (szTagBuffer[0] == '#')
        {
            // it was a tag, get rid of the #
            CHAR *p = szTagBuffer + sizeof (CHAR);
            DebugOut ("Looking up: %s\n", p);

            dwSize = GetValueFromTag (szValueBuffer, p, pECB);
            pECB -> WriteClient (pECB -> ConnID, szValueBuffer, &dwSize, 0);
        } 
        else
        {
            // it was a comment, just print it
            DebugOut ("Comment found (not a tag)\n");
            dwSize = (lpData - lpIncStart) / sizeof (CHAR);
            pECB -> WriteClient (pECB -> ConnID, lpIncStart, &dwSize, 0);
        }

        
    }

    dwSize = lstrlen (lpData);
    pECB -> WriteClient (pECB -> ConnID, lpData, &dwSize, 0);

 
    LocalFree (lpDataForDelete);


 	return HSE_STATUS_SUCCESS;
}



DWORD GetValueFromTag (CHAR *szValue, CHAR *szTag, EXTENSION_CONTROL_BLOCK *pECB)
{
    // we are assuming that out dicrtanry file is small enough to fit
    // into memory. This is a datafile format:

    // TaG2 = This_is_tag2

    // Tags proceeded with @ are the server variables.
	// Tags can't have spaces.

    DWORD dwLen = 256, dwError, dwTag = lstrlen (szTag);
    CHAR * pch = lpDataDict;
    CHAR *p;
    int i;


    if ( *szTag == cVarChar )
    {
        p=szTag + sizeof (CHAR);
        // This is a server variable 
        if ( !pECB -> GetServerVariable (pECB -> ConnID,   // Connection id
                                 p,        // Variable  
                                 szValue,             // Buffer 
                                 &dwLen))          // Length
	    {	
    	    if ( (dwError= GetLastError ()) == ERROR_INVALID_INDEX  )
			    wsprintf  ( szValue, "<br><i>Variable %s does not exist. Please notify Webmaster about this.</i><br>", p);
            else
			    wsprintf  ( szValue, "<br><i>Error %d occured while getting %s variable</i><br>", dwError, p);

	    }

    }
    else
    {
        p=szTag;
        // this is a real tag. Do nasty job of looking for it.
        if ( !pch )
        {
            // Our buffer is empty
            wsprintf  ( szValue, "<br><i>Can't find match for %s</i><br>", p);
            return lstrlen (szValue);
        }

        while (*pch)
        {
            while ( ISWHITE( *pch ) )
                pch++;

            if ( toupper( *pch ) == toupper( *szTag ) &&
                 !strnicmp( szTag, pch, dwTag )     &&
                 ( pch [dwTag] == ' ' || pch [dwTag] == '=') )
            {
                pch += dwTag + 1;
                goto Found;
            }

            pch = strchr( pch+1, '\n' );
        }
        Found:
        while ( ISWHITE( *pch ) || *pch == '=')
            pch++;

  


        i = 0;
        while ( ( *pch != '\n' ) && (i < 256) )
            szValue [i++] = *pch++;
        szValue[i] = '\0';
        
    }

    return lstrlen (szValue);
}

