//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CancelApp.rc
//
#define IDD_MAINFRAME                   128
#define IDD_CANCELDLG                   129
#define IDC_BEGIN_DUMP                  1000
#define IDC_STOP_DUMP                   1001
#define IDC_PROGRESS                    1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
