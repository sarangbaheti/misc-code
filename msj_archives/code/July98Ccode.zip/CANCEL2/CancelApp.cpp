////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 5.0 on Windows 95
//
// Shows how to use CThreadJob
// 
#include "stdafx.h"
#include "resource.h"		// main symbols
#include "ThreadJob.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////
// Message used for progress notification
//
const UINT WM_MYPROGRESS = WM_USER;

// This function simulates the long operation of dumping a record.
//
const NUMRECS = 100;
void DumpRecord(int n)
{
	Sleep(500); // sleep half a second
}

//////////////////
// Dump record job is a special case of CThreadJob, a worker thread
//
class CDumpRecordsJob : public CThreadJob {
public:
	virtual UINT DoWork();
};

//////////////////
// This is the function that does the work of the job
//
UINT CDumpRecordsJob::DoWork()
{
	// Dump the records. Quit if m_bAbort is TRUE.
	for (int i=0; i<NUMRECS && !m_bAbort; i++) {
		::DumpRecord(i);						 // dump next record
		OnProgress(i+1);						 // report progress
	}
	OnProgress(m_bAbort ? -1 : 0);		 // report done or cancelled
	return 0;
}

//////////////////
// Application main window is a dialog with "Begin Dumping", "Stop",
// and "Exit" buttons, and a static text control to show progress.
//
class CMainDlg : public CDialog {
public:
	CMainDlg() : CDialog(IDD_MAINFRAME) { };
protected:
	CStatic			 m_wndProgress;		 // static text for progress
	CButton			 m_wndBeginDump;		 // "Begin Dumping" button
	CDumpRecordsJob m_job;					 // worker job (thread)

	virtual BOOL OnInitDialog();
	afx_msg void OnBeginDump();
	afx_msg void OnStop();
	afx_msg void OnProgress(WPARAM wp, LPARAM lp);
	DECLARE_MESSAGE_MAP()
};

BEGIN_MESSAGE_MAP(CMainDlg, CDialog)
	ON_COMMAND(IDC_BEGIN_DUMP, OnBeginDump)
	ON_COMMAND(IDC_STOP_DUMP,  OnStop)
	ON_MESSAGE(WM_MYPROGRESS,  OnProgress)
END_MESSAGE_MAP()

//////////////////
// Initialize dialog: subclass controls
//
BOOL CMainDlg::OnInitDialog()
{
	m_wndProgress.SubclassDlgItem(IDC_PROGRESS, this);
	m_wndBeginDump.SubclassDlgItem(IDC_BEGIN_DUMP, this);
	return TRUE;
}

//////////////////
// User clicked "Begin Dumping" button: start job (thread)
//
void CMainDlg::OnBeginDump() 
{
	m_wndBeginDump.EnableWindow(FALSE);	 // disable start button
	m_job.Begin(this, WM_MYPROGRESS);	 // and start the job
}

//////////////////
// User clicked "Stop" button: abort the job (thread)
// 
void CMainDlg::OnStop() 
{
	m_job.Abort();
}

//////////////////
// Handle progress notification from thread.
//    wp = 0   ==> done
//		wp = -1  ==> aborted
//		else wp  =	 number of records dumped.
//
void CMainDlg::OnProgress(WPARAM wp, LPARAM lp)
{
	CString s;
	if (wp==0)
		s = _T("Done");
	else if (wp==-1)
		s = "Aborted";
	else
		s.Format(_T("Dumping record %d of %d"), wp, NUMRECS);

	if ((int)wp<=0)
		// abort or done: re-enable Start button
		m_wndBeginDump.EnableWindow(TRUE);

	m_wndProgress.SetWindowText(s);
}

//////////////////
// Application class
//
class CMyApp : public CWinApp {
public:
	virtual BOOL InitInstance();
};

CMyApp theApp;

//////////////////
// MFC InitInstance: run main dialog and then quit.
//
BOOL CMyApp::InitInstance()
{
	CMainDlg dlg;			// create main dialog
	m_pMainWnd = &dlg;	// set main window for good luck
	dlg.DoModal();			// run the dialog..
	return FALSE;			// ..and then quit
}
