////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 5.0 on Windows 95
//
// Implementation for CCancelDlg, a generic cancel dialog.
// 
#include "stdafx.h"
#include "CancelDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////
// User pressed Cancel: set flag
//
void CCancelDlg::OnCancel()
{
	m_bAbort = TRUE;
}

//////////////////
// Test for abort. This is my chance to run peek/pump message loop;
// ie, to process any messages that may be waiting for me
// or--in Windows 3.1--for other apps as well.
//
BOOL CCancelDlg::Abort()
{
	MSG msg;
	while (::PeekMessage(&msg, NULL, NULL, NULL, PM_NOREMOVE)) {
		AfxGetThread()->PumpMessage();
	}
	return m_bAbort;
}
