////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// 

////////////////
// Generic Cancel Dialog. To use it, you must design a dialog with
// an IDCANCEL button, then instantiate CCancelDlg using your ID as the
// resource, and call CDialog::Create to create a modeless dialog. Then
// start your "long process". You must call CCancelDlg::Abort periodically
// to see if the user has aborted, and if so, quit.
//
class CCancelDlg : public CDialog {
public:
	CCancelDlg() : m_bAbort(FALSE) { }
	void Reset() { m_bAbort = FALSE; }
	virtual BOOL Abort();

protected:
	BOOL m_bAbort;
	virtual void OnCancel();
};
