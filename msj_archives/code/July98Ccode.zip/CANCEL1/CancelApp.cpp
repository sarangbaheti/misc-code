////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 5.0 on Windows 95
//
// Shows how to use CCancelDlg.
// 
#include "stdafx.h"
#include "resource.h"		// main symbols
#include "CancelDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// This function simulates the long operation of dumping a record.
//
const NUMRECS = 100;
void DumpRecord(int n)
{
	Sleep(500); // sleep half a second
}

//////////////////
// My cancel dialog: derived from generic cancel dialog to report status too.
//
class CMyCancelDlg : public CCancelDlg {
public:
	CString m_sProgress;
	virtual void DoDataExchange(CDataExchange* pDX);
};

////////////////
// Data exchange: use static text control to display # records dumped
// Standard MFC DDX stuff.
//
void CMyCancelDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_PROGRESS, m_sProgress);
}

//////////////////
// Application main window is a dialog with "Begin Dumping"
// and "Exit" buttons.
//
class CMainDlg : public CDialog {
public:
	CMainDlg() : CDialog(IDD_MAINFRAME) { };
protected:
	afx_msg void OnBeginDump();
	DECLARE_MESSAGE_MAP()
};

BEGIN_MESSAGE_MAP(CMainDlg, CDialog)
	ON_COMMAND(IDC_BEGIN_DUMP, OnBeginDump)
END_MESSAGE_MAP()

//////////////////
// User clicked "Begin Dumping" button: start dumping.
//
void CMainDlg::OnBeginDump() 
{
	EnableWindow(FALSE);						 // disable myself
	CMyCancelDlg dlg;							 // create cancel dialog object..
	dlg.Create(IDD_CANCELDLG, this);		 // ..and window (modeless dialog)

	// Now dump the records. Quit if CCancelDlg::Abort returns TRUE.
	for (int i=0; i<NUMRECS && !dlg.Abort(); i++) {
		::DumpRecord(i);
		dlg.m_sProgress.Format(_T("Dumping record %d of %d"),
			i+1, NUMRECS);
		dlg.UpdateData(FALSE);
	}

	// done, or user canceled
	dlg.DestroyWindow();						 // destroy cancel dialog
	EnableWindow(TRUE);						 // enable myself..
	SetForegroundWindow();					 // ..and make foreground window
}

//////////////////
// Application class
//
class CMyApp : public CWinApp {
public:
	virtual BOOL InitInstance();
};

CMyApp theApp;

//////////////////
// MFC InitInstance: run main dialog and then quit.
//
BOOL CMyApp::InitInstance()
{
	CMainDlg dlg;			// create main dialog
	m_pMainWnd = &dlg;	// set main window for good luck
	dlg.DoModal();			// run the dialog..
	return FALSE;			// ..and then quit
}
