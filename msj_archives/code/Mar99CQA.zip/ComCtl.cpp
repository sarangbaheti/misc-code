////////////////////////////////////////////////////////////////
// ControlWizard generated code using BEGIN/END_OLEFACTORY

#include "stdafx.h"
#include "ComCtl.h"

.
.
.

/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid
// This does not implement any class factory functions, it only instantiates
// the factory itself and guid.
//
IMPLEMENT_OLECREATE_EX(CFooCtrl, "FOO.ComCtrl.1",
   0xd711842c, 0x98ce, 0x11d2, 0xa0, 0xd0, 0, 0x40, 0x33, 0xd0, 0x64, 0x5d)

/////////////////////////////////////////////////////////////////////////////
// CFooCtrl::CFooCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CFooCtrl
//
BOOL CFooCtrl::CFooCtrlFactory::UpdateRegistry(BOOL bRegister)
{
   // TODO: Verify that your control follows apartment-model threading rules.
   // Refer to MFC TechNote 64 for more information.
   // If your control does not conform to the apartment-model rules, then
   // you must modify the code below, changing the 6th parameter from
   // afxRegApartmentThreading to 0.
   //
   if (bRegister)
      return AfxOleRegisterControlClass(
         AfxGetInstanceHandle(),
         m_clsid,
         m_lpszProgID,
         IDS_COM,
         IDB_COM,
         afxRegApartmentThreading,
         _dwComOleMisc,
         _tlid,
         _wVerMajor,
         _wVerMinor);
   else
      return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}

/////////////////////////////////////////////////////////////////////////////
// Licensing strings
//
static const TCHAR BASED_CODE _szLicFileName[] = _T("com.lic");

static const WCHAR BASED_CODE _szLicString[] =  L"Copyright (c) 1998  ";


/////////////////////////////////////////////////////////////////////////////
// CFooCtrl::CFooCtrlFactory::VerifyUserLicense -
// Checks for existence of a user license
//
BOOL CFooCtrl::CFooCtrlFactory::VerifyUserLicense()
{
   return AfxVerifyLicFile(AfxGetInstanceHandle(), _szLicFileName,
      _szLicString);
}


/////////////////////////////////////////////////////////////////////////////
// CFooCtrl::CFooCtrlFactory::GetLicenseKey -
// Returns a runtime licensing key
//
BOOL CFooCtrl::CFooCtrlFactory::GetLicenseKey(DWORD dwReserved,
   BSTR FAR* pbstrKey)
{
   if (pbstrKey == NULL)
      return FALSE;

   *pbstrKey = SysAllocString(_szLicString);
   return (*pbstrKey != NULL);
}
