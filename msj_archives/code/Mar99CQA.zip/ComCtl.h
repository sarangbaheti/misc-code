//////////////////
// Typical COM class that has a custom class factory.
//
class CFooCtrl : public COleControl {
public:
   CFooCtrl();

protected:
   ~CFooCtrl();

   BEGIN_OLEFACTORY(CFooCtrl)        // Class factory and guid
      // Add your overrides here.
      // Nested class is called CFooCtrlFactory
      // (CFooCtrl::CFooCtrlFactory)
      //
      virtual BOOL VerifyUserLicense();
      virtual BOOL GetLicenseKey(DWORD, BSTR FAR*);
   END_OLEFACTORY(CFooCtrl)
   .
   .
   .
};
