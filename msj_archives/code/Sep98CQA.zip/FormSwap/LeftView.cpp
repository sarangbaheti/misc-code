////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 5.0 on Windows 95
// 
#include "stdafx.h"
#include "resource.h"
#include "Doc.h"
#include "LeftView.h"
#include "RightView.h"
#include <afxpriv.h> // for WM_IDLEUPDATECMDUI

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CLeftView, CListView)

BEGIN_MESSAGE_MAP(CLeftView, CListView)
	ON_MESSAGE(WM_IDLEUPDATECMDUI, OnUpdateUI)
// For some reason I have not yet determined, this crashes in Release build:
//	ON_NOTIFY_REFLECT(LVN_ITEMCHANGED, OnItemChanged)
END_MESSAGE_MAP()

CLeftView::CLeftView()
{
	m_pFormView = NULL;
}

CLeftView::~CLeftView()
{
}

LPCTSTR FormNames[NFORMS] = {
	_T("Form 1"), _T("Form 2"), _T("Form 3"), _T("Form 4") };

//////////////////
// Update view for first time: add form names
//
void CLeftView::OnInitialUpdate()
{
	CListView::OnInitialUpdate();
	CListCtrl& lc = GetListCtrl();
	lc.ModifyStyle(LVS_TYPEMASK, LVS_LIST|LVS_SHOWSELALWAYS);

	// add form names to list
	lc.DeleteAllItems();
	for (int i=0; i<NFORMS; i++)
		lc.InsertItem(i, FormNames[i]);
}

//////////////////
// Handle WM_IDLEUPDATECMDUI: Set selection state based on current form.
//
LRESULT CLeftView::OnUpdateUI(WPARAM, LPARAM)
{
	int iWhich = m_pFormView->GetForm();
	CListCtrl& lc = GetListCtrl();

	LVITEM lvi;
	memset(&lvi, 0, sizeof(lvi));
	lvi.mask = LVIF_STATE;
	lvi.stateMask = LVIS_SELECTED|LVIS_FOCUSED;
	for (int i=0; i<=NFORMS; i++) {
		lvi.iItem = i;
		lvi.state = (i==iWhich) ? LVIS_SELECTED|LVIS_FOCUSED : 0;
		lc.SetItem(&lvi);		
	}
	return 0;
}

//////////////////
// Reflect-handle LVN_ITEMCHANGED to select the chosen form. This should
// really be implemented as an ON_NOTIFY_REFLECT handler, but there is an
// elusive bug somewhere that occurs in release builds only when I use
// ON_NOTIFY_REFLECT, so I am doing it this way instead. OnChildNotify lets
// any control handle its own notifications.
//
BOOL CLeftView::OnChildNotify(UINT msg, WPARAM wp, LPARAM lp, LRESULT* plr)
{
	if (msg==WM_NOTIFY) {
		ASSERT(lp);
		if (((NMHDR*)lp)->code == LVN_ITEMCHANGED)
			OnItemChanged((NMLISTVIEW*)lp);
	}
	return CListView::OnChildNotify(msg, wp, lp, plr);
}
		
//////////////////
// User selected a different item: select the form
//
LRESULT CLeftView::OnItemChanged(NMLISTVIEW* pnmlv)
{
	if ((pnmlv->uChanged & LVIF_STATE) &&
		(pnmlv->uNewState & LVIS_SELECTED)) {
		m_pFormView->SetForm(pnmlv->iItem);
	}
	return 0;
}
