////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 5.0 on Windows 95
//
// CRightView shows how to change theform in a CFormView.
// CRightView::SetForm is the function that does it.
// 
#include "StdAfx.h"
#include "RightView.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CRightView, CFormView)

BEGIN_MESSAGE_MAP(CRightView, CFormView)
	ON_COMMAND(ID_NEXT_FORM, OnViewNextForm)
END_MESSAGE_MAP()

CRightView::CRightView() : CFormView(IDD_DIALOG1)
{
	m_pListView = NULL;
}

CRightView::~CRightView()
{
}

//////////////////
// Handle View | Other Form command: call ChangeForm with new template name
//
void CRightView::OnViewNextForm()
{
	UINT nID = (UINT)m_lpszTemplateName - IDD_DIALOGFIRST;
	if (++nID >= NFORMS)
		nID = 0;
	SetForm(nID);
}

//////////////////
// Change the form underlying a CFormView.
//
BOOL CRightView::SetForm(UINT iWhich)
{
	ASSERT(0<=iWhich && iWhich<NFORMS);
	return SetForm(MAKEINTRESOURCE(IDD_DIALOGFIRST + iWhich));
}
	
//////////////////
// This is the function that changes the form within the form view.
//
BOOL CRightView::SetForm(LPCTSTR lpszTemplateName)
{
	if (lpszTemplateName == m_lpszTemplateName)
		return TRUE;

	// Must temporarily remove the doc so MFC won't have a conniption.
	CDocument* pSaveDoc = m_pDocument;
	m_pDocument = NULL; // remove
	
	// Preserve same window ID (usually AFX_IDW_PANE_FIRST)
	UINT nIDView = GetDlgCtrlID();

	// Preserve same parent (frame)
	CWnd* pParent = GetParent();
	ASSERT(pParent);

	// Preserve same window pos and style
	CRect rc;
	GetWindowRect(&rc);
	pParent->ScreenToClient(&rc);
	DWORD dwStyle = GetStyle();

	// Remove the current dialog (window) and destroy it.
	HWND hwnd = UnsubclassWindow();
	ASSERT(hwnd);
	::DestroyWindow(hwnd);

	// Now the view is in more or less the same state as after calling
	//
	//			new CRightView;
	//
	// There is no window, no m_hWnd, and no doc. So now I can re-Create
	// the view, using a different dialog template. Don't need create
	// context since doc already exists.
	//
	m_lpszTemplateName = lpszTemplateName;
	VERIFY(Create(lpszTemplateName, NULL, dwStyle, rc, pParent, nIDView, NULL));

	// restore document
	m_pDocument = pSaveDoc;

	return TRUE;
}

//////////////////
// Get current selected form as integer from 0 to NFORMS-1
//
int CRightView::GetForm()
{
	int iWhich = (UINT)m_lpszTemplateName - IDD_DIALOGFIRST;
	ASSERT(0<=iWhich && iWhich<NFORMS);
	return iWhich;	
}
