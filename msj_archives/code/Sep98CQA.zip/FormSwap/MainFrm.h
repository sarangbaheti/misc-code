////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 5.0 on Windows 95
// 
class CRightView;
class CLeftView;

class CMySplitterWnd : public CSplitterWnd {
public:
	// functions to get protected CSplitterWnd dimensions
	CSize GetBorderSize()   { return CSize(m_cxBorder,   m_cyBorder);	}
	CSize GetSplitterSize() { return CSize(m_cxSplitter, m_cySplitter);	}

	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra,
		AFX_CMDHANDLERINFO* pHandlerInfo);
};

class CMainFrame : public CFrameWnd {
public:
	CMainFrame();
	virtual ~CMainFrame();
protected:
	CStatusBar			m_wndStatusBar; // status bar
	CToolBar				m_wndToolBar;	 // toolbar
	CMySplitterWnd		m_wndSplitter;	 // splitter window

	virtual BOOL OnCreateClient( LPCREATESTRUCT lpcs, CCreateContext* pContext);
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra,
		AFX_CMDHANDLERINFO* pHandlerInfo);
	virtual void CalcWindowRect(LPRECT lpClientRect,
		UINT nAdjustType = adjustBorder);

	DECLARE_DYNCREATE(CMainFrame)
	DECLARE_MESSAGE_MAP()
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
};
