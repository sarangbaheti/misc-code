////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 5.0 on Windows 95
// 
#ifndef LEFTVIEW_H
#define LEFTVIEW_H

class CMyDoc;
class CRightView;

//////////////////
// Left hand splitter pane is a list view.
//
class CLeftView : public CListView {
public:
	virtual ~CLeftView();
	CMyDoc* GetDocument();
	virtual void OnInitialUpdate();
	void SetFormView(CRightView* pFormView) { m_pFormView = pFormView; }

protected:
	CRightView* m_pFormView;
	virtual BOOL OnChildNotify(UINT msg, WPARAM wp, LPARAM lp, LRESULT* plr);

	CLeftView();
	DECLARE_DYNCREATE(CLeftView)
	DECLARE_MESSAGE_MAP()
	afx_msg LRESULT OnUpdateUI(WPARAM, LPARAM);
	afx_msg LRESULT OnItemChanged(NMLISTVIEW* pnmlv);
};

#endif 
