//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FormSwap.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_DIALOGFIRST                 131
#define IDD_DIALOG1                     131
#define IDD_DIALOG2                     132
#define IDR_MSJLINK                     132
#define IDD_DIALOG3                     133
#define IDD_DIALOG4                     134
#define IDC_EDIT1                       1000
#define IDC_STATICURLPD                 1000
#define IDC_STATICURLMSJ                1001
#define IDC_EDIT2                       1001
#define IDC_STATICURLCOM40              1002
#define IDC_SLIDER1                     1003
#define IDC_RADIO1                      1004
#define IDC_RADIO2                      1005
#define IDC_RADIO3                      1006
#define ID_NEXT_FORM                    32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
