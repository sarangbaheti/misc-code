////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 5.0 on Windows 95
// 
#ifndef DOC_H
#define DOC_H

class CMyDoc : public CDocument {
public:
	virtual ~CMyDoc();
	virtual void Serialize(CArchive& ar);
protected:
	CMyDoc();
	virtual BOOL DoFileSave();
	DECLARE_DYNCREATE(CMyDoc)
	DECLARE_MESSAGE_MAP()
};

#endif