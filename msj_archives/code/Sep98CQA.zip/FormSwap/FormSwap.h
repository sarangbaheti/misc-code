////////////////////////////////////////////////////////////////
// FormSwap 1998 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// See FormSwap.cpp
// 
#include "resource.h"       // main symbols

class CMyApp : public CWinApp {
public:
	CMyApp();
	virtual BOOL InitInstance();
protected:
	afx_msg void OnAppAbout();
	afx_msg void OnDoNothing();
	DECLARE_MESSAGE_MAP()
};
