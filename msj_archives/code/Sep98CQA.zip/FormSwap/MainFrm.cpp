////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 5.0 on Windows 95
// 
#include "StdAfx.h"
#include "FormSwap.h"
#include "MainFrm.h"
#include "RightView.h"
#include "LeftView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const CXLIST = 50;

// Get the size of a dialog
static CSize GetDialogSize(LPCTSTR lpszTemplName, CWnd* pParent);

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
END_MESSAGE_MAP()

static UINT indicators[] = {
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME)) {
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	m_wndToolBar.ModifyStyle(0, TBSTYLE_FLAT);

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT))) {
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// Make frame just big enough to fit dialog
	CSize sz = GetDialogSize(MAKEINTRESOURCE(IDD_DIALOG1), this);
	CRect rc(CPoint(0,0), sz);
	CalcWindowRect(&rc);
	SetWindowPos(NULL, 0, 0, rc.Width(), rc.Height(),
		SWP_NOMOVE|SWP_NOZORDER);

	return 0;
}

//////////////////
// Client window created: Set up splitter window and save
// pointers to the two panes
//
BOOL CMainFrame::OnCreateClient( LPCREATESTRUCT /*lpcs*/, CCreateContext* pcc)
{
	// create splitter window
	if (!m_wndSplitter.CreateStatic(this, 1, 2))
		return FALSE;

	CSplitterWnd& sw = m_wndSplitter;
	if (!sw.CreateView(0,0,RUNTIME_CLASS(CLeftView), CSize(CXLIST,100), pcc) ||
		 !sw.CreateView(0,1,RUNTIME_CLASS(CRightView),CSize(100,100), pcc)) {

		sw.DestroyWindow();

		return FALSE;
	}

	CRightView* pRightView = STATIC_DOWNCAST(CRightView, sw.GetPane(0,1));
	ASSERT(pRightView);
	CLeftView* pLeftView = STATIC_DOWNCAST(CLeftView, sw.GetPane(0,0));
	ASSERT(pLeftView);

	// Connect views to each other
	pRightView->SetListView(pLeftView);
	pLeftView->SetFormView(pRightView);

	// Activate the input view. This is important for it to receive commands.
	SetActiveView(pRightView);

	return TRUE;
}

//////////////////
// Splitter wnd function to route commands to all splitter panes/views.
//
BOOL CMySplitterWnd::OnCmdMsg(UINT nID, int nCode, void* pExtra,
	AFX_CMDHANDLERINFO* pHandlerInfo)
{
	for (int row=0; row<GetRowCount(); row++) {
		for (int col=0; col<GetColumnCount(); col++) {
			if (GetPane(row,col)->OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
				return TRUE;
		}
	}
	// Call default routing--very important!
	return CSplitterWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

//////////////////
// Route commands to splitter window.
//
BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra,
	AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// Pass to splitter
	if (m_wndSplitter.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// Call default routing--very important!
	return CFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

//////////////////
// CDialog class to get the size of a dialog.
// Assumes dialog is invisible (no WS_VISIBLE).
//
class CTempDlg : public CDialog {
public:
	CRect m_rcDlg;
protected:
	virtual BOOL OnInitDialog();
};

////////////////
// Initialize dialog: save size, then quit.
// 
BOOL CTempDlg::OnInitDialog()
{
	GetWindowRect(&m_rcDlg);
	m_rcDlg -= m_rcDlg.TopLeft();
	EndDialog(0);
	return TRUE;
}

//////////////////
// static fn uses CTempDlg to get the size of any dialog used in a CFormView.
//
static CSize GetDialogSize(LPCTSTR lpszTemplName, CWnd* pParent)
{
	CTempDlg dlg;
	dlg.Create(lpszTemplName, pParent);
	return dlg.m_rcDlg.Size();
}

//////////////////
// Calculate the size of the total frame, given a desired client (form) size.
// Start with client rect and add all the extra stuff.
//
void CMainFrame::CalcWindowRect(PRECT prcClient, UINT nAdjustType)
{
	CRect rect(0, 0, 32767, 32767);
	RepositionBars(0, 0xffff, AFX_IDW_PANE_FIRST, reposQuery,
		&rect, &rect, FALSE);

	CSize szBorder   = m_wndSplitter.GetBorderSize();
	CSize szSplitter = m_wndSplitter.GetSplitterSize();

	prcClient->bottom += rect.Height() +		// total toolbar height  +
		GetSystemMetrics(SM_CYMENU) +				// menu +
		GetSystemMetrics(SM_CYCAPTION) +			// title bar +
		2 * GetSystemMetrics(SM_CYSIZEFRAME) +	// top/bottom window frame +
		2 * szBorder.cy;								// splitter borders
		
	prcClient->right += CXLIST +					// left pane width
		2 * GetSystemMetrics(SM_CXSIZEFRAME) + // L/R window border
		4 * szBorder.cx +								// 2 panes==> 4 borders
		szSplitter.cx;									// 1 splitter
}
