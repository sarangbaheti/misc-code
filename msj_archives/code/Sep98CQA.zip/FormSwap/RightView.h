////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 5.0 on Windows 95
// 
#include "Doc.h"

const NFORMS=4; // total number of forms 

class CListView;

//////////////////
// Right hand splitter pane is a form view
//
class CRightView : public CFormView {
public:
	virtual ~CRightView();
	CMyDoc* GetDocument() { return (CMyDoc*)m_pDocument; }
	void SetListView(CListView* pListView) { m_pListView = pListView; }
	int  GetForm();
	BOOL SetForm(UINT iWhich);
	BOOL SetForm(LPCTSTR lpszTemplateName);

protected:
	CRightView();
	CListView* m_pListView;
	DECLARE_DYNCREATE(CRightView)
	DECLARE_MESSAGE_MAP()
	afx_msg void OnViewNextForm();
};
