/************************************************************
Module name: FileLink.cpp
Written by: Jeffrey Richter
Notices: Copyright (c) 1998 Jeffrey Richter
************************************************************/


#define STRICT
#define _WIN32_WINNT 0x0500
#include <windows.h>
#include <tchar.h>


/////////////////////////////////////////////////////////////


int WINAPI WinMain (HINSTANCE, HINSTANCE, LPSTR, int) {
	if (__argc != 3) {
		TCHAR sz[200];
		wsprintf(sz, 
			__TEXT("FileLink creates a hard link to an existing file.\n")
			__TEXT("Usage: %s  (ExistingFile)  (NewFileName)"),\
			__targv[0]);
		MessageBox(NULL, sz, 
			__TEXT("FileLink by Jeffrey Richter"), 
			MB_ICONINFORMATION | MB_OK);
		return(0);
	}

	if (!CreateHardLink(__targv[2], __targv[1], NULL)) {
		MessageBox(NULL, __TEXT("The FileLink couldn't be created.\n"),
			__TEXT("FileLink by Jeffrey Richter"), 
			MB_ICONINFORMATION | MB_OK);
	}
	return(0);	
}


//////////////////////// End Of File ////////////////////////
