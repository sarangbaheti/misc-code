// BullsEyeDropSource.cpp : Implementation of CATLInternalsApp and DLL registration.

#include "stdafx.h"
#include "ATLInternals.h"
#include "BullsEyeDropSource.h"

/////////////////////////////////////////////////////////////////////////////
//

