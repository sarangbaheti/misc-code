// StockEventCls.h : Declaration of the CStockEventCls

#ifndef __STOCKEVENTCLS_H_
#define __STOCKEVENTCLS_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CStockEventCls
class ATL_NO_VTABLE CStockEventCls : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CStockEventCls, &CLSID_StockEventCls>,
	public IDispatchImpl<IStockEventCls, &IID_IStockEventCls, &LIBID_STOCKEVENTCLASSLib>
{
public:
	CStockEventCls()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_STOCKEVENTCLS)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CStockEventCls)
	COM_INTERFACE_ENTRY(IStockEventCls)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IStockEventCls
public:
	STDMETHOD(NewStockListed)(BSTR Symbol);
	STDMETHOD(StockPriceChanged)(BSTR Symbol, CURRENCY Price);
};

#endif //__STOCKEVENTCLS_H_
