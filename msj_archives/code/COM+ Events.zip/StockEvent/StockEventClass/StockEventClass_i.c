/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Thu May 07 11:32:56 1998
 */
/* Compiler settings for F:\COM+BookCode\Chap5\Stock\StockEventClass\StockEventClass.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IStockEventCls = {0x913DDA24,0xE5B0,0x11D1,{0x92,0xFB,0x00,0xC0,0x4F,0xB9,0x2A,0xFD}};


const IID LIBID_STOCKEVENTCLASSLib = {0x788DA8A7,0xE5B0,0x11D1,{0x92,0xFB,0x00,0xC0,0x4F,0xB9,0x2A,0xFD}};


const CLSID CLSID_StockEventCls = {0x9FBDDCF3,0xE5B0,0x11D1,{0x92,0xFB,0x00,0xC0,0x4F,0xB9,0x2A,0xFD}};


#ifdef __cplusplus
}
#endif

