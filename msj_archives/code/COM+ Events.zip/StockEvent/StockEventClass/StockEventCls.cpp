// StockEventCls.cpp : Implementation of CStockEventCls
#include "stdafx.h"
#include "StockEventClass.h"
#include "StockEventCls.h"

/////////////////////////////////////////////////////////////////////////////
// CStockEventCls


STDMETHODIMP CStockEventCls::StockPriceChanged(BSTR Symbol, CURRENCY Price)
{
	MessageBox (NULL, "StockPriceChanged", "Event Class", 0) ;
	return S_OK;
}

STDMETHODIMP CStockEventCls::NewStockListed(BSTR Symbol)
{
	return S_OK;
}
