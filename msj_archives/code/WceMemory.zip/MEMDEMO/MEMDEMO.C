//======================================================================
// MemDemo - WinCE memory demonstration
//
// Copyright (C) 1998 Douglas Boling
// 
//======================================================================
#include <windows.h>                 // For all that Windows stuff
#include <commctrl.h>                // Command bar includes
#include <commdlg.h>                 // Common dialog includes

#include "memdemo.h"                  // Program specific stuff

//----------------------------------------------------------------------
// Global data
//
const TCHAR szAppName[] = TEXT("memdemo");
HINSTANCE hInst;                     // Program instance handle
LPVOID pMem = NULL;
PBYTE pNextMemDump = 0;

HANDLE g_hFile = 0, g_hFileMap = 0;
PBYTE g_pFileMem = 0;

// Globals for unnamed memory mapped objects
HANDLE g_hUFileMap[16];
PBYTE g_pUFileMem[16];
INT g_nUMMCnt = 0;

// Globals for unnamed memory mapped objects
HANDLE g_hNFileMap[16];
PBYTE g_pNFileMem[16];
INT g_nNMMCnt = 0;


HANDLE 	g_hHeap1 = NULL, g_hHeap = NULL;


LPVOID pVirt[512];

int nIncVirt = 0;
LPVOID pIncVirt[512];

PBYTE pConW = 0;
PBYTE pLocal[16];
int nLocalCnt = 0;
int *pStack = 0;

// Message dispatch table for MainWindowProc
const struct decodeUINT MainMessages[] = {
	WM_CREATE, DoCreateMain,
	WM_SIZE, DoSizeMain,
	WM_HIBERNATE, DoHibernateMain,
	WM_COMMAND, DoCommandMain,
	WM_DESTROY, DoDestroyMain,
};

// Command Message dispatch for MainWindowProc
const struct decodeCMD MainCommandItems[] = {
	IDM_EXIT, DoMainCommandExit,
	IDM_VMEMINFO, DoMainCommandViewMemInfo,
	IDM_VMEMORY, DoMainCommandViewMemory, 
	IDM_VNEXTMEMORY, DoMainCommandViewNextMemory, 
	IDM_EMEMORY, DoMainCommandEditMemory, 
	IDM_VMEMSTAT, DoMainCommandViewMemStatus, 
	IDM_VSLOTINFO, DoMainCommandViewSlotStatus, 
	IDM_MMFILE, DoMainCommandMapFile, 
	IDM_NMMOBJECT, DoMainCommandMapNObject,
	IDM_FNMMOBJECT, DoMainCommandUnMapNObject,
	IDM_UMMOBJECT, DoMainCommandMapUObject,
	IDM_FUMMOBJECT, DoMainCommandUnMapUObject,
	IDM_TEST1, DoMainCommandTest1,
	IDM_TEST2, DoMainCommandTest2,
	IDM_TEST3, DoMainCommandTest3,
	IDM_TEST4, DoMainCommandTest4,
	IDM_TEST5, DoMainCommandTest5,
	IDM_TEST6, DoMainCommandTest6,
	IDM_TEST7, DoMainCommandTest7,
	IDM_TEST8, DoMainCommandTest8,
	IDM_TEST9, DoMainCommandTest9,
	IDM_TEST4, DoMainCommandTest4,
	IDM_ABOUT, DoMainCommandAbout,
};

//======================================================================
//
// Program Entry Point
//
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    LPWSTR lpCmdLine, int nCmdShow) {
	HWND hwndMain;
	MSG msg;
	int rc = 0;

	// init application
	rc = InitApp (hInstance);
	if (rc) return rc;

	// Initialize this instance
	hwndMain = InitInstance(hInstance, lpCmdLine, nCmdShow);
	if (hwndMain == 0)
		return 0x10;
	
	// Application message loop
	while (GetMessage (&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	// Instance cleanup
	return TermInstance(hInstance, msg.wParam);
}
//----------------------------------------------------------------------
// InitApp - Application initialization
//
int InitApp (HINSTANCE hInstance) {
	WNDCLASS 	wc;
	INITCOMMONCONTROLSEX icex;
	
	// Register App Main Window class
	wc.style = 0;                             // Window style
	wc.lpfnWndProc = MainWndProc;             // Callback function
	wc.cbClsExtra = 0;                        // Extra class data
	wc.cbWndExtra = 0;                        // Extra window data
	wc.hInstance = hInstance;                 // Owner handle
	wc.hIcon = NULL,                          // Application icon
	wc.hCursor = NULL;                        // Default cursor
	wc.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
	wc.lpszMenuName =  NULL;                  // Menu name
	wc.lpszClassName = szAppName;             // Window class name

	if (RegisterClass(&wc) == 0) return 1;

	// Load the command bar common control class
	icex.dwSize = sizeof (INITCOMMONCONTROLSEX);
	icex.dwICC = ICC_BAR_CLASSES;
	InitCommonControlsEx (&icex);
	return 0;
}
//----------------------------------------------------------------------
// InitInstance - Instance initialization
// 
HWND InitInstance (HINSTANCE hInstance, LPWSTR lpCmdLine, int nCmdShow){
	HWND hWnd;

	// Save program instance handle in global var
	hInst = hInstance;

	// Create main window
	hWnd = CreateWindow (szAppName,           // Window Class
	                     TEXT("memdemo"),    // Window Title
	                     WS_VISIBLE,          // Style flags
	                     CW_USEDEFAULT,       // x position
	                     CW_USEDEFAULT,       // y position
	                     CW_USEDEFAULT,       // Initial Width
	                     CW_USEDEFAULT,       // Initial Height
	                     NULL,                // Parent                
	                     NULL,                // Menu, must be null
	                     hInstance,           // App instance
	                     NULL);               // Ptr to create params
	// Return fail code if window not created
	if (!IsWindow (hWnd)) return 0;

	// Zero out structure
	{
		INT i;
		for (i = 0; i < dim (pVirt); i++)
			pVirt[i] = 0;

		for (i = 0; i < dim (pIncVirt); i++)
			pIncVirt[i] = 0;
	}

	// Standard show and update calls
	ShowWindow (hWnd, nCmdShow);
	UpdateWindow (hWnd);
	return hWnd;
}
//----------------------------------------------------------------------
// TermInstance - Program cleanup
//
int TermInstance (HINSTANCE hInstance, int nDefRC) {
	INT rc, i;
	TCHAR szDebug[128];

	if (pMem)
		VirtualFree (pMem, 1024, MEM_RELEASE);

	// Free virtual mem pages
	for (i = 0; i < dim (pVirt); i++)
		if (pVirt[i])
			VirtualFree (pVirt[i], 0, MEM_RELEASE);

	for (i = 0; i < dim (pIncVirt); i++)
		if (pIncVirt[i])
			VirtualFree (pIncVirt[i], 0, MEM_RELEASE);

	if (pConW)
		VirtualFree (pConW, 0, MEM_RELEASE);

	if (g_hFile) {
		rc = UnmapViewOfFile (g_pFileMem);
		if (!rc) {
			i = GetLastError();
			wsprintf (szDebug, TEXT ("UnmapViewofFile (h:%x) fail rc=%d (%xh)"), 
			          g_pFileMem, i, i);
			MessageBox (NULL, szDebug, TEXT ("Cleanup"), MB_OK);
		}
		rc = CloseHandle (g_hFileMap);
		if (!rc) {
			i = GetLastError();
			wsprintf (szDebug, TEXT ("Close file map handle fail rc=%d (%xh)"), i, i);
			MessageBox (NULL, szDebug, TEXT ("Cleanup"), MB_OK);
		}
		rc = CloseHandle (g_hFile);
	}

	// Clean up any unnamed mm objects
	for (i = 0; i < g_nUMMCnt; i++) {
		UnmapViewOfFile (g_pUFileMem[i]);
		CloseHandle (g_hUFileMap[i]);
	}

	return nDefRC;
}
//======================================================================
// Message handling procedures for MainWindow
//

//----------------------------------------------------------------------
// MainWndProc - Callback function for application window
//
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT wMsg, WPARAM wParam, 
                             LPARAM lParam) {
	INT i;
	//
	// Search message list to see if we need to handle this
	// message.  If in list, call procedure.
	//
	for(i = 0; i < dim(MainMessages); i++) {
		if(wMsg == MainMessages[i].Code)
			return (*MainMessages[i].Fxn)(hWnd, wMsg, wParam, lParam);
	}
	return DefWindowProc(hWnd, wMsg, wParam, lParam);
}

//----------------------------------------------------------------------
// DoCreateMain - process WM_CREATE message for window.
//
LRESULT DoCreateMain (HWND hWnd, UINT wMsg, WPARAM wParam, 
                      LPARAM lParam) {
	HWND	hwndCB, hwndChild;
	INT		i, nHeight;
	HFONT	hFont;
	LPCREATESTRUCT lpcs;

	// Convert lParam into ptr to create struct
	lpcs = (LPCREATESTRUCT) lParam;

	// Create a minimal command bar that only has a menu and an 
	// exit button.
	hwndCB = CommandBar_Create (hInst, hWnd, IDC_CMDBAR);
	// Insert the menu
	CommandBar_InsertMenubar (hwndCB, hInst, ID_MENU, 0);
	// Add exit button to command bar. 
	CommandBar_AddAdornments (hwndCB, 0, 0);
	nHeight = CommandBar_Height (hwndCB);

	//
	// Create report window.  Size it so that it fits under
	// the command bar and fills the remaining client area.
	//
	hwndChild = CreateWindowEx (0, TEXT ("listbox"), 
	                     TEXT(""), WS_VISIBLE | WS_CHILD | WS_VSCROLL |
	                     LBS_USETABSTOPS | LBS_NOINTEGRALHEIGHT, 0,
	                     nHeight, lpcs->cx, lpcs->cy - nHeight,
	                     hWnd, (HMENU)IDC_RPTLIST, 
	                     lpcs->hInstance, NULL);

	// Destroy frame if window not created
	if (!IsWindow (hwndChild)) {
		DestroyWindow (hWnd);
		return 0;
	}
	hFont = (HFONT) SendMessage (hwndChild, WM_GETFONT, 0, 0);
	hFont = GetFixedEquiv (hWnd, hFont);
	SendMessage (hwndChild, WM_SETFONT, (LPARAM)hFont, MAKELPARAM (FALSE, 0));

	// Initialize tab stops for display listbox
	i = 18;
	SendMessage (hwndChild, LB_SETTABSTOPS, 1, (LPARAM)&i);
	return 0;
}
//----------------------------------------------------------------------
// DoSizeMain - process WM_SIZE message for window 
// 
LRESULT DoSizeMain (HWND hWnd, UINT wMsg, WPARAM wParam, LPARAM lParam){
	HWND hwndList;
	RECT rect;

	hwndList = GetDlgItem (hWnd, IDC_RPTLIST);

	// Adjust the size of the client rect to take into account
	// the command bar height.
	GetClientRect (hWnd, &rect);
	rect.top += CommandBar_Height (GetDlgItem (hWnd, IDC_CMDBAR));

	SetWindowPos (hwndList, NULL, rect.left, rect.top, 
	              rect.right - rect.left, rect.bottom - rect.top,
	              SWP_NOZORDER);
	return 0;
}
//----------------------------------------------------------------------
// DoCommandMain - process WM_COMMAND message for window 
// 
//
LRESULT DoCommandMain (HWND hWnd, UINT wMsg, WPARAM wParam, 
                       LPARAM lParam) {
	WORD	idItem, wNotifyCode;
	HWND	hwndCtl;
	INT 	i;

	// Parse the paramters
	idItem = (WORD) LOWORD (wParam);
	wNotifyCode = (WORD) HIWORD(wParam);
	hwndCtl = (HWND) lParam;

	// Call routine to handle control message
	for(i = 0; i < dim(MainCommandItems); i++) {
		if(idItem == MainCommandItems[i].Code)
			return (*MainCommandItems[i].Fxn)(hWnd, idItem, hwndCtl, 
			                                  wNotifyCode);
	}
	return 0;
}
//----------------------------------------------------------------------
// DoHibernateMain - process WM_HIBERNATE message for window.
//
LRESULT DoHibernateMain (HWND hWnd, UINT wMsg, WPARAM wParam, 
                         LPARAM lParam) {
	MEMORYSTATUS gmi;
	LONG lMemAvail;

	MessageBeep(0);

	gmi.dwLength = sizeof (gmi);
	GlobalMemoryStatus (&gmi);
	lMemAvail = gmi.dwAvailPhys; 

	if (pConW)
		VirtualFree (pConW, 0, MEM_RELEASE);
	
	GlobalMemoryStatus (&gmi);

	Add2List (hWnd, TEXT("WM_HIBERNATE message received.  Old: %d   New:%d"), 
	          lMemAvail, gmi.dwAvailPhys); 
	return 0;
}
//----------------------------------------------------------------------
// DoDestroyMain - process WM_DESTROY message for window.
//
LRESULT DoDestroyMain (HWND hWnd, UINT wMsg, WPARAM wParam, 
                       LPARAM lParam) {

	if (g_hHeap1)
		HeapDestroy (g_hHeap1);
	if (g_hHeap)
		HeapDestroy (g_hHeap);

	if (pConW)
		VirtualFree (pConW, 0, MEM_RELEASE);
	
	PostQuitMessage (0);
	return 0;
}
//======================================================================
// Command handler routines
//
//----------------------------------------------------------------------
// DoMainCommandExit - Process Program Exit command
//
LPARAM DoMainCommandExit (HWND hWnd, WORD idItem, HWND hwndCtl, 
                          WORD wNotifyCode) {

	SendMessage (hWnd, WM_CLOSE, 0, 0);
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandViewMemInfo - Displays system memory data
//
LPARAM DoMainCommandViewMemInfo (HWND hWnd, WORD idItem, HWND hwndCtl, 
                                 WORD wNotifyCode) {
	SYSTEM_INFO si;
	MEMORYSTATUS gmi;
	STORE_INFORMATION sti;

	GetSystemInfo (&si);
	gmi.dwLength = sizeof (gmi);
	GlobalMemoryStatus (&gmi);
	GetStoreInformation(&sti);

	SendDlgItemMessage (hWnd, IDC_RPTLIST, WM_SETREDRAW, (WPARAM)FALSE, 0);

	Add2List (hWnd, TEXT("")); 
	Add2List (hWnd, TEXT("GetSystemInfo:")); 
	Add2List (hWnd, TEXT("wProcessorArchitecture      \t%X"), si.wProcessorArchitecture); 
	Add2List (hWnd, TEXT("dwPageSize                  \t%X"), si.dwPageSize); 
	Add2List (hWnd, TEXT("lpMinimumApplicationAddress \t%08X  (%d)"), si.lpMinimumApplicationAddress, si.lpMinimumApplicationAddress); 
	Add2List (hWnd, TEXT("lpMaximumApplicationAddress \t%08X  (%d)"), si.lpMaximumApplicationAddress, si.lpMaximumApplicationAddress); 
	Add2List (hWnd, TEXT("dwActiveProcessorMask       \t%X"), si.dwActiveProcessorMask); 
	Add2List (hWnd, TEXT("dwNumberOfProcessors        \t%X"), si.dwNumberOfProcessors); 
	Add2List (hWnd, TEXT("dwProcessorType             \t%X"), si.dwProcessorType); 
	Add2List (hWnd, TEXT("dwAllocationGranularity     \t%08X"), si.dwAllocationGranularity); 
	Add2List (hWnd, TEXT("wProcessorLevel             \t%X"), si.wProcessorLevel); 
	Add2List (hWnd, TEXT("wProcessorRevision          \t%X"), si.wProcessorRevision); 

	Add2List (hWnd, TEXT("")); 
	Add2List (hWnd, TEXT("GlobalMemoryStatus:")); 
	Add2List (hWnd, TEXT("dwMemoryLoad    \t%d"), gmi.dwMemoryLoad); 
	Add2List (hWnd, TEXT("dwTotalPhys     \t%08X  (%d)"), gmi.dwTotalPhys, gmi.dwTotalPhys); 
	Add2List (hWnd, TEXT("dwAvailPhys     \t%08X  (%d)"), gmi.dwAvailPhys, gmi.dwAvailPhys); 
	Add2List (hWnd, TEXT("dwTotalPageFile \t%08X"), gmi.dwTotalPageFile); 
	Add2List (hWnd, TEXT("dwAvailPageFile \t%08X"), gmi.dwAvailPageFile); 
	Add2List (hWnd, TEXT("dwTotalVirtual  \t%08X  (%d)"), gmi.dwTotalVirtual, gmi.dwTotalVirtual); 
	Add2List (hWnd, TEXT("dwAvailVirtual  \t%08X  (%d)"), gmi.dwAvailVirtual, gmi.dwAvailVirtual); 

	Add2List (hWnd, TEXT("")); 
	Add2List (hWnd, TEXT("GetStoreInformation:")); 
	Add2List (hWnd, TEXT("dwStoreSize\t%X  (%d)"), sti.dwStoreSize, sti.dwStoreSize); 
	Add2List (hWnd, TEXT("dwFreeSize \t%X  (%d)"), sti.dwFreeSize, sti.dwFreeSize); 

	SendDlgItemMessage (hWnd, IDC_RPTLIST, WM_SETREDRAW, (WPARAM)TRUE, 0);
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandDumpMem - Displays the contents of a block of memory
//
int DumpMemory (HWND hWnd, PBYTE pPtr) {
	INT i, j, k = 0;
	BYTE dat[16];
	TCHAR szOut[128], szTmp[16];

	SendDlgItemMessage (hWnd, IDC_RPTLIST, WM_SETREDRAW, (WPARAM)FALSE, 0);

	for (j = 0; j < 8; j++) {
		wsprintf (szOut, TEXT ("%08X   "), pPtr);
		for (i = 0; i < 16; i++) {
			// Make sure we have access to this page
			try {
				dat[i] = *pPtr++;
				wsprintf (szTmp, TEXT ("%02X"), dat[i]);
			}
			__except (EXCEPTION_EXECUTE_HANDLER) {
				lstrcpy (szTmp, TEXT ("ZZ"));
			}
			k++;
			lstrcat (szOut, szTmp);
			if (i == 7)
				lstrcat (szOut, TEXT ("-"));
			else
				lstrcat (szOut, TEXT (" "));
		}
		Add2List (hWnd, szOut);
	}
	SendDlgItemMessage (hWnd, IDC_RPTLIST, WM_SETREDRAW, (WPARAM)TRUE, 0);
	return k;
}
//----------------------------------------------------------------------
// DoMainCommandDumpMem - Displays the contents of a block of memory
//
LPARAM DoMainCommandViewMemory (HWND hWnd, WORD idItem, HWND hwndCtl, 
                                WORD wNotifyCode) {
	PBYTE pPtr;
	
	pPtr = (PBYTE)DialogBoxParam (hInst, TEXT("getval"), hWnd, GetValDlgProc, 0);
	if ((INT)pPtr == -1)
		return 0;

	pNextMemDump = pPtr + DumpMemory (hWnd, pPtr);
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandDumpMem - Displays the contents of a block of memory
// 
LPARAM DoMainCommandViewNextMemory (HWND hWnd, WORD idItem, HWND hwndCtl, 
                                    WORD wNotifyCode) {
	PBYTE pPtr;
	
	pPtr = pNextMemDump;
	if ((INT)pPtr == 0) {
		PostMessage (hWnd, WM_COMMAND, 0, MAKELPARAM (0, IDM_VMEMORY));
		return 0;
	}
	pNextMemDump = pPtr + DumpMemory (hWnd, pPtr);
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandDumpMem - Displays the contents of a block of memory
//
LPARAM DoMainCommandEditMemory (HWND hWnd, WORD idItem, HWND hwndCtl, 
                                WORD wNotifyCode) {
	PBYTE pPtr;
	INT nData;
	
	pPtr = (PBYTE)DialogBoxParam (hInst, TEXT("getval"), hWnd, 
	                              GetValDlgProc, (LPARAM)&nData);
	if ((INT)pPtr == -1)
		return 0;
	*(INT *)pPtr = nData;
	pNextMemDump = pPtr + DumpMemory (hWnd, pPtr);
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandDumpMemStat - Displays the access rights of a series of
// pages.
//
LPARAM DoMainCommandViewMemStatus (HWND hWnd, WORD idItem, HWND hwndCtl, 
                                   WORD wNotifyCode) {
	INT i, j;
	MEMORY_BASIC_INFORMATION mbi;
	PBYTE pPtr;
	TCHAR szOut[256];
	PBYTE pLast;
	BOOL fLastBad = FALSE;

	pPtr = (PBYTE)DialogBoxParam (hInst, TEXT("getval"), hWnd, GetValDlgProc, 0);
	if ((INT)pPtr == -1)
		return 0;

	SendDlgItemMessage (hWnd, IDC_RPTLIST, WM_SETREDRAW, (WPARAM)FALSE, 0);
	for (i = 0; i < 1; i++) {		
		for (j = 0; j < 512; j++) {		
			if (QueryMemoryRegion (pPtr, &mbi, szOut) == 0) {
				if (!fLastBad) {
					pLast = pPtr;
				}
				fLastBad = TRUE;
			} else {
				if (fLastBad) {
					Add2List (hWnd, TEXT ("%x \t\tUndefined region  \tcx:%8d"),
					          pLast, pPtr - pLast);
				}
				Add2List (hWnd, szOut);
				fLastBad = FALSE;
			}
				
			if (mbi.RegionSize)
				pPtr += mbi.RegionSize;
			else
				pPtr += 0x400;
		}
	}
	if (fLastBad) {
		Add2List (hWnd, TEXT ("%x \t\tUndefined region  \tcx:%8d"),
		          pLast, pPtr - pLast);
	}
	SendDlgItemMessage (hWnd, IDC_RPTLIST, WM_SETREDRAW, (WPARAM)TRUE, 0);
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandMapFile - Dump the first 80h bytes of a file via memory
// mapping
//
LPARAM DoMainCommandViewSlotStatus (HWND hWnd, WORD idItem, HWND hwndCtl, 
                                    WORD wNotifyCode) {
	DWORD i;

	i = (DWORD)&i;
	Add2List (hWnd, TEXT("Slot: %d, Base Addr:%x "), 
	          (i >> 25), i & 0xff000000L);
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandMapFile - Dump the first 80h bytes of a file via memory
// mapping
//
LPARAM DoMainCommandMapFile (HWND hWnd, WORD idItem, HWND hwndCtl, 
                             WORD wNotifyCode) {
	HANDLE hFile4, hFileMap4;
	PBYTE pFileMem4;
	TCHAR szFileName[MAX_PATH];

	if (MyGetFileName (hWnd, szFileName, dim (szFileName)) == 0)
		return 0;
	Add2List (hWnd, TEXT ("Reading file: %s"), szFileName);

	// Open file using special memory mapping call
	hFile4 = CreateFileForMapping(szFileName, GENERIC_READ, 
	                             FILE_SHARE_READ, NULL, OPEN_EXISTING, 
								 FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS,0); 
	
	if (hFile4 != INVALID_HANDLE_VALUE) {

		// Create a file mapping object
		hFileMap4 = CreateFileMapping(hFile4, NULL, PAGE_READONLY, 0, 0, 0);
		if (hFileMap4) {

			// Map into memory the file mapping object
			pFileMem4 = MapViewOfFile (hFileMap4, FILE_MAP_READ, 0, 0, 0);
			if (pFileMem4) {

				// Dump the first 0x80 bytes
				DumpMemory (hWnd, pFileMem4);

				// Start cleanup by unmapping view
				UnmapViewOfFile (pFileMem4);
			} else
				Add2List (hWnd, TEXT ("MapViewOfFile fail rc=%d "), GetLastError());

			CloseHandle (hFileMap4);
		} else 
			Add2List (hWnd, TEXT ("CreateFileMapping fail rc=%d"), GetLastError());

		CloseHandle (hFile4);
	} else 
		Add2List (hWnd, TEXT ("CreateFile fail rc=%d"), GetLastError());
	 
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandMapUObject - Create an unnamed memory mapped object
// mapping
//
LPARAM DoMainCommandMapUObject (HWND hWnd, WORD idItem, HWND hwndCtl, 
                                WORD wNotifyCode) {

	INT rc;

	// Create a 16 MByte memory mapped object
	g_hUFileMap[g_nUMMCnt] = CreateFileMapping((HANDLE)-1, NULL, PAGE_READWRITE,
	                                           0, 0x1000000, NULL);
	if (!g_hUFileMap) {
		rc = GetLastError();
		Add2List (hWnd, TEXT ("CreateFileMapping fail rc=%d (%xh)"), rc, rc);
		return 0;
	} 
	// Map in the object
	g_pUFileMem[g_nUMMCnt] = MapViewOfFile (g_hUFileMap[g_nUMMCnt], 
	                                        FILE_MAP_WRITE, 0, 0, 0);

	// Report results
	Add2List (hWnd, TEXT ("Unamed memory mapped object %d created  hFileMap:%x ptr:%x"), 
	          g_nUMMCnt, g_hUFileMap[g_nUMMCnt], g_pUFileMem[g_nUMMCnt]);

	// Write some random data to get some comitted pages
	*(PBYTE)g_pUFileMem[g_nUMMCnt] = 0xdb;
	*(int *)(g_pUFileMem[g_nUMMCnt]+0x100000) = 0x12345678;
	*(PBYTE)(g_pUFileMem[g_nUMMCnt]+0xefff00) = 0xdb;

	// Inc use cnt
	g_nUMMCnt++;
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandUnMapUObject - Delete an unnamed memory mapped object
//
LPARAM DoMainCommandUnMapUObject (HWND hWnd, WORD idItem, HWND hwndCtl, 
                                  WORD wNotifyCode) {
	INT rc1, rc2;

	// Inc use cnt
	if (!g_nUMMCnt)
		return 0;

	// Dec use cnt
	g_nUMMCnt--;

	// Unmap view
	rc1 = UnmapViewOfFile (g_pUFileMem[g_nUMMCnt]);
	if (!rc1) 
		rc1 = GetLastError ();
	else
		rc1 = 0;

	// Close handle of mapping object
	rc2 = CloseHandle (g_hUFileMap[g_nUMMCnt]);
	if (!rc2) 
		rc2 = GetLastError ();
	else
		rc2 = 0;

	// Report results
	Add2List (hWnd, TEXT ("Unamed memory mapped object %d freed.  Unmap rc:%x  CloseHandle rc:%x"), 
	          g_nUMMCnt, rc1, rc2);
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandMapUObject - Create an NAMED memory mapped object
// mapping
//
LPARAM DoMainCommandMapNObject (HWND hWnd, WORD idItem, HWND hwndCtl, 
                                WORD wNotifyCode) {

	INT rc;

	// Create a 16 MByte memory mapped object
	g_hNFileMap[g_nNMMCnt] = CreateFileMapping((HANDLE)-1, NULL, PAGE_READWRITE,
	                                           0, 0x1000000, TEXT ("Bob"));
	if (!g_hNFileMap) {
		rc = GetLastError();
		Add2List (hWnd, TEXT ("CreateFileMapping fail rc=%d (%xh)"), rc, rc);
		return 0;
	} 
	// Map in the object
	g_pNFileMem[g_nNMMCnt] = MapViewOfFile (g_hNFileMap[g_nNMMCnt], 
	                                        FILE_MAP_WRITE, 0, 0, 0);

	// Report results
	Add2List (hWnd, TEXT ("Named memory mapped object %d created  hFileMap:%x ptr:%x"), 
	          g_nNMMCnt, g_hNFileMap[g_nNMMCnt], g_pNFileMem[g_nNMMCnt]);

	// Write some random data to get some comitted pages
	*(PBYTE)g_pNFileMem[g_nNMMCnt] = 0xdb;
	*(int *)(g_pNFileMem[g_nNMMCnt]+0x100000) = 0x12345678;
	*(PBYTE)(g_pNFileMem[g_nNMMCnt]+0xefff00) = 0xdb;

	// Inc use cnt
	g_nNMMCnt++;
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandUnMapUObject - Delete an NAMED memory mapped object
//
LPARAM DoMainCommandUnMapNObject (HWND hWnd, WORD idItem, HWND hwndCtl, 
                                  WORD wNotifyCode) {
	INT rc1, rc2;

	// Inc use cnt
	if (!g_nNMMCnt)
		return 0;

	// Dec use cnt
	g_nNMMCnt--;

	// Unmap view
	rc1 = UnmapViewOfFile (g_pNFileMem[g_nNMMCnt]);
	if (!rc1) 
		rc1 = GetLastError ();
	else
		rc1 = 0;

	// Close handle of mapping object
	rc2 = CloseHandle (g_hNFileMap[g_nNMMCnt]);
	if (!rc2) 
		rc2 = GetLastError ();
	else
		rc2 = 0;

	// Report results
	Add2List (hWnd, TEXT ("Named memory mapped object %d freed.  Unmap rc:%x  CloseHandle rc:%x"), 
	          g_nNMMCnt, rc1, rc2);
	return 0;
}

//----------------------------------------------------------------------
// DoMainCommandViewTest1 - 
//
LPARAM DoMainCommandTest1 (HWND hWnd, WORD idItem, HWND hwndCtl, 
                           WORD wNotifyCode) {
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandViewTest2 - 
//
LPARAM DoMainCommandTest2 (HWND hWnd, WORD idItem, HWND hwndCtl, 
                           WORD wNotifyCode) {
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandViewTest3 - 
//
LPARAM DoMainCommandTest3 (HWND hWnd, WORD idItem, HWND hwndCtl, 
                           WORD wNotifyCode) {
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandViewTest4 - 
//
LPARAM DoMainCommandTest4 (HWND hWnd, WORD idItem, HWND hwndCtl, 
                           WORD wNotifyCode) {
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandViewTest5 - 
//
LPARAM DoMainCommandTest5 (HWND hWnd, WORD idItem, HWND hwndCtl, 
                           WORD wNotifyCode) {
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandViewTest6 - 
//
LPARAM DoMainCommandTest6 (HWND hWnd, WORD idItem, HWND hwndCtl, 
                           WORD wNotifyCode) {
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandViewTest7 - 
//
LPARAM DoMainCommandTest7 (HWND hWnd, WORD idItem, HWND hwndCtl, 
                           WORD wNotifyCode) {
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandViewTest8 - 
//
LPARAM DoMainCommandTest8 (HWND hWnd, WORD idItem, HWND hwndCtl, 
                           WORD wNotifyCode) {
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandViewTest9 - 
//
LPARAM DoMainCommandTest9 (HWND hWnd, WORD idItem, HWND hwndCtl, 
                           WORD wNotifyCode) {
	return 0;
}
//----------------------------------------------------------------------
// DoMainCommandAbout - Process the Help | About menu command
//
LPARAM DoMainCommandAbout(HWND hWnd, WORD idItem, HWND hwndCtl, 
                          WORD wNotifyCode) {

	// Use DialogBox to create modal dialog
	DialogBox (hInst, TEXT("aboutbox"), hWnd, AboutDlgProc);
	return 0;
}
//----------------------------------------------------------------------
// MyGetFileName - Returns a file name using the common dialog
//
INT MyGetFileName (HWND hWnd, LPTSTR szFileName, INT nMax) {
	OPENFILENAME of;
    const LPTSTR pszOpenFilter = TEXT("All Documents (*.*)\0*.*\0\0");

	// Init file name
	szFileName[0] = '\0';

	// Init file open structure
	memset (&of, 0, sizeof (of));

	of.lStructSize = sizeof (of);
	of.hwndOwner = hWnd;
	of.lpstrFile = szFileName;
	of.nMaxFile = nMax;
    of.lpstrFilter = pszOpenFilter;
	of.Flags = 0;

	if (GetOpenFileName (&of))
		return lstrlen (szFileName);
	else
		return 0;
}
//----------------------------------------------------------------------
// Add2List - Inserts text into listbox
//
void Add2List (HWND hWnd, LPTSTR lpszFormat, ...) {
	int nBuf, i;
	TCHAR szBuffer[512];

	va_list args;
	va_start(args, lpszFormat);

	nBuf = _vstprintf(szBuffer, lpszFormat, args);
//	_ASSERTE(nBuf < sizeof(szBuffer));

	i = SendDlgItemMessage (hWnd, IDC_RPTLIST, LB_ADDSTRING, 0, 
	                        (LPARAM)(LPCTSTR)szBuffer);

	if (i != LB_ERR)
		SendDlgItemMessage (hWnd, IDC_RPTLIST, LB_SETTOPINDEX, i, 
		                    (LPARAM)(LPCTSTR)szBuffer);
	va_end(args);
}
//----------------------------------------------------------------------
// GetFixedEquiv - Attempts to return a fixed pitched font close to
// the font passed in.
//
HFONT GetFixedEquiv (HWND hWnd, HFONT hFontIn) {
	HDC hdc;
	TEXTMETRIC tm;
	LOGFONT lf;
	HFONT hOldFont;

	hdc = GetDC (hWnd);
	hOldFont = SelectObject (hdc, hFontIn);
	GetTextMetrics (hdc, &tm);
	SelectObject (hdc, hOldFont);
	ReleaseDC (hWnd, hdc);

	memset (&lf, 0, sizeof (lf));

	lf.lfHeight = -(tm.tmHeight);
	lf.lfWeight    = tm.tmWeight; 
	lf.lfItalic    = tm.tmItalic;  
	lf.lfUnderline = tm.tmUnderlined;
	lf.lfStrikeOut = tm.tmStruckOut; 
	lf.lfCharSet   = tm.tmCharSet; 
	lf.lfOutPrecision = OUT_DEFAULT_PRECIS; 
	lf.lfClipPrecision = CLIP_DEFAULT_PRECIS; 
	lf.lfQuality = DEFAULT_QUALITY; 
	lf.lfPitchAndFamily = (tm.tmPitchAndFamily & 0xf0) | TMPF_FIXED_PITCH; 
	lf.lfFaceName[0] = TEXT ('\0'); 

	// Create the font from the LOGFONT structure passed.
	return CreateFontIndirect (&lf);
}
//----------------------------------------------------------------------
TCHAR *Fl2Txt (DWORD dwFlags, PFLAGTEXT ft, INT nSize, TCHAR *pszOut) {
	TCHAR *pszStart;
	INT i;

	pszStart = pszOut;
	*pszOut = TEXT('\0');
	for (i = 0; i < nSize; i++) {
		if (dwFlags & ft[i].dwFlag) {
			lstrcat (pszOut, ft[i].pszLabel);
			pszOut += lstrlen (pszOut) + 1;
		}
	}
	return pszStart;
}
//----------------------------------------------------------------------
INT QueryMemoryRegion (PBYTE pPtr, MEMORY_BASIC_INFORMATION *pmbi, LPTSTR pszOut) {
	INT rc;
	static FLAGTEXT ftState[3] = {
		{MEM_COMMIT,  TEXT ("Commit   ")},
		{MEM_FREE,    TEXT ("Free     ")},
		{MEM_RESERVE, TEXT ("Reserved ")},
	};
	static FLAGTEXT ftType[3] = {
		{MEM_IMAGE,    TEXT ("Image  ")},
		{MEM_MAPPED,   TEXT ("Mapped ")},
		{MEM_PRIVATE,  TEXT ("Pri    ")},
	};
	static FLAGTEXT ftProt[10] = {
		{PAGE_READONLY,          TEXT ("R ")},
		{PAGE_READWRITE,         TEXT ("RW ")},
		{PAGE_WRITECOPY,         TEXT ("WC ")},
		{PAGE_EXECUTE,           TEXT ("E ")},
		{PAGE_EXECUTE_READ,      TEXT ("ER ")},
		{PAGE_EXECUTE_READWRITE, TEXT ("EWR ")},
		{PAGE_EXECUTE_WRITECOPY, TEXT ("EWC ")},
		{PAGE_GUARD,             TEXT ("G ")},
		{PAGE_NOACCESS,          TEXT ("NA ")},
		{PAGE_NOCACHE,           TEXT ("NC ")},
	};
	TCHAR szTmp[64];
	TCHAR szTmp1[64];
	TCHAR szTmp2 [64];
	TCHAR szTemplate[128];
	PFLAGTEXT ft1, ft2;

	memset (pmbi, 0, sizeof (MEMORY_BASIC_INFORMATION));
	rc = VirtualQuery (pPtr, pmbi, sizeof (MEMORY_BASIC_INFORMATION));

	ft1 = ftState;
	ft2 = ftType;

	if (pmbi->State & MEM_FREE) 
		lstrcpy (szTemplate, TEXT(" %08X  \tRegBase:%08X  \tcx:%8d \tFree"));
	else
		lstrcpy (szTemplate, TEXT(" %08X  \tRegbase:%08X  \tcx:%8d \t%s \t%s \t%s"));

	if ((int)pPtr % 0x10000)
		wsprintf (pszOut, szTemplate, 
		          pPtr, pmbi->AllocationBase, pmbi->RegionSize, 
				  Fl2Txt (pmbi->State, ftState, dim (ftState), szTmp),
				  Fl2Txt (pmbi->Type, ftType, dim (ftType), szTmp1),
				  Fl2Txt (pmbi->Protect, ftProt, dim (ftProt), szTmp2));
	else
		wsprintf (pszOut, &szTemplate[1], 
		          pPtr, pmbi->AllocationBase, pmbi->RegionSize, 
				  Fl2Txt (pmbi->State, ftState, dim (ftState), szTmp),
				  Fl2Txt (pmbi->Type, ftType, dim (ftType), szTmp1),
				  Fl2Txt (pmbi->Protect, ftProt, dim (ftProt), szTmp2));
				
	return rc;
}
//----------------------------------------------------------------------
//
//
BOOL ConvertValue (LPTSTR lpIn, INT nBase, int *pnResult) {
	LPTSTR lpPtr;
	TCHAR ch;

	*pnResult = 0;
	lpPtr = lpIn;
	CharUpper (lpIn);
	while (ch = *lpPtr++) {
		ch -= '0';

		if (ch > 9)
			ch -= 7;

		if (ch < 0) 
			return FALSE;

		if (ch > nBase - 1)
			return FALSE;

		*pnResult = (*pnResult * nBase) + ch;
	}
	return TRUE;
}
//======================================================================
// GetVal Dialog procedure
//
BOOL CALLBACK GetValDlgProc(HWND hWnd, UINT wMsg, WPARAM wParam, 
                            LPARAM lParam) {
	TCHAR szText[64];
	INT nVal;
	static INT *pData;

	switch (wMsg) {
		case WM_INITDIALOG:
			pData = (INT *)lParam;
			if (lParam == 0)
				ShowWindow (GetDlgItem (hWnd, IDD_DATA), FALSE);

			SetDlgItemInt (hWnd, IDD_VALUE, 0, TRUE);
			SendDlgItemMessage (hWnd, IDD_VALUE, EM_LIMITTEXT, 
			                    sizeof (szText)-1, 0); 
			CheckRadioButton (hWnd, IDD_DEC, IDD_HEX, IDD_HEX);
			return TRUE;

		case WM_COMMAND:
			switch (LOWORD (wParam)) {

				case IDD_HEX:
					if (SendDlgItemMessage (hWnd, IDD_HEX, 
					            BM_GETSTATE, 0, 0) == BST_CHECKED)
						return TRUE;

					GetDlgItemText (hWnd, IDD_VALUE, szText, 
					                sizeof (szText));
					if (ConvertValue (szText, 10, &nVal)) {
						wsprintf (szText, TEXT ("%x"), nVal);
						SetDlgItemText (hWnd, IDD_VALUE, szText); 

						CheckRadioButton (hWnd, IDD_DEC, IDD_HEX, IDD_HEX);

					} else {
						MessageBox (hWnd, TEXT ("Value not valid"), 
						            TEXT ("Error"), MB_OK);
					}	
					return TRUE;

				case IDD_DEC:

					if (SendDlgItemMessage (hWnd, IDD_DEC, 
					            BM_GETSTATE, 0, 0) == BST_CHECKED)
						return TRUE;

					GetDlgItemText (hWnd, IDD_VALUE, szText, 
					                sizeof (szText));
					if (ConvertValue (szText, 16, &nVal)) {
						wsprintf (szText, TEXT ("%d"), nVal);
						SetDlgItemText (hWnd, IDD_VALUE, szText); 

						CheckRadioButton (hWnd, IDD_DEC, IDD_HEX, IDD_DEC);

					} else {
						MessageBox (hWnd, TEXT ("Value not valid"), 
						            TEXT ("Error"), MB_OK);
					}	
					return TRUE;

				case IDOK:
					if (pData) {
						GetDlgItemText (hWnd, IDD_DATA, szText, sizeof (szText));
						if (ConvertValue (szText, 16, pData) == 0) {
							MessageBox (hWnd, TEXT ("Data not valid"), 
							            TEXT ("Error"), MB_OK);
							break;
						}
					}
					GetDlgItemText (hWnd, IDD_VALUE, szText, sizeof (szText));
					if (ConvertValue (szText, 16, &nVal)) 
						EndDialog (hWnd, nVal);
					else 
						MessageBox (hWnd, TEXT ("Value not valid"), 
						            TEXT ("Error"), MB_OK);
					break;
				case IDCANCEL:
					EndDialog (hWnd, -1);
					return TRUE;
			}
		break;
	}
	return FALSE;
}
//======================================================================
// About Dialog procedure
//
BOOL CALLBACK AboutDlgProc(HWND hWnd, UINT wMsg, WPARAM wParam, 
                          LPARAM lParam) {

	switch (wMsg) {
		case WM_COMMAND:
			switch (LOWORD (wParam)) {
				case IDOK:
				case IDCANCEL:
					EndDialog (hWnd, 0);
					return TRUE;
			}
		break;
	}
	return FALSE;
}

