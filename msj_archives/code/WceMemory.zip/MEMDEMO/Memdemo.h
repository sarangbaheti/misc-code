//======================================================================
// Header file
//
// Copyright (C) 1998 Douglas Boling
//
//======================================================================
// Returns number of elements
#define dim(x) (sizeof(x) / sizeof(x[0]))   

//----------------------------------------------------------------------
// Generic defines and data types
//
struct decodeUINT {                             // structure associates
    UINT Code;                                  // messages 
                                                // with a function 
    LRESULT (*Fxn)(HWND, UINT, WPARAM, LPARAM);
}; 
struct decodeCMD {                              // structure associates
    UINT Code;                                  // menu IDs with a 
    LRESULT (*Fxn)(HWND, WORD, HWND, WORD);     // function
};

//----------------------------------------------------------------------
// Generic defines used by application
#define  IDC_CMDBAR          1                  // Command band ID
#define  IDC_RPTLIST         2                  // Report window ID
#define  ID_MENU             10                 // Main menu resource ID

// Menu item IDs
#define  IDM_EXIT            101                // File menu

#define  IDM_VMEMINFO        120
#define  IDM_VMEMORY         121
#define  IDM_VNEXTMEMORY     122
#define  IDM_VMEMSTAT        123
#define  IDM_EMEMORY         124
#define  IDM_VSLOTINFO       125

#define  IDM_MMFILE          130
#define  IDM_NMMOBJECT       131
#define  IDM_FNMMOBJECT      132
#define  IDM_UMMOBJECT       133
#define  IDM_FUMMOBJECT      134


#define  IDM_TEST1           140
#define  IDM_TEST2           141
#define  IDM_TEST3           142
#define  IDM_TEST4           143
#define  IDM_TEST5           144
#define  IDM_TEST6           145
#define  IDM_TEST7           146
#define  IDM_TEST8           147
#define  IDM_TEST9           148
#define  IDM_ALLOCALL        149

#define  IDM_ABOUT           150                // Help menu

// IDs for dialog box controls
#define  IDD_VALUE           100 
#define  IDD_DATA            101
#define  IDD_DEC             102 
#define  IDD_HEX             103 
//----------------------------------------------------------------------
// Program specific structures
//
typedef struct {
	DWORD dwFlag;
	TCHAR *pszLabel;
} FLAGTEXT;
typedef FLAGTEXT *PFLAGTEXT;


//----------------------------------------------------------------------
// Function prototypes
//
int InitApp (HINSTANCE);
HWND InitInstance (HINSTANCE, LPWSTR, int);
int TermInstance (HINSTANCE, int);

void Add2List (HWND hWnd, LPTSTR lpszFormat, ...);
INT MyGetFileName (HWND hWnd, LPTSTR szFileName, INT nMax);
HFONT GetFixedEquiv (HWND hWnd, HFONT hFontIn);
INT QueryMemoryRegion (PBYTE pPtr, MEMORY_BASIC_INFORMATION *pmbi, LPTSTR pszOut);
TCHAR *Fl2Txt (DWORD dwFlags, PFLAGTEXT ft, INT nSize, TCHAR *pszOut);

// Window procedures
LRESULT CALLBACK MainWndProc(HWND, UINT, WPARAM, LPARAM);

// Message handlers
LRESULT DoCreateMain (HWND, UINT, WPARAM, LPARAM);
LRESULT DoSizeMain (HWND, UINT, WPARAM, LPARAM);
LRESULT DoCommandMain (HWND, UINT, WPARAM, LPARAM);
LRESULT DoHibernateMain (HWND, UINT, WPARAM, LPARAM);
LRESULT DoDestroyMain (HWND, UINT, WPARAM, LPARAM);

// Command functions
LPARAM DoMainCommandExit (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandViewMemInfo (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandViewMemory (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandViewNextMemory (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandEditMemory (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandViewMemStatus (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandViewSlotStatus (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandMapFile (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandMapNObject (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandUnMapNObject (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandMapUObject (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandUnMapUObject (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandTest1 (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandTest2 (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandTest3 (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandTest4 (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandTest5 (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandTest6 (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandTest7 (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandTest8 (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandTest9 (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandAllocAll (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandAbout (HWND, WORD, HWND, WORD);

// Dialog procedures
BOOL CALLBACK AboutDlgProc (HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK GetValDlgProc (HWND, UINT, WPARAM, LPARAM);

