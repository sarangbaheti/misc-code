//==========================================
// Matt Pietrek
// Microsoft Systems Journal, October 1997
// FILE: GenException.CPP
// To compile: CL GenException.CPP
//==========================================
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <float.h>
#include <assert.h>

typedef void (* PFNGENERATEEXCEPTION)(void);

void GenerateSTATUS_BREAKPOINT( void )
{
    __asm   int 3   // A regular, old breakpoint instruction
}

void GenerateSTATUS_SINGLE_STEP( void )
{
    // This is easier than using the hardware
    // breakpoint register to create an int 1
    __asm   int 1
}

void GenerateSTATUS_ACCESS_VIOLATION( void )
{
    // Create a page fault (exception 0xE) by reading
    // from memory above 2GB.
    int i = *(int *)0xFFFFFFF0;
}

void GenerateSTATUS_ILLEGAL_INSTRUCTION( void )
{
    __asm _emit 0x0F    // Garbage instruction causes an exception 0xD
    __asm _emit 0xFF
}

void GenerateSTATUS_ARRAY_BOUNDS_EXCEEDED( void )
{
    DWORD arrayBounds[2] = { 10, 48 };

    __asm   mov eax, 12
    __asm   bound eax, arrayBounds  // This BOUND instruction works

    __asm   mov eax, 7
    __asm   bound eax, arrayBounds  // This makes an exception 5
}

void UnmaskFPExceptionBits( void )
{
    unsigned short cw;

    __asm   fninit      // Initialize the coprocessor
    __asm   fstcw [cw]
    cw &= 0xFFE0;       // Turn off the most of the exception bits (except the
                        // the precision exception)
    __asm   fldcw [cw]

}

void GenerateSTATUS_FLOAT_DIVIDE_BY_ZERO( void )
{
    double a = 0;
    
    a = 1 / a;
    __asm fwait;        
}

void GenerateSTATUS_FLOAT_OVERFLOW( void )
{
    double a = DBL_MAX;

    a *= a;
    __asm fwait;
        
}

void GenerateSTATUS_FLOAT_STACK_CHECK( void )
{
    unsigned a;

    __asm   fistp [a]
    __asm   fwait;
        
}

void GenerateSTATUS_FLOAT_UNDERFLOW( void )
{
    double a = DBL_MIN;
    
    a /= 10;
    __asm fwait;
        
}

void GenerateSTATUS_INTEGER_DIVIDE_BY_ZERO( void )
{
    // Divide by zero to cause an exception 0
    int i = 0;
    i = 2 / i;
}

void GenerateSTATUS_INTEGER_OVERFLOW( void )
{
    __asm   mov eax, 07FFFFFFFh     // Signed max value
    __asm   add eax, 2              // result = 0x80000001 -> overflow!
    __asm   into                    // Makes an exception 4
}

void GenerateSTATUS_PRIVILEGED_INSTRUCTION( void )
{
    // The HLT instruction can only be executed
    // at ring 0
    __asm   hlt
}

void GenerateSTATUS_STACK_OVERFLOW( void )
{
    DWORD myArray[512];
    
    // Recurse "infinitely" to overflow the stack
    GenerateSTATUS_STACK_OVERFLOW();
}

DWORD GetExceptionNumber( PFNGENERATEEXCEPTION pfn )
{
    DWORD exceptionCode = 0;
    
    __try
    {
        pfn();  
    }
    __except( exceptionCode = GetExceptionCode(), EXCEPTION_EXECUTE_HANDLER )
    {
    
    }
    
    return exceptionCode;
}

#define SHOW_EXCEPTION( x )                                 \
    dwExceptionNumber = GetExceptionNumber( Generate##x );  \
    printf( "%X %s\n", dwExceptionNumber, #x );             \
    assert( dwExceptionNumber == x );
    
int main(int argc, char *argv[])
{
    DWORD dwExceptionNumber;
    
    SHOW_EXCEPTION( STATUS_BREAKPOINT )
    SHOW_EXCEPTION( STATUS_SINGLE_STEP )
    SHOW_EXCEPTION( STATUS_ACCESS_VIOLATION )
    SHOW_EXCEPTION( STATUS_ILLEGAL_INSTRUCTION )
    SHOW_EXCEPTION( STATUS_ARRAY_BOUNDS_EXCEEDED )

    UnmaskFPExceptionBits();
    SHOW_EXCEPTION( STATUS_FLOAT_DIVIDE_BY_ZERO )

    UnmaskFPExceptionBits();
    SHOW_EXCEPTION( STATUS_FLOAT_OVERFLOW )

    UnmaskFPExceptionBits();
    SHOW_EXCEPTION( STATUS_FLOAT_STACK_CHECK )

    UnmaskFPExceptionBits();
    SHOW_EXCEPTION( STATUS_FLOAT_UNDERFLOW )

    SHOW_EXCEPTION( STATUS_INTEGER_DIVIDE_BY_ZERO ) 
    SHOW_EXCEPTION( STATUS_INTEGER_OVERFLOW )
    SHOW_EXCEPTION( STATUS_PRIVILEGED_INSTRUCTION )

    SHOW_EXCEPTION( STATUS_STACK_OVERFLOW );
    
    return 0;
}

