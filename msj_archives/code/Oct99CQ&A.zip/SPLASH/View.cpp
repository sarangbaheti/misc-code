////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- October 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#include "stdafx.h"
#include "resource.h"
#include "View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CMyView, CWnd)
BEGIN_MESSAGE_MAP(CMyView, CWnd)
	ON_WM_PAINT()
END_MESSAGE_MAP()

CMyView::CMyView()
{
}

CMyView::~CMyView()
{
}

void CMyView::OnPaint()
{
	CPaintDC dc(this);
	CString s;
	s.LoadString(IDR_VIEWMSG);
	CRect rc;
	GetClientRect(&rc);
	dc.DrawText(s, &rc, DT_CENTER|DT_SINGLELINE|DT_VCENTER);
}

