//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestSplash.rc
//
#define IDR_VIEWMSG                     98
#define IDR_MAINFRAME                   99
#define IDD_ABOUTBOX                    100
#define IDC_MSJURL                      101
#define IDC_PDURL                       102
#define IDB_SPLASH                      104
#define IDB_MSJ                         105
#define ID_VIEW_SPLASH                  32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
