////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- October 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#pragma once

class CMyView : public CWnd {
public:
	CMyView();
	virtual ~CMyView();
protected:
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNCREATE(CMyView)
};

