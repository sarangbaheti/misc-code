////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- October 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
// ---
// TestSplash shows how to implement a splash screen in MFC.
// Splash is implemented in spash.h, splash.cpp

#include "StdAfx.h"
#include "TestSplash.h"
#include "resource.h"
#include "MainFrm.h"
#include "TraceWin.h"
#include "Splash.h"
#include "StatLink.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CMyApp, CWinApp)
BEGIN_MESSAGE_MAP(CMyApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT,	OnAppAbout)
	ON_COMMAND(ID_VIEW_SPLASH, OnViewSplash)
END_MESSAGE_MAP()

CMyApp theApp;

BOOL CMyApp::InitInstance()
{
	CSplash *pSplash = new CSplash(IDB_SPLASH, 2000, 0, &pSplash);

	// simulate 5 seconds of work
	Sleep(5000);

	// The splash window will automatically kill itself as soon as the main
	//	window comes up (or timeout expires), but if you want to kill it sooner,
	//	you can call CSplash::Kill. Just check that your pointer isn't NULL.
	//
	if (pSplash)
		pSplash->Kill();

	CMainFrame* pFrame = new CMainFrame;
	m_pMainWnd = pFrame;
	pFrame->LoadFrame(IDR_MAINFRAME);
	m_pMainWnd->CenterWindow();
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();
	return TRUE;
}

void CMyApp::OnViewSplash()
{
	new CSplash(IDB_SPLASH, 2000, CSplash::KillOnClick|CSplash::IgnoreCmdLine);
}

//////////////////
// Custom dialog uses CStaticLink for hyperlinks.
// Same dialog class works for both applets (resource ID determines dialog)
//
class CAboutDialog : public CDialog {
protected:
	CStaticLink	m_wndLink1;
	CStaticLink	m_wndLink2;
	virtual BOOL OnInitDialog() {
		m_wndLink1.SubclassDlgItem(IDC_MSJURL, this);
		m_wndLink2.SubclassDlgItem(IDC_PDURL,  this);
		return CDialog::OnInitDialog();
	}
public:
	CAboutDialog() : CDialog(IDD_ABOUTBOX, NULL) { }
};

void CMyApp::OnAppAbout()
{
	CAboutDialog().DoModal();
}
