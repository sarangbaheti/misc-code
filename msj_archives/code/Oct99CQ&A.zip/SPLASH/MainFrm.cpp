////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- October 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#include "stdafx.h"
#include "resource.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if(!CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.cx = 400;
	cs.cy = 300;
	return TRUE;
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	// create window and control bars
	VERIFY(CFrameWnd::OnCreate(lpCreateStruct)==0);
	VERIFY(m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW,
		CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL));
	VERIFY(m_wndToolBar.CreateEx(this) &&
		m_wndToolBar.LoadToolBar(IDR_MAINFRAME));
	VERIFY(m_wndDlgBar.Create(this, IDR_MAINFRAME, 
		CBRS_ALIGN_TOP, AFX_IDW_DIALOGBAR));
	VERIFY(m_wndStatusBar.Create(this) &&
		m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT)));

	// add windows to rebar
	VERIFY(m_wndReBar.Create(this));
	VERIFY(m_wndReBar.AddBar(&m_wndToolBar));
	VERIFY(m_wndReBar.AddBar(&m_wndDlgBar));

	// TODO: Remove this if you don't want tool tips
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY);

	return 0;
}

// Route commands to view (bolierplate code)
BOOL CMainFrame::OnCmdMsg(UINT a1, int a2, void* a3, AFX_CMDHANDLERINFO* a4)
{
	return m_wndView.OnCmdMsg(a1, a2, a3, a4) ?
		TRUE : CFrameWnd::OnCmdMsg(a1, a2, a3, a4);
}
