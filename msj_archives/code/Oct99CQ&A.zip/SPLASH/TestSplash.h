////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- October 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#pragma once

class CMyApp : public CWinApp {
public:
	CMyApp() { }
	virtual BOOL InitInstance();
	afx_msg void OnAppAbout();
	afx_msg void OnViewSplash();
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNAMIC(CMyApp)
};
