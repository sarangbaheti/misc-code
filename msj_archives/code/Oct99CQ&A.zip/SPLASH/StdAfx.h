#pragma once
#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#include <afxwin.h>		// MFC core and standard components
#include <afxcmn.h>		// MFC support for Windows Common Controls
#include <afxext.h>		// rebar
#include <afxmt.h>		// multithreading objects
