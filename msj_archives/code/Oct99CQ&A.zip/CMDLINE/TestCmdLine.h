////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- October 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#pragma once

class CMyApp : public CWinApp {
public:
	BOOL		m_bFoo;			// -foo flag
	BOOL		m_bBoozle;		// -boozle flag
	CString	m_sMumble;		// -mumble string

	CMyApp() : m_bFoo(0),m_bBoozle(0) { }
	virtual BOOL InitInstance();
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNAMIC(CMyApp)
};

extern CMyApp theApp;
