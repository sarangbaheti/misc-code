////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- October 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#pragma once
#include "View.h"

class CMainFrame : public CFrameWnd {
public:
	CMainFrame()			 { }
	virtual ~CMainFrame() { }
protected:
	virtual BOOL OnCmdMsg(UINT, int, void*, AFX_CMDHANDLERINFO*);
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	// child windows/controlbars
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
	CDialogBar  m_wndDlgBar;
	CReBar      m_wndReBar;
	CMyView		m_wndView;
	
	afx_msg void OnPaint();
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNCREATE(CMainFrame)
};
