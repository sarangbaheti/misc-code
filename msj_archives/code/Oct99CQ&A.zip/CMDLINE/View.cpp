////////////////////////////////////////////////////////////////
// Microsoft Systems Journal -- October 1999
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#include "stdafx.h"
#include "TestCmdLine.h"
#include "resource.h"
#include "View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CMyView, CWnd)
BEGIN_MESSAGE_MAP(CMyView, CWnd)
	ON_WM_PAINT()
END_MESSAGE_MAP()

CMyView::CMyView()
{
}

CMyView::~CMyView()
{
}

inline LPCTSTR BOOLSTR(BOOL b) { return b ? "TRUE" : "FALSE"; }

void CMyView::OnPaint()
{
	CPaintDC dc(this);
	CString s;

	s.Format(_T("bFoo is %s\nbBoozle is %s\nbMumble is \"%s\""),
		BOOLSTR(theApp.m_bFoo),
		BOOLSTR(theApp.m_bBoozle),
		theApp.m_sMumble);
	CRect rc;
	GetClientRect(&rc);
	dc.DrawText(s, &rc, 0);
}

