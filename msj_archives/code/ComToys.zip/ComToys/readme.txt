To build COM Toys and MyBands, type 

MakeAll

This builds all versions of the COM Toys library (static, dynamic, and
extension DLL, debug and release), and four versions of MyBands: COM Toys
statically linked (DebugS, ReleaseS directories) and COM Toys dynamically
linked (Debug, Release directories). Make sure your environment (PATH,
INCLUDE, LIB) is set up to run Visual C++.

To install MyBands, cd to the directory containing the version of MyBands you
want to install and type

\windows\system\regsvr32.exe MyBands.dll

If you choose a version of MyBands that uses the COM Toys DLL, you will also
have to copy cty.dll and/or ctyd.dll to some directory in your search path. 

To see TRACE output, run to program TraceWin.exe included in this directory,
then install one of the debug versions of MyBands.dll. When you run MyBands
(right click in the task bar, select Toolbars | Web Search Band), you should
see the TRACE diagnostics.

Happy Programming, and remember: if the code doesn't work, I didn't write it.

Paul DiLascia
9-9-99
