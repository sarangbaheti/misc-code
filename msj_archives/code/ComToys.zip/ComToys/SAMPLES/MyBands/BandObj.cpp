////////////////////////////////////////////////////////////////
// Copyright 1998 Paul DiLascia
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// ---
// CBandObj-- generic Windows band object (IE Info/comm band and desktop band).
// Provides default implementation for IDeskBand. You must also include the
// band object registration script, BandObj.rgs, in your RC file.
//
//
#include "StdAfx.h"
#include "BandObj.h"
#include "atliface.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define BANDOBJCLASS (_T("MSJ_DeskBandClass"))

// To turn on debugging, set this TRUE
BOOL CBandObj::bTRACE = FALSE;

#ifdef _DEBUG
#define BOTRACEFN				\
	CTraceFn __fooble;		\
	if (CBandObj::bTRACE)	\
		TRACE						
#define BOTRACE				\
	if (CBandObj::bTRACE)	\
		TRACE
#else
#define BOTRACEFN
#define BOTRACE
#endif

DEBUG_BEGIN_INTERFACE_NAMES()
	DEBUG_INTERFACE_NAME(IDeskBand)
DEBUG_END_INTERFACE_NAMES();

IMPLEMENT_DYNAMIC(CBandObjDll, CTMfcModule);

CBandObjDll::CBandObjDll()
{
}

CBandObjDll::~CBandObjDll()
{
}

//////////////////
// Call from your InitInstance to add a new band object class.
//
BOOL CBandObjDll::AddBandClass(REFCLSID clsid, CRuntimeClass* pClass,
	const CATID& catid, UINT nResID)
{
	BOTRACEFN(_T("CBandObjDll::AddBandClass\n"));
	return OnCreateFactory(clsid, pClass, catid, nResID)!=NULL;
}

//////////////////
// Override if you ever want to create a different kind of factory (rare)
//
CBandObjFactory* CBandObjDll::OnCreateFactory(REFCLSID clsid,
	CRuntimeClass* pClass, const CATID& catid, UINT nResID)
{
	return new CBandObjFactory(clsid, pClass, catid, nResID);
}

////////////////////////////////////////////////////////////////
// CBandObjFactory
//
IMPLEMENT_DYNAMIC(CBandObjFactory, COleObjectFactory)

CBandObjFactory::CBandObjFactory(REFCLSID clsid, CRuntimeClass* pClass,
	const CATID& catid, UINT nIDRes)
	:  CTFactory(clsid, nIDRes),
		COleObjectFactory(clsid, pClass, FALSE, NULL)
{
	BOTRACEFN(_T("CBandObjFactory::CBandObjFactory\n"));
	ASSERT(pClass && pClass->IsDerivedFrom(RUNTIME_CLASS(CBandObj)));
	m_catid = catid;
}

CBandObjFactory::~CBandObjFactory()
{
	BOTRACEFN(_T("CBandObjFactory::~CBandObjFactory\n"));
}

////////////////
// Band objects are not insertable, so bypass MFC's standard
// registration. There's no ProgID
//
BOOL CBandObjFactory::OnRegister(BOOL bRegister)
{
	BOTRACEFN(_T("CBandObjFactory(%p)::OnRegister(%d)\n"), this, bRegister);

	if (!CTFactory::OnRegister(bRegister))
		return FALSE;

	// Get ICatRegister
	CTCatRegister iCat;
	HRESULT hr = bRegister ?
		iCat->RegisterClassImplCategories(CTFactory::GetClassID(),1,&m_catid) :
		iCat->UnRegisterClassImplCategories(CTFactory::GetClassID(),1,&m_catid);
	return SUCCEEDED(S_OK) || !bRegister;	// if can't unregister, ignore
}

BOOL CBandObjFactory::UpdateRegistry(BOOL bRegister)
{
	return TRUE; // bypass MFC stuff, not using it
}

////////////////////////////////////////////////////////////////
// CBandObj

CBandObj::CBandObj(REFCLSID clsid) :
	CTOleWindow(m_hWnd),
	CTDockingWindow(m_hWnd),
	CTPersist(clsid),
	CTPersistStream(m_bModified),
	CTInputObject(m_hWnd, m_hAccel),
	CTMfcContextMenu(this, m_menu)
{
	BOTRACEFN(_T("CBandObj(%p)::CBandObj\n"),this);
	AfxOleLockApp(); // don't unload DLL while I'm alive

   m_dwBandID = m_dwViewMode = 0;

	// set up default DESKBANDINFO
	m_dbiDefault.ptMinSize = CPointL(-1,-1);
	m_dbiDefault.ptMaxSize = CPointL(-1,-1);
	m_dbiDefault.ptActual  = CPointL(0,0);
	m_dbiDefault.ptIntegral= CPointL(1,1);
	m_dbiDefault.dwModeFlags = DBIMF_NORMAL;

	// stuff to initialize from factory
	CTFactory* pFact = CTFactory::GetFactory(clsid);
	m_nIDRes = pFact->GetResourceID();
	m_strTitle = pFact->GetTitle();
	m_bModified = FALSE;
}

CBandObj::~CBandObj()
{
	BOTRACEFN(_T("CBandObj(%p)::~CBandObj\n"), this);
	AfxOleUnlockApp();	// OK by me to unload DLL
}

//////////////////
// called when ref count goes to zero: delete myself
//
void CBandObj::OnFinalRelease()
{
	BOTRACEFN(_T("CBandObj(%p)::OnFinalRelease\n"), this);
	CCmdTarget::OnFinalRelease(); // will delete this
}

/////////////////
// These macros implement all the interfaces using ComToys classes!
//
IMPLEMENT_IUnknownCT			(CBandObj);
IMPLEMENT_IOleWindow			(CBandObj, CTOleWindow);
IMPLEMENT_IDockingWindow	(CBandObj, CTDockingWindow);
IMPLEMENT_IPersist			(CBandObj, CTPersist);
IMPLEMENT_IContextMenu		(CBandObj, CTMfcContextMenu);
IMPLEMENT_IPersistStream	(CBandObj, CTPersistStream);
IMPLEMENT_IInputObject		(CBandObj, CTInputObject);

//////////////////
// This CCmdTarget override is used to bypass MFC's interface
// maps in CCmdTarget::InternalQueryInterface.
//
LPUNKNOWN CBandObj::GetInterfaceHook(const void* piid)
{
	return GetInterface(*((IID*)piid));
}

//////////////////
// This CTComObj override tells CTComObj what interface to use.
//
LPUNKNOWN CBandObj::GetInterface(REFIID iid)
{
	if (iid==IID_IUnknown) 
		return (IDeskBand*)this;

#define IF_INTERFACE(iid, iface)										\
	if (iid==IID_##iface)												\
		return (iface*)this;												\

	IF_INTERFACE(iid, IOleWindow);
	IF_INTERFACE(iid, IDockingWindow);
	IF_INTERFACE(iid, IObjectWithSite);
	IF_INTERFACE(iid, IInputObject);
	IF_INTERFACE(iid, IPersist);
	IF_INTERFACE(iid, IPersistStream);
	IF_INTERFACE(iid, IContextMenu);
	IF_INTERFACE(iid, IDeskBand);

	return NULL;
}

// **************** IDeskBand ****************

/////////////////
// Windows wants band info: stuff with m_dbiDefault
// or resource information
//
STDMETHODIMP CBandObj::GetBandInfo(DWORD dwBandID, DWORD dwViewMode,
	DESKBANDINFO* pdbi)
{
	CMDTARGENTRY;
	BOTRACEFN(_T("CBandObj(%p)::IDeskBand::GetBandInfo id=%d mode=%0x\n"),
		this, dwBandID, dwViewMode);

   m_dwBandID = dwBandID;					 // save in case you're interested
   m_dwViewMode = dwViewMode;				 // ditto

	if (!pdbi) 
		return E_INVALIDARG;

	DWORD mask = pdbi->dwMask;
	if (mask & DBIM_MINSIZE)
		pdbi->ptMinSize = m_dbiDefault.ptMinSize;

	if (mask & DBIM_MAXSIZE)
		pdbi->ptMaxSize = m_dbiDefault.ptMaxSize;

	if (mask & DBIM_INTEGRAL)
		pdbi->ptIntegral = m_dbiDefault.ptIntegral;

	if (mask & DBIM_ACTUAL)  // desired size
		pdbi->ptActual = m_dbiDefault.ptActual;

	if (mask & DBIM_TITLE) {
		USES_CONVERSION;
		lstrcpyW(pdbi->wszTitle, T2OLE(GetTitle()));
	}

	if (mask & DBIM_MODEFLAGS)
		pdbi->dwModeFlags = m_dbiDefault.dwModeFlags;

	if (mask & DBIM_BKCOLOR)
		pdbi->dwMask &= ~DBIM_BKCOLOR;	 // clear to use default color

	return S_OK;
}

// **************** IObjectWithSite ****************

//////////////////
// SetSite set the site and create window
//
STDMETHODIMP CBandObj::SetSite(IUnknown* pSite)
{
	CMDTARGENTRY;
	BOTRACEFN(_T("CBandObj(%p)::IObjectWithSite::SetSite %p\n"), this, pSite);

	// Standard implementation
	HRESULT hr = CTInputObjectSite::SetSite(pSite);
	if (!SUCCEEDED(hr))
		return hr;

	if (pSite!=NULL) {
		// Get parent window, which is site's window
		CComQIPtr<IOleWindow> spOleWin = m_spSite;
		if (!spOleWin)
			return E_FAIL;

		HWND hwndParent = NULL;
		spOleWin->GetWindow(&hwndParent);
		if (!hwndParent)
			return E_FAIL;

		CWnd* pParent = CWnd::FromHandle(hwndParent);
		ASSERT_VALID(pParent);
		CRect rc;
		pParent->GetClientRect(&rc);

		// Call virtual Create fn to create the window
		if (!OnCreateWindow(pParent, rc))
			return E_FAIL;
	}
	return S_OK;
}

// use standard implementation for GetSite
IMPLEMENT_IObjectWithSite_GetSite(CBandObj, CTInputObjectSite);

////////////////////////////////////////////////////////////////
// CBandObj MFC fns
//
IMPLEMENT_DYNAMIC(CBandObj, CWnd)
BEGIN_MESSAGE_MAP(CBandObj, CWnd)
	ON_WM_CREATE()
   ON_WM_SETFOCUS()
   ON_WM_KILLFOCUS()
	ON_WM_MOUSEACTIVATE()
END_MESSAGE_MAP()

//////////////////
// Create the window. You can override to do your own thing
//
BOOL CBandObj::OnCreateWindow(CWnd* pParent, const CRect& rc)
{
	static BOOL bRegistered = FALSE;
	static CCriticalSection cs; // protect static global
	CTLockData lock(cs);

	// register window class if not already
	if (!bRegistered) {
		WNDCLASS wc;
		memset(&wc, 0, sizeof(wc));
		wc.style = CS_HREDRAW | CS_VREDRAW | CS_GLOBALCLASS;
		wc.lpfnWndProc = (WNDPROC)::DefWindowProc; // will get hooked by MFC
		wc.hInstance = AfxGetInstanceHandle();
      wc.hCursor = LoadCursor(NULL, IDC_ARROW);
      wc.hbrBackground = CreateSolidBrush(GetSysColor(COLOR_WINDOW));
      wc.lpszMenuName = NULL;
      wc.lpszClassName = BANDOBJCLASS;
		if (!AfxRegisterClass(&wc)) {
			TRACE(_T("*** CBandObj::GetWindow - AfxRegisterClass failed!\n"));
			return FALSE;
		}
		bRegistered = TRUE;
	}

	// create the window
	if (!CWnd::Create(BANDOBJCLASS, GetTitle(),
		WS_CHILD|WS_CLIPSIBLINGS|WS_BORDER,
		rc, pParent, m_dwBandID, NULL)) {

		TRACE(_T("*** CBandObj::GetWindow failed to create window!\n"));
		return FALSE;
	}
	return TRUE;
}

//////////////////
// Window is being created: load context menu and accels, if any
//
int CBandObj::OnCreate(LPCREATESTRUCT lpcs)
{
	BOTRACEFN(_T("CBandObj(%p)::OnCreate\n"), this);

	// Load context menu if any. context menu is 1st submenu in resource menu.
	CMenu menu;
	if (menu.LoadMenu(GetResourceID())) {
		HMENU hSubMenu = ::GetSubMenu(menu, 0);
		if (hSubMenu) {
			m_menu.Attach(hSubMenu);
			menu.Detach(); // otherwise destructor will destroy my menu!
		}
	}

	// Load accelerators if any
	m_hAccel = ::LoadAccelerators(AfxGetInstanceHandle(),
		MAKEINTRESOURCE(GetResourceID()));

	// If there's no main window, install myself as main window,
	// so PreTranslateMessage etc will work. 
	//
	CWinApp*	pApp = AfxGetApp();
	ASSERT_VALID(pApp);
	if (pApp->m_pMainWnd) {
		TRACE(_T("*** CBandObj: WARNING: Main window already exists ***\n"));
	} else (!pApp->m_pMainWnd); {
		pApp->m_pMainWnd = this;
	}
	return CWnd::OnCreate(lpcs);
}

//////////////////
// This is required to route commands to the app object, which is normally
// done in MFC by CFrameWnd
//
BOOL CBandObj::OnCmdMsg(UINT nID, int nCode, void* pExtra,
	AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// pump through myself first
	if (CWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// pump through app
	CWinApp* pApp = AfxGetApp();
	if (pApp != NULL && pApp->OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	return FALSE;
}

//////////////////
// Focus handling stuff
//
void CBandObj::OnSetFocus(CWnd* pOldWnd)
{
	BOTRACEFN(_T("CBandObj(%p)::OnSetFocus\n"), this);
	OnFocusChange(TRUE);
}

void CBandObj::OnKillFocus(CWnd* pNewWnd)
{
	BOTRACEFN(_T("CBandObj(%p)::OnKillFocus\n"), this);
	OnFocusChange(FALSE);
}

//////////////////
// focus changed: tell site
//
void CBandObj::OnFocusChange(BOOL bFocus)
{
	BOTRACEFN(_T("CBandObj(%p)::OnFocusChange\n"), this);
	if (m_spSite) {
		m_spSite->OnFocusChangeIS((IDockingWindow*)this, bFocus);
	}
}

int CBandObj::OnMouseActivate(CWnd* pDesktopWnd, UINT nHitTest, UINT msg)
{
	SetFocus();
	return MA_ACTIVATE;
}

#include "DllEntry.cpp"
