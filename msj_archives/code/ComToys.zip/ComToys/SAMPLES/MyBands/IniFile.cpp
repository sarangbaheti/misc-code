////////////////////////////////////////////////////////////////
// Copyright 1998 Paul DiLascia
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "StdAfx.h"
#include "IniFile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

void CIniFile::Use(CWinApp *pApp, int where, LPCTSTR pszProfileName)
{
	TCHAR buf[_MAX_PATH];
	VERIFY(::GetModuleFileName(pApp->m_hInstance, buf, _MAX_PATH));
	LPTSTR ext = _tcsrchr(buf, '.');		 // points to ".exe"
	ASSERT(ext);
	_tcscpy(ext, _T(".INI"));				 // now .INI

	LPTSTR name = _tcsrchr(buf, '\\');	// points to "foo.ini"
	VERIFY(name++);
	if (pszProfileName)
		_tcscpy(name, pszProfileName);
	pszProfileName = where==LocalDir ? buf : name;

	// set the name
	free((void*)pApp->m_pszProfileName);
	pApp->m_pszProfileName = _tcsdup(pszProfileName);
	free((void*)pApp->m_pszRegistryKey);
	pApp->m_pszRegistryKey = NULL;
}
