////////////////////////////////////////////////////////////////
// Copyright 1998 Paul DiLascia
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "StdAfx.h"
#include "MyBands.h"
#include "Debug.h"
#include "TraceWin.h"
#include "resource.h"
#include "ComToys.h"
#include "IniFile.h"
#include <initguid.h> // so my GUIDs are created

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BEGIN_MESSAGE_MAP(CMyBandsDll, CBandObjDll)
END_MESSAGE_MAP()

CMyBandsDll theApp;

// {4647E381-520B-11d2-A0D0-004033D0645D}
DEFINE_GUID(CLSID_MYINFOBAND,
0x4647e381, 0x520b, 0x11d2, 0xa0, 0xd0, 0x0, 0x40, 0x33, 0xd0, 0x64, 0x5d);

// {4647E382-520B-11d2-A0D0-004033D0645D}
DEFINE_GUID(CLSID_MYCOMMBAND,
0x4647e382, 0x520b, 0x11d2, 0xa0, 0xd0, 0x0, 0x40, 0x33, 0xd0, 0x64, 0x5d);

// {4647E383-520B-11d2-A0D0-004033D0645D}
DEFINE_GUID(CLSID_MYDESKBAND,
0x4647e383, 0x520b, 0x11d2, 0xa0, 0xd0, 0x0, 0x40, 0x33, 0xd0, 0x64, 0x5d);

CMyBandsDll::CMyBandsDll()
{
	CBandObj::bTRACE=TRUE; // TRACEing on for bandobj
	ComToys::bTRACE=TRUE;  // TRACEing on for COM toys
}

CMyBandsDll::~CMyBandsDll()
{
}

//////////////////
// initialize: add each band class
//
BOOL CMyBandsDll::InitInstance()
{
	TRACEFN(_T("CMyBandsDll::InitInstance\n"));
//	SetRegistryKey(_T("MSJ"));
	CIniFile::Use(this, CIniFile::LocalDir);

	VERIFY(AddBandClass(CLSID_MYINFOBAND,
		RUNTIME_CLASS(CMyInfoBand),
		CATID_InfoBand,
		IDR_INFOBAND));

	VERIFY(AddBandClass(CLSID_MYCOMMBAND,
		RUNTIME_CLASS(CMyCommBand),
		CATID_CommBand,
		IDR_COMMBAND));

	VERIFY(AddBandClass(CLSID_MYDESKBAND,
		RUNTIME_CLASS(CMyDeskBand),
		CATID_DeskBand,
		IDR_DESKBAND));

	return CBandObjDll::InitInstance();
}

//////////////// CMyIEBand ////////////////

IMPLEMENT_DYNAMIC(CMyIEBand, CBandObj)
BEGIN_MESSAGE_MAP(CMyIEBand, CBandObj)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_ERASEBKGND()
	ON_COMMAND_RANGE(ID_COMMAND1, ID_COMMAND2, OnCommand)
END_MESSAGE_MAP()

CMyIEBand::CMyIEBand(REFIID clsid) : CBandObj(clsid)
{
}

CMyIEBand::~CMyIEBand()
{
}

BOOL CMyIEBand::OnEraseBkgnd(CDC* pDC)
{
	CClientDC dc(this);
	CRect rc;
	GetClientRect(&rc);
	dc.FillSolidRect(&rc, m_bgColor);
	return TRUE;
}

void CMyIEBand::OnPaint()
{
	CPaintDC dc(this);
	CRect rc;
	GetClientRect(&rc);
	dc.SetTextColor(RGB(0,0,0));
	dc.SetBkMode(TRANSPARENT);
	dc.DrawText(m_message, -1, &rc, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
}

void CMyIEBand::OnCommand(UINT nID)
{
	CString s;
	s.Format(_T("Command %d received!"), nID-ID_COMMAND1+1);
	GetParent()->MessageBox(s, GetTitle(), MB_OK | MB_ICONINFORMATION);
	SetFocus();
}

//////////////////
// SetSite override gets web browser when Explorer sets itself as my site
// Note as opposed to MyBands1, this is a direct override of IObjectWithSite,
// not a special virtual function.
//
STDMETHODIMP CMyIEBand::SetSite(IUnknown* pSite)
{
	HRESULT hr = CBandObj::SetSite(pSite);
	if (SUCCEEDED(hr)) {
		CComQIPtr<IServiceProvider> sp = pSite;
		if (sp)
			sp->QueryService(IID_IWebBrowserApp,
				IID_IWebBrowser2, (void**)&m_spWebBrowser2);
		else
			m_spWebBrowser2 = (LPUNKNOWN)NULL;
	}
	return hr;
}

//////////////////
// Mouse click: navigate to page
//
void CMyIEBand::OnLButtonDown(UINT nFlags, CPoint point)
{
	if (m_spWebBrowser2) {
		m_spWebBrowser2->Navigate(_bstr_t(m_url), NULL, NULL, NULL, NULL);
	}
}

//////////////// CMyCommBand ////////////////

IMPLEMENT_DYNCREATE(CMyCommBand, CMyIEBand)

CMyCommBand::CMyCommBand() : CMyIEBand(CLSID_MYCOMMBAND)
{
	m_strTitle.Empty();
	m_dbiDefault.ptMinSize = CPointL(-1,30);
	m_dbiDefault.ptMaxSize = CPointL(-1,30);
	m_dbiDefault.ptActual  = CPointL(100,30);
	m_url = _T("http://www.microsoft.com/mind");
	m_message = _T("Buy MInD");
	m_bgColor = RGB(255,0,128);
}

IMPLEMENT_DYNCREATE(CMyInfoBand, CMyIEBand)

CMyInfoBand::CMyInfoBand() : CMyIEBand(CLSID_MYINFOBAND)
{
	m_dbiDefault.dwModeFlags = DBIMF_VARIABLEHEIGHT;
	m_dbiDefault.ptActual = CPointL(10,-1);
	m_url = _T("http://www.microsoft.com/msj");
	m_message = _T("MSJ");
	m_bgColor = RGB(255,255,255);
}

//////////////// CMyDeskBand ////////////////

IMPLEMENT_DYNCREATE(CMyDeskBand, CBandObj)
BEGIN_MESSAGE_MAP(CMyDeskBand, CBandObj)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
END_MESSAGE_MAP()

CMyDeskBand::CMyDeskBand() : CBandObj(CLSID_MYDESKBAND),
	m_wndEdit(_T("SearchStrings"))
{
	const CXDESIRED = 100;	 // desired width = 100
	m_dbiDefault.ptActual  = CPointL(CXDESIRED,0);
	m_dbiDefault.dwModeFlags = DBIMF_VARIABLEHEIGHT;
}

CMyDeskBand::~CMyDeskBand()
{
}

//////////////////
// I'm being created: create edit control ad set band obj
// context menu from edit search control
//
int CMyDeskBand::OnCreate(LPCREATESTRUCT lpcs)
{
	TRACE(_T("CMyDeskBand::OnCreate\n"));
	if (CBandObj::OnCreate(lpcs)==-1)
		return -1;
	m_wndEdit.Create(WS_VISIBLE|WS_CHILD, CRect(0,0,0,0), this, 1);
	m_wndEdit.CreateSearchMenu(m_menu);
	return 0;
}

//////////////////
// Window was resized: adjust edit control
//
void CMyDeskBand::OnSize(UINT nType, int cx, int cy)
{
	TRACE(_T("CMyDeskBand::OnSize(%d,%d)\n"),cx,cy);
	CBandObj::OnSize(nType, cx, cy);
	CRect rc(CPoint(0,0),CSize(cx,cy));
	rc.DeflateRect(2,2);
	m_wndEdit.SetWindowPos(NULL, rc.left, rc.top, rc.Width(), rc.Height(), 0);
}

//////////////////
// I got focus: pass to edit control
//
void CMyDeskBand::OnSetFocus(CWnd* pOldWnd)
{
	CBandObj::OnSetFocus(pOldWnd);
	m_wndEdit.SetFocus();
}

//////////////////
// route commands through edit control
//
BOOL CMyDeskBand::OnCmdMsg(UINT a, int b, void* c, AFX_CMDHANDLERINFO* d)
{
	return m_wndEdit.OnCmdMsg(a, b, c, d) ? TRUE :
		CBandObj::OnCmdMsg(a, b, c, d);
}
