////////////////////////////////////////////////////////////////
// Copyright 1998 Paul DiLascia
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// See MyBands.cpp
//
#include "Resource.h"
#include "BandObj.h"
#include "EditSearch.h"

//////////////////
// Application class: derive from CBandObjApp
//
class CMyBandsDll : public CBandObjDll {
public:
	CMyBandsDll();
	virtual ~CMyBandsDll();
	virtual BOOL InitInstance();
protected:
	DECLARE_MESSAGE_MAP()
};

DECLARE_SMARTPTR(IWebBrowser2);

//////////////////
// common base class for info and comm bands
//
class CMyIEBand : public CBandObj {
public:
	CMyIEBand(REFIID clsid);
	~CMyIEBand();
	
protected:
	SPIWebBrowser2 m_spWebBrowser2;		 // browser interface
	CString	m_message;						 // window text
	COLORREF m_bgColor;						 // background color
	CString	m_url;							 // where to go when clicked

	STDMETHOD(SetSite)(IUnknown* pSite);

	DECLARE_MESSAGE_MAP();
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnCommand(UINT nID);
	DECLARE_DYNAMIC(CMyIEBand)
};

//////////////////
// Info band lives in IE left pane
//
class CMyInfoBand : public CMyIEBand {
public:
	CMyInfoBand();
	DECLARE_DYNCREATE(CMyInfoBand)
};


//////////////////
// Comm band lives in IE bottom pane
//
class CMyCommBand : public CMyIEBand {
public:
	CMyCommBand();
	DECLARE_DYNCREATE(CMyCommBand)
};

//////////////////
// Desk band lives in task bar
//
class CMyDeskBand : public CBandObj {
public:
	CMyDeskBand();
	~CMyDeskBand();

protected:
	CEditSearch m_wndEdit;

	// override
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra,
		AFX_CMDHANDLERINFO* pHandlerInfo);

	afx_msg void OnPaint();
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	DECLARE_MESSAGE_MAP();
	DECLARE_DYNCREATE(CMyDeskBand)
};

