////////////////////////////////////////////////////////////////
// Copyright 1998 Paul DiLascia
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// 
#pragma once

#include <ComToys.h>

DECLARE_SMARTPTR(IInputObjectSite)

//////////////////
// Handly to initialize a POINTL
struct CPointL : public POINTL {
	CPointL(long xx, long yy) { x=xx; y=yy; }
};

//////////////////
// class factory used to create band objects
//
class CBandObjFactory : public COleObjectFactory, public CTFactory {
protected:
	CATID m_catid;		// band object categroy ID
public:
	CBandObjFactory(REFCLSID clsid, CRuntimeClass* pClass,
		const CATID& catid, UINT nResID);
	~CBandObjFactory();

	const CATID& GetCatID() { return m_catid; }

	// overrides
	virtual BOOL OnRegister(BOOL bRegister);
	virtual BOOL UpdateRegistry(BOOL bRegister);
	DECLARE_DYNAMIC(CBandObjFactory)
};

//////////////////
// This is here just in case there's ever a need to do
// band-obj stuff derive your DLL from this
//
class CBandObjDll : public CTMfcModule {
protected:
	CBandObjDll();
	virtual ~CBandObjDll();

public:
	virtual BOOL AddBandClass(REFCLSID clsid, CRuntimeClass* pClass,
		const CATID& catid, UINT nResID);

	// so you can override (rare)
	virtual CBandObjFactory* OnCreateFactory(REFCLSID clsid,
		CRuntimeClass* pClass, const CATID& catid, UINT nResID);

	DECLARE_DYNAMIC(CBandObjDll);
};

// to reduce typing and angle brackets :)
typedef CTObjectWithSite<IInputObjectSite> CTInputObjectSite;

//////////////////
// The band object! Common implementation for info, comm and desk bands.
// This is a CWnd, and it also inherits all the band object COM interfaces.
//
class CBandObj : public CWnd,

	// interfaces
// public IUnknown,			// inherited
//	public IOleWindow,		// inherited
//	public IDockingWindow,	// inherited
	public IDeskBand,
	public IObjectWithSite,
	public IInputObject,
//	public IPersist,			// inherited
	public IPersistStream,
	public IContextMenu,

	// implementations 
	public CTOleWindow,
	public CTDockingWindow,
	public CTPersist,
	public CTPersistStream,
	public CTInputObject,
	public CTInputObjectSite,
	public CTMfcContextMenu
{
protected:
	DESKBANDINFO m_dbiDefault;		// default band info
	CString	m_strTitle;				// window title
	UINT		m_nIDRes;				// resource ID
	DWORD		m_dwBandID;				// band ID (from Windows)
	DWORD		m_dwViewMode;			// view mode (from Windows)
	CMenu		m_menu;					// context menu
	HACCEL	m_hAccel;				// accelerators
	BOOL		m_bModified;			// always FALSE;

public:
	static BOOL bTRACE; // controls tracing

	CBandObj(REFCLSID clsid);
	virtual ~CBandObj();

	UINT		GetResourceID()	{ return m_nIDRes; }
	CString	GetTitle()			{ return m_strTitle; }

	// overrides
	virtual LPUNKNOWN GetInterface(REFIID iid);
	virtual LPUNKNOWN GetInterfaceHook(const void* iid);
	virtual void		OnFinalRelease();

	// MFC overrides
	virtual BOOL OnCmdMsg(UINT, int, void*, AFX_CMDHANDLERINFO*);

	// new fns
	virtual void OnFocusChange(BOOL bFocus);
	virtual BOOL OnCreateWindow(CWnd* pParent, const CRect& rc);

   // interfaces implemented
	DECLARE_IUnknown();
	DECLARE_IOleWindow();
	DECLARE_IDockingWindow();
	DECLARE_IInputObject();
	DECLARE_IPersist();
	DECLARE_IPersistStream();
	DECLARE_IContextMenu();
	DECLARE_IObjectWithSite();
   STDMETHOD (GetBandInfo) (DWORD, DWORD, DESKBANDINFO*);    // IDeskBand

protected:
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg int  OnMouseActivate(CWnd* pDesktopWnd, UINT nHitTest, UINT message);
	DECLARE_MESSAGE_MAP();
	DECLARE_DYNAMIC(CBandObj)
};
