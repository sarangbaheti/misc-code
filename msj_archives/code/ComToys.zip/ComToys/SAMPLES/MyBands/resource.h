//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MyBands.rc
//
#define IDR_INFOBAND                    1
#define IDR_COMMBAND                    2
#define IDR_DESKBAND                    3
#define ID_COMMAND1                     1000
#define ID_COMMAND2                     1001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        100
#define _APS_NEXT_COMMAND_VALUE         1003
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
