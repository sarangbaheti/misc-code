#pragma once

#include "MenuInit.h"

class CEditSearch : public CEdit {
public:
	enum {ID_FIRST_SEARCHSTRING=100, MAXNUMSEARCHSTRINGS=16};

	CEditSearch(LPCTSTR pszRegKey);
	virtual ~CEditSearch();

	UINT LoadDefaults();
	UINT LoadProfile();
	void SaveProfile();
	BOOL CreateSearchMenu(CMenu& menu, BOOL bIncludeEditCmds=FALSE);
	void DoSearch();

protected:
	CPopupMenuInitHandler m_popupInit;	 // context menu handler
	CString	m_sRegKey;						 // where to save settings
	CFont		m_font;							 // font used
	BOOL		m_bNewlyActive;				 // I just got activated

	CString m_arSearchNames[MAXNUMSEARCHSTRINGS];
	CString m_arSearchStrings[MAXNUMSEARCHSTRINGS];
	UINT m_nSearchStrings;
	UINT m_iCurrentSearchString;

	// overrides
	virtual void PreSubclassWindow();
	virtual void PostNcDestroy();
	virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp);

	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint pos);
	afx_msg void OnSetSearch(UINT nID);
	afx_msg void OnUpdateSearchItem(CCmdUI* pCmdUI);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg UINT OnGetDlgCode()	{ return DLGC_WANTALLKEYS; }
	afx_msg void OnEditCut()		{ SendMessage(WM_CUT); }
	afx_msg void OnEditCopy()		{ SendMessage(WM_COPY); }
	afx_msg void OnEditPaste()		{ SendMessage(WM_PASTE); }
	afx_msg void OnUpdateCopy(CCmdUI* pCmdUI)	{ OnUpdateCut(pCmdUI); }
	afx_msg void OnUpdateCut(CCmdUI* pCmdUI)	{
		int start,end;
		GetSel(start, end);
		pCmdUI->Enable(end>start); }

	DECLARE_MESSAGE_MAP();
	DECLARE_DYNAMIC(CEditSearch);
};

