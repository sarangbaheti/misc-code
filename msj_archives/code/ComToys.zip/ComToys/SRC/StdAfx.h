#include <afxwin.h>         // MFC core and standard components
#include <afxdisp.h>        // MFC OLE automation classes
#include <afxpriv.h>        // For Unicode conversion macros
#include <afxctl.h>			 // control stuff
#include <afxmt.h>			 // Multithreading
#include <shlobj.h>			 // for IDeskBand ettc
#include <comdef.h>			 // for _bstr_t etc.
#include <atlbase.h>			 // ATL stuff

