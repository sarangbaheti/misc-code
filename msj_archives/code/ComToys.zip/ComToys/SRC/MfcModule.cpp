////////////////////////////////////////////////////////////////
// ComToys(TM) Copyright 1999 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "StdAfx.h"
#include "ComToys.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CTMfcModule, COleControlModule);

CTMfcModule::CTMfcModule()
{
}

CTMfcModule::~CTMfcModule()
{
}

BOOL CTMfcModule::InitInstance()
{
	CTTRACEFN(_T("CTMfcModule::InitInstance\n"));
	if (!CTModule::InitInstance(CWinApp::m_hInstance))
		return FALSE;
	return COleControlModule::InitInstance();
}

int CTMfcModule::ExitInstance()
{
	CTTRACEFN(_T("CTMfcModule::ExitInstance\n"));
	CTModule::ExitInstance();
	return COleControlModule::ExitInstance();
}

/////////////////////////////////////////////////////////////////////////////
// Implementation special DLL entry points.
// Call MFC to do the work.

HRESULT CTMfcModule::OnGetClassObject(REFCLSID clsid, REFIID iid, LPVOID* ppv)
{
	CTTRACEFN(_T("CTMfcModule::OnGetClassObject\n"));
	HRESULT hr = AfxDllGetClassObject(clsid, iid, ppv);
	if (*ppv==NULL) {
		TRACE(_T("***CTMfcModule::OnGetClassObject failed\n"));
		TRACE(_T("***Did you create factories before calling CTMfcModule::InitInstance?\n"));
	}
	return hr;
}

HRESULT CTMfcModule::OnCanUnloadNow(void)
{
	CTTRACEFN(_T("CTMfcModule::OnCanUnloadNow\n"));
	return AfxDllCanUnloadNow();
}

HRESULT CTMfcModule::OnRegisterServer(BOOL bRegister)
{
	CTTRACEFN(_T("CTMfcModule::OnRegisterServer\n"));
	HRESULT hr =CTModule::OnRegisterServer(bRegister);
	if (hr!=S_OK)
		return hr;
	return COleObjectFactory::UpdateRegistryAll(bRegister)
		? S_OK : SELFREG_E_CLASS;
}

HRESULT CTMfcModule::OnInstall(BOOL bInstall, LPCWSTR pszCmdLine)
{
	CTTRACEFN(_T("CTMfcModule::OnInstall\n"));
	return CTModule::OnInstall(bInstall, pszCmdLine);
}
