////////////////////////////////////////////////////////////////
// ComToys(TM) Copyright 1999 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "StdAfx.h"
#include "ComToys.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

DEBUG_BEGIN_INTERFACE_NAMES()
	DEBUG_INTERFACE_NAME(IContextMenu)
	DEBUG_INTERFACE_NAME(IContextMenu2)
	DEBUG_INTERFACE_NAME(IContextMenu3)
DEBUG_END_INTERFACE_NAMES();

CTMfcContextMenu::CTMfcContextMenu(CCmdTarget* pTarg, CMenu& menu)
	: m_ctxMenu(menu)
{
	m_pCmdTarget = pTarg;
	m_bMenuSeperator = FALSE;	// add separator after appending menu?
	m_bAutoMenuEnable = TRUE;	// like MFC frame: disable cmds with no handler
}

//////////////////
// Get menu string: default is resource string
//
CString CTMfcContextMenu::OnGetMenuString(UINT nID)
{
	CString s;
	s.LoadString(nID);
	return s;
}

//////////////////
// Add menu items to client's menu
//
STDMETHODIMP CTMfcContextMenu::QueryContextMenu(HMENU hmenu, UINT index,
	UINT idCmdFirst, UINT idCmdLast, UINT uFlags)
{
	CTTRACEFN(_T("CTMfcContextMenu::QueryContextMenu(0x%x,i=%d,first=%d,last=%d,flags=0x%x)\n"),
		hmenu, index, idCmdFirst, idCmdLast, uFlags);

	USHORT uRet = 0;
	if (m_ctxMenu && !(uFlags & CMF_DEFAULTONLY)) {
		for (UINT i=0; i<m_ctxMenu.GetMenuItemCount(); i++) {
			InitMenuItem(m_pCmdTarget, m_ctxMenu, i);
			UINT nMyID = m_ctxMenu.GetMenuItemID(i);
			if (idCmdFirst+nMyID <= idCmdLast) {
				CString sItem;
				m_ctxMenu.GetMenuString(i, sItem, MF_BYPOSITION);
				if (InsertMenu(hmenu, index,
					m_ctxMenu.GetMenuState(i, MF_BYPOSITION) | MF_BYPOSITION,
					idCmdFirst+nMyID,
					(LPCTSTR)sItem)) {
					index++;
				}
				uRet = nMyID+1;
			}
		}
		if (m_bMenuSeperator)
			InsertMenu(hmenu, index, MF_SEPARATOR|MF_BYPOSITION,-1,NULL);
	}
	return MAKE_HRESULT(SEVERITY_SUCCESS, 0, uRet);
}

//////////////////
// Initialize menu item. This works for any item in a context menu
//
void CTMfcContextMenu::InitMenuItem(CCmdTarget* pTarg, CMenu& menu, UINT nIndex)
{
	CCmdUI state;
	state.m_pMenu = &m_ctxMenu;
	state.m_nIndex = nIndex;
	state.m_nIndexMax = menu.GetMenuItemCount();
	state.m_nID = menu.GetMenuItemID(nIndex);
	if (state.m_nID == (UINT)-1) {
		// possibly a popup menu, route to first item of that popup
		state.m_pSubMenu = menu.GetSubMenu(nIndex);
		if (state.m_pSubMenu == NULL ||
			(state.m_nID = state.m_pSubMenu->GetMenuItemID(0)) == 0 ||
			state.m_nID == (UINT)-1) {
			// first item of popup can't be routed to
		}
		state.DoUpdate(pTarg, FALSE);    // popups are never auto disabled

	} else {
		// normal menu item
		// Auto enable/disable if 'm_bAutoMenuEnable'
		// and command is _not_ a system command.
		state.m_pSubMenu = NULL;
		state.DoUpdate(pTarg, m_bAutoMenuEnable);
	}
}

//////////////////
// Invoke a context menu command
//
STDMETHODIMP CTMfcContextMenu::InvokeCommand(LPCMINVOKECOMMANDINFO lpcmi)
{
	TRACE(_T("CTMfcContextMenu::InvokeCommand\n"));
	if (HIWORD(lpcmi->lpVerb)==0) {
		// save CMINVOKECOMMANDINFO so caller can use it if needed
		//
		m_cmi = *lpcmi;

		// Simulate WM_COMMAND. MFC will route to appropriate cmd target
		//
		m_pCmdTarget->OnCmdMsg(LOWORD(lpcmi->lpVerb), CN_COMMAND, NULL, NULL);
		return NOERROR;
	}
	return E_NOTIMPL;
}

//////////////////
// Copy command string or help text into caller's buffer
//
STDMETHODIMP CTMfcContextMenu::GetCommandString(UINT nID, UINT uFlags,
	UINT*, LPSTR pszName, UINT cchMax)
{
	TRACE(_T("CTMfcContextMenu::GetCommandString(%d)\n"),nID);
	HRESULT hr = E_INVALIDARG;

	ASSERT(m_ctxMenu);

	CString str;
	BOOL bCopy = TRUE;						 // assume I will return the string
	if (uFlags==GCS_HELPTEXT) {
		// get prompt string
		CString sRes = OnGetMenuString(nID);
		AfxExtractSubString(str, sRes, 0);

	} else if ((uFlags==GCS_VERB || uFlags==GCS_VALIDATE)) {
		// get menu item itself
		if (m_ctxMenu.GetMenuString(nID, str, MF_BYCOMMAND)) {
			if (uFlags==GCS_VALIDATE) {
				// don't copy for GCS_VALIDATE
				bCopy = FALSE;
			}
			hr = NOERROR;
		}
	}
	if (bCopy) {
		strncpy(pszName, str, cchMax);
		pszName[cchMax-1]=0;
	}

	return hr;
}

