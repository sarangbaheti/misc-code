#include "StdAfx.h"

// The following symbol used to force inclusion of this module 
extern "C" { int _ctForceLinkSTDAFX; }
