// Who.h : Declaration of the CWho

#ifndef __WHO_H_
#define __WHO_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CWho
class ATL_NO_VTABLE CWho : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CWho, &CLSID_Who>,
	public IDispatchImpl<IWho, &IID_IWho, &LIBID_WHOISLib>
{
public:
	CWho()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_WHO)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CWho)
	COM_INTERFACE_ENTRY(IWho)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IWho
public:
	STDMETHOD(WhoIsCaller)(/*[out, retval]*/ BSTR* pval);
};

#endif //__WHO_H_
