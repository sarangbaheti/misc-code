/*****************************************************************************
Module :     MSJTimeClient.c
Notices:     Written 1997 by Jeffrey Richter
Description: Client to request machine system time
*****************************************************************************/


#define STRICT
#include <Windows.h>
#include <WindowsX.h>
#include "Resource.h"


//////////////////////////////////////////////////////////////////////////////


#define dimof(A)  (sizeof(A) / sizeof(A[0]))


// The normal HANDLE_MSG macro in WINDOWSX.H does not work properly for
// dialog boxes because DlgProc's return a BOOL instead of an LRESULT (like
// WndProcs). This chHANDLE_DLGMSG macro corrects the problem:
#define chHANDLE_DLGMSG(hwnd, message, fn)                           \
   case (message): return (SetDlgMsgResult(hwnd, uMsg,               \
      HANDLE_##message((hwnd), (wParam), (lParam), (fn))))


//////////////////////////////////////////////////////////////////////////////


BOOL MSJTimeClient_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam) {

   // Assume that the server is on the same machine as the client
   SetDlgItemText(hwnd, IDC_SERVER, __TEXT("."));
   return(TRUE);
}


//////////////////////////////////////////////////////////////////////////////


void MSJTimeClient_OnCommand(HWND hwnd, int id, HWND hwndCtl, 
   UINT codeNotify) {

   SYSTEMTIME st;
   TCHAR sz[500];
   DWORD cbRead = 0;
   HANDLE hpipe;
   BOOL fOk;

   switch (id) {
   case IDCANCEL:
      EndDialog(hwnd, id); 
      break;

   case IDOK:
      // Construct the pathname of the pipe
      sz[0] = sz[1] = __TEXT('\\');
      GetDlgItemText(hwnd, IDC_SERVER, &sz[2], dimof(sz) - 2);
      lstrcat(sz, __TEXT("\\pipe\\MSJTime"));

      // Attempt to connect to the pipe
      fOk = WaitNamedPipe(sz, NMPWAIT_USE_DEFAULT_WAIT);
      if (fOk) {
         // Get a handle to use to talk to the pipe
         hpipe = CreateFile(sz, GENERIC_READ, 0, NULL, 
            OPEN_EXISTING, 0, NULL);
         fOk = (hpipe != INVALID_HANDLE_VALUE);
      }

      if (fOk) {
         // Valid handle, read time from pipe
         ReadFile(hpipe, &st, sizeof(st), &cbRead, NULL);
         CloseHandle(hpipe);

         // Convert UTC time to client machine's local time and display it
         SystemTimeToTzSpecificLocalTime(NULL, &st, &st);

         GetDateFormat(LOCALE_USER_DEFAULT, DATE_LONGDATE, &st, 
            NULL, sz, dimof(sz));
         SetDlgItemText(hwnd, IDC_DATE, sz);

         GetTimeFormat(LOCALE_USER_DEFAULT, LOCALE_NOUSEROVERRIDE, &st, 
            NULL, sz, dimof(sz));
         SetDlgItemText(hwnd, IDC_TIME, sz);

      } else {
         LPCTSTR pszError = (GetLastError() == ERROR_FILE_NOT_FOUND) 
            ? __TEXT("Service not found") : __TEXT("Service busy");

         SetDlgItemText(hwnd, IDC_DATE, pszError);
         SetDlgItemText(hwnd, IDC_TIME, pszError);
      }
      break;
   }
}


//////////////////////////////////////////////////////////////////////////////


BOOL WINAPI MSJTimeClient_DlgProc(HWND hwnd, UINT uMsg, 
   WPARAM wParam, LPARAM lParam) {

   switch (uMsg) {
      chHANDLE_DLGMSG(hwnd, WM_INITDIALOG, MSJTimeClient_OnInitDialog);
      chHANDLE_DLGMSG(hwnd, WM_COMMAND, MSJTimeClient_OnCommand);
   }
   return(FALSE);
}


//////////////////////////////////////////////////////////////////////////////


int WINAPI WinMain (HINSTANCE hinstExe, HINSTANCE hinstExePrev, 
   LPSTR pszCmdLine, int nCmdShow) {

   return(DialogBox(hinstExe, MAKEINTRESOURCE(IDD_MSJTIMECLIENT), NULL, 
      MSJTimeClient_DlgProc));
}


//////////////////////////////// End Of File /////////////////////////////////
