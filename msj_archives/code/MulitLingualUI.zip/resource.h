//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Globaldv.rc
//
#define IDC_MYICON                      2
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDS_LOADLIBRARYFAILED           104
#define IDM_EXIT                        105
#define IDI_GLOBALDEV                  107
#define IDI_SMALL                       108
#define IDM_MENU                        109
#define IDS_GLOBALDEV                  109
#define IDA_GLOBALDEV                  109
#define IDS_INITFAILED			111
#define IDS_UILANGCHANGED               112
#define ID_EDITCONTROL		113
#define IDE_CLOSE			114
#define IDE_CLEAR			115
#define IDE_EDIT_FONT		116
#define IDE_READINGORDER		117
#define IDE_TOGGLEALIGN		118

#define IDC_TYPE                        -1

#define IDD_SELECTUI                    130
#define IDD_USEEDITCONTROL     132

#define IDC_UILANGLIST                  1000
#define IDM_CLEAR                       32771
#define IDM_CHANGEFONT                  32775
#define IDM_INTERFACE                   32776
#define IDM_TOGGLEREADINGORDER          32777
#define IDM_TOGGLEALIGNMENT             32778
#define IDM_USEEDITCONTROL		32780
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           119
#endif
#endif

#ifndef WS_EX_LAYOUTRTL
#define WS_EX_NOINHERITLAYOUT   0x00100000L 
#define WS_EX_LAYOUTRTL         0x00400000L  // Right to left mirroring
#endif
