//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by res409.rc
//
#define IDD_TESTNLS                     132
#define IDM_TESTNLS                     32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           113
#endif
#endif
