////////////////////////////////////////////////////////////////
// 1999 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#include "stdafx.h"
#include "resource.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const CXANIMATION = 36;	// width = 40 pizels

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_WM_SETFOCUS()
	ON_COMMAND(ID_ANIM_START, OnAnimStart)
	ON_COMMAND(ID_ANIM_STOP,  OnAnimStop)
	ON_UPDATE_COMMAND_UI(ID_ANIM_START, OnUpdateAnimStart)
	ON_UPDATE_COMMAND_UI(ID_ANIM_STOP,  OnUpdateAnimStop)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

CMainFrame::CMainFrame() : m_wndToolBar(CXANIMATION, IDR_MYANIMATION)
{
	m_bPlaying = FALSE;
}

CMainFrame::~CMainFrame()
{
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if(!CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.cx = 400;
	cs.cy = 200;
	return TRUE;
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	// create myself
	VERIFY(CFrameWnd::OnCreate(lpCreateStruct)==0);

	// create view
	VERIFY(m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW,
		CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL));

	// create all the rebar windows
	VERIFY(m_wndToolBar.CreateEx(this) &&
		m_wndToolBar.LoadToolBar(IDR_MAINFRAME));
	VERIFY(m_wndToolBar.m_wndAnim.Open(IDR_MYANIMATION));
	OnAnimStart();								 // start playing

	VERIFY(m_wndStatusBar.Create(this) &&
		m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT)));

	// TODO: Remove this if you don't want tool tips
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY);

	return 0;
}

void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	m_wndView.SetFocus();
}

// Route commands to view (bolierplate code)
BOOL CMainFrame::OnCmdMsg(UINT a1, int a2, void* a3, AFX_CMDHANDLERINFO* a4)
{
	return m_wndView.OnCmdMsg(a1, a2, a3, a4) ?
		TRUE : CFrameWnd::OnCmdMsg(a1, a2, a3, a4);
}

void CMainFrame::OnAnimStart()
{
	if (!m_bPlaying) {
		m_wndToolBar.m_wndAnim.Play(0, -1, -1);
		m_bPlaying = TRUE;
	}
}

void CMainFrame::OnUpdateAnimStart(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(!m_bPlaying);
}

void CMainFrame::OnAnimStop()
{
	if (m_bPlaying) {
		m_wndToolBar.m_wndAnim.Stop();
		m_bPlaying = FALSE;
	}
}

void CMainFrame::OnUpdateAnimStop(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_bPlaying);
}

////////////////////////////////////////////////////////////////
// CMyView

IMPLEMENT_DYNAMIC(CMyView, CWnd)
BEGIN_MESSAGE_MAP(CMyView, CWnd)
	ON_WM_PAINT()
END_MESSAGE_MAP()

void CMyView::OnPaint()
{
	CPaintDC dc(this);
	CRect rc;
	GetClientRect(&rc);
	CBrush brush;
	brush.CreateSolidBrush(GetSysColor(COLOR_WINDOW));
	dc.FillRect(&rc, &brush);
}
