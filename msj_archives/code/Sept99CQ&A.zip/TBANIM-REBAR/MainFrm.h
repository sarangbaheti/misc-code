////////////////////////////////////////////////////////////////
// 1999 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#include "TBAnim.h"

class CMyView : public CWnd {
public:
	CMyView() { }
	virtual ~CMyView() { }
protected:
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNAMIC(CMyView)
};

class CMainFrame : public CFrameWnd {
public:
	CMainFrame()			 { m_bPlaying = FALSE; }
	virtual ~CMainFrame() { }
protected:
	virtual BOOL OnCmdMsg(UINT, int, void*, AFX_CMDHANDLERINFO*);
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	// child windows/controlbars
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
	CDialogBar  m_wndDlgBar;
	CTBAnim		m_wndAnim;					 // toolbar animation contol
	CReBar      m_wndReBar;
	CMyView		m_wndView;					 // my view
	BOOL			m_bPlaying;					 // animation is playing?

	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSetFocus(CWnd *pOldWnd);
	afx_msg void OnAnimStart();
	afx_msg void OnAnimStop();
	afx_msg void OnUpdateAnimStart(CCmdUI* pCmdUI);
	afx_msg void OnUpdateAnimStop(CCmdUI* pCmdUI);
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNAMIC(CMainFrame)
};
