////////////////////////////////////////////////////////////////
// 1999 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#include "StatLink.h"

#define DEFAULT_ANIM_STYLE WS_CHILD | WS_VISIBLE | ACS_CENTER

////////////////
// Toolbar animation control that has a hyperlink.
//
class CTBAnim : public CAnimateCtrl {
public:
	CTBAnim(LPCTSTR lpszURL=NULL) : m_link(lpszURL) { }
	virtual ~CTBAnim() { }
	CHyperlink m_link;						 // go here when clicked

protected:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg UINT OnNcHitTest(CPoint point);
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNCREATE(CTBAnim)
};

//////////////////
// Derive your toolbar from this if you're not using a rebar.
//
class CAnimToolBar : public CToolBar {
public:
	CAnimToolBar(UINT nWidthAnim, UINT nResID) {
		m_nWidthAnim = nWidthAnim;
		m_nIDAnim = nResID;
	}
	~CAnimToolBar() { }
	CTBAnim m_wndAnim;	// animation control

protected:
	int m_nWidthAnim;		// width of animation
	int m_nIDAnim;			// resource ID of animation

	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	DECLARE_DYNAMIC(CAnimToolBar)
	DECLARE_MESSAGE_MAP()
};
