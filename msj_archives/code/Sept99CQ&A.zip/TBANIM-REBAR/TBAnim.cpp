////////////////////////////////////////////////////////////////
// 1999 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#include "StdAfx.h"
#include "TBAnim.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CTBAnim, CAnimateCtrl)
BEGIN_MESSAGE_MAP(CTBAnim, CAnimateCtrl)
	ON_WM_NCHITTEST()
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()

//////////////////
// Normally, the animation control returns HTTRANSPARENT, which disallows
// mouse clicks; need to return HTCLIENT to get WM_LBUTTONDOWN, etc.
//
UINT CTBAnim::OnNcHitTest(CPoint point)
{
	return HTCLIENT;
}

//////////////////
// User clicked: launch the hyperlink
// If string is empty, load it from resource.
// 
void CTBAnim::OnLButtonDown(UINT nFlags, CPoint point)
{
	if (m_link.IsEmpty())
		m_link.LoadString(GetDlgCtrlID());
	m_link.Navigate();
}

////////////////////////////////////////////////////////////////
// CAnimToolBar

IMPLEMENT_DYNAMIC(CAnimToolBar, CToolBar)
BEGIN_MESSAGE_MAP(CAnimToolBar, CToolBar)
	ON_WM_CREATE()
	ON_WM_SIZE()
END_MESSAGE_MAP()

//////////////////
// Create handler: create the animation control
//
int CAnimToolBar::OnCreate(LPCREATESTRUCT lpcs)
{
	if (CToolBar::OnCreate(lpcs)==-1)
		return -1;
	m_wndAnim.Create(DEFAULT_ANIM_STYLE, CRect(0,0,0,0), this, m_nIDAnim);
	return 0;
}

//////////////////
// Size handler: size the animation control
//
void CAnimToolBar::OnSize(UINT nType, int cx, int cy)
{
	CToolBar::OnSize(nType, cx, cy);
	CRect rc(cx-m_nWidthAnim, 0, cx, cy);	// right edge
	m_wndAnim.MoveWindow(&rc);					// do it
}
