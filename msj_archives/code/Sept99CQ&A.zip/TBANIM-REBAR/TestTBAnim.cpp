////////////////////////////////////////////////////////////////
// 1999 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#include "StdAfx.h"
#include "resource.h"
#include "TestTBAnim.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CMyApp, CWinApp)
BEGIN_MESSAGE_MAP(CMyApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
END_MESSAGE_MAP()

CMyApp theApp;

BOOL CMyApp::InitInstance()
{
	CMainFrame* pFrame = new CMainFrame;
	m_pMainWnd = pFrame;
	pFrame->LoadFrame(IDR_MAINFRAME);
	pFrame->ShowWindow(SW_SHOW);
	pFrame->UpdateWindow();
	return TRUE;
}

//////////////////
// Custom dialog uses CStaticLink for hyperlinks.
// Same dialog class works for both applets (resource ID determines dialog)
//
class CAboutDialog : public CDialog {
protected:
	CStaticLink	m_wndLink1;
	CStaticLink	m_wndLink2;
	virtual BOOL OnInitDialog() {
		m_wndLink1.SubclassDlgItem(IDC_MSJURL, this);
		m_wndLink2.SubclassDlgItem(IDC_PDURL,  this);
		return CDialog::OnInitDialog();
	}
public:
	CAboutDialog() : CDialog(IDD_ABOUTBOX, NULL) { }
};

void CMyApp::OnAppAbout()
{
	CAboutDialog().DoModal(); 
}
