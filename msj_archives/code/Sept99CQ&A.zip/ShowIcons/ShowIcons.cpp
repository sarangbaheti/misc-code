////////////////////////////////////////////////////////////////
// 1999 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
// ---
// ShowIcons shows how to extract icons from an EXE or DLL,
// and how to convert them from icons to bitmaps.
// See doc.cpp and view.cpp for details.
//
#include "stdafx.h"
#include "ShowIcons.h"
#include "MainFrm.h"
#include "Doc.h"
#include "View.h"
#include "StatLink.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BEGIN_MESSAGE_MAP(CMyApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_NEW,  CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

CMyApp theApp;

CMyApp::CMyApp()
{
}

//////////////////
// Generic
//
BOOL CMyApp::InitInstance()
{
	SetRegistryKey(_T("MSJ"));
	LoadStdProfileSettings(8);

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CIconsDoc),
		RUNTIME_CLASS(CMainFrame),
		RUNTIME_CLASS(CIconsView));
	AddDocTemplate(pDocTemplate);

	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();

	return TRUE;
}

//////////////////
// Custom dialog uses CStaticLink for hyperlinks.
// Same dialog class works for both applets (resource ID determines dialog)
//
class CAboutDialog : public CDialog {
protected:
	CStaticLink	m_wndLink1;
	CStaticLink	m_wndLink2;
	virtual BOOL OnInitDialog() {
		m_wndLink1.SubclassDlgItem(IDC_MSJURL, this);
		m_wndLink2.SubclassDlgItem(IDC_PDURL,  this);
		return CDialog::OnInitDialog();
	}
public:
	CAboutDialog() : CDialog(IDD_ABOUTBOX, NULL) { }
};

void CMyApp::OnAppAbout()
{
	CAboutDialog().DoModal();
}
