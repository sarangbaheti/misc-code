////////////////////////////////////////////////////////////////
// 1999 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//////////////////
// Mostly generic mainframe
//
class CMainFrame : public CFrameWnd {
public:
	CMainFrame() { }
	virtual ~CMainFrame() { }
protected:
	CStatusBar			m_wndStatusBar;
	CToolBar				m_wndToolBar;
	afx_msg int			OnCreate(LPCREATESTRUCT lpCreateStruct);

	// view sends a message to get the tooblar control
	afx_msg LRESULT	OnGetToolBar(WPARAM, LPARAM) {
		return (LRESULT)&m_wndToolBar;
	}
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNCREATE(CMainFrame)
};
