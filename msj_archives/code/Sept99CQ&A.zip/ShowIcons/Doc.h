////////////////////////////////////////////////////////////////
// 1999 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

const MAXNUMICONS = 1024;

////////////////
// Document holds an array of small and large icons
//
class CIconsDoc : public CDocument {
public:
	CIconsDoc();
	virtual ~CIconsDoc();

	// public interface
	int GetNumIcons()					{ return m_nIcons; }
	const HICON* GetSmallIcons()	{ return m_pIconsSmall; }
	const HICON* GetLargeIcons()	{ return m_pIconsLarge; }

protected:
	int		m_nIcons;						 // total number of icons
	HICON		m_pIconsSmall[MAXNUMICONS]; // array of small HICONs
	HICON		m_pIconsLarge[MAXNUMICONS]; // array of large HICONs

	// MFC overrides
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void SetTitle(LPCTSTR lpszTitle);

	afx_msg void OnUpdateIconIndicator(CCmdUI* pCmdUI);
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNCREATE(CIconsDoc)
};
