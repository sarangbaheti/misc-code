////////////////////////////////////////////////////////////////
// 1999 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#include "stdafx.h"
#include "ShowIcons.h"
#include "Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CIconsDoc, CDocument)
BEGIN_MESSAGE_MAP(CIconsDoc, CDocument)
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_ICONS, OnUpdateIconIndicator)
END_MESSAGE_MAP()

CIconsDoc::CIconsDoc()
{
}

CIconsDoc::~CIconsDoc()
{
}

BOOL CIconsDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	m_nIcons = -1;
	return TRUE;
}

//////////////////
// Add number of icons to document title
//
void CIconsDoc::SetTitle(LPCTSTR lpszTitle)
{
	CString sTitle;
	if (m_nIcons>=0) {
		sTitle.Format(_T("%s [%d icons]"), lpszTitle, m_nIcons);
		lpszTitle = sTitle;
	}
	CDocument::SetTitle(lpszTitle);
}

//////////////////
// Load all the icons into the array.
// Ignore extra icons if more than MAXNUMICONS (so sorry).
//
void CIconsDoc::Serialize(CArchive& ar)
{
	if (!ar.IsStoring()) {
		m_nIcons = ::ExtractIconEx(
			ar.GetFile()->GetFilePath(),	 // filename
			0,										 // start index
			m_pIconsLarge,						 // array of HICONs
			m_pIconsSmall,						 // ..ditto
			MAXNUMICONS);						 // max num to get
		ASSERT(m_nIcons != -1);
	}
}

//////////////////
// Update the status bar indicator for number of icons
//
void CIconsDoc::OnUpdateIconIndicator(CCmdUI* pCmdUI)
{
	CString s = _T("No File");
	if (m_nIcons>=0)
		s.Format(_T("%d Icons"), m_nIcons);
	pCmdUI->SetText(s);
}
