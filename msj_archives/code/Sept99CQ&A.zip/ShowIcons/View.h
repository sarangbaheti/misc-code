////////////////////////////////////////////////////////////////
// 1999 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "doc.h"

const MYWM_GETTOOLBAR = WM_USER;

//////////////////
// Icon view displays all the icons in its window
//
class CIconsView : public CScrollView {
protected:
	CIconsView() { }
	virtual ~CIconsView() {	}
	CIconsDoc* GetDocument() { return (CIconsDoc*)m_pDocument; }

protected:
	virtual void OnInitialUpdate();
	virtual void OnDraw(CDC* pDC);
	afx_msg void OnFoo();
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNCREATE(CIconsView)
};
