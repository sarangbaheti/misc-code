////////////////////////////////////////////////////////////////
// 1999 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#include "stdafx.h"
#include "ShowIcons.h"
#include "Doc.h"
#include "View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CIconsView, CScrollView)
BEGIN_MESSAGE_MAP(CIconsView, CScrollView)
	ON_COMMAND(ID_FOO, OnFoo)
END_MESSAGE_MAP()

//////////////////
// Initial update: set scroll sizes and change toolbar bitmap.
//
void CIconsView::OnInitialUpdate()
{
	CIconsDoc* pdoc = GetDocument();
	ASSERT_VALID(pdoc);

	CScrollView::OnInitialUpdate();

	// compute width of all icons
	int nIcons = pdoc->GetNumIcons();
	int cx = nIcons > 0 ? nIcons * GetSystemMetrics(SM_CXICON) : 0;

	// ...and height
	int cy = GetSystemMetrics(SM_CYICON) + // normal icon
		GetSystemMetrics(SM_CYSMICON) +		// small icon
		GetSystemMetrics(SM_CYHSCROLL);		// allow room for scroll bar

	// First change window size, height only (leave width alone)
	GetParentFrame()->RecalcLayout();
	CRect rc;
	GetClientRect(&rc);
	SetScrollSizes(MM_TEXT, CSize(rc.Width(), cy));
	ResizeParentToFit();

	// Now that window size is correct, set true scroll sizes
	SetScrollSizes(MM_TEXT, CSize(cx, cy));

	// load toolbar bitmap
	CBitmap bm;
	VERIFY(bm.LoadBitmap(IDR_MAINFRAME));

	CToolBar* pToolBar = (CToolBar*)GetParent()->SendMessage(MYWM_GETTOOLBAR);

	if (nIcons > 0 && pToolBar) {
		// If there's a toolbar, change its first button to be the first
		// small icon in the currently open EXE or DLL

		// create memory DC
		CWindowDC dc(this);
		CDC memdc;
		memdc.CreateCompatibleDC(&dc);

		// select toolbar bitmap
		CBitmap *poldbm = memdc.SelectObject(&bm);

		// draw into the dc/bitmap
		CBrush brush;
		brush.CreateSysColorBrush(COLOR_BTNFACE);
		VERIFY(::DrawIconEx(memdc, 0, 0,	 // dc, x, y
			*pdoc->GetSmallIcons(),			 // HICON (first small one)
			GetSystemMetrics(SM_CXSMICON), // cx
			GetSystemMetrics(SM_CYSMICON), // cy
			0, brush, DI_NORMAL));			 // frame, brush, flags
		memdc.SelectObject(poldbm);
	}

	// Change bitmap in toolbar. This will delete the old one
	pToolBar->SetBitmap((HBITMAP)bm.Detach());
	pToolBar->Invalidate(TRUE);		 // repaint
}

//////////////////
// Draw the icons
//
void CIconsView::OnDraw(CDC* pdc)
{
	CIconsDoc* pdoc = GetDocument();
	ASSERT_VALID(pdoc);
	int nIcons = pdoc->GetNumIcons();
	if (nIcons > 0) {
		const HICON* pIconLarge = pdoc->GetLargeIcons();
		const HICON* pIconSmall = pdoc->GetSmallIcons();
		
		int w = GetSystemMetrics(SM_CXICON);
		int h = GetSystemMetrics(SM_CYICON);
		int wSmall = GetSystemMetrics(SM_CXSMICON);
		int hSmall = GetSystemMetrics(SM_CYSMICON);

		int x = 0;
		for (int i=0; i<nIcons; i++) {
			// NOTE: for normal (large) icons, you could also use
			// CWnd::DrawIcon, which has fewer args, but for small
			// icons, you must use DrawIconEx
			CBrush brush;
			brush.CreateSolidBrush(GetSysColor(COLOR_WINDOW));
			::DrawIconEx(*pdc,x,0,pIconSmall[i],w,h,0,brush,DI_NORMAL);
			::DrawIconEx(*pdc,x,h,pIconSmall[i],wSmall,hSmall,0,brush,DI_NORMAL);
			x += w;
		}
	}
}

void CIconsView::OnFoo()
{
	MessageBox(_T("The icon of this button is always the same\n\
 as the first small icon in the currently open file."));
}

