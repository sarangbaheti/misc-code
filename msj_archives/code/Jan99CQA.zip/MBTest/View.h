////////////////////////////////////////////////////////////////
// Copyright 1998 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "Doc.h"

//////////////////
// Standard edit view lets user select background
//
class CMyView : public CEditView {
public:
	virtual ~CMyView();
	CMyDoc* GetDocument() { return (CMyDoc*)m_pDocument; }
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view

protected:
	CMyView();

	DECLARE_MESSAGE_MAP()
	DECLARE_DYNCREATE(CMyView)
};
