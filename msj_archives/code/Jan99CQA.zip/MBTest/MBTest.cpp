////////////////////////////////////////////////////////////////
// Copyright 1998 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// MBTest is a simple text editor that illustrates the cool UI features
// of PixieLib. Compiles with VC++ 5.0 or later.
//
// _MDIAPP symbol defines whether to generate a MDI app; otherwise SDI

#include "StdAfx.h"
#include "MBTest.h"
#include "MainFrm.h"
#include "View.h"
#include "StatLink.h"
#include "ModulVer.h"
#include "TraceWin.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BEGIN_MESSAGE_MAP(CMyApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

CMyApp::CMyApp()
{
}

CMyApp theApp;

BOOL CMyApp::InitInstance()
{
	SetRegistryKey("PixieLib"); // Save settings in registry, not INI file
	LoadStdProfileSettings(8);  // Load standard INI file options (8 MRU files)

#ifdef _DEBUG
	// turn on extra diagnostics
//	CFlatToolBar::bTRACE = TRUE;
//	CCoolBar::bTRACE = TRUE;
//	CCoolMenuManager::bTRACE = TRUE;
	CMenuBar::bTRACE = TRUE;
#endif

#ifdef _MDIAPP
	AddDocTemplate(new CMultiDocTemplate(IDR_MYDOCTYPE,
		RUNTIME_CLASS(CMyDoc),
		RUNTIME_CLASS(CMDIChildWnd),
		RUNTIME_CLASS(CMyView)));
#else
	AddDocTemplate(new CSingleDocTemplate(IDR_MAINFRAME,
		RUNTIME_CLASS(CMyDoc),
		RUNTIME_CLASS(CMainFrame),
		RUNTIME_CLASS(CMyView)));
#endif
	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

#ifdef _MDIAPP
	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The main window has been initialized, so show and update it.
	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();

#else // SDI app
	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;
#endif
	return TRUE;
}

//////////////////
// Custom about dialog
//
class CAboutDialog : public CDialog {
protected:
	CStatic m_wndComCtl32Version;	 // comctl32.dll version message
	CStaticLink	m_wndLink[3];			 // static controls with hyperlinks
public:
	CAboutDialog() : CDialog(IDD_ABOUTBOX) { }
	virtual BOOL OnInitDialog();
};

/////////////////
// Initialize dialog: subclass static text/icon controls
//
BOOL CAboutDialog::OnInitDialog()
{
	// subclass static controls. URL is static text or 3rd arg
	m_wndLink[0].SubclassDlgItem(IDC_STATICURLPD, this);
	m_wndLink[1].SubclassDlgItem(IDC_STATICURLMSJ, this,
		_T("http://www.microsoft.com/msj"));
	m_wndLink[2].SubclassDlgItem(IDC_MSJICON, this,
		_T("http://www.microsoft.com/msj"));

	// Fill in comctl32.dll version
	m_wndComCtl32Version.SubclassDlgItem(IDC_COMCTL32VER, this);

	CModuleVersion ver;
	DLLVERSIONINFO dvi;
	if (ver.DllGetVersion(_T("comctl32.dll"), dvi)) {
		CString s;
		s.Format(_T("ComCtl32.dll version is %d.%d.%d"),
			dvi.dwMajorVersion, dvi.dwMinorVersion, dvi.dwBuildNumber);
		m_wndComCtl32Version.SetWindowText(s);
	}

	return CDialog::OnInitDialog();
}

//////////////////
// Handle Help | About : run the About dialog
//
void CMyApp::OnAppAbout()
{
	static CAboutDialog dlg; // static to remember state of hyperlinks
	dlg.DoModal();				 // run it
}
