////////////////////////////////////////////////////////////////
// Copyright 1998 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
class CMyDoc : public CDocument {
public:
	virtual ~CMyDoc();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnNewDocument();
protected:
	CMyDoc();
	DECLARE_DYNCREATE(CMyDoc)
	DECLARE_MESSAGE_MAP()
};
