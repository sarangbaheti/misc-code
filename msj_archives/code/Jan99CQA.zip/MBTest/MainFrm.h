////////////////////////////////////////////////////////////////
// Copyright 1998 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "FlatBar.h"
#include "CoolBar.h"
#include "MenuBar.h"
#include "CoolMenu.h"

////////////////
// Special combo box in cool bar used to select which views are displayed
//
class CMyComboBox : public CComboBox {
protected:
	DECLARE_DYNAMIC(CMyComboBox)
	DECLARE_MESSAGE_MAP()
	afx_msg void OnDropDown();
};

/////////////////
// My cool bar. Contains a toolbar, a combo box and menu bar
//
class CMyCoolBar : public CCoolBar {
protected:
	DECLARE_DYNAMIC(CMyCoolBar)
	CFlatToolBar	m_wndToolBar;			 // toolbar
	CMenuBar			m_wndMenuBar;			 // menu bar
	CMyComboBox		m_wndCombo;				 // combo box
	virtual BOOL   OnCreateBands();		 // fn to create the bands
};

/////////////////
// Main frame window has menu manager, cool bar, status bar
//
class CMainFrame : public CFrameWnd {
public:
	CMainFrame();
	~CMainFrame();

protected:
	CStatusBar				m_wndStatusBar; // standard status bar
	CMyCoolBar				m_wndCoolBar;	 // if using coolbar (rebar)
	CBitmap				   m_bmCoolBar;	 // coolbar bitmap
	CCoolMenuManager		m_menuManager;	 // cool (bitmap button) menus

	// helpers
	void ShowCoolbarBitmap(BOOL bShow);

	// overrides
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	// message handlers
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnHideShowCoolBarBitmap();
	afx_msg void OnUpdateHideShowCoolbarBitmap(CCmdUI* pCmdUI);
	afx_msg void OnComboChange();
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNCREATE(CMainFrame)
};
