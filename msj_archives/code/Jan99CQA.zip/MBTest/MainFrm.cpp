////////////////////////////////////////////////////////////////
// Copyright 1998 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "StdAfx.h"
#include "MainFrm.h"
#include "View.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// ID and minimum size of combo box in coolbar band
const IDCOMBO = 1001;
const COMBO_CXMIN = 150;

////////////////////////////////////////////////////////////////
// CMainFrame
//
IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_COMMAND(ID_VIEW_CBBITMAP,			   OnHideShowCoolBarBitmap)
	ON_UPDATE_COMMAND_UI(ID_VIEW_CBBITMAP, OnUpdateHideShowCoolbarBitmap)
	ON_CBN_SELCHANGE(IDCOMBO, OnComboChange)
END_MESSAGE_MAP()

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

////////////////
// Override flicker-free drawing with no CS_VREDRAW and CS_HREDRAW. This has
// nothing to do with coolbars, but it's a good thing to do.
//
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
   cs.lpszClass = AfxRegisterWndClass(
      0,											 // no redraw
      NULL,                             // no cursor (use default)
      NULL,                             // no background brush
      AfxGetApp()->LoadIcon(IDR_MAINFRAME)); // app icon
   ASSERT(cs.lpszClass);
   return CFrameWnd::PreCreateWindow(cs);
}

//////////////////
// Create handler creates control bars
//
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	VERIFY(CFrameWnd::OnCreate(lpCreateStruct) == 0);

	// Create status bar
	static UINT indicators[] = {
		ID_SEPARATOR, ID_INDICATOR_CAPS, ID_INDICATOR_NUM, ID_INDICATOR_SCRL };

	VERIFY(m_wndStatusBar.Create(this));
	VERIFY(m_wndStatusBar.SetIndicators(indicators,
		sizeof(indicators)/sizeof(indicators[0])));
		
	CMyCoolBar& cb = m_wndCoolBar;
	VERIFY(cb.Create(this,
		WS_CHILD|WS_VISIBLE|WS_BORDER|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|
			RBS_TOOLTIPS|RBS_BANDBORDERS|RBS_VARHEIGHT));

	cb.SetColors(GetSysColor(COLOR_BTNTEXT),
		GetSysColor(COLOR_3DFACE));
	ShowCoolbarBitmap(TRUE);

	// add dropdown button, but only if comctl32 version >= 4.71 (IE 4)
	//
	if (CFixMFCToolBar::iVerComCtl32 >= 471) {
		cb.m_wndToolBar.AddDropDownButton(ID_FILE_OPEN,
			IDR_FILEDROPDOWN, TRUE);
	}

	// install/load cool menus
	m_menuManager.Install(this);
	m_menuManager.LoadToolbar(IDR_MAINFRAME);

	return 0;
}

//////////////////
// Toggle coolbar Bitmap
//
void CMainFrame::OnHideShowCoolBarBitmap()
{
	ShowCoolbarBitmap(m_bmCoolBar.GetSafeHandle() ? FALSE : TRUE);
}
void CMainFrame::OnUpdateHideShowCoolbarBitmap(CCmdUI* pCmdUI)
{
	pCmdUI->SetText(m_bmCoolBar.GetSafeHandle() ?
		_T("Hide Coolbar &Bitmap") : _T("Show Coolbar &Bitmap"));
}

void CMainFrame::ShowCoolbarBitmap(BOOL bShow)
{
	if (bShow) {
		// show bitmap: load if needed
		if (!m_bmCoolBar.GetSafeHandle()) {

			// load bitmap
			HBITMAP hbm = (HBITMAP)::LoadImage(AfxGetResourceHandle(),
				MAKEINTRESOURCE(IDB_COOLBARBG),
				IMAGE_BITMAP,
				0, 0,
				LR_LOADMAP3DCOLORS|LR_LOADTRANSPARENT);
			ASSERT(hbm);
			m_bmCoolBar.Attach(hbm);
		}
	} else {
		// hide bitmap: delete if needed
		if (m_bmCoolBar.GetSafeHandle()) {
			m_bmCoolBar.DeleteObject();		 // delete bitmap
		}
	}
	m_wndCoolBar.SetBackgroundBitmap(&m_bmCoolBar);
	m_wndCoolBar.Invalidate();
}

//////////////////
// Command handler for combo box select
//
void CMainFrame::OnComboChange()
{
	CString s;
	m_wndCoolBar.m_wndCombo.GetWindowText(s);
	AfxGetApp()->OpenDocumentFile(s);
}

//////////////////
// Give Menu bar a chance to pre-translate messages. This is CRITICAL!
// You MUST call CMenuBar::TranslateFrameMessage() to translate mnemonics.
//
BOOL CMainFrame::PreTranslateMessage(MSG* pMsg)
{
	return m_wndCoolBar.m_wndMenuBar.TranslateFrameMessage(pMsg) ?
		TRUE : CFrameWnd::PreTranslateMessage(pMsg);
}

////////////////////////////////////////////////////////////////
// CMyCoolBar
//
IMPLEMENT_DYNAMIC(CMyCoolBar, CCoolBar)

////////////////
// This is the virtual function you have to override to add bands
//
BOOL CMyCoolBar::OnCreateBands()
{
	//////////////////
	// Create menu bar
	CMenuBar& mb = m_wndMenuBar;

	VERIFY(mb.Create(this, WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|
		CBRS_TOOLTIPS|CBRS_SIZE_DYNAMIC|CBRS_FLYBY|CBRS_ORIENT_HORZ));
	mb.ModifyStyle(0, TBSTYLE_TRANSPARENT);

	// Load doc or main menu. Only required since this app flips
	// between coolbar/toolbars.
	CFrameWnd *pParent = GetParentFrame();
	CFrameWnd* pFrame = pParent->GetActiveFrame();
	mb.LoadMenu(IDR_MAINFRAME);

	CRect rc;
	mb.GetItemRect(0, &rc);
	CSize szMenu = mb.CalcDynamicLayout(-1, LM_HORZ); // get min horz size

	// create menu bar band.
	CSize szMin;
	szMin = CSize( szMenu.cx, rc.Height());
	if (!InsertBand(&mb, szMin, 0x7ff))
		return FALSE;

	//////////////////
	// Create tool bar
	CFlatToolBar& tb = m_wndToolBar;
	VERIFY(tb.Create(this,
		WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|
			CBRS_TOOLTIPS|CBRS_SIZE_DYNAMIC|CBRS_FLYBY|CBRS_ORIENT_HORZ));
	VERIFY(tb.LoadToolBar(IDR_MAINFRAME)); 
	// use transparent so coolbar bitmap will show through
	tb.ModifyStyle(0, TBSTYLE_TRANSPARENT);

	// Get minimum size of toolbar, which is basically size of one button
	CSize szHorz = tb.CalcDynamicLayout(-1, LM_HORZ); // get min horz size
	tb.GetItemRect(0, &rc);
	szMin = rc.Size(); // CSize( szHorz.cx, rc.Height()); 

	// create toolbar band. Use largest size possible
	if (!InsertBand(&tb, szMin, 0x7fff, NULL, -1, TRUE))
		return FALSE;

	//////////////////
	// Create combo box and fill with data
	CRect rcCombo(0,0,0,0);
	m_wndCombo.Create(WS_VISIBLE|WS_CHILD|WS_VSCROLL|CBS_DROPDOWNLIST|
		WS_CLIPCHILDREN|WS_CLIPSIBLINGS, rcCombo, this, IDCOMBO);
	m_wndCombo.SetFont(GetFont());

	static LPCTSTR data[] = {		// initial combo data
		_T("c:\\autoexec.bat"),
		_T("c:\\config.sys"),
		_T("c:\\bootlog.txt"),
		NULL
	};
	for (LPCTSTR *p=data; *p; p++)
		m_wndCombo.AddString(*p);
	m_wndCombo.SetCurSel(-1);

	// create combo band
	szMin.cx = COMBO_CXMIN;
	if (!InsertBand(&m_wndCombo, szMin, 0, _T("System files:")))
		return FALSE;

	return TRUE; // OK
}

////////////////////////////////////////////////////////////////
// CMyComboBox
//
IMPLEMENT_DYNAMIC(CMyComboBox, CComboBox)

BEGIN_MESSAGE_MAP(CMyComboBox, CComboBox)
	ON_CONTROL_REFLECT(CBN_DROPDOWN, OnDropDown)
END_MESSAGE_MAP()

//////////////////
// Must resize the combo when I get CBN_DROPDOWN
//		
void CMyComboBox::OnDropDown()
{
	CRect rc;
	GetWindowRect(&rc);
	SetWindowPos(NULL,0,0,rc.Width(),200, // use same width but taller height
		SWP_NOMOVE|SWP_NOACTIVATE);
}
