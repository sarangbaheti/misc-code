//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MBTest.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME	                128
#define IDR_MSJLINK  	                129
#define IDB_COOLBARBG                   132
#define ID_BUTTONTEST                   134
#define IDR_FILEDROPDOWN                137
#define IDC_STATICURLPD                 1000
#define IDC_STATICURLMSJ                1001
#define IDC_MSJICON		                1002
#define IDC_COMCTL32VER                 1003
#define ID_DISABLED                     32773
#define ID_VIEW_CBBITMAP                32811

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32819
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
