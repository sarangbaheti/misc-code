////////////////////////////////////////////////////////////////
// Copyright 1998 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// See MBTest.cpp
// 
#include "resource.h" // main symbols

class CMyApp : public CWinApp {
public:
	CMyApp();
	virtual BOOL InitInstance();
protected:
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};
