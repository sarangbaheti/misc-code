/*----------------------------------------------------------------------
John Robbins
Microsoft Systems Journal, October 1997 - Dem Bugs!
----------------------------------------------------------------------*/

#ifndef _PCH_H
#define _PCH_H

// Why can't windows.h compile with warning level 4?
#pragma warning (disable : 4201)
#pragma warning (disable : 4514)
#pragma warning (disable : 4127)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <tchar.h>

#include "msjdbg.h"


#endif      // _PCH_H
