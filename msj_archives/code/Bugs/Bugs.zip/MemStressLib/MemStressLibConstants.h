/*----------------------------------------------------------------------
FILE        :   MemStressLibConstants.h
DISCUSSION  :
    Holds all the constants for the MemStress library.
----------------------------------------------------------------------*/

#ifndef _MEMSTRESSLIBCONSTANTS_H
#define _MEMSTRESSLIBCONSTANTS_H

// The name of the INI file.
const LPCSTR k_INI_FILENAME = "MEMSTRESS.INI" ;

// The name of the default program.
const LPCSTR k_INI_DEFAULTSECTION = "(Defaults For All)" ;

// The keys written for each program.
const LPCSTR k_INI_CRTCHECKMEM         = "CRT Check Memory"            ;
const LPCSTR k_INI_CRTDELAYMEM         = "CRT Delay Memory Frees"      ;
const LPCSTR k_INI_CRTCHECKLEAKS       = "CRT Leak Checking"           ;
const LPCSTR k_INI_GENFAILALLALLOCS    = "GEN OPT Fail All Allocs"     ;
const LPCSTR k_INI_GENFAILEVERYNALLOCS = "GEN OPT Fail Every N Allocs" ;
const LPCSTR k_INI_GENFAILAFTERXBYTES  = "GEN OPT Fail After X Bytes"  ;
const LPCSTR k_INI_GENFAILOVERYBYTES   = "GEN OPT Fail Over Y Bytes"   ;
const LPCSTR k_INI_GENASKONEACHALLOC   = "GEN OPT Ask On Each Alloc"   ;
const LPCSTR k_INI_GENNUMFILEFAILURES  = "Number of files to fail"     ;
const LPCSTR k_INI_GENFILEFAILPREFIX   = "File#"                       ;

// The seperator for the file and line number for file entries.
const LPCSTR k_SEP_FILEANDLINE = " & " ;

// The message box constants for when asking the user.
const LPCSTR k_MSGFMT =
                      "Press 'Yes' to fail the allocation in %s at %d" ;
const LPCSTR k_MSGTITLE = "C/C++ Memory Stress" ;

#endif      // _MEMSTRESSLIBCONSTANTS_H


