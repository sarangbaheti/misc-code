/*----------------------------------------------------------------------
John Robbins
Microsoft Systems Journal, October 1997 - Dem Bugs!
----------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>
#include <iostream.h>
#include "MemDumperValidator.h"

class TestClass
{
public:
    TestClass ( void )
    {
        strcpy ( m_szData , "TestClass constructor data!" ) ;
    }
    ~TestClass ( void )
    {
        m_szData[ 0 ] = '\0' ;
    }

    // The declaration of the memory debugging stuff for C++ classes.
    DECLARE_MEMDEBUG ( TestClass ) ;

private     :
    char m_szData[ 100 ] ;

} ;

// This set up the static DVINFO
IMPLEMENT_MEMDEBUG ( TestClass ) ;

// The functions that you must implement to do the dumping and
//  validating.
#ifdef _DEBUG
void TestClass::ClassDumper ( const void * pData )
{
    TestClass * pClass = (TestClass*)pData ;
    _RPT1 ( _CRT_WARN ,
            " TestClass::ClassDumper : %s\n" ,
            pClass->m_szData ) ;
}
void TestClass::ClassValidator ( const void * pData   ,
                                 const void *          )
{
    // Do any validation on the data here,
    TestClass * pClass = (TestClass*)pData ;
    _RPT1 ( _CRT_WARN                           ,
            " TestClass::ClassValidator : %s\n" ,
            pClass->m_szData                     ) ;
}
#endif

typedef struct tag_SimpleStruct
{
    char szName[ 256 ] ;
    char szRank[ 256 ] ;
} SimpleStruct ;

// The dumper and validator for simple string data memory.
void DumperOne ( const void * pData )
{
    _RPT1 ( _CRT_WARN , " Data is : %s\n" , pData ) ;
}

void ValidatorOne ( const void * pData , const void * pContext )
{
    // Do any validation on the string data here.
    _RPT2 ( _CRT_WARN ,
            " Validator called with : %s : 0x%08X\n" ,
            pData , pContext ) ;
}

// The dumper and validator for the structure allocations.
void DumperTwo ( const void * pData )
{
    _RPT2 ( _CRT_WARN                       ,
             " Data is Name : %s\n"
             "         Rank : %s\n"         ,
             ((SimpleStruct*)pData)->szName   ,
             ((SimpleStruct*)pData)->szRank    ) ;
}

void ValidatorTwo ( const void * pData , const void * pContext )
{
    // Do any structure validations here.
    _RPT2 ( _CRT_WARN ,
            " Validator called with : %s : 0x%08X\n" ,
            pData , pContext ) ;
}

// The C functions, unfortunately, need to have predefined values for
//  the client blocks.  The best bet is to try and make them high
//  enough that they stay out of the way.  In a real world application,
//  these should all be centrally located in a single header file that
//  everyone includes.
#define ONE_CB  CLIENT_BLOCK_VALUE(10)
#define TWO_CB  CLIENT_BLOCK_VALUE(11)

void main ( void )
{
    cout << "At start of main\n" ;

    // Do the memory debugging initialization stuff for type one.
    INITIALIZE_MEMDEBUG ( ONE_CB , DumperOne , ValidatorOne )  ;
    // The memory debugging initialization for number two.
    INITIALIZE_MEMDEBUG ( TWO_CB , DumperTwo , ValidatorTwo )  ;

    // Allocate the class with the memory debugging new.
    TestClass * pstClass ;
    //pstClass = MEMDEBUG_NEW TestClass ;
    pstClass = new TestClass ;

    // Allocate the two C types.
    char * p = (char*)MEMDEBUG_MALLOC ( ONE_CB , 10 ) ;
    strcpy ( p , "VC VC" ) ;

    SimpleStruct * pSt =
            (SimpleStruct*)MEMDEBUG_MALLOC ( TWO_CB ,
                                             sizeof ( SimpleStruct ) ) ;

    strcpy ( pSt->szName , "Pam" ) ;
    strcpy ( pSt->szRank , "CINC" ) ;

    // Validate all the blocks in the list.
    VALIDATEALLBLOCKS ( NULL ) ;

    cout << "At end of main\n" ;

    // Everything will get dumped as part of the memory leak checking.

}
