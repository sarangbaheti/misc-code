/*----------------------------------------------------------------------
John Robbins
Microsoft Systems Journal, October 1997 - Dem Bugs!
----------------------------------------------------------------------*/
#if !defined(AFX_STDAFX_H)
#define AFX_STDAFX_H

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define VC_EXTRALEAN

#include <afxwin.h>
#include <afxext.h>
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>
#endif // _AFX_NO_AFXCMN_SUPPORT

#include "MemStressLib.h"
#define new DEBUG_NEW

//{{AFX_INSERT_LOCATION}}


#endif
