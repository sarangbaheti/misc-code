/*----------------------------------------------------------------------
John Robbins
Microsoft Systems Journal, October 1997 - Dem Bugs!
----------------------------------------------------------------------*/

#if !defined(AFX_MEMSTRESSDEMO_H)
#define AFX_MEMSTRESSDEMO_H

#if _MSC_VER >= 1000
    #pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
    #error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"           // main symbols

////////////////////////////////////////////////////////////////////////
// CMemStressDemoApp:
// See MemStressDemo.cpp for the implementation of this class
//

class CMemStressDemoApp : public CWinApp
{
public:
    CMemStressDemoApp();

    // Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CMemStressDemoApp)
public:
    virtual BOOL InitInstance();
    //}}AFX_VIRTUAL

    // Implementation

    //{{AFX_MSG(CMemStressDemoApp)
    // NOTE - the ClassWizard will add and remove member functions here.
    //    DO NOT EDIT what you see in these blocks of generated code !
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};



//{{AFX_INSERT_LOCATION}}

#endif
