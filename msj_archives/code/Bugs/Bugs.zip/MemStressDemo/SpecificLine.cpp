/*----------------------------------------------------------------------
John Robbins
Microsoft Systems Journal, October 1997 - Dem Bugs!
----------------------------------------------------------------------*/
#include "StdAfx.h"

void SpecificLine ( void )
{
        char * szBuff ;
        szBuff = (char *)new char[ 100 ] ;
}