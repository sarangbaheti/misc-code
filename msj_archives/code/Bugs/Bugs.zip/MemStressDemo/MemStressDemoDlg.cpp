/*----------------------------------------------------------------------
John Robbins
Microsoft Systems Journal, October 1997 - Dem Bugs!
----------------------------------------------------------------------*/

#include "stdafx.h"
#include "MemStressDemo.h"
#include "MemStressDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////////////
// CMemStressDemoDlg dialog

CMemStressDemoDlg::CMemStressDemoDlg(CWnd* pParent /*=NULL*/)
                  : CDialog(CMemStressDemoDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CMemStressDemoDlg)
    // NOTE: the ClassWizard will add member initialization here
    //}}AFX_DATA_INIT
    m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
    m_bMemInit = FALSE ;
}

CMemStressDemoDlg :: ~CMemStressDemoDlg ( )
{
    if ( TRUE == m_bMemInit )
    {
        SHUTDOWNMEMSTRESS ( ) ;
    }
}


void CMemStressDemoDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CMemStressDemoDlg)
    DDX_Control(pDX, IDC_SHUTDOWN, m_btnShutdown);
    DDX_Control(pDX, IDC_INITIALIZE, m_btnInit);
    DDX_Control(pDX, IDC_GENALLOC, m_btnGenAlloc);
    DDX_Control(pDX, IDC_FILEANDLINE, m_btnFileAndLine);
    DDX_Control(pDX, IDC_100BYTEALLOC, m_btn100Alloc);
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMemStressDemoDlg, CDialog)
//{{AFX_MSG_MAP(CMemStressDemoDlg)
ON_WM_PAINT()
ON_WM_QUERYDRAGICON()
ON_BN_CLICKED(IDC_GENALLOC, OnGenAlloc)
ON_BN_CLICKED(IDC_100BYTEALLOC, On100ByteAlloc)
ON_BN_CLICKED(IDC_FILEANDLINE, OnFileAndLine)
ON_BN_CLICKED(IDC_SHUTDOWN, OnShutdown)
ON_BN_CLICKED(IDC_INITIALIZE, OnInitialize)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

////////////////////////////////////////////////////////////////////////
// CMemStressDemoDlg message handlers

BOOL CMemStressDemoDlg::OnInitDialog()
{
    CDialog::OnInitDialog();

    // Set the icon for this dialog.  The framework does this
    //  automatically when the application's main window is not a dialog
    SetIcon(m_hIcon, TRUE);                 // Set big icon
    SetIcon(m_hIcon, FALSE);                // Set small icon

    // TODO: Add extra initialization here

    return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMemStressDemoDlg::OnPaint()
{
    if (IsIconic())
    {
        CPaintDC dc(this); // device context for painting

        SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

        // Center icon in client rectangle
        int cxIcon = GetSystemMetrics(SM_CXICON);
        int cyIcon = GetSystemMetrics(SM_CYICON);
        CRect rect;
        GetClientRect(&rect);
        int x = (rect.Width() - cxIcon + 1) / 2;
        int y = (rect.Height() - cyIcon + 1) / 2;

        // Draw the icon
        dc.DrawIcon(x, y, m_hIcon);
    } else
    {
        CDialog::OnPaint();
    }
}

HCURSOR CMemStressDemoDlg::OnQueryDragIcon()
{
    return (HCURSOR) m_hIcon;
}

void CMemStressDemoDlg::OnGenAlloc()
{
    char * szBuff = (char*)malloc ( 10 ) ;
    ASSERT ( NULL != szBuff ) ;
}

void CMemStressDemoDlg::On100ByteAlloc()
{
    char * szBuff = (char*)malloc ( 100 ) ;
    ASSERT ( NULL != szBuff ) ;
}

void SpecificLine ( void ) ;
void CMemStressDemoDlg::OnFileAndLine()
{
    SpecificLine ( ) ;
}


void CMemStressDemoDlg::OnShutdown()
{
    SHUTDOWNMEMSTRESS ( ) ;

    m_btnInit.EnableWindow ( TRUE ) ;
    m_btnShutdown.EnableWindow ( FALSE ) ;

    m_btnGenAlloc.EnableWindow ( FALSE ) ;
    m_btnFileAndLine.EnableWindow ( FALSE ) ;
    m_btn100Alloc.EnableWindow ( FALSE ) ;
}

void CMemStressDemoDlg::OnInitialize()
{
    INITMEMSTRESS ( "MemStressDemo" ) ;
    m_bMemInit = TRUE ;
    m_btnInit.EnableWindow ( FALSE ) ;
    m_btnShutdown.EnableWindow ( TRUE ) ;

    m_btnGenAlloc.EnableWindow ( TRUE ) ;
    m_btnFileAndLine.EnableWindow ( TRUE ) ;
    m_btn100Alloc.EnableWindow ( TRUE ) ;
}
