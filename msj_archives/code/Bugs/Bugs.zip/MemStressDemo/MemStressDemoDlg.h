/*----------------------------------------------------------------------
John Robbins
Microsoft Systems Journal, October 1997 - Dem Bugs!
----------------------------------------------------------------------*/

#if !defined(AFX_MEMSTRESSDEMODLG_H)
#define AFX_MEMSTRESSDEMODLG_H

#if _MSC_VER >= 1000
    #pragma once
#endif // _MSC_VER >= 1000

////////////////////////////////////////////////////////////////////////
// CMemStressDemoDlg dialog

class CMemStressDemoDlg : public CDialog
{
    // Construction
public:
    CMemStressDemoDlg(CWnd* pParent = NULL);
    virtual ~CMemStressDemoDlg ( ) ;
    // Dialog Data
    //{{AFX_DATA(CMemStressDemoDlg)
    enum
    {IDD = IDD_MEMSTRESSDEMO_DIALOG};
    CButton m_btnShutdown;
    CButton m_btnInit;
    CButton m_btnGenAlloc;
    CButton m_btnFileAndLine;
    CButton m_btn100Alloc;
    //}}AFX_DATA

    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CMemStressDemoDlg)
protected:
    virtual void DoDataExchange(CDataExchange* pDX);
    //}}AFX_VIRTUAL

    // Implementation
protected:
    BOOL m_bMemInit;
    HICON m_hIcon;

    // Generated message map functions
    //{{AFX_MSG(CMemStressDemoDlg)
    virtual BOOL OnInitDialog();
    afx_msg void OnPaint();
    afx_msg HCURSOR OnQueryDragIcon();
    afx_msg void OnGenAlloc();
    afx_msg void On100ByteAlloc();
    afx_msg void OnFileAndLine();
    afx_msg void OnShutdown();
    afx_msg void OnInitialize();
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}

#endif
