/*----------------------------------------------------------------------
John Robbins
Microsoft Systems Journal, October 1997 - Dem Bugs!
----------------------------------------------------------------------*/

#ifndef _MEMSTRESSLIB_H
#define _MEMSTRESSLIB_H

// Include the main header to get everything.
#include "MSJDBG.h"

#ifdef __cplusplus
extern "C" {
#endif      // __cplusplus

#ifdef _DEBUG

/*----------------------------------------------------------------------
Function        :   InitializeMemStress
Discussion      :
    Initializes the memory stressing routines.
Parameters      :
    szProgName - The name of the program.  This is the same name that
                 a set of options was stored with in the C/C++ Memory
                 Stress window of the STRESS32.EXE application.  This
                 parameter is used to read the settings out of the
                 MEMSTRESS.INI file.
Returns         :
    1 - All initialization went correctly.
    0 - There was a problem initializing.  Read the output messages from
        OutputDebugStrings in the debugger to see what went wrong.
----------------------------------------------------------------------*/
int InitializeMemStressA ( const char * szProgName ) ;
int InitializeMemStressW ( const wchar_t * szProgName ) ;

#ifndef UNICODE
#define InitializeMemStress InitializeMemStressA
#else
#define InitializeMemStress InitializeMemStressW
#endif

/*----------------------------------------------------------------------
Function        :   TerminateMemStress
Discussion      :
    Terminates the memory stressing.
Parameters      :
    None.
Returns         :
    1 - The termination went correctly.
    0 - There was a problem terminating.  Read the output messages from
        OutputDebugStrings in the debugger to see what went wrong.
----------------------------------------------------------------------*/
int TerminateMemStress ( void ) ;

////////////////////////////////////////////////////////////////////////
// Helper Macros.
////////////////////////////////////////////////////////////////////////
#define INITMEMSTRESS(x)        InitializeMemStress(x)
#define SHUTDOWNMEMSTRESS()     TerminateMemStress ( )

#else       // _DEBUG defined

#define INITMEMSTRESS(x)
#define SHUTDOWNMEMSTRESS()

#endif      // _DEBUG

#ifdef __cplusplus
}
#endif      // __cplusplus

#endif      // _MEMSTRESSLIB_H


