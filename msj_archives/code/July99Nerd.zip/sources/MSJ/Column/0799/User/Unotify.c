/*
  Unotify.C - 1999 James M. Finnegan - Microsoft Systems Journal

  Copyright (c)1999 Microsoft Corporation.  All Rights Reserved.

  This is the main module for demonstrating asynchronous notification
  from kernel-mode.
*/
#include <windows.h>
#include <stdio.h>
#include "resource.h"


LRESULT WINAPI WndProc(HWND,UINT,WPARAM,LPARAM);


HANDLE hDriver = INVALID_HANDLE_VALUE;



// External functions in Dynamic.c
extern HANDLE LoadDriver(OSVERSIONINFO *, BOOL *);
extern BOOL UnloadDynamicNTDriver();


// External functions in Async.c
extern BOOL WINAPI KernelModeEvent(DWORD);
extern BOOL WINAPI UserModeEvent(DWORD);
extern BOOL WINAPI EmptyIRP(DWORD);
extern void         ApcDispatch();
extern void         ApcDispatchWithKMAlertHack();




int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                                            LPSTR lpszCmdLine, int nCmdShow)
{
    static char szAppName[]="UNotify";
    HWND        hWnd;
    MSG         msg;
    WNDCLASS    wndclass;


    if(!hPrevInstance)
    {
        wndclass.style         = CS_HREDRAW | CS_VREDRAW;
        wndclass.lpfnWndProc   = WndProc;
        wndclass.cbClsExtra    = 0;
        wndclass.cbWndExtra    = 0;
        wndclass.hInstance     = hInstance;
        wndclass.hIcon         = NULL;
        wndclass.hCursor       = LoadCursor(NULL, IDC_ARROW);
        wndclass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
        wndclass.lpszMenuName  = MAKEINTRESOURCE(IDR_MENU1);
        wndclass.lpszClassName = szAppName;

        if(!RegisterClass(&wndclass))
            return -1;
    }

    // Create the main window
    hWnd = CreateWindow(szAppName,"MSJ Kernel Mode Async Notification App",
                WS_OVERLAPPED | WS_THICKFRAME | WS_MINIMIZEBOX | 
                WS_MAXIMIZEBOX |WS_SYSMENU | WS_CLIPCHILDREN,
                CW_USEDEFAULT,CW_USEDEFAULT,
                CW_USEDEFAULT,CW_USEDEFAULT,
                0,0,hInstance,NULL);
    
    ShowWindow(hWnd,nCmdShow);
    UpdateWindow(hWnd);

    while(GetMessage(&msg,NULL,0,0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    
    return msg.wParam;
}



VOID CenterWindow(HWND hWnd)
{
    RECT rect;
    WORD wWidth,
         wHeight;
         
         
    GetWindowRect(hWnd,&rect);

    wWidth =GetSystemMetrics(SM_CXSCREEN);
    wHeight=GetSystemMetrics(SM_CYSCREEN);

    MoveWindow(hWnd,(wWidth/2)   - ((rect.right -  rect.left)/2),
                    (wHeight/2)  - ((rect.bottom - rect.top) /2),
                     rect.right  -   rect.left,
                     rect.bottom -   rect.top, 
                     FALSE);
}


LRESULT WINAPI WndProc(HWND hWnd,UINT uMessage,WPARAM wParam,LPARAM lParam)
{
    static OSVERSIONINFO os={0};
    static BOOL fNTDynaLoaded;

    HANDLE hThread;
    DWORD dwThread;


    switch(uMessage)
    {
        case WM_CREATE:
			CenterWindow(hWnd);

            // Get the current OS information.
            os.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
            GetVersionEx(&os);

            hDriver = LoadDriver(&os, &fNTDynaLoaded);
            break;

        case WM_COMMAND:
            switch(wParam)
            {
                case IDM_KERNEL_EVENT:
                    if(!(hThread = CreateThread((LPSECURITY_ATTRIBUTES)NULL, 0, (LPTHREAD_START_ROUTINE) KernelModeEvent, NULL, 0, &dwThread)))
                        MessageBox(NULL,"Cannot create thread!","Error",MB_OK);
                    break;

                case IDM_USER_EVENT:
                    if(!(hThread = CreateThread((LPSECURITY_ATTRIBUTES)NULL, 0, (LPTHREAD_START_ROUTINE) UserModeEvent, NULL, 0, &dwThread)))
                        MessageBox(NULL,"Cannot create thread!","Error",MB_OK);
                    break;

                case IDM_EMPTY_IRP:
                    if(!(hThread = CreateThread((LPSECURITY_ATTRIBUTES)NULL, 0, (LPTHREAD_START_ROUTINE) EmptyIRP, NULL, 0, &dwThread)))
                        MessageBox(NULL,"Cannot create thread!","Error",MB_OK);
                    break;

                case IDM_APC:
                    ApcDispatch();
                    break;

                case IDM_APC_KM_THREAD_ALERTING:
                    ApcDispatchWithKMAlertHack();
                    break;
                
                case IDM_EXIT:
                    PostMessage(hWnd, WM_CLOSE, 0, 0L);
                    break;
            }
            break;

        case WM_DESTROY:
            CloseHandle(hDriver);

            // If the NT driver was previously dynamically loaded, unload it here!
            if(fNTDynaLoaded)
                UnloadDynamicNTDriver();

            PostQuitMessage(0);
            break;
        
        default:
            return DefWindowProc(hWnd,uMessage,wParam,lParam);
            break;
          
    }

    return 0L;
}                                                            
