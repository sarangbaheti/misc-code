/*
  Async.C - 1999 James M. Finnegan - Microsoft Systems Journal

  Copyright (c)1999 Microsoft Corporation.  All Rights Reserved.

  This module sends various requests the associated kernel-mode driver to 
  instruct the driver to trigger KM to user-mode notification mechanisms.
*/
#include <windows.h>
#include <winioctl.h>

#define FILE_DEVICE_UNKNOWN             0x00000022
#define IOCTL_UNKNOWN_BASE              FILE_DEVICE_UNKNOWN

#define IOCTL_NOTIFY_KERNEL_EVENT CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0800, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
#define IOCTL_NOTIFY_USER_EVENT   CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0801, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
#define IOCTL_NOTIFY_EMPTY_IRP    CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0802, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
#define IOCTL_NOTIFY_REGISTER_APC CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0803, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)

#define IOCTL_NOTIFY_REGISTER_APC_WITH_KM_ALERTING \
                                  CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0804, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)


extern HANDLE hDriver;


BOOL WINAPI KernelModeEvent(DWORD t)
{
    HANDLE KnotifyEvent;
    DWORD dwBytesReturned;
    BOOL  bReturnCode = FALSE;
    OVERLAPPED ov={0};


    // Create an event handle for async notification
    // from our driver
    ov.hEvent = CreateEvent(NULL,  // Default security
                            TRUE,  // Manual reset
                            FALSE, // non-signaled state
                            NULL); // No name

    // Tell the driver to signal its event...
    bReturnCode = DeviceIoControl(hDriver,
                                  IOCTL_NOTIFY_KERNEL_EVENT,
                                  0, 0,
                                  0, 0,
                                  &dwBytesReturned,
                                  &ov);
        
    // Wait here for the event handle to be set, indicating
    // that the IOCTL processing is complete.
    bReturnCode = GetOverlappedResult(hDriver, &ov,
                                      &dwBytesReturned, TRUE);

    CloseHandle(ov.hEvent);

    // Get a handle to the named kernel event and wait on it!
    KnotifyEvent = OpenEvent(SYNCHRONIZE, FALSE, "KnotifyEvent");
    WaitForSingleObject(KnotifyEvent, INFINITE);
        
    MessageBox(NULL,"Kernel-mode event has been signaled!","Unotify",MB_OK);

    return 0;
}


BOOL WINAPI UserModeEvent(DWORD t)
{
    HANDLE UserModeEvent;
    DWORD dwBytesReturned;
    BOOL  bReturnCode = FALSE;
    OVERLAPPED ov={0};


    // Create an event handle that the KM driver can signal
    UserModeEvent = CreateEvent(NULL,  // Default security
                                TRUE,  // Manual reset
                                FALSE, // non-signaled state
                                NULL); // No name

    // Create an event handle for async notification
    // from our driver
    ov.hEvent = CreateEvent(NULL,  // Default security
                            TRUE,  // Manual reset
                            FALSE, // non-signaled state
                            NULL); // No name

    // Tell the driver to signal its event...
    bReturnCode = DeviceIoControl(hDriver,
                                  IOCTL_NOTIFY_USER_EVENT,
                                  &UserModeEvent, sizeof(HANDLE),
                                  0, 0,
                                  &dwBytesReturned,
                                  &ov);
        
    // Wait here for the event handle to be set, indicating
    // that the IOCTL processing is complete.
    bReturnCode = GetOverlappedResult(hDriver, &ov,
                                      &dwBytesReturned, TRUE);

    CloseHandle(ov.hEvent);

    
    WaitForSingleObject(UserModeEvent, INFINITE);

    MessageBox(NULL,"User-mode event has been signaled!","Unotify",MB_OK);

    CloseHandle(UserModeEvent);
    
    return 0;
}


BOOL WINAPI EmptyIRP(DWORD t)
{
    DWORD dwBytesReturned;
    BOOL  bReturnCode = FALSE;
    OVERLAPPED ov={0};


    // Create an event handle for async notification
    // from our driver
    ov.hEvent = CreateEvent(NULL,  // Default security
                            TRUE,  // Manual reset
                            FALSE, // non-signaled state
                            NULL); // No name

    // Issue an empty IRP to the driver.  The driver will mark it pending till it's
    // ready to complete it
    bReturnCode = DeviceIoControl(hDriver,
                                  IOCTL_NOTIFY_EMPTY_IRP,
                                  0, 0,
                                  0, 0,
                                  &dwBytesReturned,
                                  &ov);
        
    // Wait here for the event handle to be set, indicating
    // that the IOCTL processing is complete.
    bReturnCode = GetOverlappedResult(hDriver, &ov,
                                      &dwBytesReturned, TRUE);

    CloseHandle(ov.hEvent);

    MessageBox(NULL,"Empty IRP has been completed!","Unotify",MB_OK);

    return 0;
}


void ApcCallback(PVOID NormalContext, PVOID SystemArgument1, PVOID SystemArgument2)
{
    char Message[80];


    wsprintf(Message,"APC Callback!\n P1 == %lx\n P2 == %lx\n P3 == %lx", NormalContext, 
                                                                          SystemArgument1, 
                                                                          SystemArgument2);
    MessageBox(NULL, Message, "Unotify", MB_OK);
}


void ApcDispatch()
{
    DWORD dwBytesReturned;
    BOOL  bReturnCode = FALSE;
    OVERLAPPED ov={0};

    DWORD pfnApc = (DWORD)&ApcCallback;


    // Create an event handle for async notification
    // from our driver
    ov.hEvent = CreateEvent(NULL,  // Default security
                            TRUE,  // Manual reset
                            FALSE, // non-signaled state
                            NULL); // No name
    
    // Tell the driver to signal its event...
    bReturnCode = DeviceIoControl(hDriver,
                                  IOCTL_NOTIFY_REGISTER_APC,
                                  &pfnApc, sizeof(DWORD),
                                  0, 0,
                                  &dwBytesReturned,
                                  &ov);
        
    // Wait here for the event handle to be set, indicating
    // that the IOCTL processing is complete.
    bReturnCode = GetOverlappedResult(hDriver, &ov,
                                      &dwBytesReturned, TRUE);

    CloseHandle(ov.hEvent);
    
    MessageBox(NULL,"APC Dispatched!","Unotify",MB_OK);

    // Force the thread into being alertable...
    SleepEx(INFINITE, TRUE);
}


void ApcDispatchWithKMAlertHack()
{
    DWORD dwBytesReturned;
    BOOL  bReturnCode = FALSE;
    OVERLAPPED ov={0};

    DWORD pfnApc = (DWORD)&ApcCallback;


    // Create an event handle for async notification
    // from our driver
    ov.hEvent = CreateEvent(NULL,  // Default security
                            TRUE,  // Manual reset
                            FALSE, // non-signaled state
                            NULL); // No name
    
    // Tell the driver to signal its event...
    bReturnCode = DeviceIoControl(hDriver,
                                  IOCTL_NOTIFY_REGISTER_APC_WITH_KM_ALERTING,
                                  &pfnApc, sizeof(DWORD),
                                  0, 0,
                                  &dwBytesReturned,
                                  &ov);
        
    // Wait here for the event handle to be set, indicating
    // that the IOCTL processing is complete.
    bReturnCode = GetOverlappedResult(hDriver, &ov,
                                      &dwBytesReturned, TRUE);

    CloseHandle(ov.hEvent);
    
    MessageBox(NULL,"APC Dispatched!  Look, no user-mode alert!","Unotify",MB_OK);
}
