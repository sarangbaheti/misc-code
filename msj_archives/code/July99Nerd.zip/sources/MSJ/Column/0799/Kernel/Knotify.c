/*
  Knotify.C - 1999 James M. Finnegan - Microsoft Systems Journal

  Copyright (c)1999 Microsoft Corporation.  All Rights Reserved.

  This module implements the kernel code to demonstrate notification
  techniques to user-mode Win32 applicaitons
*/

#include "ntddk.h"
#include <stdio.h>


#define FILE_DEVICE_UNKNOWN             0x00000022
#define IOCTL_UNKNOWN_BASE              FILE_DEVICE_UNKNOWN

#define IOCTL_NOTIFY_KERNEL_EVENT CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0800, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
#define IOCTL_NOTIFY_USER_EVENT   CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0801, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
#define IOCTL_NOTIFY_EMPTY_IRP    CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0802, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
#define IOCTL_NOTIFY_REGISTER_APC CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0803, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
#define IOCTL_NOTIFY_REGISTER_APC_WITH_KM_ALERTING \
                                  CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0804, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)


// Definitions for NT supplied APC routines.  These are exported in the
// import libraries, but are not in NTDDK.H
void KeInitializeApc(PKAPC Apc,
                     PKTHREAD Thread,
                     CCHAR ApcStateIndex,
                     PKKERNEL_ROUTINE KernelRoutine,
                     PKRUNDOWN_ROUTINE RundownRoutine,
                     PKNORMAL_ROUTINE NormalRoutine,
                     KPROCESSOR_MODE ApcMode,
                     PVOID NormalContext);

void KeInsertQueueApc(PKAPC Apc,
                      PVOID SystemArgument1,
                      PVOID SystemArgument2,
                      UCHAR unknown);



void     KnotifyUnloadDriver(PDRIVER_OBJECT DriverObject);
NTSTATUS KnotifyDispatchCreateClose(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);
NTSTATUS KnotifyDispatchIoctl(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);

typedef struct _DEVICE_EXTENSION 
{
    PDEVICE_OBJECT DeviceObject;
    HANDLE  NotifyHandle;
    PKEVENT NotifyEvent;

} DEVICE_EXTENSION, *PDEVICE_EXTENSION ;


NTSTATUS DriverEntry(IN PDRIVER_OBJECT DriverObject,
                     IN PUNICODE_STRING RegistryPath)
/*++

Routine Description:

    This routine is called when the driver is loaded by NT.

Arguments:

    DriverObject - Pointer to driver object created by system.
    RegistryPath - Pointer to the name of the services node for this driver.

Return Value:

    The function value is the final status from the initialization operation.

--*/
{
    NTSTATUS        ntStatus;
    UNICODE_STRING  uszDriverString;
    UNICODE_STRING  uszDeviceString;
    UNICODE_STRING  uszNotifyEventString;

    PDEVICE_OBJECT  pDeviceObject;
    PDEVICE_EXTENSION extension;

        
    // Point uszDriverString at the driver name
    RtlInitUnicodeString(&uszDriverString, L"\\Device\\Knotify");

    // Create and initialize device object
    ntStatus = IoCreateDevice(DriverObject,
                              sizeof(DEVICE_EXTENSION),
                              &uszDriverString,
                              FILE_DEVICE_UNKNOWN,
                              0,
                              FALSE,
                              &pDeviceObject);

    if(ntStatus != STATUS_SUCCESS)
        return ntStatus;

    // Assign extension variable...
    extension = pDeviceObject->DeviceExtension;

    // Point uszDeviceString at the device name
    RtlInitUnicodeString(&uszDeviceString, L"\\DosDevices\\Knotify");

    // Create symbolic link to the user-visible name
    ntStatus = IoCreateSymbolicLink(&uszDeviceString, &uszDriverString);

    if(ntStatus != STATUS_SUCCESS)
    {
        // Delete device object if not successful
        IoDeleteDevice(pDeviceObject);
        return ntStatus;
    }

    // Load structure to point to IRP handlers...
    DriverObject->DriverUnload                         = KnotifyUnloadDriver;
    DriverObject->MajorFunction[IRP_MJ_CREATE]         = KnotifyDispatchCreateClose;
    DriverObject->MajorFunction[IRP_MJ_CLOSE]          = KnotifyDispatchCreateClose;
    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = KnotifyDispatchIoctl;

    // Create event for user-mode processes to monitor
    RtlInitUnicodeString(&uszNotifyEventString, L"\\BaseNamedObjects\\KnotifyEvent");
    extension->NotifyEvent = IoCreateNotificationEvent(&uszNotifyEventString, &extension->NotifyHandle);

    KeClearEvent(extension->NotifyEvent);

    // Return success
    return ntStatus;
}


NTSTATUS KnotifyDispatchCreateClose(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp)
{
    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information=0;

    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return(STATUS_SUCCESS);
}

PWORK_QUEUE_ITEM pItem;


void KSignalEvent(PKEVENT NotifyEvent)
{
    LARGE_INTEGER Timeout;


    // AET - 143
    Timeout.QuadPart = -5000000;

    // Delay execution to show "asynchronous" processing
    KeDelayExecutionThread(KernelMode, FALSE, &Timeout);

    KeSetEvent(NotifyEvent, 0, FALSE);

    ExFreePool(pItem);
}


void KDelayIRPCompletion(PIRP Irp)
{
    LARGE_INTEGER Timeout;


    Timeout.QuadPart = -5000000;

    // Delay execution to show "asynchronous" processing
    KeDelayExecutionThread(KernelMode, FALSE, &Timeout);

    Irp->IoStatus.Status = STATUS_SUCCESS;
    
    // Set # of bytes to copy back to user-mode...
    Irp->IoStatus.Information = 0;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);

    ExFreePool(pItem);
}


void KMApcCallback(PKAPC Apc, PKNORMAL_ROUTINE NormalRoutine,
                    PVOID NormalContext, PVOID SystemArgument1, PVOID SystemArgument2)
{
    ExFreePool(Apc);
    return;
}


NTSTATUS KnotifyDispatchIoctl(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp)
{
    NTSTATUS           ntStatus;
    PIO_STACK_LOCATION irpStack  = IoGetCurrentIrpStackLocation(Irp);
    PDEVICE_EXTENSION  extension = DeviceObject->DeviceExtension;

    switch(irpStack->Parameters.DeviceIoControl.IoControlCode)
    {
        case IOCTL_NOTIFY_KERNEL_EVENT:
        {
            KeClearEvent(extension->NotifyEvent);

            pItem = ExAllocatePool(NonPagedPool, sizeof(WORK_QUEUE_ITEM));
            
            // Queue execution to a system thread to permit this IRP to complete...
            ExInitializeWorkItem(pItem, KSignalEvent, extension->NotifyEvent);
            ExQueueWorkItem(pItem, DelayedWorkQueue);

            ntStatus = STATUS_SUCCESS;
            break;
        }

        case IOCTL_NOTIFY_USER_EVENT:
        {
            PKEVENT UserEvent;

            
            // Obtain a kernel pointer to the user-mode created event handle...
            ObReferenceObjectByHandle(*((PHANDLE)Irp->AssociatedIrp.SystemBuffer),
                                      0,
                                      (POBJECT_TYPE) NULL,
                                      UserMode,
                                      (PVOID)&UserEvent,
                                      (POBJECT_HANDLE_INFORMATION) NULL);
            
            pItem = ExAllocatePool(NonPagedPool, sizeof(WORK_QUEUE_ITEM));
            
            // Queue execution to a system thread to permit this IRP to complete...
            ExInitializeWorkItem(pItem, KSignalEvent, UserEvent);
            ExQueueWorkItem(pItem, DelayedWorkQueue);

            ntStatus = STATUS_SUCCESS;
            break;
        }

        case IOCTL_NOTIFY_EMPTY_IRP:
            pItem = ExAllocatePool(NonPagedPool, sizeof(WORK_QUEUE_ITEM));
            
            // Queue execution to a system thread to permit this IRP to complete...
            ExInitializeWorkItem(pItem, KDelayIRPCompletion, Irp);
            ExQueueWorkItem(pItem, DelayedWorkQueue);

            // Mark the IRP pending.  The driver will complete it later...
            IoMarkIrpPending(Irp);
            ntStatus = STATUS_PENDING;
            break;

        case IOCTL_NOTIFY_REGISTER_APC:
        {
            PKAPC Apc;
            ULONG *UserRoutine = (ULONG *)Irp->AssociatedIrp.SystemBuffer;


            Apc = ExAllocatePool(NonPagedPool, sizeof(KAPC));

            KeInitializeApc(Apc,
                            KeGetCurrentThread(),
                            0,
                            (PKKERNEL_ROUTINE)&KMApcCallback, // kernel-mode routine
                            0,                                // rundown routine
                            (PKNORMAL_ROUTINE)*UserRoutine,   // user-mode routine
                            UserMode, (PVOID)(ULONG)1);

            KeInsertQueueApc(Apc, (PVOID)(ULONG)2, (PVOID)(ULONG)3, 0);

            ntStatus = STATUS_SUCCESS;
            break;
        }

        case IOCTL_NOTIFY_REGISTER_APC_WITH_KM_ALERTING:
        {
            KEVENT event;
            PKTHREAD pThread = KeGetCurrentThread();
            PKAPC Apc;
            ULONG *UserRoutine = (ULONG *)Irp->AssociatedIrp.SystemBuffer;
            LARGE_INTEGER Timeout;

            
            Timeout.QuadPart = 0;

            Apc = ExAllocatePool(NonPagedPool, sizeof(KAPC));

            KeInitializeApc(Apc,
                            KeGetCurrentThread(),
                            0,
                            (PKKERNEL_ROUTINE)&KMApcCallback, // kernel-mode routine
                            0,                                // rundown routine
                            (PKNORMAL_ROUTINE)*UserRoutine,   // user-mode routine
                            UserMode, (PVOID)(ULONG)1);

            KeInsertQueueApc(Apc, (PVOID)(ULONG)2, (PVOID)(ULONG)3, 0);
            
            // Cheezy way to force the thread into being alertable :-)
            KeInitializeEvent(&event, SynchronizationEvent, FALSE);
            KeWaitForSingleObject(&event, Executive, UserMode, TRUE, &Timeout);

            ntStatus = STATUS_SUCCESS;
            break;
        }
        
        default:
            break;
    }

    Irp->IoStatus.Status = ntStatus;
    
    // Set # of bytes to copy back to user-mode...
    if(ntStatus == STATUS_SUCCESS)
        Irp->IoStatus.Information = irpStack->Parameters.DeviceIoControl.OutputBufferLength;
    else
        Irp->IoStatus.Information = 0;

    if(ntStatus != STATUS_PENDING)
        IoCompleteRequest(Irp, IO_NO_INCREMENT);

    return ntStatus;
}


void KnotifyUnloadDriver(PDRIVER_OBJECT DriverObject)
{
    UNICODE_STRING  uszDeviceString;


    IoDeleteDevice(DriverObject->DeviceObject);

    RtlInitUnicodeString(&uszDeviceString, L"\\DosDevices\\Knotify");
    IoDeleteSymbolicLink(&uszDeviceString);
}
