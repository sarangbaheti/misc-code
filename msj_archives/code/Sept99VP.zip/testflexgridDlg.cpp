// testflexgridDlg.cpp : implementation file
//

#include "stdafx.h"
#include "testflexgrid.h"
#include "testflexgridDlg.h"
#include "DlgProxy.h"

#include "picture.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define PALVERSION 0x300

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

struct CPropertyNotifySinkImpl : public IPropertyNotifySink 
{
	ULONG m_cRef;

	CPropertyNotifySinkImpl()
	{
		m_cRef = 0;
	}


	STDMETHODIMP QueryInterface(REFIID riid, void** ppv)
	{
		if(riid == IID_IUnknown || riid == IID_IPropertyNotifySink)
		{
			*ppv = static_cast<IPropertyNotifySink*>(this);
			((IUnknown*)*ppv)->AddRef();
			return S_OK;
		} else
		{
			*ppv = 0;
			return E_NOINTERFACE;
		}
	}

	STDMETHODIMP_(ULONG) AddRef()
	{
		return m_cRef++;
	}

	STDMETHODIMP_(ULONG) Release()
	{
		m_cRef--;

		if(m_cRef == 0)
		{
			return 0;
		} else
		{
			return m_cRef;
		}
	}

	STDMETHODIMP OnChanged(DISPID dispid)
	{
		CString str;

		str.Format("Changed Property #%ld", dispid);
		AfxMessageBox(str);
		return S_OK;
	}

	STDMETHODIMP OnRequestEdit(DISPID dispid)
	{
		return S_FALSE;
	}
};

CPropertyNotifySinkImpl g_propNotifySink;
IPropertyNotifySink* g_pPropNotifySink = static_cast<IPropertyNotifySink*>(&g_propNotifySink);
DWORD g_cookie;

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestflexgridDlg dialog

IMPLEMENT_DYNAMIC(CTestflexgridDlg, CDialog);

CTestflexgridDlg::CTestflexgridDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestflexgridDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestflexgridDlg)
	m_nPicture = 0;
	m_bSaveDuringSelection = FALSE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pAutoProxy = NULL;
}

CTestflexgridDlg::~CTestflexgridDlg()
{
	// If there is an automation proxy for this dialog, set
	//  its back pointer to this dialog to NULL, so it knows
	//  the dialog has been deleted.
	if (m_pAutoProxy != NULL)
		m_pAutoProxy->m_pDialog = NULL;
}

void CTestflexgridDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestflexgridDlg)
	DDX_Control(pDX, IDC_BLUEPICTURE, m_ctlBlue);
	DDX_Control(pDX, IDC_REDPICTURE, m_ctlRed);
	DDX_Control(pDX, IDC_YELLOWPICTURE, m_ctlYellow);
	DDX_Radio(pDX, IDC_YELLOW, m_nPicture);
	DDX_Control(pDX, IDC_MSFLEXGRID1, m_flexgrid);
	DDX_Check(pDX, IDC_SAVEDURINGSELECTION, m_bSaveDuringSelection);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestflexgridDlg, CDialog)
	//{{AFX_MSG_MAP(CTestflexgridDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_SELECTBMP, OnSelectbmp)
	ON_BN_CLICKED(IDC_LOADSAVEDBITMAP, OnLoadsavedbitmap)
	ON_BN_CLICKED(IDC_CLEARSELECTEDBITMAP, OnClearselectedbitmap)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestflexgridDlg message handlers

BOOL CTestflexgridDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTestflexgridDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTestflexgridDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
        int x;
		x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestflexgridDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

// Automation servers should not exit when a user closes the UI
//  if a controller still holds on to one of its objects.  These
//  message handlers make sure that if the proxy is still in use,
//  then the UI is hidden but the dialog remains around if it
//  is dismissed.

void CTestflexgridDlg::OnClose() 
{
	if (CanExit())
		CDialog::OnClose();
}

void CTestflexgridDlg::OnOK() 
{
	if (CanExit())
		CDialog::OnOK();
}

void CTestflexgridDlg::OnCancel() 
{
	if (CanExit())
		CDialog::OnCancel();
}

BOOL CTestflexgridDlg::CanExit()
{
	// If the proxy object is still around, then the automation
	//  controller is still holding on to this application.  Leave
	//  the dialog around, but hide its UI.
	if (m_pAutoProxy != NULL)
	{
		ShowWindow(SW_HIDE);
		return FALSE;
	}

	return TRUE;
}

int PalEntriesOnDevice(HDC hDC) 
{ 
    int nColors;  // number of colors 
 
    // Find out the number of colors on this device. 
     
    nColors = (1 << (GetDeviceCaps(hDC, BITSPIXEL) * GetDeviceCaps(hDC, PLANES))); 
 
    ASSERT(nColors); 
    return nColors; 
} 

void SetupConnection(IUnknown* pUnk)
{

	IConnectionPointContainer* pCPC = 0;

	HRESULT hr = pUnk->QueryInterface(&pCPC);
	if(SUCCEEDED(hr))
	{
		IEnumConnectionPoints* pECP = 0;

		// Interesting-- they don't implement
		//  IEnumConnectionPoints
		hr = pCPC->EnumConnectionPoints(&pECP);
		if(SUCCEEDED(hr))
		{
			IConnectionPoint* rgpCP[10];
			ULONG cbFetched;
			pECP->Next(10, rgpCP, &cbFetched);
			for(ULONG i = 0; i < cbFetched; i++)
			{
			}
			pECP->Release();
		}

		IConnectionPoint* pCP = 0;
		hr = pCPC->FindConnectionPoint(IID_IPropertyNotifySink, 
										&pCP);
		if(SUCCEEDED(hr))
		{
			hr = pCP->Advise(g_pPropNotifySink, &g_cookie);
			pCP->Release();
		}
		pCPC->Release();
	}
}

void TeardownConnection(IUnknown* pUnk)
{

	IConnectionPointContainer* pCPC = 0;

	HRESULT hr = pUnk->QueryInterface(&pCPC);
	if(SUCCEEDED(hr))
	{
		IConnectionPoint* pCP = 0;
		hr = pCPC->FindConnectionPoint(__uuidof(pCPC), &pCP);
		if(SUCCEEDED(hr))
		{
			pCP->Unadvise(g_cookie);
			pCP->Release();
		}
		pCPC->Release();
	}
}

void ExamineIPicture(IUnknown* pUnk)
{
	if(pUnk)
	{
		IDispatch* pDispatch = 0;
		pUnk->QueryInterface(&pDispatch);
		if(pDispatch)
		{
			pDispatch->Release();
		}

		IPictureDisp* pPictureDisp = 0;
		pUnk->QueryInterface(&pPictureDisp);
		if(pPictureDisp)
		{
			pPictureDisp->Release();
		}

		IPicture* pPicture = 0;
		pUnk->QueryInterface(&pPicture);
		if(pPicture)
		{
			HRESULT hr = pPicture->PictureChanged();
			pPicture->Release();
		}

		IPersistStream* pPersistStream = 0;
		pUnk->QueryInterface(&pPersistStream);
		if(pPersistStream)
		{
			pPersistStream->Release();
		}
	}
}

void SaveThePicture(IUnknown* pUnk)
{
	IPicture* pPicture = 0;

	HRESULT hr = pUnk->QueryInterface(&pPicture);

	if(SUCCEEDED(hr))
	{
		IStorage* pStg = 0;

		hr = ::StgCreateDocfile(L"c:\\picttest", 
								STGM_SHARE_EXCLUSIVE | 
								STGM_CREATE | 
								STGM_READWRITE, 
								0, &pStg);
		if(SUCCEEDED(hr))
		{
			IStream* pStream = 0;
	
			hr = pStg->CreateStream(L"PICTURE", 
									STGM_SHARE_EXCLUSIVE | STGM_CREATE | STGM_READWRITE, 
									0, 0, &pStream);
			if(SUCCEEDED(hr))
			{
				hr = pPicture->SaveAsFile(pStream, TRUE, NULL);
				pStream->Release();
			}
			pStg->Release();
		}
		pPicture->Release();
	}
}

void CTestflexgridDlg::OnSelectbmp() 
{
	IDispatch* pDisp = 0;

	PICTDESC pictDesc;
	memset(&pictDesc, 0, sizeof(pictDesc));
	pictDesc.cbSizeofstruct = sizeof(pictDesc);
	pictDesc.bmp.hpal = 0;

	UpdateData(TRUE);
	switch(this->m_nPicture)
	{
		case 0:
		{
			pictDesc.bmp.hbitmap = m_ctlYellow.GetBitmap();
			pictDesc.picType = PICTYPE_BITMAP;

			HRESULT hr = OleCreatePictureIndirect(&pictDesc, 
													IID_IDispatch, 
													FALSE, 
													(void**)&pDisp);
			if(SUCCEEDED(hr))
			{
				if(m_bSaveDuringSelection)
				{
					SaveThePicture(pDisp);
				}

				SetupConnection(pDisp);

				this->m_flexgrid.SetRefCellPicture(pDisp);

				ExamineIPicture(pDisp);

				TeardownConnection(pDisp);
				pDisp->Release();
			} else
			{
				AfxMessageBox("Couldn't create the picture dispatch interface");
			}
		}
			break;
		case 1:
		{
			pictDesc.bmp.hbitmap = m_ctlRed.GetBitmap();
			pictDesc.picType = PICTYPE_BITMAP;

			HRESULT hr = OleCreatePictureIndirect(&pictDesc, 
													IID_IDispatch, 
													FALSE, 
													(void**)&pDisp);
			if(SUCCEEDED(hr))
			{
				if(m_bSaveDuringSelection)
				{
					SaveThePicture(pDisp);
				}

				SetupConnection(pDisp);

				ExamineIPicture(pDisp);

				TeardownConnection(pDisp);

				this->m_flexgrid.SetRefCellPicture(pDisp);
				pDisp->Release();
			} else
			{
				AfxMessageBox("Couldn't create the picture dispatch interface");
			}
		}
			break;
		case 2:
		{
			pictDesc.bmp.hbitmap = m_ctlBlue.GetBitmap();
			pictDesc.picType = PICTYPE_BITMAP;

			HRESULT hr = OleCreatePictureIndirect(&pictDesc, 
													IID_IDispatch, 
													FALSE, 
													(void**)&pDisp);
			if(SUCCEEDED(hr))
			{
				if(m_bSaveDuringSelection)
				{
					SaveThePicture(pDisp);
				}

				SetupConnection(pDisp);

				this->m_flexgrid.SetRefCellPicture(pDisp);

				ExamineIPicture(pDisp);

				TeardownConnection(pDisp);

				pDisp->Release();
			} else
			{
				AfxMessageBox("Couldn't create the picture dispatch interface");
			}
		}
			break;
		case 3:
		{
			HICON hIcon;
			hIcon = ::LoadIcon(AfxGetApp()->m_hInstance,
								MAKEINTRESOURCE(IDC_ANICON));
			if(hIcon)
			{
				pictDesc.icon.hicon = hIcon;
				pictDesc.picType = PICTYPE_ICON;

				HRESULT hr = OleCreatePictureIndirect(&pictDesc, 
														IID_IDispatch, 
														FALSE, 
														(void**)&pDisp);
				if(SUCCEEDED(hr))
				{
					this->m_flexgrid.SetRefCellPicture(pDisp);
					pDisp->Release();
				} else
				{
					AfxMessageBox("Couldn't create the picture dispatch interface");
				}
			}
		}
			break;
	default :
		break;
	}
}

void CTestflexgridDlg::OnLoadsavedbitmap() 
{
	IStorage* pStg = 0;

	HRESULT hr;
	hr = ::StgOpenStorage(L"c:\\picttest", 
							NULL,
							STGM_SHARE_EXCLUSIVE | 
							STGM_READ, 
							NULL, 0, &pStg);
	if(SUCCEEDED(hr))
	{
		IStream* pStream = 0;
	
		hr = pStg->OpenStream(L"PICTURE", NULL, 
								STGM_SHARE_EXCLUSIVE | STGM_READ, 
								0, &pStream);
		if(SUCCEEDED(hr))
		{
			IDispatch* pDispatch;
			hr = ::OleLoadPicture(pStream,
									0, // read entire stream
									TRUE, 
									IID_IDispatch, 
									(void**)&pDispatch);
			if(SUCCEEDED(hr))
			{
				this->m_flexgrid.SetRefCellPicture(pDispatch);	
				pDispatch->Release();
			}
			pStream->Release();
		}
		pStg->Release();
	}
}

void CTestflexgridDlg::OnClearselectedbitmap() 
{
	this->m_flexgrid.SetRefCellPicture(NULL);	
}
