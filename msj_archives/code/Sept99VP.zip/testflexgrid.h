// testflexgrid.h : main header file for the TESTFLEXGRID application
//

#if !defined(AFX_TESTFLEXGRID_H__977A0829_D7ED_11D2_8045_EAFF3F000000__INCLUDED_)
#define AFX_TESTFLEXGRID_H__977A0829_D7ED_11D2_8045_EAFF3F000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CTestflexgridApp:
// See testflexgrid.cpp for the implementation of this class
//

class CTestflexgridApp : public CWinApp
{
public:
	CTestflexgridApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestflexgridApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTestflexgridApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTFLEXGRID_H__977A0829_D7ED_11D2_8045_EAFF3F000000__INCLUDED_)
