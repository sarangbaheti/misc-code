// testflexgridDlg.h : header file
//
//{{AFX_INCLUDES()
#include "msflexgrid.h"
//}}AFX_INCLUDES

#if !defined(AFX_TESTFLEXGRIDDLG_H__977A082B_D7ED_11D2_8045_EAFF3F000000__INCLUDED_)
#define AFX_TESTFLEXGRIDDLG_H__977A082B_D7ED_11D2_8045_EAFF3F000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTestflexgridDlgAutoProxy;

/////////////////////////////////////////////////////////////////////////////
// CTestflexgridDlg dialog

class CTestflexgridDlg : public CDialog
{
	DECLARE_DYNAMIC(CTestflexgridDlg);
	friend class CTestflexgridDlgAutoProxy;

// Construction
public:
	CTestflexgridDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CTestflexgridDlg();

// Dialog Data
	//{{AFX_DATA(CTestflexgridDlg)
	enum { IDD = IDD_TESTFLEXGRID_DIALOG };
	CStatic	m_ctlBlue;
	CStatic	m_ctlRed;
	CStatic	m_ctlYellow;
	int		m_nPicture;
	CMSFlexGrid	m_flexgrid;
	BOOL	m_bSaveDuringSelection;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestflexgridDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CTestflexgridDlgAutoProxy* m_pAutoProxy;
	HICON m_hIcon;

	BOOL CanExit();

	// Generated message map functions
	//{{AFX_MSG(CTestflexgridDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnSelectbmp();
	afx_msg void OnLoadsavedbitmap();
	afx_msg void OnClearselectedbitmap();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTFLEXGRIDDLG_H__977A082B_D7ED_11D2_8045_EAFF3F000000__INCLUDED_)
