// DlgProxy.cpp : implementation file
//

#include "stdafx.h"
#include "testflexgrid.h"
#include "DlgProxy.h"
#include "testflexgridDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestflexgridDlgAutoProxy

IMPLEMENT_DYNCREATE(CTestflexgridDlgAutoProxy, CCmdTarget)

CTestflexgridDlgAutoProxy::CTestflexgridDlgAutoProxy()
{
	EnableAutomation();
	
	// To keep the application running as long as an automation 
	//	object is active, the constructor calls AfxOleLockApp.
	AfxOleLockApp();

	// Get access to the dialog through the application's
	//  main window pointer.  Set the proxy's internal pointer
	//  to point to the dialog, and set the dialog's back pointer to
	//  this proxy.
	ASSERT (AfxGetApp()->m_pMainWnd != NULL);
	ASSERT_VALID (AfxGetApp()->m_pMainWnd);
	ASSERT_KINDOF(CTestflexgridDlg, AfxGetApp()->m_pMainWnd);
	m_pDialog = (CTestflexgridDlg*) AfxGetApp()->m_pMainWnd;
	m_pDialog->m_pAutoProxy = this;
}

CTestflexgridDlgAutoProxy::~CTestflexgridDlgAutoProxy()
{
	// To terminate the application when all objects created with
	// 	with automation, the destructor calls AfxOleUnlockApp.
	//  Among other things, this will destroy the main dialog
	if (m_pDialog != NULL)
		m_pDialog->m_pAutoProxy = NULL;
	AfxOleUnlockApp();
}

void CTestflexgridDlgAutoProxy::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}

BEGIN_MESSAGE_MAP(CTestflexgridDlgAutoProxy, CCmdTarget)
	//{{AFX_MSG_MAP(CTestflexgridDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CTestflexgridDlgAutoProxy, CCmdTarget)
	//{{AFX_DISPATCH_MAP(CTestflexgridDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_ITestflexgrid to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {977A0826-D7ED-11D2-8045-EAFF3F000000}
static const IID IID_ITestflexgrid =
{ 0x977a0826, 0xd7ed, 0x11d2, { 0x80, 0x45, 0xea, 0xff, 0x3f, 0x0, 0x0, 0x0 } };

BEGIN_INTERFACE_MAP(CTestflexgridDlgAutoProxy, CCmdTarget)
	INTERFACE_PART(CTestflexgridDlgAutoProxy, IID_ITestflexgrid, Dispatch)
END_INTERFACE_MAP()

// The IMPLEMENT_OLECREATE2 macro is defined in StdAfx.h of this project
// {977A0824-D7ED-11D2-8045-EAFF3F000000}
IMPLEMENT_OLECREATE2(CTestflexgridDlgAutoProxy, "Testflexgrid.Application", 0x977a0824, 0xd7ed, 0x11d2, 0x80, 0x45, 0xea, 0xff, 0x3f, 0x0, 0x0, 0x0)

/////////////////////////////////////////////////////////////////////////////
// CTestflexgridDlgAutoProxy message handlers
