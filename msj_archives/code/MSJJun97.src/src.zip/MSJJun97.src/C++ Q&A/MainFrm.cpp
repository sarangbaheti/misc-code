////////////////////////////////////////////////////////////////
// Copyright 1996 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// This program compiles with Visual C++ 4.1 on Windows 95
// See ShadeCap.cpp
// 
#include "StdAfx.h"
#include "ShadeCap.h"
#include "MainFrm.h"
#include "PaintCap.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const UINT WM_PAINTMYCAPTION = WM_USER;

IMPLEMENT_DYNCREATE(CMainFrame, CBaseFrameWnd)
BEGIN_MESSAGE_MAP  (CMainFrame, CBaseFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_MESSAGE(WM_PAINTMYCAPTION, OnPaintMyCaption)
	ON_COMMAND(ID_VIEW_MINMAXHELP, OnViewMinmaxhelp)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MINMAXHELP, OnUpdateViewMinmaxhelp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT BASED_CODE indicators[] = {
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

//////////////////
// Standard MFC create stuff
//
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CBaseFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))	{
		return -1;      // fail to create
	}
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT))) {
		return -1;      // fail to create
	}
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// Install caption painter
	m_capp.Install(this, WM_PAINTMYCAPTION);

	return 0;
}

// Private MFC function only sets the title if it's different
//
extern void AFXAPI AfxSetWindowText(HWND, LPCTSTR);

//////////////////
// Override to change title--app name first, then doc name, which is
// the opposite of the normal MFC way.
//
void CMainFrame::OnUpdateFrameTitle(BOOL bAddToTitle)
{
	AfxSetWindowText(m_hWnd, m_strTitle + " " + GetDocTitle());
}

//////////////////
// Get doc title: I use full path name or "untitled"
//
CString CMainFrame::GetDocTitle()
{
	CString s;
	CFrameWnd *pFrame = GetActiveFrame();
	ASSERT(pFrame);
	CDocument * pDoc = pFrame->GetActiveDocument();
	if (pDoc)
		s = pDoc->GetTitle();
	return s;
}

//////////////////
// Helper function to compute the luminosity for an RGB color.
// Measures how bright the color is. I use this so I can draw the caption
// text using the user's chosen color, unless it's too dark. See MSDN for
// definition of luminosity and how to compute it.
//
static int GetLuminosity(COLORREF color)
{
#define HLSMAX 240	// This is what Display Properties uses
#define RGBMAX 255	// max r/g/b value is 255
	int r = GetRValue(color);
	int g = GetGValue(color);
	int b = GetBValue(color);
	int rgbMax = max( max(r,g), b);
	int rgbMin = min( min(r,g), b);
	return (((rgbMax+rgbMin) * HLSMAX) + RGBMAX ) / (2*RGBMAX);
}

#define COLOR_WHITE RGB(255,255,255)
#define COLOR_BLACK RGB(0,0,0)
#define NCOLORSHADES 64		// this many shades in gradient

//////////////////
// Helper to paint rectangle with a color.
//
static void PaintRect(CDC& dc, int x, int y, int w, int h, COLORREF color)
{
	CBrush brush(color);
	CBrush* pOldBrush = dc.SelectObject(&brush);
	dc.PatBlt(x, y, w, h, PATCOPY);
	dc.SelectObject(pOldBrush);
}

//////////////////
// Paint custom caption.
// This is the function that actually does the shading. It creates a
// bitmap that's used to paint the caption. It looks horrible, but it's
// just a lot of bit-twiddling GDI stuff.
//
LRESULT CMainFrame::OnPaintMyCaption(WPARAM bActive, LPARAM lParam)
{
	if (lParam == 0) {
		// lParam = 0 means system setting change: invalidate fonts.
		m_fontCaption.DeleteObject();
		m_fontAcme.DeleteObject();
		return 0;
	}

	const PAINTCAP& pc = *((PAINTCAP*)lParam);
	ASSERT(pc.m_pDC);
	CDC& dc = *pc.m_pDC;

	int cxCap = pc.m_szCaption.cx;
	int cyCap = pc.m_szCaption.cy;

	if (!bActive) {
		// Inactive caption: don't do shading, just fill w/bg color
		PaintRect(dc, 0, 0, cxCap, cyCap, GetSysColor(COLOR_INACTIVECAPTION));

	} else {
		// Active caption: do shading
		//
		COLORREF clrBG = GetSysColor(COLOR_ACTIVECAPTION); // background color
		int r = GetRValue(clrBG);				// red..
		int g = GetGValue(clrBG);				// ..green
		int b = GetBValue(clrBG);				// ..blue color vals
		int x = 5*cxCap/6;						// start 5/6 of the way right
		int w = x;									// width of area to shade
		int xDelta= max(w/NCOLORSHADES,1);	// width of one shade band

		// Paint far right 1/6 of caption the background color
		PaintRect(dc, x, 0, cxCap-x, cyCap, clrBG);

		// Compute new color brush for each band from x to x + xDelta.
		// Excel uses a linear algorithm from black to normal, i.e.
		//
		//		color = CaptionColor * r
		//
		// where r is the ratio x/w, which ranges from 0 (x=0, left)
		// to 1 (x=w, right). This results in a mostly black title bar,
		// since we humans don't distinguish dark colors as well as light
		// ones. So instead, I use the formula
		//
		//		color = CaptionColor * [1-(1-r)^2]
		//
		// which still equals black when r=0 and CaptionColor when r=1,
		// but spends more time near CaptionColor. For example, when r=.5,
		// the multiplier is [1-(1-.5)^2] = .75, closer to 1 than .5.
		// I leave the algebra to the reader to verify that the above formula
		// is equivalent to
		//
		//		color = CaptionColor - (CaptionColor*(w-x)*(w-x))/(w*w)
		//
		// The computation looks horrendous, but it's only done once each
		// time the caption changes size; thereafter BitBlt'ed to the screen.
		//
		while (x > xDelta) {						// paint bands right to left
			x -= xDelta;							// next band
			int wmx2 = (w-x)*(w-x);				// w minus x squared
			int w2  = w*w;							// w squared
			PaintRect(dc, x, 0, xDelta, cyCap,	
				RGB(r-(r*wmx2)/w2, g-(g*wmx2)/w2, b-(b*wmx2)/w2));
		}

		PaintRect(dc,0,0,x,cyCap,COLOR_BLACK);  // whatever's left ==> black
	}

	// Use caption painter to draw icon and buttons
	int cxIcon  = m_capp.DrawIcon(pc);
	int cxButns = m_capp.DrawButtons(pc);

	// Now draw text. First Create fonts if needed
	//
	if (!m_fontCaption.m_hObject)
		CreateFonts();

	// Paint "ACME TEXT" using ACME font, always white
	CString s = m_strTitle + " ";				// app title
	CRect rc(CPoint(0,0), pc.m_szCaption); // text rectangle
	rc.left  += cxIcon+2;						// start after icon
	rc.right -= cxButns;							// don't draw past buttons
	dc.SetBkMode(TRANSPARENT);					// draw on top of our shading
	dc.SetTextColor(COLOR_WHITE);				// always white
	CFont* pOldFont = dc.SelectObject(&m_fontAcme);
	dc.DrawText(s, &rc, DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS);

	// Now paint window title (caption)
	rc.left += dc.GetTextExtent(s).cx;		// move past "ACME EDIT "
	if (rc.right > rc.left) {					// if still room:
		COLORREF clrText;							// text color
		if (bActive) {
			// Excel always uses white for title color, but I use the user's
			// selected color--unless it's too dark, then I use white.
			//
			clrText = GetSysColor(COLOR_CAPTIONTEXT);
			if (GetLuminosity(clrText) < 90) // good from trial & error
				clrText = COLOR_WHITE;
		} else
			clrText = GetSysColor(COLOR_INACTIVECAPTIONTEXT);

		// Paint the text. Use DT_END_ELLIPSIS to draw ellipsis if text
		// won't fit. Win32 sure is friendly!
		//
		dc.SetTextColor(clrText);
		dc.SelectObject(&m_fontCaption);
		dc.DrawText(GetDocTitle(), &rc,
			DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS);
	} 

	// Restore DC
	dc.SelectObject(pOldFont);
	return 0;
}

//////////////////
// Helper function to build the fonts I need.
//
void CMainFrame::CreateFonts()
{
	// Get current system caption font, just to get its size
	//
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(ncm);
	VERIFY(SystemParametersInfo(SPI_GETNONCLIENTMETRICS, 0, &ncm, 0));
	m_fontCaption.CreateFontIndirect(&ncm.lfCaptionFont);

	// Create "ACME" font same size as caption font, but use Book Antiqua
	//
	m_fontAcme.CreatePointFont(120, "Book Antiqua"); // 12 pt for now
	LOGFONT lf;
	m_fontAcme.GetLogFont(&lf);					// get font info
	m_fontAcme.DeleteObject();						// I don't really want 12 pt
	lf.lfWeight|=FW_BOLD;							// make bold
	lf.lfHeight = ncm.lfCaptionFont.lfHeight; // same height as caption font
	m_fontAcme.CreateFontIndirect(&lf);			// create font
}


void CMainFrame::OnViewMinmaxhelp() 
{
	if (GetExStyle() & WS_EX_CONTEXTHELP) {
		ModifyStyleEx(WS_EX_CONTEXTHELP,0);
		ModifyStyle  (0,WS_MINIMIZEBOX|WS_MAXIMIZEBOX);
	} else {
		ModifyStyleEx(0,WS_EX_CONTEXTHELP);
		ModifyStyle  (WS_MINIMIZEBOX|WS_MAXIMIZEBOX,0);		
	}
	m_capp.Invalidate();
	SendMessage(WM_NCPAINT);
}

void CMainFrame::OnUpdateViewMinmaxhelp(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(GetExStyle() & WS_EX_CONTEXTHELP);
}
