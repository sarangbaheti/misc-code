////////////////////////////////////////////////////////////////
// Copyright 1996 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// This program compiles with Visual C++ 4.1 on Windows 95
// See ShadeCap.cpp

#include "PaintCap.h"

#ifdef _MDI
#define CBaseFrameWnd CMDIFrameWnd
#else
#define CBaseFrameWnd CFrameWnd
#endif

/////////////////
// Mainframe that draws shaded caption a la Excel 95
//
class CMainFrame : public CBaseFrameWnd {
public:
	CMainFrame();
	virtual ~CMainFrame();

protected:
	DECLARE_DYNCREATE(CMainFrame)
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;

	// Stuff for painting custom title bar:
	CCaptionPainter m_capp;			// caption painter
	CFont		m_fontCaption;			// normal system font for active caption
	CFont		m_fontAcme;				// "ACME" company font (same active/inactive)

	// Overrides
	virtual void OnUpdateFrameTitle(BOOL bAddToTitle);

	// Helpers
	CString	GetDocTitle();
	void		CreateFonts();

	//{{AFX_MSG(CMainFrame)
	afx_msg int		 OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg LRESULT OnPaintMyCaption(WPARAM wp, LPARAM lp);
	afx_msg void OnViewMinmaxhelp();
	afx_msg void OnUpdateViewMinmaxhelp(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

