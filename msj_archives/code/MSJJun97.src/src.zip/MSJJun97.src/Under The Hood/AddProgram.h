// AddProgram.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAddProgram dialog

class CAddProgram : public CDialog
{
// Construction
public:
    BOOL m_fLineScrolling;
    CAddProgram(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
    //{{AFX_DATA(CAddProgram)
    enum { IDD = IDD_ADD_PROGRAM };
    UINT    m_incrementAmount;
    CString    m_newProgramName;
    //}}AFX_DATA


// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CAddProgram)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:
    void UpdateIncrementEdit(void);

    // Generated message map functions
    //{{AFX_MSG(CAddProgram)
    afx_msg void OnBrowseButton();
    virtual BOOL OnInitDialog();
    afx_msg void OnRadioLine();
    afx_msg void OnRadioPage();
    virtual void OnOK();
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};
