// AddProgram.cpp : implementation file
//

#include "stdafx.h"
#include "MW.h"
#include "AddProgram.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddProgram dialog


CAddProgram::CAddProgram(CWnd* pParent /*=NULL*/)
    : CDialog(CAddProgram::IDD, pParent)
{
    //{{AFX_DATA_INIT(CAddProgram)
    m_incrementAmount = 1;
    m_newProgramName = _T("");
    //}}AFX_DATA_INIT
}


void CAddProgram::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CAddProgram)
    DDX_Text(pDX, IDC_EDIT_INCREMENT_AMOUNT, m_incrementAmount);
    DDV_MinMaxUInt(pDX, m_incrementAmount, 1, 65535);
    DDX_Text(pDX, IDC_NEW_PROGRAM_NAME, m_newProgramName);
    //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddProgram, CDialog)
    //{{AFX_MSG_MAP(CAddProgram)
    ON_BN_CLICKED(IDC_BROWSE_BUTTON, OnBrowseButton)
    ON_BN_CLICKED(IDC_RADIO_LINE, OnRadioLine)
    ON_BN_CLICKED(IDC_RADIO_PAGE, OnRadioPage)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddProgram message handlers

void CAddProgram::OnBrowseButton() 
{
    // TODO: Add your control notification handler code here
    CFileDialog dlg( TRUE, "EXE", "*.EXE", OFN_FILEMUSTEXIST, 0, this );
    
    if ( IDOK != dlg.DoModal() )
        return;

    ((CWnd*)GetDlgItem(IDC_NEW_PROGRAM_NAME))->SetWindowText(dlg.GetPathName());
}


BOOL CAddProgram::OnInitDialog() 
{
    CDialog::OnInitDialog();
    
    // TODO: Add extra initialization here
    
    CSpinButtonCtrl * pSpinButton = (CSpinButtonCtrl *)GetDlgItem( IDC_SPIN1 );
    pSpinButton->SetBuddy( GetDlgItem(IDC_EDIT_INCREMENT_AMOUNT) );
    pSpinButton->SetRange( 1, 100 );

    // Set the line scrolling BOOL to TRUE (by default), and check
    // the "line scrolling" checkbox to reflect this
    m_fLineScrolling = TRUE;
    ((CButton *)GetDlgItem(IDC_RADIO_LINE))->SetCheck( 1 );

    return TRUE;  // return TRUE unless you set the focus to a control
                  // EXCEPTION: OCX Property Pages should return FALSE
}

void CAddProgram::OnRadioLine() 
{
    // TODO: Add your control notification handler code here
    m_fLineScrolling = TRUE;
}

void CAddProgram::OnRadioPage() 
{
    // TODO: Add your control notification handler code here
    m_fLineScrolling = FALSE;    
}

void CAddProgram::OnOK() 
{
    // TODO: Add extra validation here
    CEdit * pEdit = (CEdit *)GetDlgItem( IDC_NEW_PROGRAM_NAME );

    if ( 0 == pEdit->GetWindowTextLength() )
    {
        MessageBox( "Must specify a program name" );
        return;
    }

    CDialog::OnOK();
}
