#define MW_SCROLL_INCREMENT_MASK     0x0000FFFF
#define MW_SCROLL_PAGE               0x00010000

// Dummy routine in MouseWheel.DLL to allow implicit importing
extern "C" void DoNothing(void);

