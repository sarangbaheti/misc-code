// MW.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "MW.h"
#include "MWDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMWApp

BEGIN_MESSAGE_MAP(CMWApp, CWinApp)
    //{{AFX_MSG_MAP(CMWApp)
        // NOTE - the ClassWizard will add and remove mapping macros here.
        //    DO NOT EDIT what you see in these blocks of generated code!
    //}}AFX_MSG
    ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMWApp construction

CMWApp::CMWApp()
{
    m_RegPath = "SoftWare\\WheatyProductions\\MouseWheel";
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CMWApp object

CMWApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CMWApp initialization

extern "C" void DoNothing(void);

BOOL CMWApp::InitInstance()
{
    // Standard initialization

    DoNothing();    // Just forces a link to MouseWheel.DLL

    CMWDlg dlg;

    dlg.DoModal();

    // Since the dialog has been closed, return FALSE so that we exit the
    // application, rather than start the application's message pump.
    return FALSE;
}

HKEY CMWApp::GetRegKey()
{
    HKEY hKey;
    DWORD dwDisposition;

    if ( ERROR_SUCCESS != RegCreateKeyEx(HKEY_CURRENT_USER,
                                        m_RegPath,
                                        0, 0, 0,
                                        KEY_ALL_ACCESS,
                                        0,
                                        &hKey,
                                        &dwDisposition) )
        return 0;
 
    return hKey;
}
