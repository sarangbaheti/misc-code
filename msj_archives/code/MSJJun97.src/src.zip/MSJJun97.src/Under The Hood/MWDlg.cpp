// MWDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MW.h"
#include "MWDlg.h"
#include "addprogram.h"
#include "mousewheel.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMWDlg dialog

CMWDlg::CMWDlg(CWnd* pParent /*=NULL*/)
                : CDialog(CMWDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CMWDlg)
        // NOTE: the ClassWizard will add member initialization here
    //}}AFX_DATA_INIT
    // Note that LoadIcon does not require a subsequent DestroyIcon in Win32
    m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
    
    m_okToShow = FALSE;    // Don't show the dialog initially
}

void CMWDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CMWDlg)
        // NOTE: the ClassWizard will add DDX and DDV calls here
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMWDlg, CDialog)
    //{{AFX_MSG_MAP(CMWDlg)
    ON_MESSAGE( WM_MY_TRAY_NOTIFICATION, OnTrayNotification )
    ON_WM_PAINT()
    ON_WM_QUERYDRAGICON()
    ON_BN_CLICKED(IDC_ADD_PROGRAM, OnAddProgram)
    ON_BN_CLICKED(IDC_DELETE_PROGRAM, OnDeleteProgram)
    ON_WM_CLOSE()
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMWDlg message handlers

BOOL CMWDlg::OnInitDialog()
{
    CDialog::OnInitDialog();

    CMenu* pSysMenu = GetSystemMenu(FALSE);

    // Set the icon for this dialog.  The framework does this automatically
    //  when the application's main window is not a dialog
    SetIcon(m_hIcon, TRUE);            // Set big icon
    SetIcon(m_hIcon, FALSE);        // Set small icon

    m_notifyIconData.cbSize = sizeof(m_notifyIconData);
    m_notifyIconData.hWnd = this->m_hWnd;
    m_notifyIconData.uID = WM_MY_TRAY_NOTIFICATION;
    m_notifyIconData.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    m_notifyIconData.uCallbackMessage = WM_MY_TRAY_NOTIFICATION;
    m_notifyIconData.hIcon = m_hIcon;
    lstrcpy( m_notifyIconData.szTip, "MouseWheel" );
    Shell_NotifyIcon( NIM_ADD, &m_notifyIconData );

    RefreshProgramListbox();

    return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMWDlg::OnPaint() 
{
    // If the user hasn't asked to see the dialog yet, hide it.  It would be
    // better to not show the dialog in the first place, but MFC seems bound
    // and determined to get that dialog on the screen!
    if ( !m_okToShow )
    {
        ShowWindow( SW_HIDE );
    }

    if (IsIconic())
    {
        CPaintDC dc(this); // device context for painting

        SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

        // Center icon in client rectangle
        int cxIcon = GetSystemMetrics(SM_CXICON);
        int cyIcon = GetSystemMetrics(SM_CYICON);
        CRect rect;
        GetClientRect(&rect);
        int x = (rect.Width() - cxIcon + 1) / 2;
        int y = (rect.Height() - cyIcon + 1) / 2;

        // Draw the icon
        dc.DrawIcon(x, y, m_hIcon);
    }
    else
    {
        CDialog::OnPaint();
    }
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMWDlg::OnQueryDragIcon()
{
    return (HCURSOR) m_hIcon;
}

void CMWDlg::OnAddProgram() 
{
    // TODO: Add your control notification handler code here
    CAddProgram addDialog( this );
    
    if ( IDOK != addDialog.DoModal() )
        return;

    // Low WORD is the number of units to scroll
    DWORD dwRegValue = addDialog.m_incrementAmount;

    // High word is flags.  Right now, the only flag is the "scroll by pages" flag
    if ( FALSE == addDialog.m_fLineScrolling )
        dwRegValue |= MW_SCROLL_PAGE;

    HKEY hKey = ((CMWApp *)AfxGetApp())->GetRegKey();
    if ( !hKey )
        return;

    if ( 0 == RegSetValueEx(hKey,
                            addDialog.m_newProgramName,
                            0,
                            REG_DWORD,
                            (PBYTE)&dwRegValue,
                            sizeof(dwRegValue) ) )
    {
        RefreshProgramListbox();
        MessageBox("You must shut down and restart MW.EXE for this change to "
                   "take affect");
    }
    else
        MessageBox( "Error adding program to registry" );

    RegCloseKey( hKey );
}


BOOL CMWDlg::RefreshProgramListbox( void )
{
    CListBox * pListBox = (CListBox *)GetDlgItem(IDC_PROGRAM_LIST);
    
    pListBox->ResetContent();    // Clear anything that's in there now

    HKEY hKey = ((CMWApp *)AfxGetApp())->GetRegKey();
    if ( !hKey )
        return FALSE;

    for ( unsigned i =0; ; i++ )
    {
        LONG hResult;
        char szValueName[MAX_PATH];
        DWORD dwValue;
        DWORD type, cbValueName = sizeof(szValueName), cbValue = sizeof(dwValue);

        hResult = RegEnumValue(    hKey, i, szValueName, &cbValueName, 0,
                                &type, (PBYTE)&dwValue, &cbValue );

        if ( ERROR_NO_MORE_ITEMS == hResult )
            break;

        char szLB_Line[ MAX_PATH + 32 ];
        wsprintf( szLB_Line, "%s\t%s %u",
                    szValueName,
                    dwValue & MW_SCROLL_PAGE ? "PAGE" : "LINE",
                    dwValue & MW_SCROLL_INCREMENT_MASK );

        pListBox->AddString( szLB_Line );
    }

    RegCloseKey( hKey );

    return TRUE;
}


void CMWDlg::OnDeleteProgram() 
{
    // TODO: Add your control notification handler code here
    CListBox * pListBox = (CListBox *)GetDlgItem(IDC_PROGRAM_LIST);

    int curSel = pListBox->GetCurSel();
    if ( LB_ERR == curSel )
    {
        MessageBox( "Must select an program to delete" );
        return;
    }

    CString cLBText;
    
    pListBox->GetText( curSel, cLBText );

    CString cProgramName = cLBText.SpanExcluding( "\t" );

    HKEY hKey = ((CMWApp *)AfxGetApp())->GetRegKey();
    if ( !hKey )
        return;

    RegDeleteValue( hKey, cProgramName );

    RegCloseKey( hKey );

    RefreshProgramListbox();
}

void CMWDlg::OnOK() 
{
    // Default OK behavior should hide the dialog, not terminate the app
    ShowWindow( SW_HIDE );
}


void CMWDlg::OnClose() 
{
    // TODO: Add your message handler code here and/or call default
    
    m_notifyIconData.uFlags = NIF_ICON;
    Shell_NotifyIcon( NIM_DELETE, &m_notifyIconData );

    CDialog::OnClose();
}


//////////////////
// Handle notification from tray icon: display a message.
//
LRESULT CMWDlg::OnTrayNotification(WPARAM uID, LPARAM lEvent)
{
    if ( lEvent == WM_LBUTTONDBLCLK )
    {
        m_okToShow = TRUE;    // Allow the dialog to be shown

        if ( !IsWindowVisible() )
            ShowWindow( SW_SHOW );

        if ( IsIconic() )
            ShowWindow( SW_RESTORE );
    }

    #if 1
    else if ( lEvent == WM_RBUTTONUP )
    {
        CMenu * pSysMenu = GetSystemMenu( FALSE );
        if ( pSysMenu )
        {
            CPoint mouse;
            GetCursorPos(&mouse);
            pSysMenu->TrackPopupMenu( TPM_CENTERALIGN, mouse.x, mouse.y, this );
            // delete pSysMenu;
        }
    }
    #endif

    return 0;
}



BOOL CMWDlg::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo) 
{
    // If it's the WM_SYSCOMMAND SC_CLOSE message, repost it as a WM_CLOSE message
    // so that our normal WM_CLOSE handler will handle it.
    if ( SC_CLOSE == nID )
        PostMessage( WM_CLOSE );

    return CDialog::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}
