// MW.h : main header file for the MW application
//

#ifndef __AFXWIN_H__
    #error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"        // main symbols

/////////////////////////////////////////////////////////////////////////////
// CMWApp:
// See MW.cpp for the implementation of this class
//

class CMWApp : public CWinApp
{
public:
    HKEY GetRegKey();
    CMWApp();

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CMWApp)
    public:
    virtual BOOL InitInstance();
    //}}AFX_VIRTUAL

// Implementation

    //{{AFX_MSG(CMWApp)
        // NOTE - the ClassWizard will add and remove member functions here.
        //    DO NOT EDIT what you see in these blocks of generated code !
    //}}AFX_MSG

    CString m_RegPath;

    DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
