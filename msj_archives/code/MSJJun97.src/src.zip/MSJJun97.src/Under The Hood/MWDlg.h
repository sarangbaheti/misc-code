// MWDlg.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CMWDlg dialog

#define WM_MY_TRAY_NOTIFICATION WM_APP+0

class CMWDlg : public CDialog
{
// Construction
public:
    CMWDlg(CWnd* pParent = NULL);    // standard constructor

// Dialog Data
    //{{AFX_DATA(CMWDlg)
    enum { IDD = IDD_MW_DIALOG };
        // NOTE: the ClassWizard will add data members here
    //}}AFX_DATA

    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CMWDlg)
    public:
    virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:
    BOOL RefreshProgramListbox( void );
    HICON m_hIcon;

    NOTIFYICONDATA m_notifyIconData;
    BOOL m_okToShow;

    // Generated message map functions
    //{{AFX_MSG(CMWDlg)
    afx_msg LRESULT OnTrayNotification(WPARAM wp, LPARAM lp);
    virtual BOOL OnInitDialog();
    afx_msg void OnPaint();
    afx_msg HCURSOR OnQueryDragIcon();
    afx_msg void OnAddProgram();
    afx_msg void OnDeleteProgram();
    virtual void OnOK();
    afx_msg void OnClose();
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};
