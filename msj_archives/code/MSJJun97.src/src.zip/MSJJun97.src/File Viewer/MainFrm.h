////////////////////////////////////////////////////////////////
// 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "PalHook.h"
#include "FVFrame.h"

////////////////
// Palette-handling main frame window
//
class CMainFrame : public CFVFrameWnd {
protected:
	DECLARE_DYNCREATE(CMainFrame)
	CPalMsgHandler m_palMsgHandler; // handles palette messages
	CStatusBar		m_wndStatusBar;	// status bar
	CToolBar			m_wndToolBar;		// tool (button) bar

	DECLARE_MESSAGE_MAP()
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);

public:
	CMainFrame();
	virtual ~CMainFrame();
};
