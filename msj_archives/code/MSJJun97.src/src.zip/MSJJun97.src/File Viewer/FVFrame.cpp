////////////////////////////////////////////////////////////////
// 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// Main frame viewer for quick view file viewers.
// Implements drag/drop and a few messages needed for file viewers.
// You should derive your viewer frame window from this.
//
#include "StdAfx.h"
#include "FVFrame.h"
#include "Debug.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CFVFrameWnd, CFrameWnd)
BEGIN_MESSAGE_MAP(CFVFrameWnd, CFrameWnd)
	ON_WM_CLOSE()
	ON_WM_DESTROY()
	ON_WM_DROPFILES()
END_MESSAGE_MAP()

////////////////
// Constructor hooks up to CFileViewerApp
//
CFVFrameWnd::CFVFrameWnd()
{
	TRACEFN("CFVFrameWnd::CFVFrameWnd\n");
	m_pApp = (CFileViewerApp*)AfxGetApp();
	ASSERT_KINDOF(CFileViewerApp, m_pApp);
	ASSERT_VALID(m_pApp);

	// Default toolbar ID you can override, or set to zero
	// for no toolbar management.
	m_uIDToolBar = AFX_IDW_TOOLBAR;
}

/////////////////
// Destructor for TRACE diagnostics
//
CFVFrameWnd::~CFVFrameWnd()
{
	TRACE0("CFVFrameWnd::~CFVFrameWnd\n");
}

/////////////////
// User clicked close box or Alt-F4. MFC's close logic is messed up
// for our purposes: it won't post a quit message because it thinks doing
// so is wrong for DLLs. So we have to override MFC: Mimic CFrameWnd
// close sequence, but make sure to call AfxPostQuitMessage.
//
void CFVFrameWnd::OnClose() 
{
	TRACEFN("CFVFrameWnd::OnClose\n");
	ASSERT(m_lpfnCloseProc == NULL);	 // (MFC uses this for preview mode)
	m_pApp->CloseAllDocuments(FALSE); // will destroy main main (this) win too
	AfxPostQuitMessage(0);				 // end message loop*/
}



//////////////////
// Window is being destroyed: unpin if we're pinned, else can cause havoc.
//
void CFVFrameWnd::OnDestroy() 
{
	TRACEFN("CFVFrameWnd::OnDestroy\n");
	if (m_pApp->GetPinned())
		m_pApp->SetPinned(FALSE);
	CFrameWnd::OnDestroy();
}

//////////////////
// User dragged a file onto us, or we're pinned and QuickView
// opened another file: view it. If more than one file, do first only.
// Note: only uses first file since FVSHOWINFO doesn't have room for more.
//
void CFVFrameWnd::OnDropFiles(HDROP hDropInfo)
{
	TRACEFN("CFVFrameWnd::OnDropFiles\n");
	TCHAR szFileName[_MAX_PATH];
	::DragQueryFile(hDropInfo, 0, szFileName, _MAX_PATH);
	m_pApp->OpenDocumentFile(CString(szFileName)); // delegate to app
	::DragFinish(hDropInfo);
}

// C++ Hack to access bitmap in toolbar
//
class CMyToolBar : public CToolBar {
public:
	HBITMAP GetBitmap() { return m_hbmImageWell; }
};

//////////////////
// Change toolbar "Open" button icon to the file's associated program icon,
// if any. Assumes open button is the first one in the toolbar bitmap.
//
void CFVFrameWnd::OnSetOpenButtonIcon()
{
	if (m_uIDToolBar!=0) {

		// Get tool bar
		CToolBar* pToolBar = (CToolBar*)GetDlgItem(m_uIDToolBar);
		ASSERT(pToolBar);
		ASSERT_KINDOF(CToolBar, pToolBar);

		// Get small icon
		SHFILEINFO shfi;
		LPCSTR lpFileName = m_pApp->OnGetFileName();
		if (SHGetFileInfo(lpFileName, 0, &shfi, sizeof(shfi),
			SHGFI_ICON | SHGFI_SMALLICON)) {

			// Copy current toolbar bitmap. Use hack to get it.
			HBITMAP hbm = ((CMyToolBar*)pToolBar)->GetBitmap();
			ASSERT(hbm);
			hbm = (HBITMAP)::CopyImage(hbm,IMAGE_BITMAP,0,0,LR_COPYRETURNORG);
			ASSERT(hbm);

			// Render the icon into new bitmap
			CWindowDC dcWin(pToolBar);
			CDC memdc;
			memdc.CreateCompatibleDC(&dcWin);
			CBitmap *pOldBM = memdc.SelectObject(CBitmap::FromHandle(hbm));
			CBrush brush;
			brush.CreateSysColorBrush(COLOR_BTNFACE);
			VERIFY(::DrawIconEx(memdc.m_hDC, 0, 0, shfi.hIcon, 16, 16, 0, brush,
				DI_NORMAL));
			memdc.SelectObject(pOldBM);

			// Change bitmap in toolbar 
			pToolBar->SetBitmap(hbm);
			pToolBar->Invalidate(TRUE);

		} else 
			TRACE("Warning: couldn't find icon for %s\n", lpFileName);
	}
}
