////////////////////////////////////////////////////////////////
// 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// CFileViewer implements the IFileViewer interface. It delegates most
// of the work to CFileViewerApp. You should never have to override
// anything here; use CFileViewerApp.
//
// This class/file implement all the COM stuff, including the Dllxxx
// functions, and converts everything to normal MFC virtual function
// calls by delegating to the app. 
//
// The only thing you have to do is include the IMPLEMENT_OLECREATE macro
// in your app file, to create the CFileViewer class factory with yout own
// GUID and external name.

#include "StdAfx.h"
#include "FVApp.h"
#include "Debug.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Use this to turn off tracing
/*#undef TRACEFN
#undef TRACE
#undef TRACE0
#define TRACEFN CString().Format
#define TRACE CString().Format
#define TRACE0 CString().Format*/

IMPLEMENT_DYNCREATE(CFileViewer, CCmdTarget)
BEGIN_INTERFACE_MAP(CFileViewer, CCmdTarget)
	INTERFACE_PART(CFileViewer,	IID_IFileViewer,	FileViewer)
	INTERFACE_PART(CFileViewer,	IID_IPersistFile,	PersistFile)
END_INTERFACE_MAP()

CFileViewer::CFileViewer()
{
	TRACEFN("CFileViewer::CFileViewer\n");
	m_state = Dead;
	m_pApp = (CFileViewerApp*)AfxGetApp();
	ASSERT_KINDOF(CFileViewerApp, m_pApp);
	ASSERT_VALID(m_pApp);
	ASSERT(m_pApp->m_pfv==NULL);
	m_pApp->m_pfv = this;   // hook myself up to application object
	AfxOleLockApp();			// don't let app quit while I'm alive
}

CFileViewer::~CFileViewer()
{
	TRACEFN("CFileViewer::~CFileViewer\n");
	ASSERT(m_pApp->m_pfv == this);
	m_pApp->m_pfv = NULL;   // unhook myself from application object
	AfxOleUnlockApp();		// I'm dead: OK to quit app
}

//////////////////
// This function is called when the ref count goes to zero
//
void CFileViewer::OnFinalRelease()
{
	TRACEFN("CFileViewer::OnFinalRelease\n");
	m_pApp->OnFinalReleaseFV();	// let app clean up
	CCmdTarget::OnFinalRelease(); // will delete this
}

////////////////////////////////////////////////////////////////
// IFileViewer implementation
//
STDMETHODIMP_(ULONG) CFileViewer::XFileViewer::AddRef()
{
	METHOD_PROLOGUE(CFileViewer, FileViewer)
	TRACEFN("CFileViewer::IFileViewer::AddRef\n");
	DWORD dwRef = pThis->ExternalAddRef();
	TRACE("[ref count=%ld]\n", dwRef);
	return dwRef;
}

STDMETHODIMP_(ULONG) CFileViewer::XFileViewer::Release()
{
	METHOD_PROLOGUE(CFileViewer, FileViewer)
	TRACEFN("CFileViewer::IFileViewer::Release\n");
	DWORD dwRef = pThis->ExternalRelease();
	TRACE("[ref count=%ld]\n", dwRef);
	return dwRef;
}

STDMETHODIMP CFileViewer::XFileViewer::QueryInterface(REFIID iid, 
	LPVOID* ppvObj)
{
	METHOD_PROLOGUE(CFileViewer, FileViewer)
	TRACEFN("CFileViewer::IFileViewer::QueryInterface(%s)\n", DbgName(iid));
	HRESULT hr = pThis->ExternalQueryInterface(&iid, ppvObj);
	TRACE("[ref count=%ld]\n", pThis->m_dwRef);
	return hr;
}

STDMETHODIMP CFileViewer::XFileViewer::ShowInitialize(LPFILEVIEWERSITE ipSite)
{
	METHOD_PROLOGUE(CFileViewer, FileViewer);
	TRACEFN("CFileViewer::IFileViewer::ShowInitialize\n");

	if (pThis->m_state != Loaded) {
		TRACE("***ShowInitialize called before IPersistFile::Load!\n");
		return E_UNEXPECTED;
	}

	// Make parent class members look like mine. These are references, 
	// so when I change them, I change the real thing.
	//
	CFileViewerApp*&	m_pApp		= pThis->m_pApp;
	LPFILEVIEWERSITE& m_ipSite		= m_pApp->m_ipSite;
	HRESULT&				m_hr			= m_pApp->m_hr;

	// Store viewer site interface. 
	ASSERT(m_ipSite==NULL);
	m_ipSite = ipSite;
	ipSite->AddRef();

	m_hr = E_UNEXPECTED;			// assume the worst
	if (m_pApp->OnShowInitialize()) {
		pThis->m_state = ShowInit;
		m_hr = NOERROR;
	} else {
		TRACE("***OnShowInitialize failed.\n");
	}
	return m_hr;
}

#ifdef _DEBUG
//////////////////
// Helper to trace the contents of FVSHOWINFO structure
//
void TraceFVSHOWINFO(LPFVSHOWINFO pfvsi)
{
	static LPCSTR ShowCommands[] = {
		"SW_HIDE",
		"SW_SHOWNORMAL",
		"SW_SHOWMINIMIZED",
		"SW_SHOWMAXIMIZED",
		"SW_MAXIMIZE",
		"SW_SHOWNOACTIVATE",
		"SW_SHOW",
		"SW_MINIMIZE",
		"SW_SHOWMINNOACTIVE",
		"SW_SHOWNA",
		"SW_RESTORE"
	};

	CString sFlags;
	DWORD dwFlags = pfvsi->dwFlags;
	if (dwFlags & FVSIF_RECT)
		sFlags += "FVSIF_RECT ";
	if (dwFlags & FVSIF_PINNED)
		sFlags += "FVSIF_PINNED ";
	if (dwFlags & FVSIF_NEWFAILED)
		sFlags += "FVSIF_NEWFAILED ";
	if (dwFlags & FVSIF_NEWFILE)
		sFlags += "FVSIF_NEWFILE ";
	if (dwFlags & FVSIF_CANVIEWIT)
		sFlags += "FVSIF_CANVIEWIT ";

	// TRACE diagnostics for args
	TRACE(" hwndOwner  = 0x%08lx\n", pfvsi->hwndOwner);
	TRACE(" iShow      = %s\n", ShowCommands[pfvsi->iShow]);
	TRACE(" dwFlags    = %s\n", (LPCSTR)sFlags);
	TRACE(" rect       = (%d,%d,%d,%d)\n", pfvsi->rect.left,
		pfvsi->rect.top, pfvsi->rect.right, pfvsi->rect.bottom);
	TRACE(" punkrel    = %p\n", pfvsi->punkRel);
	TRACE(" strNewFile = %s\n", (LPCSTR)(CString(pfvsi->strNewFile)));
}
#else
#define TraceFVSHOWINFO
#endif

STDMETHODIMP CFileViewer::XFileViewer::Show( LPFVSHOWINFO pfvsi)
{
	METHOD_PROLOGUE(CFileViewer, FileViewer);
	TRACEFN("CFileViewer::IFileViewer::Show\n");
	TraceFVSHOWINFO(pfvsi);

	if (pThis->m_state!=ShowInit) {
		TRACE("***Show called before ShowInitialize!\n");
		return E_UNEXPECTED;
	}

	// Make parent class members look like mine.
	//
	CFileViewerApp*&	m_pApp   = pThis->m_pApp;
	LPFILEVIEWERSITE& m_ipSite	= m_pApp->m_ipSite;
	LPFVSHOWINFO&		m_pfvsi  = m_pApp->m_pfvsi;
	HRESULT&				m_hr     = m_pApp->m_hr;
	
	m_hr = E_UNEXPECTED;
	m_pfvsi = pfvsi;

	// Call app to show it!
	if (m_pApp->OnShow(pfvsi))
		m_hr = NOERROR;
	else {
		TRACE("***OnShow failed\n");
	}
			
	// Done with viewer site and FVSHOWINFO
	m_pfvsi = NULL;
	if (m_ipSite) {
		m_ipSite->Release();
		m_ipSite = NULL;
	}

	TRACE0("returning from OnShow with:\n");
	TraceFVSHOWINFO(pfvsi);

	// Go back to ShowInitialized state (could get another show)
	pThis->m_state = m_pApp->m_pMainWnd ? ShowInit : Dead;
	return m_hr;
}

STDMETHODIMP CFileViewer::XFileViewer::PrintTo( LPSTR pszDriver, 
	BOOL fSuppressUI)
{
	METHOD_PROLOGUE(CFileViewer, FileViewer)
	CFileViewerApp*& m_pApp = pThis->m_pApp;
	HRESULT& m_hr = m_pApp->m_hr;
	m_hr = E_UNEXPECTED;
	if (m_pApp->OnPrintTo(pszDriver, fSuppressUI))
		m_hr = NOERROR;
	return m_hr;
}

////////////////////////////////////////////////////////////////
// IPersistFile implementation
//
STDMETHODIMP_(ULONG) CFileViewer::XPersistFile::AddRef()
{
	METHOD_PROLOGUE(CFileViewer, PersistFile)
	TRACEFN("CFileViewer::IPersistFile::AddRef\n");
	DWORD dwRef = pThis->ExternalAddRef();
	TRACE("[ref count=%d]\n", dwRef);
	return dwRef;
}

STDMETHODIMP_(ULONG) CFileViewer::XPersistFile::Release()
{
	METHOD_PROLOGUE(CFileViewer, PersistFile)
	TRACEFN("CFileViewer::IPersistFile::Release\n");
	DWORD dwRef = pThis->ExternalRelease();
	TRACE("[ref count=%d]\n", dwRef);
	return dwRef;
}

STDMETHODIMP CFileViewer::XPersistFile::QueryInterface(REFIID iid, 
	LPVOID* ppvObj)
{
	METHOD_PROLOGUE(CFileViewer, PersistFile)
	TRACEFN("CFileViewer::IPersistFile::QueryInterface(%s)\n", DbgName(iid));
	HRESULT hr = pThis->ExternalQueryInterface(&iid, ppvObj);
	TRACE("[ref count=%d]\n", pThis->m_dwRef);
	return hr;
}

STDMETHODIMP CFileViewer::XPersistFile::GetClassID(LPCLSID pClsID)
{
	METHOD_PROLOGUE(CFileViewer, FileViewer)
	return E_NOTIMPL;
}

STDMETHODIMP CFileViewer::XPersistFile::IsDirty()
{
	METHOD_PROLOGUE(CFileViewer, FileViewer)
	return S_FALSE; // since I never edit it
}

STDMETHODIMP CFileViewer::XPersistFile::Load(LPCOLESTR lpFileName, 
	DWORD grfMode)
{
	METHOD_PROLOGUE(CFileViewer, PersistFile);
	TRACEFN("CFileViewer::IPersistFile::Load(%s,%08lx)\n",
		(LPCSTR)(CString(lpFileName)), grfMode);

	if (pThis->m_state!=Dead) {
		TRACE("***Load called at wrong time!\n");
		return E_UNEXPECTED;
	}

	CFileViewerApp*& m_pApp = pThis->m_pApp;
	HRESULT& m_hr = m_pApp->m_hr;
	m_hr = E_FAIL;
	if (m_pApp->OnLoad(lpFileName, grfMode)) {
		pThis->m_state = Loaded;
		m_hr = NOERROR;
	} else {
		TRACE("***Load failed\n");
	}
	return m_hr;
}

STDMETHODIMP CFileViewer::XPersistFile::Save(LPCOLESTR, BOOL)
{
	METHOD_PROLOGUE(CFileViewer, FileViewer)
	return E_NOTIMPL;
}

STDMETHODIMP CFileViewer::XPersistFile::SaveCompleted(LPCOLESTR)
{
	METHOD_PROLOGUE(CFileViewer, FileViewer)
	return E_NOTIMPL;
}

STDMETHODIMP CFileViewer::XPersistFile::GetCurFile(LPOLESTR* lplpFileName)
{
	METHOD_PROLOGUE(CFileViewer, FileViewer);

	if (!lplpFileName)
		return E_UNEXPECTED;
	*lplpFileName = NULL;

	// Make parent class members look like mine.
	//
	CFileViewerApp*&	m_pApp		= pThis->m_pApp;
	HRESULT&				m_hr        = m_pApp->m_hr;

	USES_CONVERSION;			// MFC Unicode conversion macros
	LPVOID pMem = NULL;
	CString sFileName = m_pApp->OnGetFileName();
	int len = (sFileName.GetLength() + 1)*sizeof(OLECHAR);
	m_hr = MfxOleAlloc(len, &pMem);
	if (FAILED(m_hr))
		return m_hr;
	else if (!pMem)
		return E_OUTOFMEMORY;

	// Convert filename to wide char and copy to caller's buffer
	//
	*lplpFileName=(LPOLESTR)pMem;
	wcscpy(*lplpFileName, A2W((LPCSTR)sFileName));

	return m_hr = NOERROR;
}

//////////////////
// Helper function to allocate memory using IMalloc
//
HRESULT MfxOleAlloc(ULONG cb, LPVOID* ppv)
{
	LPMALLOC pIMalloc;

	HRESULT hr = ::CoGetMalloc(MEMCTX_TASK, &pIMalloc);
	if (FAILED(hr)) {
		TRACE("MfxOleAlloc failed %08lx", hr);
		*ppv = NULL;
	} else {
		*ppv=pIMalloc->Alloc(cb);
		pIMalloc->Release();
	}
	return hr;
}

/////////////////////////////////////////////////////////////////////////////
// Special entry points required for inproc servers

//////////////////
// COM calls this function to obtain a class library to create objects
//
STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

#ifdef _DEBUG
	// Real bad hack: create/destroy a window to make sure
	// TRACEWIN DLL gets injected into my process space.
	HWND hwnd = ::CreateWindow("Button","",0,0,0,0,0,0,0,
		AfxGetInstanceHandle(),0);
	::DestroyWindow(hwnd);
#endif _DEBUG

	TRACEFN("DllGetClassObject(%s, %s)\n", DbgName(rclsid), DbgName(riid));
	return AfxDllGetClassObject(rclsid, riid, ppv);
}

///////////////////
// COM calls this function to see if it's OK to unload the DLL
//
STDAPI DllCanUnloadNow(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	SCODE sc = AfxDllCanUnloadNow();
	TRACE("DllCanUnloadNow? %s\n", sc==S_OK ? "Yes" : "No");
	return sc;
}

////////////////
// By exporting DllRegisterServer, you can use regsvr.exe to
// register your COM object.
//
STDAPI DllRegisterServer(void)
{
	COleObjectFactory::UpdateRegistryAll();
	return S_OK;
}
