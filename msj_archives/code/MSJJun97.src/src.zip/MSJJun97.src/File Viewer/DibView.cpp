////////////////////////////////////////////////////////////////
// 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// DIBVIEW is a Quick File Viewer for device-independent bitmaps.
// You can open .DIB or .BMP files and view them
//
#include "StdAfx.h"
#include "DibView.h"
#include "MainFrm.h"
#include "Doc.h"
#include "View.h"
#include "Debug.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BEGIN_MESSAGE_MAP(CApp, CFileViewerApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	// Below are handled by CFileViewerApp
	ON_COMMAND(ID_FILE_OPEN,							OnFileOpen)
	ON_COMMAND(ID_VIEW_REPLACEWINDOW,				OnPinWindow)
	ON_UPDATE_COMMAND_UI(ID_VIEW_REPLACEWINDOW,	OnUpdatePinWindow)
END_MESSAGE_MAP()

CApp theApp;

// You must insert this line in your app somewhere.
// Change GUID and name to your own
//
// {828C5D60-1B7E-11cf-82ED-444553540000}
IMPLEMENT_OLECREATE(CFileViewer, "MSJ DIB Bitmap Viewer",
	0x828c5d60, 0x1b7e, 0x11cf, 0x82, 0xed, 0x44, 0x45, 0x53, 0x54, 0x0, 0x0)

#ifdef _DEBUG
// Used for debugging--Interfaces I want to watch
static DBGINTERFACENAME InterfaceNames[] = {
	{ &IID_IUnknown,		"IUnknown" },
	{ &IID_IClassFactory,"IClassFactory" },
	{ &IID_IPersistFile,	"IPersistFile" },
	{ &IID_IFileViewer,	"IFileViewer" },
	{ &IID_IUnknown, NULL }
};
#endif

CApp::CApp()
{
#ifdef _DEBUG
	_pDbgInterfaceNames = InterfaceNames;
#endif
}

CApp::~CApp()
{
}

BOOL CApp::InitInstance()
{
	// Save settings in registry, not INI file
	SetRegistryKey("MSJ");

	if (!CFileViewerApp::InitInstance())
		return FALSE;

	// Create document template
	TRACE("[creating doc template]\n");
	AddDocTemplate(new CSingleDocTemplate(IDR_MAINFRAME,
		RUNTIME_CLASS(CDIBDoc),
		RUNTIME_CLASS(CMainFrame),
		RUNTIME_CLASS(CDIBView)));
	return TRUE;
}

void CApp::OnAppAbout()
{
	CDialog(IDD_ABOUTBOX).DoModal();
}
