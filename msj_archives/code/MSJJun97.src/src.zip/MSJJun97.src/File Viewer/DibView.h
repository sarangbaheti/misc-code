////////////////////////////////////////////////////////////////
// 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// See DibView.cpp
//
#include "Resource.h"
#include "FVApp.h"

//////////////////
// Application class: derive from CFileViewerApp
//
class CApp : public CFileViewerApp {
public:
	CApp();
	virtual ~CApp();
	virtual BOOL InitInstance();
protected:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnAppAbout();
};
