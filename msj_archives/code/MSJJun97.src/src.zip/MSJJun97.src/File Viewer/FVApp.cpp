////////////////////////////////////////////////////////////////
// 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "StdAfx.h"
#include "FVApp.h"
#include "FVFrame.h"
#include "Debug.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CFileViewerApp, CWinApp)

//////////////////
// Construct file viewer app
//
CFileViewerApp::CFileViewerApp()
{
	TRACE("CFileViewerApp::CFileViewerApp\n");
	m_hr = NOERROR;
	m_ipSite = NULL;
}

CFileViewerApp::~CFileViewerApp()
{
	TRACE("CFileViewerApp::~CFileViewerApp\n");
}

BOOL CFileViewerApp::InitInstance()
{
	TRACEFN("CFileViewerApp::InitInstance\n");

	// Register class factories, so clients can create file viewers.
	COleObjectFactory::RegisterAll();

	// This hack is to correct a "flaw" in MFC. Normally, MFC calls this to
	// initialize the doc manager, from InitApplication. But MFC doesn't call
	// InitApplication for a DLL, so I have to init the doc manager manually.
	AddDocTemplate(NULL);

	return TRUE;
}

//////////////////
// Exit viewer: just display TRACE diagnostic
//
int CFileViewerApp::ExitInstance()
{
	TRACEFN("CFileViewerApp::ExitInstance\n");
	return CWinApp::ExitInstance();
}

//////////////////
// Get name of current document. Used for IPersistFile::GetCurFile
//
CString CFileViewerApp::OnGetFileName()
{
	CDocument* pDoc = m_pOpenDoc;
	if (!pDoc) {
		CFrameWnd* pFrame = (CFrameWnd*)m_pMainWnd;
		if (pFrame) {
			ASSERT_KINDOF(CFrameWnd, pFrame);
			pDoc = pFrame->GetActiveDocument();
		}
	}
	return pDoc ? pDoc->GetPathName() : CString();
}

/////////////////
// I got a new file to open via drag/drop or QuickView.
//
CDocument* CFileViewerApp::OpenDocumentFile(LPCTSTR lpszFileName)
{
	TRACEFN("CFileViewerApp::OpenDocumentFile(%s)\n",lpszFileName);
	CDocument* pDoc = NULL;
	if (CanOpenDocument(lpszFileName)) {						// if can open:
		if (OnGetFileName()==CString(lpszFileName))			// if already open:
			pDoc = ((CFrameWnd*)m_pMainWnd)->GetActiveDocument(); 
		else {
			pDoc = CWinApp::OpenDocumentFile(lpszFileName); // open it
			m_pMainWnd->SetForegroundWindow(); // else Windows gets confused
		}

	} else {
		// I can't open this doc, so quit message loop and pass filename back
		// to QuickView as new file to view. Must convert name to OLECHAR (yuk).
		//
		mbstowcs(m_pfvsi->strNewFile, lpszFileName, strlen(lpszFileName)+1);
		m_pfvsi->dwFlags |= FVSIF_NEWFILE;
		AfxPostQuitMessage(0);
	}
	if (pDoc)						// if a doc was successfully opened:
		SetOpenButtonIcon();		// set toolbar "Open" button

	if (!pDoc)
		TRACE("***CFileViewerApp::OpenDocumentFile returning NULL\n");

	return pDoc;
}

//////////////////
// This helper fn determines if I can open a document. It searches the doc
// templates for one whose file name extension matches the requested file.
// Note: I have never tried it with more than one doc template, but in theory
// it should work.
//
CDocTemplate* CFileViewerApp::CanOpenDocument(LPCTSTR lpszPath)
{
	CDocument* pDoc;
	POSITION pos = m_pDocManager->GetFirstDocTemplatePosition();
	while (pos != NULL) {
		CDocTemplate* pdt = m_pDocManager->GetNextDocTemplate(pos);
		if (pdt->MatchDocType(lpszPath,pDoc) >= CDocTemplate::yesAttemptNative)
			return pdt;
	}
	if (!pDoc) {
		// If you got here, you may have forgotten to set the file extension
		// in your IDR_MAINFRAME string, or are trying to open a different
		// kind of doc by drag/drop (which is normal).
		TRACE("***Can't find doc template for %s\n", lpszPath);
	}
	return NULL;
}

//////////////////
// This is copied from CWinThread::Run, except that instead of
// calling ExitInstance when the loop ends, I just return.
//
int CFileViewerApp::Run()
{
	TRACEFN("CFileViewerApp::Run\n");
	ASSERT_VALID(this);

	// for tracking the idle time state
	BOOL bIdle = TRUE;
	LONG lIdleCount = 0;

#ifdef _DEBUG
	// In debug mode, MFC uses the following counter to prevent you from
	// calling Run twice; i.e., reentering the message loop. But we want to
	// do just that! So let's fake out MFC.
	m_nDisablePumpCount = 0;  
#endif

	// acquire and dispatch messages until a WM_QUIT message is received.
	for (;;)
	{
		// phase1: check to see if we can do idle work
		while (bIdle &&
			!::PeekMessage(&m_msgCur, NULL, NULL, NULL, PM_NOREMOVE))
		{
			// call OnIdle while in bIdle state
			if (!OnIdle(lIdleCount++))
				bIdle = FALSE; // assume "no idle" state
		}

		// phase2: pump messages while available
		do
		{
			// pump message, but quit on WM_QUIT
			if (!PumpMessage())
				return 0; // <<***** RETURN, DON'T CALL ExitInstance! *****

			// reset "no idle" state after pumping "normal" message
			if (IsIdleMessage(&m_msgCur))
			{
				bIdle = TRUE;
				lIdleCount = 0;
			}

		} while (::PeekMessage(&m_msgCur, NULL, NULL, NULL, PM_NOREMOVE));
	}

	ASSERT(FALSE);  // not reachable
}

//////////////////
// Load document. This function is responsible for opening the document
// and setting m_pOpenDoc to the document loaded.
//
BOOL CFileViewerApp::OnLoad(LPCOLESTR lpFileName, DWORD grfMode)
{
	ASSERT(lpFileName!=NULL);
	CString sFileName = lpFileName;
	TRACEFN("CFileViewerApp::OnLoad(%s)\n",(LPCTSTR)sFileName);
	CDocTemplate* pDocTemplate = CanOpenDocument(sFileName);
	if (pDocTemplate) {
		CDocument* pDoc = pDocTemplate->CreateNewDocument();
		if (pDoc) {
			if (pDoc->OnOpenDocument(sFileName)) {
				pDoc->SetPathName(sFileName);
				ASSERT(m_pOpenDoc==NULL);
				m_pOpenDoc = pDoc;
				return TRUE;
			}
			delete pDoc;
		}
	}
	return FALSE;
}

//////////////////
// Handle IFileViewer::ShowInitialize - create main window if not there.
//
BOOL CFileViewerApp::OnShowInitialize()
{
	TRACEFN("CFileViewerApp::OnShowInitialize\n");
	if (m_pMainWnd==NULL) {
		TRACE("[creating main window]\n");
		m_nCmdShow = SW_HIDE;	// don't show window yet
		// Manually create the frame/view and attach to our loaded doc
		CDocument* pDoc = m_pOpenDoc;
		ASSERT(pDoc);
		CDocTemplate *pDocTemplate = pDoc->GetDocTemplate();
		CFrameWnd* pFrame = pDocTemplate->CreateNewFrame(pDoc, NULL);
		m_pMainWnd = pFrame;
	} else
		TRACE("[reusing main window]\n");

	return TRUE;
}

//////////////////
// Handle IFileViewer::Show - show main frame, then enter message loop.
//
BOOL CFileViewerApp::OnShow(LPFVSHOWINFO pfvsi)
{
	TRACEFN("CFileViewerApp::OnShow\n");
	ASSERT_VALID(m_pMainWnd);

	// If QuickView specified a rectangle, use it
	if (pfvsi->dwFlags & FVSIF_RECT) {
		CRect rc = pfvsi->rect;
		m_pMainWnd->SetWindowPos(NULL,
			rc.left, rc.top, rc.Width(), rc.Height(),
			SWP_NOZORDER | SWP_NOREDRAW | SWP_NOACTIVATE );
	}

	// Change the toolbar "Open" button
	SetOpenButtonIcon();

	// Show window. Unless this is a failed NEWFILE, the window should be
	// empty since I haven't called InitialUpdateFrame yet
	//
	m_pMainWnd->ShowWindow(pfvsi->iShow);

	// If there was a previous viewer, Release it.
	if (pfvsi->punkRel) {
		TRACE0("[Releasing previous viewer]\n");
		pfvsi->punkRel->Release();
		pfvsi->punkRel = NULL;
	}

	// Check for pinned state
	if ((pfvsi->dwFlags & FVSIF_PINNED) && m_ipSite) {
		TRACE0("[Making meself the pinned window]\n");
		VERIFY(m_ipSite->SetPinnedWindow(NULL)==NOERROR); // force unpin old
		SetPinned(TRUE);											  // pin myself
	}

	if (pfvsi->dwFlags & FVSIF_NEWFAILED) {
		// In the case of FVSIF_NEWFAILED, everything is fine: The window is
		// still here and I just drop into a new message loop. Some
		// implementations destroy the window and recreate it again here, but
		// there's no need--that's the whole point of pfvsi->punkRel
		// and the deferred final Release.

	} else {
		// Not FVSIF_NEWFAILED: I have a new loaded doc whose frame
		// to initialize.
		TRACE0("[Initializing frame]\n");
		ASSERT(m_pOpenDoc);

		// Must move to foreground so palette stuff all works fine
		m_pMainWnd->SetForegroundWindow(); 

		// Now call InitialUpdateFrame. This is part of what normally happens
		// in OpenDocumentFile that now got split off as part of Show.
		// This will send OnInitialUpdate to the view--very important!
		// 
		m_nCmdShow = pfvsi->iShow;
		m_pOpenDoc->GetDocTemplate()->
			InitialUpdateFrame((CFrameWnd*)m_pMainWnd, m_pOpenDoc, TRUE);
		m_pOpenDoc = NULL;				 // doc belongs to frame now
		m_pMainWnd->UpdateWindow();	 // paint it
	}

	pfvsi->dwFlags = 0; // clear flags

	// Enter message loop. Doesn't return until user quits or I get
	// a WM_DROPFILES from somewhere (shell or QuickView).
	// 
	TRACE0("[Entering message loop]\n");
	Run();
	TRACE0("[Exited message loop]\n");

	// There are only two ways we could have exited the message loop:
	//
	// * the user closed, in which case the main window should be gone; or
	//
	// * I got a WM_DROPFILES to view a new file, in which case, the main
	//   window should still be here. I must give QuickView an IUnknown to
	//   release, and when it does (after the new viewer has displayed itself
	//   over my window), I'll destroy my main window, in OnFinalRelease
	//
	if (pfvsi->dwFlags & FVSIF_NEWFILE) {
		ASSERT_VALID(m_pMainWnd); // main window should still be here

		// Return my pinned state to QuickView/new viewer.
		if (GetPinned())
			pfvsi->dwFlags |= FVSIF_PINNED;

		// Return my main window coordinates to QuickView/new viewer.
		m_pMainWnd->GetWindowRect(&pfvsi->rect);
		pfvsi->dwFlags |= FVSIF_RECT;

		// Give QuickView an IUnknown to release me.
		// (That's when I'll destroy the main window)
		ASSERT(m_pfv);
		m_pfv->m_xFileViewer.QueryInterface(IID_IUnknown,
			(LPVOID*)&pfvsi->punkRel);

	} else {
		// User must have exited; main window should be gone.
		ASSERT(m_pMainWnd==NULL);
	}

	return TRUE;
}

//////////////////
// Handle IFileViewer::PrintTo - not implemented.
//
BOOL CFileViewerApp::OnPrintTo(LPSTR pszDriver, BOOL fSuppressUI)
{
	m_hr = E_NOTIMPL;
	return FALSE;		
}

//////////////////
// QuickView called final Release on file viewer. This function is called
// from CFileViewer::OnFinalRelease. Destroy everything and die.
//
void CFileViewerApp::OnFinalReleaseFV()
{
	TRACEFN("CFileViewerApp::OnFinalReleaseFV\n");

	if (m_pMainWnd) {
		TRACE0("[Closing main window]\n");
		CloseAllDocuments(FALSE);	// Will destroy main window too..
		ASSERT(m_pMainWnd==NULL);	// (..you hope)
	} else if (m_pOpenDoc)
		delete m_pOpenDoc;

	// For some reason I have as yet to discover, the destructor for the
	// thread state doesn't get called, or else it gets called after the memory
	// leak check is done, so I delete this stuff to avoid annoying memory leak
	// warnings. Pee-yew.
	//
	_AFX_THREAD_STATE& state = *AfxGetThreadState();
	if (state.m_pToolTip != NULL) {
		state.m_pToolTip->DestroyWindow();
		delete state.m_pToolTip;
		state.m_pToolTip = NULL;
	}
	// free safety pool buffer
	if (state.m_pSafetyPoolBuffer != NULL) {
		free(state.m_pSafetyPoolBuffer);
		state.m_pSafetyPoolBuffer = NULL;
	}
}

//////////////////
// Test if I am pinned. Since some other viewer can change the pinned
// window at any time SetPinnedWindow(NULL), then SetPinnedWindow(hwnd),
// the only way to really tell if I am pinned is to call GetPinnedWindow.
//
BOOL CFileViewerApp::GetPinned()
{
	if (!m_ipSite)
		return FALSE;
	HWND hwnd;
	VERIFY(m_ipSite->GetPinnedWindow(&hwnd)==NOERROR);
	return hwnd && hwnd==m_pMainWnd->GetSafeHwnd();
}

//////////////////
// Pin/unpin myself. Can fail if some other window is pinned.
// (Only one pinned window allowed for the whole system.)
// Returns new pinned state.
//
BOOL CFileViewerApp::SetPinned(BOOL bPin)
{
	if (!m_ipSite)
		return FALSE;
	ASSERT(m_pfvsi);
	HWND hwnd;
	DWORD dwFlags = m_pfvsi->dwFlags;
	hwnd = bPin ? m_pMainWnd->GetSafeHwnd() : NULL;
	TRACE("[setting pinned window=0x%04x]\n", hwnd);
	if (m_ipSite->SetPinnedWindow(hwnd)!=NOERROR) {
		TRACE0("[***failed]\n");
	}
	return GetPinned();
}

//////////////////
// Handle Pin command (View Replace Window).
// Put this function in your message map to support pinning.
//
void CFileViewerApp::OnPinWindow()
{
	SetPinned(!GetPinned());
}

//////////////////
// Set state of Replace Window menu item/button
// Put this function in your message map manage pin button state.
//
void CFileViewerApp::OnUpdatePinWindow(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_ipSite != NULL);
	pCmdUI->SetCheck(GetPinned());
}

/////////////////
// Handle File Open command: Open file for editing.
// Launches app assocated w/file name.
//
void CFileViewerApp::OnFileOpen() 
{
	CString sFileName = OnGetFileName();
	if (ShellExecute(m_pMainWnd->GetSafeHwnd(), NULL,
		(LPCSTR)sFileName, NULL, NULL, SW_NORMAL) <= (HINSTANCE)32) {
		char buf[_MAX_PATH + 128];
		sprintf(buf, "Error executing %s",(LPCSTR)sFileName);
		m_pMainWnd->MessageBox(buf);
	}
}

//////////////////
// Helper to change the icon in the "Open" button to the file's
// associated program icon, if any. Assumes open button is the first one
// in the toolbar bitmap.
//
void CFileViewerApp::SetOpenButtonIcon()
{
	CFVFrameWnd* pFrame = (CFVFrameWnd*)m_pMainWnd;
	ASSERT(pFrame);
	ASSERT_KINDOF(CFVFrameWnd, pFrame);
	pFrame->OnSetOpenButtonIcon();
}