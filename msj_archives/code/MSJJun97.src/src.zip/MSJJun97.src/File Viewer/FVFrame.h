////////////////////////////////////////////////////////////////
// 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "FVApp.h"

//////////////////
// File viewer frame window. Derive your main frame from this.
//
class CFVFrameWnd : public CFrameWnd {
public:
	CFVFrameWnd();
	virtual ~CFVFrameWnd();

	// New virtual functions
	virtual void OnSetOpenButtonIcon();

protected:
	DECLARE_DYNAMIC(CFVFrameWnd)
	CFileViewerApp*	m_pApp;			// ptr to app
	UINT					m_uIDToolBar;	// ID of toolbar (0=none)

	// MFC overrides
	afx_msg void OnClose();
	afx_msg void OnDestroy();
	afx_msg void OnDropFiles(HDROP hDropInfo);
	DECLARE_MESSAGE_MAP()
};

