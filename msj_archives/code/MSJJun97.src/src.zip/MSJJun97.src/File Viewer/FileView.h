////////////////////////////////////////////////////////////////
// 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// See FileView.cpp.
// 
#ifndef FILEVIEW_H
#define FILEVIEW_H

class CFileViewerApp; // fwd ref

//////////////////
// This class implements the IFileViewer interface.
//
class CFileViewer : public CCmdTarget {
protected:
	DECLARE_DYNCREATE(CFileViewer)
	DECLARE_OLECREATE(CFileViewer)
	DECLARE_INTERFACE_MAP()
	CFileViewerApp* m_pApp;			// ptr to one-and-only application object

	// state machine state
	enum { Dead=0, Loaded, ShowInit, Show } m_state;

public:
	CFileViewer();
	virtual ~CFileViewer();
	virtual void OnFinalRelease();

	// IFileViewer methods
	BEGIN_INTERFACE_PART(FileViewer, IFileViewer)
   STDMETHODIMP ShowInitialize( LPFILEVIEWERSITE ipSite);
   STDMETHODIMP Show( LPFVSHOWINFO pvsi);
   STDMETHODIMP PrintTo( LPSTR pszDriver, BOOL fSuppressUI);
	END_INTERFACE_PART(FileViewer)

	// IPersistFile methods
	BEGIN_INTERFACE_PART(PersistFile, IPersistFile)
	STDMETHODIMP GetClassID(LPCLSID pClsID);
	STDMETHODIMP IsDirty(void);
	STDMETHODIMP Load(LPCOLESTR, DWORD);
	STDMETHODIMP Save(LPCOLESTR, BOOL);
	STDMETHODIMP SaveCompleted(LPCOLESTR);
	STDMETHODIMP GetCurFile(LPOLESTR *);
	END_INTERFACE_PART(PersistFile)
};

#endif
