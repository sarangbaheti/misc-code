#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxole.h>         // MFC OLE classes
#include <afxdisp.h>        // MFC OLE automation classes
#include <afxpriv.h>        // For Unicode conversion macros
#include <afxcmn.h>         // For tooltip control
#include <shlobj.h>			 // for IFileViewer
#include <vfw.h>				 // for DrawDib

