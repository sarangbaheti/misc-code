////////////////////////////////////////////////////////////////
// 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#ifndef _FVAPP_H
#define _FVAPP_H

#include "FileView.h"

//////////////////
// File viewer application.
// Derive your app from this and override special virtual functions.
//
class CFileViewerApp : public CWinApp {
	friend CFileViewer;
	friend CFileViewer::XFileViewer;
	friend CFileViewer::XPersistFile;

protected:
	CFileViewer*		m_pfv;			// ptr to CFileViewer
	LPFILEVIEWERSITE	m_ipSite;		// viewer site, to talk to QuickView
	HRESULT				m_hr;				// used to return errrors
	LPFVSHOWINFO		m_pfvsi;			// show info
	CDocument*			m_pOpenDoc;		// current open doc (loaded)

public:
	DECLARE_DYNAMIC(CFileViewerApp)
	CFileViewerApp();
	~CFileViewerApp();

	// Helpers
	BOOL SetPinned(BOOL bPinned);		// Pin/unpin myself
	BOOL GetPinned();						// get pinned state
	void SetOpenButtonIcon();			// set toolbar open button

	// Standard MFC overrides
	virtual CDocument* OpenDocumentFile(LPCTSTR lpszFileName);
	virtual BOOL InitInstance();
	virtual int  ExitInstance();
	virtual void OnFileOpen();
	virtual int  Run();

	// New file viewer functions. Override to implement specific viewers.
	virtual BOOL			 OnLoad(LPCOLESTR lpFileName, DWORD grfMode);
	virtual BOOL			 OnShowInitialize();
	virtual BOOL			 OnShow(LPFVSHOWINFO pfvsi);
	virtual BOOL			 OnPrintTo(LPSTR pszDriver, BOOL fSuppressUI);
	virtual void			 OnFinalReleaseFV();
	virtual CString		 OnGetFileName();
	virtual CDocTemplate* CanOpenDocument(LPCTSTR lpszPath);

	// Command handlers you can use
	afx_msg void OnPinWindow();
	afx_msg void OnUpdatePinWindow(CCmdUI* pCmdUI);
};

// Helper to allocate bytes using current IMalloc
//
extern HRESULT MfxOleAlloc(ULONG cb, LPVOID* ppv);

#endif // _FVAPP_H
