template <class Base>
class CComObjectNoLock : public Base {
public:
	typedef Base _BaseClass;
	CComObjectNoLock(void* = NULL){}
	~CComObjectNoLock() {m_dwRef = 1L; FinalRelease();}

	STDMETHOD_(ULONG, AddRef)() {return InternalAddRef();}
	STDMETHOD_(ULONG, Release)() {
		ULONG l = InternalRelease();
		if (l == 0)
			delete this;
		return l;
	}
	STDMETHOD(QueryInterface)(REFIID iid, void ** ppvObject)
	{return _InternalQueryInterface(iid, ppvObject);}
};

template <class Base>
class CComObject : public Base {
public:
	typedef Base _BaseClass;
	CComObject(void* = NULL) { _Module.Lock(); }
	~CComObject() {	m_dwRef = 1L; FinalRelease(); _Module.Unlock();	}

	STDMETHOD_(ULONG, AddRef)() {return InternalAddRef();}
	STDMETHOD_(ULONG, Release)() {
		ULONG l = InternalRelease();
		if (l == 0)
			delete this;
		return l;
	}
	STDMETHOD(QueryInterface)(REFIID iid, void ** ppvObject)
	{return _InternalQueryInterface(iid, ppvObject);}
	static HRESULT WINAPI CreateInstance(CComObject<Base>** pp);
};
