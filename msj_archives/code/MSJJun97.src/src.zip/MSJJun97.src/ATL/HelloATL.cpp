////////////////////////////////////////////////////
//
// HelloATL.cpp - Copyright 1997, Don Box
//
// An ATL-based implementation of a COM in-process server
//

#include <windows.h>
#include "hello.h"
#define IID_DEFINED
#include "hello_i.c"

#include <atlbase.h>
extern CComModule _Module;
#include <atlcom.h>
#include <atlimpl.cpp>

class ATL_NO_VTABLE CHelloATL 
    :   public CComObjectRootEx<CComMultiThreadModel>,
        public CComCoClass<CHelloATL, &CLSID_HelloATL>,
        public IHello
{
public:
BEGIN_COM_MAP(CHelloATL)
    COM_INTERFACE_ENTRY(IHello)
END_COM_MAP()

    DECLARE_REGISTRY_RESOURCEID(1)

    STDMETHODIMP Hello(BSTR bstr)
    {
        MessageBoxW(0, bstr ? bstr : OLESTR(""), L"Hello!", MB_SETFOREGROUND);
        return S_OK;
    }
};

CComModule _Module;

BEGIN_OBJECT_MAP(ObjectMap)
    OBJECT_ENTRY(CLSID_HelloATL, CHelloATL)
END_OBJECT_MAP()

BOOL WINAPI DllMain(HINSTANCE h, DWORD dwReason, void *)
{
    if (dwReason == DLL_PROCESS_ATTACH)
        _Module.Init(ObjectMap, h);
    else if (dwReason == DLL_PROCESS_DETACH)
        _Module.Term();
    return TRUE;
}

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, void **ppv)
{ return _Module.GetClassObject(rclsid, riid, ppv); }

STDAPI DllCanUnloadNow(void)
{ return _Module.GetLockCount() ? S_FALSE : S_OK; }

STDAPI DllRegisterServer(void)
{ return _Module.RegisterServer(TRUE); }

STDAPI DllUnregisterServer(void)
{ return _Module.UnregisterServer(); }
