class CComObjectRootBase {
public:
// C++ constuctor
  CComObjectRootBase() { m_dwRef = 0L; }

// ATL psuedo-constructor and and psuedo-destructors
  HRESULT FinalConstruct() { return S_OK; } 
  void FinalRelease() {}

// Inner Unknown function (InternalAddRef/Release supplied by derived class)
  static HRESULT WINAPI InternalQueryInterface(void* pThis, 
            const _ATL_INTMAP_ENTRY* pEntries, REFIID iid, void** ppvObject) {
    HRESULT hRes = AtlInternalQueryInterface(pThis,pEntries,iid,ppvObject);
    return _ATLDUMPIID(iid, pszClassName, hRes);
  }

// Outer Unknown functions
  ULONG OuterAddRef()	 { return m_pOuterUnknown->AddRef(); }
  ULONG OuterRelease() { return m_pOuterUnknown->Release(); }
  HRESULT OuterQueryInterface(REFIID iid, void ** ppvObject) 
  { return m_pOuterUnknown->QueryInterface(iid, ppvObject); }

// ATL creator hook routines
  void SetVoid(void*) {}
  void InternalFinalConstructAddRef() {}
  void InternalFinalConstructRelease() {}

// ATL interface map helper functions
  static HRESULT WINAPI _Break(       void*, REFIID, void**, DWORD);
  static HRESULT WINAPI _NoInterface( void*, REFIID, void**, DWORD);
  static HRESULT WINAPI _Creator(     void*, REFIID, void**, DWORD);
  static HRESULT WINAPI _Delegate(    void*, REFIID, void**, DWORD);
  static HRESULT WINAPI _Chain(       void*, REFIID, void**, DWORD);
  static HRESULT WINAPI _Cache(       void*, REFIID, void**, DWORD);

// The actual reference count OR the back pointer to the real Unknown
  union {
    long m_dwRef;
    IUnknown* m_pOuterUnknown;
  };
};

template <class ThreadModel>
class CComObjectRootEx : public CComObjectRootBase {
public:
  typedef ThreadModel _ThreadModel;
  typedef _ThreadModel::AutoCriticalSection _CritSec;

// Inner Unknown function (InternalQueryInterface supplied by CComObjectRootBase)
  ULONG InternalAddRef()  { return _ThreadModel::Increment(&m_dwRef); }
  ULONG InternalRelease()	{ return _ThreadModel::Decrement(&m_dwRef); }

// Object-level lock operations
  void Lock() {m_critsec.Lock();}
  void Unlock() {m_critsec.Unlock();}
private:
  _CritSec m_critsec;
};
