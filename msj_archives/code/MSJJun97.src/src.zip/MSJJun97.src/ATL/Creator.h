template <class T1> class CComCreator {
public:
    static HRESULT WINAPI CreateInstance(void* pv, REFIID riid, LPVOID* ppv) {
		HRESULT hRes = E_OUTOFMEMORY;
		T1* p = NULL;
		ATLTRY(p = new T1(pv))
		if (p != NULL) {
			p->SetVoid(pv);
			p->InternalFinalConstructAddRef();
			hRes = p->FinalConstruct();
			p->InternalFinalConstructRelease();
			if (hRes == S_OK)
				hRes = p->QueryInterface(riid, ppv);
			if (hRes != S_OK)
				delete p;
		}
		return hRes;
	}
};

template <HRESULT hr> class CComFailCreator {
public:
	static HRESULT WINAPI CreateInstance(void*, REFIID, LPVOID*)
    { return hr; }
};

template <class T1, class T2> class CComCreator2 {
public:
	static HRESULT WINAPI CreateInstance(void* pv, REFIID riid, LPVOID* ppv) {
		HRESULT hRes = E_OUTOFMEMORY;
		if (pv == NULL)
			hRes = T1::CreateInstance(NULL, riid, ppv);
		else
			hRes = T2::CreateInstance(pv, riid, ppv);
		return hRes;
	}
};
