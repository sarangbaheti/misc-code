template <class T>
class CComPtr {
public:
	typedef T _PtrClass;
	CComPtr() {p=NULL;}
	CComPtr(T* lp) {
		if ((p = lp) != NULL)
			p->AddRef();
	}
	CComPtr(const CComPtr<T>& lp) {
		if ((p = lp.p) != NULL)
			p->AddRef();
	}
	~CComPtr() {if (p) p->Release();}
	void Release() {if (p) p->Release(); p=NULL;}
	operator T*() {return (T*)p;}
	T& operator*() {_ASSERTE(p!=NULL); return *p; }
	T** operator&() { _ASSERTE(p==NULL); return &p; }
	T* operator->() { _ASSERTE(p!=NULL); return p; }
	T* operator=(T* lp){return (T*)AtlComPtrAssign((IUnknown**)&p, lp);}
	T* operator=(const CComPtr<T>& lp) {
		return (T*)AtlComPtrAssign((IUnknown**)&p, lp.p);
	}
	bool operator!(){return (p == NULL);}
	T* p;
};

template <class T, const IID* piid>
class CComQIPtr
{
public:
	typedef T _PtrClass;
	CComQIPtr() {p=NULL;}
    CComQIPtr(T* lp) {
		if ((p = lp) != NULL)
			p->AddRef();
	}
	CComQIPtr(const CComQIPtr<T,piid>& lp) {
		if ((p = lp.p) != NULL)
			p->AddRef();
	}
	CComQIPtr(IUnknown* lp)	{
		p=NULL;
		if (lp != NULL)
			lp->QueryInterface(*piid, (void **)&p);
	}
	~CComQIPtr() {if (p) p->Release();}
	void Release() {if (p) p->Release(); p=NULL;}
	operator T*() {return p;}
	T& operator*() {_ASSERTE(p!=NULL); return *p; }
	T** operator&() { _ASSERTE(p==NULL); return &p; }
	T* operator->() {_ASSERTE(p!=NULL); return p; }
	T* operator=(T* lp){return (T*)AtlComPtrAssign((IUnknown**)&p, lp);}
    T* operator=(const CComQIPtr<T,piid>& lp) {
		return (T*)AtlComPtrAssign((IUnknown**)&p, lp.p);
	}
	T* operator=(IUnknown* lp) {
		return (T*)AtlComQIPtrAssign((IUnknown**)&p, lp, *piid);
	}
	bool operator!(){return (p == NULL);}
	T* p;
};
