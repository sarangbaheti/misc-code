Readme for October '98 Bugslayer Code:

If you have any questions (or debugging tips -- keep'em rollin' in!)
send me a note through www.jprobbins.com.

If you have not read my October '98 column, I strongly encourage you to
read the column first before playing with this code.  This is a fairly
complicated utility and without the column explaination, it might not
make much sense.

Directories:

.\BugslayerUtil         - The common code library for all Bugslayer
                          columns.
.\BugslayerUtil\Tests   - Unit test for BugslayerUtil code.
.\Include               - The include directory for all shared headers.
.\DeadlockDetection     - The DeadlockDetection DLL.
.\Death                 - An application that deadlocks.
.\mtgdi                 - Test code for DeadlockDetection.
.\Mutexes               - Test code for DeadlockDetection.
.\Output                - The location for all _DEBUG build binaries.
.\Release               - The location for all _RELEASE build binaries.
.\SimpTest              - Test code for DeadlockDetection.
.\TextFileDDExt         - The DeadlockDetection Extension DLL for
                          logging to text files.

Building The DeadlockDetection System:
0.  Build the BugslayerUtil.DLL with the supplied VC5 project using the
    "Win32 Debug Using Static RTL" and "Win32 Release Using Static RTL"
    configurations. (.\BugslayerUtil\BuglslayerUtil.dsw)
1.  Build the DeadlockDetection.DLL with the supplied VC5 project using
    then "Win32 Debug" and "Win32 Release" configurations.
    (.\DeadlockDetection\DeadlockDetection.dsw)
2. Build the TextFileDDExt with with the supplied VC5 project using
   the "Win32 Debug" and "Win32 Release" configurations.
   (.\TextFileDDExt\TextFileDDExt.dsw)

Building the Test Programs:
0.  Build BOUNCE.EXE with the Debug.bat and Release.bat batch files.
    (.\Bounce)
1.  Build DEATH.EXE with the Debug.bat and Release.bat batch files.
    (.\Death)
2.  Build MTGDI.EXE with the supplied VC5 project using the "Win32
    Debug" and "Win32 Release" configurations.
    (.\MTGDI)
3.  Build MUTEXES.EXE with the supplied VC5 project using the "Win32
    Debug" and "Win32 Release" configurations.
    (.\MUTEXES)
4.  Build SIMPTEST.EXE with the Debug.bat and Release.bat batch files.
    (.\SimpTest)

Happy Deadlock Detecting,

John Robbins.


