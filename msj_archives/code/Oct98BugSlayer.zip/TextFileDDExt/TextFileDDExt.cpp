/*----------------------------------------------------------------------
   John Robbins - Oct '98 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
The File Logging Deadlock Detection Extension DLL.
----------------------------------------------------------------------*/
#include "PCH.h"
#include "DeadlockDetection.h"
#include "ParamDecode.h"

/*//////////////////////////////////////////////////////////////////////
                    Type Definitions and Prototypes
//////////////////////////////////////////////////////////////////////*/
// The definition for all parameter output functions.
typedef int (*PFNOUTPUTFUNC)( LPTSTR    szBuff   ,
                              DWORD     dwParams  ) ;

// The array of output items.
typedef struct tagOutputData
{
    LPCTSTR         szName ;
    PFNOUTPUTFUNC   pProc  ;
} OUTPUTDATA , *LPOUTPUTDATA ;

// The output items for each function enum.  Keep this in the same order
//  as the eFuncEnum list in DeadlockDetection.h.
OUTPUTDATA g_stOutData [ ] =
{
    { _T ( "**UNINITIALIZED FUNCTION ENUM!**" ) , NULL } ,
// Special functions that are always reported.
    { _T ( "ExitProcess" ) ,
      Trans_ExitProcessParams
    } ,
// Waiting and special functions that are always reported.
    { _T ( "WaitForSingleObject" ) ,
      Trans_WaitForSingleObjectParams
    } ,
    { _T ( "WaitForSingleObjectEx" ) ,
      Trans_WaitForSingleObjectExParams
    } ,
    { _T ( "WaitForMultipleObjects" ) ,
      Trans_WaitForMultipleObjectsParams
    } ,
    { _T ( "WaitForMultipleObjectsEx" ) ,
      Trans_WaitForMultipleObjectsExParams
    } ,
    { _T ( "MsgWaitForMultipleObjects" ) ,
      Trans_MsgWaitForMultipleObjectsParams
    } ,
    { _T ( "MsgWaitForMultipleObjectsEx" ) ,
      Trans_MsgWaitForMultipleObjectsExParams
    } ,
    { _T ( "SignalObjectAndWait" ) ,
      Trans_SignalObjectAndWaitParams
    } ,
    { _T ( "CloseHandle" ) ,
      Trans_CloseHandleParams
    } ,
    { _T ( "GetProcAddress" ) ,
      Trans_GetProcAddressParams
    } ,
// Thread specific functions.
    { _T ( "CreateThread" ) ,
      Trans_CreateThreadParams
    } ,
    { _T ( "ExitThread" ) ,
      Trans_ExitThreadParams
    } ,
    { _T ( "SuspendThread" ) ,
      Trans_SuspendThreadParams
    } ,
    { _T ( "ResumeThread" ) ,
      Trans_ResumeThreadParams
    } ,
    { _T ( "TerminateThread" ) ,
      Trans_TerminateThreadParams
    } ,
// CriticalSection functions.
    { _T ( "InitializeCriticalSection" ) ,
      Trans_InitializeCriticalSectionParams
    } ,
    { _T ( "InitializeCriticalSectionAndSpinCount" ) ,
      Trans_InitializeCriticalSectionAndSpinCountParams
    } ,
    { _T ( "DeleteCriticalSection" ) ,
      Trans_DeleteCriticalSectionParams
    } ,
    { _T ( "EnterCriticalSection" ) ,
      Trans_EnterCriticalSectionParams
    } ,
    { _T ( "LeaveCriticalSection" ) ,
      Trans_LeaveCriticalSectionParams
    } ,
    { _T ( "SetCriticalSectionSpinCount" ) ,
      Trans_SetCriticalSectionSpinCountParams
    } ,
    { _T ( "TryEnterCriticalSection" ) ,
      Trans_TryEnterCriticalSectionParams
    } ,
// Mutex functions.
    { _T ( "CreateMutexA" ) ,
      Trans_CreateMutexAParams
    } ,
    { _T ( "CreateMutexW" ) ,
      Trans_CreateMutexWParams
    } ,
    { _T ( "OpenMutexA" ) ,
      Trans_OpenMutexAParams
    } ,
    { _T ( "OpenMutexW" ) ,
      Trans_OpenMutexWParams
    } ,
    { _T ( "ReleaseMutex" ) ,
      Trans_ReleaseMutexParams
    } ,
// Semaphore functions.
    { _T ( "CreateSemaphoreA" ) ,
      Trans_CreateSemaphoreAParams
    } ,
    { _T ( "CreateSemaphoreW" ) ,
      Trans_CreateSemaphoreWParams
    } ,
    { _T ( "OpenSemaphoreA" ) ,
      Trans_OpenSemaphoreAParams
    } ,
    { _T ( "OpenSemaphoreW" ) ,
      Trans_OpenSemaphoreWParams
    } ,
    { _T ( "ReleaseSemaphore" ) ,
      Trans_ReleaseSemaphoreParams
    } ,
// Event functions.
    { _T ( "CreateEventA" ) ,
      Trans_CreateEventAParams
    } ,
    { _T ( "CreateEventW" ) ,
      Trans_CreateEventWParams
    } ,
    { _T ( "OpenEventA" ) ,
      Trans_OpenEventAParams
    } ,
    { _T ( "OpenEventW" ) ,
      Trans_OpenEventWParams
    } ,
    { _T ( "PulseEvent" ) ,
      Trans_PulseEventParams
    } ,
    { _T ( "ResetEvent" ) ,
      Trans_ResetEventParams
    } ,
    { _T ( "SetEvent" ) ,
      Trans_SetEventParams
    } ,
} ;


/*//////////////////////////////////////////////////////////////////////
                          Function Prototypes
//////////////////////////////////////////////////////////////////////*/
LPCTSTR ConvertFuncEnumToString ( eFuncEnum eFunc ) ;
LPCTSTR ConvertPrePostToString ( ePrePostEnum ePrePost ) ;

FILE * g_pFile = NULL ;
TCHAR g_szBuff[ MAX_PATH ] ;

BOOL WINAPI DeadDetProcessEvent ( const LPDDEVENTINFO pEvtInfo )
{


    // Double check that the file has not been closed on us.
    if ( NULL == g_pFile )
    {
        return ( FALSE ) ;
    }
    int iCurr = 0 ;

    // Put in the thread ID, the return address and if this is a pre or
    //  post function call.
    iCurr += wsprintf ( g_szBuff + iCurr        ,
                        _T ( "0x%08X [0x%08X] %s" ) ,
                        pEvtInfo->dwThreadId    ,
                        pEvtInfo->dwAddr        ,
                        ConvertPrePostToString ( pEvtInfo->ePrePost ) );

    // If this is post call, then put in the returned value.
    if ( ePostCall == pEvtInfo->ePrePost )
    {
        iCurr += wsprintf ( g_szBuff + iCurr     ,
                            _T ( " 0x%08X" )     ,
                            pEvtInfo->dwRetValue  ) ;
    }
    else
    {
        iCurr += wsprintf ( g_szBuff + iCurr      ,
                            _T ( "           " )  ) ;

    }

    // Slap in the function name.
    if ( pEvtInfo->eFunc >= eMAXFUNCTIONENUM )
    {
        iCurr += wsprintf ( g_szBuff + iCurr ,
                            _T ( "**OUT OF RANGE FUNC ENUM*** " ) ) ;
    }
    else
    {
        iCurr += wsprintf ( g_szBuff + iCurr  ,
                            _T ( " %s " )     ,
                            g_stOutData[ pEvtInfo->eFunc ].szName ) ;
    }

    // Call the decoding function for the parameters.
    if ( NULL != g_stOutData[ pEvtInfo->eFunc ].pProc )
    {
        iCurr +=
            g_stOutData[pEvtInfo->eFunc].pProc( g_szBuff + iCurr   ,
                                                pEvtInfo->dwParams  ) ;
    }

    // Put on the CR/LF on the end.
    lstrcpy ( g_szBuff + iCurr , _T ( "\n" ) ) ;

    // Write it out to the file.
    _fputts ( g_szBuff , g_pFile ) ;

    // If this is any kind of wait function, flush the file in case
    //  this is the one call that deadlocks.
    switch ( pEvtInfo->eFunc )
    {
        case eWaitForSingleObject         :
        case eWaitForSingleObjectEx       :
        case eWaitForMultipleObjects      :
        case eWaitForMultipleObjectsEx    :
        case eMsgWaitForMultipleObjects   :
        case eMsgWaitForMultipleObjectsEx :
        case eSignalObjectAndWait         :
        case eEnterCriticalSection        :
        case eTryEnterCriticalSection     :
            fflush ( g_pFile ) ;
            break ;
        default :
            break ;
    }

    return ( TRUE ) ;
}

////////////////////////////////////////////////////////////////////////
//                        Necessary Functions
////////////////////////////////////////////////////////////////////////
extern "C" BOOL WINAPI DllMain ( HINSTANCE hInst       ,
                                 DWORD     dwReason    ,
                                 LPVOID    /*lpReserved*/ )
{
    BOOL bRet = TRUE ;
    switch ( dwReason )
    {
        case DLL_PROCESS_ATTACH :
            DisableThreadLibraryCalls ( hInst ) ;
            break ;
        case DLL_PROCESS_DETACH :
            DeadDetExtClose ( ) ;
            break ;
        default                 :
            break ;
    }
    return ( bRet ) ;
}

BOOL WINAPI DeadDetExtOpen ( void )
{
    if ( NULL != g_pFile )
    {
        return ( FALSE ) ;
    }
    // Create the file in the same directory as the EXE.
    TCHAR szFile [ MAX_PATH ] ;
    GetModuleFileName ( NULL , szFile , MAX_PATH ) ;

    LPTSTR szPeriod = _tcsrchr ( szFile , _T ( '.' ) ) ;
    if ( NULL != szPeriod )
    {
        szPeriod++ ;
        *szPeriod = _T ( '\0' ) ;
        strcpy ( szPeriod , _T ( "DD" ) ) ;

        g_pFile = _tfopen ( szFile , _T ( "w" ) ) ;

        if  ( NULL != g_pFile )
        {

            // Put in the header for the file.
            _fputts (
    _T ( "TID        Ret Addr     C/R Ret Value  Function & Params\n" ) ,
                     g_pFile ) ;
        }
    }

    return ( TRUE ) ;
}

void WINAPI DeadDetExtClose ( void )
{
    if ( NULL != g_pFile )
    {
        fclose ( g_pFile ) ;
    }
        g_pFile = NULL ;
}

LPCTSTR ConvertFuncEnumToString ( eFuncEnum eFunc )
{
    if ( eFunc >= eMAXFUNCTIONENUM )
    {
        return ( _T ( "**OUT OF RANGE FUNC ENUM***" ) ) ;
    }
    return ( g_stOutData[ eFunc ].szName ) ;
}

static LPCSTR g_szPrePostString [ ] =
{
    _T ( "** UNINITIALIZED PRE POST" ) ,
    _T ( "(C)" ) ,
    _T ( "(R)" ) ,
} ;

LPCTSTR ConvertPrePostToString ( ePrePostEnum ePrePost )
{
    if ( ePrePost >= eMAXPREPOSTENUM )
    {
        return ( _T ( "***OUT OF RANCE PREPOST ENUM***" ) ) ;
    }
    return ( g_szPrePostString [ ePrePost ] ) ;
}


