#include <windows.h>
#include <stdio.h>
#include "DeadlockDetection.h"

#define EVT_NAME "The Event Name"

CRITICAL_SECTION g_stCS ;

DWORD HappyGoLuckyThread ( DWORD )
{
    printf ("I'm HappyGoLuckyThread and I would like the CS please!\n");
    EnterCriticalSection ( &g_stCS ) ;
    printf ( "HappyGoLuckyThread has the CS, waiting on the event\n" ) ;
    HANDLE hEvent = OpenEvent ( EVENT_ALL_ACCESS , FALSE , EVT_NAME ) ;
    WaitForSingleObject ( hEvent , INFINITE ) ;
    CloseHandle ( hEvent ) ;
    LeaveCriticalSection (  &g_stCS ) ;
    return  ( 1 ) ;
}

DWORD GrumpyThread ( DWORD )
{
    printf ("I'm GrumpyThread opening the event, NOW!\n");
    HANDLE hEvent = OpenEvent ( EVENT_ALL_ACCESS , FALSE , EVT_NAME ) ;
    printf ( "GrumpyThread give me the CS, NOW!\n" ) ;
    EnterCriticalSection ( &g_stCS ) ;
    SetEvent ( hEvent ) ;
    CloseHandle ( hEvent ) ;
    LeaveCriticalSection (  &g_stCS ) ;
    return  ( 1 ) ;
}

void main ( void )
{
    HANDLE hEvent ;
    DWORD dwThreadId ;

    OpenDeadlockDetection ( DDOPT_ALL ) ;

    InitializeCriticalSection ( &g_stCS ) ;
    hEvent = CreateEvent ( NULL , TRUE , FALSE , EVT_NAME ) ;


    HANDLE hThread1 = CreateThread ( NULL ,
                                    0    ,
                             (LPTHREAD_START_ROUTINE)HappyGoLuckyThread,
                                    (LPVOID)0  ,
                                    0    ,
                                    &dwThreadId ) ;

    HANDLE hThread2 = CreateThread ( NULL ,
                                    0    ,
                                   (LPTHREAD_START_ROUTINE)GrumpyThread,
                                    (LPVOID)0  ,
                                    0    ,
                                    &dwThreadId ) ;

    EnterCriticalSection ( &g_stCS ) ;
    WaitForSingleObject ( hEvent , INFINITE ) ;
    LeaveCriticalSection ( &g_stCS ) ;
    CloseHandle ( hEvent ) ;
    CloseHandle ( hThread1 ) ;
    CloseHandle ( hThread2 ) ;
}
