#include <windows.h>
#include <tchar.h>
#include "DeadlockDetection.h"

CRITICAL_SECTION g_stCS ;
CRITICAL_SECTION g_stCSTwo ;

void CriticalSectionTests ( )
{
    InitializeCriticalSection ( &g_stCS ) ;

    EnterCriticalSection ( &g_stCS ) ;

    LeaveCriticalSection ( &g_stCS ) ;

    DeleteCriticalSection ( &g_stCS ) ;

    typedef BOOL (WINAPI *PFNINITCRITSECANDSPINCOUNT) (
                                   LPCRITICAL_SECTION lpCriticalSection,
                                   DWORD              dwSpinCount     );

    PFNINITCRITSECANDSPINCOUNT pfnICSASP = NULL ;
    pfnICSASP = (PFNINITCRITSECANDSPINCOUNT)
        GetProcAddress(GetModuleHandle ( "kernel32.dll"  ) ,
                       "InitializeCriticalSectionAndSpinCount");
    if ( NULL != pfnICSASP )
    {
        pfnICSASP ( &g_stCSTwo , 400 ) ;
    }

    typedef BOOL (WINAPI *PFNSETCRITSECSPINCOUNT) (
                                   LPCRITICAL_SECTION lpCriticalSection,
                                   DWORD dwSpinCount ) ;

    PFNSETCRITSECSPINCOUNT pfnSCSSP = NULL ;
    pfnSCSSP = (PFNSETCRITSECSPINCOUNT)
        GetProcAddress ( GetModuleHandle ( _T ( "kernel32.dll" ) ) ,
                         _T ( "SetCriticalSectionSpinCount" )     );
    if ( NULL != pfnSCSSP )
    {
        pfnSCSSP ( &g_stCSTwo , 0x800 );
    }
    typedef BOOL (WINAPI *PFNTRYENTERCRITSEC)
                              ( LPCRITICAL_SECTION lpCriticalSection ) ;

    PFNTRYENTERCRITSEC pfnTECS = NULL ;
    pfnTECS = (PFNTRYENTERCRITSEC)
        GetProcAddress ( GetModuleHandle ( _T ( "kernel32.dll" ) ) ,
                         _T ( "TryEnterCriticalSection" )         );
    if ( NULL != pfnTECS )
    {
        pfnTECS ( &g_stCSTwo ) ;
    }

}

void EventTests ( void )
{
    HANDLE hRet ;
    HANDLE hDup ;

    hRet = CreateEvent ( NULL , TRUE , FALSE , "Manual rest event" ) ;
    SetEvent ( hRet ) ;
    ResetEvent ( hRet ) ;
    hDup = OpenEvent ( EVENT_ALL_ACCESS ,
                       FALSE            ,
                       "Manual rest event" );

    // Wide Version.
    hRet = CreateEventW ( NULL , TRUE , FALSE , L"Wide Char event" ) ;
    PulseEvent ( hRet ) ;
    hDup = OpenEventW ( EVENT_ALL_ACCESS , FALSE , L"Wide Char event" );
}

void MutexTests ( void )
{
    HANDLE hRet ;
    HANDLE hDup ;

    hRet = CreateMutex ( NULL , TRUE , "ANSI Mutex String" ) ;
    hDup = OpenMutex ( MUTEX_ALL_ACCESS , FALSE , "ANSI Mutex String" );
    ReleaseMutex ( hRet ) ;
    ReleaseMutex ( hDup ) ;

    hRet = CreateMutexW ( NULL , TRUE , L"Wide Mutex String" ) ;
    hDup = OpenMutexW ( MUTEX_ALL_ACCESS    , FALSE , L"Wide Mutex String");
    ReleaseMutex ( hRet ) ;
    ReleaseMutex ( hDup ) ;
}

void SemaphoreTests ( void )
{
    HANDLE hRet ;
    hRet = CreateSemaphore ( NULL , 1 , 1 , "FooSemaphore" ) ;

    HANDLE hRet2 = OpenSemaphore ( SEMAPHORE_ALL_ACCESS ,
                                   FALSE                ,
                                   "Non existant semaphore!" ) ;

    hRet = CreateSemaphoreW ( NULL , 1 , 1 , L"Wide Semaphore" ) ;

    hRet2 = OpenSemaphoreW ( SEMAPHORE_ALL_ACCESS ,
                             FALSE                ,
                             L"Wide Nonexistant" ) ;


    ReleaseSemaphore ( hRet , 1 , NULL ) ;
}

DWORD ThreadFunc ( DWORD dwSleepVal )
{
    Sleep ( dwSleepVal ) ;

    ExitThread ( 5 ) ;
    return ( 5 ) ;
}

void ThreadTests ( void )
{
    DWORD dwThreadId ;

    HANDLE hThread = CreateThread ( NULL ,
                                    0    ,
                                    (LPTHREAD_START_ROUTINE)ThreadFunc,
                                    (LPVOID)0  ,
                                    0    ,
                                    &dwThreadId ) ;

    hThread = CreateThread ( NULL ,
                             0    ,
                             (LPTHREAD_START_ROUTINE)ThreadFunc,
                             (LPVOID)0  ,
                             0    ,
                             &dwThreadId ) ;

    WaitForSingleObject ( hThread , INFINITE ) ;

    hThread = CreateThread ( NULL ,
                             0    ,
                             (LPTHREAD_START_ROUTINE)ThreadFunc,
                             (LPVOID)2000 ,
                             0    ,
                             &dwThreadId ) ;

    SuspendThread ( hThread ) ;
    ResumeThread ( hThread ) ;
    TerminateThread ( hThread , 10 ) ;
}

void WaitTests ( void )
{
    HANDLE hArray[ 2 ] ;

    hArray[0] = CreateEvent ( NULL  ,
                              TRUE  ,
                              FALSE ,
                              "Wait Tests Event Zero" ) ;
    hArray[1] = CreateEvent ( NULL  ,
                              TRUE  ,
                              TRUE  ,
                              "Wait Tests Event One" ) ;
    WaitForSingleObject ( hArray[1] , INFINITE ) ;
    WaitForSingleObjectEx ( hArray[1] , INFINITE , TRUE ) ;
    WaitForMultipleObjects ( 2 ,
                            (CONST HANDLE*)&hArray ,
                            FALSE ,
                            INFINITE ) ;
    WaitForMultipleObjectsEx ( 2 ,
                               (CONST HANDLE*)&hArray ,
                               FALSE ,
                               INFINITE ,
                               TRUE ) ;
}

int main ( void )
{
    BOOL bRet = OpenDeadlockDetection ( DDOPT_ALL ) ;

    DWORD dwOpts = GetDeadlockDetectionOptions ( ) ;

    SetDeadlockDetectionOptions ( DDOPT_SEMAPHORE ) ;
    OutputDebugString ( "Test 1  : Should not see any thing "
                        "between this line\n");
    // Since the options are only semaphores the first set should
    //  not be seen.
    CriticalSectionTests ( ) ;
    OutputDebugString ( "Test 1  : ...and this line from DD\n\n" ) ;

//////////////////////////////////////////////

    SetDeadlockDetectionOptions ( DDOPT_ALL ) ;
    OutputDebugString ( "Test 2  : Should see 9 crit sec calls "
                        "between this line...\n" ) ;

    CriticalSectionTests ( ) ;

    OutputDebugString ( "Test 2  : ...and this line\n\n" ) ;

//////////////////////////////////////////////

    OutputDebugString ( "Test 3  : Should see 7 event calls "
                        "between this line...\n" ) ;

    EventTests ( ) ;

    OutputDebugString ( "Test 3  : ...and this line\n\n" ) ;

//////////////////////////////////////////////
    OutputDebugString ( "Test 4  : Should see 8 mutex calls between "
                        " this line...\n" ) ;

    MutexTests ( ) ;

    OutputDebugString ( "Test 4  : ...and this line\n\n" ) ;

//////////////////////////////////////////////

    OutputDebugString ( "Test 5  : Should see 5 semaphore calls "
                        "between this line...\n" ) ;

    SemaphoreTests ( ) ;

    OutputDebugString ( "Test 5  : ...and this line\n\n" ) ;

//////////////////////////////////////////////

    OutputDebugString ( "Test 6  : Should see 8 thread related calls "
                        "between this line...\n" ) ;

    ThreadTests ( ) ;

    OutputDebugString ( "Test 6  : ...and this line\n\n" ) ;


//////////////////////////////////////////////
    OutputDebugString ( "Test 7  : Should see 6 wait related calls "
                        "between this line...\n" ) ;
    WaitTests ( ) ;

    OutputDebugString ( "Test 7  : ...and this line\n\n" ) ;

    HMODULE hMod = LoadLibrary ( "WINMM.DLL" ) ;
    FreeLibrary ( hMod ) ;
    LoadLibrary ( "CARDS.DLL" ) ;


    // No more output.
    SuspendDeadlockDetection ( ) ;
    return ( 3 ) ;
}
