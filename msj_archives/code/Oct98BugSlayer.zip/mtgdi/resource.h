//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by mtgdi.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDS_CAPTION_FORMAT              129
#define IDS_CAPTION_NOTHREADS           130
#define ID_THREAD_NEWBALL               32771
#define ID_THREAD_KILLTHREADS           32772
#define ID_THREAD_NEWRECTANGLE          32773
#define ID_THREAD_NEWLINE               32774
#define ID_THREAD_10NEWBALLS            32775
#define ID_THREAD_25NEWBALLS            32776
#define ID_THREAD_10NEWRECTANGLES       32777
#define ID_THREAD_25NEWRECTANGLES       32778
#define ID_THREAD_10NEWLINES            32779
#define ID_THREAD_25NEWLINES            32780
#define ID_THREAD_KILLTHREADSSLOW       32782

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32783
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
