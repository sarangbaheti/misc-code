/*----------------------------------------------------------------------
   John Robbins - Oct '98 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
The function tables.
----------------------------------------------------------------------*/
#include "pch.h"
#include "DeadlockDetection.h"
#include "BugslayerUtil.h"
#include "Internal.h"
#include "Tables.h"

////////////////////////////////////////////////////////////////////////
// KEEP THESE TABLES SORTED IN ALPHABETICAL ORDER!!!!
// KEEP THESE TABLES SORTED IN ALPHABETICAL ORDER!!!!
// KEEP THESE TABLES SORTED IN ALPHABETICAL ORDER!!!!
////////////////////////////////////////////////////////////////////////

// The tables for the mandatory functions to hook.
HOOKFUNCDESC g_stDDKernelFuncs[ NUMBER_KERNEL_FUNCS ] =
{
    {
        _T ( "CloseHandle" ) ,
        (PROC)DD_CloseHandle
    } ,
    {
        _T ( "CreateEventA" ) ,
        (PROC)DD_CreateEventA
    } ,
    {
        _T ( "CreateEventW" ) ,
        (PROC)DD_CreateEventW
    } ,
    {
        _T ( "CreateMutexA" ) ,
        (PROC)DD_CreateMutexA
    } ,
    {
        _T ( "CreateMutexW" ) ,
        (PROC)DD_CreateMutexW
    } ,
    {
        _T ( "CreateSemaphoreA" ) ,
        (PROC)DD_CreateSemaphoreA
    } ,
    {
        _T ( "CreateSemaphoreW" ) ,
        (PROC)DD_CreateSemaphoreW
    } ,
    {
        _T ( "CreateThread" ) ,
        (PROC)DD_CreateThread
    } ,
    {
        _T ( "DeleteCriticalSection" ),
        (PROC)DD_DeleteCriticalSection
    } ,
    {
        _T ( "EnterCriticalSection"  ),
        (PROC)DD_EnterCriticalSection
    } ,
    {
        _T ( "ExitProcess" )  ,
        (PROC)DD_ExitProcess
    } ,
    {
        _T ( "ExitThread" )   ,
        (PROC)DD_ExitThread
    } ,
    {
        _T ( "GetProcAddress" ) ,
        (PROC)DD_GetProcAddress
    } ,
    {
        _T ( "InitializeCriticalSection" ),
        (PROC)DD_InitializeCriticalSection
    } ,
    {
        _T ( "InitializeCriticalSectionAndSpinCount" ) ,
        (PROC)DD_InitializeCriticalSectionAndSpinCount
    } ,
    {
        _T ( "LeaveCriticalSection" ) ,
        (PROC)DD_LeaveCriticalSection
    } ,
    {
        _T ( "LoadLibraryA" ) ,
        (PROC)DD_LoadLibraryA
    } ,
    {
        _T ( "LoadLibraryExA" ) ,
        (PROC)DD_LoadLibraryExA
    } ,
    {
        _T ( "LoadLibraryExW" ) ,
        (PROC)DD_LoadLibraryExW
    } ,
    {
        _T ( "LoadLibraryW" ) ,
        (PROC)DD_LoadLibraryW
    } ,
    {
        _T ( "OpenEventA" ) ,
        (PROC)DD_OpenEventA
    } ,
    {
        _T ( "OpenEventW" ) ,
        (PROC)DD_OpenEventW
    } ,
    {
        _T ( "OpenMutexA" ) ,
        (PROC)DD_OpenMutexA
    } ,
    {
        _T ( "OpenMutexW" ) ,
        (PROC)DD_OpenMutexW
    } ,
    {
        _T ( "OpenSemaphoreA" ) ,
        (PROC)DD_OpenSemaphoreA
    } ,
    {
        _T ( "OpenSemaphoreW" ) ,
        (PROC)DD_OpenSemaphoreW
    } ,
    {
        _T ( "PulseEvent" ) ,
        (PROC)DD_PulseEvent
    } ,
    {
        _T ( "ReleaseMutex" ) ,
        (PROC)DD_ReleaseMutex
    } ,
    {
        _T ( "ReleaseSemaphore" ) ,
        (PROC)DD_ReleaseSemaphore
    } ,
    {
        _T ( "ResetEvent" ) ,
        (PROC)DD_ResetEvent
    } ,
    {
        _T ( "ResumeThread" ) ,
        (PROC)DD_ResumeThread
    } ,
    {
        _T ( "SetCriticalSectionSpinCount" ) ,
        (PROC)DD_SetCriticalSectionSpinCount
    } ,
    {
        _T ( "SetEvent" ) ,
        (PROC)DD_SetEvent
    } ,
    {
        _T ( "SignalObjectAndWait" ) ,
        (PROC)DD_SignalObjectAndWait
    } ,
    {
        _T ( "SuspendThread" ) ,
        (PROC)DD_SuspendThread
    } ,
    {
        _T ( "TerminateThread" ) ,
        (PROC)DD_TerminateThread
    } ,
    {
        _T ( "TryEnterCriticalSection" ) ,
        (PROC)DD_TryEnterCriticalSection
    } ,
    {
        _T ( "WaitForMultipleObjects" ) ,
        (PROC)DD_WaitForMultipleObjects
    } ,
    {
        _T ( "WaitForMultipleObjectsEx" ) ,
        (PROC)DD_WaitForMultipleObjectsEx
    } ,
    {
        _T ( "WaitForSingleObject" ) ,
        (PROC)DD_WaitForSingleObject
    } ,
    {
        _T ( "WaitForSingleObjectEx" ) ,
        (PROC)DD_WaitForSingleObjectEx
    }
} ;

HOOKFUNCDESC g_stRealKernelFuncs[ NUMBER_KERNEL_FUNCS ] =
{
    {
        _T ( "CloseHandle"  ) ,
        (PROC)CloseHandle
    } ,
    {
        _T ( "CreateEventA" ) ,
        (PROC)CreateEventA
    } ,
    {
        _T ( "CreateEventW" ) ,
        (PROC)CreateEventW
    } ,
    {
        _T ( "CreateMutexA" ) ,
        (PROC)CreateMutexA
    } ,
    {
        _T ( "CreateMutexW" ) ,
        (PROC)CreateMutexW
    } ,
    {
        _T ( "CreateSemaphoreA" ) ,
        (PROC)CreateSemaphoreA
    } ,
    {
        _T ( "CreateSemaphoreW" ) ,
        (PROC)CreateSemaphoreW
    } ,
    {
        _T ( "CreateThread" ) ,
        (PROC)CreateThread
    } ,
    {
        _T ( "DeleteCriticalSection" ) ,
        (PROC)DeleteCriticalSection
    } ,
    {
        _T ( "EnterCriticalSection" ) ,
        (PROC)EnterCriticalSection
    } ,
    {
        _T ( "ExitProcess" ) ,
        (PROC)ExitProcess
    } ,
    {
        _T ( "ExitThread" ) ,
        (PROC)ExitThread
    } ,
    {
        _T ( "GetProcAddress" ) ,
        (PROC)GetProcAddress
    } ,
    {
        _T ( "InitializeCriticalSection" ) ,
        (PROC)InitializeCriticalSection
    } ,
    {
        _T ( "InitializeCriticalSectionAndSpinCount" ) ,
        (PROC)NULL
    } ,
    {
        _T ( "LeaveCriticalSection" ) ,
        (PROC)LeaveCriticalSection
    } ,
    {
        _T ( "LoadLibraryA" ) ,
        (PROC)LoadLibraryA
    } ,
    {
        _T ( "LoadLibraryExA" ) ,
        (PROC)LoadLibraryExA
    } ,
    {
        _T ( "LoadLibraryExW" ) ,
        (PROC)LoadLibraryExW
    } ,
    {
        _T ( "LoadLibraryW" ) ,
        (PROC)LoadLibraryW
    } ,
    {
        _T ( "OpenEventA" ) ,
        (PROC)OpenEventA
    } ,
    {
        _T ( "OpenEventW" ) ,
        (PROC)OpenEventW
    } ,
    {
        _T ( "OpenMutexA" ) ,
        (PROC)OpenMutexA
    } ,
    {
        _T ( "OpenMutexW" ) ,
        (PROC)OpenMutexW
    } ,
    {
        _T ( "OpenSemaphoreA" ) ,
        (PROC)OpenSemaphoreA
    } ,
    {
        _T ( "OpenSemaphoreW" ) ,
        (PROC)OpenSemaphoreW
    } ,
    {
        _T ( "PulseEvent" ) ,
        (PROC)PulseEvent
    } ,
    {
        _T ( "ReleaseMutex" ) ,
        (PROC)ReleaseMutex
    } ,
    {
        _T ( "ReleaseSemaphore" ) ,
        (PROC)ReleaseSemaphore
    } ,
    {
        _T ( "ResetEvent" ) ,
        (PROC)ResetEvent
    } ,
    {
        _T ( "ResumeThread" ) ,
        (PROC)SuspendThread
    } ,
    {
        _T ( "SetCriticalSectionSpinCount" ) ,
        (PROC)NULL
    } ,
    {
        _T ( "SetEvent"   ) ,
        (PROC)SetEvent
    } ,
    {
        _T ( "SignalObjectAndWait" ) ,
        (PROC)NULL
    } ,
    {
        _T ( "SuspendThread" ) ,
        (PROC)ResumeThread
    } ,
    {
        _T ( "TerminateThread" ) ,
        (PROC)TerminateThread
    } ,
    {
        _T ( "TryEnterCriticalSection" ) ,
        (PROC)NULL
    } ,
    {
        _T ( "WaitForMultipleObjects" ) ,
        (PROC)WaitForMultipleObjects
    } ,
    {
        _T ( "WaitForMultipleObjectsEx" ) ,
        (PROC)WaitForMultipleObjectsEx
    } ,
    {
        _T ( "WaitForSingleObject" ) ,
        (PROC)WaitForSingleObject
    } ,
    {
        _T ( "WaitForSingleObjectEx" ) ,
        (PROC)WaitForSingleObjectEx
    } ,
} ;


HOOKFUNCDESC g_stDDUserFuncs[ NUMBER_USER_FUNCS] =
{
    {
        _T ( "MsgWaitForMultipleObjects" ) ,
        (PROC)DD_MsgWaitForMultipleObjects
    } ,
    {
        _T ( "MsgWaitForMultipleObjectsEx" ) ,
        (PROC)DD_MsgWaitForMultipleObjectsEx
    }
} ;

HOOKFUNCDESC g_stRealUserFuncs[ NUMBER_USER_FUNCS ] =
{
    {
        _T ( "MsgWaitForMultipleObjects" ) ,
        (PROC)MsgWaitForMultipleObjects
    } ,
    {
        _T ( "MsgWaitForMultipleObjectsEx" ) ,
        (PROC)NULL
    }
} ;

