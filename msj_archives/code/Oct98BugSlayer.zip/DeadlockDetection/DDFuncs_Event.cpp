/*----------------------------------------------------------------------
   John Robbins - Oct '98 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
The event functions.
----------------------------------------------------------------------*/

#include "PCH.h"
#include "DeadlockDetection.h"
#include "Internal.h"

// Turn off all optimizations to avoid registers being changed behind
//  my back.
#pragma optimize( "", off )

HANDLE NAKEDDEF DD_CreateEventA(LPSECURITY_ATTRIBUTES lpEventAttributes,
                                BOOL                  bManualReset     ,
                                BOOL                  bInitialState    ,
                                LPCSTR                lpName           )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_EVENT ) )
    {

        FILL_EVENTINFO ( eCreateEventA ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        CreateEventA ( lpEventAttributes ,
                       bManualReset      ,
                       bInitialState     ,
                       lpName             ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        CreateEventA ( lpEventAttributes ,
                       bManualReset      ,
                       bInitialState     ,
                       lpName             ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 4 ) ;
}

HANDLE NAKEDDEF DD_CreateEventW(LPSECURITY_ATTRIBUTES lpEventAttributes,
                                  BOOL                bManualReset     ,
                                  BOOL                bInitialState    ,
                                  LPCWSTR             lpName           )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_EVENT ) )
    {

        FILL_EVENTINFO ( eCreateEventW ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        CreateEventW ( lpEventAttributes ,
                       bManualReset      ,
                       bInitialState     ,
                       lpName             ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        CreateEventW ( lpEventAttributes ,
                       bManualReset      ,
                       bInitialState     ,
                       lpName             ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 4 ) ;
}

HANDLE NAKEDDEF DD_OpenEventA ( DWORD  dwDesiredAccess ,
                                BOOL   bInheritHandle  ,
                                LPCSTR lpName           )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_EVENT ) )
    {

        FILL_EVENTINFO ( eOpenEventA ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        OpenEventA ( dwDesiredAccess ,
                     bInheritHandle  ,
                     lpName           ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        OpenEventA ( dwDesiredAccess ,
                     bInheritHandle  ,
                     lpName           ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 3 ) ;
}

HANDLE NAKEDDEF DD_OpenEventW ( DWORD   dwDesiredAccess ,
                                BOOL    bInheritHandle  ,
                                LPCWSTR lpName           )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_EVENT ) )
    {

        FILL_EVENTINFO ( eOpenEventW ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        OpenEventW ( dwDesiredAccess ,
                     bInheritHandle  ,
                     lpName           ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        OpenEventW ( dwDesiredAccess ,
                     bInheritHandle  ,
                     lpName           ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 3 ) ;
}

BOOL NAKEDDEF DD_PulseEvent ( HANDLE hEvent )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_EVENT ) )
    {

        FILL_EVENTINFO ( ePulseEvent ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        PulseEvent ( hEvent ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        PulseEvent ( hEvent ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 1 ) ;
}

BOOL NAKEDDEF DD_ResetEvent ( HANDLE hEvent )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_EVENT ) )
    {

        FILL_EVENTINFO ( eResetEvent ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        ResetEvent ( hEvent ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        ResetEvent ( hEvent ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 1 ) ;
}

BOOL NAKEDDEF DD_SetEvent ( HANDLE hEvent )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_EVENT ) )
    {

        FILL_EVENTINFO ( eSetEvent ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        SetEvent ( hEvent ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        SetEvent ( hEvent ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 1 ) ;
}

// Turn optimizations back on.
#pragma optimize( "", on )

