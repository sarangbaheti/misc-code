/*----------------------------------------------------------------------
   John Robbins - Oct '98 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
The wait and special functions.
----------------------------------------------------------------------*/

#include "PCH.h"
#include "DeadlockDetection.h"
#include "Internal.h"

// Turn off all optimizations to avoid registers being changed behind
//  my back.
#pragma optimize( "", off )

DWORD NAKEDDEF DD_WaitForSingleObject ( HANDLE hHandle        ,
                                        DWORD  dwMilliseconds  )
{
    HOOKFN_PROLOG ( ) ;

    if ( FALSE == IsSuspended ( ) )
    {
        FILL_EVENTINFO ( eWaitForSingleObject ) ;

        // Record that the thread is about to wait on a handle.
        stEvtInfo.ePrePost = ePreCall ;
        ProcessEvent ( &stEvtInfo ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        WaitForSingleObject ( hHandle , dwMilliseconds ) ;
        REAL_FUNC_POST_CALL ( ) ;

        stEvtInfo.ePrePost = ePostCall ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        WaitForSingleObject ( hHandle , dwMilliseconds ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 2 ) ;
}

DWORD NAKEDDEF DD_WaitForSingleObjectEx ( HANDLE hHandle        ,
                                          DWORD  dwMilliseconds ,
                                          BOOL   bAlertable      )
{
    HOOKFN_PROLOG ( ) ;

    if ( FALSE == IsSuspended ( ) )
    {

        FILL_EVENTINFO ( eWaitForSingleObjectEx ) ;

        // Record that the thread is about to wait on a handle.
        stEvtInfo.ePrePost = ePreCall ;
        ProcessEvent ( &stEvtInfo ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        WaitForSingleObjectEx ( hHandle , dwMilliseconds , bAlertable );
        REAL_FUNC_POST_CALL ( ) ;

        stEvtInfo.ePrePost = ePostCall ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        WaitForSingleObjectEx ( hHandle , dwMilliseconds , bAlertable );
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 3 ) ;
}

DWORD NAKEDDEF DD_WaitForMultipleObjects( DWORD          nCount     ,
                                          CONST HANDLE * lpHandles  ,
                                          BOOL           bWaitAll   ,
                                          DWORD          dwMilliseconds)
{
    HOOKFN_PROLOG ( ) ;

    if ( FALSE == IsSuspended ( ) )
    {

        FILL_EVENTINFO ( eWaitForMultipleObjects ) ;

        // Record that the thread is about to wait on some handles.
        stEvtInfo.ePrePost = ePreCall ;
        ProcessEvent ( &stEvtInfo ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        WaitForMultipleObjects ( nCount         ,
                                 lpHandles      ,
                                 bWaitAll       ,
                                 dwMilliseconds  ) ;
        REAL_FUNC_POST_CALL ( ) ;

        stEvtInfo.ePrePost = ePostCall ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        WaitForMultipleObjects ( nCount         ,
                                 lpHandles      ,
                                 bWaitAll       ,
                                 dwMilliseconds  ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 4 ) ;
}

DWORD NAKEDDEF DD_WaitForMultipleObjectsEx( DWORD        nCount        ,
                                            CONST HANDLE *lpHandles    ,
                                            BOOL         bWaitAll      ,
                                            DWORD        dwMilliseconds,
                                            BOOL         bAlertable    )
{
    HOOKFN_PROLOG ( ) ;

    if ( FALSE == IsSuspended ( ) )
    {

        FILL_EVENTINFO ( eWaitForMultipleObjectsEx ) ;

        // Record that the thread is about to wait on some handles.
        stEvtInfo.ePrePost = ePreCall ;
        ProcessEvent ( &stEvtInfo ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        WaitForMultipleObjectsEx ( nCount         ,
                                   lpHandles      ,
                                   bWaitAll       ,
                                   dwMilliseconds ,
                                   bAlertable      ) ;
        REAL_FUNC_POST_CALL ( ) ;

        // Record that the thread now owns the critical section.
        stEvtInfo.ePrePost = ePostCall ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        WaitForMultipleObjectsEx ( nCount         ,
                                   lpHandles      ,
                                   bWaitAll       ,
                                   dwMilliseconds ,
                                   bAlertable      ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 5 ) ;
}

DWORD NAKEDDEF DD_MsgWaitForMultipleObjects ( DWORD    nCount         ,
                                              LPHANDLE pHandles       ,
                                              BOOL     fWaitAll       ,
                                              DWORD    dwMilliseconds ,
                                              DWORD    dwWakeMask      )
{
    HOOKFN_PROLOG ( ) ;

    if ( FALSE == IsSuspended ( ) )
    {

        FILL_EVENTINFO ( eMsgWaitForMultipleObjects ) ;

        // Record that the thread is about to wait on some handles.
        stEvtInfo.ePrePost = ePreCall ;
        ProcessEvent ( &stEvtInfo ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        MsgWaitForMultipleObjects ( nCount         ,
                                    pHandles       ,
                                    fWaitAll       ,
                                    dwMilliseconds ,
                                    dwWakeMask      ) ;
        REAL_FUNC_POST_CALL ( ) ;

        // Record that the thread now owns the critical section.
        stEvtInfo.ePrePost = ePostCall ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        MsgWaitForMultipleObjects ( nCount         ,
                                    pHandles       ,
                                    fWaitAll       ,
                                    dwMilliseconds ,
                                    dwWakeMask      ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 5 ) ;
}

DWORD NAKEDDEF DD_MsgWaitForMultipleObjectsEx ( DWORD    nCount        ,
                                                LPHANDLE pHandles      ,
                                                DWORD    dwMilliseconds,
                                                DWORD    dwWakeMask    ,
                                                DWORD    dwFlags       )
{
    HOOKFN_PROLOG ( ) ;

    if ( FALSE == IsSuspended ( ) )
    {

        FILL_EVENTINFO ( eMsgWaitForMultipleObjectsEx ) ;

        // Record that the thread is about to wait on some handles.
        stEvtInfo.ePrePost = ePreCall ;
        ProcessEvent ( &stEvtInfo ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        MsgWaitForMultipleObjectsEx ( nCount        ,
                                      pHandles      ,
                                      dwMilliseconds,
                                      dwWakeMask    ,
                                      dwFlags        ) ;
        REAL_FUNC_POST_CALL ( ) ;

        // Record that the thread now owns the critical section.
        stEvtInfo.ePrePost = ePostCall ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        MsgWaitForMultipleObjectsEx ( nCount        ,
                                      pHandles      ,
                                      dwMilliseconds,
                                      dwWakeMask    ,
                                      dwFlags        ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 5 ) ;
}

typedef DWORD (WINAPI *PFNSIGNALOBJECTANDWAIT) ( HANDLE ,
                                                 HANDLE ,
                                                 DWORD  ,
                                                 BOOL    ) ;
static PFNSIGNALOBJECTANDWAIT g_pfnSOAW = NULL ;

DWORD NAKEDDEF DD_SignalObjectAndWait ( HANDLE hObjectToSignal,
                                        HANDLE hObjectToWaitOn,
                                        DWORD  dwMilliseconds,
                                        BOOL   bAlertable )
{
    HOOKFN_PROLOG ( ) ;
    if ( NULL == g_pfnSOAW )
    {
        g_pfnSOAW = (PFNSIGNALOBJECTANDWAIT)
              GetProcAddress ( GetModuleHandle ( _T ( "KERNEL32.DLL" )),
                               _T ( "SignalObjectAndWait" )           );
    }

    if ( NULL != g_pfnSOAW )
    {
        if ( FALSE == IsSuspended ( ) )
        {

            FILL_EVENTINFO ( eSignalObjectAndWait ) ;

            // Record that the thread is about to wait on some handles.
            stEvtInfo.ePrePost = ePreCall ;
            ProcessEvent ( &stEvtInfo ) ;

            REAL_FUNC_PRE_CALL ( ) ;
            g_pfnSOAW ( hObjectToSignal ,
                        hObjectToWaitOn ,
                        dwMilliseconds  ,
                        bAlertable       ) ;
            REAL_FUNC_POST_CALL ( ) ;

            stEvtInfo.ePrePost = ePostCall ;

            ProcessEvent ( &stEvtInfo ) ;
        }
        else
        {
            REAL_FUNC_PRE_CALL ( ) ;
            g_pfnSOAW ( hObjectToSignal ,
                        hObjectToWaitOn ,
                        dwMilliseconds  ,
                        bAlertable       ) ;
            REAL_FUNC_POST_CALL ( ) ;
        }
    }
    HOOKFN_EPILOG ( 4 ) ;
}

BOOL NAKEDDEF DD_CloseHandle ( HANDLE hObject )
{
    HOOKFN_PROLOG ( ) ;

    if ( FALSE == IsSuspended ( ) )
    {

        FILL_EVENTINFO ( eCloseHandle ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        CloseHandle ( hObject ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        CloseHandle ( hObject ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }
    HOOKFN_EPILOG ( 1 ) ;
}

// Turn optimizations back on.
#pragma optimize( "", on )
