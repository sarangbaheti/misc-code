/*----------------------------------------------------------------------
   John Robbins - Oct '98 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------

----------------------------------------------------------------------*/
#include "pch.h"
#include "BugslayerUtil.h"
#include "DeadlockDetection.h"
#include "DeadlockDetection_RC.h"
#include "DDExtHandler.h"
#include "PersistSettings.h"
#include "DD_Funcs.h"
#include "Internal.h"
#include "ModList.h"
#include "Tables.h"

/*//////////////////////////////////////////////////////////////////////
                             File Constants
//////////////////////////////////////////////////////////////////////*/
// The default extension DLL.
const LPCTSTR k_szDEFEXTDLLNAME = _T ( "DeadDetExt.DLL" ) ;
// The default for starting in DllMain.
const BOOL    k_bSTARTINDLLMAIN = FALSE ;
// The default logging options.
const DWORD   k_dwDEFAULTOPTS   = DDOPT_ALL ;
// The interesting module strings.
const LPCTSTR k_KERNEL32 = _T ( "KERNEL32.DLL" ) ;
const LPCTSTR k_USER32 = _T ( "USER32.DLL" ) ;
const LPCTSTR k_BUGSLAYERUTIL = _T ( "BUGSLAYERUTIL.DLL" ) ;

/*//////////////////////////////////////////////////////////////////////
                           File Scope Globals
//////////////////////////////////////////////////////////////////////*/
// The HINSTANCE for DeadlockDetection.DLL.
static HINSTANCE g_hInst = NULL ;
// The flag that indicates that the deadlock system is initialized.
static BOOL g_bInitialized = FALSE ;
// The private heap that everything is allocated from for this whole
//  module.  By doing this, I do not interfere with the user's memory
//  scheme.
static HANDLE g_hHeap ;
// The processed module list class.
static CModList g_cProcessedModList ;
// The critical section that is used to protect everything that can be
//  called from outside this file.
static CRITICAL_SECTION g_CritSec ;
// The DeadDet Extension DLL handler class.
static CDDExtHandler g_cDDExtHandler ;
// The current options.
static DWORD g_dwOptions ;
// The suspended state flag.
static BOOL  g_bSuspended = FALSE ;


/*//////////////////////////////////////////////////////////////////////
                          File Scope Functions
//////////////////////////////////////////////////////////////////////*/
static void InitTables ( void ) ;
static void InitProcessedModList ( CModList & cList ) ;
static BOOL UnHookModuleForDeadlockDetection ( HINSTANCE hMod ) ;
static BOOL HookModuleForDeadlockDetection ( HINSTANCE hMod ) ;

/*//////////////////////////////////////////////////////////////////////
                    Exported Function Implementation
//////////////////////////////////////////////////////////////////////*/

// See description in DeadlockDetection.h.
BOOL DEADDET_DLLINTERFACE WINAPI OpenDeadlockDetection ( DWORD dwOpts )
{
    // If we have already been initialized, just kick out now.
    if ( TRUE == g_bInitialized )
    {
        SetLastError ( ERROR_ALREADY_INITIALIZED ) ;
        return ( FALSE ) ;
    }
    __try
    {
        __try
        {
            // Initialize the critical section that protects life as
            //  the deadlock detection system knows it.
            InitializeCriticalSection ( &g_CritSec ) ;
            // Now grab the critical section.
            EnterCriticalSection ( &g_CritSec ) ;

            // Initialize the tables.
            InitTables ( ) ;

            // Set the options.
            g_dwOptions = dwOpts ;

            // Figure out the extension DLL to load.
            TCHAR szExtName [ MAX_PATH ] ;

            VERIFY ( GetExtDllFilename ( szExtName            ,
                                         sizeof ( szExtName ) ,
                                         k_szDEFEXTDLLNAME     ) ) ;

            // Load and verify the extension DLL.
            if ( FALSE == g_cDDExtHandler.LoadDDExtDll ( szExtName ) )
            {
                ShowFatalError ( g_hInst            ,
                                 IDS_NODDEXTDLLLOAD ,
                                 szExtName           ) ;
                g_bInitialized = FALSE ;
                __leave ;
            }

            if ( FALSE == g_cDDExtHandler.DeadDetExtOpen ( ) )
            {
                ShowFatalError ( g_hInst             ,
                                 IDS_DDEXTFAILEDINIT ,
                                 szExtName            ) ;
                g_bInitialized = FALSE ;
                __leave ;
            }

            // Create the heap that everything is allocated from.
            g_hHeap = HeapCreate ( 0 , 0 , 0 ) ;

            ASSERT ( NULL != g_hHeap ) ;
            if ( NULL == g_hHeap )
            {
                ShowFatalError ( g_hInst , IDS_NOHEAPCREATE ) ;
                g_bInitialized = FALSE ;
                __leave ;
            }

            // Set the module list heap.
            g_cProcessedModList.SetHeap ( g_hHeap ) ;

            InitProcessedModList ( g_cProcessedModList ) ;

            // The basic initialization work is done.  At this point
            //  start figuring out the DLLs that are in this address
            //  space and patch them.
            HookAllLoadedModules ( ) ;

            // Everything worked so everything is initialized.
            g_bInitialized = TRUE ;
        }
        __except ( EXCEPTION_EXECUTE_HANDLER )
        {
            ASSERT ( FALSE ) ;
            // Make sure the initialization settings get set to FALSE.
            g_bInitialized = FALSE ;
        }
    }
    __finally
    {
        // Always release the critical section here.
        LeaveCriticalSection ( &g_CritSec ) ;

        // Was there a problem initializing?
        if ( FALSE == g_bInitialized )
        {
            // Since nothing should own the critical section, get rid
            //  of it here.
            DeleteCriticalSection ( &g_CritSec ) ;
        }
    }
    // Always return the initialization state.
    return ( g_bInitialized ) ;
}

// See description in DeadlockDetection.h.
void DEADDET_DLLINTERFACE WINAPI CloseDeadlockDetection ( void )
{
    // If not initialize, kick out now.
    if ( FALSE == g_bInitialized )
    {
        SetLastError ( ERROR_ACCESS_DENIED ) ;
        return ;
    }
    __try
    {
        // Always grab the critical section.
        EnterCriticalSection ( &g_CritSec ) ;
        __try
        {
            // Shut off the initialization flag immediately.
            g_bInitialized = FALSE ;


            // Do all the unhooking.
            for ( UINT i = 0                            ;
                  i < g_cProcessedModList.GetCount ( )  ;
                  i++                                    )
            {
                if ( ( g_hInst != g_cProcessedModList [ i ]     ) &&
                     ( g_cDDExtHandler.GetDDExtHandle ( ) !=
                                       g_cProcessedModList [ i ])    )
                {
                    UnHookModuleForDeadlockDetection (
                                           g_cProcessedModList [ i ] ) ;
                }
            }

            // Tell the extension DLL that it is done.
            g_cDDExtHandler.DeadDetExtClose ( ) ;

            // Unload the extension DLL.
            g_cDDExtHandler.FreeDDExtDll ( ) ;

            // Clear out the module list.
            g_cProcessedModList.Clear ( ) ;
            g_cProcessedModList.SetHeap ( NULL ) ;

            // Shut down the private heap.
            VERIFY ( HeapDestroy ( g_hHeap ) ) ;
        }
        __except ( EXCEPTION_EXECUTE_HANDLER )
        {
            ASSERT ( FALSE ) ;
        }
    }
    __finally
    {
        // Get rid of the critical section.
        LeaveCriticalSection ( &g_CritSec ) ;
        DeleteCriticalSection ( &g_CritSec ) ;
    }
}

// See description in DeadlockDetection.h.
DWORD DEADDET_DLLINTERFACE WINAPI GetDeadlockDetectionOptions ( void )
{
    return ( g_dwOptions ) ;
}

// See description in DeadlockDetection.h.
DWORD DEADDET_DLLINTERFACE WINAPI
                         SetDeadlockDetectionOptions ( DWORD dwNewOpts )
{
    // If not initialized, kick out.
    if ( FALSE == g_bInitialized )
    {
        SetLastError ( ERROR_ACCESS_DENIED ) ;
        return ( 0 ) ;
    }
    EnterCriticalSection ( &g_CritSec ) ;

    DWORD dwOldOpts = g_dwOptions ;
    g_dwOptions = dwNewOpts ;

    LeaveCriticalSection ( &g_CritSec ) ;
    return ( dwOldOpts ) ;
}

void DEADDET_DLLINTERFACE WINAPI SuspendDeadlockDetection ( void )
{
    if ( FALSE == g_bInitialized )
    {
        SetLastError ( ERROR_ACCESS_DENIED ) ;
        return ;
    }

    EnterCriticalSection ( &g_CritSec ) ;
    g_bSuspended = TRUE ;
    LeaveCriticalSection ( &g_CritSec ) ;
}

void DEADDET_DLLINTERFACE WINAPI ResumeDeadlockDetection ( void )
{
    if ( FALSE == g_bInitialized )
    {
        SetLastError ( ERROR_ACCESS_DENIED ) ;
        return ;
    }

    EnterCriticalSection ( &g_CritSec ) ;
    g_bSuspended = FALSE ;
    LeaveCriticalSection ( &g_CritSec ) ;
}


/*//////////////////////////////////////////////////////////////////////
                     Internal Function Definitions
//////////////////////////////////////////////////////////////////////*/

// Ye ol' standard DLL main.
BOOL WINAPI DllMain ( HINSTANCE hInst       ,
                      DWORD     dwReason    ,
                      LPVOID    /*lpReserved*/ )
{
    BOOL bRet = TRUE ;
    switch ( dwReason )
    {
        case DLL_PROCESS_ATTACH :
            // Save off the DLL hInstance.
            g_hInst = hInst ;
            // I don't need the thread notifications.
            DisableThreadLibraryCalls ( g_hInst ) ;
            // Set the name of the settings file.
            SetPersistentFilename ( g_hInst ) ;
            // Get the default options.
            g_dwOptions = DefaultEventOptions ( k_dwDEFAULTOPTS ) ;
            // Do I start the whole thing on the load?
            if ( TRUE == StartInDllMain ( k_bSTARTINDLLMAIN ) )
            {
                bRet = OpenDeadlockDetection ( g_dwOptions ) ;
                ASSERT ( TRUE == bRet ) ;
            }
            break ;
        case DLL_PROCESS_DETACH :
            // If the library is initialized, then force the close down
            //  just in case.
            if ( TRUE == g_bInitialized )
            {
                CloseDeadlockDetection ( ) ;
            }
            break ;
        default                 :
            break ;
    }
    return ( bRet ) ;
}

// See INTERNAL.H.
BOOL HookAllLoadedModules ( void )
{
    // Allocate and fill the array of loaded modules.
    UINT uiModCount = 0 ;
    HMODULE * phMods =
                AllocAndFillProcessModuleList ( g_hHeap , &uiModCount );

    // Did we get it?
    ASSERT ( NULL != phMods ) ;
    ASSERT ( 0 != uiModCount ) ;
    if ( ( NULL == phMods ) || ( 0 == uiModCount ) )
    {
        ShowFatalError ( g_hInst , IDS_NOGETLOADEDMODS ) ;
        return ( FALSE ) ;
    }

    // Keep the updated list in cTempList.
    CModList cTempList ;
    cTempList.SetHeap ( g_hHeap ) ;

    // Loop through the modules and hook them if needed.
    for ( UINT i = 0 ; i < uiModCount ; i++ )
    {
        // Has this module already been processed?
        if ( FALSE == g_cProcessedModList.IsInList ( phMods [ i ] ) )
        {
            // This is a module that has not been processed so
            //  hook away.
            HookModuleForDeadlockDetection ( phMods [ i ] ) ;
        }
        // The module has been processed, stick it in the temp list.
        cTempList.Add ( phMods[ i ] ) ;
    }
    // Copy the temp list into the real list.
    g_cProcessedModList = cTempList ;

    // Get rid of the memory allocated earlier.
    VERIFY ( HeapFree ( g_hHeap , 0 , phMods ) ) ;

    // All OK, Jump Master!
    return ( TRUE ) ;
}

/*----------------------------------------------------------------------
FUNCTION        : HookModuleForDeadlockDetection
DISCUSSION      :
    Hooks the specified module's thread and synchronization functions.
PARAMETERS      :
    hMod - The module to hook.
RETURNS         :
    TRUE  - Life is good.
    FALSE - There was a problem.
----------------------------------------------------------------------*/
static BOOL HookModuleForDeadlockDetection ( HINSTANCE hMod )
{
    // Note that all the functions for the module are always hooked.
    //  It is up to the actual DD* hookee functions to determine if
    //  they are active through the options or not.
    // By hooking all the functions, the user can toggle various sets
    //  on and off on the fly!

#ifdef _DEBUG
    {
        TCHAR szName[ MAX_PATH ] ;
        VERIFY ( GetModuleFileName ( hMod , szName , MAX_PATH ) ) ;
        TRACE1 ( "Hooking module -> %s\n" , szName ) ;
    }
#endif

    // If this is Win95 and the module is one that is in shared memory
    //  skip it.
    if ( ( FALSE == IsNT ( ) ) && ( (DWORD)hMod >= 0x80000000 ) )
    {
        return ( FALSE ) ;
    }

    HookImportedFunctionsByName ( hMod                  ,
                                  k_KERNEL32            ,
                                  NUMBER_KERNEL_FUNCS   ,
                                  g_stDDKernelFuncs     ,
                                  NULL                  ,
                                  NULL                   ) ;

    HookImportedFunctionsByName ( hMod              ,
                                  k_USER32          ,
                                  NUMBER_USER_FUNCS ,
                                  g_stDDUserFuncs   ,
                                  NULL              ,
                                  NULL               ) ;

    // All OK, Jump Master!
    return ( TRUE ) ;
}

/*----------------------------------------------------------------------
FUNCTION        : UnHookModuleForDeadlockDetection
DISCUSSION      :
    Puts the original thread and synchronization functions back.
PARAMETERS      :
    hMod - The module to unhook.
RETURNS         :
    TRUE  - Life is good.
    FALSE - There was a problem.
----------------------------------------------------------------------*/
static BOOL UnHookModuleForDeadlockDetection ( HINSTANCE hMod )
{
    // BUG BUG
    //  Some work needs to be done here.  Right now this function just
    //  unhooks the module.  This should get extended to remove the
    //  module from the processed module list.  Of course, this means
    //  that the CModList class will need to handle it as well.

#ifdef _DEBUG
    {
        TCHAR szName[ MAX_PATH ] ;
        VERIFY ( GetModuleFileName ( hMod , szName , MAX_PATH ) ) ;
        TRACE1 ( "Unhooking module -> %s\n" , szName ) ;
    }
#endif

    HookImportedFunctionsByName ( hMod                  ,
                                  k_KERNEL32            ,
                                  NUMBER_KERNEL_FUNCS   ,
                                  g_stRealKernelFuncs   ,
                                  NULL                  ,
                                  NULL                   ) ;

    HookImportedFunctionsByName ( hMod              ,
                                  k_USER32          ,
                                  NUMBER_USER_FUNCS ,
                                  g_stRealUserFuncs ,
                                  NULL              ,
                                  NULL               ) ;
    // All OK, Jump Master!
    return ( TRUE ) ;
}

// See INTERNAL.H.
void ProcessEvent ( LPDDEVENTINFO lpEvtInfo )
{
    // Grab the critical section.
    EnterCriticalSection ( &g_CritSec ) ;
    // Post the data.
    if ( FALSE == g_cDDExtHandler.DeadDetProcessEvent ( lpEvtInfo ) )
    {
        // Since there was a problem, shift to suspended mode.
        SuspendDeadlockDetection ( ) ;
    }
    // Release the critical section.
    LeaveCriticalSection ( &g_CritSec ) ;
}

// See INTERNAL.H.
BOOL DoLogging ( DWORD dwItem )
{
    if ( ( dwItem == ( g_dwOptions & dwItem ) ) &&
         ( FALSE == g_bSuspended              )    )
    {
        return ( TRUE ) ;
    }
    return ( FALSE ) ;
}

// See INTERNAL.H.
BOOL IsSuspended ( void )
{
    return ( g_bSuspended ) ;
}

/*----------------------------------------------------------------------
FUNCTION        :   InitTables
DISCUSSION      :
    Initializes those real function tables with NULL values.  Those are
the functions that are either new or not supported on multiple operating
systems.
PARAMETERS      :
    None.
RETURNS         :
    None.
----------------------------------------------------------------------*/
static void InitTables ( void )
{
    HMODULE hKernel = GetModuleHandle ( k_KERNEL32 ) ;
    HMODULE hUser   = GetModuleHandle ( k_USER32 ) ;

    ASSERT ( NULL != hKernel ) ;
    ASSERT ( NULL != hUser ) ;

    if ( ( NULL != hKernel ) && ( NULL != hUser ) )
    {
        // Plow though the KERNEL32 functions.
        for ( int i = 0 ; i < NUMBER_KERNEL_FUNCS ; i++ )
        {
            if ( NULL == g_stRealKernelFuncs[ i ].pProc )
            {
                g_stRealKernelFuncs[ i ].pProc
                    = (PROC)GetProcAddress ( hKernel ,
                                         g_stRealKernelFuncs[i].szFunc);
            }
        }
        // Plow through the USER32 functions.
        for ( i = 0 ; i < NUMBER_USER_FUNCS ; i++ )
        {
            if ( NULL == g_stRealUserFuncs[ i ].pProc )
            {
                g_stRealUserFuncs[ i ].pProc
                    = (PROC)GetProcAddress ( hUser ,
                                           g_stRealUserFuncs[i].szFunc);
            }
        }
    }
}

/*----------------------------------------------------------------------
FUNCTION        : InitProcessedModList
DISCUSSION      :
    Initializes the processed module list.
PARAMETERS      :
    cList - The particular list to initialize.
RETURNS         :
    None.
----------------------------------------------------------------------*/
static void InitProcessedModList ( CModList & cList )
{
    // Clear out any modules that were there.
    cList.Clear ( ) ;

    // Always add the deadlock detection module, the DDExt module, and
    //  any other modules I load to the module list so I don't patch
    //  them.
    cList.Add ( g_hInst ) ;
    cList.Add ( g_cDDExtHandler.GetDDExtHandle ( ) ) ;

    HMODULE hTemp = GetModuleHandle ( k_BUGSLAYERUTIL ) ;
    if ( NULL != hTemp )
    {
        cList.Add ( hTemp ) ;
    }

    // BUG BUG
    //  It might be worth it to also have some sort of master
    //  skip list as well.
}

