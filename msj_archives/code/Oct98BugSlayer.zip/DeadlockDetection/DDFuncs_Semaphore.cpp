/*----------------------------------------------------------------------
   John Robbins - Oct '98 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
The semaphore functions.
----------------------------------------------------------------------*/

#include "PCH.h"
#include "DeadlockDetection.h"
#include "Internal.h"

// Turn off all optimizations to avoid registers being changed behind
//  my back.
#pragma optimize( "", off )

HANDLE NAKEDDEF
    DD_CreateSemaphoreA ( LPSECURITY_ATTRIBUTES lpSemaphoreAttributes,
                          LONG lInitialCount,
                          LONG lMaximumCount,
                          LPCSTR lpName )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_SEMAPHORE ) )
    {

        FILL_EVENTINFO ( eCreateSemaphoreA ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        CreateSemaphoreA ( lpSemaphoreAttributes ,
                           lInitialCount         ,
                           lMaximumCount         ,
                           lpName                 ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        CreateSemaphoreA ( lpSemaphoreAttributes ,
                           lInitialCount         ,
                           lMaximumCount         ,
                           lpName                 ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 4 ) ;
}

HANDLE NAKEDDEF
    DD_CreateSemaphoreW ( LPSECURITY_ATTRIBUTES lpSemaphoreAttributes,
                          LONG lInitialCount,
                          LONG lMaximumCount,
                          LPCWSTR lpName )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_SEMAPHORE ) )
    {

        FILL_EVENTINFO ( eCreateSemaphoreW ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        CreateSemaphoreW ( lpSemaphoreAttributes ,
                           lInitialCount         ,
                           lMaximumCount         ,
                           lpName                 ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        CreateSemaphoreW ( lpSemaphoreAttributes ,
                           lInitialCount         ,
                           lMaximumCount         ,
                           lpName                 ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 4 ) ;
}

HANDLE NAKEDDEF DD_OpenSemaphoreA ( DWORD  dwDesiredAccess ,
                                    BOOL   bInheritHandle  ,
                                    LPCSTR lpName           )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_SEMAPHORE ) )
    {

        FILL_EVENTINFO ( eOpenSemaphoreA ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        OpenSemaphoreA ( dwDesiredAccess ,
                         bInheritHandle  ,
                         lpName           ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        OpenSemaphoreA ( dwDesiredAccess ,
                         bInheritHandle  ,
                         lpName           ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 3 ) ;
}

HANDLE NAKEDDEF DD_OpenSemaphoreW ( DWORD dwDesiredAccess,
                                    BOOL bInheritHandle,
                                    LPCWSTR lpName )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_SEMAPHORE ) )
    {

        FILL_EVENTINFO ( eOpenSemaphoreW ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        OpenSemaphoreW ( dwDesiredAccess ,
                         bInheritHandle  ,
                         lpName           ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        OpenSemaphoreW ( dwDesiredAccess ,
                         bInheritHandle  ,
                         lpName           ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 3 ) ;
}

BOOL NAKEDDEF DD_ReleaseSemaphore ( HANDLE hSemaphore,
                                    LONG lReleaseCount,
                                    LPLONG lpPreviousCount)
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_SEMAPHORE ) )
    {

        FILL_EVENTINFO ( eReleaseSemaphore ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        ReleaseSemaphore ( hSemaphore       ,
                           lReleaseCount    ,
                           lpPreviousCount   )  ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        ReleaseSemaphore ( hSemaphore       ,
                           lReleaseCount    ,
                           lpPreviousCount   )  ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 3 ) ;
}

// Turn optimizations back on.
#pragma optimize( "", on )

