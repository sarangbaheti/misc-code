/*----------------------------------------------------------------------
   John Robbins - Oct '98 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
All the persistent storage handling routines
----------------------------------------------------------------------*/

#ifndef _PERSISTSETTINGS_H
#define _PERSISTSETTINGS_H

/*----------------------------------------------------------------------
FUNCTION        :   SetPersistentFilename
DISCUSSION      :
    Sets up this unit by calculating the location of the persistent file
based off an HINSTANCE.  This function MUST be called before any other
in this subsystem.
PARAMETERS      :
    hMod    - The module to use.
RETURNS         :
    None.
----------------------------------------------------------------------*/
void SetPersistentFilename ( HINSTANCE hMod ) ;

/*----------------------------------------------------------------------
FUNCTION        :   GetExtDllFilename
DISCUSSION      :
    Loads the extension DLL filename.
PARAMETERS      :
    szBuff - The buffer to copy the name into.
    uiSize - The size in characters of szBuff.
    szDef  - The default name.
RETURNS         :
    The number of characters copied into szBuff.
----------------------------------------------------------------------*/
int GetExtDllFilename ( LPTSTR szBuff , UINT uiSize , LPCTSTR szDef ) ;

/*----------------------------------------------------------------------
FUNCTION        :   StartInDllMain
DISCUSSION      :
    Returns TRUE if the deadlock detection system is supposed to start
as soon as the DLL is loaded.
PARAMETERS      :
    bDef - The default if the storage does not say.
RETURNS         :
    1 - Start the system as soon as the DLL is loaded.
    0 - Do not start the system until directed.
----------------------------------------------------------------------*/
BOOL StartInDllMain ( BOOL bDef ) ;

/*----------------------------------------------------------------------
FUNCTION        :   DefaultEventOptions
DISCUSSION      :
    Retrieves the default event logging options.
PARAMETERS      :
    dwDef - The default if the storage does not say.
RETURNS         :
    The default options.
----------------------------------------------------------------------*/
DWORD DefaultEventOptions ( DWORD dwDef ) ;

#endif  // _PERSISTSETTINGS_H


