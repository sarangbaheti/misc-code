/*----------------------------------------------------------------------
       John Robbins - Microsoft Systems Journal Bugslayer Column
----------------------------------------------------------------------*/

#ifndef _DEADLOCKDETECTION_RC_H
#define _DEADLOCKDETECTION_RC_H

// Stringtable defines.
#define IDS_NODDEXTDLLLOAD  100
#define IDS_NOHEAPCREATE    101
#define IDS_NOGETLOADEDMODS 102
#define IDS_DDEXTFAILEDINIT 103

#endif  // _DEADLOCKDETECTION_RC_H


