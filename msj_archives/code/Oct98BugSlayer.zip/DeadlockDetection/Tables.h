/*----------------------------------------------------------------------
   John Robbins - Oct '98 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
The function tables information.
----------------------------------------------------------------------*/

#ifndef _TABLES_H
#define _TABLES_H

// The table sizes.
#define NUMBER_KERNEL_FUNCS     41
#define NUMBER_USER_FUNCS       2

// The table of DeadlockDetection functions for KERNEL32.DLL.
extern HOOKFUNCDESC g_stDDKernelFuncs[ NUMBER_KERNEL_FUNCS ] ;
// The table of real KERNEL32.DLL functions that are hooked.
extern HOOKFUNCDESC g_stRealKernelFuncs[ NUMBER_KERNEL_FUNCS ] ;
// The table of DeadlockDetection functions for USER32.DLL.
extern HOOKFUNCDESC g_stDDUserFuncs[ NUMBER_USER_FUNCS ] ;
// The table of real USER32.DLL functions that are hooked.
extern HOOKFUNCDESC g_stRealUserFuncs[ NUMBER_USER_FUNCS ] ;

#endif  // _TABLES_H


