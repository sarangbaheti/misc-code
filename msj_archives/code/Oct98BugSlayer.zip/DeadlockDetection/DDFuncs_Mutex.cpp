/*----------------------------------------------------------------------
   John Robbins - Oct '98 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
The mutex functions.
----------------------------------------------------------------------*/

#include "PCH.h"
#include "DeadlockDetection.h"
#include "Internal.h"

// Turn off all optimizations to avoid registers being changed behind
//  my back.
#pragma optimize( "", off )

HANDLE NAKEDDEF DD_CreateMutexA(LPSECURITY_ATTRIBUTES lpMutexAttributes,
                                BOOL                  bInitialOwner    ,
                                LPCSTR                lpName           )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_MUTEX ) )
    {

        FILL_EVENTINFO ( eCreateMutexA ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        CreateMutexA ( lpMutexAttributes ,
                       bInitialOwner     ,
                       lpName             ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        CreateMutexA ( lpMutexAttributes ,
                       bInitialOwner     ,
                       lpName             ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 3 ) ;
}

HANDLE NAKEDDEF DD_CreateMutexW(LPSECURITY_ATTRIBUTES lpMutexAttributes,
                                BOOL                  bInitialOwner    ,
                                LPCWSTR               lpName           )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_MUTEX ) )
    {

        FILL_EVENTINFO ( eCreateMutexW ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        CreateMutexW ( lpMutexAttributes ,
                       bInitialOwner     ,
                       lpName             ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        CreateMutexW ( lpMutexAttributes ,
                       bInitialOwner     ,
                       lpName             ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 3 ) ;
}

HANDLE NAKEDDEF DD_OpenMutexA ( DWORD  dwDesiredAccess ,
                                BOOL   bInheritHandle  ,
                                LPCSTR lpName           )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_MUTEX ) )
    {

        FILL_EVENTINFO ( eOpenMutexA ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        OpenMutexA ( dwDesiredAccess ,
                     bInheritHandle  ,
                     lpName           ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        OpenMutexA ( dwDesiredAccess ,
                     bInheritHandle  ,
                     lpName           ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 3 ) ;

}

HANDLE NAKEDDEF DD_OpenMutexW ( DWORD   dwDesiredAccess ,
                                BOOL    bInheritHandle  ,
                                LPCWSTR lpName           )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_MUTEX ) )
    {

        FILL_EVENTINFO ( eOpenMutexW ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        OpenMutexW ( dwDesiredAccess ,
                     bInheritHandle  ,
                     lpName           ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        OpenMutexW ( dwDesiredAccess ,
                     bInheritHandle  ,
                     lpName           ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 3 ) ;

}

BOOL NAKEDDEF DD_ReleaseMutex ( HANDLE hMutex )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_MUTEX ) )
    {

        FILL_EVENTINFO ( eReleaseMutex ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        ReleaseMutex ( hMutex ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        ReleaseMutex ( hMutex ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 1 ) ;
}

// Turn optimizations back on.
#pragma optimize( "", on )

