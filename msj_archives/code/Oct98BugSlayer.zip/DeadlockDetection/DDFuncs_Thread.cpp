/*----------------------------------------------------------------------
   John Robbins - Oct '98 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
The thread functions.
----------------------------------------------------------------------*/

#include "PCH.h"
#include "DeadlockDetection.h"
#include "Internal.h"

// Turn off all optimizations to avoid registers being changed behind
//  my back.
#pragma optimize( "", off )

HANDLE NAKEDDEF DD_CreateThread (
                              LPSECURITY_ATTRIBUTES  lpThreadAttributes,
                              DWORD                  dwStackSize       ,
                              LPTHREAD_START_ROUTINE lpStartAddress    ,
                              LPVOID                 lpParameter       ,
                              DWORD                  dwCreationFlags   ,
                              LPDWORD                lpThreadId        )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_THREADS ) )
    {

        FILL_EVENTINFO ( eCreateThread ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        CreateThread ( lpThreadAttributes ,
                       dwStackSize        ,
                       lpStartAddress     ,
                       lpParameter        ,
                       dwCreationFlags    ,
                       lpThreadId          ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        CreateThread ( lpThreadAttributes ,
                       dwStackSize        ,
                       lpStartAddress     ,
                       lpParameter        ,
                       dwCreationFlags    ,
                       lpThreadId          ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 6 ) ;
}

VOID NAKEDDEF DD_ExitThread ( DWORD dwExitCode )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_THREADS ) )
    {

        FILL_EVENTINFO ( eExitThread ) ;

        // Once ExitThread is called, then nothing after it will
        //  execute.  Therefore, show the event information right here.
        stEvtInfo.ePrePost = ePreCall ;

        ProcessEvent ( &stEvtInfo ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        ExitThread ( dwExitCode ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        ExitThread ( dwExitCode ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 1 ) ;

}

DWORD NAKEDDEF DD_SuspendThread ( HANDLE hThread )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_THREADS ) )
    {

        FILL_EVENTINFO ( eSuspendThread ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        SuspendThread ( hThread ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        SuspendThread ( hThread ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 1 ) ;
}

DWORD NAKEDDEF DD_ResumeThread ( HANDLE hThread )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_THREADS ) )
    {

        FILL_EVENTINFO ( eResumeThread ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        ResumeThread ( hThread ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        ResumeThread ( hThread ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 1 ) ;
}

BOOL NAKEDDEF DD_TerminateThread ( HANDLE hThread , DWORD dwExitCode )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_THREADS ) )
    {

        FILL_EVENTINFO ( eTerminateThread ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        TerminateThread ( hThread , dwExitCode ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        TerminateThread ( hThread , dwExitCode ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 2 ) ;
}

// Turn optimizations back on.
#pragma optimize( "", on )

