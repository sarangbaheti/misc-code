/*----------------------------------------------------------------------
   John Robbins - Oct '98 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
The critical section functions.
----------------------------------------------------------------------*/

#include "PCH.h"
#include "DeadlockDetection.h"
#include "Internal.h"

// Turn off all optimizations to avoid registers being changed behind
//  my back.
#pragma optimize( "", off )

VOID NAKEDDEF
     DD_InitializeCriticalSection(LPCRITICAL_SECTION lpCriticalSection)
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_CRITSEC ) )
    {

        FILL_EVENTINFO ( eInitializeCriticalSection ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        InitializeCriticalSection ( lpCriticalSection ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {

        REAL_FUNC_PRE_CALL ( ) ;
        InitializeCriticalSection ( lpCriticalSection ) ;
        REAL_FUNC_POST_CALL ( ) ;

    }

    HOOKFN_EPILOG ( 1 ) ;
}

typedef BOOL (WINAPI *PFNINITCRITSECANDSPINCOUNT) (
                                   LPCRITICAL_SECTION lpCriticalSection,
                                   DWORD              dwSpinCount     );

static PFNINITCRITSECANDSPINCOUNT g_pfnICSASP = NULL ;

BOOL NAKEDDEF DD_InitializeCriticalSectionAndSpinCount (
                                   LPCRITICAL_SECTION lpCriticalSection,
                                   DWORD              dwSpinCount      )
{
    HOOKFN_PROLOG ( ) ;

    if ( NULL == g_pfnICSASP )
    {
        g_pfnICSASP = (PFNINITCRITSECANDSPINCOUNT)
            GetProcAddress(GetModuleHandle ( _T ( "kernel32.DLL" ) ) ,
                               "InitializeCriticalSectionAndSpinCount");
    }

    if ( NULL != g_pfnICSASP )
    {
        if ( TRUE == DoLogging ( DDOPT_CRITSEC ) )
        {

            FILL_EVENTINFO ( eInitializeCriticalSectionAndSpinCount ) ;

            REAL_FUNC_PRE_CALL ( ) ;
            g_pfnICSASP ( lpCriticalSection , dwSpinCount);
            REAL_FUNC_POST_CALL ( ) ;

            ProcessEvent ( &stEvtInfo ) ;
        }
        else
        {
            REAL_FUNC_PRE_CALL ( ) ;
            g_pfnICSASP ( lpCriticalSection , dwSpinCount ) ;
            REAL_FUNC_POST_CALL ( ) ;

        }
    }

    HOOKFN_EPILOG ( 2 ) ;
}

VOID NAKEDDEF
       DD_DeleteCriticalSection ( LPCRITICAL_SECTION lpCriticalSection )
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_CRITSEC ) )
    {

        FILL_EVENTINFO ( eDeleteCriticalSection ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        DeleteCriticalSection ( lpCriticalSection ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        DeleteCriticalSection ( lpCriticalSection ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 1 ) ;
}

VOID NAKEDDEF
          DD_EnterCriticalSection(LPCRITICAL_SECTION lpCriticalSection)
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_CRITSEC ) )
    {

        FILL_EVENTINFO ( eEnterCriticalSection ) ;

        // Record that the thread is about to enter the critical section.
        stEvtInfo.ePrePost = ePreCall ;

        ProcessEvent ( &stEvtInfo ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        EnterCriticalSection ( lpCriticalSection ) ;
        REAL_FUNC_POST_CALL ( ) ;

        // Record that the thread now owns the critical section.
        stEvtInfo.ePrePost = ePostCall ;
        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        EnterCriticalSection ( lpCriticalSection ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 1 ) ;
}

VOID NAKEDDEF
           DD_LeaveCriticalSection(LPCRITICAL_SECTION lpCriticalSection)
{
    HOOKFN_PROLOG ( ) ;

    if ( TRUE == DoLogging ( DDOPT_CRITSEC ) )
    {

        FILL_EVENTINFO ( eLeaveCriticalSection ) ;

        REAL_FUNC_PRE_CALL ( ) ;
        LeaveCriticalSection ( lpCriticalSection ) ;
        REAL_FUNC_POST_CALL ( ) ;

        ProcessEvent ( &stEvtInfo ) ;
    }
    else
    {
        REAL_FUNC_PRE_CALL ( ) ;
        LeaveCriticalSection ( lpCriticalSection ) ;
        REAL_FUNC_POST_CALL ( ) ;
    }

    HOOKFN_EPILOG ( 1 ) ;
}

typedef BOOL (WINAPI *PFNSETCRITSECSPINCOUNT) (
                                   LPCRITICAL_SECTION lpCriticalSection,
                                   DWORD dwSpinCount ) ;

static PFNSETCRITSECSPINCOUNT g_pfnSCSSP = NULL ;

DWORD NAKEDDEF
    DD_SetCriticalSectionSpinCount(LPCRITICAL_SECTION lpCriticalSection,
                                   DWORD dwSpinCount )
{
    HOOKFN_PROLOG ( ) ;

    if ( NULL == g_pfnSCSSP )
    {
        g_pfnSCSSP = (PFNSETCRITSECSPINCOUNT)
            GetProcAddress ( GetModuleHandle ( _T ( "kernel32.DLL" ) ) ,
                             "SetCriticalSectionSpinCount"            );
    }

    if ( NULL != g_pfnSCSSP )
    {
        if ( TRUE == DoLogging ( DDOPT_CRITSEC ) )
        {

            FILL_EVENTINFO ( eSetCriticalSectionSpinCount ) ;

            REAL_FUNC_PRE_CALL ( ) ;
            g_pfnSCSSP ( lpCriticalSection , dwSpinCount );
            REAL_FUNC_POST_CALL ( ) ;

            ProcessEvent ( &stEvtInfo ) ;
        }
        else
        {
            REAL_FUNC_PRE_CALL ( ) ;
            g_pfnSCSSP ( lpCriticalSection , dwSpinCount );
            REAL_FUNC_POST_CALL ( ) ;
        }
    }
    HOOKFN_EPILOG ( 2 ) ;
}

typedef BOOL (WINAPI *PFNTRYENTERCRITSEC)
                              ( LPCRITICAL_SECTION lpCriticalSection ) ;

static PFNTRYENTERCRITSEC g_pfnTECS = NULL ;

BOOL NAKEDDEF
    DD_TryEnterCriticalSection ( LPCRITICAL_SECTION lpCriticalSection )
{
    HOOKFN_PROLOG ( ) ;

    if ( NULL == g_pfnTECS )
    {
        g_pfnTECS = (PFNTRYENTERCRITSEC)
            GetProcAddress ( GetModuleHandle ( _T ( "kernel32.DLL" ) ) ,
                             "TryEnterCriticalSection"                );
    }

    if ( NULL != g_pfnTECS )
    {
        if ( TRUE == DoLogging ( DDOPT_CRITSEC ) )
        {

            FILL_EVENTINFO ( eTryEnterCriticalSection ) ;

            // Record that the thread is about to enter the critical
            //  section.
            stEvtInfo.ePrePost = ePreCall ;

            ProcessEvent ( &stEvtInfo ) ;

            REAL_FUNC_PRE_CALL ( ) ;
            g_pfnTECS ( lpCriticalSection ) ;
            REAL_FUNC_POST_CALL ( ) ;

            // Record that the thread now owns the critical section.
            stEvtInfo.ePrePost = ePostCall ;

            ProcessEvent ( &stEvtInfo ) ;
        }
        else
        {
            REAL_FUNC_PRE_CALL ( ) ;
            g_pfnTECS ( lpCriticalSection ) ;
            REAL_FUNC_POST_CALL ( ) ;
        }
    }
    HOOKFN_EPILOG ( 1 ) ;
}

// Turn optimizations back on.
#pragma optimize( "", on )
