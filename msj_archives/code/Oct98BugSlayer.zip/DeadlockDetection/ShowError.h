/*----------------------------------------------------------------------
       John Robbins - Microsoft Systems Journal Bugslayer Column
----------------------------------------------------------------------*/

#ifndef _SHOWERROR_H
#define _SHOWERROR_H

void ShowFatalError ( HINSTANCE hInst , UINT uiRes , ... ) ;

#endif  // _SHOWERROR_H


