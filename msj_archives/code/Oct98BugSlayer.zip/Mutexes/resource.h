//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by mutexes.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDC_PRIORITYCLASS               100
#define IDS_ABOUTBOX                    101
#define IDC_DSPYTHRDPRIORITY            101
#define IDD_MUTEXES_DIALOG              102
#define IDC_CNTRTHRDPRIORITY            102
#define IDC_PAUSE                       103
#define IDC_SYNCHRONIZE                 104
#define IDC_SHOWCNTRTHRD                105
#define IDC_DATABOX                     106
#define IDR_MAINFRAME                   128

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
