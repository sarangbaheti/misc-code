// PalGen.h : main header file for the PALGEN application
//

#if !defined(AFX_PALGEN_H__76D20305_FD20_11D0_B2D9_444553540000__INCLUDED_)
#define AFX_PALGEN_H__76D20305_FD20_11D0_B2D9_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
    #error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CPalGenApp:
// See PalGen.cpp for the implementation of this class
//

class CPalGenApp : public CWinApp
{
public:
    CPalGenApp();

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CPalGenApp)
    public:
    virtual BOOL InitInstance();
    //}}AFX_VIRTUAL

// Implementation

    //{{AFX_MSG(CPalGenApp)
        // NOTE - the ClassWizard will add and remove member functions here.
        //    DO NOT EDIT what you see in these blocks of generated code !
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PALGEN_H__76D20305_FD20_11D0_B2D9_444553540000__INCLUDED_)
