// PalGenDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Quantize.h"
#include "PalGen.h"
#include "PalGenDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
    CAboutDlg();

// Dialog Data
    //{{AFX_DATA(CAboutDlg)
    enum { IDD = IDD_ABOUTBOX };
    //}}AFX_DATA

    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CAboutDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:
    //{{AFX_MSG(CAboutDlg)
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
    //{{AFX_DATA_INIT(CAboutDlg)
    //}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CAboutDlg)
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
    //{{AFX_MSG_MAP(CAboutDlg)
        // No message handlers
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPalGenDlg dialog

CPalGenDlg::CPalGenDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CPalGenDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CPalGenDlg)
        // NOTE: the ClassWizard will add member initialization here
    //}}AFX_DATA_INIT
    // Note that LoadIcon does not require a subsequent DestroyIcon in Win32
    m_hIcon = AfxGetApp()->LoadStandardIcon(IDI_WINLOGO);
}

void CPalGenDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CPalGenDlg)
    DDX_Control(pDX, IDC_GENERATE, m_wndGenerate);
    DDX_Control(pDX, IDC_SPIN, m_wndSpin);
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPalGenDlg, CDialog)
    //{{AFX_MSG_MAP(CPalGenDlg)
    ON_WM_SYSCOMMAND()
    ON_WM_PAINT()
    ON_WM_QUERYDRAGICON()
    ON_EN_CHANGE(IDC_INPUT, OnChangeInput)
    ON_BN_CLICKED(IDC_GENERATE, OnGeneratePalette)
    ON_BN_CLICKED(IDC_BROWSE1, OnBrowseInput)
    ON_BN_CLICKED(IDC_BROWSE2, OnBrowseOutput)
    //}}AFX_MSG_MAP
    ON_EN_CHANGE(IDC_OUTPUT, OnChangeInput)
    ON_EN_CHANGE(IDC_NUMCOLORS, OnChangeInput)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPalGenDlg message handlers

BOOL CPalGenDlg::OnInitDialog()
{
    CDialog::OnInitDialog();

    // Add "About..." menu item to system menu.

    // IDM_ABOUTBOX must be in the system command range.
    ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
    ASSERT(IDM_ABOUTBOX < 0xF000);

    CMenu* pSysMenu = GetSystemMenu(FALSE);
    if (pSysMenu != NULL)
    {
        CString strAboutMenu;
        strAboutMenu.LoadString(IDS_ABOUTBOX);
        if (!strAboutMenu.IsEmpty())
        {
            pSysMenu->AppendMenu(MF_SEPARATOR);
            pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
        }
    }

    // Set the icon for this dialog.  The framework does this automatically
    //  when the application's main window is not a dialog
    SetIcon(m_hIcon, TRUE);         // Set big icon
    SetIcon(m_hIcon, FALSE);        // Set small icon
    
    SetDlgItemText (IDC_OUTPUT, _T ("Output.pal"));
    SetDlgItemInt (IDC_NUMCOLORS, 236); 
    m_wndSpin.SetRange (8, 1024);

    return TRUE;  // return TRUE  unless you set the focus to a control
}

void CPalGenDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
    if ((nID & 0xFFF0) == IDM_ABOUTBOX)
    {
        CAboutDlg dlgAbout;
        dlgAbout.DoModal();
    }
    else
    {
        CDialog::OnSysCommand(nID, lParam);
    }
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPalGenDlg::OnPaint() 
{
    if (IsIconic())
    {
        CPaintDC dc(this); // device context for painting

        SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

        // Center icon in client rectangle
        int cxIcon = GetSystemMetrics(SM_CXICON);
        int cyIcon = GetSystemMetrics(SM_CYICON);
        CRect rect;
        GetClientRect(&rect);
        int x = (rect.Width() - cxIcon + 1) / 2;
        int y = (rect.Height() - cyIcon + 1) / 2;

        // Draw the icon
        dc.DrawIcon(x, y, m_hIcon);
    }
    else
    {
        CDialog::OnPaint();
    }
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPalGenDlg::OnQueryDragIcon()
{
    return (HCURSOR) m_hIcon;
}

void CPalGenDlg::OnChangeInput() 
{
    if (m_wndGenerate.m_hWnd == NULL)
        return;

    CString strInput, strOutput;
    GetDlgItemText (IDC_INPUT, strInput);
    GetDlgItemText (IDC_OUTPUT, strOutput);
    UINT nColors = GetDlgItemInt (IDC_NUMCOLORS);

    strInput.TrimLeft ();
    strInput.TrimRight ();
    strOutput.TrimLeft ();
    strOutput.TrimRight ();

    if (!strInput.IsEmpty () && !strOutput.IsEmpty () &&
        (nColors >= 8) && (nColors <= 1024))
        m_wndGenerate.EnableWindow (TRUE);
    else
        m_wndGenerate.EnableWindow (FALSE);
}

void CPalGenDlg::OnGeneratePalette() 
{
    //
    // Get user input.
    //
    CString strInput, strOutput;
    GetDlgItemText (IDC_INPUT, strInput);
    GetDlgItemText (IDC_OUTPUT, strOutput);
    UINT nColors = GetDlgItemInt (IDC_NUMCOLORS);

    strInput.TrimLeft ();
    strInput.TrimRight ();
    strOutput.TrimLeft ();
    strOutput.TrimRight ();

    //
    // Prompt before overwriting an existing file.
    //
    WIN32_FIND_DATA fd;
    HANDLE hFind = ::FindFirstFile (strOutput, &fd);

    if (hFind != INVALID_HANDLE_VALUE) {
        CString string;
        string.Format (_T ("Overwrite %s?"), strOutput);
        if (MessageBox (string, _T ("Wait!"), MB_ICONQUESTION |
            MB_YESNO) == IDNO) {
            ::FindClose (hFind);
            return;
        }
    }

    ::FindClose (hFind);

    //
    // Create a quantizer object.
    //
    CQuantizer quantizer (nColors, 6);

    //
    // Quantize the image(s).
    //
    CWaitCursor wait;
    CString strFile = GetNextFileName (&strInput);

    while (!strFile.IsEmpty ()) {
        TRACE (_T ("Processing %s\n"), strFile);
        HANDLE hImage = ::LoadImage (NULL, strFile, IMAGE_BITMAP,
            0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);

        if (hImage == NULL) {
            CString strError;
            strError.Format (_T ("%s could not be opened or does not " \
                "contain a valid BMP image"), strFile);
            MessageBox (strError);
            return;
        }

        if (!quantizer.ProcessImage (hImage)) {
            ::DeleteObject (hImage);
            CString strError;
            strError.Format (_T ("Error quantizing %s"), strFile);
            MessageBox (strError);
            return;
        }

        ::DeleteObject (hImage);
        strFile = GetNextFileName (&strInput);
    }

    wait.Restore ();

    //
    // Build a color table.
    //
    UINT nNumColors = quantizer.GetColorCount ();
    ASSERT (nNumColors <= 1024); // Sanity check
    RGBQUAD* prgb = new RGBQUAD[nNumColors];
    quantizer.GetColorTable (prgb);

    //
    // Output the color table to a file.
    //
    try {
        CFile file (strOutput, CFile::modeCreate | CFile::modeWrite);
        WriteColorOutput (&file, prgb, nNumColors);
    }
    catch (CFileException* e) {
        if (e->m_cause == CFileException::diskFull)
            MessageBox (_T ("Disk full"));
        else if ((e->m_cause == CFileException::badPath) ||
            (e->m_cause == CFileException::fileNotFound) ||
            (e->m_cause == CFileException::accessDenied) ||
            (e->m_cause == CFileException::tooManyOpenFiles))
            MessageBox (_T ("Error creating output file"));
        else
            MessageBox (_T ("Error writing output file"));
        e->Delete ();
    }

    //
    // Clean up and return.
    //
    delete prgb;

    TCHAR szPath[MAX_PATH];
    ::GetFullPathName (strOutput, sizeof (szPath) / sizeof (TCHAR), szPath,
        NULL);

    CString string;
    string.Format (_T ("Finished writing %d colors to %s"), nNumColors,
        szPath);
    MessageBox (string);
}

CString CPalGenDlg::GetNextFileName(CString * pString)
{
    CString strResult = pString->SpanExcluding (_T (";,\t"));
    int nChars = pString->GetLength () - strResult.GetLength () - 1;
    *pString = pString->Right (nChars);
    strResult.TrimLeft ();
    strResult.TrimRight ();
    return strResult;
}

void CPalGenDlg::WriteColorOutput(CFile * pFile, RGBQUAD * prgb,
    UINT nNumColors)
{
    CString string;
    string.Format (_T ("// %d RGB colors\r\n"), nNumColors);
    pFile->Write ((LPCTSTR) string, string.GetLength ());

    if (nNumColors == 0)
        return; // Sanity check

    string.Format ("BYTE byVals[%d][3] = {\r\n", nNumColors);
    pFile->Write ((LPCTSTR) string, string.GetLength ());

    for (UINT i=0; i<nNumColors; i++) {
        CString string;
        if (i != nNumColors - 1)
            string.Format ("\t%3d, %3d, %3d,\r\n",
                prgb[i].rgbRed, prgb[i].rgbGreen, prgb[i].rgbBlue);
        else
            string.Format ("\t%3d, %3d, %3d\r\n",
                prgb[i].rgbRed, prgb[i].rgbGreen, prgb[i].rgbBlue);
        pFile->Write ((LPCTSTR) string, string.GetLength ());
    }
    pFile->Write ("};\r\n", 4);
}

void CPalGenDlg::OnBrowseInput() 
{
    static const TCHAR szFilters[] =
        _T ("BMP Files (*.bmp)|*.bmp|All Files (*.*)|*.*||");

    CFileDialog dlg (TRUE, _T ("bmp"), _T ("*.bmp"), OFN_FILEMUSTEXIST |
        OFN_HIDEREADONLY | OFN_ALLOWMULTISELECT, szFilters, AfxGetMainWnd ());

    if (dlg.DoModal () == IDOK) {
        CString string;
        POSITION pos = dlg.GetStartPosition ();
        while (pos != NULL) {
            CString strFile = dlg.GetNextPathName (pos);
            if (!string.IsEmpty ())
                string += _T ("; ");
            string += strFile;
        }
        SetDlgItemText (IDC_INPUT, string);
    }   
}

void CPalGenDlg::OnBrowseOutput() 
{
    static const TCHAR szFilters[] =
        _T ("PAL Files (*.pal)|*.pal|All Files (*.*)|*.*||");

    CFileDialog dlg (FALSE, _T ("pal"), _T ("*.pal"), OFN_HIDEREADONLY,
        szFilters, AfxGetMainWnd ());

    if (dlg.DoModal () == IDOK) {
        CString string = dlg.GetPathName ();
        SetDlgItemText (IDC_OUTPUT, string);
    }   
}

void CPalGenDlg::OnOK ()
{
    OnGeneratePalette ();
}
