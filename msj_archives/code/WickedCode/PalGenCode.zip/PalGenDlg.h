// PalGenDlg.h : header file
//

#if !defined(AFX_PALGENDLG_H__76D20307_FD20_11D0_B2D9_444553540000__INCLUDED_)
#define AFX_PALGENDLG_H__76D20307_FD20_11D0_B2D9_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CPalGenDlg dialog

class CPalGenDlg : public CDialog
{
// Construction
public:
    CPalGenDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
    //{{AFX_DATA(CPalGenDlg)
    enum { IDD = IDD_PALGEN_DIALOG };
    CButton m_wndGenerate;
    CSpinButtonCtrl m_wndSpin;
    //}}AFX_DATA

    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CPalGenDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL
    virtual void OnOK ();

// Implementation
protected:
    void WriteColorOutput (CFile* pFile, RGBQUAD* prgb, UINT nNumColors);
    CString GetNextFileName (CString* pString);
    HICON m_hIcon;

    // Generated message map functions
    //{{AFX_MSG(CPalGenDlg)
    virtual BOOL OnInitDialog();
    afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
    afx_msg void OnPaint();
    afx_msg HCURSOR OnQueryDragIcon();
    afx_msg void OnChangeInput();
    afx_msg void OnGeneratePalette();
    afx_msg void OnBrowseInput();
    afx_msg void OnBrowseOutput();
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PALGENDLG_H__76D20307_FD20_11D0_B2D9_444553540000__INCLUDED_)
