///////////////////////////////////////////
//
// Printall.cpp - a simple client that prints
//                the result of a select statement
//

#define OLEDBVER 0x0250 
#define _WIN32_DCOM
#include <windows.h>
#include <stdio.h>
#include <oledb.h>
#include <msdasc.h>

#include <atlbase.h>
CComModule _Module;
#include <atlcom.h>

// some helper macros
#define CELEMS(rg) (sizeof(rg)/sizeof(*(rg)))
#define sizeofmember(T, m) sizeof( (((T*)16)->m) )

// client representation of a row
struct CUSTOMER
{
    CUSTOMER() { *id = *lname = *fname = 0; }
    TCHAR id[9];
    TCHAR lname[33];
    TCHAR fname[33];
};

// description of CUSTOMER representation
DBBINDING rgBindings[] =
{
    { 1, offsetof(CUSTOMER, id), 0, 0, 0, 0, 0, DBPART_VALUE, 
        DBMEMOWNER_CLIENTOWNED, 0, sizeofmember(CUSTOMER, id), 
        0, DBTYPE_STR, 0, 0 },
    { 2, offsetof(CUSTOMER, fname), 0, 0, 0, 0, 0, DBPART_VALUE, 
        DBMEMOWNER_CLIENTOWNED, 0, sizeofmember(CUSTOMER, fname), 
        0, DBTYPE_STR, 0, 0 },
    { 3, offsetof(CUSTOMER, lname), 0, 0, 0, 0, 0, DBPART_VALUE, 
        DBMEMOWNER_CLIENTOWNED, 0, sizeofmember(CUSTOMER, lname), 
        0, DBTYPE_STR, 0, 0 },
};

#define HR(exp) { HRESULT _hr = (exp); if (FAILED(_hr)) return _hr; }

HRESULT PrintAll(const OLECHAR *pwszInitString)
{
// load and initialize the provider
    CComPtr<IDataInitialize> pdi;
    HR(CoCreateInstance(__uuidof(MSDAINITIALIZE), 0, CLSCTX_ALL, __uuidof(pdi), (void**)&pdi));

    CComPtr<IDBInitialize> dbInit;
    HR(pdi->GetDataSource(0, CLSCTX_ALL, pwszInitString, 
                          __uuidof(dbInit), (IUnknown**)&dbInit));
    HR(dbInit->Initialize());

// create a new command with our select statement
    CComPtr<IDBCreateSession> cs;
    HR(dbInit->QueryInterface(&cs));

    CComPtr<IDBCreateCommand> cc;
    HR(cs->CreateSession(0, __uuidof(cc), (IUnknown**)&cc));
    
    CComPtr<ICommandText> cmd;
    HR(cc->CreateCommand(0, __uuidof(cmd), (IUnknown**)&cmd));
    HR(cmd->SetCommandText(DBGUID_DEFAULT, L"select * from customers"));

// squirt the SQL down to the database and get back a rowset object
    CComPtr<IRowset> rs;
    HR(cmd->Execute(0, __uuidof(rs), 0, 0, (IUnknown**)&rs));

// create an accessor for CUSTOMER
    CComPtr<IAccessor> acc;
    HR(rs->QueryInterface(&acc));

    DBSTATUS rgStatus[CELEMS(rgBindings)];
    HACCESSOR hAccessor;
    HR(acc->CreateAccessor(DBACCESSOR_ROWDATA, CELEMS(rgBindings), 
                           rgBindings, sizeof(CUSTOMER), 
                           &hAccessor, rgStatus));

// walk through the rowset and print each row
    bool bDone = false;
    HRESULT hr = S_OK;
    while (!bDone)
    {
        const int CHUNKSIZE = 5;
        HROW *prgRows = 0;
        ULONG cRows;
// fetch CHUNKSIZE rows into provider's buffer
        hr = rs->GetNextRows(0, 0, CHUNKSIZE, &cRows, &prgRows);
        if (hr != S_OK)
            bDone = true;
        if (SUCCEEDED(hr))
        {
            for (ULONG i = 0; SUCCEEDED(hr) && i < cRows; i++)
            {
// copy row into client buffer (record) and print
                CUSTOMER record;
                hr = rs->GetData(prgRows[i], hAccessor, &record);
                if (FAILED(hr))
                    bDone = true;
                else
                    printf("%s: %s %s\n", record.id, 
                           record.fname, record.lname);
            }
// clean up
            rs->ReleaseRows(cRows, prgRows, 0, 0, 0);
            CoTaskMemFree(prgRows);
        }
    }
    acc->ReleaseAccessor(hAccessor, 0);
    return hr;
}


int main(int argc, char **argv)
{
    HRESULT hr = CoInitializeEx(0, 0);
    if (SUCCEEDED(hr))
    {
        hr = PrintAll(L""PROVIDER=SQLOLEDB;DATABASE=bob;UID=sa;PWD=");
        CoUninitialize();
    }
    return hr;
}
