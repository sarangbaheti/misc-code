#define _WIN32_WINNT 0x403
#include <windows.h>
#include "..\delegate.h"
#include "..\delegate_i.c"
#include "test.h"
#include "test_i.c"
#include <stdio.h>

// Here are the three things you can screw around with
// to test various features of the delegator.
// Note that during the cross-apartment test, you can
// significantly improve performance if you either make
// the object apartment neutral, or have the delegator
// maintain identity. Both these mechanisms keep the
// delegator from propagating itself to an apartment
// where its counterpart (same identity) already lives.
// This is kind of a wierd case though, so don't assume
// that using either of these options will generally
// give you better performance. Think about your situation
// and do some tests to figure out what's best for you.

// We either marshal into the GIT, or via CoMarshalInterThreadInterfaceInStream.
const bool g_bMarshalIntoGIT		= false;

// CoFoo can aggregate the FTM if you like (the delegator watches for this).
const bool g_bUseAptNeutralObject	= false;

// The delegator can maintain COM identity during MBV if you like.
const bool g_bMaintainIdentity		= false;

struct CoFoo : IFoo
{
	long m_cRefs;
	IUnknown* m_pFTM;
	IFoo* m_pWrappedFoo;

	CoFoo() : m_cRefs(0), m_pFTM(0), m_pWrappedFoo(0) {}
	~CoFoo() { printf( "CoFoo destroyed.\n" ); if ( m_pFTM ) m_pFTM->Release(); }
	STDMETHODIMP QueryInterface( REFIID iid, void** ppv )
	{
		if ( IID_IUnknown == iid )
			*ppv = static_cast<IFoo*>( this );
		else if ( IID_IFoo == iid )
			*ppv = static_cast<IFoo*>( this );
		else if ( ( IID_IMarshal == iid ) && g_bUseAptNeutralObject )
		{
			if ( !m_pFTM )
				CoCreateFreeThreadedMarshaler( (IFoo*)this, &m_pFTM );
			return m_pFTM->QueryInterface( iid, ppv );
		}
		else return (*ppv = 0), E_NOINTERFACE;
		reinterpret_cast<IUnknown*>(*ppv)->AddRef();
		return S_OK;
	}
	STDMETHODIMP_(ULONG) AddRef()
	{
		return InterlockedIncrement( &m_cRefs );
	}

	STDMETHODIMP_(ULONG) Release()
	{
		ULONG n = InterlockedDecrement( &m_cRefs );
		if ( 0 == n )
			delete this;
		return n;
	}

	STDMETHODIMP MethodOne( long n )
	{
		printf( "MethodOne( %d );\n", n );
		return S_OK;
	}
	STDMETHODIMP Recurse( long nDepth, IFoo* pFoo )
	{
		printf( "%d: Recurse( %d );\n", GetCurrentThreadId(), nDepth );
		if ( 0 == nDepth )
			return S_OK;
		return pFoo->Recurse( nDepth - 1, m_pWrappedFoo );
	}
};

// Here's a very simple hook that supports pre/post processing
struct __declspec(uuid("780cac30-37d3-11d2-a7d7-006008d25ccf"))
	CoHookQI : IDelegatorHookQI, IDelegatorHookMethods, IPersist
{
	long m_cRefs;
	CoHookQI() : m_cRefs(0) {}
	~CoHookQI() { printf( "CoHookQI destroyed.\n" ); }
	STDMETHODIMP QueryInterface( REFIID iid, void** ppv )
	{
		if ( IID_IUnknown == iid )
			*ppv = static_cast<IDelegatorHookQI*>( this );
		else if ( IID_IDelegatorHookQI == iid )
			*ppv = static_cast<IDelegatorHookQI*>( this );
		else if ( IID_IDelegatorHookMethods == iid )
			*ppv = static_cast<IDelegatorHookMethods*>( this );
		else if ( IID_IPersist == iid )
			*ppv = static_cast<IPersist*>( this );
		else return (*ppv = 0), E_NOINTERFACE;
		reinterpret_cast<IUnknown*>(*ppv)->AddRef();
		return S_OK;
	}
	STDMETHODIMP_(ULONG) AddRef()
	{
		return InterlockedIncrement( &m_cRefs );
	}

	STDMETHODIMP_(ULONG) Release()
	{
		ULONG n = InterlockedDecrement( &m_cRefs );
		if ( 0 == n )
			delete this;
		return n;
	}
	STDMETHODIMP Init( IUnknown* )
	{
		wprintf( L"IDelegatorHookQI::Init()\n" );
		return S_OK;
	}
	STDMETHODIMP OnFirstDelegatorQIFor( REFIID iid,
								   IUnknown* pItfInner,
								   DWORD* pgrfDelegatorHookOptions,
								   REFIID iidMethodHook, void** ppvMethodHook )
	{
		*pgrfDelegatorHookOptions = DHO_PREPROCESS_METHODS | DHO_POSTPROCESS_METHODS;
		wchar_t sz[80];
		StringFromGUID2( iid, sz, sizeof sz / sizeof *sz );
		wprintf( L"OnFirstDelegatorQIFor( %s )\n", sz );
		return QueryInterface( iidMethodHook, ppvMethodHook );
	}

	STDMETHODIMP_(void) DelegatorPreprocess( DWORD nVtblIndex,
											void* pArgs,
											DWORD* pnCookie )
	{
		printf( "DelegatorPreprocess( %d )\n", nVtblIndex );
	}

	STDMETHODIMP DelegatorPostprocess( DWORD nVtblIndex,
									  HRESULT hrFromInner,
									  DWORD nCookie )
	{
		printf( "DelegatorPostprocess( hr = %x, vtbl index = %d )\n", hrFromInner, nVtblIndex );
		return S_OK;
	}
	STDMETHODIMP GetClassID( CLSID* pclsid )
	{
		*pclsid = __uuidof( CoHookQI );
		return S_OK;
	}
};


// Simple class factory for above hook
struct CoHookQICF : IClassFactory
{
	STDMETHODIMP QueryInterface( REFIID iid, void** ppv )
	{
		if ( IID_IUnknown == iid )
			*ppv = static_cast<IClassFactory*>( this );
		else if ( IID_IClassFactory == iid )
			*ppv = static_cast<IClassFactory*>( this );
		else return (*ppv = 0), E_NOINTERFACE;
		reinterpret_cast<IUnknown*>(*ppv)->AddRef();
		return S_OK;
	}
	STDMETHODIMP_(ULONG) AddRef()
	{
		return 2;
	}

	STDMETHODIMP_(ULONG) Release()
	{
		return 1;
	}

	STDMETHODIMP CreateInstance( IUnknown*, REFIID iid, void** ppv )
	{
		CoHookQI* pObj = new CoHookQI;
		pObj->AddRef();
		HRESULT hr = pObj->QueryInterface( iid, ppv );
		pObj->Release();
		return hr;
	}
	STDMETHODIMP LockServer( BOOL )
	{
		return S_OK;
	}
};

CoHookQICF g_cf;
IDelegatorFactory* g_pFactory = 0;

IUnknown* CreateWrappedFoo()
{
	IUnknown* pUnkHook = 0;
	CoCreateInstance( __uuidof(CoHookQI), 0, CLSCTX_INPROC_SERVER, IID_IUnknown, (void**)&pUnkHook );
	CoFoo* pFoo = new CoFoo;
	pFoo->AddRef();
	IUnknown* pUnk = 0;
	DWORD grfOptions = DO_MBV_INPROC;
	if ( g_bMaintainIdentity )
		grfOptions |= DO_MAINTAIN_IDENTITY;
	HRESULT hr = g_pFactory->CreateDelegator( 0, pFoo, 0, pUnkHook,  grfOptions, IID_IUnknown, (void**)&pUnk );
	pFoo->Release();
	pUnkHook->Release();
	pUnk->QueryInterface( IID_IFoo, (void**)&pFoo->m_pWrappedFoo );

	return pUnk;
}

DWORD WINAPI ThreadProc( void* pv )
{
	CoInitialize(0);
	DWORD nCookie = 0;
	CoRegisterClassObject( __uuidof( CoHookQI ), &g_cf, CLSCTX_INPROC_SERVER, REGCLS_MULTIPLEUSE, &nCookie );
	const DWORD gitCookie = g_bMarshalIntoGIT ? *(DWORD*)pv : 0;
	IUnknown* pUnk = 0;
	HRESULT hr = S_OK;
	IGlobalInterfaceTable* pgit = 0;
	if ( g_bMarshalIntoGIT )
		 hr = CoCreateInstance( CLSID_StdGlobalInterfaceTable, 0, CLSCTX_INPROC_SERVER, IID_IGlobalInterfaceTable, (void**)&pgit );
    else hr = CoGetInterfaceAndReleaseStream( (IStream*)pv, IID_IUnknown, (void**)&pUnk );
	if ( SUCCEEDED( hr ) )
	{
		if ( !g_bMarshalIntoGIT ||
			SUCCEEDED( pgit->GetInterfaceFromGlobal( gitCookie, IID_IUnknown, (void**)&pUnk ) ) )
		{
			IFoo* pFoo = 0;
			hr = pUnk->QueryInterface( IID_IFoo, (void**)&pFoo );
			if ( SUCCEEDED( hr ) )
			{
				pFoo->MethodOne( 5 );
				
				// create an object in this apartment
				IUnknown* pUnk = CreateWrappedFoo();
				if ( pUnk )
				{
					IFoo* pFoo2 = 0;
					if ( SUCCEEDED( pUnk->QueryInterface( IID_IFoo, (void**)&pFoo2 ) ) )
					{
						// tests cross-apartment recursion
						pFoo->Recurse( 1000, pFoo2 );
						pFoo2->Release();
					}
					pUnk->Release();
				}
				pFoo->Release();
			}
			pUnk->Release();
			if ( g_bMarshalIntoGIT )
			{
				pgit->RevokeInterfaceFromGlobal( gitCookie );
				pgit->Release();
			}
		}
	}
	CoRevokeClassObject( nCookie );
	CoUninitialize();
	return 0;
}

void TestDelegator()
{
	DWORD nCookie = 0;
	CoRegisterClassObject( __uuidof( CoHookQI ), &g_cf, CLSCTX_INPROC_SERVER, REGCLS_MULTIPLEUSE, &nCookie );

	IUnknown* pUnk = CreateWrappedFoo();
	if ( pUnk )
	{
		IFoo* pFoo = 0;
		HRESULT hr = pUnk->QueryInterface( IID_IFoo, (void**)&pFoo );
		if ( SUCCEEDED( hr ) )
		{
			pFoo->MethodOne( 5 );
			pFoo->Recurse( 10, pFoo );	// intra-apartment recursion
			pFoo->Release();
		}

		IGlobalInterfaceTable* pgit = 0;
		IStream* pstm = 0;
		if ( g_bMarshalIntoGIT )
			 hr = CoCreateInstance( CLSID_StdGlobalInterfaceTable, 0, CLSCTX_INPROC_SERVER, IID_IGlobalInterfaceTable, (void**)&pgit );
		else hr = CoMarshalInterThreadInterfaceInStream( IID_IUnknown, pUnk, &pstm );
		if ( SUCCEEDED( hr ) )
		{
			DWORD gitCookie = 0;
			HANDLE ht = 0;
			if ( g_bMarshalIntoGIT )
			{
				pgit->RegisterInterfaceInGlobal( pUnk, IID_IUnknown, &gitCookie );
				ht = CreateThread( 0, 0, ThreadProc, &gitCookie, 0, 0 );
				pgit->Release();
				pgit = 0;
			}
			else
			{
				ht = CreateThread( 0, 0, ThreadProc, pstm, 0, 0 );
				pstm = 0;
			}
			if ( ht )
			{
				bool bDone = false;
				while ( !bDone )
				{
					// service the message queue until the thread is finished
					MSG msg;
					if ( WAIT_OBJECT_0 == MsgWaitForMultipleObjects( 1, &ht, FALSE, INFINITE, QS_ALLINPUT ) )
						bDone = true;
					while( PeekMessage( &msg, 0, 0, 0, PM_REMOVE ) )
						DispatchMessage( &msg );

				}
				CloseHandle( ht );
			}
		}
		pUnk->Release();
	}
	CoRevokeClassObject( nCookie );
}

void main()
{
	CoInitialize(0);

	HRESULT hr = CoGetClassObject( CLSID_CoDelegator, CLSCTX_INPROC_SERVER, 0,
									IID_IDelegatorFactory, (void**)&g_pFactory );
	if ( SUCCEEDED( hr ) )
	{
		TestDelegator();
		g_pFactory->Release();
	}
	CoUninitialize();
}
