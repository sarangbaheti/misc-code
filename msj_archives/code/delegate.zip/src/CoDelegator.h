/////////////////////////////////////////////////////////////
// CoDelegator.h - Generic Delegator Component
//
// Copyright 1998, Keith Brown
//
// The CoDelegator class implements a standard non-delegating
// unknown and caches interface pointers lazily as they
// are asked for by the outer object.
// Each new interface pointer is wrapped by a Delegator
// object and refcounted individually, until the refcount
// on the interface drops to zero, at which time it is
// released and removed from the collection.
/////////////////////////////////////////////////////////////
#ifndef _CODELEGATOR_H
#define _CODELEGATOR_H

#include "delegator.h"

struct CallContext
{
	CallContext()
	  : m_pDelegator( 0 ),
	    m_pReturnAddr( 0 ),
		m_nCookie( 0 ),
		m_nVtblOffset( 0 )
	{}
	CallContext( Delegator& d, const void* pReturnAddr, DWORD nVtblOffset )
	  : m_pDelegator( &d ),
		m_pReturnAddr( pReturnAddr ),
		m_nCookie( 0 ),
		m_nVtblOffset( nVtblOffset )
	{}
	Delegator*	m_pDelegator;
	const void* m_pReturnAddr;
	DWORD		m_nCookie;
	DWORD		m_nVtblOffset;
};

//---------------------------------------------------------------------------//
// CoDelegator is an aggregatable component that assimilates a child object
// and exposes all the child's interfaces via a thunking wrapper.
// The effect is that a non-aggregatable object (perhaps even an out-of-proc
// object) can be aggregated by using CoDelegator as a shim. Another use might
// be to dynamically aggregate an existing object (direct aggregation requires
// you to *construct* the object passing the outer unknown).
//
// The motivation for creating CoDelegator was to automate handler marshaling
// by allowing a custom handler to aggregate on the standard proxy.
//
// The space complexity for this object is as follows:
//		 52 bytes for a non-delegating IUnknown
//	plus 28 bytes per custom interface in use.
//	  
// The time complexity for this object is as follows:
//		Non-Delegating Unknown:
//			Zero overhead for QI on cached interfaces
//			O(N) overhead for QI on non-cached interfaces
//			Zero overhead for AddRef/Release,
//				except for final release, which is O(N)
//		Delegating Unknown
//			Zero overhead
//		Assimilated interface methods
//			O(1) overhead per method call (about 14 assembly instructions on x86)
//
class CoDelegator : public IMarshal
{
	friend struct Delegator;
public:
	CoDelegator( IUnknown* pUnkOuter, IUnknown* pUnkInner,
				 IDelegatorHookQI* pHook, DWORD grfOptions );
	~CoDelegator();

	bool RemoveDelegatorIfNoRefs( Delegator* pDelegator );
	IUnknown* GetOuter() { return m_pUnkOuter; }
	IUnknown* GetInner() { return m_pUnkInner; }
	bool NoRefs() { return 0 == m_cRefs; }

	static CallContext* PushNewCallContext( Delegator& d,
											const void* pReturnAddr,
											DWORD nVtblOffset );
	static CallContext* PopCallContext();
	static void DeleteCallContext( CallContext* pcc );

	// allow initialization and cleanup of static state
	static bool Startup();
	static void Shutdown();

	enum { DMSH_SERIALIZED_HOOK_STATE	= 0x00000001,
		   DMSH_INNER_IN_GIT			= 0x00000002 };

	enum { INTERNALFLAGS_USEFTM			= 0x80000000 };

	STDMETHODIMP QueryInterface( REFIID iid, void** ppv );
	STDMETHODIMP_(ULONG) AddRef();
	STDMETHODIMP_(ULONG) Release();

	STDMETHODIMP GetUnmarshalClass( REFIID iid, void* pv, DWORD grfDestCtx, void*, DWORD grfMshFlags, CLSID* pClsid );
	STDMETHODIMP GetMarshalSizeMax( REFIID iid, void* pv, DWORD grfDestCtx, void*, DWORD grfMshFlags, ULONG* pcb );
	STDMETHODIMP MarshalInterface( IStream* pstm, REFIID iid, void* pv, DWORD grfDestCtx, void*, DWORD grfMshFlags );
	STDMETHODIMP ReleaseMarshalData( IStream* pstm );
	STDMETHODIMP UnmarshalInterface( IStream* pstm, REFIID iid, void** ppv );
	STDMETHODIMP DisconnectObject( DWORD );

private:
	HRESULT _growArray();
	bool _findDelegator( REFIID iid, Delegator*& pDelegator, HRESULT& hr );
	bool _mbvInThisContext( DWORD nDestCtx );	
	void _checkForFTM();
	static bool _lazyAllocTLSIndex();

	class Lock
	{
	public:
		Lock( CoDelegator& obj )
		  : m_obj( obj )
		{ EnterCriticalSection( &m_obj.m_sect ); }
		~Lock() { LeaveCriticalSection( &m_obj.m_sect ); }
	private:
		CoDelegator& m_obj;
	};
	friend class Lock;

	struct LinkedCallContext : CallContext
	{
		LinkedCallContext()
		  : CallContext(),
		    m_pNext( 0 )
		{}
		LinkedCallContext( Delegator& d, const void* pReturnAddr, DWORD nVtblOffset, LinkedCallContext* pNext )
		  : CallContext( d, pReturnAddr, nVtblOffset ),
		    m_pNext ( pNext )
		{}
		LinkedCallContext* m_pNext;
	};

	enum { INITIAL_CAPACITY = 3 };

	long				m_cRefs;
	IUnknown*			m_pUnkOuter;
	IUnknown*			m_pUnkInner;
	IDelegatorHookQI*	m_pHook;
	DWORD				m_grf;
	Delegator**			m_first;
	Delegator**			m_last;
	Delegator**			m_end;
	CRITICAL_SECTION	m_sect;				// 24 bytes

	static DWORD				s_nTLSIndex;
	static CRITICAL_SECTION		s_sect;
	static LinkedCallContext*	s_pHeadCtx;
	static LinkedCallContext*   s_pCachedCtx;
};

#endif // _CODELEGATOR_H