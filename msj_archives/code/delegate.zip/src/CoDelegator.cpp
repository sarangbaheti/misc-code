/////////////////////////////////////////////////////////////
// CoDelegator.cpp - Generic Delegator Component
//
// Copyright 1998, Keith Brown
//
// The CoDelegator class implements a standard non-delegating
// unknown and caches interface pointers lazily as they
// are asked for by the outer object.
// Each new interface pointer is wrapped by a Delegator
// object and refcounted individually, until the refcount
// on the interface drops to zero, at which time it is
// removed from the collection.
/////////////////////////////////////////////////////////////
#include "precomp.h"
#include "CoDelegator.h"
#include "Delegator.h"
#include "Unmarshaler.h"
#include "FixedAllocator.h"
#include "crt.h"

struct __declspec(uuid("0000001C-0000-0000-C000-000000000046")) FTM;

DWORD CoDelegator::s_nTLSIndex = 0xFFFFFFFF;
CRITICAL_SECTION CoDelegator::s_sect;
CoDelegator::LinkedCallContext* CoDelegator::s_pHeadCtx;
CoDelegator::LinkedCallContext* CoDelegator::s_pCachedCtx;
FixedAllocator s_lccAlloc;

//---------------------------------------------------------------------------//
CoDelegator::CoDelegator( IUnknown* pUnkOuter, IUnknown* pUnkInner,
						  IDelegatorHookQI* pHook, DWORD grfOptions )
  : m_cRefs( 0 ),
	m_pUnkOuter( pUnkOuter ),
	m_pUnkInner( pUnkInner ),
	m_pHook( pHook ),
	m_grf( grfOptions ),
	m_first( 0 ),
	m_last( 0 ),
	m_end( 0 )
{
	if ( !m_pUnkOuter )
		m_pUnkOuter = this;

	InitializeCriticalSection( &m_sect );
	m_pUnkInner->AddRef();
	if ( m_pHook )
		m_pHook->AddRef();

	// For efficiency when using MBV inproc, discover whether the
	// inner object is relying on the FTM. If so, we'll also use
	// the FTM to make the most efficient use of the GIT, etc.
	// If so, _checkForFTM sets the INTERNALFLAGS_USEFTM bit in m_grf.
	if ( DO_MBV_INPROC & grfOptions )
		_checkForFTM();
}

//---------------------------------------------------------------------------//
CoDelegator::~CoDelegator()
{
	for ( Delegator** it = m_first; it != m_last; ++it )
		delete *it;
	delete [] m_first;

	if ( m_pHook )
		m_pHook->Release();
	m_pUnkInner->Release();
	DeleteCriticalSection( &m_sect );
}

//---------------------------------------------------------------------------//
bool CoDelegator::RemoveDelegatorIfNoRefs( Delegator* pDelegator )
{
	Lock lock( *this );

	// The Delegator's refcount transitioned to zero, but it's possible
	// that another thread could have QI'd for the same interface
	// before we acquired the lock above. To code below avoids acquiring
	// the lock during every Release() call, which would be expensive.
	// Thanks to Geoff Outhred (DCOM-list member) for catching the race.
	if ( 0 == pDelegator->m_cRefs )
	{
		for ( Delegator** it = m_first; m_last != it; ++it )
		{
			if ( *it == pDelegator )
			{
				while ( ++it != m_last )
					*(it - 1) = *it;
				--m_last;
				return true;
			}
		}
	}
	return false;
}

//---------------------------------------------------------------------------//
bool CoDelegator::Startup()
{
	InitializeCriticalSection( &s_sect );
	return s_lccAlloc.Startup( sizeof LinkedCallContext, 10 );
}

//---------------------------------------------------------------------------//
void CoDelegator::Shutdown()
{
	s_lccAlloc.Shutdown();
	DeleteCriticalSection( &s_sect );
}

//---------------------------------------------------------------------------//
CallContext* CoDelegator::PushNewCallContext( Delegator& d,
	const void* pReturnAddr, DWORD nVtblOffset )
{

	EnterCriticalSection( &s_sect );
	void* pBuf = s_lccAlloc.Alloc();
	CallContext* pCtx = 0;
	if ( pBuf )
	{
		LinkedCallContext* pHead = reinterpret_cast<LinkedCallContext*>( TlsGetValue( s_nTLSIndex ) );
		pCtx = new( pBuf ) LinkedCallContext( d, pReturnAddr, nVtblOffset, pHead );
		TlsSetValue( s_nTLSIndex, pCtx );
	}
	LeaveCriticalSection( &s_sect );
	return pCtx;
}

//---------------------------------------------------------------------------//
CallContext* CoDelegator::PopCallContext()
{
	// Pops are guaranteed to balance pushes, so no need for runtime checks
	EnterCriticalSection( &s_sect );
	LinkedCallContext* pHead = reinterpret_cast<LinkedCallContext*>( TlsGetValue( s_nTLSIndex ) );
	TlsSetValue( s_nTLSIndex, pHead->m_pNext );
	LeaveCriticalSection( &s_sect );
	return pHead;
}

//---------------------------------------------------------------------------//
void CoDelegator::DeleteCallContext( CallContext* pcc )
{
	EnterCriticalSection( &s_sect );
	s_lccAlloc.Free( static_cast<LinkedCallContext*>( pcc ) );
	LeaveCriticalSection( &s_sect );
}

//---------------------------------------------------------------------------//
HRESULT CoDelegator::_growArray()
{
	size_t capacity = 2 * (m_end - m_first);
	if ( 0 == capacity )	
		capacity = INITIAL_CAPACITY;
	
	Delegator** first = new Delegator*[capacity];
	if ( !first )
		return E_OUTOFMEMORY;
	
	Delegator** dest = first;
	for ( Delegator** it = m_first; it != m_last; ++it )
		*dest++ = *it;

	m_last = first + (m_last - m_first);
	m_end = first + capacity;
	delete m_first;
	m_first = first;
	
	return S_OK;
}

//---------------------------------------------------------------------------//
bool CoDelegator::_findDelegator( REFIID iid, Delegator*& pDelegator, HRESULT& hr )
{
	hr = S_OK;

	for ( Delegator** it = m_first; it != m_last; ++it )
	{
		if ( (*it)->m_iid == iid )
		{
			if ( Delegator::DONT_EXPOSE_FROM_QI & (*it)->m_grf )
				 hr = E_NOINTERFACE;
			else pDelegator = *it;
			return true;
		}
	}
	return false;
}

//---------------------------------------------------------------------------//
bool CoDelegator::_mbvInThisContext( DWORD nDestCtx )
{
	switch ( nDestCtx )
	{
		case MSHCTX_INPROC:				return ( m_grf & DO_MBV_INPROC ) ? true : false;
		case MSHCTX_LOCAL:				// fall through
		case MSHCTX_NOSHAREDMEM:		return ( m_grf & DO_MBV_LOCAL ) ? true : false;
		case MSHCTX_DIFFERENTMACHINE:	return ( m_grf & DO_MBV_DIFFERENTMACHINE ) ? true : false;
	}
	return false;
}

//---------------------------------------------------------------------------//
void CoDelegator::_checkForFTM()
{
	IMarshal* pMsh = 0;
	if ( SUCCEEDED( m_pUnkInner->QueryInterface( IID_IMarshal, (void**)&pMsh ) ) )
	{
		CLSID clsid;
		if ( SUCCEEDED( pMsh->GetUnmarshalClass( IID_IUnknown, m_pUnkInner,
			MSHCTX_INPROC, 0, MSHLFLAGS_NORMAL, &clsid ) ) )
		{
			if ( __uuidof( FTM ) == clsid )
				m_grf |= INTERNALFLAGS_USEFTM;
		}
		pMsh->Release();
	}
}

//---------------------------------------------------------------------------//
bool CoDelegator::_lazyAllocTLSIndex()
{
	bool bResult = true;
	if ( 0xFFFFFFFF == s_nTLSIndex )
	{
		s_nTLSIndex = TlsAlloc();
		if ( 0xFFFFFFFF == s_nTLSIndex )
			 bResult = false;
		else TlsSetValue( s_nTLSIndex, 0 );
	}
	return bResult;
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoDelegator::QueryInterface( REFIID iid, void** ppv )
{
	// we subsume the identity of the inner
	if ( IID_IUnknown == iid )
	{
		((IUnknown*)(*ppv = (IUnknown*)this))->AddRef();
		return S_OK;
	}
	else if ( ( IID_IMarshal == iid ) && ( DO_MBV_ALL & m_grf ) )
	{
		((IUnknown*)(*ppv = (IMarshal*)this))->AddRef();
		return S_OK;
	}
	*ppv = 0;

	Lock lock( *this );

	// see if we've already assimilated the requested interface
	HRESULT hr = S_OK;
	{
		Delegator* pDelegator = 0;
		if ( _findDelegator( iid, pDelegator, hr ) )
		{
			if ( SUCCEEDED( hr ) )
				reinterpret_cast<IUnknown*>( *ppv = pDelegator )->AddRef();
			return hr;
		}
	}

	// go get the requested interface from the inner and assimilate it.
	IUnknown* pUnkInner = 0;
	hr = m_pUnkInner->QueryInterface( iid, (void**)&pUnkInner );
	if ( SUCCEEDED( hr ) )
	{
		DWORD grfOptions = 0;
		IDelegatorHookMethods* pHookMethods = 0;
		if ( m_pHook )
		{
			hr = m_pHook->OnFirstDelegatorQIFor( iid, pUnkInner,
												 &grfOptions,
												 IID_IDelegatorHookMethods,
												 (void**)&pHookMethods );
			if ( SUCCEEDED( hr ) )
			{
				// watch for invalid results from QI hook
				grfOptions = grfOptions & 0x00000007;
				if ( ( 0 == grfOptions ) && pHookMethods )
				{
					pHookMethods->Release();
					pHookMethods = 0;
				}
			}
			else if ( E_NOINTERFACE == hr )
			{
				// we only give the QI hook *one* chance to say this
				// to a particular interface so that we help maintain a
				// correct implementation of QI.
				grfOptions = Delegator::DONT_EXPOSE_FROM_QI;
				hr = S_OK;
			}

			// if postprocessing is required, make sure we've acquired a TLS slot
			if ( SUCCEEDED( hr )
				&& ( DHO_POSTPROCESS_METHODS & grfOptions )
				&& !_lazyAllocTLSIndex() )
			{
				hr = E_OUTOFMEMORY;	// sort of :-)
				if ( pHookMethods )
				{
					pHookMethods->Release();
					pHookMethods = 0;
				}
			}
		}

		if ( SUCCEEDED( hr ) )
		{
			// grow the array if necessary
			if ( m_last == m_end )
				hr = _growArray();
			
			if ( SUCCEEDED( hr ) )
			{
				Delegator* pDelegator = new Delegator( *this, pUnkInner, iid,
														grfOptions, pHookMethods );
				if ( pDelegator )
				{
					*m_last++ = pDelegator;
					if ( Delegator::DONT_EXPOSE_FROM_QI & grfOptions )
						 hr = E_NOINTERFACE;
					else ((IUnknown*)(*ppv = pDelegator))->AddRef();
				}
				else hr = E_OUTOFMEMORY;
			}
			if ( pHookMethods )
				pHookMethods->Release();
		}
		pUnkInner->Release();
	}
	return hr;
}

//---------------------------------------------------------------------------//
STDMETHODIMP_(ULONG) CoDelegator::AddRef()
{
	extern void SvcLock();
	if ( 0 == m_cRefs )
		SvcLock();
	return InterlockedIncrement( &m_cRefs );
}

//---------------------------------------------------------------------------//
STDMETHODIMP_(ULONG) CoDelegator::Release()
{
	extern void SvcUnlock();
	ULONG n = InterlockedDecrement( &m_cRefs );
	if ( 0 == n )
	{
		delete this;
		SvcUnlock();
	}
	return n;
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoDelegator::GetUnmarshalClass( REFIID iid, void* pItf,
	DWORD nDestCtx, void* pvCtx, DWORD grfMshFlags, CLSID* pClsid )
{
	if ( !pClsid )
		return E_POINTER;

	if ( _mbvInThisContext( nDestCtx ) )
	{
		// Use FTM if inner is apartment neutral
		if ( ( MSHCTX_INPROC == nDestCtx ) && ( m_grf & INTERNALFLAGS_USEFTM ) )
		{
			*pClsid = __uuidof( FTM );
			return S_OK;
		}
		*pClsid = __uuidof( Unmarshaler );
		return S_OK;
	}

	// We obey iid_is, so the following block determines which pointer we will marshal
	HRESULT hr = S_OK;
	IUnknown* pUnkInner = 0; // don't need to release this local var
	if ( IID_IUnknown == iid )
		pUnkInner = m_pUnkInner;
	else
	{
		Delegator* pDelegator = 0;
		Lock lock( *this );
		if ( !_findDelegator( iid, pDelegator, hr ) )
			return E_UNEXPECTED; // should never be asked to marshal an unknown ptr
		pUnkInner = pDelegator->m_pUnkInner;
	}
	if ( FAILED( hr ) )
		return hr;

	IMarshal* pMsh = 0;
	hr = m_pUnkInner->QueryInterface( IID_IMarshal, (void**)&pMsh );
	if ( FAILED( hr ) )
		hr = CoGetStandardMarshal( iid, pUnkInner, nDestCtx, pvCtx, grfMshFlags, &pMsh );
	if ( FAILED( hr ) )
		return hr;
	hr = pMsh->GetUnmarshalClass( iid, pUnkInner, nDestCtx, pvCtx, grfMshFlags, pClsid );
	pMsh->Release();

	return hr;
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoDelegator::GetMarshalSizeMax( REFIID iid, void* pItf,
	DWORD nDestCtx, void* pvCtx, DWORD grfMshFlags, ULONG* pcb )
{
	if ( !pcb )
		return E_POINTER;

	// We obey iid_is, so the following block determines which pointer we will marshal
	HRESULT hr = S_OK;
	IUnknown* pUnkInner = 0; // don't need to release this local var
	if ( IID_IUnknown == iid )
		pUnkInner = m_pUnkInner;
	else
	{
		Delegator* pDelegator = 0;
		Lock lock( *this );
		if ( !_findDelegator( iid, pDelegator, hr ) )
			return E_UNEXPECTED; // should never be asked to marshal an unknown ptr
		pUnkInner = pDelegator->m_pUnkInner;
	}
	if ( FAILED( hr ) )
		return hr;

	if ( !_mbvInThisContext( nDestCtx ) )
		return CoGetMarshalSizeMax( pcb, iid, pUnkInner, nDestCtx, pvCtx, grfMshFlags );

	// Use FTM if inner is apartment neutral
	if ( ( MSHCTX_INPROC == nDestCtx ) && ( m_grf & INTERNALFLAGS_USEFTM ) )
	{
		IUnknown* pUnkFTM = 0;
		HRESULT hr = CoCreateFreeThreadedMarshaler( static_cast<IMarshal*>( this ), &pUnkFTM );
		if ( SUCCEEDED( hr ) )
		{
			IMarshal* pMsh = 0;
			hr = pUnkFTM->QueryInterface( IID_IMarshal, (void**)&pMsh );
			if ( SUCCEEDED( hr ) )
			{
				hr = pMsh->GetMarshalSizeMax( iid, pItf, nDestCtx, pvCtx, grfMshFlags, pcb );
				pMsh->Release();
			}
			pUnkFTM->Release();
		}
		return hr;
	}

	if ( grfMshFlags & MSHLFLAGS_TABLESTRONG )
	{
		if ( MSHCTX_INPROC != nDestCtx )
			return E_FAIL;
	}
	else if ( grfMshFlags & MSHLFLAGS_TABLEWEAK )
		return E_FAIL;

	// some hooks support IPersistStream, which will contribute to the size
	IPersistStream* pHookPersistStream = 0;
	if ( m_pHook && FAILED( m_pHook->QueryInterface( IID_IPersistStream, (void**)&pHookPersistStream ) ) )
		pHookPersistStream = 0;

	if ( grfMshFlags & MSHLFLAGS_TABLESTRONG )
	{
		*pcb = sizeof( DWORD ) + sizeof( DWORD ) + sizeof m_grf + sizeof( CLSID );
	}
	else
	{
		hr = CoGetMarshalSizeMax( pcb, iid, pUnkInner, nDestCtx, pvCtx, grfMshFlags );
		*pcb += sizeof( DWORD ) + sizeof m_grf + sizeof( CLSID );
	}
	if ( SUCCEEDED( hr ) && pHookPersistStream )
	{
		__int64 cb;
		hr = pHookPersistStream->GetSizeMax( reinterpret_cast<ULARGE_INTEGER*>( &cb ) );
		*pcb += sizeof( DWORD ) + static_cast<ULONG>( cb );
	}

	if ( pHookPersistStream )
		pHookPersistStream->Release();

	return hr;
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoDelegator::MarshalInterface( IStream* pstm, REFIID iid,
	void* pItf, DWORD nDestCtx, void* pvCtx, DWORD grfMshFlags )
{
	if ( !pstm )
		return E_INVALIDARG;

	// We obey iid_is, so the following block determines which pointer we will marshal
	HRESULT hr = S_OK;
	IUnknown* pUnkInner = 0; // don't need to release this local var
	if ( IID_IUnknown == iid )
		pUnkInner = m_pUnkInner;
	else
	{
		Delegator* pDelegator = 0;
		Lock lock( *this );
		if ( !_findDelegator( iid, pDelegator, hr ) )
			return E_UNEXPECTED; // should never be asked to marshal an unknown ptr
		pUnkInner = pDelegator->m_pUnkInner;
	}
	if ( FAILED( hr ) )
		return hr;

	if ( !_mbvInThisContext( nDestCtx ) )
		return CoMarshalInterface( pstm, iid, pUnkInner, nDestCtx, pvCtx, grfMshFlags );

	// Use FTM if inner is apartment neutral
	if ( ( MSHCTX_INPROC == nDestCtx ) && ( m_grf & INTERNALFLAGS_USEFTM ) )
	{
		IUnknown* pUnkFTM = 0;
		HRESULT hr = CoCreateFreeThreadedMarshaler( static_cast<IMarshal*>( this ), &pUnkFTM );
		if ( SUCCEEDED( hr ) )
		{
			IMarshal* pMsh = 0;
			hr = pUnkFTM->QueryInterface( IID_IMarshal, (void**)&pMsh );
			if ( SUCCEEDED( hr ) )
			{
				hr = pMsh->MarshalInterface( pstm, iid, pItf, nDestCtx, pvCtx, grfMshFlags );
				pMsh->Release();
			}
			pUnkFTM->Release();
		}
		return hr;
	}

	// we don't support table marshals, except for the special case of
	// MSHCTX_INPROC and MSHLFLAGS_TABLESTRONG, which is a good indication
	// that we are being marshaled into the GIT. In this case, we marshal the
	// proxy into the GIT and store the cookie in our custom OBJREF.
	if ( grfMshFlags & MSHLFLAGS_TABLESTRONG )
	{
		if ( MSHCTX_INPROC != nDestCtx )
			return E_FAIL;
	}
	else if ( grfMshFlags & MSHLFLAGS_TABLEWEAK )
		return E_FAIL;

	IPersist* pHookPersist = 0;
	IPersistStream* pHookPersistStream = 0;
	if ( m_pHook )
	{
		// all hooks support at least IPersist
		if ( FAILED( m_pHook->QueryInterface( IID_IPersist, (void**)&pHookPersist ) ) )
			return E_UNEXPECTED;

		// some hooks support IPersistStream
		if ( FAILED( m_pHook->QueryInterface( IID_IPersistStream, (void**)&pHookPersistStream ) ) )
			pHookPersistStream = 0;
	}

	// put all useful information about the stream format up front to simplify
	// our life when we need to read it back
	DWORD grfDelegatorMarshal = 0;
	if ( pHookPersistStream )
		grfDelegatorMarshal |= DMSH_SERIALIZED_HOOK_STATE;
	if ( grfMshFlags & MSHLFLAGS_TABLESTRONG )
		grfDelegatorMarshal |= DMSH_INNER_IN_GIT;

	// begin marshaling
	hr = pstm->Write( &grfDelegatorMarshal, sizeof grfDelegatorMarshal, 0 );

	__int64 beginSubmarshal;
	__int64 zero = 0;
	bool bSubmarshaled = false;
	IGlobalInterfaceTable* pgit = 0;
	DWORD nGITCookie = 0;

	// record our current stream offset in case we have to back out a submarshal on failure
	if ( SUCCEEDED( hr ) )
		hr = pstm->Seek( *reinterpret_cast<LARGE_INTEGER*>(&zero), STREAM_SEEK_CUR, reinterpret_cast<ULARGE_INTEGER*>( &beginSubmarshal ) );

	//  attempt to submarshal the interface pointer
	if ( SUCCEEDED( hr ) )
	{
		if ( grfDelegatorMarshal & DMSH_INNER_IN_GIT )
		{
			// marshal into the GIT
			HRESULT hrGIT = CoCreateInstance( CLSID_StdGlobalInterfaceTable, 0, CLSCTX_INPROC_SERVER, IID_IGlobalInterfaceTable, (void**)&pgit );
			if ( SUCCEEDED( hrGIT ) )
			{
				hrGIT = pgit->RegisterInterfaceInGlobal( pUnkInner, iid, &nGITCookie );
//				pgit->Release();
				if ( SUCCEEDED( hrGIT ) )
				{
					hr = pstm->Write( &nGITCookie, sizeof nGITCookie, 0 );
					bSubmarshaled = true;
				}
				else hr = E_FAIL; // TBD: need to define better error codes, but using what facility???
			}
			else pgit = 0;
		}
		else
		{
			// submarshal into the custom OBJREF
			hr = CoMarshalInterface( pstm, iid, pUnkInner, nDestCtx, pvCtx, grfMshFlags );
			if ( SUCCEEDED( hr ) )
				bSubmarshaled = true; // if we fail part way through, will need to CoReleaseMarshalData
		}
	}

	// write the rest of our state, including the hook and any state it may have
	if ( SUCCEEDED( hr ) )
		hr = pstm->Write( &m_grf, sizeof m_grf, 0 );
	if ( SUCCEEDED( hr ) && m_pHook )
	{
		CLSID clsidHook;
		hr = pHookPersist->GetClassID( &clsidHook );
		if ( SUCCEEDED( hr ) )
			hr = pstm->Write( &clsidHook, sizeof clsidHook, 0 );
		if ( SUCCEEDED( hr ) && pHookPersistStream )
		{
			// store hook data with a length prefix to make ReleaseMarshalData
			// possible without having to rehydrate the hook
			__int64 skip = sizeof DWORD;
			__int64 beginHookData;
			hr = pstm->Seek( *reinterpret_cast<LARGE_INTEGER*>(&skip), STREAM_SEEK_CUR, reinterpret_cast<ULARGE_INTEGER*>( &beginHookData ) );
			if ( SUCCEEDED( hr ) )
				hr = pHookPersistStream->Save( pstm, FALSE );
			__int64 endHookData;
			if ( SUCCEEDED( hr ) )
				hr = pstm->Seek( *reinterpret_cast<LARGE_INTEGER*>(&zero), STREAM_SEEK_CUR, reinterpret_cast<ULARGE_INTEGER*>( &endHookData ) );
			if ( SUCCEEDED( hr ) )
			{
				// back up to write the length-prefix
				__int64 hookDataHeaderPos = beginHookData - sizeof DWORD;
				hr = pstm->Seek( *reinterpret_cast<LARGE_INTEGER*>(&hookDataHeaderPos), STREAM_SEEK_SET, 0 );
			}
			if ( SUCCEEDED( hr ) )
			{
				// write the length-prefix
				DWORD cbHookData = static_cast<DWORD>( endHookData - beginHookData );
				hr = pstm->Write( &cbHookData, sizeof cbHookData, 0 );
			}
			// restore the stream to the end of the hook data
			if ( SUCCEEDED( hr ) )			
				hr = pstm->Seek( *reinterpret_cast<LARGE_INTEGER*>(&endHookData), STREAM_SEEK_SET, 0 );
		}
	}
	else hr = pstm->Write( &CLSID_NULL, sizeof CLSID_NULL, 0 );

	if ( FAILED( hr ) && bSubmarshaled )
	{
		// free the submarshal
		if ( grfDelegatorMarshal & DMSH_INNER_IN_GIT )
			pgit->RevokeInterfaceFromGlobal( nGITCookie );
		else if ( SUCCEEDED( pstm->Seek( *reinterpret_cast<LARGE_INTEGER*>( &beginSubmarshal ), STREAM_SEEK_SET, 0 ) ) )
			CoReleaseMarshalData( pstm );
	}
	if ( pgit )
		pgit->Release();
	if ( pHookPersistStream )
		pHookPersistStream->Release();
	if ( pHookPersist )
		pHookPersist->Release();

	return hr;
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoDelegator::ReleaseMarshalData( IStream* pstm )
{
	return CoReleaseMarshalData( pstm );
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoDelegator::UnmarshalInterface( IStream*, REFIID, void** )
{
	// implemented by unmarshaler
	return E_NOTIMPL;
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoDelegator::DisconnectObject( DWORD )
{
	return S_OK;
}
