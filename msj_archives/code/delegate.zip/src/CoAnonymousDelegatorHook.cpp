/////////////////////////////////////////////////////////////
// CoAnonymousDelegatorHook.cpp - Generic Delegator Component
//
// Copyright 1998, Keith Brown
//
// Simple hook that drops the authn level to NONE for every
// interface. No pre/post processing is required, so this is
// a very lightweight hook.
/////////////////////////////////////////////////////////////
#include "precomp.h"
#include "CoAnonymousDelegatorHook.h"
#include "crt.h"

static CoAnonymousDelegatorHook s_TheHook;

//---------------------------------------------------------------------------//
HRESULT CoAnonymousDelegatorHook::_setBlanket( IUnknown* pItfInner )
{
	IClientSecurity* pcs = 0;
	HRESULT hr = pItfInner->QueryInterface( IID_IClientSecurity, (void**)&pcs );
	if ( FAILED( hr ) )
		return hr;

	DWORD nAuthnSvc, nAuthzSvc, nImpLevel, grfCaps;
	OLECHAR* pszServerPrincipal = 0;
	void* pAuthIdentity = 0;
	hr = pcs->QueryBlanket( pItfInner, &nAuthnSvc, &nAuthzSvc,
		&pszServerPrincipal, 0, &nImpLevel, &pAuthIdentity, &grfCaps );

	if ( SUCCEEDED( hr ) )
		hr = pcs->SetBlanket( pItfInner, nAuthnSvc, nAuthzSvc,
			pszServerPrincipal, RPC_C_AUTHN_LEVEL_NONE,
			nImpLevel, pAuthIdentity, grfCaps );

	pcs->Release();
	return hr;
}

//---------------------------------------------------------------------------//
void CoAnonymousDelegatorHook::Startup()
{
	new ( &s_TheHook ) CoAnonymousDelegatorHook;
}

//---------------------------------------------------------------------------//
CoAnonymousDelegatorHook& CoAnonymousDelegatorHook::TheHook()
{
	return s_TheHook;
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoAnonymousDelegatorHook::QueryInterface( REFIID iid, void** ppv )
{
	if ( !ppv )
		return E_POINTER;
	if ( IID_IDelegatorHookQI == iid || IID_IUnknown == iid )
		*ppv = static_cast<IDelegatorHookQI*>( this );
	else if ( IID_IClassFactory == iid )
		*ppv = static_cast<IClassFactory*>( this );
	else return (*ppv = 0), E_NOINTERFACE;
	// no AddRef required - static object
	return S_OK;
}

//---------------------------------------------------------------------------//
STDMETHODIMP_(ULONG) CoAnonymousDelegatorHook::AddRef()
{
	extern void SvcLock();
	SvcLock();
	return 2;
}

//---------------------------------------------------------------------------//
STDMETHODIMP_(ULONG) CoAnonymousDelegatorHook::Release()
{
	extern void SvcUnlock();
	SvcUnlock();
	return 1;
}
//---------------------------------------------------------------------------//
STDMETHODIMP CoAnonymousDelegatorHook::Init( IUnknown* pUnkInner )
{
	return _setBlanket( pUnkInner );
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoAnonymousDelegatorHook::OnFirstDelegatorQIFor( REFIID iid,
	IUnknown* pItfInner, DWORD* pgrfDelegatorHookOptions,
	REFIID iidMethodHook, void** ppvMethodHook )
{
	*pgrfDelegatorHookOptions = 0;
	*ppvMethodHook = 0;
	return _setBlanket( pItfInner );
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoAnonymousDelegatorHook::GetClassID( CLSID* pclsid )
{
	if ( !pclsid )
		return E_POINTER;
	*pclsid = __uuidof(this);
	return S_OK;
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoAnonymousDelegatorHook::CreateInstance( IUnknown* pUnkOuter,
	REFIID iid, void** ppv )
{
	if ( !ppv )
		return E_POINTER;
	*ppv = 0;
	if ( pUnkOuter )
		return CLASS_E_NOAGGREGATION;
	return QueryInterface( iid, ppv );
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoAnonymousDelegatorHook::LockServer( BOOL bLock )
{
	extern void SvcLock();
	extern void SvcUnlock();
	if ( bLock )
		 SvcLock();
	else SvcUnlock();
	return S_OK;
}
