/////////////////////////////////////////////////////////////
// CoAlternateCredentialHook.h - Generic Delegator Component
//
// Copyright 1998, Keith Brown
//
// Simple hook that overrides the security settings on the
// proxy. No pre/post processing is required, so this is
// a very lightweight hook.
/////////////////////////////////////////////////////////////
#pragma once

#include "delegate.h"

class __declspec(uuid("9b8c32f7-249a-11d2-a7bb-006008d25ccf"))
	CoAlternateCredentialDelegatorHook :
		public IDelegatorHookQI,
		public IAlternateCredentialDelegatorHook,
		public IPersistStream
{
public:
	CoAlternateCredentialDelegatorHook()
	  : m_cRefs(0),
		m_grfOptions(0),
		m_nAuthnSvc(0),
		m_nAuthzSvc(0),
		m_nAuthnLevel(0),
		m_nImpLevel(0),
		m_grfCaps(0),
		m_pStringBuffer(0),
		m_cbStrings(0),
		m_pszServerPrincipal(0)
	{
		OutputDebugString( __TEXT( "CoAlternateCredentialDelegatorHook ctor\n" ) );
		ZeroMemory( &m_authIdentity, sizeof m_authIdentity );
	}
	~CoAlternateCredentialDelegatorHook()
	{
		OutputDebugString( __TEXT( "CoAlternateCredentialDelegatorHook dtor\n" ) );
		if ( m_pStringBuffer )
			CoTaskMemFree( m_pStringBuffer );
	}
	HRESULT _setBlanket( IUnknown* pItfInner );

	STDMETHODIMP QueryInterface( REFIID iid, void** ppv );
	STDMETHODIMP_(ULONG) AddRef();
	STDMETHODIMP_(ULONG) Release();

	STDMETHODIMP Init( IUnknown* pUnkInner );
	STDMETHODIMP OnFirstDelegatorQIFor( REFIID iid,	IUnknown* pItfInner,
		DWORD* pgrfDelegatorHookOptions, REFIID iidMethodHook, void** ppvMethodHook );

	STDMETHODIMP Init(	DWORD grfOptions,
						DWORD nAuthnSvc,
						DWORD nAuthzSvc,
						const OLECHAR* pszServerPrincipal,
						DWORD nAuthnLevel,
						DWORD nImpLevel,
						const OLECHAR* pszAuthority,
						const OLECHAR* pszPrincipal,
						const OLECHAR* pszPassword,
						DWORD grfCaps );

	STDMETHODIMP GetClassID( CLSID* pclsid );
	STDMETHODIMP IsDirty();
	STDMETHODIMP Load( IStream* pstm );
	STDMETHODIMP Save( IStream* pstm, BOOL );
	STDMETHODIMP GetSizeMax( ULARGE_INTEGER* pcb );

	STDMETHODIMP CreateInstance( IUnknown*, REFIID iid, void** ppv );
	STDMETHODIMP LockServer( BOOL bLock );

private:
	enum { HOOK_VERSION = 1 };
	long		m_cRefs;
	DWORD		m_grfOptions;
	DWORD		m_nAuthnSvc;
	DWORD		m_nAuthzSvc;
	DWORD		m_nAuthnLevel;
	DWORD		m_nImpLevel;
	DWORD		m_grfCaps;
	OLECHAR*	m_pStringBuffer;
	DWORD		m_cbStrings;
	const OLECHAR*	m_pszServerPrincipal;
	COAUTHIDENTITY m_authIdentity;
};
