#pragma once

//---------------------------------------------------------------------------//
template <class T>
struct ClassFactory : IClassFactory
{
	STDMETHODIMP QueryInterface( REFIID iid, void** ppv )
	{
		if ( !ppv )
			return E_POINTER;
		if ( IID_IClassFactory == iid || IID_IUnknown == iid )
			*ppv = static_cast<IClassFactory*>( this );
		else return (*ppv = 0), E_NOINTERFACE;
		// no AddRef required - static object
		return S_OK;
	}
	STDMETHODIMP_(ULONG) AddRef()
	{
		extern void SvcLock();
		SvcLock();
		return 2;
	}
	STDMETHODIMP_(ULONG) Release()
	{
		extern void SvcUnlock();
		SvcUnlock();
		return 1;
	}
	STDMETHODIMP CreateInstance( IUnknown* pUnkOuter, REFIID iid, void** ppv )
	{
		if ( !ppv )
			return E_POINTER;
		*ppv = 0;
		if ( pUnkOuter )
			return CLASS_E_NOAGGREGATION;
		T* p = new T;
		if ( !p )
			return E_OUTOFMEMORY;
		p->AddRef();
		HRESULT hr = p->QueryInterface( iid, ppv );
		p->Release();
		return hr;
	}
	STDMETHODIMP LockServer( BOOL bLock )
	{
		extern void SvcLock();
		extern void SvcUnlock();
		if ( bLock )
			 SvcLock();
		else SvcUnlock();
		return S_OK;
	}
};
