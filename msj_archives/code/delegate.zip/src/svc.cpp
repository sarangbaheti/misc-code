// svc.cpp - simple inproc server shell
#include "precomp.h"
#include "CoDelegator.h"
#include "Unmarshaler.h"
#include "CoAnonymousDelegatorHook.h"
#include "CoAlternateCredentialDelegatorHook.h"
#include "delegate.h"
#include "delegate_i.c"
#include "crt.h"
#include "ClassFactory.h"

long g_cLocks;

struct REG_DATA
{
    const TCHAR *pszKeyName;
    const TCHAR *pszValueName;
    const TCHAR *pszValue;
    BOOL        bDeleteOnUnregister;
};

TCHAR g_szFileName[MAX_PATH];

const REG_DATA g_rgEntries[] =
{
    { __TEXT("CLSID\\{9b8c32f0-249a-11d2-a7bb-006008d25ccf}"),
      0,
      __TEXT("CoDelegator class"),
      TRUE
    },
    { __TEXT("CLSID\\{9b8c32f0-249a-11d2-a7bb-006008d25ccf}\\InprocServer32"),
      0,
      g_szFileName,
      TRUE
    },
    { __TEXT("CLSID\\{CE8555A0-977B-11d0-B33A-00400530E4E8}\\InprocServer32"),
      __TEXT("ThreadingModel"),
      __TEXT("Both"),
      TRUE
    },
    { __TEXT("CLSID\\{CE8555A0-977B-11d0-B33A-00400530E4E8}"),
      0,
      __TEXT("CoDelegator0 class"),
      TRUE
    },
    { __TEXT("CLSID\\{CE8555A0-977B-11d0-B33A-00400530E4E8}\\InprocServer32"),
      0,
      g_szFileName,
      TRUE
    },
    { __TEXT("CLSID\\{9b8c32f0-249a-11d2-a7bb-006008d25ccf}\\InprocServer32"),
      __TEXT("ThreadingModel"),
      __TEXT("Both"),
      TRUE
    },
    { __TEXT("CLSID\\{9b8c32f4-249a-11d2-a7bb-006008d25ccf}"),
      0,
      __TEXT("CoDelegator MBV unmarshaler"),
      TRUE
    },
    { __TEXT("CLSID\\{9b8c32f4-249a-11d2-a7bb-006008d25ccf}\\InprocServer32"),
      0,
      g_szFileName,
      TRUE
    },
    { __TEXT("CLSID\\{9b8c32f4-249a-11d2-a7bb-006008d25ccf}\\InprocServer32"),
      __TEXT("ThreadingModel"),
      __TEXT("Both"),
      TRUE
    },
    { __TEXT("CLSID\\{9b8c32f6-249a-11d2-a7bb-006008d25ccf}"),
      0,
      __TEXT("CoAnonymousDelegatorHook"),
      TRUE
    },
    { __TEXT("CLSID\\{9b8c32f6-249a-11d2-a7bb-006008d25ccf}\\InprocServer32"),
      0,
      g_szFileName,
      TRUE
    },
    { __TEXT("CLSID\\{9b8c32f6-249a-11d2-a7bb-006008d25ccf}\\InprocServer32"),
      __TEXT("ThreadingModel"),
      __TEXT("Both"),
      TRUE
    },
    { __TEXT("CLSID\\{9b8c32f7-249a-11d2-a7bb-006008d25ccf}"),
      0,
      __TEXT("CoAlternateCredentialDelegatorHook"),
      TRUE
    },
    { __TEXT("CLSID\\{9b8c32f7-249a-11d2-a7bb-006008d25ccf}\\InprocServer32"),
      0,
      g_szFileName,
      TRUE
    },
    { __TEXT("CLSID\\{9b8c32f7-249a-11d2-a7bb-006008d25ccf}\\InprocServer32"),
      __TEXT("ThreadingModel"),
      __TEXT("Both"),
      TRUE
    }
};

const int g_cEntries = sizeof(g_rgEntries)/sizeof(*g_rgEntries);

static HRESULT Unregister(const REG_DATA *rgEntries, int cEntries)
{
    BOOL bSuccess = TRUE;
    for (int i = cEntries - 1; i >= 0; i--)
        if (rgEntries[i].bDeleteOnUnregister)
        {
            
            LONG err = RegDeleteKey(HKEY_CLASSES_ROOT,
                                    rgEntries[i].pszKeyName);
            if (err != ERROR_SUCCESS)
                bSuccess = FALSE;
        }
    return bSuccess ? S_OK : S_FALSE;
}

static HRESULT Register(const REG_DATA *rgEntries, int cEntries)
{
    BOOL bSuccess = TRUE;
    const REG_DATA *pEntry = rgEntries;
    while (pEntry < rgEntries + cEntries)
    {
        HKEY hkey;
        LONG err = RegCreateKey(HKEY_CLASSES_ROOT,
                                pEntry->pszKeyName,
                                &hkey);
        if (err == ERROR_SUCCESS)
        {
            err = RegSetValueEx(hkey, 
                                pEntry->pszValueName,
                                0, REG_SZ, 
                                (const BYTE*)pEntry->pszValue,
                                (lstrlen(pEntry->pszValue) + 1) * sizeof(TCHAR));
            if (err != ERROR_SUCCESS)
            {
                bSuccess = FALSE;
                Unregister(rgEntries, 1 + pEntry - rgEntries);
            }
            RegCloseKey(hkey);
        }
        if (err != ERROR_SUCCESS)
        {
            bSuccess = FALSE;
            if (pEntry != rgEntries)
                Unregister(rgEntries, pEntry - rgEntries);
        }
        pEntry++;
    }
    return bSuccess ? S_OK : E_FAIL;
}

void SvcLock()
{
	InterlockedIncrement( &g_cLocks );
}

void SvcUnlock()
{
	InterlockedDecrement( &g_cLocks );
}

class CoDelegatorFactory : public IDelegatorFactory
{
public:
	STDMETHODIMP QueryInterface( REFIID iid, void** ppv )
	{
		if ( !ppv )
			return E_POINTER;
		if ( IID_IDelegatorFactory == iid )
			*ppv = (IDelegatorFactory*) this;
		else if ( IID_IUnknown == iid )
			*ppv = (IDelegatorFactory*) this;
		else return (*ppv = 0), E_NOINTERFACE;
		((IUnknown*)*ppv)->AddRef();
		return S_OK;
	}
	STDMETHODIMP_(ULONG) AddRef()
	{
		SvcLock();
		return 2;
	}
	STDMETHODIMP_(ULONG) Release()
	{
		SvcUnlock();
		return 1;
	}
	STDMETHODIMP CreateDelegator( IUnknown* pUnkOuter,
								  IUnknown* pInner,
								  CLSID* pclsidHook,
								  IUnknown* pUnkHook,
								  DWORD grfOptions,
								  REFIID iid, void** ppv )
	{
		if ( !ppv )
			return E_POINTER;
		*ppv = 0;

		if ( grfOptions & ~0x0000000F )
			return E_INVALIDARG;

		if ( DO_MAINTAIN_IDENTITY == ( grfOptions & ( DO_MBV_ALL | DO_MAINTAIN_IDENTITY ) ) )
			return E_INVALIDARG; // must also specify MBV

		// must an inner, otherwise there's nobody to delegate to...
		if ( !pInner )
			return E_INVALIDARG;

		if ( pclsidHook && pUnkHook )
			return E_INVALIDARG;

		IUnknown* pUnkInner = 0;
		HRESULT hr = pInner->QueryInterface( IID_IUnknown, (void**)&pUnkInner );
		if ( FAILED( hr ) )
			return hr;

		IDelegatorHookQI* pHook = 0;
		if ( pUnkHook )
			 hr = pUnkHook->QueryInterface( IID_IDelegatorHookQI, (void**)&pHook );
		else if ( pclsidHook )
			hr = CoCreateInstance( *pclsidHook, 0, CLSCTX_INPROC_SERVER, IID_IDelegatorHookQI, (void**)&pHook );
		if ( FAILED( hr ) )
			pHook = 0;

		if ( SUCCEEDED( hr ) && pHook && ( DO_MBV_ALL & grfOptions ) )
		{
			// For MBV, we require that the hook supports at least IPersist
			IPersist* pHookPersist = 0;
			if ( SUCCEEDED( pHook->QueryInterface( IID_IPersist, (void**)&pHookPersist ) ) )
				 pHookPersist->Release();
			else hr = E_INVALIDARG;
		}

		if ( SUCCEEDED( hr ) )
			hr = pHook->Init( pUnkInner );

		if ( SUCCEEDED( hr ) )
		{
			CoDelegator* p = new CoDelegator( pUnkOuter, pUnkInner, pHook, grfOptions );
			if ( p )
			{
				p->AddRef();
				hr = p->QueryInterface( iid, ppv );
				p->Release();
			}
			else hr = E_OUTOFMEMORY;
		}
		pUnkInner->Release();
		if ( pHook )
			pHook->Release();
		return hr;
	}
};

class CoDelegatorFactory0 : public IDelegatorFactory0
{
public:
	STDMETHODIMP QueryInterface( REFIID iid, void** ppv )
	{
		if ( !ppv )
			return E_POINTER;
		if ( ( IID_IDelegatorFactory0 == iid ) || ( IID_IUnknown == iid ) )
			*ppv = (IDelegatorFactory0*) this;
		else return (*ppv = 0), E_NOINTERFACE;
		((IUnknown*)*ppv)->AddRef();
		return S_OK;
	}
	STDMETHODIMP_(ULONG) AddRef()
	{
		SvcLock();
		return 2;
	}
	STDMETHODIMP_(ULONG) Release()
	{
		SvcUnlock();
		return 1;
	}
	STDMETHODIMP CreateDelegator( IUnknown* pUnkOuter,
								  IUnknown* pUnkInner,
								  REFIID iid, void** ppv )
	{
		if ( !ppv )
			return E_POINTER;
		*ppv = 0;

		if ( !pUnkOuter || !pUnkInner )
			return E_INVALIDARG;

		HRESULT hr = S_OK;
		CoDelegator* p = new CoDelegator( pUnkOuter, pUnkInner, 0, 0 );
		if ( p )
		{
			p->AddRef();
			hr = p->QueryInterface( iid, ppv );
			p->Release();
		}
		else hr = E_OUTOFMEMORY;
		return hr;
	}
};

CoDelegatorFactory g_factory;
CoDelegatorFactory0 g_factory0;
ClassFactory<CoAlternateCredentialDelegatorHook> g_AlternateCredentialHookFactory;

BOOL WINAPI DllMain(HINSTANCE h, DWORD dwReason, void *)
{
    if (dwReason == DLL_PROCESS_ATTACH)
    {
		if ( !CoDelegator::Startup() )
			return FALSE;
		if ( !Unmarshaler::Startup() )
		{
			CoDelegator::Shutdown();
			return FALSE;
		}
		CoAnonymousDelegatorHook::Startup();

		// we must initialize static data ourselves (no crt)
		new( &g_factory ) CoDelegatorFactory;
		new( &g_AlternateCredentialHookFactory ) ClassFactory<CoAlternateCredentialDelegatorHook>;

        GetModuleFileName(h, g_szFileName, MAX_PATH);
    }
	else if ( dwReason == DLL_PROCESS_DETACH )
	{
		CoAnonymousDelegatorHook::Shutdown();
		Unmarshaler::Shutdown();
		CoDelegator::Shutdown();
	}
    return TRUE;
}

STDAPI DllCanUnloadNow()
{
	return g_cLocks ? S_FALSE : S_OK;
}

STDAPI DllGetClassObject( REFCLSID clsid, REFIID iid, void** ppv )
{
	if ( CLSID_CoDelegator == clsid )
		return g_factory.QueryInterface( iid, ppv );
	else if ( __uuidof( Unmarshaler ) == clsid )
		return Unmarshaler::TheUnmarshaler().QueryInterface( iid, ppv );
	else if ( __uuidof( CoAnonymousDelegatorHook ) == clsid )
		return CoAnonymousDelegatorHook::TheHook().QueryInterface( iid, ppv );
	else if ( __uuidof( CoAlternateCredentialDelegatorHook ) == clsid )
		return g_AlternateCredentialHookFactory.QueryInterface( iid, ppv );
	else if ( CLSID_CoDelegator0 == clsid )
		return g_factory0.QueryInterface( iid, ppv );
	else return CLASS_E_CLASSNOTAVAILABLE;
}

STDAPI DllRegisterServer()
{
	return Register( g_rgEntries, g_cEntries );
}

STDAPI DllUnregisterServer()
{
	return Unregister( g_rgEntries, g_cEntries );
}
