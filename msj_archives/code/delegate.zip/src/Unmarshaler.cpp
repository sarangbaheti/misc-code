/////////////////////////////////////////////////////////////
// Unmarshaler.cpp - Generic Delegator Component
//
// Copyright 1998, Keith Brown
//
// This is the COM class that is responsible for unmarshaling
// interface pointers from delegators having various DO_MBV_XXXX
// options set. The reason this is a separate class is to
// to support the DO_MAINTAIN_IDENTITY option.
/////////////////////////////////////////////////////////////
#include "precomp.h"
#include "Unmarshaler.h"
#include "CoDelegator.h"
#include "crt.h"

static Unmarshaler s_TheUnmarshaler;

//---------------------------------------------------------------------------//
// DelegatorDictionary - simple hash table for maintaining identity
//   Key   == inner's identity
//   Value == delegator's identity
//---------------------------------------------------------------------------//
class DelegatorDictionary
{
public:
	void Startup()
	{
		m_prgBuckets = 0;
	}
	void Shutdown()
	{
		// during normal shutdown, all buckets will be empty
		delete [] m_prgBuckets;
	}

	HRESULT Insert( IUnknown* pUnkInner, IUnknown* pUnkDelegator )
	{
		HRESULT hr = S_OK;
		if ( !m_prgBuckets )
			hr = _lazyInit();
		if ( SUCCEEDED( hr ) )
		{
			Item* pNewHead = new Item( pUnkInner, pUnkDelegator );
			if ( pNewHead )
			{
				DWORD hash = _hash(pUnkInner);
				Item*& pHead = m_prgBuckets[hash];
				pNewHead->pNext = pHead;
				pHead = pNewHead;
			}
			else hr = E_OUTOFMEMORY;
		}
		return hr;
	}
	void Remove( IUnknown* pUnkInner )
	{
		if ( !m_prgBuckets )
			return;
		const DWORD hash = _hash( pUnkInner );
		Item*& pHead = m_prgBuckets[hash];
		if ( pHead )
		{
			if ( pUnkInner == pHead->pUnkInner )
			{
				Item* pNewHead = pHead->pNext;
				delete pHead;
				pHead = pNewHead;
			}
			else _removeFromTail( pHead, pUnkInner );
		}
	}
	IUnknown* Lookup( IUnknown* pUnkInner )
	{
		if ( m_prgBuckets )
		{
			Item* pItem = m_prgBuckets[_hash(pUnkInner)];
			while ( pItem )
			{
				if ( pUnkInner == pItem->pUnkInner )
					return pItem->pUnkDelegator;
				pItem = pItem->pNext;
			}
		}
		return 0;
	}

private:
	enum { MaxBuckets = 253 }; // TBD: find a reasonable prime
	struct Item
	{
		Item( IUnknown* _pUnkInner, IUnknown* _pUnkDelegator )
		  : pNext( 0 ), pUnkInner( _pUnkInner ), pUnkDelegator( _pUnkDelegator )
		{}
		Item* pNext;
		IUnknown* pUnkInner;		// key
		IUnknown* pUnkDelegator;	// value
	};
	HRESULT _lazyInit()
	{
		m_prgBuckets = new Item*[MaxBuckets];
		if ( !m_prgBuckets )
			return E_OUTOFMEMORY;
		ZeroMemory( m_prgBuckets, sizeof( Item* ) * MaxBuckets );
		return S_OK;
	}
	DWORD _hash( IUnknown* pUnk )
	{
		return (HIWORD(pUnk) ^ LOWORD(pUnk)) % MaxBuckets;
	}
	void _removeFromTail( Item* pHead, IUnknown* pUnkInner )
	{
		Item* pTail = pHead->pNext;
		while ( pTail )
		{
			if ( pUnkInner == pTail->pUnkInner )
			{
				pHead->pNext = pTail->pNext;
				delete pTail;
				break;
			}
			pHead = pTail;
			pTail = pHead->pNext;
		}
	}

	Item** m_prgBuckets;
};

static DelegatorDictionary Dictionary;

CRITICAL_SECTION Unmarshaler::s_sect;

//---------------------------------------------------------------------------//
bool Unmarshaler::Startup()
{
	InitializeCriticalSection( &s_sect );
	Dictionary.Startup();
	new ( &s_TheUnmarshaler ) Unmarshaler;
	return true;
}

//---------------------------------------------------------------------------//
void Unmarshaler::Shutdown()
{
	Dictionary.Shutdown();
	DeleteCriticalSection( &s_sect );
}

//---------------------------------------------------------------------------//
bool Unmarshaler::ReleaseIdentityConsciousDelegator( CoDelegator& d )
{
	bool bOkToDie = false;
	EnterCriticalSection( &s_sect );
	if ( d.NoRefs() )
	{
		// we can now safely remove d from the table
		Dictionary.Remove( d.GetInner() );
		bOkToDie = true;
	}
	LeaveCriticalSection( &s_sect );
	return bOkToDie;
}

//---------------------------------------------------------------------------//
Unmarshaler& Unmarshaler::TheUnmarshaler()
{
	return s_TheUnmarshaler;
}

//---------------------------------------------------------------------------//
HRESULT Unmarshaler::_createHook( IStream* pstm, REFCLSID clsidHook,
	IUnknown* pUnkInner, bool bSerializedHookState, IDelegatorHookQI*& pHook )
{
	HRESULT hr = S_OK;
	if ( CLSID_NULL != clsidHook )
	{
		if ( bSerializedHookState )
		{
			IPersistStream* pHookPersistor = 0;
			hr = CoCreateInstance( clsidHook, 0, CLSCTX_INPROC_SERVER,
									IID_IPersistStream, (void**)&pHookPersistor );
			if ( SUCCEEDED( hr ) )
			{
				// seek past the length prefix
				__int64 skip = sizeof( DWORD );
				hr = pstm->Seek( *reinterpret_cast<LARGE_INTEGER*>(&skip), STREAM_SEEK_CUR, 0 );
				if ( SUCCEEDED( hr ) )
					hr = pHookPersistor->Load( pstm );
				if ( SUCCEEDED( hr ) )
				{
					hr = pHookPersistor->QueryInterface( IID_IDelegatorHookQI, (void**)&pHook );
					if ( FAILED( hr ) )
						pHook = 0;
				}
				pHookPersistor->Release();
			}
		}
		else
		{
			hr = CoCreateInstance( clsidHook, 0, CLSCTX_INPROC_SERVER,
									IID_IDelegatorHookQI, (void**)&pHook );
			if ( FAILED( hr ) )
				pHook = 0;
		}
		if ( pHook )
			hr = pHook->Init( pUnkInner );
	}
	return hr;
}

//---------------------------------------------------------------------------//
HRESULT Unmarshaler::_createNew( IStream* pstm, IUnknown* pUnkInner,
	DWORD grf, REFCLSID clsidHook, bool bSerializedHookState, IUnknown*& pUnkDelegator )
{
	IDelegatorHookQI* pHook = 0;
	HRESULT hr = _createHook( pstm, clsidHook, pUnkInner, bSerializedHookState, pHook );

	if ( SUCCEEDED( hr ) )
	{
		pUnkDelegator = new CoDelegator( 0, pUnkInner, pHook, grf );
		if ( pUnkDelegator )
			 pUnkDelegator->AddRef();
		else hr = E_OUTOFMEMORY;
	}

	if ( pHook )
		pHook->Release();
	return hr;
}

//---------------------------------------------------------------------------//
HRESULT Unmarshaler::_insert( IUnknown* pUnkInner, IUnknown* pUnkDelegator )
{
		// TBD
	return E_NOTIMPL;
}

//---------------------------------------------------------------------------//
STDMETHODIMP Unmarshaler::QueryInterface( REFIID iid, void** ppv )
{
	if ( !ppv )
		return E_POINTER;
	if ( IID_IMarshal == iid || IID_IUnknown == iid )
		*ppv = static_cast<IMarshal*>( this );
	else if ( IID_IClassFactory == iid )
		*ppv = static_cast<IClassFactory*>( this );
	else return (*ppv = 0), E_NOINTERFACE;
	// no AddRef required - static object
	return S_OK;
}

//---------------------------------------------------------------------------//
STDMETHODIMP_(ULONG) Unmarshaler::AddRef()
{
	extern void SvcLock();
	SvcLock();
	return 2;
}

//---------------------------------------------------------------------------//
STDMETHODIMP_(ULONG) Unmarshaler::Release()
{
	extern void SvcUnlock();
	SvcUnlock();
	return 1;
}

//---------------------------------------------------------------------------//
STDMETHODIMP Unmarshaler::GetUnmarshalClass( REFIID iid, void* pv,
	DWORD grfDestCtx, void*, DWORD grfMshFlags, CLSID* pClsid )
{
	// implemented by marshaler
	return E_NOTIMPL;
}

//---------------------------------------------------------------------------//
STDMETHODIMP Unmarshaler::GetMarshalSizeMax( REFIID iid, void* pv,
	DWORD grfDestCtx, void*, DWORD grfMshFlags, ULONG* pcb )
{
	// implemented by marshaler
	return E_NOTIMPL;
}

//---------------------------------------------------------------------------//
STDMETHODIMP Unmarshaler::MarshalInterface( IStream* pstm,
	REFIID iid, void* pv, DWORD grfDestCtx, void*, DWORD grfMshFlags )
{
	// implemented by marshaler
	return E_NOTIMPL;
}

//---------------------------------------------------------------------------//
STDMETHODIMP Unmarshaler::ReleaseMarshalData( IStream* pstm )
{
	DWORD grfDelegatorMarshal = 0;
	HRESULT hr = pstm->Read( &grfDelegatorMarshal, sizeof grfDelegatorMarshal, 0 );
	if ( FAILED( hr ) )
		return hr;

	// release inner
	if ( grfDelegatorMarshal & CoDelegator::DMSH_INNER_IN_GIT )
	{
		DWORD nGITCookie = 0;
		hr = pstm->Read( &nGITCookie, sizeof nGITCookie, 0 );
		if ( SUCCEEDED( hr ) )
		{
			IGlobalInterfaceTable* pgit = 0;
			HRESULT hrGIT = CoCreateInstance( CLSID_StdGlobalInterfaceTable, 0,
				CLSCTX_INPROC_SERVER, IID_IGlobalInterfaceTable, (void**)&pgit );
			if ( SUCCEEDED( hrGIT ) )
			{
				hrGIT = pgit->RevokeInterfaceFromGlobal( nGITCookie );
				pgit->Release();
			}
			if ( FAILED( hrGIT ) )
				hr = E_FAIL;
		}
	}
	else hr = CoReleaseMarshalData( pstm );
	
	// ReleaseMarshalData must seek the stream to the end of the OBJREF,
	// so the following code figures out how far ahead this is...
	if ( SUCCEEDED( hr ) )
	{
		__int64 skip = sizeof( DWORD ) + sizeof( CLSID );
		hr = pstm->Seek( *reinterpret_cast<LARGE_INTEGER*>(&skip), STREAM_SEEK_CUR, 0 );
		if ( grfDelegatorMarshal & CoDelegator::DMSH_SERIALIZED_HOOK_STATE )
		{
			DWORD cbHookData = 0;
			hr = pstm->Read( &cbHookData, sizeof cbHookData, 0 );
			if ( SUCCEEDED( hr ) )
			{
				skip = cbHookData;
				hr = pstm->Seek( *reinterpret_cast<LARGE_INTEGER*>(&skip), STREAM_SEEK_CUR, 0 );
			}
		}
	}
	return hr;
}

//---------------------------------------------------------------------------//
STDMETHODIMP Unmarshaler::UnmarshalInterface( IStream* pstm,
	REFIID iid, void** ppv )
{
	if ( !ppv )
		return E_POINTER;
	*ppv = 0;

	DWORD grfDelegatorMarshal = 0;
	HRESULT hr = pstm->Read( &grfDelegatorMarshal, sizeof grfDelegatorMarshal, 0 );
	if ( FAILED( hr ) )
		return hr;

	// Unmarshal inner
	IUnknown* pInnerItf = 0;
	if ( grfDelegatorMarshal & CoDelegator::DMSH_INNER_IN_GIT )
	{
		DWORD nGITCookie = 0;
		hr = pstm->Read( &nGITCookie, sizeof nGITCookie, 0 );
		if ( SUCCEEDED( hr ) )
		{
			IGlobalInterfaceTable* pgit = 0;
			HRESULT hrGIT = CoCreateInstance( CLSID_StdGlobalInterfaceTable, 0,
				CLSCTX_INPROC_SERVER, IID_IGlobalInterfaceTable, (void**)&pgit );
			if ( SUCCEEDED( hrGIT ) )
			{
				hrGIT = pgit->GetInterfaceFromGlobal( nGITCookie, iid, (void**)&pInnerItf );
				pgit->Release();
			}
			else pgit = 0;
			// note that we only use the GIT for table marshals,
			// so we wait for a ReleaseMarshalData() call to revoke the GIT marshal,
			// even if we return a failure code from UnmarshalInterface
			if ( FAILED( hrGIT ) )
			{
				pInnerItf = 0;
				hr = E_FAIL;
			}
		}
	}
	else
	{
		// note that this call (if successful) will automatically
		// release the submarshal, so ReleaseMarshalData does not
		// need to be called for a NORMAL marshal (and it's not).
		hr = CoUnmarshalInterface( pstm, iid, (void**)&pInnerItf );
		if ( FAILED( hr ) )
		{
			CoReleaseMarshalData( pstm );
			pInnerItf = 0;
		}
	}
	// Explicitly QI for IID_IUnknown to obtain object's identity in this apartment
	IUnknown* pUnkInner = 0;
	if ( SUCCEEDED( hr ) )
	{
		hr = pInnerItf->QueryInterface( IID_IUnknown, (void**)&pUnkInner );
		if ( FAILED( hr ) )
			pUnkInner = 0;  // of course we never expect this to happen :-)
	}

	DWORD grf = 0;
	CLSID clsidHook;
	if ( SUCCEEDED( hr ) )
		hr = pstm->Read( &grf, sizeof grf, 0 );
	if ( SUCCEEDED( hr ) )
		hr = pstm->Read( &clsidHook, sizeof clsidHook, 0 );

	const bool bMaintainIdentity = DO_MAINTAIN_IDENTITY == ( DO_MAINTAIN_IDENTITY & grf );

	// if we're supposed to maintain identity,
	// then perform a table lookup on existing delegators
	IUnknown* pUnkDelegator = 0;
	if ( bMaintainIdentity )
	{
		EnterCriticalSection( &s_sect );
		if ( SUCCEEDED( hr ) )
		{
			pUnkDelegator = Dictionary.Lookup( pUnkInner );
			if ( pUnkDelegator )
				pUnkDelegator->AddRef();
		}
	}

	bool bCreatedNew = false;
	if ( SUCCEEDED( hr ) && !pUnkDelegator )
	{
		const bool bSerializedHookState =
			( grfDelegatorMarshal & CoDelegator::DMSH_SERIALIZED_HOOK_STATE ) ? true : false;
		hr = _createNew( pstm, pUnkInner, grf, clsidHook, bSerializedHookState, pUnkDelegator );
		bCreatedNew = true;
	}

	if ( bMaintainIdentity )
	{
		if ( SUCCEEDED( hr ) && bCreatedNew )
			hr = Dictionary.Insert( pUnkInner, pUnkDelegator );
		LeaveCriticalSection( &s_sect );
	}

	if ( SUCCEEDED( hr ) )
		hr = pUnkDelegator->QueryInterface( iid, ppv );

	if ( pUnkDelegator )
		pUnkDelegator->Release();
	if ( pUnkInner )
		pUnkInner->Release();
	if ( pInnerItf )
		pInnerItf->Release();
	return hr;
}

//---------------------------------------------------------------------------//
STDMETHODIMP Unmarshaler::DisconnectObject( DWORD )
{
	// implemented by marshaler
	return E_NOTIMPL;
}

//---------------------------------------------------------------------------//
STDMETHODIMP Unmarshaler::CreateInstance( IUnknown* pUnkOuter,
	REFIID iid, void** ppv )
{
	if ( !ppv )
		return E_POINTER;
	*ppv = 0;
	if ( pUnkOuter )
		return CLASS_E_NOAGGREGATION;
	return QueryInterface( iid, ppv );
}

//---------------------------------------------------------------------------//
STDMETHODIMP Unmarshaler::LockServer( BOOL bLock )
{
	extern void SvcLock();
	extern void SvcUnlock();
	if ( bLock )
		 SvcLock();
	else SvcUnlock();
	return S_OK;
}
