#ifndef _CRT_H
#define _CRT_H

// placement new
inline void* operator new( size_t, void* p )
{
	return p;
}

#endif // _CRT_H
