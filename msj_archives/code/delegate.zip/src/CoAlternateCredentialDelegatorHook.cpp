/////////////////////////////////////////////////////////////
// CoAlternateCredentialHook.cpp - Generic Delegator Component
//
// Copyright 1998, Keith Brown
//
// Simple hook that overrides the security settings on the
// proxy. No pre/post processing is required, so this is
// a very lightweight hook.
/////////////////////////////////////////////////////////////
#include "precomp.h"
#include "CoAlternateCredentialDelegatorHook.h"

//---------------------------------------------------------------------------//
static wchar_t* _copy( wchar_t* pszDst, const wchar_t* pszSrc, int cch )
{
	CopyMemory( pszDst, pszSrc, cch * sizeof *pszDst );
	return pszDst + cch;
}

//---------------------------------------------------------------------------//
HRESULT CoAlternateCredentialDelegatorHook::_setBlanket( IUnknown* pItfInner )
{
	// if we don't have a proxy, we're a no-op.
	IClientSecurity* pcs = 0;
	if ( FAILED( pItfInner->QueryInterface( IID_IClientSecurity, (void**)&pcs ) ) )
		return S_OK;

	DWORD nAuthnSvc, nAuthzSvc, nAuthnLevel, nImpLevel, grfCaps;
	OLECHAR* pszServerPrincipal = 0;
	void* pAuthIdentity = 0;
	HRESULT hr = pcs->QueryBlanket( pItfInner, &nAuthnSvc, &nAuthzSvc,
		&pszServerPrincipal, &nAuthnLevel, &nImpLevel,
		&pAuthIdentity, &grfCaps );

	if ( SUCCEEDED( hr ) )
	{
		// If SetBlanket fails, we ignore it. There's not much we can do,
		// especially if we have a proxy to an inproc object, which doesn't
		// allow pAuthIdentity customization anyway (returns E_INVALIDARG in this case).
		pcs->SetBlanket( pItfInner,
			( m_grfOptions & ACDH_AUTHNSVC )		? m_nAuthnSvc : nAuthnSvc,
			( m_grfOptions & ACDH_AUTHZSVC )		? m_nAuthzSvc : nAuthzSvc,
			( m_grfOptions & ACDH_SERVERPRINCIPAL ) ? const_cast<OLECHAR*>( m_pszServerPrincipal ) : pszServerPrincipal,
			( m_grfOptions & ACDH_AUTHNLEVEL )		? m_nAuthnLevel : nAuthnLevel,
			( m_grfOptions & ACDH_IMPLEVEL )		? m_nImpLevel : nImpLevel,
			( m_grfOptions & ACDH_CREDENTIALS )		? &m_authIdentity : pAuthIdentity,
			( m_grfOptions & ACDH_CAPS )			? m_grfCaps : grfCaps );
	}

	pcs->Release();
	return S_OK;
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoAlternateCredentialDelegatorHook::QueryInterface(
	REFIID iid, void** ppv )
{
	if ( !ppv )
		return E_POINTER;
	if ( IID_IDelegatorHookQI == iid || IID_IUnknown == iid )
		*ppv = static_cast<IDelegatorHookQI*>( this );
	else if ( IID_IAlternateCredentialDelegatorHook == iid )
		*ppv = static_cast<IAlternateCredentialDelegatorHook*>( this );
	else if ( IID_IPersistStream == iid || IID_IPersist == iid )
		*ppv = static_cast<IPersistStream*>( this );
	else return (*ppv = 0), E_NOINTERFACE;
	reinterpret_cast<IUnknown*>( *ppv )->AddRef();
	return S_OK;
}

//---------------------------------------------------------------------------//
STDMETHODIMP_(ULONG) CoAlternateCredentialDelegatorHook::AddRef()
{
	extern void SvcLock();
	if ( 0 == m_cRefs )
		SvcLock();
	return InterlockedIncrement( &m_cRefs );
}

//---------------------------------------------------------------------------//
STDMETHODIMP_(ULONG) CoAlternateCredentialDelegatorHook::Release()
{
	extern void SvcUnlock();
	ULONG n = InterlockedDecrement( &m_cRefs );
	if ( 0 == n )
	{
		delete this;
		SvcUnlock();
	}
	return n;
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoAlternateCredentialDelegatorHook::Init( IUnknown* pUnkInner )
{
	return _setBlanket( pUnkInner );
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoAlternateCredentialDelegatorHook::OnFirstDelegatorQIFor(
	REFIID iid, IUnknown* pItfInner, DWORD* pgrfDelegatorHookOptions,
	REFIID iidMethodHook, void** ppvMethodHook )
{
	*pgrfDelegatorHookOptions = 0;
	*ppvMethodHook = 0;
	return _setBlanket( pItfInner );
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoAlternateCredentialDelegatorHook::Init(
	DWORD grfOptions,
	DWORD nAuthnSvc,
	DWORD nAuthzSvc,
	const OLECHAR* pszServerPrincipal,
	DWORD nAuthnLevel,
	DWORD nImpLevel,
	const OLECHAR* pszAuthority,
	const OLECHAR* pszPrincipal,
	const OLECHAR* pszPassword,
	DWORD grfCaps )
{

	if ( grfOptions & 0xFFFFFFF80 )
		return E_INVALIDARG;

	m_grfOptions = grfOptions;

	DWORD cchTotal = 0;
	DWORD cchServerPrincipal = 0;
	if ( m_grfOptions & ACDH_SERVERPRINCIPAL )
	{
		if ( !pszServerPrincipal )
			return E_INVALIDARG;
		cchServerPrincipal = wcslen( pszServerPrincipal );
		cchTotal += cchServerPrincipal + 1;
	}
	if ( m_grfOptions & ACDH_CREDENTIALS )
	{
		if ( !pszAuthority || !pszPrincipal || !pszPassword )
			return E_INVALIDARG;
		m_authIdentity.DomainLength		= wcslen( pszAuthority );
		m_authIdentity.UserLength		= wcslen( pszPrincipal );
		m_authIdentity.PasswordLength	= wcslen( pszPassword );
		m_authIdentity.Flags			= SEC_WINNT_AUTH_IDENTITY_UNICODE;
		cchTotal += m_authIdentity.DomainLength + m_authIdentity.UserLength
					+ m_authIdentity.PasswordLength + 3;
	}
	
	m_cbStrings = cchTotal * sizeof( OLECHAR );
	m_pStringBuffer = reinterpret_cast<OLECHAR*>( CoTaskMemAlloc( m_cbStrings ) );
	if ( !m_pStringBuffer )
		return E_OUTOFMEMORY;

	OLECHAR* pCursor = m_pStringBuffer;
	if ( m_grfOptions & ACDH_SERVERPRINCIPAL )
	{
		m_pszServerPrincipal = pCursor;
		pCursor = _copy( pCursor, pszServerPrincipal, cchServerPrincipal + 1 );
	}
	if ( m_grfOptions & ACDH_CREDENTIALS )
	{
		m_authIdentity.Domain = pCursor;
		pCursor = _copy( pCursor, pszAuthority, m_authIdentity.DomainLength + 1 );
		m_authIdentity.User = pCursor;
		pCursor = _copy( pCursor, pszPrincipal, m_authIdentity.UserLength + 1 );
		m_authIdentity.Password = pCursor;
		pCursor = _copy( pCursor, pszPassword,  m_authIdentity.PasswordLength + 1 );
	}
	if ( m_grfOptions & ACDH_AUTHNSVC )
		m_nAuthnSvc = nAuthnSvc;
	if ( m_grfOptions & ACDH_AUTHZSVC )
		m_nAuthzSvc = nAuthzSvc;
	if ( m_grfOptions & ACDH_AUTHNLEVEL )
		m_nAuthnLevel = nAuthnLevel;
	if ( m_grfOptions & ACDH_IMPLEVEL )
		m_nImpLevel = nImpLevel;
	if ( m_grfOptions & ACDH_CAPS )
		m_grfCaps = grfCaps;
	return S_OK;
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoAlternateCredentialDelegatorHook::GetClassID( CLSID* pclsid )
{
	if ( !pclsid )
		return E_POINTER;
	*pclsid = __uuidof(this);
	return S_OK;
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoAlternateCredentialDelegatorHook::IsDirty()
{
	return S_FALSE;
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoAlternateCredentialDelegatorHook::Load( IStream* pstm )
{
	if ( !pstm )
		return E_INVALIDARG;
	if ( m_pStringBuffer )
		return E_UNEXPECTED;

	DWORD rgn[8];
	HRESULT hr = pstm->Read( rgn, sizeof rgn, 0 );
	if ( FAILED( hr ) )
		return hr;

	if ( HOOK_VERSION != rgn[0] )
		return E_FAIL;

	m_grfOptions	= rgn[1];
	m_nAuthnSvc		= rgn[2];
	m_nAuthzSvc		= rgn[3];
	m_nAuthnLevel	= rgn[4];
	m_nImpLevel		= rgn[5];
	m_grfCaps		= rgn[6];
	m_cbStrings		= rgn[7];

	m_pStringBuffer = reinterpret_cast<OLECHAR*>( CoTaskMemAlloc( m_cbStrings ) );
	if ( !m_pStringBuffer )
		return E_OUTOFMEMORY;
	hr = pstm->Read( m_pStringBuffer, m_cbStrings, 0 );
	OLECHAR* pCursor = m_pStringBuffer;
	if ( m_grfOptions & ACDH_SERVERPRINCIPAL )
	{
		m_pszServerPrincipal = pCursor;
		pCursor += wcslen( pCursor ) + 1;
	}
	if ( m_grfOptions & ACDH_CREDENTIALS )
	{
		pCursor += ( m_authIdentity.DomainLength = wcslen( m_authIdentity.Domain = pCursor ) ) + 1;
		pCursor += ( m_authIdentity.UserLength = wcslen( m_authIdentity.User = pCursor ) ) + 1;
		m_authIdentity.PasswordLength = wcslen( m_authIdentity.Password = pCursor );
		m_authIdentity.Flags = SEC_WINNT_AUTH_IDENTITY_UNICODE;
	}
	return hr;
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoAlternateCredentialDelegatorHook::Save( IStream* pstm, BOOL )
{
	if ( !pstm )
		return E_INVALIDARG;

	DWORD rgn[] = { HOOK_VERSION,
					m_grfOptions,
					m_nAuthnSvc,
					m_nAuthzSvc,
					m_nAuthnLevel,
					m_nImpLevel,
					m_grfCaps,
					m_cbStrings };
	HRESULT hr = pstm->Write( rgn, sizeof rgn, 0 );
	if ( FAILED( hr ) )
		return hr;
	hr = pstm->Write( m_pStringBuffer, m_cbStrings, 0 );
	return hr;
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoAlternateCredentialDelegatorHook::GetSizeMax( ULARGE_INTEGER* pcb )
{
	if ( !pcb )
		return E_POINTER;

	DWORD cb =  sizeof HOOK_VERSION +
				sizeof m_grfOptions +
				sizeof m_nAuthnSvc +
				sizeof m_nAuthzSvc +
				sizeof m_nAuthnLevel +
				sizeof m_nImpLevel +
				sizeof m_grfCaps +
				sizeof m_cbStrings +
				m_cbStrings;
	*reinterpret_cast<__int64*>(pcb) = cb;
	return S_OK;
}

