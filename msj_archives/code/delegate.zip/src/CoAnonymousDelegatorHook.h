/////////////////////////////////////////////////////////////
// CoAnonymousDelegatorHook.h - Generic Delegator Component
//
// Copyright 1998, Keith Brown
//
// Simple hook that drops the authn level to NONE for every
// interface. No pre/post processing is required, so this is
// a very lightweight hook.
/////////////////////////////////////////////////////////////
#pragma once

#include "delegate.h"

class __declspec(uuid("9b8c32f6-249a-11d2-a7bb-006008d25ccf"))
	CoAnonymousDelegatorHook :
		public IDelegatorHookQI,
		public IPersist,
		public IClassFactory
{
public:
	HRESULT _setBlanket( IUnknown* pItfInner );
	static void Startup();
	static void Shutdown() {}
	static CoAnonymousDelegatorHook& TheHook();

	STDMETHODIMP QueryInterface( REFIID iid, void** ppv );
	STDMETHODIMP_(ULONG) AddRef();
	STDMETHODIMP_(ULONG) Release();

	STDMETHODIMP Init( IUnknown* pUnkInner );
	STDMETHODIMP OnFirstDelegatorQIFor( REFIID iid,	IUnknown* pItfInner,
		DWORD* pgrfDelegatorHookOptions, REFIID iidMethodHook, void** ppvMethodHook );

	STDMETHODIMP GetClassID( CLSID* pclsid );

	STDMETHODIMP CreateInstance( IUnknown*, REFIID iid, void** ppv );
	STDMETHODIMP LockServer( BOOL bLock );
};
