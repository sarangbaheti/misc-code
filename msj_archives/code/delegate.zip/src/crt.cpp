// crt.cpp - simple, lightweight C Runtime Library
#include "precomp.h"

size_t wcslen( const wchar_t* psz )
{
	const wchar_t* pszBegin = psz;
	while ( *psz )
		psz++;
	return psz - pszBegin;
}

void* operator new( size_t cBytes )
{
	return CoTaskMemAlloc( cBytes );
}

void operator delete( void* p )
{
	CoTaskMemFree( p );
}

void* malloc( size_t cBytes )
{
	return CoTaskMemAlloc( cBytes );
}

void free( void* p )
{
	CoTaskMemFree( p );
}

int __cdecl _purecall()
{
	return 0;
}

// the following methods are implemented intrinsically by the release compiler
// but must be supplied for debug builds to work properly.
#ifdef _DEBUG
void* __cdecl memset( void* p, int c, size_t n )
{
	byte* pb = (byte*)p;
	byte* pbend = pb + n;
	while ( pb != pbend )
		*pb++ = c;
	return p;
}

int __cdecl memcmp( const void* plhs, const void* prhs, size_t n )
{
	const BYTE* pblhs = (BYTE*)plhs;
	const BYTE* pbrhs = (BYTE*)prhs;


	for ( size_t i = 0; i < n; ++i )
	{
		if ( *pblhs < *pbrhs )
			return -1;
		else if ( *pblhs > *pbrhs )
			return 1;
		++pblhs;
		++pbrhs;
	}
	return 0;
}

void* __cdecl memcpy( void* pDest, const void* pSrc, size_t n )
{
	const BYTE* pbSrc = (BYTE*)pSrc;
	BYTE* pb = (BYTE*)pDest;
	BYTE* pbend = pb + n;
	while ( pb != pbend )
		*pb++ = *(BYTE*)pbSrc++;
	return pDest;
}
#endif // _DEBUG
