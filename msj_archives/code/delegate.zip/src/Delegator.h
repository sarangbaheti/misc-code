/////////////////////////////////////////////////////////////
// Delegator.h - Generic Delegator Component
//
// Copyright 1998, Keith Brown
//
// The Delegator class holds a single interface pointer and
// implements the delegating unknown, as well as the auto-
// forwarding of method calls to the inner object.
// Delegator objects notify their CoDelegator parent when
// their individual refcount drops to zero so the parent
// can destroy them and remove them from the collection.
/////////////////////////////////////////////////////////////
#ifndef _DELEGATOR_H
#define _DELEGATOR_H

#include "delegate.h"

class CoDelegator;
interface IDelegatorHookMethods;

//---------------------------------------------------------------------------//
// We hand out a Delegator struct for each wrapped interface pointer.
// Note the size of this object is significant (28 bytes).
// This is the main reason that we refcount each interface ptr,
// to avoid CoDelegator from getting too corpulent :)
struct Delegator
{
	static const void* _assignVptr( DWORD grfOptions )
	{
		return (grfOptions & DHO_POSTPROCESS_METHODS) ? s_vptr2 : s_vptr;
	}

	Delegator( CoDelegator& parent, IUnknown* pUnkInner, const IID& iid,
				DWORD grfOptions, IDelegatorHookMethods* pHook )
	  : m_vptr( _assignVptr( grfOptions ) ),
		m_pUnkInner( pUnkInner ),
		m_grf( grfOptions ),
		m_parent( parent ),
		m_pHook( pHook ),
		m_iid( iid ),
		m_cRefs( 0 )
	{
		m_pUnkInner->AddRef();
		if ( m_pHook )
			m_pHook->AddRef();
	}
	~Delegator()
	{
		if ( m_pHook )
			m_pHook->Release();
		m_pUnkInner->Release();
	}

	// this flag will be set in m_grf if the QI hook returned
	// a failure code from OnFirstDelegatorQIFor
	enum { DONT_EXPOSE_FROM_QI = 0x80000000 };

	const void*	const		m_vptr;			// ORDER_DEPENDENCY (this + 0 bytes)
	IUnknown*				m_pUnkInner;	// ORDER_DEPENDENCY (this + 4 bytes)
	DWORD					m_grf;			// ORDER_DEPENDENCY (this + 8 bytes)
	CoDelegator&			m_parent;
	IDelegatorHookMethods*	m_pHook;
	const IID				m_iid;
	long					m_cRefs;		// refcount for this interface

	static const void* const s_vptr;		// used when only preprocessing is desired
	static const void* const s_vptr2;		// used when postprocessing also needed
};

#endif // _DELEGATOR_H
