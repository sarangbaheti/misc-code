/////////////////////////////////////////////////////////////
// Delegator.cpp - Generic Delegator Component
//
// Copyright 1998, Keith Brown
//
// The Delegator class holds a single interface pointer and
// implements the delegating unknown, as well as the auto-
// forwarding of method calls to the inner object.
// Delegator objects notify their CoDelegator parent when
// their individual refcount drops to zero so the parent
// can remove them from the collection.
/////////////////////////////////////////////////////////////
#include "precomp.h"
#include "Delegator.h"
#include "CoDelegator.h"

// delegating unknown
STDMETHODIMP Delegator_QueryInterface( Delegator* pThis, REFIID iid, void** ppv )
{
	return pThis->m_parent.GetOuter()->QueryInterface( iid, ppv );
}

STDMETHODIMP_(ULONG) Delegator_AddRef( Delegator* pThis )
{
	// thread-safe - only the initial thread hits both resources
	if ( 0 == pThis->m_cRefs )
		pThis->m_parent.GetOuter()->AddRef();
	return InterlockedIncrement( &pThis->m_cRefs );
}

STDMETHODIMP_(ULONG) Delegator_Release( Delegator* pThis )
{
	const long cRefs = InterlockedDecrement( &pThis->m_cRefs );
	if ( 0 != cRefs )
		return cRefs;

	if ( pThis->m_parent.RemoveDelegatorIfNoRefs( pThis ) )
	{
		pThis->m_parent.GetOuter()->Release();
		delete pThis;
		return 0;
	}
	else return 1; // not terribly important, but makes code a little clearer
}

#pragma code_seg(".orpc")

// this method is called when *only* preprocessing is required
void __stdcall preprocess( Delegator& d, DWORD nVtblOffset, void* pArgs )
{
	d.m_pHook->DelegatorPreprocess( nVtblOffset / sizeof( void* ), pArgs, 0 );
}

// this method is called if we need to postprocess as well
DWORD __stdcall preprocess2( Delegator& d, const void* pReturnAddr,
							 DWORD nVtblOffset, void* pArgs )
{
	// first try to acquire a buffer - if this fails, we cannot do any delegation
	// at all - just shunt the method directly to the inner object and forget it.
	CallContext* pcc = CoDelegator::PushNewCallContext( d, pReturnAddr, nVtblOffset );
	if ( !pcc )
		return 0;

	if ( DHO_PREPROCESS_METHODS & d.m_grf )
		d.m_pHook->DelegatorPreprocess( nVtblOffset / sizeof( void* ), pArgs, &pcc->m_nCookie );

	return 1;
}

HRESULT __stdcall postprocess( HRESULT hrFromInner,
								const void** ppReturnAddr )
{
	// get the call context back from TLS
 	CallContext* const pcc = CoDelegator::PopCallContext();

	HRESULT hr = pcc->m_pDelegator->m_pHook->
			DelegatorPostprocess( pcc->m_nVtblOffset / sizeof( void* ), hrFromInner, pcc->m_nCookie );

	*ppReturnAddr = pcc->m_pReturnAddr;
	CoDelegator::DeleteCallContext( pcc );

	return hr;
}

static __declspec(naked) void delegate(void)
{
	__asm
	{
		push ebp			// set up simple stack frame
		mov  ebp, esp

		// ebp/nVtblOffset/retaddr/this/args
		push ecx
		mov  ecx, [ebp+12]	// ecx = this

		mov  eax, [ecx+8]	// if ( 0 == ( this->m_grf & 1 ) )
		test eax, 1			//   goto skipPreprocess;
		jz skipPreprocess

		lea  eax, [ebp+16]	// preprocess( this, nVtblOffset, pArgs );
		push eax
		mov  eax, [ebp+4]
		push eax
		push ecx
		call preprocess
		mov  ecx, [ebp+12]	// ecx = this

	skipPreprocess:
		
		mov  eax, [ecx+4]	// this = eax = pInner
		mov  [ebp+12], eax	

		mov  eax, [eax]
		add  eax, [ebp+4]
		mov  eax, [eax]		// eax = address of sink's virtual function

		pop  ecx
		pop  ebp
		mov  [esp], eax
		ret
	}
}

static __declspec(naked) void delegateAndPostprocess(void)
{
	__asm
	{
		// get the vtbl index
		pop  eax			// eax = vtbl index (in bytes)
		sub  esp, 8
		push eax
		push ebp			// set up simple stack frame
		mov  ebp, esp

		// ebp+4  = local variable: vtbl offset (in bytes)
		// ebp+8  = local variable: result of context allocation
		// ebp+12 = local variable: address of inner's method
		// ebp+16 = retaddr
		// ebp+20 = this
		// ebp+24 = args

		lea  eax, [ebp+24]	// eax = preprocess( this, pReturnAddr, nVtblOffset, pArgs );
		push eax
		push [ebp+4]
		push [ebp+16]
		push [ebp+20]
		call preprocess2
		mov  [ebp+8], eax	// store result of context allocation

		mov  eax, [ebp+20]	// this = eax = pInner
		mov  eax, [eax+4]
		mov  [ebp+20], eax	

		mov  eax, [eax]		// store address of inner's virtual function
		add  eax, [ebp+4]
		mov  eax, [eax]		
		mov  [ebp+12], eax

		pop  ebp			// tear down stack frame
		pop  eax			// discard vtbl offset

		pop  eax			// was context alloc successful?
		test eax, 1
		jnz allocSuccessful

		pop	 eax			// delegate without postprocessing
		jmp eax

	allocSuccessful:
		pop  eax
		add  esp, 4			// remove caller's return addr from stack and call inner
		call eax

		sub  esp, 4			// make room for original return addr
		push esp			// eax = postprocess( eax, ppReturnAddr )
		push eax
		call postprocess

		ret
	}
}

#define DELEGATOR_ENTRY_POINTS(n) \
static void __declspec(naked) del_##n(void)  \
{ __asm push (n*4) __asm jmp delegate }		 \
static void __declspec(naked) del2_##n(void) \
{ __asm push (n*4) __asm jmp delegateAndPostprocess }

#include "entrypoints.inc"
