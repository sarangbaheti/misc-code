#include <windows.h>
#include <windowsx.h>
#include <toolhelp.h>
#include <malloc.h>
#include <memory.h>

typedef struct _LOADPARMS {
    WORD      segEnv;         /* child environment  */
    LPSTR     lpszCmdLine;    /* child command tail */
    UINT FAR* lpShow;         /* how to show child  */
    UINT FAR* lpReserved;     /* must be NULL       */
} LOADPARMS;

void ShowEnvironment( WORD environmentSelector );

// The environment that we'll pass to the second instance.  Note the
// double NULL's at the end.
char DummyEnvironment[] = "Rubber Baby Buggy Bumpers!\0BFG9000\0\0";

int PASCAL WinMain( HANDLE hInstance, HANDLE hPrevInstance,
                    LPSTR lpszCmdLine, int nCmdShow )
{
    LOADPARMS loadParms;
    UINT ShowStuff[2] = {2, SW_SHOWNORMAL};
    LPBYTE customChildEnvironment;
    HINSTANCE childHInstance;
    WORD childEnvironmentSeg;
    char szOurFileName[260];
    TASKENTRY te;
    MSG msg;
    
    if ( hPrevInstance )    // If this is the 2nd instance...
    {
        // Show the environment, post a message to the parent app, then exit
        ShowEnvironment( *(LPWORD)MAKELP(GetCurrentPDB(), 0x2C) );
        PostAppMessage( *(LPWORD)MAKELP(GetCurrentTask(),0x22),
                        0, 0, 0x12345678L );
        return 0;
    }

    // Create an environment segment to pass to the second instance.  We
    // only get to specify a segment (without an offset), so the we'll
    // GlobalAlloc a block of memory, and copy the desired environment
    // into it.
    customChildEnvironment =
        (LPBYTE) GlobalAllocPtr(GMEM_MOVEABLE, sizeof(DummyEnvironment) );
    memcpy(customChildEnvironment, DummyEnvironment, sizeof(DummyEnvironment));

    // Set up the LOADPARMS struct in preparation for the call to LoadModule
    loadParms.segEnv = SELECTOROF(customChildEnvironment);
    loadParms.lpszCmdLine = "\0\r"; // Empty command line
    loadParms.lpShow = ShowStuff;   // 2, SW_SHOWNORMAL
    loadParms.lpReserved = NULL;

    MessageBox(0, "Click \"OK\" to start a second instance of this program "
                  "with a customized environment.  The contents of its "
                  "environment will be in the next MessageBox you see.",
                  "PASSENV", MB_OK);
                      
    // Get the complete path of this program so that we can LoadModule
    // another instance of it.
    GetModuleFileName( hInstance, szOurFileName, sizeof(szOurFileName) );

    // Load a second instance of this program
    childHInstance = LoadModule(szOurFileName, &loadParms);
    if ( childHInstance < 32 )
        return 0;
    
    // We no longer need our copy of the environment we passed to the child
    GlobalFreePtr( customChildEnvironment );

    // Find the hTask of the child task using TOOLHELP TaskFirst/TaskNext
    te.dwSize = sizeof(te);
    for ( TaskFirst(&te); TaskNext(&te); )
        if ( te.hInst == childHInstance )
            break;
    
    if ( te.hInst != childHInstance )   // Hmmm... didn't find it.  This
        return 0;                       // shouldn't happen.

    // Get the environment segment out of the child task's PDB/PSP
    childEnvironmentSeg = *(LPWORD)MAKELP(te.wPSPOffset, 0x2C);

    // Wait for the second instance to exit.  We'll know when this occurs
    // because the second instance will post us a msg with HNWD == 0 and
    // an LPARAM of 0x12345678.
    while ( GetMessage(&msg, 0, 0, 0) )
        if ( (msg.hwnd == 0) && (msg.lParam == 0x12345678L) )
            break;

    MessageBox(0, "The second instance has now exited.  The next MessageBox "
                  "shows that the memory allocated for its environment is "
                  "still around and wasn't freed when the child exited.",
                  "PASSENV", MB_OK );

    // Show the second instance's environment segment again.
    ShowEnvironment( childEnvironmentSeg );
    
    return 0;
}

void ShowEnvironment( WORD environmentSelector )
{
    // Show the environment strings in the segment passed as the parameter.
    // Uses MessageBox to display the strings.
        
    WORD environmentLen;
    LPSTR lpEnvironment, lpszEnvironCopy, lp, lp2;

    // Make a far pointer to the beginning of the segment
    lp = lpEnvironment = MAKELP(environmentSelector, 0);

    // Now scan for the end of segment ( two NULL characters in a row )
    while( *lp || *(lp+1) )
        lp++;
    
    environmentLen = OFFSETOF(lp) + 2;  // Calculate total environment length

    // Allocate memory to make a copy of the environment segment, then
    // copy the environment into the copy.
    lp2 = lpszEnvironCopy = malloc( environmentLen );
    memcpy( lpszEnvironCopy, lpEnvironment, environmentLen );

    // Scan through the copy of the environment data, replacing single
    // NULL characters with '\r' (carriage-return).  This will cause
    // the call to MessageBox to display each string on its own line.
    while ( *lp2 || *(lp2+1) )
    {
        if ( *lp2 == 0 )
            *lp2 = '\r';
        lp2++;
    }

    MessageBox( 0, lpszEnvironCopy, "Environment is:", MB_OK );
    
    free( lpszEnvironCopy );
}
