/*
  MSJDrvr.C - 1998 James M. Finnegan - Microsoft Systems Journal

  This module implements all of the IOCTLs described in the accompanying article
*/

#include "ntddk.h"



#define FILE_DEVICE_UNKNOWN             0x00000022
#define IOCTL_UNKNOWN_BASE              FILE_DEVICE_UNKNOWN

#define IOCTL_MSJDRVR_GET_STRING     CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0800, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
#define IOCTL_MSJDRVR_READ_MBR       CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0801, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
#define IOCTL_MSJDRVR_READ_CMOS      CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0802, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)


void MSJUnloadDriver(PDRIVER_OBJECT DriverObject);

NTSTATUS MSJDispatchCreate(IN PDEVICE_OBJECT DeviceObject,
                       IN PIRP Irp);

NTSTATUS MSJDispatchClose(IN PDEVICE_OBJECT DeviceObject,
                       IN PIRP Irp);

NTSTATUS MSJDispatchIoctl(IN PDEVICE_OBJECT DeviceObject,
                            IN PIRP Irp);


NTSTATUS DriverEntry(IN PDRIVER_OBJECT DriverObject,
                     IN PUNICODE_STRING RegistryPath)
/*++

Routine Description:

    This routine is called when the driver is loaded by NT.

Arguments:

    DriverObject - Pointer to driver object created by system.
    RegistryPath - Pointer to the name of the services node for this driver.

Return Value:

    The function value is the final status from the initialization operation.

--*/
{
    NTSTATUS        ntStatus;
    UNICODE_STRING  uszDriverString;
    UNICODE_STRING  uszDeviceString;
    PDEVICE_OBJECT  pDeviceObject;

        
    // Point uszDriverString at the driver name
    RtlInitUnicodeString(&uszDriverString, L"\\Device\\MSJDrvr");

    // Create and initialize device object
    ntStatus = IoCreateDevice(DriverObject,
                              0,
                              &uszDriverString,
                              FILE_DEVICE_UNKNOWN,
                              0,
                              FALSE,
                              &pDeviceObject);

    if(ntStatus != STATUS_SUCCESS)
        return ntStatus;

    // Point uszDeviceString at the device name
    RtlInitUnicodeString(&uszDeviceString, L"\\DosDevices\\MSJDrvr");

    // Create symbolic link to the user-visible name
    ntStatus = IoCreateSymbolicLink(&uszDeviceString, &uszDriverString);

    if(ntStatus != STATUS_SUCCESS)
    {
        // Delete device object if not successful
        IoDeleteDevice(pDeviceObject);
        return ntStatus;
    }

    // Load structure to point to IRP handlers...
    DriverObject->DriverUnload                         = MSJUnloadDriver;
    DriverObject->MajorFunction[IRP_MJ_CREATE]         = MSJDispatchCreate;
    DriverObject->MajorFunction[IRP_MJ_CLOSE]          = MSJDispatchClose;
    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = MSJDispatchIoctl;

    // Return success
    return ntStatus;
}


NTSTATUS MSJDispatchCreate(IN PDEVICE_OBJECT DeviceObject,
                       IN PIRP Irp)
{
    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information=0;

    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return(STATUS_SUCCESS);
}


NTSTATUS MSJDispatchClose(IN PDEVICE_OBJECT DeviceObject,
                       IN PIRP Irp)
{
    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information=0;

    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return(STATUS_SUCCESS);
}


typedef struct tagCMOSMemory
{
    ULONG ulBaseMem;
    ULONG ulExtMem;
}CMOS_MEMORY, *PCMOS_MEMORY;


NTSTATUS MSJReadDriveZeroMasterBootRecord(PUCHAR pBuffer)
{
    NTSTATUS        ntStatus;
    UNICODE_STRING  uszDeviceName;
    PFILE_OBJECT    fileObject;
    PDEVICE_OBJECT  pDriveDeviceObject;


    // Initialize unicode string
    RtlInitUnicodeString(&uszDeviceName, L"\\DosDevices\\PhysicalDrive0");

    // Get a pointer to PhysicalDrive0
    ntStatus = IoGetDeviceObjectPointer(&uszDeviceName,
                                        FILE_READ_ATTRIBUTES,
                                        &fileObject,
                                        &pDriveDeviceObject);

    // If the device object pointer is valid...
    if(NT_SUCCESS(ntStatus))
    {
        IO_STATUS_BLOCK    ioStatus; 
        KEVENT             event; 
        PIRP               pIrp;

        LARGE_INTEGER   sectorNum;

            
        KeInitializeEvent(&event, NotificationEvent, FALSE); 
            

        sectorNum.LowPart = sectorNum.HighPart = 0;

        pIrp = IoBuildSynchronousFsdRequest(IRP_MJ_READ,
                                            pDriveDeviceObject,
                                            pBuffer,
                                            512,
                                            &sectorNum,
                                            &event,
                                            &ioStatus);

        if(!pIrp)
           return FALSE; 

        ntStatus = IoCallDriver(pDriveDeviceObject, pIrp);
 
        if(ntStatus == STATUS_PENDING)
        {
            KeWaitForSingleObject(&event, Suspended, KernelMode, FALSE, NULL);
            ntStatus = ioStatus.Status;
        } 

        if(!NT_SUCCESS(ntStatus))
            return ntStatus; 

            
        // Ditch the fileObject pointer created earlier
        ObDereferenceObject(fileObject);
    }
    
    return ntStatus;
}


NTSTATUS MSJReadMemoryStatsFromCMOS(PCMOS_MEMORY pMemory)
{
    UCHAR byHiByte, byLowByte;
    UCHAR byBuffer[256];

#if 0
    /*
    The following code demonstrates a straight port from old MS-DOS or 16-bit
    Windows code to obtain CMOS data.  It shows that I/O ports can be freely
    poked and prodded via kernel-mode.  Even though this code works, the
    proper way to obtain CMOS info under Windows NT is demonstrated below,
    via the call to HalGetBusData().
    */
    
    // Get base memory bytes from CMOS
    WRITE_PORT_UCHAR((PUCHAR)0x70, 0x15);
    byLowByte = READ_PORT_UCHAR((PUCHAR)0x71);
    WRITE_PORT_UCHAR((PUCHAR)0x70, 0x16);
    byHiByte = READ_PORT_UCHAR((PUCHAR)0x71);

    pMemory->ulBaseMem = (byHiByte << 8) | byLowByte;

    // Get extended memory bytes from CMOS
    WRITE_PORT_UCHAR((PUCHAR)0x70, 0x17);
    byLowByte = READ_PORT_UCHAR((PUCHAR)0x71);
    WRITE_PORT_UCHAR((PUCHAR)0x70, 0x18);
    byHiByte = READ_PORT_UCHAR((PUCHAR)0x71);

    pMemory->ulExtMem = (byHiByte << 8) | byLowByte;
#endif

    // Read the CMOS info from HAL, since it "owns" the CMOS resource...
    HalGetBusData(Cmos, 0, 0, &byBuffer, sizeof(byBuffer));

    // Get the values from the appropriate offsets and load up the
    // caller's structure...
    
    // Base memory
    byLowByte = byBuffer[0x15];
    byHiByte = byBuffer[0x16];
    pMemory->ulBaseMem = (byHiByte << 8) | byLowByte;

    // Extended memory
    byLowByte = byBuffer[0x17];
    byHiByte = byBuffer[0x18];
    pMemory->ulExtMem = (byHiByte << 8) | byLowByte;

    return STATUS_SUCCESS;
}


NTSTATUS MSJDispatchIoctl(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp)
{
    NTSTATUS ntStatus;
    PIO_STACK_LOCATION     irpStack = IoGetCurrentIrpStackLocation(Irp);

    
    switch(irpStack->Parameters.DeviceIoControl.IoControlCode)
    {
        case IOCTL_MSJDRVR_GET_STRING:
            strcpy(Irp->AssociatedIrp.SystemBuffer, "Hello from NT Kernel-land!\n");
            ntStatus = STATUS_SUCCESS;
            break;

        case IOCTL_MSJDRVR_READ_MBR:
            // Read the MBR if the output buffer is at least the size of one sector
            if(irpStack->Parameters.DeviceIoControl.OutputBufferLength >= 512)
                ntStatus = MSJReadDriveZeroMasterBootRecord(Irp->AssociatedIrp.SystemBuffer);
            else
                ntStatus = STATUS_BUFFER_TOO_SMALL;
            break;

        case IOCTL_MSJDRVR_READ_CMOS:
            // Query the CMOS if the output buffer can hold our results...
            if(irpStack->Parameters.DeviceIoControl.OutputBufferLength >= sizeof(CMOS_MEMORY))
                ntStatus = MSJReadMemoryStatsFromCMOS(Irp->AssociatedIrp.SystemBuffer);
            else
                ntStatus = STATUS_BUFFER_TOO_SMALL;
            break;

        default:
            break;
    }

    Irp->IoStatus.Status = ntStatus;
    
    // Set # of bytes to copy back to user-mode...
    if(ntStatus == STATUS_SUCCESS)
        Irp->IoStatus.Information = irpStack->Parameters.DeviceIoControl.OutputBufferLength;
    else
        Irp->IoStatus.Information = 0;

    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return ntStatus;
}


void MSJUnloadDriver(PDRIVER_OBJECT DriverObject)
{
    UNICODE_STRING  uszDeviceString;


    IoDeleteDevice(DriverObject->DeviceObject);

    RtlInitUnicodeString(&uszDeviceString, L"\\DosDevices\\MSJDrvr");
    IoDeleteSymbolicLink(&uszDeviceString);
}
