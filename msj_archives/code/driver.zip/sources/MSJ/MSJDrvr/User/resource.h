//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestApp.rc
//
#define IDR_MENU                        101
#define IDD_ABOUT                       102
#define MSJDAT95                        104
#define MSJDATNT                        105
#define ID_MENU_EXIT                    40001
#define IDM_FILE_EXIT                   40001
#define IDM_TEST_GET_STRING             40002
#define IDM_TEST_MBR_FROM_DRIVE         40003
#define IDM_TEST_MBR_FROM_DRIVER        40004
#define IDM_HELP_ABOUT                  40005
#define IDM_TEST_CMOS_MEMORY            40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
