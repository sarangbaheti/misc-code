/*
    TestApp.c - 1998 James M. Finnegan - Microsoft Systems Journal

    This is the main module for TestApp, which dispatches various
    IOCTLs to the NT driver or VxD
*/
#include <windows.h>         
#include <winioctl.h>
#include "resource.h"


// Define IOCTLs that we use in our driver.  You should really put
// these in a common header file, and share them between the code modules
#define FILE_DEVICE_UNKNOWN             0x00000022
#define IOCTL_UNKNOWN_BASE              FILE_DEVICE_UNKNOWN

#define IOCTL_MSJDRVR_GET_STRING        CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0800, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
#define IOCTL_MSJDRVR_READ_MBR       CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0801, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
#define IOCTL_MSJDRVR_READ_CMOS      CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0802, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)

// Structure definitions...
#pragma pack(1)
typedef struct tagCMOSMemory
{
    ULONG ulBaseMem;
    ULONG ulExtMem;
}CMOS_MEMORY, *PCMOS_MEMORY;


typedef struct tagPartitionInfo
{
    UCHAR ucActivePartFlag; // Indicator of active (boot) partition
    UCHAR ucDH;        // Starting CHS, in Int13h format
    UCHAR ucCL;
    UCHAR ucCH;
    UCHAR ucType;      // Partition (File System) type
    UCHAR ucEndDH;     // Ending CHS, in Int13h format
    UCHAR ucEndCL;
    UCHAR ucEndCH;
    DWORD dwLba;       // Start of partition (in sectors)
    DWORD dwSize;      // Size of partition (in sectors)
} PART_INFO, *PPART_INFO;


typedef struct tagMBR
{
    UCHAR ucBootProgramAndData[0x1be];  // Bootstrap app.
    PART_INFO PartInfo[4];   // Storage for up to 4 primary partitions
    USHORT usSignature;      // MBR signature - should be 0xaa55
}MBR, *PMBR;
#pragma pack()


// External functions in Dynamic.c
extern HANDLE LoadDriver(OSVERSIONINFO *os, BOOL *fNTDynaLoaded);
extern BOOL UnloadDynamicNTDriver();

HINSTANCE ghInst;


VOID CenterWindow(HWND hWnd)
{
    RECT rect;
    WORD wWidth,
         wHeight;
         
         
    GetWindowRect(hWnd,&rect);

    wWidth =GetSystemMetrics(SM_CXSCREEN);
    wHeight=GetSystemMetrics(SM_CYSCREEN);

    MoveWindow(hWnd,(wWidth/2)   - ((rect.right -  rect.left)/2),
                    (wHeight/2)  - ((rect.bottom - rect.top) /2),
                     rect.right  -   rect.left,
                     rect.bottom -   rect.top, 
                     FALSE);
}


BOOL CALLBACK DlgProc(HWND hWnd,UINT uMessage,WPARAM wParam,LPARAM lParam)
{
    static WORD wTimer;

    switch(uMessage)
    {
        case WM_INITDIALOG:
            CenterWindow(hWnd);
            return FALSE;
            break;

		case WM_COMMAND:
			switch(wParam)
			{
				case IDOK:
					EndDialog(hWnd, FALSE);
					break;
			}
			break;
            
            
        default:
            return FALSE;
    }
    
    return TRUE;
}


void DisplayPartitionInfo(HWND hWnd, PMBR pMbr)
{
    char szOutput[256];
    char szTemp[80];
    int i;

    
    // Display the MBR's signature
    wsprintf(szOutput,"MBR Signature: 0x%x\n\n",pMbr->usSignature);
    
    strcat(szOutput,"#  Active\tType\tStarting CHS  Ending CHS\tStart\tLength\n");

    // Loop thru all 4 primary partition entries...
    for(i = 0; i < 4; i++)
    {
        // Convert the int13h-style partition values into reasonable CHS values...
        wsprintf(szTemp,"%1d  %s\t%1d\t%04d %02d %02d   %04d %02d %02d\t%ld\t%ld\n", 
                                                    i+1,
                                                    (pMbr->PartInfo[i].ucActivePartFlag) ? "Yes" : "No",
                                                    pMbr->PartInfo[i].ucType,
                                                    ((pMbr->PartInfo[i].ucCL & 0xc0) << 2) | (USHORT)(pMbr->PartInfo[i].ucCH),
                                                    pMbr->PartInfo[i].ucDH,
                                                    pMbr->PartInfo[i].ucCL & 0x3f,
                                                    ((pMbr->PartInfo[i].ucEndCL & 0xc0) << 2) | (pMbr->PartInfo[i].ucEndCH),
                                                    pMbr->PartInfo[i].ucEndDH,
                                                    pMbr->PartInfo[i].ucEndCL & 0x3f,
                                                    pMbr->PartInfo[i].dwLba,
                                                    pMbr->PartInfo[i].dwSize);

        strcat(szOutput,szTemp);
    }    

    // Show the results!
    MessageBox(hWnd,szOutput,"Disk 0 Partition Information",MB_OK);
}


LRESULT WINAPI WndProc(HWND hWnd,UINT uMessage,WPARAM wParam,LPARAM lParam)
{
    static OSVERSIONINFO os={0};
    static BOOL fNTDynaLoaded;
    static HANDLE hDriver = INVALID_HANDLE_VALUE;


    switch(uMessage)
    {
        case WM_CREATE:
            // Get the current OS information.  Place it in a static
            // structure for later use...
            os.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
            GetVersionEx(&os);

			// Call LoadDriver (in DrvrLoad.c) to load our
            // NT KM driver or 95 VxD, depending on the current OS

// Uncomment the following lines to load the driver from an external file.
// Do this to test the driver for static loading under a non-privileged account.             
//            hDriver = LoadDriver(&os, &fNTDynaLoaded);
            
            // If we couldn't load the driver, try creating it from our
            // embedded resource and load it again!
            if(hDriver == INVALID_HANDLE_VALUE)
            {
	            HRSRC       hRsrc;
                HGLOBAL     hDriverResource;
                DWORD		dwDriverSize;    
                LPVOID		lpvDriver;
                HFILE       hfTempFile;
                OFSTRUCT    of;


                // If we're under NT, load the .SYS resource...
			    if(os.dwPlatformId == VER_PLATFORM_WIN32_NT)
				    hRsrc = FindResource(ghInst,MAKEINTRESOURCE(MSJDATNT),"BINRES");
			    // Otherwise we're under 95, load the .VXD resource...
			    else
				    hRsrc = FindResource(ghInst,MAKEINTRESOURCE(MSJDAT95),"BINRES");

			    hDriverResource = LoadResource(ghInst, hRsrc);
			    dwDriverSize = SizeofResource(ghInst, hRsrc);
			    lpvDriver = LockResource(hDriverResource);

			    // Dump the resource out to a file
                if(os.dwPlatformId == VER_PLATFORM_WIN32_NT)
			        hfTempFile = _lcreat("msjdrvr.sys",0);
                else
			        hfTempFile = _lcreat("msjdrvr.vxd",0);

			    _hwrite(hfTempFile, lpvDriver, dwDriverSize); 
			    _lclose(hfTempFile);
    
    		    // Try loading it again!
                hDriver = LoadDriver(&os, &fNTDynaLoaded);

			    // Delete the temp file...
                if(os.dwPlatformId == VER_PLATFORM_WIN32_NT)
 			        OpenFile("msjdrvr.sys",&of,OF_DELETE);
                else
 			        OpenFile("msjdrvr.vxd",&of,OF_DELETE);
            }

            // If we *still* couldn't load the driver, turn off the menu picks
            // that depend on it...
            if(hDriver == INVALID_HANDLE_VALUE)
            {
                HMENU hMenu = GetMenu(hWnd);

                EnableMenuItem(hMenu, IDM_TEST_GET_STRING,      MF_BYCOMMAND | MF_GRAYED);
                EnableMenuItem(hMenu, IDM_TEST_MBR_FROM_DRIVER, MF_BYCOMMAND | MF_GRAYED);
                EnableMenuItem(hMenu, IDM_TEST_CMOS_MEMORY,     MF_BYCOMMAND | MF_GRAYED);
            }

            // If we're not running under NT, turn off the
            // menu picks that are not supported in the VxD...
            if(os.dwPlatformId != VER_PLATFORM_WIN32_NT)            
            {
                HMENU hMenu = GetMenu(hWnd);

                EnableMenuItem(hMenu, IDM_TEST_MBR_FROM_DRIVE,  MF_BYCOMMAND | MF_GRAYED);
                EnableMenuItem(hMenu, IDM_TEST_MBR_FROM_DRIVER, MF_BYCOMMAND | MF_GRAYED);
                EnableMenuItem(hMenu, IDM_TEST_CMOS_MEMORY,     MF_BYCOMMAND | MF_GRAYED);
            }

            break;

        case WM_COMMAND:
            switch(wParam)
            {
                // Call the NT driver/VxD to obtain and display whatever string
                // this IOCTL returns...
                case IDM_TEST_GET_STRING:
                {    
                    DWORD dwBytesReturned;
                    BOOL  bReturnCode = FALSE;
                    OVERLAPPED ov={0};
                    char szString[80];


                    // Create an event handle for async notification
                    // from our driver
                    ov.hEvent = CreateEvent(NULL,  // Default security
                                            TRUE,  // Manual reset
                                            FALSE, // non-signaled state
                                            NULL); // No name

                    // Dispatch the GET_STRING IOCTL to our NT or 95 driver.
                    // Which driver is loaded is irrelevant, since both
                    // support the same interface :-)
                    bReturnCode = DeviceIoControl(hDriver,
                                  IOCTL_MSJDRVR_GET_STRING,
                                  0, 0,
                                  szString, sizeof(szString),
                                  &dwBytesReturned,
                                  &ov);
        
                    // Wait here for the event handle to be set, indicating
                    // that the IOCTL processing is complete.
                    bReturnCode = GetOverlappedResult(hDriver, &ov,
                                                      &dwBytesReturned, TRUE);

                    CloseHandle(ov.hEvent);

                    // Display the results!
                    MessageBox(hWnd,szString,"Get Driver String",MB_OK);
                    break;
                }

                // Get the MBR directly from \\PhysicalDrive0.  This will not
                // work for accounts that do not have adminstrator privileges
                case IDM_TEST_MBR_FROM_DRIVE:
                {
                    HANDLE hPhysicalDrive;


                    // Open the device representing the first hard disk.  This
                    // call will fail if the user doesn' have sufficient rights
                    hPhysicalDrive = CreateFile("\\\\.\\PhysicalDrive0",
                                         GENERIC_READ | GENERIC_WRITE, 
                                         FILE_SHARE_READ | FILE_SHARE_WRITE,
                                         0, OPEN_EXISTING,
                                         0, 0);
        
                    if(hPhysicalDrive == INVALID_HANDLE_VALUE)
                    {
                        char szError[80];

                        wsprintf(szError, "Error %ld", GetLastError());
                        MessageBox(hWnd, "Drive 0 Open Error", szError, MB_OK);
                    }
                    else
                    {
                        MBR data;
                        DWORD dwBytesRead;

                        // Read sector 0 off of the drive...
                        ReadFile(hPhysicalDrive, &data, 512, &dwBytesRead, NULL);

                        // Display it!
                        DisplayPartitionInfo(hWnd, &data);
			    
                        // Close the driver
                        CloseHandle(hPhysicalDrive);
                    }
                    
                    break;
                }
                
                // Get the MBR indirectly via our NT driver.  This demonstrates
                // how a driver can call normally "protected" resources on 
                // behalf of of users that do not have sufficient privileges.
                case IDM_TEST_MBR_FROM_DRIVER:
                {    
                    DWORD dwBytesReturned;
                    BOOL  bReturnCode = FALSE;
                    OVERLAPPED ov={0};
                    MBR data;


                    // Create an event handle for async notification
                    // from our driver
                    ov.hEvent = CreateEvent(NULL,  // Default security
                                            TRUE,  // Manual reset
                                            FALSE, // non-signaled state
                                            NULL); // No name

                    bReturnCode = DeviceIoControl(hDriver,
                                  IOCTL_MSJDRVR_READ_MBR,
                                  0, 0,
                                  &data, sizeof(data),
                                  &dwBytesReturned,
                                  &ov);
        
                    // Wait here for the event handle to be set, indicating
                    // that the IOCTL processing is complete.
                    bReturnCode = GetOverlappedResult(hDriver, &ov,
                                                      &dwBytesReturned, TRUE);

                    CloseHandle(ov.hEvent);

                    // Display the results!
                    DisplayPartitionInfo(hWnd, &data);
                    break;
                }

                case IDM_TEST_CMOS_MEMORY:
                {    
                    DWORD dwBytesReturned;
                    BOOL  bReturnCode = FALSE;
                    OVERLAPPED ov={0};
                    CMOS_MEMORY Memory;

                    char szText[80];


                    // Create an event handle for async notification
                    // from our driver
                    ov.hEvent = CreateEvent(NULL,  // Default security
                                            TRUE,  // Manual reset
                                            FALSE, // non-signaled state
                                            NULL); // No name

                    // Dispatch the GET_STRING IOCTL to our NT or 95 driver.
                    // Which driver is loaded is irrelevant, since both
                    // support the same interface :-)
                    bReturnCode = DeviceIoControl(hDriver,
                                  IOCTL_MSJDRVR_READ_CMOS,
                                  0, 0,
                                  &Memory, sizeof(Memory),
                                  &dwBytesReturned,
                                  &ov);
        
                    // Wait here for the event handle to be set, indicating
                    // that the IOCTL processing is complete.
                    bReturnCode = GetOverlappedResult(hDriver, &ov,
                                                      &dwBytesReturned, TRUE);

                    CloseHandle(ov.hEvent);

                    wsprintf(szText,"Base Memory:\t%ldK\nExtended Memory:\t%ldK",Memory.ulBaseMem, Memory.ulExtMem);
                    MessageBox(hWnd,szText,"CMOS Memory Results",MB_OK);
                    break;
                }

                case IDM_HELP_ABOUT:
                    DialogBox(ghInst, MAKEINTRESOURCE(IDD_ABOUT), hWnd, DlgProc);
                    break;

                case IDM_FILE_EXIT:
                    PostMessage(hWnd, WM_CLOSE, 0, 0L);
                    break;
            }
            break;

        case WM_DESTROY:
            CloseHandle(hDriver);

            // If the NT driver was previously dynamically loaded, unload it here!
            if(fNTDynaLoaded)
                UnloadDynamicNTDriver();

            PostQuitMessage(0);
            break;
            
        default:
            return DefWindowProc(hWnd,uMessage,wParam,lParam);
            break;
          
    }
    return 0L;
}                                                            


int PASCAL WinMain(HINSTANCE hInstance, HANDLE hPrevInstance,
                                            LPSTR lpszCmdLine, int nCmdShow)
{
    static char szAppName[]="MSJ Device Driver Test Application - 1998 James M. Finnegan";
    HWND        hWnd;
    MSG         msg;
    WNDCLASS    wndclass;
    
    
    
    if(!hPrevInstance)
    {
        wndclass.style         = CS_HREDRAW | CS_VREDRAW;
        wndclass.lpfnWndProc   = WndProc;
        wndclass.cbClsExtra    = 0;
        wndclass.cbWndExtra    = 0;
        wndclass.hInstance     = hInstance;
        wndclass.hIcon         = LoadIcon(hInstance,szAppName);
        wndclass.hCursor       = LoadCursor(NULL, IDC_ARROW);
        wndclass.hbrBackground = GetStockObject(WHITE_BRUSH);
        wndclass.lpszMenuName  = MAKEINTRESOURCE(IDR_MENU);
        wndclass.lpszClassName = szAppName;

        if(!RegisterClass(&wndclass))
            return -1;
    }

    // Save away the hInstance ina global for later use...
    ghInst = hInstance;
    
    // Create the main window
    hWnd= CreateWindow(szAppName,szAppName,
                WS_OVERLAPPED | WS_THICKFRAME | WS_MINIMIZEBOX | 
                WS_MAXIMIZEBOX |WS_SYSMENU | WS_CLIPCHILDREN,
                CW_USEDEFAULT,CW_USEDEFAULT,
                CW_USEDEFAULT,CW_USEDEFAULT,
                0,0,hInstance,NULL);

    ShowWindow(hWnd,nCmdShow);
    UpdateWindow(hWnd);
    
    while(GetMessage(&msg,NULL,0,0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return msg.wParam;
}                 
