/*
    Query.c - 1998 James M. Finnegan - Microsoft Systems Journal

    This console app displays all of the device names present in an
    NT system, and tests each for accessibility.
*/
#include <windows.h>
#include <stdio.h>


void main()
{
    static char szDevices[65535];
    char *szCurrentDevice;
    char szName[80];

    int i=0;


    printf("Win32(R) Device Name Enumerator - James M. Finnegan, 1998\n");
    printf("Copyright (c)1998 Microsoft Systems Journal, All Rights Reserved\n\n");
    
    
    // Get all the current device names...
    if(QueryDosDevice(NULL, szDevices, 65535) != 0)
    {
        printf("%-20.20s  Accessible?\n", "Device Name");
        printf("--------------------  -----------\n");

        for(;;)
        {
            static HANDLE hDriver;


            // Try to open each device name...
            szCurrentDevice = &szDevices[i];

            sprintf(szName,"\\\\.\\%s", szCurrentDevice);

            hDriver = CreateFile(szName,
                             GENERIC_READ | GENERIC_WRITE, 
                             FILE_SHARE_READ | FILE_SHARE_WRITE,
                             0,                     // Default security
                             OPEN_EXISTING,
                             0,  
                             0);                    // No template
        
            // If the open failed, print out the error code
            if(hDriver == INVALID_HANDLE_VALUE)
                printf("%-20.20s  No: Error %ld\n", szCurrentDevice, GetLastError());
            // Otherwise, print success and close the driver
            else
            {
                printf("%-20.20s  Yes\n", szCurrentDevice);
                // Close the driver
                CloseHandle(hDriver);
            }

            // Go to next NULL character
            while(szDevices[i] != 0)
                i++;

            // Bump pointer to the next string
            i++;

            // The list is double-NULL terminated, so if the character is
            // now NULL, we're at the end
            if(szDevices[i] == 0)
                break;
        }

    }
    else
        printf("No Devices in list!\n");
}
