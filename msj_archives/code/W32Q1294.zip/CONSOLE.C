/*************************************************************
Module name: DbgApp.c
Notices: Written 1994 by Jeffrey Richter
*************************************************************/


#include <Windows.h>
#include <Stdio.h>

int WINAPI WinMain (HINSTANCE hinstExe, HINSTANCE hinstExePrev, 
	LPSTR lpszCmdLine, int nCmdShow) {

	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	BOOL fOk;

	printf("lpszCmdLine=%x, \"%s\"\n", lpszCmdLine, lpszCmdLine);

	ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);

	fOk = CreateProcess(NULL, "Nothing", NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);
	if (!fOk) {
		printf("CreateProcess failed, error = %d\n", GetLastError());
	}
	printf("Before msg box\n");
	MessageBox(NULL, "Hi", NULL, MB_OK);
	printf("After msg box\n");
	return(0);
}


/////////////////////// End Of File ////////////////////////
