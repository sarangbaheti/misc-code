////////////////////////////////////////////////////////////////
// 2000 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// This program compiles with Visual C++ 6.0 on Windows 98
//
#include "resource.h"       // main symbols

class CMyApp : public CWinApp {
public:
	CMyApp() { }
	virtual BOOL InitInstance();
	virtual int  ExitInstance();
protected:
	//{{AFX_MSG(CMyApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
