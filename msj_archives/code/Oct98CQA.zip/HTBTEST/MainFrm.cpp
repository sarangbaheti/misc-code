////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "StdAfx.h"
#include "HTBTest.h"
#include "MainFrm.h"
#include "hottb.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_GO_BACK, OnNotImplemented)
	ON_COMMAND(ID_GO_FORWARD, OnNotImplemented)
	ON_COMMAND(ID_VIEW_STOP, OnNotImplemented)
	ON_COMMAND(ID_VIEW_REFRESH, OnNotImplemented)
	ON_COMMAND(ID_GO_START_PAGE, OnNotImplemented)
	ON_COMMAND(ID_GO_SEARCH_THE_WEB, OnNotImplemented)
	ON_COMMAND(ID_FAVORITES_DROPDOWN, OnNotImplemented)
	ON_COMMAND(ID_FILE_PRINT, OnNotImplemented)
	ON_COMMAND(ID_FONT_DROPDOWN, OnNotImplemented)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT BASED_CODE indicators[] = {
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

#ifndef TB_SETEXTENDEDSTYLE
// from newer versions of commctrl.h
#define TB_SETEXTENDEDSTYLE     (WM_USER + 84)  // For TBSTYLE_EX_*
#define TBSTYLE_EX_DRAWDDARROWS 0x00000001
#endif

const NBUTTONS = 9;

// This table is used to load the buttons
// One table is worth a thousand lines of code (well, a lot, anyway)
// Use tables!!!
//
static struct {
	UINT id;										 // command ID
	UINT style;									 // button style
	UINT iImage;								 // index of image in normal/hot bitmaps

} Buttons[NBUTTONS] = {

	// command ID					button style								image index
	{ ID_GO_BACK,					TBSTYLE_BUTTON,							0 },
	{ ID_GO_FORWARD,				TBSTYLE_BUTTON,							1 },
	{ ID_VIEW_STOP,				TBSTYLE_BUTTON,							2 },
	{ ID_VIEW_REFRESH,			TBSTYLE_BUTTON,							3 },
	{ ID_GO_START_PAGE,			TBSTYLE_BUTTON,							4 },
	{ ID_GO_SEARCH_THE_WEB,		TBSTYLE_BUTTON,							5 },
	{ ID_FAVORITES_DROPDOWN,	TBSTYLE_BUTTON | TBSTYLE_DROPDOWN,	6 },
	{ ID_FILE_PRINT,				TBSTYLE_BUTTON,							7 },
	{ ID_FONT_DROPDOWN,			TBSTYLE_BUTTON | TBSTYLE_DROPDOWN,	8 }
};

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// Create toolbar--but don't load it
	if (!m_wndToolBar.Create(this)) {
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	// Use handy class to set up cold/hot toolar button bitmaps
	CHotToolBarSetup htb;
	htb.SetupHotToolBar(m_wndToolBar,
		IDB_COLDTOOLBAR,						 // ID of bitmap for "normal" buttons
		IDB_HOTTOOLBAR,						 // ID of bitmap for "hot" buttons
		0,											 // ID of bitmap for disabled buttons
		22,										 // width of one button in bitmap
		RGB(255, 0, 255));					 // background color

	// for dropdown arrows--note: they are not implemented
	m_wndToolBar.SendMessage(TB_SETEXTENDEDSTYLE, 0, TBSTYLE_EX_DRAWDDARROWS);

	// Add toolbar buttons since I'm not using LoadToolBar
	m_wndToolBar.SetButtons(NULL, NBUTTONS);
	for (int i=0; i<NBUTTONS; i++) {
		m_wndToolBar.SetButtonInfo(i,
			Buttons[i].id,						 // command id
			Buttons[i].style,					 // buttons style
			Buttons[i].iImage);				 // index of image in bitmap
	}
		
	// Rest is normal main frame stuff...
	// 
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT))) {
		TRACE("Failed to create status bar\n");
		return -1;      // fail to create
	}

	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	return 0;
}

void CMainFrame::OnNotImplemented()
{
	MessageBeep(0);
}
