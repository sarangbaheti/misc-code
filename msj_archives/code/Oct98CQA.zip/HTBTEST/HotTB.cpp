////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 5.0 on Windows 95
// 
#include "stdafx.h"
#include "hottb.h"

CHotToolBarSetup::CHotToolBarSetup()
{
	// MFC normally makes the button 7 pixels larger all around than the
	// actual button image. Change this if you like before calling Setup.
	//
	m_szButtonMargin = CSize(7,7);
}
		
// Set up toolbar with normal and "hot" button bitmaps
//
void CHotToolBarSetup::SetupHotToolBar(CToolBar& tb, // toolbar
	UINT nIdNormal,		// resource ID for normal buttons bitmap
	UINT nIdHot,			// resource ID for hot button bitmap
	UINT nIdDisab,			// resource ID for disabled button bitmap
	int cx,					// width of one button image
	COLORREF clrBkgnd)	// background (transparent) color
{
	// Size of one button image--will calculate cy below
	CSize szImage(cx,0);

	// A toolbar must be flat to use "hot" bitmap (image list)
	tb.ModifyStyle(0, TBSTYLE_FLAT);

	// Create image list from normal bitmap
	ASSERT(nIdNormal);
	CImageList il;
	VERIFY(il.Create(nIdNormal, cx, 0, clrBkgnd));

	// Get height of button image from image list itself.
	IMAGEINFO info;
	il.GetImageInfo(0, &info);
	szImage.cy = ((CRect&)info.rcImage).Height();

	// Set toolbar button sizes for MFC
	tb.SetSizes(szImage + m_szButtonMargin, szImage);

	// set normal button images.
	// It's important to detach the HIMAGELIST, else CImageList will destroy.
	tb.SendMessage(TB_SETIMAGELIST, 0, (LPARAM)il.Detach());

	// Load hot bitmap and set in toolbar
	if (nIdHot) {
		VERIFY(il.Create(nIdHot, cx, 0, clrBkgnd));
		tb.SendMessage(TB_SETHOTIMAGELIST, 0, (LPARAM)il.Detach());
	}

	// Load disabled bitmap and set in toolbar
	if (nIdDisab) {
		VERIFY(il.Create(nIdDisab, cx, 0, clrBkgnd));
		tb.SendMessage(TB_SETDISABLEDIMAGELIST, 0, (LPARAM)il.Detach());
	}
}
