//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by HTBTest.rc
//
#define IDR_MAINFRAME                   2
#define IDD_ABOUTBOX                    100
#define ID_GO_BACK                      1000
#define ID_GO_FORWARD                   1001
#define ID_VIEW_STOP                    1002
#define ID_VIEW_REFRESH                 1003
#define ID_GO_START_PAGE                1004
#define ID_GO_SEARCH_THE_WEB            1005
#define ID_FAVORITES_DROPDOWN           1006
#define ID_FONT_DROPDOWN                1007
#define IDB_COLDTOOLBAR                 101
#define IDB_HOTTOOLBAR                  102

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
