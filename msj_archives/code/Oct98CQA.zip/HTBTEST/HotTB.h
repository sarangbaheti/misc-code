////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 5.0 on Windows 95
// 

//////////////////
// This class sets up a toolbar with hot/cold button bitmaps.
// To use it instead of CToolBar::LoadToolBar, create an instance in
// you CMainFrame::OnCreate, then call SetupHotToolBar like so
//
// CHotToolBarSetup htbs;
// htbs.SetupHotToolBar(m_wndToolBar, ID_NORMAL, ID_HOT, ID_DISAB, cx, clrBk);
//
// m_wndToolBar		is your CToolBar
// ID_NORMAL			is the resource id of bitmap to use for normal buttons
// ID_HOT				is the resource id of bitmap to use for "hot" buttons
// ID_DISAB				is the resource id of bitmap to use for disabled buttons
// cx						is the width of one button
// clrBk  				is the background color of the bitmaps, which will be
//                   mapped to transparent
// 
class CHotToolBarSetup {

private:
	CSize m_szButtonMargin; // button size this much bigger than image size

public:
	CHotToolBarSetup();
	void SetupHotToolBar(CToolBar& tb, UINT nIdCold, UINT nidHot, UINT nIdDisab,
		int cx, COLORREF clrBkgnd);
};
