////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 5.0 on Windows 95
// 

//////////////////
// class to represent global mouse object.
//
class CMouse {
public:
	CWnd* Capture()			{ return CWnd::GetCapture(); }
	CWnd* Capture(CWnd *w)	{ return w->SetCapture(); }
	void Release()				{ ReleaseCapture(); }
	CPoint GetPos()			{ CPoint p; ::GetCursorPos(&p); return p; }
	operator CPoint()			{ return GetPos(); }
};
extern CMouse Mouse;
