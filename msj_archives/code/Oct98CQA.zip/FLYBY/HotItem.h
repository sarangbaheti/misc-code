class CHotItem {
	virtual BOOL HitTest(CPoint pt);
	virtual 

}