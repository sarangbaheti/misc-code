9-17-98

Dear readers,

Contrary to what is printed in the October 1998 column and the
Microsoft documentation, the SetCapture method of implementing
mousesover in FLYBY *WILL* work in Win95/98 and NT, and is better
than using a timer. This directory contains the newer, correct
version using SetCapture. Don't use a timer--it's gross!!

Thanks,

Paul DiLascia
askpd@pobox.com

