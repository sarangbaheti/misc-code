////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 5.0 on Windows 95
// 

#include <stdafx.h>
#include "mouse.h"

// Instantiate one-and-only mouse object
CMouse Mouse;


