////////////////////////////////////////////////////////////////
// FLYBY 1998 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "StdAfx.h"
#include "Flyby.h"
#include "Doc.h"
#include "View.h"
#include "Mouse.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CMyView, CView)

BEGIN_MESSAGE_MAP(CMyView, CView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_MOUSEMOVE()
	ON_WM_EXITMENULOOP()
	ON_MESSAGE(WM_MOUSELEAVE,   OnMouseLeave)
END_MESSAGE_MAP()

CMyView::CMyView()
{
	m_bHilite = -1;			// invalid state
	m_bTrackLeave = FALSE;	// not traking mouse
}

CMyView::~CMyView()
{
}

int CMyView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct)==-1)
		return -1;

	CWnd* pFrame = GetTopLevelParent();
	ASSERT_VALID(pFrame);
	m_frameHook.Install(this, *pFrame);
	return 0; // OK
}

//////////////////
// Draw ellipse within client area.
// If mouse is outside the ellipse, draw gray; else red
//
void CMyView::OnDraw(CDC* pDC)
{
	// create brush w/appropriate color: red/gray.
	if (m_bHilite==-1) {
		CPoint pt = Mouse;		// mouse pos in screen coords 
		ScreenToClient(&pt);		// convert to client
		m_bHilite = GetHighlight(pt);
	}
	CBrush brush(m_bHilite ? RGB(255,0,0) : RGB(192,192,192));

	// select brush and draw ellipse
	CGdiObject *pOldBrush = pDC->SelectObject(&brush);
	pDC->Ellipse(&m_rcClient);
	pDC->SelectObject(pOldBrush);
}

//////////////////
// Window size changed: update client rectangle and elliptic region.
//
void CMyView::OnSize(UINT nType, int cx, int cy)
{
	m_rcClient.SetRect(0,0,cx,cy);
	m_hotRegion.DeleteObject();
	m_hotRegion.CreateEllipticRgnIndirect(&m_rcClient);
}

//////////////////
// Determine if I should highlight the ellipse based on mouse coords.
// That is, if point is inside ellipse and I have the focus.
//
BOOL CMyView::GetHighlight(CPoint pt)
{
	return m_hotRegion.PtInRegion(pt) &&
		CWnd::GetFocus()==this;
}

//////////////////
// Handle mouse move message: highlight or unhighlight ellipse.
//
void CMyView::OnMouseMove(UINT nFlags, CPoint pt)
{
	if (!m_bTrackLeave) {
		// First time since mouse entered my window: request leave notification
		TRACKMOUSEEVENT tme;
		tme.cbSize = sizeof(tme);
		tme.hwndTrack = m_hWnd;
		tme.dwFlags = TME_LEAVE;
		_TrackMouseEvent(&tme);
		m_bTrackLeave = TRUE;
	}
	DoHighlight(pt);
}

//////////////////
// Mouse left the window.
//
LPARAM CMyView::OnMouseLeave(WPARAM wp, LPARAM lp)
{
	m_bTrackLeave = FALSE;			 // no longer tracking
	DoHighlight();						 // dehighlight mouse
	return 0;
}

//////////////////
// User quit menu
//
void CMyView::OnExitMenuLoop(BOOL bIsTrackPopupMenu)
{
	DoHighlight();
}

//////////////////
// Highlight or unhighlight ellipse based on mouse pt
//
void CMyView::DoHighlight(CPoint pt)
{
	BOOL bHilite = GetHighlight(pt);
	if (bHilite != m_bHilite) {
		// mouse has either left or entered the ellipse: repaint
		m_bHilite = bHilite;
		Invalidate(FALSE);
		UpdateWindow();
	}
}

void CMyView::DoHighlight()
{
	CPoint pt = Mouse;				 // mouse pos in screen coords 
	ScreenToClient(&pt);				 // convert to client
	DoHighlight(pt);					 // call overloaded version
}

////////////////////////////////////////////////////////////////
// CFrameHook. This class hooks the parent frame so the view
// can see its WM_EXITMENULOOP message
//
CFrameHook::CFrameHook()
{
}

CFrameHook::~CFrameHook()
{
	HookWindow((HWND)NULL); // (unhook)
}

BOOL CFrameHook::Install(CMyView* pView, HWND hWndToHook)
{
	ASSERT_VALID(pView);
	m_pView = pView;
	return HookWindow(hWndToHook);
}

LRESULT CFrameHook::WindowProc(UINT msg, WPARAM wp, LPARAM lp)
{
	if (msg==WM_EXITMENULOOP)
		// got WM_EXITMENULOOP: let view see it
		m_pView->SendMessage(WM_EXITMENULOOP, wp, lp);
	return CSubclassWnd::WindowProc(msg, wp, lp);
}
