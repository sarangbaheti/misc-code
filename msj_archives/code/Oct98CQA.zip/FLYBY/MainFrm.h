////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 5.0 on Windows 95
// 

////////////////
// Standard MFC main frame window
//
class CMainFrame : public CFrameWnd {
public:
	virtual ~CMainFrame();

protected:
	CMainFrame();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	DECLARE_DYNCREATE(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	DECLARE_MESSAGE_MAP()
};
