////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 5.0 on Windows 95
//
// FLYBY shows how to implement the mouseover feature
// Compiles with VC++ 5.0 or later, under Windows 98.
//
#include "Subclass.h"

//////////////////
// This clas hooks the frame window so the view can see WM_EXITMENULOOP.
//
class CFrameHook : public CSubclassWnd {
	friend class CMyView;
protected:
	CFrameHook();
	~CFrameHook();
	BOOL Install(CMyView* pView, HWND hWndToHook);
	CMyView* m_pView;
	virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp);
};

//////////////////
// View class handles mouseover
//
class CMyView : public CView {
private:
	CFrameHook m_frameHook;

	CRect m_rcClient;			// client area rectangle
	CRgn	m_hotRegion;		// elliptic region
	BOOL  m_bHilite;			// highlight the ellipse?
	BOOL  m_bTrackLeave;		// I am tracking mouse leave

public:
	virtual ~CMyView();
	CMyDoc* GetDocument() { return (CMyDoc*)m_pDocument; }

	virtual void OnDraw(CDC* pDC);
	BOOL GetHighlight(CPoint pt);
	void DoHighlight(CPoint pt);
	void DoHighlight();

protected:
	DECLARE_DYNCREATE(CMyView)
	CMyView();
	afx_msg int    OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void   OnMouseMove(UINT nFlags, CPoint pt);
	afx_msg LPARAM OnMouseLeave(WPARAM wp, LPARAM lp);
	afx_msg void   OnSize(UINT nType, int cx, int cy);
	afx_msg void	OnExitMenuLoop(BOOL bIsTrackPopupMenu);
	DECLARE_MESSAGE_MAP()
};
