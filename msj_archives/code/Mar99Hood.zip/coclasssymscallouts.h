#ifdef __cplusplus
extern "C" {
#endif

BOOL __stdcall CoClassSymsBeginSymbolCallouts( PSTR pszExecutable );

BOOL __stdcall  CoClassSymsAddSymbol(
		unsigned short section,
		unsigned long offset,
		PSTR pszSymbolName );
		
BOOL __stdcall CoClassSymsSymbolsFinished( void );

#ifdef __cplusplus
}
#endif
