//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Controls.rc
//
#define IDS_PROJNAME                    100
#define IDB_DARTBOARD                   101
#define IDR_DARTBOARD                   102
#define IDD_DARTBOARD                   103
#define IDB_SMARTDARTBOARD              104
#define IDH_SMARTDARTBOARD              105
#define IDR_SMARTDARTBOARD              106
#define IDC_BULLSEYE                    201
#define IDC_SCORE                       203
#define IDC_RESET                       204

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         205
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
