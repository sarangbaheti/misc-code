//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Container.rc
//
#define ID_MORE_RINGS                   3
#define ID_FEWER_RINGS                  4
#define ID_HELP_ABOUT                   101
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define ID_FILE_EXIT                    105
#define IDD_BULLSEYE                    105
#define IDI_CONTAINER                   107
#define IDD_DARTBOARD                   107
#define IDI_SMALL                       108
#define IDC_CONTAINER                   109
#define IDR_CONTAINER                   109
#define IDC_BULLSEYE                    1000
#define IDC_SCORE                       1001
#define IDC_DARTBOARD1                  1004
#define ID_EDIT_PROPERTIES              40002
#define ID_FILE_SAVEAS                  40006
#define ID_EDIT_INSERTCONTROL           40007
#define ID_EDIT_SHOWBULLSEYE            40008
#define ID_EDIT_SHOW_DARTBOARD          40009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40010
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
