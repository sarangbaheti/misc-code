/*----------------------------------------------------------------------
   John Robbins - Jan '99 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
FILE        :   TTest.cpp
DISCUSSION  :
    A very simple device driver driver ;^) to make a few calls into the
    TrackTest.sys device driver.
----------------------------------------------------------------------*/

#include <windows.h>
#include <WINIOCTL.H>
#include <stdio.h>
#include <stdlib.h>
#include "TrackTestIOCTL.h"

void Usage ( void )
{
    printf ( "The simple device driver driver for TrackTest.sys\n" ) ;
    printf ( "**Please note that TrackTest.sys MUST be loaded before "
             "running TTest.exe\n\n" ) ;

    printf ( "TrackTest.sys WILL PROBABLY CRASH YOUR SYSTEM WITH A "
             "FATAL ERROR.  IT SHOULD\n"
             "ONLY BE RUN ON A CHECKED MACHINE!  YOU HAVE BEEN "
             "WARNED!\n\n" ) ;

    printf ( "Command line options:\n" ) ;
    printf ( "  stats   - Dumps the stats at the current point\n" ) ;
    printf ( "  dump    - Dumps all outstanding allocations\n" ) ;
    printf ( "  valid   - Validates all outstanding memory allocs\n" ) ;
    printf ( "  corrupt - Allocate and corrupt some memory\n" ) ;
    printf ( "  ntalloc - Allocate some non-tracked things\n" ) ;
    printf ( "  alloc   - Allocate some tracked things\n" ) ;
    printf ( "  free    - Free all allocated things\n" ) ;
}

void __cdecl main ( int argc , char ** argv )
{
    if ( 1 == argc )
    {
        Usage ( ) ;
        return ;
    }

    // Try and get the handle to the loaded driver.
    HANDLE hDevice = CreateFile ( "\\\\.\\TrackTest"             ,
                                  GENERIC_READ | GENERIC_WRITE   ,
                                  0                              ,
                                  NULL                           ,
                                  OPEN_EXISTING                  ,
                                  FILE_ATTRIBUTE_NORMAL          ,
                                  NULL                            ) ;

     if ( INVALID_HANDLE_VALUE == hDevice )
     {
        printf ( "Unable to get a handle to TrackTest.sys\n\n" ) ;
        printf ( "Use the INSTDRV.EXE loader program to load "
                 "TrackTest.sys!!\n" ) ;
        return ;
    }

    LONG lIOCTL = 0 ;

    if ( 0 == strcmp ( argv[ 1 ] , "stats" ) )
    {
        lIOCTL = IOCTL_TRACKTEST_MEMSTATS ;
    }
    else if ( 0 == strcmp ( argv[ 1 ] , "dump" ) )
    {
        lIOCTL = IOCTL_TRACKTEST_DUMPMEM ;
    }
    else if ( 0 == strcmp ( argv[ 1 ] , "valid" ) )
    {
        lIOCTL = IOCTL_TRACKTEST_CHECKMEM ;
    }
    else if ( 0 == strcmp ( argv[ 1 ] , "corrupt" ) )
    {
        lIOCTL = IOCTL_TRACKTEST_DOCORRUPT ;
    }
    else if ( 0 == strcmp ( argv[ 1 ] , "ntalloc" ) )
    {
        lIOCTL = IOCTL_NOTTRACKTEST_DOTRACKALLOCS ;
    }
    else if ( 0 == strcmp ( argv[ 1 ] , "alloc" ) )
    {
        lIOCTL = IOCTL_TRACKTEST_DOTRACKALLOCS ;
    }
    else if ( 0 == strcmp ( argv[ 1 ] , "free" ) )
    {
        lIOCTL = IOCTL_TRACKTEST_DOFREES ;
    }
    else
    {
        printf ( "Invalid command line option\n\n" ) ;
        Usage ( ) ;
        CloseHandle ( hDevice ) ;
        return ;
    }

    // Try it.  This might be the last we see this login!!!
    DWORD dwRet ;
    BOOL bRet = DeviceIoControl ( hDevice               ,
                                  lIOCTL                ,
                                  NULL                  ,
                                  0                     ,
                                  NULL                  ,
                                  0                     ,
                                  &dwRet                ,
                                  NULL                   ) ;
    CloseHandle ( hDevice ) ;
}
