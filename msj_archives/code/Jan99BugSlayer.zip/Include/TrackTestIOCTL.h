/*----------------------------------------------------------------------
   John Robbins - Jan '99 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
FILE        :   TrackTestIOCTL.h
DISCUSSION  :
    The public TrackTest IOCTL values.
----------------------------------------------------------------------*/

#ifndef _TRACKTESTIOCTL_H
#define _TRACKTESTIOCTL_H

////////////////////////////////////////////////////////////////////////
// The device type value.  0xAFC8 == 45,002.
#define FILE_DEVICE_TRACKTEST   0x0000AFCA

////////////////////////////////////////////////////////////////////////
// The IOCTL index values.  0xBB8 == 3,002
#define TRACKTEST_BASEINDEX     0xBBA

#define DOTRACKALLOCS_INDEX     TRACKTEST_BASEINDEX + 0
#define DONOTTRACKALLOCS_INDEX  TRACKTEST_BASEINDEX + 1
#define DOFREES_INDEX           TRACKTEST_BASEINDEX + 2
#define DOCORRUPT_INDEX         TRACKTEST_BASEINDEX + 3
#define CHECKMEM_INDEX          TRACKTEST_BASEINDEX + 4
#define DUMPMEM_INDEX           TRACKTEST_BASEINDEX + 5
#define MEMSTATS_INDEX          TRACKTEST_BASEINDEX + 6

////////////////////////////////////////////////////////////////////////
// The IOCTL values and coreesponding structures for TrackTest.

#define IOCTL_TRACKTEST_DOTRACKALLOCS CTL_CODE ( FILE_DEVICE_TRACKTEST,\
                                               DOTRACKALLOCS_INDEX   , \
                                               METHOD_NEITHER        , \
                                               FILE_ANY_ACCESS       )


#define IOCTL_NOTTRACKTEST_DOTRACKALLOCS                               \
                                   CTL_CODE ( FILE_DEVICE_TRACKTEST   ,\
                                              DONOTTRACKALLOCS_INDEX  ,\
                                              METHOD_NEITHER          ,\
                                              FILE_ANY_ACCESS         )

#define IOCTL_TRACKTEST_DOFREES     CTL_CODE ( FILE_DEVICE_TRACKTEST , \
                                               DOFREES_INDEX         , \
                                               METHOD_NEITHER        , \
                                               FILE_ANY_ACCESS       )

#define IOCTL_TRACKTEST_DOCORRUPT   CTL_CODE ( FILE_DEVICE_TRACKTEST , \
                                               DOCORRUPT_INDEX       , \
                                               METHOD_NEITHER        , \
                                               FILE_ANY_ACCESS       )

#define IOCTL_TRACKTEST_CHECKMEM    CTL_CODE ( FILE_DEVICE_TRACKTEST , \
                                               CHECKMEM_INDEX        , \
                                               METHOD_NEITHER        , \
                                               FILE_ANY_ACCESS       )

#define IOCTL_TRACKTEST_DUMPMEM     CTL_CODE ( FILE_DEVICE_TRACKTEST , \
                                               DUMPMEM_INDEX         , \
                                               METHOD_NEITHER        , \
                                               FILE_ANY_ACCESS       )

#define IOCTL_TRACKTEST_MEMSTATS    CTL_CODE ( FILE_DEVICE_TRACKTEST , \
                                               MEMSTATS_INDEX        , \
                                               METHOD_NEITHER        , \
                                               FILE_ANY_ACCESS       )




#endif      // _TRACKTESTIOCTL_H


