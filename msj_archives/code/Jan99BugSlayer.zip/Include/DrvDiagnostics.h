/*----------------------------------------------------------------------
   John Robbins - Jan '99 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
VERY useful driver diagnostic routines.
----------------------------------------------------------------------*/

#ifndef _DRVDIAGNOSTICS_H
#define _DRVDIAGNOSTICS_H

#if DBG !=0
#ifndef _DEBUG
#define _DEBUG
#endif
#endif

////////////////////////////////////////////////////////////////////////
// The usual trace macros.
#ifdef _DEBUG

// The trace macros that work in C and C++.
#define TRACE0(x)       DbgPrint ( x )
#define TRACE1(x,y)     DbgPrint ( x , y )
#define TRACE2(x,y,z)   DbgPrint ( x , y , z )
#define TRACE3(x,y,z,a) DbgPrint ( x , y , z , a )

// A VERIFY macro.
#define VERIFY(x) ASSERT(x)

// The C++ specific trace statements.
#ifdef __cplusplus
#define TRACE           DbgPrint
#endif   // __cplusplus

#ifdef __cplusplus
// The C++ BreakIfKdPresent function.
inline void BreakIfKdPresent ( void )
{
    // Wind through the IAT and grab the real value.
    PULONG * pData = (PULONG*)(&KdDebuggerEnabled) ;
    if ( 1 == **pData )
    {
        DbgBreakPoint ( ) ;
    }
} ;

#else
// The C BreakIfKdPresent macro.
#define BreakIfKdPresent()                                  \
    {                                                       \
        PULONG * pData = (PULONG*)(&KdDebuggerEnabled) ;    \
        if ( 1 == **pData )                                 \
        {                                                   \
            DbgBreakPoint ( ) ;                             \
        }                                                   \
    }
#endif

// The C/C++ ASSERTIRQL define.  This checks that the IRQL is equal to
//  that specified.  If it is not, then the assert fires.
#define ASSERTIRQL(x)                                       \
            ASSERTMSG ( "KeGetCurrentIrql ( ) == "#x ,      \
                         KeGetCurrentIrql ( ) == x    ) ;

// For consistency....
#define ASSERTIRQL_EQ(x)    ASSERTIRQL ( x )

// Is the IRQL less than x?
#define ASSERTIRQL_LT(x)                                    \
            ASSERTMSG ( "KeGetCurrentIrql ( ) < "#x ,       \
                         KeGetCurrentIrql ( )< x     ) ;

// Is the IRQL less than or equal to x?
#define ASSERTIRQL_LE(x)                                    \
            ASSERTMSG ( "KeGetCurrentIrql ( ) <= "#x ,      \
                         KeGetCurrentIrql ( ) <= x    ) ;

// Is the IRQL greater than or equal to x?
#define ASSERTIRQL_GE(x)                                    \
            ASSERTMSG ( "KeGetCurrentIrql ( ) >= "#x ,      \
                         KeGetCurrentIrql ( ) >= x    ) ;

// Is the IRQL greater than x?
#define ASSERTIRQL_GT(x)                                    \
            ASSERTMSG ( "KeGetCurrentIrql ( ) > "#x ,       \
                         KeGetCurrentIrql ( ) > x    ) ;

// Is the IRQL not equal to x?
#define ASSERTIRQL_NE(x)                                    \
            ASSERTMSG ( "KeGetCurrentIrql ( ) != "#x ,      \
                         KeGetCurrentIrql ( ) != x    ) ;

#else   // _DEBUG is not defined.

#define TRACE0(x)
#define TRACE1(x,y)
#define TRACE2(x,y,z)
#define TRACE3(x,y,z,a)

#define BreakIfKdPresent()

#define ASSERTIRQL(x)
#define ASSERTIRQL_EQ(x)
#define ASSERTIRQL_LE(x)
#define ASSERTIRQL_GE(x)
#define ASSERTIRQL_GT(x)
#define ASSERTIRQL_NE(x)

#define VERIFY(x) x

#ifdef __cplusplus
inline void _cdecl FakeDbgPrint ( PCH , ... ) { }
#define TRACE        1 ? (void)0 : ::FakeDbgPrint
#endif   // __cplusplus

#endif      // _DEBUG


#endif      // _DRVDIAGNOSTICS_H


