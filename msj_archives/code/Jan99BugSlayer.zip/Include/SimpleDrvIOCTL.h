/*----------------------------------------------------------------------
FILE        :   SimpleDrvIOCTL.h
DISCUSSION  :
    The public SimpleDrv IOCTL values.
----------------------------------------------------------------------*/

#ifndef _SIMPLEDRVIOCTL_H
#define _SIMPLEDRVIOCTL_H

////////////////////////////////////////////////////////////////////////
// The device type value.  0xAFC8 == 45,002.
#define FILE_DEVICE_SIMPLEDRV    0x0000AFCA

////////////////////////////////////////////////////////////////////////
// The IOCTL index values.  0xBB8 == 3,002
#define SIMPLEDRV_BASEINDEX      0xBBA


////////////////////////////////////////////////////////////////////////
// The IOCTL values and coresponding structures for SimpleDrv.


#endif      // _SIMPLEDRVIOCTL_H


