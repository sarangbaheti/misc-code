Readme for January 1999 Bugslayer Code:

If you have any questions (or debugging tips -- keep'em rollin' in!)
send me a note through www.jprobbins.com.

Please make sure you read the *complete* January 1999 Bugslayer column
before looking at this code!

Directories:

.\Build     - The example SOURCES file and DDKCOMMON.MAK that that
              make BUILD.EXE a little more palatable.  Read the
              NewProj.bat file to see how to get the appropriate file
              copied over each time you start a new project.
.\Include   - The general include directory.  This is where
              DrvDiagnostics.h lives.
.\Track     - The source code for the Track Library.  The header file
              Track.h resides in this directory.
.\TrackTest - The sample driver.  Please be very careful when running
              this driver.  It is supposed to leak and corrupt memory
              so do not be surprised if it crashes your machine.
.\TTest     - A user mode driver to control TrackTest.sys.  Use the
              INSTDRV.EXE DDK sample program to load TrackTest.sys
              before running this program.  Once TrackTest.sys is loaded
              you can use TTest.exe to cause allocations and problems
              in the driver.  Run TTest.exe with no command line
              parameters to see the options.

Building:

0.  Read the January 1999 Bugslayer Column.
1.  Open a DOS Box that has either the DDK free or checked build
environment variables set.
1.  Set your INCLUDE environment variable to directory where you
unzipped the .\BUILD\DDKCOMMON.MAK file.  If you unzipped it to
"c:\junk\Bugslayer\Build", that's the directory you want to add.
2.  Type "BUILD" to create it all.
3.  Built binaries go to the .\Obj\i386\(free|checked) directory(s).

Happy Device Driver Tracking!

John Robbins.
