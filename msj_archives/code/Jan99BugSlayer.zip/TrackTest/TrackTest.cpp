/*----------------------------------------------------------------------
FILE        :   TrackTest.cpp
DISCUSSION  :
    A very dangerous driver to run!
----------------------------------------------------------------------*/

////////////////////////////////////////////////////////////////////////
// The usual headers.
#include "PCH.h"
#include "DrvDiagnostics.h"
#include "TrackTest.h"
#include "TrackTestIOCTL.h"
#include "Track.h"

////////////////////////////////////////////////////////////////////////
// File specific defines.

////////////////////////////////////////////////////////////////////////
// File specific typedefs.

////////////////////////////////////////////////////////////////////////
// File specific prototypes.
// Doin' the nasty...
void DoTrackedAllocs ( void ) ;
void DoNotTrackedAllocs ( void ) ;
void DoFrees ( void ) ;
void DoCorrupt ( void ) ;
void DoCheckMem ( void ) ;
void DoDumpMem ( void ) ;
void DoStats ( void ) ;

// The main entry point.
extern "C" NTSTATUS DriverEntry (  IN PDRIVER_OBJECT  pDriverObject   ,
                                   IN PUNICODE_STRING pusRegistryPath );

// The driver create routine for processing IRP_MJ_CREATE.
extern "C" NTSTATUS TrackTestCreate ( IN PDEVICE_OBJECT pDevObject ,
                                      IN PIRP           pIrp        ) ;

// The driver close routine for processing IRP_MJ_CLOSE.
extern "C" NTSTATUS TrackTestClose ( IN PDEVICE_OBJECT pDevObject ,
                                     IN PIRP           pIrp        ) ;

// The driver unload routine.
extern "C" VOID TrackTestUnload ( IN PDRIVER_OBJECT pDrvObject ) ;

// The driver dispatch routine.
extern "C" NTSTATUS TrackTestDispatch ( IN PDEVICE_OBJECT pDevObject ,
                                        IN PIRP           pIrp        ) ;

////////////////////////////////////////////////////////////////////////
// Driver section specifications.
// Indicate the INIT routines.
#pragma alloc_text ( INIT , DriverEntry )
// Indicate the pageable routines.
#pragma alloc_text ( PAGE , TrackTestCreate )
#pragma alloc_text ( PAGE , TrackTestClose )
#pragma alloc_text ( PAGE , TrackTestUnload )


////////////////////////////////////////////////////////////////////////
// File specific globals.

/*//////////////////////////////////////////////////////////////////////
                            CODE STARTS HERE
//////////////////////////////////////////////////////////////////////*/


/*----------------------------------------------------------------------
FUNCTION    :   DriverEntry
DISCUSSION  :
    The driver entry point that all drivers must have.
PARAMETERS  :
    pDriverObject   - The pointer to the driver object that DriverEntry
                      can use.
    pusRegistryPath - The driver registry path.
IRQL        :   PASSIVE_LEVEL_IRQL
----------------------------------------------------------------------*/
extern "C" NTSTATUS DriverEntry (  IN PDRIVER_OBJECT  pDriverObject   ,
                                   IN PUNICODE_STRING /*pusRegistryPath*/ )
{
    TRACE ( "TrackTest DriverEntry called\n" ) ;

    BreakIfKdPresent ( ) ;

    TRACKINITIALIZE ( ) ;

    // Since there is no hardware or other resources that are needed
    //  for TrackTest, no resource allocation needs to take place.

    // The device name and link buffers.
    WCHAR           wcDevNameBuffer [ ] = TRACKTEST_NAME_STRING ;
    UNICODE_STRING  usDevName                                   ;
    WCHAR           wcDevLinkBuffer [ ] = TRACKTEST_LINK_STRING ;
    UNICODE_STRING  usDevLink                                   ;

    // The device object pointer.
    PDEVICE_OBJECT  pDeviceObject       = NULL                  ;

    // The device extension for this driver.
    PDEVICE_EXTENSION pDeviceExtension  = NULL                  ;


    // Indicates if the IoCreateSymbolicLink succeeded.  If it did and,
    //  initialization failed later, then I use it to make sure to call
    //  IoDeleteSymbolicLink.
    int             bSymLinkCreated     = TRUE                  ;

    // The holder of the status return code from DDK APIs.
    NTSTATUS        ntStatus                                    ;

    // Initialize the unicode string that holds the driver name.
    RtlInitUnicodeString ( &usDevName , wcDevNameBuffer ) ;

    // Create the device.  This device has no characteristics and is
    //  an exclusive device.
    ntStatus = TrackIoCreateDevice ( pDriverObject               ,
                                     sizeof ( DEVICE_EXTENSION ) ,
                                     &usDevName                  ,
                                     FILE_DEVICE_TRACKTEST       ,
                                     0                           ,
                                     FALSE                       ,
                                     &pDeviceObject               ) ;

    if ( NT_SUCCESS ( ntStatus ) )
    {

        // Set up the symbolic link for ring 3 applications.
        RtlInitUnicodeString ( &usDevLink , wcDevLinkBuffer ) ;
        ntStatus = IoCreateSymbolicLink ( &usDevLink , &usDevName ) ;

        // What should really happen if the symbolic link fails?
        if ( NT_SUCCESS ( ntStatus ) )
        {

            // Set the flag that means IoCreateSymbolicLink succeeded.
            bSymLinkCreated = TRUE ;

            // Set up all the dispatch functions for device control,
            //  unloading, etc.
            pDriverObject->MajorFunction[IRP_MJ_CREATE] =
                                                       TrackTestCreate ;
            pDriverObject->MajorFunction[IRP_MJ_CLOSE] = TrackTestClose;
            pDriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] =
                                                      TrackTestDispatch;
            pDriverObject->DriverUnload = TrackTestUnload ;

            // Initialize the device extension values so they can be
            //  used later.
            // Get a pointer to the device extension.
            pDeviceExtension =
                     (PDEVICE_EXTENSION)pDeviceObject->DeviceExtension ;

        }
        else
        {
            bSymLinkCreated = FALSE ;
            TRACE ( "IoCreateSymbolicLink returned : 0x%08X\n" ,
                    ntStatus                                    ) ;
        }
    }
    else
    {
        TRACE ( "IoCreateDevice returned : 0x%08X\n" , ntStatus ) ;
    }

    // Did everything execute?
    if ( !NT_SUCCESS ( ntStatus ) )
    {
        // There was a problem so free resources.
        if ( TRUE == bSymLinkCreated )
        {
            IoDeleteSymbolicLink ( &usDevLink ) ;
        }

        if ( NULL != pDeviceObject )
        {
            IoDeleteDevice ( pDeviceObject ) ;
        }
    }

    return ( ntStatus ) ;
}

/*----------------------------------------------------------------------
FUNCTION    :   TrackTestCreate
DISCUSSION  :
    The IRP_MJ_CREATE function handler.  At this point, this does
nothing more than just return STATUS_SUCCESS.
PARAMETERS  :
    pDeviceObject   - The pointer to the device object.
    pIrp            - The I/O request packet.
IRQL        :   PASSIVE_LEVEL_IRQL
----------------------------------------------------------------------*/
NTSTATUS TrackTestCreate ( IN PDEVICE_OBJECT /*pDevObject*/ ,
                           IN PIRP           pIrp            )
{
     TRACE ( "TrackTestCreate processing IRP_MJ_CREATE\n" ) ;

    // Initialize the return status to a known value.
    pIrp->IoStatus.Status = STATUS_SUCCESS ;
    pIrp->IoStatus.Information = 0 ;

    // Indicate that the processing is done.
    IoCompleteRequest ( pIrp , IO_NO_INCREMENT ) ;

    // All OK, Jumpmaster!
    return ( STATUS_SUCCESS ) ;
}

/*----------------------------------------------------------------------
FUNCTION    :   TrackTestClose
DISCUSSION  :
    The IRP_MJ_CLOSE function handler.  At this point, this does nothing
more than just return STATUS_SUCCESS.
PARAMETERS  :
    pDeviceObject   - The pointer to the device object.
    pIrp            - The I/O request packet.
IRQL        :   PASSIVE_LEVEL_IRQL
----------------------------------------------------------------------*/
NTSTATUS TrackTestClose ( IN PDEVICE_OBJECT /*pDevObject*/ ,
                          IN PIRP           pIrp            )
{
     TRACE ( "TrackTestClose processing IRP_MJ_CLOSE\n" ) ;

    // Initialize the return status to a known value.
    pIrp->IoStatus.Status = STATUS_SUCCESS ;
    pIrp->IoStatus.Information = 0 ;

    // Indicate that the processing is done.
    IoCompleteRequest ( pIrp , IO_NO_INCREMENT ) ;

    // All OK, Jumpmaster!
    return ( STATUS_SUCCESS ) ;
}

/*----------------------------------------------------------------------
FUNCTION    :   TrackTestDispatch
DISCUSSION  :
    The dispatch routine that handles the major function code
processing.  No real processing for the device driver functionality is
done here.  It simply does the work of figuring out who to call.
PARAMETERS  :
    pDeviceObject   - The pointer to the device object.
    pIrp            - The I/O request packet.
IRQL        :   PASSIVE_LEVEL_IRQL
----------------------------------------------------------------------*/
NTSTATUS TrackTestDispatch ( IN PDEVICE_OBJECT pDeviceObject ,
                             IN PIRP           pIrp           )
{

    // The pointer to the caller's stack for pIrp.
    PIO_STACK_LOCATION  pIrpStack               ;
    // The device extension for this driver.
    PDEVICE_EXTENSION   pDeviceExtension        ;
    // The pointer to the system space buffer for buffered I/O.
    PVOID               pioBuffer               ;
    // The input buffer length.
    ULONG               ulInputBufferLength     ;
    // The output buffer length.
    ULONG               ulOutputBufferLength    ;
    // The control code for IRP_MJ_DEVICE_CONTROL dispatching.
    ULONG               ulIoControlCode         ;
    // Various item's return status.
    NTSTATUS            ntStatus                ;

    // Initialize the return status to a known value.
    pIrp->IoStatus.Status = STATUS_SUCCESS ;
    pIrp->IoStatus.Information = 0 ;

    // Get the caller's stack location in the Irp.  All the function
    //  codes and parameters are here.
    pIrpStack = IoGetCurrentIrpStackLocation ( pIrp ) ;

    // Get a pointer to the device extension.
    pDeviceExtension =
                     (PDEVICE_EXTENSION)pDeviceObject->DeviceExtension ;

    // Get a pointer to the input/output buffer.
    pioBuffer = pIrp->AssociatedIrp.SystemBuffer ;
    // Get the input and output buffer lengths.
    ulInputBufferLength =
                pIrpStack->Parameters.DeviceIoControl.InputBufferLength;
    ulOutputBufferLength =
               pIrpStack->Parameters.DeviceIoControl.OutputBufferLength;

    // Now figure out which major function to deal with.
    switch ( pIrpStack->MajorFunction )
    {
        case IRP_MJ_DEVICE_CONTROL :

            // A control code.  Figure out which it is and act
            //  appropriately.

            TRACE ( "TrackTest.SYS: IRP_MJ_DEVICE_CONTROL\n" ) ;

            ulIoControlCode =
                    pIrpStack->Parameters.DeviceIoControl.IoControlCode ;

            switch ( ulIoControlCode )
            {
                case IOCTL_TRACKTEST_DOTRACKALLOCS   :
                    DoTrackedAllocs ( ) ;
                    break ;
                case IOCTL_NOTTRACKTEST_DOTRACKALLOCS :
                    DoNotTrackedAllocs ( ) ;
                    break ;
                case IOCTL_TRACKTEST_DOFREES    :
                    DoFrees (  ) ;
                    break ;
                case IOCTL_TRACKTEST_DOCORRUPT  :
                    DoCorrupt (  ) ;
                    break ;
                case IOCTL_TRACKTEST_CHECKMEM   :
                    DoCheckMem (  ) ;
                    break ;
                case IOCTL_TRACKTEST_DUMPMEM    :
                    DoDumpMem (  ) ;
                    break ;
                case IOCTL_TRACKTEST_MEMSTATS   :
                    DoStats (  ) ;
                    break ;

                default                         :

                    pIrp->IoStatus.Status = STATUS_INVALID_PARAMETER ;

                    TRACE ( "TrackTest.SYS: unknown "\
                             "IRP_MJ_DEVICE_CONTROL\n" ) ;

                    break ;

            }
            break ;
        default :
            break ;
    }

    // Save the status because after calling IoCompleteRequest, the Irp
    //  is gone.
    ntStatus = pIrp->IoStatus.Status ;

    // Indicate that the processing is done.  Since there is not much
    //  that happens in this dispatch routine, the priority does not
    //  need a boost.
    IoCompleteRequest ( pIrp , IO_NO_INCREMENT ) ;

    // All OK, Jumpmaster!
    return ( ntStatus ) ;
}

/*----------------------------------------------------------------------
FUNCTION    :   TrackTestUnload
DISCUSSION  :
    The unload routine for the whole driver.  This is only called when
the driver is about to leave memory.
PARAMETERS  :
    pDriverObject   - The pointer to the driver object.
IRQL        :   PASSIVE_LEVEL_IRQL
----------------------------------------------------------------------*/
VOID TrackTestUnload ( IN PDRIVER_OBJECT pDriverObject )
{
    // The Ring 3 application symbolic name.
    WCHAR           wcDevLinkBuffer [ ] = TRACKTEST_LINK_STRING  ;
    UNICODE_STRING  usDevLink                                   ;

    // Free the things that have been allocated.
    PDEVICE_OBJECT pDeviceObject = pDriverObject->DeviceObject ;

    // The device extension for this driver.
    PDEVICE_EXTENSION   pDeviceExtension ;
    // Get a pointer to the device extension.
    pDeviceExtension =
             (PDEVICE_EXTENSION)pDeviceObject->DeviceExtension ;

    // Delete the symbolic link.
    RtlInitUnicodeString ( &usDevLink , wcDevLinkBuffer ) ;

    IoDeleteSymbolicLink ( &usDevLink ) ;

    // Delete the device object
    TrackIoDeleteDevice ( pDeviceObject ) ;

    TRACKCLOSE ( ) ;

    TRACE ( "TrackTestUnload processing driver unload\n" ) ;
}

// Globals used by the helper functions below.
typedef struct tag_HAPPYALLOCS
{
    BOOLEAN         bInit                           ;
    PVOID           pExAllocatePool                 ;
    PVOID           pExAllocatePoolWithTag          ;
    PVOID           pExAllocatePoolQuota            ;
    PVOID           pExAllocatePoolWithQuotaTag     ;
    PVOID           pMmAllocateContiguousMemory     ;
    PVOID           pMmAllocateNonCachedMemory      ;
    UNICODE_STRING  usRtlAnsiStringToUnicodeString  ;
    ANSI_STRING     ansiRtlUnicodeStringToAnsiString;
    HANDLE          hIoCreateNotificationEvent      ;
    HANDLE          hIoCreateSynchronizationEvent   ;
} HAPPYALLOCS , * PHAPPYALLOCS ;

// The two types of allocations.
static HAPPYALLOCS g_Tracked ;
static HAPPYALLOCS g_NotTracked ;

#define NUM_BYTES 20

void DoTrackedAllocs ( void )
{
    PHYSICAL_ADDRESS  Phys ;
    Phys.LowPart = 0xFFFFFFFF ;
    Phys.HighPart = 0xFFFFFFFF ;

    ANSI_STRING aStr ;
    RtlInitAnsiString ( &aStr , "ANSI" ) ;

    UNICODE_STRING uStr ;
    RtlInitUnicodeString ( &uStr , L"Unicode" ) ;

    UNICODE_STRING uStr2 ;
    RtlInitUnicodeString ( &uStr2 , L"Unicode2" ) ;

    g_Tracked.bInit = TRUE ;

    g_Tracked.pExAllocatePool =
            TrackExAllocatePool ( NonPagedPool , NUM_BYTES ) ;
    g_Tracked.pExAllocatePoolWithTag =
            TrackExAllocatePoolWithTag ( NonPagedPool ,
                                         NUM_BYTES ,
                                         'DOOF' ) ;
    g_Tracked.pExAllocatePoolQuota =
            TrackExAllocatePoolWithQuota ( NonPagedPool , NUM_BYTES ) ;
    g_Tracked.pExAllocatePoolWithQuotaTag =
            TrackExAllocatePoolWithQuotaTag ( NonPagedPool  ,
                                              NUM_BYTES     ,
                                              'DOOF'         ) ;
    g_Tracked.pMmAllocateContiguousMemory =
            TrackMmAllocateContiguousMemory ( NUM_BYTES , Phys ) ;
    g_Tracked.pMmAllocateNonCachedMemory =
            TrackMmAllocateNonCachedMemory ( NUM_BYTES ) ;

    TrackRtlAnsiStringToUnicodeString (
                              &g_Tracked.usRtlAnsiStringToUnicodeString,
                              &aStr ,
                              TRUE ) ;

    TrackRtlUnicodeStringToAnsiString (
                            &g_Tracked.ansiRtlUnicodeStringToAnsiString,
                            &uStr ,
                            TRUE   ) ;
    TrackIoCreateNotificationEvent ( &uStr ,
                                &g_Tracked.hIoCreateNotificationEvent ) ;

    TrackIoCreateSynchronizationEvent ( &uStr2 ,
                              &g_Tracked.hIoCreateSynchronizationEvent);
}

void DoNotTrackedAllocs ( void )
{
    PHYSICAL_ADDRESS  Phys ;
    Phys.LowPart = 0xFFFFFFFF ;
    Phys.HighPart = 0xFFFFFFFF ;

    ANSI_STRING aStr ;
    RtlInitAnsiString ( &aStr , "ANSI5" ) ;

    UNICODE_STRING uStr ;
    RtlInitUnicodeString ( &uStr , L"Unicode5" ) ;

    UNICODE_STRING uStr2 ;
    RtlInitUnicodeString ( &uStr2 , L"Unicode10" ) ;

    g_NotTracked.bInit = TRUE ;

    g_NotTracked.pExAllocatePool =
            ExAllocatePool ( NonPagedPool , NUM_BYTES ) ;
    g_NotTracked.pExAllocatePoolWithTag =
            ExAllocatePoolWithTag ( NonPagedPool ,
                                    NUM_BYTES ,
                                    'DOOF' ) ;
    g_NotTracked.pExAllocatePoolQuota =
            ExAllocatePoolWithQuota ( NonPagedPool , NUM_BYTES ) ;
    g_NotTracked.pExAllocatePoolWithQuotaTag =
            TrackExAllocatePoolWithQuotaTag ( NonPagedPool  ,
                                              NUM_BYTES     ,
                                              'DOOF'         ) ;
    g_NotTracked.pMmAllocateContiguousMemory =
            MmAllocateContiguousMemory ( NUM_BYTES , Phys ) ;
    g_NotTracked.pMmAllocateNonCachedMemory =
            MmAllocateNonCachedMemory ( NUM_BYTES ) ;

    RtlAnsiStringToUnicodeString (
                              &g_NotTracked.usRtlAnsiStringToUnicodeString,
                              &aStr ,
                              TRUE ) ;

    RtlUnicodeStringToAnsiString (
                            &g_NotTracked.ansiRtlUnicodeStringToAnsiString,
                            &uStr ,
                            TRUE   ) ;
    IoCreateNotificationEvent ( &uStr ,
                                &g_NotTracked.hIoCreateNotificationEvent ) ;

    IoCreateSynchronizationEvent ( &uStr2 ,
                              &g_NotTracked.hIoCreateSynchronizationEvent);
}

void DoFrees ( void )
{
    if ( TRUE == g_Tracked.bInit )
    {
        TrackExFreePool ( g_Tracked.pExAllocatePool ) ;
        TrackExFreePool ( g_Tracked.pExAllocatePoolWithTag ) ;
        TrackExFreePool ( g_Tracked.pExAllocatePoolQuota ) ;
        TrackExFreePool ( g_Tracked.pExAllocatePoolWithQuotaTag ) ;
        TrackMmFreeContiguousMemory (
                               g_Tracked.pMmAllocateContiguousMemory ) ;
        TrackMmFreeNonCachedMemory (
                                  g_Tracked.pMmAllocateNonCachedMemory,
                                  NUM_BYTES );
        TrackRtlFreeUnicodeString(&g_Tracked.usRtlAnsiStringToUnicodeString);
        TrackRtlFreeAnsiString(&g_Tracked.ansiRtlUnicodeStringToAnsiString);

        TrackZwClose ( g_Tracked.hIoCreateNotificationEvent ) ;
        TrackZwClose ( g_Tracked.hIoCreateSynchronizationEvent ) ;
        g_Tracked.bInit = FALSE ;
    }
}

void DoCorrupt ( void )
{
    char * szAlloc = (char*)TrackExAllocatePool ( NonPagedPool ,
                                                  NUM_BYTES );

    char * szUnder = szAlloc - 1 ;
    *szUnder = 'U' ;

    char * szOver = szAlloc + NUM_BYTES + 1 ;
    *szOver = 'O' ;
}

void DoCheckMem ( void )
{
    TRACKVALIDATEALLOCATED ( ) ;
}

void DoDumpMem ( void )
{
    TRACKDUMPALLOCATED ( ) ;
}

void DoStats ( void )
{
    TRACKSTATS ( ) ;
}

