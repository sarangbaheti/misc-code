/*----------------------------------------------------------------------
FILE        :   TrackTest.h
DISCUSSION  :
    The main internal header file for the TrackTest device driver.
----------------------------------------------------------------------*/

#ifndef _TRACKTEST_H
#define _TRACKTEST_H

////////////////////////////////////////////////////////////////////////
// The device name and link defines.
#define TRACKTEST_NAME_STRING    L"\\Device\\TRACKTEST"
#define TRACKTEST_LINK_STRING    L"\\DosDevices\\TrackTest"

////////////////////////////////////////////////////////////////////////
// The usual device extension where all global values are stored.
typedef struct _DEVICE_EXTENSION
{
    // A dummy value.
    int bDummy ;

} DEVICE_EXTENSION , * PDEVICE_EXTENSION ;


#endif  // _TRACKTEST_H


