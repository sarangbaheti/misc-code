/*----------------------------------------------------------------------
FILE        :
PROJECT     :
DISCUSSION  :
----------------------------------------------------------------------*/

#include "PCH.h"
#include "Track.h"
#include "TrackInternal.h"

// This file is only active if TRACK is defined.
#ifdef TRACK

/*//////////////////////////////////////////////////////////////////////
                 File Scope Structures and Enumerations
//////////////////////////////////////////////////////////////////////*/
// The eFunc enumeration identified the function that did an allocation
//   of some sort.
typedef enum tag_eHandlesFunc
{
    eOutOfRange = 0 ,

    eZwClose ,

    eIoCreateNotificationEvent ,
    eIoCreateSynchronizationEvent ,
    eZwCreateDirectoryObject ,
    eZwCreateFile ,
    eZwOpenKey ,
    eZwOpenSection ,

    eMaxRange
} eHandlesFunc ;

typedef struct tag_HANDLESSTATS
{
    ULONG ulTotalCalls ;
} HANDLESSTATS , * PHANDLESSTATS ;

/*//////////////////////////////////////////////////////////////////////
                    File Scope Defines and Constants
//////////////////////////////////////////////////////////////////////*/

/*//////////////////////////////////////////////////////////////////////
                         File Scope Prototypes
//////////////////////////////////////////////////////////////////////*/

/*//////////////////////////////////////////////////////////////////////
                           File Scope Globals
//////////////////////////////////////////////////////////////////////*/
static HANDLESSTATS g_HandlesStats ;

static char * g_szFuncNames[ ] =
{
    "**OutOfRange**" ,

    "ZwClose" ,

    "IoCreateNotificationEvent" ,
    "IoCreateSynchronizationEvent" ,
    "ZwCreateDirectoryObject" ,
    "ZwCreateFile" ,
    "ZwOpenKey" ,
    "ZwOpenSection" ,

    "**eMaxRange**"
} ;

/*//////////////////////////////////////////////////////////////////////
                       Implementation Starts Here
//////////////////////////////////////////////////////////////////////*/

void TrackHandlesInitialize ( void )
{
    RtlFillMemory ( &g_HandlesStats , sizeof ( HANDLESSTATS ) , 0 ) ;
}

void TrackHandlesClose ( void )
{
}

void TrackHandlesStats ( void )
{
    TRACE ( "************************\n" ) ;
    TRACE ( "Track Handle Statistics*\n" ) ;
    TRACE ( "************************\n" ) ;
    TRACE ( "  Total Handle Calls : %u\n" ,
            g_HandlesStats.ulTotalCalls ) ;
}

void TrackHandlesReportLeak ( PTRACKALLOCATION pItem )
{
    ASSERT ( TRUE == MmIsAddressValid ( pItem ) ) ;
    TRACE ( "AllocatorFn : %s\n" , g_szFuncNames[ pItem->sID ] ) ;
    TRACE ( "   Source   : %s\n" , pItem->szSource ) ;
    TRACE ( "   Line     : %d\n" , pItem->lLine ) ;
}

/*//////////////////////////////////////////////////////////////////////
                          Wrappers Start Here
//////////////////////////////////////////////////////////////////////*/
NTSTATUS Track_ZwClose ( IN HANDLE Handle ,
                         char *    szFile ,
                         ULONG     uLine   )
{
    if ( FALSE == InternalInitialized ( ) )
    {
        return ( ZwClose ( Handle ) ) ;
    }

    // Grab the spinlock so the information can be added to the list.
    KIRQL kOldIrql ;
    // A boolean that tells me if I can ZwClose.
    BOOLEAN bCallFunction = TRUE ;
    // The return value.
    NTSTATUS ntRet = STATUS_INVALID_HANDLE ;
    __try
    {
        __try
        {
            InternalAcquireSpinLock ( &kOldIrql ) ;

            PTRACKALLOCATION pTemp =
                               InternalFindAllocation ( (ULONG)Handle );
            if ( NULL != pTemp )
            {
                // Is this from the matching allocator?
                switch ( pTemp->sID )
                {
                    case eIoCreateNotificationEvent :
                        bCallFunction = TRUE ;
                        InternalRemoveAllocation ( pTemp ) ;
                        break ;

                    default :
                        // Got a little problem.
                        TRACE ( k_TRACK_ERROR ) ;
                        TRACE ( "The object created in %s, line %d "
                                "cannot be deleted with "
                                "ZwClose.\n" ) ;
                        TRACE ( k_TRACK_ERROR ) ;
                        ASSERTMSG ( "Invalid delete" , FALSE ) ;
                        bCallFunction = FALSE ;
                        break ;
                }
            }
            else
            {
                // Whoops, show the warning!
                TRACE ( k_TRACK_WARN ) ;
                TRACE ( "ZwClose was called in %s, line %d with "
                        "memory that was not tracked\n" ,
                        szFile                          ,
                        uLine                            ) ;
                TRACE ( k_TRACK_WARN ) ;
                bCallFunction = FALSE ;
            }
        }
        __except ( EXCEPTION_EXECUTE_HANDLER )
        {
            ASSERTMSG ( "Track_ZwClose had an access violation!\n"                       ,
                        FALSE                                     ) ;
        }
    }
    __finally
    {
        // Always release the spinlock and drop the IRQL so that I can
        //  call ZwClose.
        InternalReleaseSpinLock ( kOldIrql ) ;
        if ( TRUE == bCallFunction )
        {
            ntRet = ZwClose ( Handle ) ;
        }
    }
    return ( ntRet ) ;
}


PKEVENT Track_IoCreateNotificationEvent ( IN PUNICODE_STRING  EventName,
                                          OUT PHANDLE  EventHandle,
                                          char * szFile,
                                          ULONG  uLine  )
{
    PKEVENT pkRet = IoCreateNotificationEvent ( EventName   ,
                                                EventHandle  ) ;
    if ( ( TRUE == InternalInitialized ( ) ) &&
         ( NULL != pkRet                   )    )
    {
        InternalAddSimpleAlloction (  TRACKCLASS_HANDLES         ,
                                      eIoCreateNotificationEvent ,
                                      (ULONG)*EventHandle        ,
                                      szFile                     ,
                                      uLine                       ) ;
        g_HandlesStats.ulTotalCalls++ ;
    }
    return ( pkRet ) ;
}

PKEVENT Track_IoCreateSynchronizationEvent (
                                           IN PUNICODE_STRING EventName,
                                           OUT PHANDLE  EventHandle ,
                                           char * szFile ,
                                           ULONG  uLine )
{
    PKEVENT pkRet = IoCreateSynchronizationEvent ( EventName   ,
                                                   EventHandle  ) ;
    if ( ( TRUE == InternalInitialized ( ) ) &&
         ( NULL != pkRet                   )    )
    {
        InternalAddSimpleAlloction ( TRACKCLASS_HANDLES            ,
                                     eIoCreateSynchronizationEvent ,
                                     (ULONG)*EventHandle           ,
                                      szFile                       ,
                                      uLine                         ) ;
        g_HandlesStats.ulTotalCalls++ ;
    }
    return ( pkRet ) ;
}

NTSTATUS Track_ZwCreateDirectoryObject (
                                OUT PHANDLE  DirectoryHandle,
                                IN ACCESS_MASK  DesiredAccess,
                                IN POBJECT_ATTRIBUTES  ObjectAttributes,
                                char * szFile ,
                                ULONG  uLine   )
{
    NTSTATUS ntRet = ZwCreateDirectoryObject ( DirectoryHandle  ,
                                               DesiredAccess    ,
                                               ObjectAttributes  ) ;
    if ( ( TRUE == InternalInitialized ( ) ) &&
         ( NT_SUCCESS ( ntRet )            )    )
    {
        InternalAddSimpleAlloction ( TRACKCLASS_HANDLES       ,
                                     eZwCreateDirectoryObject ,
                                     (ULONG)*DirectoryHandle  ,
                                     szFile                   ,
                                     uLine                     ) ;
        g_HandlesStats.ulTotalCalls++ ;
    }
    return ( ntRet ) ;
}

NTSTATUS Track_ZwCreateFile ( OUT PHANDLE FileHandle,
                              IN ACCESS_MASK DesiredAccess,
                              IN POBJECT_ATTRIBUTES ObjectAttributes,
                              OUT PIO_STATUS_BLOCK IoStatusBlock,
                              IN PLARGE_INTEGER AllocationSize,
                              IN ULONG FileAttributes,
                              IN ULONG ShareAccess,
                              IN ULONG CreateDisposition,
                              IN ULONG CreateOptions,
                              IN PVOID EaBuffer,
                              IN ULONG EaLength,
                              char * szFile ,
                              ULONG  uLine   )
{
    NTSTATUS ntRet = ZwCreateFile ( FileHandle          ,
                                    DesiredAccess       ,
                                    ObjectAttributes    ,
                                    IoStatusBlock       ,
                                    AllocationSize      ,
                                    FileAttributes      ,
                                    ShareAccess         ,
                                    CreateDisposition   ,
                                    CreateOptions       ,
                                    EaBuffer            ,
                                    EaLength             ) ;
    if ( ( TRUE == InternalInitialized ( ) ) &&
         ( NT_SUCCESS ( ntRet )            )    )
    {
        InternalAddSimpleAlloction ( TRACKCLASS_HANDLES  ,
                                     eZwCreateFile       ,
                                     (ULONG)*FileHandle  ,
                                     szFile              ,
                                     uLine               ) ;
        g_HandlesStats.ulTotalCalls++ ;
    }
    return ( ntRet ) ;
}

NTSTATUS Track_ZwOpenKey ( OUT PHANDLE  KeyHandle,
                           IN ACCESS_MASK  DesiredAccess,
                           IN POBJECT_ATTRIBUTES  ObjectAttributes,
                           char * szFile ,
                           ULONG  uLine   )
{
    NTSTATUS ntRet = ZwOpenKey ( KeyHandle          ,
                                 DesiredAccess      ,
                                 ObjectAttributes    ) ;
    if ( ( TRUE == InternalInitialized ( ) ) &&
         ( NT_SUCCESS ( ntRet )            )    )
    {
        InternalAddSimpleAlloction ( TRACKCLASS_HANDLES ,
                                     eZwOpenKey         ,
                                     (ULONG)*KeyHandle  ,
                                     szFile             ,
                                     uLine               ) ;
        g_HandlesStats.ulTotalCalls++ ;
    }
    return ( ntRet ) ;
}

NTSTATUS Track_ZwOpenSection ( OUT PHANDLE  SectionHandle,
                               IN ACCESS_MASK  DesiredAccess,
                               IN POBJECT_ATTRIBUTES  ObjectAttributes,
                               char * szFile ,
                               ULONG  uLine )
{
    NTSTATUS ntRet = ZwOpenSection ( SectionHandle      ,
                                     DesiredAccess      ,
                                     ObjectAttributes    ) ;
    if ( ( TRUE == InternalInitialized ( ) ) &&
         ( NT_SUCCESS ( ntRet )            )    )
    {
        InternalAddSimpleAlloction ( TRACKCLASS_HANDLES    ,
                                     eZwOpenSection        ,
                                     (ULONG)*SectionHandle ,
                                     szFile                ,
                                     uLine                  ) ;
        g_HandlesStats.ulTotalCalls++ ;
    }
    return ( ntRet ) ;
}

// This file is only active if TRACK is defined.
#endif



