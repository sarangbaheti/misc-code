/*----------------------------------------------------------------------
   John Robbins - Jan '99 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
    Where all the real work gets done for the TRACK system.
----------------------------------------------------------------------*/

#include "PCH.h"
#include "Track.h"
#include "TrackInternal.h"
#include "TrackMemory.h"
#include "TrackGeneralResources.h"
#include "TrackHandles.h"

// This file is only active if TRACK is defined.
#ifdef TRACK

/*//////////////////////////////////////////////////////////////////////
                 File Scope Structures and Enumerations
//////////////////////////////////////////////////////////////////////*/

/*//////////////////////////////////////////////////////////////////////
                    File Scope Defines and Constants
//////////////////////////////////////////////////////////////////////*/
// The maximum entries on the lookaside list.  If your driver does a
//  good number of allocations, you might want to bump this up.
const USHORT k_LL_DEPTH = 50 ;

/*//////////////////////////////////////////////////////////////////////
                         File Scope Prototypes
//////////////////////////////////////////////////////////////////////*/

/*//////////////////////////////////////////////////////////////////////
                           File Scope Globals
//////////////////////////////////////////////////////////////////////*/
// The lookaside list where all TRACKALLOCATION structures are allocated
//  from.
static NPAGED_LOOKASIDE_LIST g_NPLL ;
// The head of the allocation list.  This is just here to have a known
//  place.
static LIST_ENTRY g_AllocHead ;
// The spin lock that protects access to g_pAllocHead.
static KSPIN_LOCK g_kAllocSL ;
// The flag that indicates life is initialized.
static BOOLEAN g_bInitialized = FALSE ;

/*//////////////////////////////////////////////////////////////////////
                       Implementation Starts Here
//////////////////////////////////////////////////////////////////////*/

// See TrackInternal.h for a discussion.
NTSTATUS InternalInitializeStorage ( void )
{
    // This function can only be run at PASSIVE_LEVEL.
    ASSERTIRQL ( PASSIVE_LEVEL ) ;

    __try
    {
        // Initialize the spinlock that protects the allocation list.
        KeInitializeSpinLock ( &g_kAllocSL ) ;

        // Allocate the lookaside list.
        ExInitializeNPagedLookasideList ( &g_NPLL                    ,
                                          NULL                       ,
                                          NULL                       ,
                                          0                          ,
                                          sizeof ( TRACKALLOCATION ) ,
                                          'KART'                     ,
                                          k_LL_DEPTH                  );

        InitializeListHead ( &g_AllocHead ) ;

        // Initialize all the class subsystems.
        TrackMemoryInitialize ( ) ;
        TrackGeneralResourcesInitialize ( ) ;
        TrackHandlesInitialize ( ) ;

        // Initialization worked.
        g_bInitialized = TRUE ;

    }
    __except ( EXCEPTION_EXECUTE_HANDLER )
    {
        ASSERTMSG ( "InternalInitializeStorage had an access "
                    "violation!\n" , FALSE ) ;
        // This sure did not initialize.
        g_bInitialized = FALSE ;
    }

    if ( TRUE == g_bInitialized )
    {
        return ( STATUS_SUCCESS ) ;
    }
    else
    {
        return ( STATUS_ACCESS_VIOLATION ) ;
    }
}

// See TrackInternal.h for a discussion.
NTSTATUS InternalCloseStorage ( void )
{
    // This function can only be run at PASSIVE_LEVEL.
    ASSERTIRQL ( PASSIVE_LEVEL ) ;

    // Is life initialized?
    if ( FALSE == g_bInitialized )
    {
        return ( STATUS_UNSUCCESSFUL ) ;
    }

    // Now grab the spin lock.
    KIRQL kOldIrql ;
    KeAcquireSpinLock ( &g_kAllocSL , &kOldIrql ) ;
    __try
    {
        __try
        {
            // Free up the lookaside list and everything on it.
            ExDeleteNPagedLookasideList ( &g_NPLL ) ;

            // Reinitialize the list head since all the memory it
            //  points to is gone.
            InitializeListHead ( &g_AllocHead ) ;

            // Close down all the class subsystems.
            TrackMemoryClose ( ) ;
            TrackGeneralResourcesClose ( ) ;
            TrackHandlesClose ( ) ;

            // Indicate that the subsystem is cooked.
            g_bInitialized = FALSE ;

        }
        __except ( EXCEPTION_EXECUTE_HANDLER )
        {
            ASSERTMSG ( "TrackClose had an access violation!\n" ,
                        FALSE                                    ) ;
        }
    }
    __finally
    {
        // Indicate that the subsystem is cooked.
        g_bInitialized = FALSE ;

        // Always release the spinlock.
        KeReleaseSpinLock ( &g_kAllocSL , kOldIrql ) ;
    }
    return ( STATUS_SUCCESS ) ;
}

// See TrackInternal.h for a discussion.
BOOLEAN InternalInitialized ( void )
{
    if ( FALSE == g_bInitialized )
    {
        TRACE ( k_TRACK_WARN ) ;
        TRACE ( "The Track Library is not initialized!\n" ) ;
        TRACE ( k_TRACK_WARN ) ;
    }
    return ( g_bInitialized ) ;
}

// See TrackInternal.h for a discussion.
PTRACKALLOCATION InternalAllocateStorage ( void )
{
    PTRACKALLOCATION pTemp ;
    pTemp = (PTRACKALLOCATION)
                         ExAllocateFromNPagedLookasideList ( &g_NPLL ) ;
    ASSERT ( NULL != pTemp ) ;
    // Put garbage in the memory to keep myself honest.
    RtlFillMemory ( pTemp , sizeof ( TRACKALLOCATION ) , 0xCD ) ;
    return ( pTemp ) ;
}

// See TrackInternal.h for a discussion.
NTSTATUS InternalRemoveAllocation ( PTRACKALLOCATION pTrackAlloc )
{
    ASSERT ( TRUE == MmIsAddressValid ( pTrackAlloc ) ) ;
    if ( FALSE == MmIsAddressValid ( pTrackAlloc ) )
    {
        return ( STATUS_INVALID_PARAMETER ) ;
    }

    // Take the memory out of the list.
    RemoveEntryList ( &pTrackAlloc->stListEntry ) ;

    // Put garbage in just incase the memory gets touched again.
    RtlFillMemory ( pTrackAlloc , sizeof ( TRACKALLOCATION ) , 0xDC ) ;

    // Now free the memory.
    ExFreeToNPagedLookasideList ( &g_NPLL , pTrackAlloc ) ;

    // All OK, Jumpmaster!
    return ( STATUS_SUCCESS ) ;
}

// See TrackInternal.h for a discussion.
NTSTATUS InternalAddAllocation ( PTRACKALLOCATION pTrackAlloc )
{
    // Always check.
    ASSERT ( TRUE == MmIsAddressValid ( pTrackAlloc ) ) ;
    if ( FALSE == MmIsAddressValid ( pTrackAlloc ) )
    {
        return ( STATUS_INVALID_PARAMETER ) ;
    }

    // Put this block at the head of the list.
    InsertHeadList ( &g_AllocHead , &pTrackAlloc->stListEntry ) ;

    // All OK, Jumpmaster!
    return ( STATUS_SUCCESS ) ;
}

// See TrackInternal.h for a discussion.
PTRACKALLOCATION InternalFindAllocation ( ULONG ulValue )
{
    // Check the easy case.
    if ( TRUE == IsListEmpty ( &g_AllocHead ) )
    {
        return ( NULL ) ;
    }

    // There's at least something to look for.
    PTRACKALLOCATION pRet = (PTRACKALLOCATION)g_AllocHead.Flink ;
    while ( (PLIST_ENTRY)pRet != &g_AllocHead )
    {
        // Is this the one?
        if ( pRet->ulValue == ulValue )
        {
            return ( pRet ) ;
        }
        pRet = (PTRACKALLOCATION)pRet->stListEntry.Flink ;
    }

    // Bummer, did not find it.
    return ( NULL ) ;
}

// See TrackInternal.h for a discussion.
NTSTATUS InternalValidateAllocated ( void )
{
    // Is life initialized?
    if ( FALSE == g_bInitialized )
    {
        return ( STATUS_UNSUCCESSFUL ) ;
    }

    NTSTATUS ntRet = STATUS_SUCCESS ;
    __try
    {

        PTRACKALLOCATION pCurr = (PTRACKALLOCATION)g_AllocHead.Flink ;
        while ( (PLIST_ENTRY)pCurr != &g_AllocHead )
        {
            NTSTATUS ntCheckRet ;
            switch ( pCurr->sClassID )
            {
                case TRACKCLASS_MEMORY  :
                    ntCheckRet = TrackMemoryCheckMem ( pCurr ) ;
                    break ;
                case TRACKCLASS_GENERALRESOURCES:
                    // Nothing to do yet.
                    break ;
                case TRACKCLASS_HANDLES :
                    // Noting to do yet.
                    break ;
                default :
                    TRACE ( "^^^^^^^^^^^^^^\n" ) ;
                    TRACE ( "Unknown type in InternalValidateAllocated"
                            " (%d)\n" , pCurr->sClassID ) ;
                    TRACE ( "^^^^^^^^^^^^^^\n" ) ;
                    break ;
            }
            // If unsuccessful, keep track of that.
            if ( STATUS_UNSUCCESSFUL == ntCheckRet )
            {
                ntRet = STATUS_UNSUCCESSFUL ;
            }
            // Look at the next one.
            pCurr = (PTRACKALLOCATION)pCurr->stListEntry.Flink ;
        }
    }
    __except ( EXCEPTION_EXECUTE_HANDLER )
    {
        ntRet = STATUS_ACCESS_VIOLATION ;
    }
    return ( ntRet ) ;
}

// See TrackInternal.h for a discussion.
void InternalAcquireSpinLock ( PKIRQL pIrql )
{
    KeAcquireSpinLock ( &g_kAllocSL , pIrql ) ;
}

// See TrackInternal.h for a discussion.
void InternalReleaseSpinLock ( KIRQL kIrql )
{
    KeReleaseSpinLock ( &g_kAllocSL , kIrql ) ;
}

// See TrackInternal.h for a discussion.
NTSTATUS InternalReportLeaks ( void )
{
    // Is life initialized?
    if ( FALSE == g_bInitialized )
    {
        return ( STATUS_UNSUCCESSFUL ) ;
    }

    NTSTATUS ntRet = STATUS_SUCCESS ;
    __try
    {
        if ( FALSE == IsListEmpty ( &g_AllocHead ) )
        {
            TRACE ( "****************************************\n" ) ;
            TRACE ( "Track Reports Allocation/Resource Leaks:\n" ) ;
            TRACE ( "****************************************\n" ) ;

            PTRACKALLOCATION pCurr =
                               (PTRACKALLOCATION)g_AllocHead.Flink ;
            while ( (PLIST_ENTRY)pCurr != &g_AllocHead )
            {
                switch ( pCurr->sClassID )
                {
                    case TRACKCLASS_MEMORY  :
                        TrackMemoryReportLeak ( pCurr ) ;
                        break ;

                    case TRACKCLASS_GENERALRESOURCES:
                        TrackGeneralResourcesReportLeak ( pCurr ) ;
                        break ;

                    case TRACKCLASS_HANDLES:
                        TrackHandlesReportLeak ( pCurr ) ;
                        break ;

                    default :
                        TRACE ( "^^^^^^^^^^^^^^\n" ) ;
                        TRACE ( "Unknown type in InternalReportLeaks"
                                " (%d)\n" , pCurr->sClassID ) ;
                        TRACE ( "^^^^^^^^^^^^^^\n" ) ;
                        break ;
                }
                pCurr = (PTRACKALLOCATION)pCurr->stListEntry.Flink ;
            }
        }
        else
        {
            TRACE("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n") ;
            TRACE("Track Reports No Memory or Resource Leaks!!\n") ;
            TRACE("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n") ;
        }
    }
    __except ( EXCEPTION_EXECUTE_HANDLER )
    {
        ntRet = STATUS_ACCESS_VIOLATION ;
    }
    return ( ntRet ) ;
}

// See TrackInternal.h for a discussion.
NTSTATUS InternalReportStats ( void )
{
    // Is life initialized?
    if ( FALSE == g_bInitialized )
    {
        return ( STATUS_UNSUCCESSFUL ) ;
    }
    // Call each class subsystem in turn.
    // Do memory.
    TrackMemoryStats ( ) ;
    TrackGeneralResourcesStats ( ) ;
    TrackHandlesStats ( ) ;

    return ( STATUS_SUCCESS ) ;
}

// See TrackInternal.h for a discussion.
NTSTATUS InternalAddSimpleAlloction ( SHORT     sClassID ,
                                      SHORT     sID      ,
                                      ULONG     ulValue  ,
                                      char *    szFile   ,
                                      ULONG     ulLine    )
{
    // Grab the spinlock so the information can be added to the list.
    KIRQL kOldIrql ;
    // The return value.
    NTSTATUS ntRet = STATUS_SUCCESS ;
    __try
    {
        __try
        {
            InternalAcquireSpinLock ( &kOldIrql ) ;

            // Allocate a new chunk of memory from the lookaside list.
            PTRACKALLOCATION pTemp ;
            pTemp = InternalAllocateStorage ( ) ;
            ASSERT ( NULL != pTemp ) ;

            // Fill out all identification information.
            pTemp->sClassID = sClassID ;
            pTemp->sID = sID ;

            // Put the source file in.
            int iLast = min ( sizeof ( pTemp->szSource ) - 1 ,
                              strlen ( szFile )               ) ;

            strncpy ( pTemp->szSource ,
                      szFile          ,
                      iLast            ) ;
            pTemp->szSource[ iLast ] = '\0' ;

            // Do the source line.
            pTemp->lLine   = ulLine ;
            // The key value.
            pTemp->ulValue = ulValue ;
            // Zero out unused fields.
            pTemp->ulFlags = 0 ;
            pTemp->ulSize  = 0 ;

            // Put this block at the head of the list.
            InternalAddAllocation ( pTemp ) ;

        }
        __except ( EXCEPTION_EXECUTE_HANDLER )
        {
            ASSERTMSG ( "InternalAddSimpleAlloction had an access "
                        "violation!\n"                             ,
                        FALSE                                       ) ;
            ntRet = STATUS_UNSUCCESSFUL ;
        }
    }
    __finally
    {
        // Always release the spinlock.
        InternalReleaseSpinLock ( kOldIrql ) ;
    }
    return ( ntRet ) ;
}

// This file is only active if TRACK is defined.
#endif

