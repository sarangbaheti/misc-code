/*----------------------------------------------------------------------
   John Robbins - Jan '99 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
    This is the implementation file for those APIs that do memory
allocations.  The TRACK system puts guard bytes on the front and end of
all allocations to protect against underwrites and overwrites.
Additionally, it fills in those guard bytes when the memory is deleted
to protect against double deletes.
----------------------------------------------------------------------*/

#include "PCH.h"
#include "Track.h"
#include "TrackInternal.h"

// This file is only active if TRACK is defined.
#ifdef TRACK

/*//////////////////////////////////////////////////////////////////////
                 File Scope Structures and Enumerations
//////////////////////////////////////////////////////////////////////*/
// The eFunc enumeration identified the function that did an allocation
//   of some sort.  This must be in the same order as g_szFuncNames.
typedef enum tag_eMemFunc
{
    eOutOfRange = 0             ,

    // Common memory allocation routines.
    eExAllocatePool             ,
    eExAllocatePoolWithQuota    ,
    eExAllocatePoolWithQuotaTag ,
    eExAllocatePoolWithTag      ,
    eExFreePool                 ,

    eMmAllocateContiguousMemory ,
    eMmAllocateNonCachedMemory  ,
    eMmFreeContiguousMemory     ,
    eMmFreeNonCachedMemory      ,

    eMaxRange
} eMemFunc ;

// The core memory allocation stats structure.
typedef struct tag_TRACKMEMSTATS
{
    // The total number of memory allocations calls of all types.
    ULONG       ulTotalAllocCalls   ;
    // The maximum nonpaged memory allocated.
    ULONG       ulMaxNonPagedMem    ;
    // The current nonpaged memory allocated.
    ULONG       ulCurrNonPageMem    ;
    // The maximum paged memory allocated.
    ULONG       ulMaxPagedMem       ;
    // The current paged memory allocated.
    ULONG       ulCurrPagedMem      ;
} TRACKMEMSTATS , * PTRACKMEMSTATS ;

/*//////////////////////////////////////////////////////////////////////
                    File Scope Defines and Constants
//////////////////////////////////////////////////////////////////////*/

// The value placed in header guard bytes to look for underwrites.
const ULONG k_INIT_GUARD_BYTES = 0xEDFEEFBE ; //0xBEEFFEED
// The values placed in the guard bytes after memory is deallocated.
const ULONG k_FREED_GUARD_BYTES = 0xDEC0ADDE ; //0xDEADC0DE

// The number to bump up the requested bytes by to put on the guard
//  bytes.
const ULONG k_GUARD_BYTE_SIZE = sizeof ( k_INIT_GUARD_BYTES ) * 2 ;

/*//////////////////////////////////////////////////////////////////////
                         File Scope Prototypes
//////////////////////////////////////////////////////////////////////*/

// Checks if guard bytes are still properly placed in the memory.
static ULONG CheckGuardBytes ( PVOID pMem       ,
                               ULONG ulSize     ,
                               ULONG ulBytes     ) ;

// Checks if memory is corrupted.
static NTSTATUS CheckMemForCorruption ( PTRACKALLOCATION pItem      ,
                                        char *           szFreeFile ,
                                        ULONG            ulLine      ) ;

/*//////////////////////////////////////////////////////////////////////
                           File Scope Globals
//////////////////////////////////////////////////////////////////////*/

// The memory stats.
static TRACKMEMSTATS g_MemStats ;

// The DDK functions handled by this file.  This must match the eMemFunc
//  enumeration.
static char * g_szFuncNames[ ] =
{
    "OutOfRange"                 ,

    // Common memory allocation routines.
    "ExAllocatePool"             ,
    "ExAllocatePoolWithQuota"    ,
    "ExAllocatePoolWithQuotaTag" ,
    "ExAllocatePoolWithTag"      ,
    "ExFreePool"                 ,

    "MmAllocateContiguousMemory" ,
    "MmAllocateNonCachedMemory"  ,
    "MmFreeContiguousMemory"     ,
    "MmFreeNonCachedMemory"      ,

    "MaxRange"
} ;

/*//////////////////////////////////////////////////////////////////////
                       Implementation Starts Here
//////////////////////////////////////////////////////////////////////*/

void TrackMemoryInitialize ( void )
{
    // Just need to zero out the mem stats.
    RtlFillMemory ( &g_MemStats , sizeof ( TRACKMEMSTATS ) , 0 ) ;
}

void TrackMemoryClose ( void )
{
    // Nothing to do.
}

// To get the current statistics that Track has, call this function.
void TrackMemoryStats ( void )
{
    TRACE ( "************************\n" ) ;
    TRACE ( "Track Memory Statistics*\n" ) ;
    TRACE ( "************************\n" ) ;
    TRACE ( "  Total Alloc Calls     : %u\n" ,
            g_MemStats.ulTotalAllocCalls ) ;
    TRACE ( "  Total Paged Pool      : %u\n" ,
            g_MemStats.ulMaxNonPagedMem     ) ;
    TRACE ( "  Current Paged Pool    : %u\n" ,
            g_MemStats.ulCurrNonPageMem     ) ;
    TRACE ( "  Total NonPaged Pool   : %u\n" ,
            g_MemStats.ulMaxPagedMem        ) ;
    TRACE ( "  Current NonPaged Pool : %u\n" ,
            g_MemStats.ulCurrNonPageMem       ) ;
}

// The function that can be called to dump all currently allocated
//  items to DbgPrint.
void TrackMemoryReportLeak ( PTRACKALLOCATION pItem )
{
    ASSERT ( TRUE == MmIsAddressValid ( pItem ) ) ;
    TRACE ( "AllocatorFn : %s\n" , g_szFuncNames[ pItem->sID ] ) ;
    TRACE ( "   Source   : %s\n" , pItem->szSource ) ;
    TRACE ( "   Line     : %d\n" , pItem->lLine ) ;
    TRACE ( "   Size     : %u\n" , pItem->ulSize ) ;
}

// Checks if the memory block has overwrites, or undewrites.
NTSTATUS TrackMemoryCheckMem ( PTRACKALLOCATION pItem )
{
    return ( CheckMemForCorruption ( pItem , NULL , 0 ) ) ;
}

// Checks if memory is corrupted.
static NTSTATUS CheckMemForCorruption ( PTRACKALLOCATION pItem      ,
                                        char *           szFreeFile ,
                                        ULONG            ulLine      )
{
    ASSERT ( TRUE == MmIsAddressValid ( pItem ) ) ;

    // I have to check the dispatch level.  One cannot go off and access
    //  paged memory inside pItem at the wrong time!
    if ( ( KeGetCurrentIrql ( ) > APC_LEVEL               ) &&
         ( ( PagedPool == pItem->ulFlags             ) ||
           ( PagedPoolCacheAligned == pItem->ulFlags )    )    )
    {
        TRACE ( k_TRACK_WARN ) ;
        TRACE ( "Track - Running at IRQL > APC_LEVEL, cannot "
                "check paged memory\n" ) ;
        TRACE ( k_TRACK_WARN ) ;
        return ( STATUS_SUCCESS ) ;
    }

    ULONG ulRet = CheckGuardBytes ( (PVOID)pItem->ulValue   ,
                                    pItem->ulSize           ,
                                    k_INIT_GUARD_BYTES       ) ;
    if ( ulRet > 0 )
    {
        char * pCorruptType ;
        if ( 3 == ulRet )
        {
            pCorruptType = "Underwrite and Overwrite" ;
        }
        else if ( 2 == ulRet )
        {
            pCorruptType = "Overwrite" ;
        }
        else
        {
            pCorruptType = "Underwrite" ;
        }
        TRACE ( k_TRACK_ERROR ) ;
        TRACE ( "Memory %s corruption\n" , pCorruptType ) ;
        TRACE ( "  Allocation point : %s, line %d\n" ,
                pItem->szSource ,
                pItem->lLine     ) ;
        if ( NULL != szFreeFile )
        {
            TRACE ( "  Free point       : %s, line %d\n" ,
                    szFreeFile   ,
                    ulLine        ) ;
        }
        TRACE ( k_TRACK_ERROR ) ;
        ASSERTMSG ( "Corrupt Memory" , FALSE ) ;
        return ( STATUS_UNSUCCESSFUL ) ;
    }
    return ( STATUS_SUCCESS ) ;
}

/*//////////////////////////////////////////////////////////////////////
                    Internal Function Implementation
//////////////////////////////////////////////////////////////////////*/
// Given an allocated piece of memory, add the specified bytes to the
//  front and the end.  This returns the pointer to the start of the
//  user's memory.
static PVOID AddGuardBytes ( PVOID pMem , ULONG ulSize , ULONG ulBytes )
{
    ASSERT ( NULL != pMem ) ;

    // Add the front part.
    *(PULONG)pMem = ulBytes ;

    // Add the rear part.
    *(PULONG)((ULONG)pMem + ulSize + sizeof ( ulBytes )) = ulBytes ;
    // Return the user portion.
    return ( (PVOID)((ULONG)pMem + sizeof ( ulBytes ) ) ) ;
}

// Given a piece of memory, which is the user's value, check that the
//  specified guard bytes are still there.  Note that pMem is the value
//  the user is dealing with so this function must do the calculation to
//  the header.
// Returns:
//  0 - The guard bytes are intact.
//  1 - The memory has been underwritten.
//  2 - The memory has been overwritten.
//  3 - The memory has been both over- and underwritten.
static ULONG CheckGuardBytes ( PVOID pMem       ,
                               ULONG ulSize     ,
                               ULONG ulBytes     )
{
    ASSERT ( NULL != pMem ) ;

    // Assume that the check will work.
    ULONG ulRet = 0 ;

    // Check for underwrites.
    PULONG pGB = (PULONG)((ULONG)pMem  - sizeof ( ulBytes ) ) ;
    if ( ulBytes != *pGB )
    {
        ulRet |= 0x01 ;
    }
    // Check for overwrites.
    pGB = (PULONG)( (ULONG)pMem + ulSize ) ;
    if ( ulBytes != *pGB )
    {
        ulRet |= 0x02 ;
    }
    return ( ulRet ) ;
}

// A simple routine to get the real memory header.
static inline PVOID GetRealMemStart ( PVOID pMem )
{
    return ( (PULONG)((ULONG)pMem  - sizeof ( k_INIT_GUARD_BYTES ) ) ) ;
}

static PVOID PutMemInList ( PVOID       pMem       ,
                            ULONG       ulSize     ,
                            eMemFunc    eAllocFunc ,
                            ULONG       ulFlags    ,
                            char *      szFile     ,
                            ULONG       ulLine      )
{
    // Grab the spinlock so the information can be added to the list.
    KIRQL kOldIrql ;
    __try
    {
        __try
        {
            InternalAcquireSpinLock ( &kOldIrql ) ;

            // Put the guard bytes on.  This returns the pointer to
            //  give back to the user.
            pMem = AddGuardBytes ( pMem , ulSize , k_INIT_GUARD_BYTES );

            // Allocate a new chunk of memory from the lookaside list.
            PTRACKALLOCATION pTemp ;
            pTemp = InternalAllocateStorage ( ) ;
            ASSERT ( NULL != pTemp ) ;

            // Fill out all the memory status information.
            pTemp->sClassID = TRACKCLASS_MEMORY ;
            pTemp->sID = eAllocFunc ;

            int iLast = min ( sizeof ( pTemp->szSource ) - 1 ,
                              strlen ( szFile )               ) ;

            strncpy ( pTemp->szSource ,
                      szFile          ,
                      iLast            ) ;
            pTemp->szSource[ iLast ] = '\0' ;

            pTemp->lLine = ulLine ;
            pTemp->ulValue = (ULONG)pMem ;
            pTemp->ulFlags = ulFlags ;
            pTemp->ulSize  = ulSize ;

            // Put this block at the head of the list.
            InternalAddAllocation ( pTemp ) ;

            // Fill out the stats.
            g_MemStats.ulTotalAllocCalls++ ;

            switch ( ( POOL_TYPE )ulFlags )
            {
                case NonPagedPool                   :
                case NonPagedPoolMustSucceed        :
                case NonPagedPoolCacheAligned       :
                case NonPagedPoolCacheAlignedMustS  :
                    g_MemStats.ulCurrPagedMem += ulSize ;
                    g_MemStats.ulMaxNonPagedMem += ulSize ;
                    break ;

                case PagedPool              :
                case PagedPoolCacheAligned  :
                    g_MemStats.ulCurrPagedMem += ulSize ;
                    g_MemStats.ulMaxPagedMem += ulSize ;
                    break ;

                default :
                    TRACE ( k_TRACK_WARN ) ;
                    TRACE ( "Track : Unknown pool type %d"
                            "being allocated\n" ,
                            ulFlags              ) ;
                    TRACE ( k_TRACK_WARN ) ;
                    break ;
            }
        }
        __except ( EXCEPTION_EXECUTE_HANDLER )
        {
            ASSERTMSG ( "PutMemInList had an access violation!\n"                        ,
                        FALSE                                     ) ;
        }
    }
    __finally
    {
        // Always release the spinlock.
        InternalReleaseSpinLock ( kOldIrql ) ;
    }
    return ( pMem ) ;
}

/*//////////////////////////////////////////////////////////////////////
                      Wrapper Functions Start Here
//////////////////////////////////////////////////////////////////////*/

PVOID Track_ExAllocatePool ( IN POOL_TYPE  PoolType       ,
                             IN ULONG      NumberOfBytes  ,
                             char *        szFile         ,
                             ULONG         uLine           )
{
    ULONG ulMemSize = NumberOfBytes + k_GUARD_BYTE_SIZE ;
    // Is everything initialized?
    if ( FALSE == InternalInitialized ( ) )
    {
        return ( ExAllocatePool ( PoolType , NumberOfBytes ) ) ;
    }

    // Always do the allocation first.
    PVOID pRet = ExAllocatePool ( PoolType , ulMemSize ) ;

    // Stuff the memory into the list.
    pRet = PutMemInList ( pRet            ,
                          NumberOfBytes   ,
                          eExAllocatePool ,
                          (ULONG)PoolType ,
                          szFile          ,
                          uLine            ) ;
    return ( pRet ) ;
}

PVOID Track_ExAllocatePoolWithQuota ( IN POOL_TYPE  PoolType       ,
                                      IN ULONG      NumberOfBytes  ,
                                      char *        szFile         ,
                                      ULONG         uLine           )
{
    ULONG ulMemSize = NumberOfBytes + k_GUARD_BYTE_SIZE ;
    // Is everything initialized?
    if ( FALSE == InternalInitialized ( ) )
    {
        return ( ExAllocatePoolWithQuota ( PoolType , NumberOfBytes ) );
    }

    // Always do the allocation first.
    PVOID pRet = ExAllocatePoolWithQuota ( PoolType , ulMemSize ) ;

    // Stuff the memory into the list.
    pRet = PutMemInList ( pRet                      ,
                          NumberOfBytes             ,
                          eExAllocatePoolWithQuota  ,
                          (ULONG)PoolType           ,
                          szFile                    ,
                          uLine                      ) ;
    return ( pRet ) ;
}

PVOID Track_ExAllocatePoolWithTag ( IN POOL_TYPE PoolType      ,
                                    IN ULONG     NumberOfBytes ,
                                    IN ULONG     Tag           ,
                                    char *       szFile        ,
                                    ULONG        uLine          )

{
    ULONG ulMemSize = NumberOfBytes + k_GUARD_BYTE_SIZE ;

    // Is everything initialized?
    if ( FALSE == InternalInitialized ( ) )
    {
        return ( ExAllocatePoolWithTag( PoolType      ,
                                        NumberOfBytes ,
                                        Tag            ) ) ;
    }

    PVOID pRet = ExAllocatePoolWithTag ( PoolType , ulMemSize , Tag ) ;

    // Stuff the memory into the list.
    pRet = PutMemInList ( pRet                   ,
                          NumberOfBytes          ,
                          eExAllocatePoolWithTag ,
                          (ULONG)PoolType        ,
                          szFile                 ,
                          uLine                   ) ;
    return ( pRet ) ;
}

PVOID Track_ExAllocatePoolWithQuotaTag ( IN POOL_TYPE PoolType      ,
                                         IN ULONG     NumberOfBytes ,
                                         IN ULONG     Tag           ,
                                         char *       szFile        ,
                                         ULONG        uLine          )

{
    ULONG ulMemSize = NumberOfBytes + k_GUARD_BYTE_SIZE ;

    // Is everything initialized?
    if ( FALSE == InternalInitialized ( ) )
    {
        return ( ExAllocatePoolWithQuotaTag( PoolType      ,
                                             NumberOfBytes ,
                                             Tag            ) ) ;
    }

    PVOID pRet = ExAllocatePoolWithQuotaTag ( PoolType  ,
                                              ulMemSize ,
                                              Tag        ) ;

    // Stuff the memory into the list.
    pRet = PutMemInList ( pRet                        ,
                          NumberOfBytes               ,
                          eExAllocatePoolWithQuotaTag ,
                          (ULONG)PoolType             ,
                          szFile                      ,
                          uLine                        ) ;
    return ( pRet ) ;
}

VOID Track_ExFreePool ( IN PVOID P      ,
                        char *   szFile ,
                        ULONG    uLine   )

{
    if ( FALSE == InternalInitialized ( ) )
    {
        // Get rid of the memory here.
        ExFreePool ( P ) ;
        return ;
    }

    // Grab the spinlock so the information can be added to the list.
    KIRQL kOldIrql ;
    // The flag so that the finally block knows what to do with the
    //  memory.  If this is non-zero, that value will be passed to
    //  ExFreePool.
    PVOID pFreeVal ;
    __try
    {
        __try
        {
            InternalAcquireSpinLock ( &kOldIrql ) ;

            // Try and find the item.
            PTRACKALLOCATION pItem = InternalFindAllocation( (ULONG)P );

            if ( NULL == pItem )
            {
                // The memory could have been double freed so take a
                //  peak at the 4 bytes before it and see if they are
                //  the dead markers.
                PULONG pGB = (PULONG)GetRealMemStart ( P ) ;

                if ( k_FREED_GUARD_BYTES == *pGB )
                {
                    TRACE ( k_TRACK_ERROR ) ;
                    TRACE ( "Attempting to double free a piece of "
                            "memory from the following location\n" ) ;
                    TRACE ( "  Source : %s\n" , szFile ) ;
                    TRACE ( "  Line   : %d\n" , uLine  ) ;
                    TRACE ( k_TRACK_ERROR ) ;
                    ASSERTMSG ( "Double Free!" , FALSE ) ;
                    // Don't pass the memory on to the OS to free.  This
                    //  will cause a BSOD.
                    pFreeVal = NULL ;
                }
                else
                {
                    // The memory is not in the list and the freed mem
                    //  header is not on it, so I have to assume that
                    //  the memory has not been tracked.  I guess this
                    //  could also be an ASSERT, but a TRACE is good
                    //  enough.
                    TRACE ( k_TRACK_WARN ) ;
                    TRACE ( "ExFreePool called in %s, line %d with "
                            "memory that was not tracked\n" ,
                            szFile                          ,
                            uLine                            ) ;
                    TRACE ( k_TRACK_WARN ) ;
                    // Get rid of the memory.  If my assumtions are
                    //  wrong, the BSOD will let me know....
                    pFreeVal = P ;
                }
            }
            else
            {
                // Check that the memory is not corrupted.
                CheckMemForCorruption ( pItem , szFile , uLine ) ;

                // Update the stats.
                switch ( ( POOL_TYPE )pItem->ulFlags )
                {
                    case NonPagedPool                   :
                    case NonPagedPoolMustSucceed        :
                    case NonPagedPoolCacheAligned       :
                    case NonPagedPoolCacheAlignedMustS  :
                        g_MemStats.ulCurrPagedMem -= pItem->ulSize ;
                        break ;

                    case PagedPool              :
                    case PagedPoolCacheAligned  :
                        g_MemStats.ulCurrPagedMem -= pItem->ulSize ;
                        break ;

                    default :
                        TRACE ( k_TRACK_WARN ) ;
                        TRACE ( "Track Internal Problem: Unknown pool "
                                "type %d being deallocated \n" ,
                                pItem->ulFlags          ) ;
                        TRACE ( k_TRACK_WARN ) ;
                        break ;
                }

                // Check that this is memory that used an approriate
                //  allocator function for this deallocator.
                switch ( pItem->sID )
                {
                    // Valid functions which can call ExFreePool.
                    case eExAllocatePool            :
                    case eExAllocatePoolWithQuota   :
                    case eExAllocatePoolWithQuotaTag:
                    case eExAllocatePoolWithTag     :
                        // Get the real header and let the memory be
                        //  free!
                        pFreeVal=GetRealMemStart((PVOID)pItem->ulValue);
                        break ;

                    default :
                        TRACE ( k_TRACK_ERROR ) ;
                        TRACE ( "The object allocated in %s, line %d "
                                "cannot be freed with ExFreePool.\n" ) ;
                        TRACE ( k_TRACK_ERROR ) ;
                        pFreeVal = NULL ;
                        ASSERTMSG ( "Invalid free" , FALSE ) ;
                        break ;
                }

                // I am completely done with this item so get rid
                //  of it.
                InternalRemoveAllocation ( pItem ) ;

            }
        }
        __except ( EXCEPTION_EXECUTE_HANDLER )
        {
            ASSERTMSG ( "Track_ExFreePool had an access violation!\n"                        ,
                        FALSE                                        ) ;
        }
    }
    __finally
    {
        // Always release the spinlock.
        InternalReleaseSpinLock ( kOldIrql ) ;
        // The only place in the try..finally section where the memory
        //  is actually freed.
        if ( NULL != pFreeVal )
        {
            ExFreePool ( pFreeVal ) ;
        }
    }
}

PVOID Track_MmAllocateContiguousMemory ( IN ULONG       NumberOfBytes,
                                         IN PHYSICAL_ADDRESS
                                              HighestAcceptableAddress,
                                         char *         szFile        ,
                                         ULONG          uLine          )
{
    ULONG ulMemSize = NumberOfBytes + k_GUARD_BYTE_SIZE ;

    // Is everything initialized?
    if ( FALSE == InternalInitialized ( ) )
    {
        return ( MmAllocateContiguousMemory (NumberOfBytes ,
                                             HighestAcceptableAddress));
    }

    PVOID pRet = MmAllocateContiguousMemory ( ulMemSize ,
                                              HighestAcceptableAddress);

    // Stuff the memory into the list.
    pRet = PutMemInList ( pRet                        ,
                          NumberOfBytes               ,
                          eMmAllocateContiguousMemory ,
                          (ULONG)NonPagedPool         ,
                          szFile                      ,
                          uLine                        ) ;
    return ( pRet ) ;
}

PVOID Track_MmAllocateNonCachedMemory ( IN ULONG NumberOfBytes ,
                                        char *   szFile        ,
                                        ULONG   uLine           )
{
    ULONG ulMemSize = NumberOfBytes + k_GUARD_BYTE_SIZE ;

    // Is everything initialized?
    if ( FALSE == InternalInitialized ( ) )
    {
        return ( MmAllocateNonCachedMemory ( NumberOfBytes ) ) ;
    }

    PVOID pRet = MmAllocateNonCachedMemory ( ulMemSize ) ;

    // Stuff the memory into the list.
    pRet = PutMemInList ( pRet                       ,
                          NumberOfBytes              ,
                          eMmAllocateNonCachedMemory ,
                          (ULONG)PagedPool           ,
                          szFile                     ,
                          uLine                       ) ;
    return ( pRet ) ;
}

VOID Track_MmFreeContiguousMemory ( IN PVOID BaseAddress ,
                                    char *   szFile      ,
                                    ULONG    uLine        )

{
    if ( FALSE == InternalInitialized ( ) )
    {
        // Get rid of the memory here.
        MmFreeContiguousMemory ( BaseAddress ) ;
        return ;
    }

    // Grab the spinlock so the information can be added to the list.
    KIRQL kOldIrql ;
    // The flag so that the finally block knows what to do with the
    //  memory.  If this is non-zero, that value will be passed to
    //  MmFreeContiguousMemory.
    PVOID pFreeVal ;
    __try
    {
        __try
        {
            InternalAcquireSpinLock ( &kOldIrql ) ;

            // Try and find the item.
            PTRACKALLOCATION pItem =
                           InternalFindAllocation( (ULONG)BaseAddress );

            if ( NULL == pItem )
            {
                // The memory could have been double freed so take a
                //  peak at the 4 bytes before it and see if they are
                //  the dead markers.
                PULONG pGB = (PULONG)GetRealMemStart ( BaseAddress ) ;

                if ( k_FREED_GUARD_BYTES == *pGB )
                {
                    TRACE ( k_TRACK_ERROR ) ;
                    TRACE ( "Attempting to double free a piece of "
                            "memory from the following location\n" ) ;
                    TRACE ( "  Source : %s\n" , szFile ) ;
                    TRACE ( "  Line   : %d\n" , uLine  ) ;
                    TRACE ( k_TRACK_ERROR ) ;
                    ASSERTMSG ( "Double Free!" , FALSE ) ;
                    // Don't pass the memory on to the OS to free.  This
                    //  will cause a BSOD.
                    pFreeVal = NULL ;
                }
                else
                {
                    // The memory is not in the list and the freed mem
                    //  header is not on it, so I have to assume that
                    //  the memory has not been tracked.  I guess this
                    //  could also be an ASSERT, but a TRACE is good
                    //  enough.
                    TRACE ( k_TRACK_WARN ) ;
                    TRACE ( "MmFreeContiguousMemory called in %s, "
                            "line %d with memory that was not "
                            "tracked\n" ,
                            szFile                          ,
                            uLine                            ) ;
                    TRACE ( k_TRACK_WARN ) ;
                    // Get rid of the memory.  If my assumtions are
                    //  wrong, the BSOD will let me know....
                    pFreeVal = BaseAddress ;
                }
            }
            else
            {
                // Check that the memory is not corrupted.
                CheckMemForCorruption ( pItem , szFile , uLine ) ;

                // Update the stats.
                switch ( ( POOL_TYPE )pItem->ulFlags )
                {
                    case NonPagedPool                   :
                        g_MemStats.ulCurrPagedMem -= pItem->ulSize ;
                        break ;

                    case PagedPool              :
                        g_MemStats.ulCurrPagedMem -= pItem->ulSize ;
                        break ;

                    default :
                        TRACE ( k_TRACK_WARN ) ;
                        TRACE ( "Track Internal Problem: Unknown pool "
                                "type %d being deallocated \n" ,
                                pItem->ulFlags          ) ;
                        TRACE ( k_TRACK_WARN ) ;
                        break ;
                }

                // Check that this is memory that used an approriate
                //  allocator function for this deallocator.
                if ( eMmAllocateContiguousMemory == pItem->sID )
                {
                    // Get the real header and let the memory be
                    //  free!
                    pFreeVal=GetRealMemStart((PVOID)pItem->ulValue);
                }
                else
                {
                    TRACE ( k_TRACK_ERROR ) ;
                    TRACE ( "The object allocated in %s, line %d "
                            "cannot be freed with "
                            "MmFreeContiguousMemory.\n" ) ;
                    TRACE ( k_TRACK_ERROR ) ;
                    pFreeVal = NULL ;
                    ASSERTMSG ( "Invalid free" , FALSE ) ;
                }

                // I am completely done with this item so get rid
                //  of it.
                InternalRemoveAllocation ( pItem ) ;

            }
        }
        __except ( EXCEPTION_EXECUTE_HANDLER )
        {
            ASSERTMSG ( "Track_MmFreeContiguousMemory had an access "
                        "violation!\n" ,
                        FALSE            ) ;
        }
    }
    __finally
    {
        // Always release the spinlock.
        InternalReleaseSpinLock ( kOldIrql ) ;
        // The only place in the try..finally section where the memory
        //  is actually freed.
        if ( NULL != pFreeVal )
        {
            MmFreeContiguousMemory ( pFreeVal ) ;
        }
    }
}

VOID Track_MmFreeNonCachedMemory ( IN PVOID  BaseAddress   ,
                                   IN ULONG  NumberOfBytes ,
                                   char *    szFile        ,
                                   ULONG     uLine          )

{
    if ( FALSE == InternalInitialized ( ) )
    {
        // Get rid of the memory here.
        MmFreeNonCachedMemory ( BaseAddress , NumberOfBytes ) ;
        return ;
    }

    // Grab the spinlock so the information can be added to the list.
    KIRQL kOldIrql ;
    // The flag so that the finally block knows what to do with the
    //  memory.  If this is non-zero, that value will be passed to
    //  MmFreeNonCachedMemory.
    PVOID pFreeVal ;
    __try
    {
        __try
        {
            InternalAcquireSpinLock ( &kOldIrql ) ;

            // Try and find the item.
            PTRACKALLOCATION pItem =
                           InternalFindAllocation( (ULONG)BaseAddress );

            if ( NULL == pItem )
            {
                // The memory could have been double freed so take a
                //  peak at the 4 bytes before it and see if they are
                //  the dead markers.
                PULONG pGB = (PULONG)GetRealMemStart ( BaseAddress ) ;

                if ( k_FREED_GUARD_BYTES == *pGB )
                {
                    TRACE ( k_TRACK_ERROR ) ;
                    TRACE ( "Attempting to double free a piece of "
                            "memory from the following location\n" ) ;
                    TRACE ( "  Source : %s\n" , szFile ) ;
                    TRACE ( "  Line   : %d\n" , uLine  ) ;
                    TRACE ( k_TRACK_ERROR ) ;
                    ASSERTMSG ( "Double Free!" , FALSE ) ;
                    // Don't pass the memory on to the OS to free.  This
                    //  will cause a BSOD.
                    pFreeVal = NULL ;
                }
                else
                {
                    // The memory is not in the list and the freed mem
                    //  header is not on it, so I have to assume that
                    //  the memory has not been tracked.  I guess this
                    //  could also be an ASSERT, but a TRACE is good
                    //  enough.
                    TRACE ( k_TRACK_WARN ) ;
                    TRACE ( "MmFreeNonCachedMemory called in %s, "
                            "line %d with memory that was not "
                            "tracked\n" ,
                            szFile                          ,
                            uLine                            ) ;
                    TRACE ( k_TRACK_WARN ) ;
                    // Get rid of the memory.  If my assumtions are
                    //  wrong, the BSOD will let me know....
                    pFreeVal = BaseAddress ;
                }
            }
            else
            {
                // Check that the memory is not corrupted.
                CheckMemForCorruption ( pItem , szFile , uLine ) ;

                // Update the stats.
                g_MemStats.ulCurrPagedMem -= pItem->ulSize ;

                // Check that this is memory that used an approriate
                //  allocator function for this deallocator.
                if ( eMmAllocateNonCachedMemory == pItem->sID )
                {
                    // Get the real header and let the memory be
                    //  free!
                    pFreeVal=GetRealMemStart((PVOID)pItem->ulValue);
                }
                else
                {
                    TRACE ( k_TRACK_ERROR ) ;
                    TRACE ( "The object allocated in %s, line %d "
                            "cannot be freed with "
                            "MmFreeNonCachedMemory.\n" ) ;
                    TRACE ( k_TRACK_ERROR ) ;
                    pFreeVal = NULL ;
                    ASSERTMSG ( "Invalid free" , FALSE ) ;
                }

                // I am completely done with this item so get rid
                //  of it.
                InternalRemoveAllocation ( pItem ) ;
            }
        }
        __except ( EXCEPTION_EXECUTE_HANDLER )
        {
            ASSERTMSG ( "Track_MmFreeNonCachedMemory had an access "
                        "violation!\n" ,
                        FALSE            ) ;
        }
    }
    __finally
    {
        // Always release the spinlock.
        InternalReleaseSpinLock ( kOldIrql ) ;
        // The only place in the try..finally section where the memory
        //  is actually freed.
        if ( NULL != pFreeVal )
        {
            MmFreeNonCachedMemory ( pFreeVal , NumberOfBytes ) ;
        }
    }
}


// This file is only active if TRACK is defined.
#endif

