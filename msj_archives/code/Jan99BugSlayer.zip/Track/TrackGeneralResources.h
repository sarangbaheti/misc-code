/*----------------------------------------------------------------------
   John Robbins - Jan '99 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
    This header works on all those functions that are general resources
such as IoCreateDevice and IoDeleteDevice.
----------------------------------------------------------------------*/

#ifndef _TRACKGENERALRESOURCES_H
#define _TRACKGENERALRESOURCES_H

/*//////////////////////////////////////////////////////////////////////
                    File Scope Defines and Constants
//////////////////////////////////////////////////////////////////////*/

void TrackGeneralResourcesInitialize ( void ) ;

void TrackGeneralResourcesClose ( void ) ;

void TrackGeneralResourcesStats ( void ) ;

void TrackGeneralResourcesReportLeak ( PTRACKALLOCATION pItem ) ;

#endif  //_TRACKGENERALRESOURCES_H


