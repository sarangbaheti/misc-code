/*----------------------------------------------------------------------
   John Robbins - Jan '99 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
Common headers and warning manipulations.
----------------------------------------------------------------------*/
/* Nonstandard extension : nameless struct/union */
#pragma warning ( disable : 4201 )

/* Unreferenced in inline function removed */
#pragma warning ( disable : 4514 )

/* conditional expression is constant */
#pragma warning ( disable : 4127 )

/* default constructor could not be generated */
#pragma warning ( disable : 4510 )

extern "C" {
#include <ntddk.h>
#include <stdarg.h>
#include <stdio.h>
}

#include <DrvDiagnostics.h>

// Include my cool diagnostic helpers.
#include "DrvDiagnostics.h"

/* Nonstandard extension : nameless struct/union */
#pragma warning ( default : 4201 )

/* Unreferenced in inline function removed */
/*#pragma warning ( default : 4514 )*/

/* conditional expression is constant */
/*#pragma warning ( default : 4127 )*/

/* default constructor could not be generated */
#pragma warning ( default : 4510 )

/* struct '' can never be instantiated - user defined constructor */
/* required */
#pragma warning ( default : 4610 )

/* unreferenced local function has been removed */
#pragma warning ( default : 4505 )



