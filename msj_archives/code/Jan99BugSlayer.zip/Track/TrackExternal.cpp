/*----------------------------------------------------------------------
   John Robbins - Jan '99 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
    The implementation of the external API, minus wrapper functions, for
the TRACK system.  Generally, the functions just call the main internal
functions.
----------------------------------------------------------------------*/

#include "PCH.h"
#include "Track.h"
#include "TrackInternal.h"

// This file is only active if TRACK is defined.
#ifdef TRACK

/*//////////////////////////////////////////////////////////////////////
                 File Scope Structures and Enumerations
//////////////////////////////////////////////////////////////////////*/

/*//////////////////////////////////////////////////////////////////////
                    File Scope Defines and Constants
//////////////////////////////////////////////////////////////////////*/

/*//////////////////////////////////////////////////////////////////////
                         File Scope Prototypes
//////////////////////////////////////////////////////////////////////*/

/*//////////////////////////////////////////////////////////////////////
                           File Scope Globals
//////////////////////////////////////////////////////////////////////*/

/*//////////////////////////////////////////////////////////////////////
                       Implementation Starts Here
//////////////////////////////////////////////////////////////////////*/

// The initialization function for the whole Track subsystem.
NTSTATUS TrackInitialize ( void )
{
    // This function can only be run at PASSIVE_LEVEL.
    ASSERTIRQL ( PASSIVE_LEVEL ) ;

    BOOLEAN bInit = FALSE ;
    __try
    {

        // Initialize all the different subsystem classes.
        if ( STATUS_SUCCESS == InternalInitializeStorage ( ) )
        {
            bInit = TRUE ;
        }

    }
    __except ( EXCEPTION_EXECUTE_HANDLER )
    {
        ASSERTMSG ( "TrackInitialize had an access violation!\n" ,
                    FALSE                                         ) ;
        // This sure did not initialize.
        bInit = FALSE ;
    }

    if ( TRUE == bInit )
    {
        return ( STATUS_SUCCESS ) ;
    }
    else
    {
        return ( STATUS_ACCESS_VIOLATION ) ;
    }
}

// To get the current statistics that Track has, call this function.
NTSTATUS TrackStats ( void )
{
    return ( InternalReportStats ( ) ) ;
}

// The function that can be called to dump all currently allocated
//  items to DbgPrint.
NTSTATUS TrackDumpAllocated ( void )
{
    if ( FALSE == InternalInitialized ( ) )
    {
        return ( STATUS_UNSUCCESSFUL ) ;
    }

    // Now grab the spin lock.
    KIRQL kOldIrql ;
    InternalAcquireSpinLock ( &kOldIrql ) ;

    NTSTATUS ntRet = InternalReportLeaks ( ) ;

    InternalReleaseSpinLock ( kOldIrql ) ;

    // Show the final stats.
    TrackStats ( ) ;

    return ( ntRet ) ;
}

// BIG NOTE:
//  Notice that the spinlock is not acquired here.  It is up to you
//  to call this function when your driver is not actively messing with
//  memory.  If you acquire the spinlock in this function, then it
//  cannot access paged pool memory because the IRQL is raised to
//  DISPATCH_LEVEL.  Remember your IRQLs when accessing memory!
// However, this is still probably fairly safe as the only time you
//  generally should call this function is through a special IOCTL for
//  your driver.
NTSTATUS TrackValidateAllocated ( void )
{
    // This function can only be run at PASSIVE_LEVEL.
    ASSERTIRQL ( PASSIVE_LEVEL ) ;
    if ( PASSIVE_LEVEL != KeGetCurrentIrql ( ) )
    {
        TRACE ( "TrackValidateAllocated() can only be called at"
                " PASSIVE_LEVEL\n" ) ;
        return ( STATUS_UNSUCCESSFUL ) ;

    }

    if ( FALSE == InternalInitialized ( ) )
    {
        return ( STATUS_UNSUCCESSFUL ) ;
    }

    TRACE ( "Starting to validate allocations.  This could crash if"
            "your driver\nattempts to allocate/free resources"
            "while validating.\n" ) ;
    NTSTATUS ntRet = InternalValidateAllocated ( ) ;
    TRACE ( "All allocations validated.\n" ) ;

    return ( ntRet ) ;
}

// The close function.  If this is not called, then the Track subsystem
//  will leak memory!
NTSTATUS TrackClose ( void )
{
    // This function can only be run at PASSIVE_LEVEL.
    ASSERTIRQL ( PASSIVE_LEVEL ) ;

    // Is life initialized?
    if ( FALSE == InternalInitialized ( ) )
    {
        return ( STATUS_UNSUCCESSFUL ) ;
    }

    // Show any allocation leaks.
    TrackDumpAllocated ( ) ;

    return ( InternalCloseStorage ( ) ) ;
}

// This file is only active if TRACK is defined.
#endif

