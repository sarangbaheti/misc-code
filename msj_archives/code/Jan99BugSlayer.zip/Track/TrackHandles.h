/*----------------------------------------------------------------------
   John Robbins - Jan '99 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
    This is the header file for those APIs that create and remove
handles, i.e., IoCreateNotificationEvent and ZwClose.  This is used
internally to the TRACK project so you don't need to include it in your
main project.
----------------------------------------------------------------------*/

#ifndef _TRACKHANDLES_H
#define _TRACKHANDLES_H

void TrackHandlesInitialize ( void ) ;

void TrackHandlesClose ( void ) ;

void TrackHandlesStats ( void ) ;

void TrackHandlesReportLeak ( PTRACKALLOCATION pItem ) ;

#endif  //_TRACKHANDLES_H


