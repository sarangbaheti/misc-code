/*----------------------------------------------------------------------
   John Robbins - Jan '99 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
    This header works on all those functions that are general resources
such as IoCreateDevice and IoDeleteDevice.
----------------------------------------------------------------------*/

#include "PCH.h"
#include "Track.h"
#include "TrackInternal.h"

// This file is only active if TRACK is defined.
#ifdef TRACK

/*//////////////////////////////////////////////////////////////////////
                 File Scope Structures and Enumerations
//////////////////////////////////////////////////////////////////////*/
// The eFunc enumeration identified the function that did an allocation
//   of some sort.
typedef enum tag_eGeneralResourcesFunc
{
    eOutOfRange = 0 ,

    eIoCreateDevice ,
    eIoDeleteDevice ,

    eRtlAnsiStringToUnicodeString ,
    eRtlFreeUnicodeString ,

    eRtlUnicodeStringToAnsiString ,
    eRtlFreeAnsiString ,

    eMmMapIoSpace ,
    eMmUnmapIoSpace ,

    eIoAllocateMdl ,
    eIoBuildPartialMdl ,
    eIoFreeMdl ,

    eMmMapLockedPages ,
    eMmUnmapLockedPages ,

    eMaxRange
} eGeneralResourcesFunc ;

typedef struct TAG_GENERALRESOURCESSTATS
{
    ULONG ulTotalCalls ;
} GENERALRESOURCESSTATS , * PGENERALRESOURCESSTATS ;
/*//////////////////////////////////////////////////////////////////////
                    File Scope Defines and Constants
//////////////////////////////////////////////////////////////////////*/

/*//////////////////////////////////////////////////////////////////////
                         File Scope Prototypes
//////////////////////////////////////////////////////////////////////*/

/*//////////////////////////////////////////////////////////////////////
                           File Scope Globals
//////////////////////////////////////////////////////////////////////*/
static GENERALRESOURCESSTATS g_GeneralResourcesStats ;

static char * g_szFuncNames[ ] =
{
    "**OutOfRange**" ,

    "IoCreateDevice" ,
    "IoDeleteDevice" ,

    "RtlAnsiStringToUnicodeString" ,
    "RtlFreeUnicodeString" ,

    "RtlUnicodeStringToAnsiString" ,
    "RtlFreeAnsiString" ,

    "MmMapIoSpace" ,
    "MmUnmapIoSpace" ,

    "IoAllocateMdl" ,
    "IoBuildPartialMdl" ,
    "IoFreeMdl" ,

    "MmMapLockedPages" ,
    "MmUnmapLockedPages" ,

    "**eMaxRange**"

} ;

/*//////////////////////////////////////////////////////////////////////
                       Implementation Starts Here
//////////////////////////////////////////////////////////////////////*/

void TrackGeneralResourcesInitialize ( void )
{
    RtlFillMemory ( &g_GeneralResourcesStats         ,
                    sizeof ( GENERALRESOURCESSTATS ) ,
                    0                                ) ;
}

void TrackGeneralResourcesClose ( void )
{
}

void TrackGeneralResourcesStats ( void )
{
    TRACE ( "***********************************\n" ) ;
    TRACE ( "Track General Resources Statistics*\n" ) ;
    TRACE ( "***********************************\n" ) ;
    TRACE ( "  Total Alloc Calls     : %u\n" ,
            g_GeneralResourcesStats.ulTotalCalls ) ;
}

void TrackGeneralResourcesReportLeak ( PTRACKALLOCATION pItem )
{
    ASSERT ( TRUE == MmIsAddressValid ( pItem ) ) ;
    TRACE ( "AllocatorFn : %s\n" , g_szFuncNames[ pItem->sID ] ) ;
    TRACE ( "   Source   : %s\n" , pItem->szSource ) ;
    TRACE ( "   Line     : %d\n" , pItem->lLine ) ;
}

PTRACKALLOCATION
        FindGeneralResourcesRecord ( eGeneralResourcesFunc eFunc   ,
                                     ULONG                 ulValue ,
                                     char *                szFile  ,
                                     ULONG                 uLine    )
{
    PTRACKALLOCATION pRet = InternalFindAllocation( ulValue );
    if ( NULL == pRet )
    {
        // Whoops, show the warning!
        TRACE ( k_TRACK_WARN ) ;
        TRACE ( "%s was called in %s, line %d with "
                "a resource that was not tracked\n" ,
                g_szFuncNames[ eFunc ]              ,
                szFile                              ,
                uLine                                ) ;
        TRACE ( k_TRACK_WARN ) ;
    }
    return ( pRet ) ;
}

/*//////////////////////////////////////////////////////////////////////
                          Wrappers Start Here
//////////////////////////////////////////////////////////////////////*/

NTSTATUS Track_IoCreateDevice ( IN PDRIVER_OBJECT  DriverObject,
                                IN ULONG  DeviceExtensionSize,
                                IN PUNICODE_STRING  DeviceName,
                                IN DEVICE_TYPE  DeviceType,
                                IN ULONG  DeviceCharacteristics,
                                IN BOOLEAN  Exclusive,
                                OUT PDEVICE_OBJECT  *DeviceObject,
                                char * szFile,
                                ULONG  uLine )
{
    // Make the call no matter what.
    NTSTATUS ntRet = IoCreateDevice ( DriverObject,
                                      DeviceExtensionSize,
                                      DeviceName,
                                      DeviceType,
                                      DeviceCharacteristics,
                                      Exclusive,
                                      DeviceObject ) ;
    if ( ( TRUE == InternalInitialized ( ) ) &&
         ( NT_SUCCESS ( ntRet )            )    )
    {
        // Add away.
        InternalAddSimpleAlloction ( TRACKCLASS_GENERALRESOURCES  ,
                                     eIoCreateDevice              ,
                                     (ULONG)*DeviceObject         ,
                                     szFile                       ,
                                     uLine                         ) ;
        g_GeneralResourcesStats.ulTotalCalls++ ;
    }
    return ( ntRet ) ;
}

VOID Track_IoDeleteDevice ( IN PDEVICE_OBJECT DeviceObject ,
                            char *            szFile       ,
                            ULONG             uLine         )
{
    if ( FALSE == InternalInitialized ( ) )
    {
        IoDeleteDevice ( DeviceObject ) ;
        return ;
    }

    ASSERT ( TRUE == MmIsAddressValid ( DeviceObject ) ) ;
    // Grab the spinlock so the information can be added to the list.
    KIRQL kOldIrql ;
    // A boolean that tells me if I can IoDeleteDevice.
    BOOLEAN bCallFunction = TRUE ;
    __try
    {
        __try
        {
            InternalAcquireSpinLock ( &kOldIrql ) ;

            PTRACKALLOCATION pTemp =
                    FindGeneralResourcesRecord ( eIoDeleteDevice     ,
                                                 (ULONG)DeviceObject ,
                                                 szFile              ,
                                                 uLine               );
            if ( NULL != pTemp )
            {
                // Is this from the matching allocator?
                if ( eIoCreateDevice != pTemp->sID )
                {
                    // Got a little problem.
                    TRACE ( k_TRACK_ERROR ) ;
                    TRACE ( "The object created in %s, line %d "
                            "cannot be deleted with "
                            "IoDeleteDevice.\n" ) ;
                    TRACE ( k_TRACK_ERROR ) ;
                    ASSERTMSG ( "Invalid delete" , FALSE ) ;
                    bCallFunction = FALSE ;
                }
                else
                {
                    bCallFunction = TRUE ;
                    InternalRemoveAllocation ( pTemp ) ;
                }
            }
            else
            {
                bCallFunction = FALSE ;
            }
        }
        __except ( EXCEPTION_EXECUTE_HANDLER )
        {
            ASSERTMSG ( "Track_IoDeleteDevice had an access "
                        "violation!\n"                       ,
                        FALSE                                 ) ;
        }
    }
    __finally
    {
        // Always release the spinlock and drop the IRQL so that I can
        //  calll IoDeleteObject.
        InternalReleaseSpinLock ( kOldIrql ) ;
        if ( TRUE == bCallFunction )
        {
            IoDeleteDevice ( DeviceObject ) ;
        }
    }
}


NTSTATUS Track_RtlAnsiStringToUnicodeString (
                              IN OUT PUNICODE_STRING  DestinationString,
                              IN PANSI_STRING  SourceString,
                              IN BOOLEAN  AllocateDestinationString,
                              char * szFile,
                              ULONG  uLine  )
{
    // Make the call no matter what.
    NTSTATUS ntRet = RtlAnsiStringToUnicodeString ( DestinationString,
                                                    SourceString,
                                             AllocateDestinationString);
    if ( ( TRUE == InternalInitialized ( ) ) &&
         ( NT_SUCCESS ( ntRet )            )    )
    {
        // Only track this if the AllocateDestinationString is true.
        if ( TRUE == AllocateDestinationString )
        {
            // Add away.
            InternalAddSimpleAlloction ( TRACKCLASS_GENERALRESOURCES   ,
                                         eRtlAnsiStringToUnicodeString ,
                                      (ULONG)DestinationString->Buffer ,
                                         szFile                        ,
                                         uLine                        );
            g_GeneralResourcesStats.ulTotalCalls++ ;
        }
    }
    return ( ntRet ) ;
}

VOID Track_RtlFreeUnicodeString ( IN IN PUNICODE_STRING  UnicodeString ,
                                  char *                 szFile        ,
                                  ULONG                  uLine         )
{
    if ( FALSE == InternalInitialized ( ) )
    {
        RtlFreeUnicodeString ( UnicodeString ) ;
        return ;
    }

    ASSERT ( TRUE == MmIsAddressValid ( UnicodeString ) ) ;
    // Grab the spinlock so the information can be added to the list.
    KIRQL kOldIrql ;
    // A boolean that tells me if I can RtlFreeAnsiString.
    BOOLEAN bCallFunction = TRUE ;
    __try
    {
        __try
        {
            InternalAcquireSpinLock ( &kOldIrql ) ;

            PTRACKALLOCATION pTemp =
            FindGeneralResourcesRecord ( eRtlFreeUnicodeString        ,
                                         (ULONG)UnicodeString->Buffer ,
                                         szFile                       ,
                                         uLine                        );
            if ( NULL != pTemp )
            {
                // Is this from the matching allocator?
                if ( eRtlAnsiStringToUnicodeString != pTemp->sID )
                {
                    // Got a little problem.
                    TRACE ( k_TRACK_ERROR ) ;
                    TRACE ( "The object created in %s, line %d "
                            "cannot be deleted with "
                            "RtlFreeUnicodeString.\n" ) ;
                    TRACE ( k_TRACK_ERROR ) ;
                    ASSERTMSG ( "Invalid delete" , FALSE ) ;
                    bCallFunction = FALSE ;
                }
                else
                {
                    bCallFunction = TRUE ;
                    InternalRemoveAllocation ( pTemp ) ;
                }
            }
            else
            {
                bCallFunction = FALSE ;
            }
        }
        __except ( EXCEPTION_EXECUTE_HANDLER )
        {
            ASSERTMSG ( "Track_RtlFreeUnicodeString had an access "
                        "violation!\n"                       ,
                        FALSE                                 ) ;
        }
    }
    __finally
    {
        // Always release the spinlock and drop the IRQL so that I can
        //  call RtlFreeUnicodeString.
        InternalReleaseSpinLock ( kOldIrql ) ;
        if ( TRUE == bCallFunction )
        {
            RtlFreeUnicodeString ( UnicodeString ) ;
        }
    }
}

NTSTATUS Track_RtlUnicodeStringToAnsiString (
                                 IN OUT PANSI_STRING  DestinationString,
                                 IN PUNICODE_STRING  SourceString,
                                 IN BOOLEAN  AllocateDestinationString,
                                 char * szFile,
                                 ULONG  uLine  )
{
    // Make the call no matter what.
    NTSTATUS ntRet = RtlUnicodeStringToAnsiString ( DestinationString,
                                                    SourceString,
                                             AllocateDestinationString);
    if ( ( TRUE == InternalInitialized ( ) ) &&
         ( NT_SUCCESS ( ntRet )            )    )
    {
        // Only track this if the AllocateDestinationString is true.
        if ( TRUE == AllocateDestinationString )
        {
            // Add away.
            InternalAddSimpleAlloction ( TRACKCLASS_GENERALRESOURCES   ,
                                         eRtlUnicodeStringToAnsiString ,
                                      (ULONG)DestinationString->Buffer ,
                                         szFile                        ,
                                         uLine                        );
            g_GeneralResourcesStats.ulTotalCalls++ ;
        }
    }
    return ( ntRet ) ;
}

VOID Track_RtlFreeAnsiString ( IN IN PANSI_STRING  AnsiString ,
                               char *              szFile     ,
                               ULONG               uLine       )
{
    if ( FALSE == InternalInitialized ( ) )
    {
        RtlFreeAnsiString ( AnsiString ) ;
        return ;
    }

    ASSERT ( TRUE == MmIsAddressValid ( AnsiString ) ) ;
    // Grab the spinlock so the information can be added to the list.
    KIRQL kOldIrql ;
    // A boolean that tells me if I can RtlFreeAnsiString.
    BOOLEAN bCallFunction = TRUE ;
    __try
    {
        __try
        {
            InternalAcquireSpinLock ( &kOldIrql ) ;

            PTRACKALLOCATION pTemp =
              FindGeneralResourcesRecord ( eRtlFreeAnsiString        ,
                                           (ULONG)AnsiString->Buffer ,
                                           szFile                    ,
                                           uLine                      );
            if ( NULL != pTemp )
            {
                // Is this from the matching allocator?
                if ( eRtlUnicodeStringToAnsiString != pTemp->sID )
                {
                    // Got a little problem.
                    TRACE ( k_TRACK_ERROR ) ;
                    TRACE ( "The object created in %s, line %d "
                            "cannot be deleted with "
                            "RtlFreeAnsiString.\n" ) ;
                    TRACE ( k_TRACK_ERROR ) ;
                    ASSERTMSG ( "Invalid delete" , FALSE ) ;
                    bCallFunction = FALSE ;
                }
                else
                {
                    bCallFunction = TRUE ;
                    InternalRemoveAllocation ( pTemp ) ;
                }
            }
            else
            {
                bCallFunction = FALSE ;
            }
        }
        __except ( EXCEPTION_EXECUTE_HANDLER )
        {
            ASSERTMSG ( "Track_RtlFreeAnsiString had an access "
                        "violation!\n"                       ,
                        FALSE                                 ) ;
        }
    }
    __finally
    {
        // Always release the spinlock and drop the IRQL so that I can
        //  call RtlFreeAnsiString.
        InternalReleaseSpinLock ( kOldIrql ) ;
        if ( TRUE == bCallFunction )
        {
            RtlFreeAnsiString ( AnsiString ) ;
        }
    }
}


PVOID Track_MmMapIoSpace ( IN PHYSICAL_ADDRESS  PhysicalAddress,
                           IN ULONG  NumberOfBytes,
                           IN MEMORY_CACHING_TYPE CacheType,
                           char * szFile,
                           ULONG  uLine  )
{
    // Make the call no matter what.
    PVOID pRet = MmMapIoSpace ( PhysicalAddress ,
                                NumberOfBytes   ,
                                CacheType        ) ;
    if ( ( TRUE == InternalInitialized ( ) ) &&
         ( NULL != pRet                    )    )
    {
        // Add away.
        InternalAddSimpleAlloction ( TRACKCLASS_GENERALRESOURCES  ,
                                     eMmMapIoSpace        ,
                                     (ULONG)pRet          ,
                                     szFile               ,
                                     uLine                 ) ;
        g_GeneralResourcesStats.ulTotalCalls++ ;
    }
    return ( pRet ) ;
}

VOID Track_MmUnmapIoSpace ( IN PVOID  BaseAddress,
                            IN ULONG  NumberOfBytes,
                            char * szFile,
                            ULONG uLine )
{
    if ( FALSE == InternalInitialized ( ) )
    {
        MmUnmapIoSpace ( BaseAddress , NumberOfBytes ) ;
        return ;
    }

    ASSERT ( TRUE == MmIsAddressValid ( BaseAddress ) ) ;
    // Grab the spinlock so the information can removed from the list.
    KIRQL kOldIrql ;
    // A boolean that tells me if I can MmUnmapIoSpace.
    BOOLEAN bCallFunction = TRUE ;
    __try
    {
        __try
        {
            InternalAcquireSpinLock ( &kOldIrql ) ;

            PTRACKALLOCATION pTemp =
                    FindGeneralResourcesRecord ( eMmUnmapIoSpace    ,
                                                 (ULONG)BaseAddress ,
                                                 szFile             ,
                                                 uLine               ) ;
            if ( NULL != pTemp )
            {
                // Is this from the matching allocator?
                if ( eMmMapIoSpace != pTemp->sID )
                {
                    // Got a little problem.
                    TRACE ( k_TRACK_ERROR ) ;
                    TRACE ( "The object created in %s, line %d "
                            "cannot be deleted with "
                            "MmUnmapIoSpace.\n" ) ;
                    TRACE ( k_TRACK_ERROR ) ;
                    ASSERTMSG ( "Invalid delete" , FALSE ) ;
                    bCallFunction = FALSE ;
                }
                else
                {
                    bCallFunction = TRUE ;
                    InternalRemoveAllocation ( pTemp ) ;
                }
            }
            else
            {
                bCallFunction = FALSE ;
            }
        }
        __except ( EXCEPTION_EXECUTE_HANDLER )
        {
            ASSERTMSG ( "Track_MmUnmapIoSpace had an access "
                        "violation!\n"                       ,
                        FALSE                                 ) ;
        }
    }
    __finally
    {
        // Always release the spinlock and drop the IRQL so that I can
        //  calll MmUnmapIoSpace.
        InternalReleaseSpinLock ( kOldIrql ) ;
        if ( TRUE == bCallFunction )
        {
            MmUnmapIoSpace ( BaseAddress , NumberOfBytes ) ;
        }
    }
}


PMDL Track_IoAllocateMdl ( IN PVOID  VirtualAddress,
                           IN ULONG  Length,
                           IN BOOLEAN  SecondaryBuffer,
                           IN BOOLEAN  ChargeQuota,
                           IN OUT PIRP  Irp,
                           char * szFile,
                           ULONG uLine )

{
    // Make the call no matter what.
    PMDL pRet = IoAllocateMdl ( VirtualAddress  ,
                                Length          ,
                                SecondaryBuffer ,
                                ChargeQuota     ,
                                Irp              ) ;
    if ( ( TRUE == InternalInitialized ( ) ) &&
         ( NULL != pRet                    )    )
    {
        // Add away.
        InternalAddSimpleAlloction ( TRACKCLASS_GENERALRESOURCES  ,
                                     eIoAllocateMdl               ,
                                     (ULONG)pRet                  ,
                                     szFile                       ,
                                     uLine                         ) ;
        g_GeneralResourcesStats.ulTotalCalls++ ;
    }
    return ( pRet ) ;
}


// Can this function fail??
VOID Track_IoBuildPartialMdl ( IN PMDL  SourceMdl,
                               IN OUT PMDL  TargetMdl,
                               IN PVOID  VirtualAddress,
                               IN ULONG  Length,
                               char * szFile,
                               ULONG uLine )

{
    // Make the call no matter what.
    IoBuildPartialMdl ( SourceMdl       ,
                        TargetMdl       ,
                        VirtualAddress  ,
                        Length           ) ;
    if ( TRUE == InternalInitialized ( ) )
    {
        // Add away.
        InternalAddSimpleAlloction ( TRACKCLASS_GENERALRESOURCES  ,
                                     eIoBuildPartialMdl           ,
                                     (ULONG)TargetMdl             ,
                                     szFile                       ,
                                     uLine                         ) ;
        g_GeneralResourcesStats.ulTotalCalls++ ;
    }
}

VOID Track_IoFreeMdl ( IN PMDL Mdl,
                       char * szFile,
                       ULONG uLine )

{
    if ( FALSE == InternalInitialized ( ) )
    {
        IoFreeMdl ( Mdl ) ;
        return ;
    }

    ASSERT ( TRUE == MmIsAddressValid ( Mdl ) ) ;
    // Grab the spinlock so the information can removed from the list.
    KIRQL kOldIrql ;
    // A boolean that tells me if I can IoFreeMdl.
    BOOLEAN bCallFunction = TRUE ;
    __try
    {
        __try
        {
            InternalAcquireSpinLock ( &kOldIrql ) ;

            PTRACKALLOCATION pTemp =
                    FindGeneralResourcesRecord ( eIoFreeMdl ,
                                                 (ULONG)Mdl ,
                                                 szFile     ,
                                                 uLine       ) ;
            if ( NULL != pTemp )
            {
                // Is this from the matching allocators?
                if ( ( eIoAllocateMdl     != pTemp->sID ) ||
                     ( eIoBuildPartialMdl != pTemp->sID )   )
                {
                    // Got a little problem.
                    TRACE ( k_TRACK_ERROR ) ;
                    TRACE ( "The object created in %s, line %d "
                            "cannot be deleted with "
                            "IoFreeMdl.\n" ) ;
                    TRACE ( k_TRACK_ERROR ) ;
                    ASSERTMSG ( "Invalid delete" , FALSE ) ;
                    bCallFunction = FALSE ;
                }
                else
                {
                    bCallFunction = TRUE ;
                    InternalRemoveAllocation ( pTemp ) ;
                }
            }
            else
            {
                bCallFunction = FALSE ;
            }
        }
        __except ( EXCEPTION_EXECUTE_HANDLER )
        {
            ASSERTMSG ( "Track_IoFreeMdl had an access violation!\n" ,
                        FALSE                                        ) ;
        }
    }
    __finally
    {
        // Always release the spinlock and drop the IRQL so that I can
        //  call IoFreeMdl.
        InternalReleaseSpinLock ( kOldIrql ) ;
        if ( TRUE == bCallFunction )
        {
            IoFreeMdl ( Mdl ) ;
        }
    }
}

PVOID Track_MmMapLockedPages ( IN PMDL  MemoryDescriptorList,
                               IN KPROCESSOR_MODE  AccessMode,
                               char * szFile,
                               ULONG uLine )
{
    // Make the call no matter what.
    PVOID pRet = MmMapLockedPages ( MemoryDescriptorList , AccessMode );

    if ( ( TRUE == InternalInitialized ( ) ) &&
         ( NULL != pRet                    )    )
    {
        // Add away.
        InternalAddSimpleAlloction ( TRACKCLASS_GENERALRESOURCES  ,
                                     eMmMapLockedPages            ,
                                     (ULONG)pRet                  ,
                                     szFile                       ,
                                     uLine                         ) ;
        g_GeneralResourcesStats.ulTotalCalls++ ;
    }
    return ( pRet ) ;
}


VOID Track_MmUnmapLockedPages ( IN PVOID  BaseAddress,
                                IN PMDL  MemoryDescriptorList,
                                char * szFile,
                                ULONG uLine )
{
    if ( FALSE == InternalInitialized ( ) )
    {
        MmUnmapLockedPages ( BaseAddress , MemoryDescriptorList ) ;
        return ;
    }

    // Grab the spinlock so the information can removed from the list.
    KIRQL kOldIrql ;
    // A boolean that tells me if I can MmUnmapIoSpace.
    BOOLEAN bCallFunction = TRUE ;
    __try
    {
        __try
        {
            InternalAcquireSpinLock ( &kOldIrql ) ;

            PTRACKALLOCATION pTemp =
                    FindGeneralResourcesRecord ( eMmUnmapLockedPages ,
                                                 (ULONG)BaseAddress  ,
                                                 szFile              ,
                                                 uLine                );
            if ( NULL != pTemp )
            {
                // Is this from the matching allocator?
                if ( eMmMapLockedPages != pTemp->sID )
                {
                    // Got a little problem.
                    TRACE ( k_TRACK_ERROR ) ;
                    TRACE ( "The object created in %s, line %d "
                            "cannot be deleted with "
                            "MmUnmapLockedPages.\n" ) ;
                    TRACE ( k_TRACK_ERROR ) ;
                    ASSERTMSG ( "Invalid delete" , FALSE ) ;
                    bCallFunction = FALSE ;
                }
                else
                {
                    bCallFunction = TRUE ;
                    InternalRemoveAllocation ( pTemp ) ;
                }
            }
            else
            {
                bCallFunction = FALSE ;
            }
        }
        __except ( EXCEPTION_EXECUTE_HANDLER )
        {
            ASSERTMSG ( "Track_MmUnmapLockedPages had an access "
                        "violation!\n"                           ,
                        FALSE                                     ) ;
        }
    }
    __finally
    {
        // Always release the spinlock and drop the IRQL so that I can
        //  call MmUnmapLockedPages.
        InternalReleaseSpinLock ( kOldIrql ) ;
        if ( TRUE == bCallFunction )
        {
            MmUnmapLockedPages ( BaseAddress , MemoryDescriptorList ) ;
        }
    }
}

// This file is only active if TRACK is defined.
#endif

