/*----------------------------------------------------------------------
   John Robbins - Jan '99 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
    The public header file for the Track memory and resource monitoring
system for kernel mode device drivers.
Usage:
    0.  Define "TRACK" in your SOURCES file with
        C_DEFINES=$(C_DEFINES) /DTRACK in checked builds only.
    1.  Set up to link TRACK.LIB with the checked build of your driver
        in your SOURCES file.
        TARGETLIBS=$(TARGETPATH)\*\$(DDKBUILDENV)\Track.lib
    2.  At the earliest point in your driver initialization routine make
        a call to the TRACK initialization function, TRACKINITIALIZE().
        As late as possible, like in your unload function, call
        TRACKCLOSE().
    3.  Instead of using a memory or resource API directly, use the
        macros in here instead.  For example, ExAllocatePool becomes
        TrackExAllocatePool.
    4.  All output goes to the kernel debugger.  Additionally, when
        needed, TRACK will pop an ASSERT so watch for them as well.
    5.  If you want to validate allocation corruptions, you can use the
        TRACKVALIDATEALLOCATED() function.  However, you should only
        call it from a special IOCTL in your driver dispatch routine.
    6.  Just for the record, the Track library uses the DrvDiagnostics.h
        header file.

    This is the first version of this library and not all of the
memory and resouce functions are monitored.  However, almost all the
common ones are.  If you add others, and if you are so inclined, send
me the source at www.jprobbins.com and I will post it for others.
----------------------------------------------------------------------*/

#ifndef _TRACK_H
#define _TRACK_H

#ifdef __cplusplus
extern "C" {
#endif

// Track only works with _DEBUG builds.  Even if TRACK is defined, I
//  will undefine it here.  Yes, this looks like a weird way to 
//  check a define.  Unfortunately, NDEBUG (the free build compilation
//  flag) is defined for both free and checked builds.
#if !(DBG==1)
#ifdef TRACK
#undef TRACK
#endif
#endif

// To turn on the tracking system, define TRACK in your SOURCES file.
#ifdef TRACK

/*//////////////////////////////////////////////////////////////////////
                    Core Track Function Declarations
//////////////////////////////////////////////////////////////////////*/

/*----------------------------------------------------------------------
FUNCTION    :   TrackInitialize - Use the TRACKINITIALIZE() macro.
DISCUSSION  :
    Initializes the whole track subsystem.  This must be called before
any other function and should be called at the top of your DriverEntry
function.
PARAMETERS  :
    None.
RETURNS     :
    STATUS_SUCCESSFUL        - Life is good.
    STATUS_ACCESS_VIOLATION  - There was an access violation during
                               initialization.
IRQL        :   PASSIVE_LEVEL
----------------------------------------------------------------------*/
NTSTATUS TrackInitialize ( void ) ;

/*----------------------------------------------------------------------
FUNCTION    :   TrackClose - Use the TRACKCLOSE() macro.
DISCUSSION  :
    Closes down the whole track system.  If this is not called and your
driver unloads, you will leak all the memory used by the track system.
    This should be called either in your driver's unload routine or in
the shutdown routine.
PARAMETERS  :
    None.
RETURNS     :
    STATUS_SUCCESSFUL   - Life is good.
IRQL        :   PASSIVE_LEVEL
----------------------------------------------------------------------*/
NTSTATUS TrackClose ( void ) ;

/*----------------------------------------------------------------------
FUNCTION    :   TrackDumpAllocated - Use the TRACKDUMPALLOCATED() macro.
DISCUSSION  :
    Runs through and dumps all currently allocated items.  In essense,
this is the same thing as reporting leaks at the end, but it allows you
to see the currently outstanding allocations at any time.
PARAMETERS  :
    None.
RETURNS     :
    STATUS_SUCCESSFUL       - Life is good.
    STATUS_UNSUCCESSFUL     - The track library is not initialized.
    STATUS_ACCESS_VIOLATION - There was an access violation.  (The
                              machine will probably crash before you
                              get this error.
IRQL        : <= DISPATCH_LEVEL
----------------------------------------------------------------------*/
NTSTATUS TrackDumpAllocated ( void ) ;

/*----------------------------------------------------------------------
FUNCTION    :   TrackValidateAllocated - Use the
                                          TRACKVALIDATEALLOCATED() macro
DISCUSSION  :
    Validates memory blocks for corruption, i.e., underwrites and
overwrites.
    Be very careful calling this function as the track library cannot
use its internal synchronization mechanism to protect this call.  If
the spinlock is used, the IRQL jumps to DISPATCH_LEVEL, which means that
paged pool memory cannot be accessed, thus minimalizing the
effectiveness of the whole function.  The track library itself does not
call this function because of this.  It is up to you to make the call.
    The way to use this is to set up a special IOCTL that your user mode
applications call to make sure this function is called at PASSIVE_LEVEL.
Of course, you should only call your special IRQL when your driver is
not actively allocating and deallocating memory!
PARAMETERS  :
RETURNS     :
    STATUS_SUCCESSFUL       - Life is good.
    STATUS_UNSUCCESSFUL     - The library is not initialized.
    STATUS_ACCESS_VIOLATION - There was an access violation during the
                              processing.
IRQL        :   PASSIVE_LEVEL
----------------------------------------------------------------------*/
NTSTATUS TrackValidateAllocated ( void ) ;

/*----------------------------------------------------------------------
FUNCTION    :   TrackStats - Use the TRACKSTATS() macro.
DISCUSSION  :
    Reports the stats on numbers of allocations and bytes of memory
allocated.
PARAMETERS  :
    None.
RETURNS     :
    STATUS_SUCCESSFUL   - Life is good.
    STATUS_UNSUCCESSFUL - The library is not initialized.
IRQL        :   Any
----------------------------------------------------------------------*/
NTSTATUS TrackStats ( void ) ;

/*//////////////////////////////////////////////////////////////////////
                  Track Wrapper Function Declarations
//////////////////////////////////////////////////////////////////////*/
////////////////////////////////////////////////////////////////////////
// Core memory tracking functions.
////////////////////////////////////////////////////////////////////////
PVOID Track_ExAllocatePool ( IN POOL_TYPE  PoolType       ,
                             IN ULONG      NumberOfBytes  ,
                             char *        szFile         ,
                             ULONG         uLine           ) ;
PVOID Track_ExAllocatePoolWithTag ( IN POOL_TYPE PoolType      ,
                                    IN ULONG     NumberOfBytes ,
                                    IN ULONG     Tag           ,
                                    char *       szFile        ,
                                    ULONG        uLine          ) ;
PVOID Track_ExAllocatePoolWithQuota ( IN POOL_TYPE  PoolType       ,
                                      IN ULONG      NumberOfBytes  ,
                                      char *        szFile         ,
                                      ULONG         uLine           ) ;
PVOID Track_ExAllocatePoolWithQuotaTag ( IN POOL_TYPE PoolType      ,
                                         IN ULONG     NumberOfBytes ,
                                         IN ULONG     Tag           ,
                                         char *       szFile        ,
                                         ULONG        uLine          ) ;
VOID Track_ExFreePool ( IN PVOID P      ,
                        char *   szFile ,
                        ULONG    uLine   ) ;

PVOID Track_MmAllocateContiguousMemory ( IN ULONG       NumberOfBytes,
                                         IN PHYSICAL_ADDRESS
                                              HighestAcceptableAddress,
                                         char *         szFile        ,
                                         ULONG          uLine         );
PVOID Track_MmAllocateNonCachedMemory ( IN ULONG NumberOfBytes ,
                                        char *   szFile        ,
                                        ULONG   uLine           ) ;
VOID Track_MmFreeContiguousMemory ( IN PVOID BaseAddress ,
                                    char *   szFile      ,
                                    ULONG    uLine        ) ;

VOID Track_MmFreeNonCachedMemory ( IN PVOID  BaseAddress   ,
                                   IN ULONG  NumberOfBytes ,
                                   char *    szFile      ,
                                   ULONG     uLine        ) ;

////////////////////////////////////////////////////////////////////////
// General Resource Allocators.
////////////////////////////////////////////////////////////////////////
NTSTATUS Track_IoCreateDevice ( IN PDRIVER_OBJECT  DriverObject,
                                IN ULONG  DeviceExtensionSize,
                                IN PUNICODE_STRING  DeviceName,
                                IN DEVICE_TYPE  DeviceType,
                                IN ULONG  DeviceCharacteristics,
                                IN BOOLEAN  Exclusive,
                                OUT PDEVICE_OBJECT  *DeviceObject,
                                char * szFile,
                                ULONG  uLine ) ;

VOID Track_IoDeleteDevice ( IN PDEVICE_OBJECT DeviceObject ,
                            char *            szFile       ,
                            ULONG             uLine         ) ;

NTSTATUS Track_RtlAnsiStringToUnicodeString (
                            IN OUT PUNICODE_STRING  DestinationString,
                            IN PANSI_STRING  SourceString,
                            IN BOOLEAN  AllocateDestinationString,
                            char * szFile,
                            ULONG  uLine  ) ;

VOID Track_RtlFreeUnicodeString ( IN PUNICODE_STRING  UnicodeString ,
                                  char *              szFile        ,
                                  ULONG               uLine          ) ;

NTSTATUS Track_RtlUnicodeStringToAnsiString (
                                 IN OUT PANSI_STRING  DestinationString,
                                 IN PUNICODE_STRING  SourceString,
                                 IN BOOLEAN  AllocateDestinationString,
                                 char * szFile,
                                 ULONG  uLine  ) ;

VOID Track_RtlFreeAnsiString ( IN IN PANSI_STRING  AnsiString ,
                               char *              szFile     ,
                               ULONG               uLine       ) ;

PVOID Track_MmMapIoSpace ( IN PHYSICAL_ADDRESS  PhysicalAddress,
                           IN ULONG  NumberOfBytes,
                           IN MEMORY_CACHING_TYPE CacheType,
                           char * szFile,
                           ULONG  uLine  ) ;

VOID  Track_MmUnmapIoSpace ( IN PVOID  BaseAddress,
                             IN ULONG  NumberOfBytes,
                             char * szFile,
                             ULONG uLine ) ;

PMDL Track_IoAllocateMdl ( IN PVOID  VirtualAddress,
                           IN ULONG  Length,
                           IN BOOLEAN  SecondaryBuffer,
                           IN BOOLEAN  ChargeQuota,
                           IN OUT PIRP  Irp ,
                           char * szFile,
                           ULONG uLine ) ;

VOID Track_IoBuildPartialMdl ( IN PMDL  SourceMdl,
                               IN OUT PMDL  TargetMdl,
                               IN PVOID  VirtualAddress,
                               IN ULONG  Length,
                               char * szFile,
                               ULONG uLine ) ;

VOID Track_IoFreeMdl ( IN PMDL Mdl ,
                       char * szFile,
                       ULONG uLine ) ;


PVOID Track_MmMapLockedPages ( IN PMDL  MemoryDescriptorList,
                               IN KPROCESSOR_MODE  AccessMode,
                               char * szFile,
                               ULONG uLine ) ;

VOID Track_MmUnmapLockedPages ( IN PVOID  BaseAddress,
                                IN PMDL  MemoryDescriptorList,
                                char * szFile,
                                ULONG uLine ) ;

////////////////////////////////////////////////////////////////////////
// Handle allocators.
////////////////////////////////////////////////////////////////////////
NTSTATUS Track_ZwClose ( IN HANDLE Handle ,
                         char *    szFile ,
                         ULONG     uLine   ) ;

PKEVENT Track_IoCreateNotificationEvent ( IN PUNICODE_STRING  EventName,
                                          OUT PHANDLE  EventHandle,
                                          char * szFile,
                                          ULONG  uLine  ) ;

PKEVENT Track_IoCreateSynchronizationEvent (
                                           IN PUNICODE_STRING EventName,
                                           OUT PHANDLE  EventHandle ,
                                           char * szFile ,
                                           ULONG  uLine ) ;

NTSTATUS Track_ZwCreateDirectoryObject (
                                OUT PHANDLE  DirectoryHandle,
                                IN ACCESS_MASK  DesiredAccess,
                                IN POBJECT_ATTRIBUTES  ObjectAttributes,
                                char * szFile ,
                                ULONG  uLine   ) ;

NTSTATUS Track_ZwCreateFile ( OUT PHANDLE FileHandle,
                              IN ACCESS_MASK DesiredAccess,
                              IN POBJECT_ATTRIBUTES ObjectAttributes,
                              OUT PIO_STATUS_BLOCK IoStatusBlock,
                              IN PLARGE_INTEGER AllocationSize,
                              IN ULONG FileAttributes,
                              IN ULONG ShareAccess,
                              IN ULONG CreateDisposition,
                              IN ULONG CreateOptions,
                              IN PVOID EaBuffer,
                              IN ULONG EaLength,
                              char * szFile ,
                              ULONG  uLine   ) ;

NTSTATUS Track_ZwOpenKey ( OUT PHANDLE  KeyHandle,
                           IN ACCESS_MASK  DesiredAccess,
                           IN POBJECT_ATTRIBUTES  ObjectAttributes,
                           char * szFile ,
                           ULONG  uLine   ) ;

NTSTATUS Track_ZwOpenSection ( OUT PHANDLE  SectionHandle,
                               IN ACCESS_MASK  DesiredAccess,
                               IN POBJECT_ATTRIBUTES  ObjectAttributes,
                               char * szFile ,
                               ULONG  uLine ) ;

/*//////////////////////////////////////////////////////////////////////
                        Track Macro Definitions
//////////////////////////////////////////////////////////////////////*/
// The macros to use to the core track functions

#define TRACKINITIALIZE()           TrackInitialize ( )
#define TRACKDUMPALLOCATED()        TrackDumpAllocated ( )
#define TRACKVALIDATEALLOCATED()    TrackValidateAllocated ( )
#define TRACKSTATS()                TrackStats ( )
#define TRACKCLOSE()                TrackClose ( )

////////////////////////////////////////////////////////////////////////
// The wrapper function definitions
////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////
// Core memory tracking functions.
////////////////////////////////////////////////////////////////////////
#define TrackExAllocatePool(x,y)                                    \
                Track_ExAllocatePool ( x           ,                \
                                       y           ,                \
                                       __FILE__    ,                \
                                       __LINE__     )

#define TrackExAllocatePoolWithTag(x,y,z)                           \
                Track_ExAllocatePoolWithTag ( x         ,           \
                                              y         ,           \
                                              z         ,           \
                                              __FILE__  ,           \
                                              __LINE__   )

#define TrackExAllocatePoolWithQuota(x,y)                           \
                Track_ExAllocatePoolWithQuota ( x           ,       \
                                                y           ,       \
                                                __FILE__    ,       \
                                                __LINE__     )

#define TrackExAllocatePoolWithQuotaTag(x,y,z)                      \
                Track_ExAllocatePoolWithQuotaTag ( x         ,      \
                                                   y         ,      \
                                                   z         ,      \
                                                   __FILE__  ,      \
                                                   __LINE__   )

#define TrackExFreePool(x) Track_ExFreePool ( x , __FILE__ , __LINE__ )

#define TrackMmAllocateContiguousMemory(x,y)                        \
                Track_MmAllocateContiguousMemory ( x          ,     \
                                                   y          ,     \
                                                   __FILE__   ,     \
                                                   __LINE__    )
#define TrackMmAllocateNonCachedMemory(x)                           \
                Track_MmAllocateNonCachedMemory ( x           ,     \
                                                  __FILE__    ,     \
                                                  __LINE__     )
#define TrackMmFreeContiguousMemory(x)                              \
                Track_MmFreeContiguousMemory ( x          ,         \
                                               __FILE__   ,         \
                                               __LINE__    )
#define TrackMmFreeNonCachedMemory(x,y)                             \
                Track_MmFreeNonCachedMemory ( x        ,            \
                                              y        ,            \
                                              __FILE__ ,            \
                                              __LINE__  )

////////////////////////////////////////////////////////////////////////
// // General Resource Allocators.
////////////////////////////////////////////////////////////////////////

#define TrackIoCreateDevice(a,b,c,d,e,f,g)                          \
                Track_IoCreateDevice ( a        ,                   \
                                       b        ,                   \
                                       c        ,                   \
                                       d        ,                   \
                                       e        ,                   \
                                       f        ,                   \
                                       g        ,                   \
                                       __FILE__ ,                   \
                                       __LINE__  )

#define TrackIoDeleteDevice(x)                                      \
                Track_IoDeleteDevice ( x        ,                   \
                                       __FILE__ ,                   \
                                       __LINE__  )

#define TrackRtlAnsiStringToUnicodeString(x,y,z)                    \
                Track_RtlAnsiStringToUnicodeString ( x          ,   \
                                                     y          ,   \
                                                     z          ,   \
                                                     __FILE__   ,   \
                                                     __LINE__ )

#define TrackRtlFreeUnicodeString(x)                                \
                Track_RtlFreeUnicodeString ( x          ,           \
                                             __FILE__   ,           \
                                             __LINE__    )

#define TrackRtlUnicodeStringToAnsiString(x,y,z)                    \
                Track_RtlUnicodeStringToAnsiString ( x          ,   \
                                                     y          ,   \
                                                     z          ,   \
                                                     __FILE__   ,   \
                                                     __LINE__ )

#define TrackRtlFreeAnsiString(x)                                   \
                Track_RtlFreeAnsiString ( x          ,              \
                                          __FILE__   ,              \
                                          __LINE__    )

#define TrackMmMapIoSpace(x,y,z)                                    \
                Track_MmMapIoSpace ( x        ,                     \
                                     y        ,                     \
                                     z        ,                     \
                                     __FILE__ ,                     \
                                     __LINE__  )

#define TrackMmUnmapIoSpace(x,y)                                    \
                Track_MmUnmapIoSpace ( x        ,                   \
                                       y        ,                   \
                                       __FILE__ ,                   \
                                       __LINE__  )

#define TrackIoAllocateMdl(a,b,c,d,e)                               \
                Track_IoAllocateMdl ( a         ,                   \
                                      b         ,                   \
                                      c         ,                   \
                                      d         ,                   \
                                      e         ,                   \
                                      __FILE__  ,                   \
                                      __LINE__   ) ;

#define TrackIoBuildPartialMdl(a,b,c,d)                             \
                Track_IoBuildPartialMdl ( a         ,               \
                                          b         ,               \
                                          c         ,               \
                                          d         ,               \
                                          __FILE__  ,               \
                                          __LINE__   )

#define TrackIoFreeMdl(x)                                           \
                Track_IoFreeMdl ( x         ,                       \
                                  __FILE__  ,                       \
                                  __LINE__   )

#define TrackMmMapLockedPages(x,y)                                  \
                Track_MmMapLockedPages ( x          ,               \
                                         y          ,               \
                                         __FILE__   ,               \
                                         __LINE__    )

#define TrackMmUnmapLockedPages(x,y)                                \
                Track_MmUnmapLockedPages ( x          ,             \
                                           y          ,             \
                                           __FILE__   ,             \
                                           __LINE__    )

////////////////////////////////////////////////////////////////////////
// Handle allocators.
////////////////////////////////////////////////////////////////////////
#define TrackZwClose(x)                                             \
                Track_ZwClose ( x        ,                          \
                                __FILE__ ,                          \
                                __LINE__  )

#define TrackIoCreateNotificationEvent(x,y)                         \
                Track_IoCreateNotificationEvent ( x         ,       \
                                                  y         ,       \
                                                  __FILE__  ,       \
                                                  __LINE__   )

#define TrackIoCreateSynchronizationEvent(x,y)                      \
                Track_IoCreateSynchronizationEvent ( x ,            \
                                                     y ,            \
                                                     __FILE__ ,     \
                                                     __LINE__  )

#define TrackZwCreateDirectoryObject(x,y,z)                         \
                Track_ZwCreateDirectoryObject ( x       ,           \
                                                y       ,           \
                                                z       ,           \
                                                __FILE__,           \
                                                __LINE__ )

#define TrackZwCreateFile(a,b,c,d,e,f,g,h,i,j,k)                    \
                Track_ZwCreateFile ( a          ,                   \
                                     b          ,                   \
                                     c          ,                   \
                                     d          ,                   \
                                     e          ,                   \
                                     f          ,                   \
                                     g          ,                   \
                                     h          ,                   \
                                     i          ,                   \
                                     j          ,                   \
                                     k          ,                   \
                                     __FILE__   ,                   \
                                     __LINE__    )

#define TrackZwOpenKey(x,y,z)                                       \
                Track_ZwOpenKey ( x         ,                       \
                                  y         ,                       \
                                  z         ,                       \
                                  __FILE__  ,                       \
                                  __LINE__   )

#define TrackZwOpenSection(x,y,z)                                   \
                Track_ZwOpenSection ( x         ,                   \
                                      y         ,                   \
                                      z         ,                   \
                                      __FILE__  ,                   \
                                      __LINE__   )

////////////////////////////////////////////////////////////////////////
#else   // ! TRACK
////////////////////////////////////////////////////////////////////////

// Track is not defined so eat up any track system defines.
#define TRACKINITIALIZE()
#define TRACKDUMPALLOCATED()
#define TRACKVALIDATEALLOCATED()
#define TRACKCLOSE()
#define TRACKSTATS()

////////////////////////////////////////////////////////////////////////
// Core memory tracking functions.
////////////////////////////////////////////////////////////////////////
#define TrackExAllocatePool(x,y)                                    \
                ExAllocatePool(x,y)

#define TrackExAllocatePoolWithTag(x,y,z)                           \
                ExAllocatePoolWithTag(x,y,z)

#define TrackExAllocatePoolWithQuota(x,y)                           \
                ExAllocatePoolWithQuota(x,y)

#define TrackExAllocatePoolWithQuotaTag(x,y,z)                      \
                ExAllocatePoolWithQuotaTag(x,y,z)

#define TrackExFreePool(x)                                          \
                ExFreePool(x)

#define TrackMmAllocateContiguousMemory(x,y)                        \
                MmAllocateContiguousMemory ( x , y )

#define TrackMmAllocateNonCachedMemory(x)                           \
                MmAllocateNonCachedMemory ( x )

#define TrackMmFreeContiguousMemory(x)                              \
                MmFreeContiguousMemory ( x )

#define TrackMmFreeNonCachedMemory(x,y)                             \
                MmFreeNonCachedMemory ( x , y )

////////////////////////////////////////////////////////////////////////
// // General Resource Allocators.
////////////////////////////////////////////////////////////////////////

#define TrackIoCreateDevice(a,b,c,d,e,f,g)                          \
                IoCreateDevice ( a , b , c , d , e , f , g )

#define TrackIoDeleteDevice(x)                                      \
                IoDeleteDevice ( x )

#define TrackRtlAnsiStringToUnicodeString(x,y,z)                    \
                RtlAnsiStringToUnicodeString ( x , y , z )

#define TrackRtlFreeUnicodeString(x)                                \
                RtlFreeUnicodeString ( x )

#define TrackRtlUnicodeStringToAnsiString(x,y,z)                    \
                RtlUnicodeStringToAnsiString ( x , y , z )

#define TrackRtlFreeAnsiString(x)                                   \
                RtlFreeAnsiString ( x )

#define TrackMmMapIoSpace(x,y,z)                                    \
                MmMapIoSpace ( x , y , z )

#define TrackMmUnmapIoSpace(x,y)                                    \
                MmUnmapIoSpace ( x , y )

#define TrackIoAllocateMdl(a,b,c,d,e)                               \
                IoAllocateMdl ( a , b , c , d , e )

#define TrackIoBuildPartialMdl(a,b,c,d)                             \
                IoBuildPartialMdl ( a , b , c , d )

#define TrackIoFreeMdl(x)                                           \
                IoFreeMdl ( x )

#define TrackMmMapLockedPages(x,y)                                  \
                MmMapLockedPages ( x , y )

#define TrackMmUnmapLockedPages(x,y)                                \
                MmUnmapLockedPages ( x , y )

////////////////////////////////////////////////////////////////////////
// Handle allocators.
////////////////////////////////////////////////////////////////////////
#define TrackZwClose(x)                                             \
                ZwClose ( x )

#define TrackIoCreateNotificationEvent(x,y)                         \
                IoCreateNotificationEvent ( x , y )


#define TrackIoCreateSynchronizationEvent(x,y)                      \
                IoCreateSynchronizationEvent ( x , y )

#define TrackZwCreateDirectoryObject(x,y,z)                         \
                ZwCreateDirectoryObject ( x , y , z )

#define TrackZwCreateFile(a,b,c,d,e,f,g,h,i,j,k)                    \
                ZwCreateFile ( a          ,                   \
                               b          ,                   \
                               c          ,                   \
                               d          ,                   \
                               e          ,                   \
                               f          ,                   \
                               g          ,                   \
                               h          ,                   \
                               i          ,                   \
                               j          ,                   \
                               k           )

#define TrackZwOpenKey(x,y,z)                                       \
                ZwOpenKey ( x , y , z )

#define TrackZwOpenSection(x,y,z)                                   \
                ZwOpenSection ( x , y , z )

#endif  // TRACK

#ifdef __cplusplus
}
#endif

#endif  // _TRACK_H



