/*----------------------------------------------------------------------
   John Robbins - Jan '99 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
    This is the header file for those APIs that do memory allocations.
The TRACK system puts guard bytes on the front and end of all
allocations to protect against underwrites and overwrites.
Additionally, it fills in those guard bytes when the memory is deleted
to protect against double deletes.
----------------------------------------------------------------------*/

#ifndef _TRACKMEMORY_H
#define _TRACKMEMORY_H

/*//////////////////////////////////////////////////////////////////////
                    File Scope Defines and Constants
//////////////////////////////////////////////////////////////////////*/

void TrackMemoryInitialize ( void ) ;

void TrackMemoryClose ( void ) ;

void TrackMemoryStats ( void ) ;

NTSTATUS TrackMemoryCheckMem ( PTRACKALLOCATION pItem ) ;

void TrackMemoryReportLeak ( PTRACKALLOCATION pItem ) ;

#endif  //_TRACKMEMORY_H


