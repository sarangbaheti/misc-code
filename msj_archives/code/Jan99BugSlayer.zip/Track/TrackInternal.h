/*----------------------------------------------------------------------
   John Robbins - Jan '99 Microsoft Systems Journal Bugslayer Column
------------------------------------------------------------------------
    The main internal header file for the TRACK project.  This defines
most of the worker routines.  The actual memory and resource trackers
don't have to mess with the grunge of getting memory, handling storage,
and other fun things if they use the support routines.
    Please note that there is a spinlock associated with the internal
storage that your routines must grab in order to protect the internals.
See the function comments for which of those functions need to do this.
----------------------------------------------------------------------*/

#ifndef _TRACKINTERNAL_H
#define _TRACKINTERNAL_H

/*//////////////////////////////////////////////////////////////////////
                 Internal Track Classification Defines
//////////////////////////////////////////////////////////////////////*/
// These IDs are how the TrackDumpAllocated function will know which
//  system to call.

// Pure memory allocation functions, i.e., those that I can put guard
//  bytes on.  (ExAllocatePool, ExFreePool).
#define TRACKCLASS_MEMORY           1
// General resource functions, i.e., those that allocate things and have
//  special deallocators.  (IoCreateDevice, IoDeleteDevice).
#define TRACKCLASS_GENERALRESOURCES 2
// Handle based resource functions, i.e., those that require one to call
//  ZwClose to deallocate space for an item.
#define TRACKCLASS_HANDLES          3

/*//////////////////////////////////////////////////////////////////////
                         Internal Track Defines
//////////////////////////////////////////////////////////////////////*/
// Warning and error strings.
#define k_TRACK_ERROR "Track Error ****************\n"
#define k_TRACK_WARN  "Track Warning **************\n"

// This is not defined in the DDK or SDK.
#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif

/*//////////////////////////////////////////////////////////////////////
                       Internal Track Structures
//////////////////////////////////////////////////////////////////////*/
// The structure that is stored in the lookaside list.  This describes
//  a general allocation of something.
typedef struct tag_TRACKALLOCATION
{
    // The list entry structure so I can keep these in a linked list.
    LIST_ENTRY  stListEntry         ;
    // The classification ID.  See TRACKCLASS_* defines.
    SHORT       sClassID            ;
    // The field for the classes to use to ID this block.  Generally,
    //  this is the function ID.
    SHORT       sID                 ;
    // The first part of the source file where the allocation took
    //  place.
    char        szSource[ 40 ]      ;
    // The source line where the allocation took place.
    LONG        lLine               ;
    // The size of the allocation item, if applicable.
    ULONG       ulSize              ;
    // The value of the allocation.  This is for pointer values.  The
    //  memory here will never be referenced directly.
    ULONG       ulValue             ;
    // A flag field for general use.  Different sets of API trackers
    //  use this differently.
    ULONG       ulFlags             ;
} TRACKALLOCATION , * PTRACKALLOCATION ;

/*//////////////////////////////////////////////////////////////////////
                        Internal Track Functions
//////////////////////////////////////////////////////////////////////*/

/*----------------------------------------------------------------------
FUNCTION    :   InternalInitializeStorage
DISCUSSION  :
    Initializes the internal storage that track will use to hold all
allocations.  If the storage set up succeeds, this function also sets
the internal initialization state to TRUE.
    The internal spin lock does not need to be acquired to call this
function.
PARAMETERS  :
    None.
RETURNS     :
    STATUS_SUCCESSFUL   - Life is good.
    STATUS_UNSUCCESSFUL - There was a problem so initialization cannot
                          continue.
IRQL        :   PASSIVE_LEVEL
----------------------------------------------------------------------*/
NTSTATUS InternalInitializeStorage ( void ) ;

/*----------------------------------------------------------------------
FUNCTION    :   InternalCloseStorage
DISCUSSION  :
    Frees up storage allocated by InternalInitializeStorage.  This
function also marks the initialization state as FALSE.
    The internal spin lock does not need to be acquired to call this
function.
PARAMETERS  :
    None.
RETURNS     :
    STATUS_SUCCESSFUL   - Life is good.
IRQL        :   PASSIVE_LEVEL
----------------------------------------------------------------------*/
NTSTATUS InternalCloseStorage ( void ) ;

/*----------------------------------------------------------------------
FUNCTION    :   InternalInitialized
DISCUSSION  :
    Returns the initialization state.
PARAMETERS  :
    None.
RETURNS     :
    TRUE  - The internals are initialized.
    FALSE - The internals are not initialized.
IRQL        :   Any.
----------------------------------------------------------------------*/
BOOLEAN InternalInitialized ( void ) ;

/*----------------------------------------------------------------------
FUNCTION    :   InternalAllocateStorage
DISCUSSION  :
    Creates an uninitialized PTRACKALLOCATION structure.  This function
does NOT grab the internal spinlock.  The callers must have already
acquired it and must release it accordingly.
PARAMETERS  :
    None.
RETURNS     :
    NULL  - There was a problem.
    !NULL - The allocation succeeded.
IRQL        :   <= DISPATCH_LEVEL
----------------------------------------------------------------------*/
PTRACKALLOCATION InternalAllocateStorage ( void ) ;

/*----------------------------------------------------------------------
FUNCTION    :   InternalRemoveAllocation
DISCUSSION  :
    Removes the specified PTRACKALLOCATION from internal storage.  Once
this function is called, the pointer in pTrackAlloc cannot be accessed.
pTrackAlloc must have been initialized with InternalAllocateStorage.
    This function does NOT grab the internal spinlock.  The callers must
have already acquired it and must release it accordingly.
PARAMETERS  :
    pTraclAlloc - The allocation to remove and free.
RETURNS     :
    STATUS_SUCCESSFUL   - Life is good.
    STATUS_UNSUCCESSFUL - There was a problem.
IRQL        :   <= DISPATCH_LEVEL
----------------------------------------------------------------------*/
NTSTATUS InternalRemoveAllocation ( PTRACKALLOCATION pTrackAlloc ) ;

/*----------------------------------------------------------------------
FUNCTION    :   InternalAddAllocation
DISCUSSION  :
    Adds the specified PTRACKALLOCATION to the internal storage.  This
function does NOT grab the internal spinlock.  The callers must have
already acquired it and must release it accordingly.
PARAMETERS  :
    pTrackAlloc - The filled in allocation that was allocated by
                  InternalAllocateStorage.
RETURNS     :
    STATUS_SUCCESSFUL   - Life is good.
IRQL        :   Any
----------------------------------------------------------------------*/
NTSTATUS InternalAddAllocation ( PTRACKALLOCATION pTrackAlloc ) ;

/*----------------------------------------------------------------------
FUNCTION    :   InternalFindAllocation
DISCUSSION  :
    Finds the allocation in the internal storage.  If found, returns the
pointer to the complete TRACKALLOCATION structure.  This function does
NOT grab the internal spinlock.  The callers must have already acquired
it and must release it accordingly.
PARAMETERS  :
    ulValue - A value that was placed in the ulValue field when
              inserting into the internal storage.
RETURNS     :
    NULL  - The value was not found.
    !NULL - The value was found.
IRQL        :   Any.
----------------------------------------------------------------------*/
PTRACKALLOCATION InternalFindAllocation ( ULONG ulValue ) ;

/*----------------------------------------------------------------------
FUNCTION    :   InternalValidateAllocated
DISCUSSION  :
    Loops through the allocated blocks and if the allocated class can be
validated, it is.  This function does NOT grab the internal spinlock.
The callers must have already acquired it and must release it
accordingly.
PARAMETERS  :
    STATUS_SUCCESS      - All memory checked out.
    STATUS_UNSUCCESSFUL - Some memory is corrupted.
RETURNS     :
    None.
IRQL        :   <= DISPATCH_LEVEL
----------------------------------------------------------------------*/
NTSTATUS InternalValidateAllocated ( void ) ;

/*----------------------------------------------------------------------
FUNCTION    :   InternalAcquireSpinLock
DISCUSSION  :
    Gets the internal spin lock in order to protect the internal
storage.
PARAMETERS  :
    pIrql - Receives the current IRQL value.
RETURNS     :
    None.
IRQL        :   <= DISPATCH_LEVEL
----------------------------------------------------------------------*/
void InternalAcquireSpinLock ( PKIRQL pIrql ) ;

/*----------------------------------------------------------------------
FUNCTION    :   InternalReleaseSpinLock
DISCUSSION  :
    Releases the internal spin lock.
PARAMETERS  :
    kIrql - The IRQL before grabbing the spin lock.
RETURNS     :
    None.
IRQL        :   DISPATCH_LEVEL
----------------------------------------------------------------------*/
void InternalReleaseSpinLock ( KIRQL kIrql ) ;

/*----------------------------------------------------------------------
FUNCTION    :   InternalReportLeaks
DISCUSSION  :
    Calls all the internal class subsystem report functions on all
leaked allocations.
    The internal spin lock MUST be acquired to call this function.
PARAMETERS  :
    None.
RETURNS     :
    STATUS_SUCCESSFUL   - Life is good.
IRQL        :   <= DISPATCH_LEVEL
----------------------------------------------------------------------*/
NTSTATUS InternalReportLeaks ( void ) ;

/*----------------------------------------------------------------------
FUNCTION    :   InternalReportStats
DISCUSSION  :
    Calls all the internal class subsystem stat report functions.
    The internal spin lock MUST be acquired to call this function.
PARAMETERS  :
    None.
RETURNS     :
    STATUS_SUCCESSFUL   - Life is good.
IRQL        :   <= DISPATCH_LEVEL
----------------------------------------------------------------------*/
NTSTATUS InternalReportStats ( void ) ;

/*----------------------------------------------------------------------
FUNCTION    :   InternalAddSimpleAlloction
DISCUSSION  :
    Many of the allocator functions only need to fill out a couple of
the main fields in the TRACKALLOCATION.  This function takes care of all
the synchronization and adding simple allocations to the internal
storage.
PARAMETERS  :
    sClassID - The subsystem ID.  See the defines at the top of the
               file.
    sID      - The subsystem assigned ID.
    ulValue  - The allocator ID.
    szFile   - The source file doing the action.
    ulLine   - The line in the source file doing the action.
RETURNS     :
    STATUS_SUCCESSFUL   - Life is good.
IRQL        :   <= DISPATCH_LEVEL
----------------------------------------------------------------------*/
NTSTATUS InternalAddSimpleAlloction ( SHORT     sClassID ,
                                      SHORT     sID      ,
                                      ULONG     ulValue  ,
                                      char *    szFile   ,
                                      ULONG     ulLine    ) ;


#endif  // _TRACKINTERNAL_H


