//////////////////////////////////////////////////////////
// constants
//////////////////////////////////////////////////////////

const DWORD MAXTERMINALS            = 5;


#define WM_PRIVATETAPIEVENT         WM_USER+101


//////////////////////////////////////////////////////////
// PROTOTYPES
//////////////////////////////////////////////////////////

HRESULT
OnTapiEvent(
            TAPI_EVENT TapiEvent,
            IDispatch * pEvent
           );

void
HandleCallNotificationEvent( IDispatch * pEvent );

void
MakeWindowsVisible( ITCallStateEvent * pCallStateEvent );

void
HandleCallStateEvent( IDispatch * pEvent );

BOOL
CALLBACK
MainDialogProc(
               HWND hDlg,
               UINT uMsg,
               WPARAM wParam,
               LPARAM lParam
              );

HRESULT
RegisterTapiEventInterface();

HRESULT
ListenOnAddresses();

HRESULT
ListenOnThisAddress(
                    ITAddress * pAddress,
                    long * plRegistrations,
                    DWORD dwCount
                   );

HRESULT
AnswerTheCall();

HRESULT
DisconnectTheCall();

void
ReleaseTheCall();

void
DoMessage(
          LPWSTR pszMessage
         );

void
SetStatusMessage(
                 LPWSTR pszMessage
                );

HRESULT
InitializeTapi();

void
ShutdownTapi();

void
EnableButton(
             int ID
            );
void
DisableButton(
              int ID
             );

HRESULT
ResizeRegistration();
    
