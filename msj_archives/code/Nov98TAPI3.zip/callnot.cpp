//////////////////////////////////////////////////////////////////////
// callnot.cpp
//
// Implementation of the ITTAPIEventNotification interface.
//
// This is an outgoing interface that is defined by TAPI 3.0.  This
// is basically a callback function that TAPI 3.0 calls to inform
// the application of events related to calls (on a specific address)
//
// Please refer to COM documentation for information on outgoing
// interfaces.
// 
// An application must implement and register this interface in order
// to receive calls and events related to calls
//
//////////////////////////////////////////////////////////////////////


#include "windows.h"
#include "tapi3.h"
#include "incoming.h"
#include "callnot.h"
#include "resource.h"
#include "control.h"
#include "strmif.h"

extern ITBasicCallControl * gpCall;
extern HWND ghDlg;
extern BSTR gbstrVideo;



///////////////////////////////////////////////////////////////////
//
// CTAPIEventNotification::Event
//
// The only method in the ITCallEventNotification interface.  This gets
// called by TAPI 3.0 when there is a call event to report
//
// We don't do any processing here, just post a message to our
// main UI thread to handle this.  In general, an MTA application should
// do as little as possible on the thread that the callback
// is fired in
//
///////////////////////////////////////////////////////////////////
HRESULT
STDMETHODCALLTYPE
CTAPIEventNotification::Event(
                              TAPI_EVENT TapiEvent,
                              IDispatch * pEvent
                             )
{
    //
    // addref the event so it doesn't go away
    //
    pEvent->AddRef();

    //
    // post a message to ourself
    //
    PostMessage(
                ghDlg,
                WM_PRIVATETAPIEVENT,
                (WPARAM) TapiEvent,
                (LPARAM) pEvent
               );

    return S_OK;
}


///////////////////////////////////////////////////////////////////
//
// OnTapiEvent
//
// This is the real event handler.  This is called from our
// msg proc when the WM_PRIVATETAPIEVENT message is received
//
///////////////////////////////////////////////////////////////////
HRESULT
OnTapiEvent(
            TAPI_EVENT TapiEvent,
            IDispatch * pEvent
           )
{
    HRESULT hr;

    switch ( TapiEvent )
    {
        case TE_CALLNOTIFICATION:
        {
            HandleCallNotificationEvent( pEvent );
            
            break;
        }
        
        case TE_CALLSTATE:
        {
            HandleCallStateEvent( pEvent );

            break;
        }

        default:

            //
            // not handling other events
            //

            break;
            
    }


    //
    // make sure to release the event
    // we addref'd in in CTAPIEventNotification::Event()
    //
    pEvent->Release();
    
    return S_OK;
}


///////////////////////////////////////////////////////////////////
//
// HandleCallNotificationEvent
//
///////////////////////////////////////////////////////////////////
void HandleCallNotificationEvent( IDispatch * pEvent )
{
    ITCallNotificationEvent         * pNotify;
    CALL_NOTIFICATION_EVENT           cne;
    ITCallInfo                      * pCall;
    HRESULT                           hr;

    
    //
    // CET_CALLNOTIFICATION means that the application is being notified
    // of a new call.
    //
    // Note that we don't answer to call at this point.  The application
    // should wait for a CS_OFFERING CallState message before answering
    // the call.
    //
    
    //
    // get the correct interface on the event
    //
    hr = pEvent->QueryInterface(
                                IID_ITCallNotificationEvent,
                                (void **)&pNotify
                               );

    if (S_OK != hr)
    {
        DoMessage( L"Incoming call, but failed to get the event interface");

        return;
    }

    //
    // check to see if we own the call
    //
    pNotify->get_Event( &cne );

    if ( CNE_OWNER != cne )
    {
        return;
    }

    //
    // get the call
    //
    pNotify->get_Call( &pCall );

    //
    // save the BasicCallControl interface of this
    // call in the global
    //
    pCall->QueryInterface( IID_ITBasicCallControl, (void**)&gpCall );

    //
    // release our local reference
    //
    pCall->Release();

    //
    // release the event object
    //
    pNotify->Release();

    //
    // update UI
    //
    SetStatusMessage(L"New Owner Call");

    return;
}

///////////////////////////////////////////////////////////////////
//
// MakeWindowsVisible
//
///////////////////////////////////////////////////////////////////
void MakeWindowsVisible(
        ITCallStateEvent * pCallStateEvent
        )
{
    HRESULT                   hr;
    ITCallInfo              * pCallInfo = NULL;
    IEnumTerminal           * pEnumTerm = NULL;
    ITTerminal              * pTerminal = NULL;
    IVideoWindow            * pVideoWindow = NULL;

    //
    // Get the call this event is for
    //
    pCallStateEvent->get_Call( &pCallInfo );


    //
    // Get an enumerator for the terminals on the call
    //
    pCallInfo->EnumerateTerminalsInUse( &pEnumTerm );

    //
    // Look for the Video In terminal
    //
    while ( TRUE )
    {
        hr = pEnumTerm->Next( 1, &pTerminal, NULL );

        if ( S_OK != hr )
        {
            break;
        }
        
        //
        // See if this terminal supports the video window interface
        //
        hr = pTerminal->QueryInterface(
                                       IID_IVideoWindow,
                                       (void**)&pVideoWindow
                                      );

        if ( SUCCEEDED(hr) )
        {
            //
            // set windows to visible
            //
            pVideoWindow->put_Visible((long)-1);

            // Clean up
            pVideoWindow->Release();
        }
        else
        {
            //
            // of this is the video capture terminal
            // enable the preview window
            //
            ITPreviewConfig * pPreviewConfig;

            hr = pTerminal->QueryInterface(
                                           IID_ITPreviewConfig,
                                           (void**)&pPreviewConfig
                                          );

            if (SUCCEEDED(hr))
            {
                IDispatch * pDisp;
                
                hr = pPreviewConfig->get_PreviewInterface( &pDisp );

                if ( SUCCEEDED(hr) && (NULL != pDisp) )
                {
                    hr = pDisp->QueryInterface(
                                              IID_IVideoWindow,
                                              (void **)&pVideoWindow
                                             );

                    if (SUCCEEDED(hr))
                    {
                        pVideoWindow->put_Visible( VARIANT_TRUE );
                        pVideoWindow->Release();
                    }

                    pDisp->Release();
                                              
                }
                
                pPreviewConfig->Release();
            }
        }

            
        
        // Clean up
        pTerminal->Release();
    }

    //
    // Be sure to release all the interfaces we used
    //
    pEnumTerm->Release();
    pCallInfo->Release();
}

///////////////////////////////////////////////////////////////////
//
// HandleCallStateEvent
//
///////////////////////////////////////////////////////////////////
void HandleCallStateEvent( IDispatch * pEvent )
{

    CALL_STATE         cs;
    ITCallStateEvent * pCallStateEvent;

    //
    // Get the correct event interface
    //
    pEvent->QueryInterface( IID_ITCallStateEvent, (void **)&pCallStateEvent );

    //
    // get the CallState that we are being notified of.
    //
    pCallStateEvent->get_State( &cs );

    switch ( cs )
    {
        case CS_OFFERING:
            
            //
            // if it's offering, update our UI
            //
            EnableButton( IDC_ANSWER );
            DisableButton( IDC_DISCONNECT );
            
            SetStatusMessage(L"Click the Answer button");

            break;
            
        case CS_DISCONNECTED:

            //
            // the call is disconnected -
            // release it
            //
            ReleaseTheCall();

            //
            // update the UI
            //
            EnableButton( IDOK );
            DisableButton( IDC_DISCONNECT );

            SetStatusMessage(L"Waiting for a call...");

            break;

        case CS_CONNECTED:

            SetStatusMessage(L"Connected");

            MakeWindowsVisible( pCallStateEvent );

            break;

        default:

            //
            // not handling other call states
            //
            break;
    }


    //
    // Release the interface
    //
    pCallStateEvent->Release();

    return;
}

