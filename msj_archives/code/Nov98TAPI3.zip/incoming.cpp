#define UNICODE
#include <windows.h>
#include <tapi3.h>
#include "incoming.h"
#include "callnot.h"
#include "resource.h"

//////////////////////////////////////////////////////////
// T3IN.EXE
//
// Sample application that handling incoming TAPI calls.
// This application will register to recieve calls on
// all addresses that support at least audioin and audioout.
//
// NOTE:  This application is limited to working with one call at
// at time, and will not work correctly if multiple calls
// are present at the same time.
//////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
// GLOBALS
//////////////////////////////////////////////////////////

HINSTANCE                     ghInst;
HWND                          ghDlg = NULL;
ITTAPI                      * gpTapi;
ITBasicCallControl          * gpCall;
CTAPIEventNotification      * gpTAPIEventNotification = NULL;
ULONG                         gulAdvise;
long                        * gplRegistrationInstances = NULL;
DWORD                         gdwNumRegistrations = 10;

WCHAR gszTapi30[] = L"TAPI 3.0 Incoming Call Sample";

//////////////////////////////////////////////////////////
//
//              FUNCTIONS
//
//////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
// WinMain
//
//////////////////////////////////////////////////////////
int
WINAPI
WinMain(
        HINSTANCE hInst,
        HINSTANCE hPrevInst,
        LPSTR lpCmdLine,
        int nCmdShow
       )
{
    ghInst = hInst;

    
    //
    // need to coinit
    //
    if (!SUCCEEDED(CoInitializeEx(NULL, COINIT_MULTITHREADED)))
    {
        return 0;
    }

    //
    // do tapi initialization
    //
    if (S_OK != InitializeTapi())
    {
        return 0;
    }

    //
    // everything is initialized, so
    // start the main dialog box
    //
    DialogBox(
              ghInst,
              MAKEINTRESOURCE(IDD_MAINDLG),
              NULL,
              MainDialogProc
             );


    //
    // clean up
    //
    ShutdownTapi();
    
    CoUninitialize();

    return 1;
}


//////////////////////////////////////////////////////////////
//
// InitializeTapi
//
// Standard TAPI initialization
//
///////////////////////////////////////////////////////////////
HRESULT
InitializeTapi()
{
    HRESULT         hr;


    //
    // cocreate the TAPI object
    //
    hr = CoCreateInstance(
                          CLSID_TAPI,
                          NULL,
                          CLSCTX_INPROC_SERVER,
                          IID_ITTAPI,
                          (LPVOID *)&gpTapi
                         );

    if ( !SUCCEEDED(hr) )
    {
        DoMessage(L"CoCreateInstance on TAPI failed");
        return hr;
    }

    //
    // call initialize.  this must be called before
    // any other tapi functions are called.
    //
    hr = gpTapi->Initialize();

    if ( !SUCCEEDED(hr) )
    {
        DoMessage(L"TAPI failed to initialize");

        gpTapi->Release();
        gpTapi = NULL;
        
        return hr;
    }


    //
    // Register the event interface
    //
    hr = RegisterTapiEventInterface();

    if ( !SUCCEEDED(hr) )
    {
        ShutdownTapi();
        
        return hr;
    }
    
    //
    // find all address objects that
    // we will use to listen for calls on
    //
    hr = ListenOnAddresses();

    if ( !SUCCEEDED(hr) )
    {
        DoMessage(L"Could not find any addresses to listen on");

        ShutdownTapi();
        
        return hr;
    }

    return S_OK;

}


///////////////////////////////////////////////////////////////
//
// ShutdownTapi
//
///////////////////////////////////////////////////////////////
void
ShutdownTapi()
{
    //
    // if there is still a call,
    // release it
    //
    ReleaseTheCall();

    //
    // release main object.
    //
    if ( NULL != gpTapi )
    {
        IConnectionPointContainer           * pCPC;
        IConnectionPoint                    * pCP;
        DWORD                                 dwCount;


        //
        // unregister all of our call notifications
        //
        if ( NULL != gplRegistrationInstances )
        {
            for ( dwCount = 0; dwCount < gdwNumRegistrations; dwCount++ )
            {
                gpTapi->UnregisterNotifications( 
                    gplRegistrationInstances[dwCount]
                    );
            }

            LocalFree( gplRegistrationInstances );

            gplRegistrationInstances = NULL;
        }


        //
        // unadvise our connection point
        //
        gpTapi->QueryInterface(
                               IID_IConnectionPointContainer,
                               (void**) &pCPC
                              );

        pCPC->FindConnectionPoint(
                                  IID_ITTAPIEventNotification,
                                  &pCP
                                 );

        pCP->Unadvise( gulAdvise );

        pCPC->Release();
        pCP->Release();

        //
        // shutdown tapi
        //
        gpTapi->Shutdown();
        gpTapi->Release();
        gpTapi = NULL;
    }

}


///////////////////////////////////////////////////////////////////////////
//
// MainDlgProc
//
///////////////////////////////////////////////////////////////////////////
BOOL
CALLBACK
MainDialogProc(
               HWND hDlg,
               UINT uMsg,
               WPARAM wParam,
               LPARAM lParam
              )
{
    switch (uMsg)
    {
        case WM_INITDIALOG:
        {
            // set up dialog
            ghDlg = hDlg;
            
            DisableButton( IDC_ANSWER );
            DisableButton( IDC_DISCONNECT );

            SetStatusMessage( L"Waiting for a call..." );

            return 0;
        }

        case WM_COMMAND:
        {
            switch ( LOWORD(wParam) )
            {
                //
                // answer request
                //
                case IDCANCEL:
                {
                    // quit
                    EndDialog( hDlg, 0 );

                    return 1;
                }
                    
                case IDC_ANSWER:
                {
                    SetStatusMessage(L"Answering...");

                    //
                    // answer the call
                    //
                    if ( S_OK == AnswerTheCall() )
                    {
                        EnableButton( IDC_DISCONNECT );
                        DisableButton( IDC_ANSWER );
                    }
                    else
                    {
                        DisableButton( IDC_ANSWER );
                        DoMessage(L"Answer failed");
                        SetStatusMessage(L"Waiting for a call...");
                    }

                    return 1;
                }

                //
                // disconnect request
                //
                case IDC_DISCONNECT:
                {
                    SetStatusMessage(L"Disconnecting...");

                    //
                    // disconnect
                    //
                    if (S_OK != DisconnectTheCall())
                    {
                        DoMessage(L"Disconnect failed");
                    }

                    return 1;
                }

                default:

                    return 0;
            }

            //
            // this is where we handle any TAPI
            // events
            //
            case WM_PRIVATETAPIEVENT:
            {
                OnTapiEvent(
                            (TAPI_EVENT) wParam,
                            (IDispatch *) lParam
                           );
            }
        }
        
        default:

            return 0;
    }
}

//////////////////////////////////////////////////////////////////////
//
// RegisterTapiEventInterface
//
// Creates and registers the outgoing event interface interface
//
//////////////////////////////////////////////////////////////////////
HRESULT
RegisterTapiEventInterface()
{
    HRESULT                       hr = S_OK;
    IConnectionPointContainer   * pCPC;
    IConnectionPoint            * pCP;
    
    //
    // create a notification object
    //
    gpTAPIEventNotification = new CTAPIEventNotification;

    if ( NULL == gpTAPIEventNotification )
    {
        DoMessage(L"Failed to create event interface");

        return E_FAIL;
    }
    
    //
    // get the connectionpointcontainter interface
    // off the tapi object
    //
    hr = gpTapi->QueryInterface(
                                IID_IConnectionPointContainer,
                                (void **)&pCPC
                               );

    if ( !SUCCEEDED(hr) )
    {
        return hr;
    }

    //
    // get the correct connection point
    //
    hr = pCPC->FindConnectionPoint(
                                   IID_ITTAPIEventNotification,
                                   &pCP
                                  );
    pCPC->Release();
        
    if ( !SUCCEEDED(hr) )
    {
        return hr;
    }

    hr = pCP->Advise(
                     gpTAPIEventNotification,
                     &gulAdvise
                    );

    pCP->Release();

    
    return hr;

}


//////////////////////////////////////////////////////////////////////
//
// ListenOnAddresses
//
// This procedure will find all addresses that supports audio
// and will call ListenOnThisAddress to start listening on it
//
//////////////////////////////////////////////////////////////////////
HRESULT
ListenOnAddresses()
{
    HRESULT             hr = S_OK;
    IEnumAddress      * pEnumAddress;
    ITAddress         * pAddress;
    ITMediaSupport    * pMediaSupport;
    VARIANT_BOOL        bSupport;
    DWORD               dwCount = 0;
    

    gplRegistrationInstances = (long *) LocalAlloc(
        LPTR,
        sizeof(long) * gdwNumRegistrations
        );

    if ( NULL == gplRegistrationInstances )
    {
        return E_FAIL;
    }
    
    //
    // enumerate the addresses
    //
    hr = gpTapi->EnumerateAddresses( &pEnumAddress );

    if (S_OK != hr)
    {
        return hr;
    }

    while ( TRUE )
    {
        //
        // get the next address
        //
        hr = pEnumAddress->Next( 1, &pAddress, NULL );

        if (S_OK != hr)
        {
            break;
        }

        pAddress->QueryInterface(
                                 IID_ITMediaSupport,
                                 (void **)&pMediaSupport
                                );

        //
        // does it support Audio?
        //
        pMediaSupport->QueryMediaType(
                                      TAPIMEDIAMODE_AUDIO,
                                      &bSupport
                                     );

        if (bSupport)
        {
            //
            // If it does then we'll listen.
            //
            hr = ListenOnThisAddress(
                                     pAddress,
                                     gplRegistrationInstances,
                                     dwCount
                                    );
            
            if ( !SUCCEEDED(hr) )
            {
                DoMessage(L"Listen failed on an address");
            }
            else
            {
                dwCount++;
            }
        }

        pMediaSupport->Release();
        pAddress->Release();

        if (dwCount == gdwNumRegistrations)
        {
            ResizeRegistration();
        }
        
    }

    pEnumAddress->Release();

    return S_OK;
}


///////////////////////////////////////////////////////////////////
//
// ListenOnThisAddress
//
// the app must call RegisterCallNotifications
// for the address that it wants calls on
//
///////////////////////////////////////////////////////////////////
HRESULT
ListenOnThisAddress(
                    ITAddress * pAddress,
                    long * plRegistrations,
                    DWORD dwRegistrationCount
                   )
{
    HRESULT                     hr = S_OK;
    long                        lMediaTypes;
    ITMediaSupport            * pMediaSupport;
    


    //
    // listen for all media types that the address
    // supports.
    //
    hr = pAddress->QueryInterface(
                                  IID_ITMediaSupport,
                                  (void**)&pMediaSupport
                                 );

    hr = pMediaSupport->get_MediaTypes( &lMediaTypes );

    pMediaSupport->Release();
    
    hr = gpTapi->RegisterCallNotifications(
                                           pAddress,
                                           VARIANT_TRUE, // monitor
                                           VARIANT_TRUE, // owner
                                           lMediaTypes,  // media to listen for
                                           0,            // callback instance
                                           &(plRegistrations[dwRegistrationCount])
                                                         // registration instance
                                          );

    return hr;

}
                    
/////////////////////////////////////////////////////////
//
// GetVideoRenderTerminal
//
// Creates a Terminal for the VideoIn mediatype 
// This is a dynamic terminal type.
//
/////////////////////////////////////////////////////////
HRESULT
GetVideoRenderTerminal(
                       ITTerminalSupport * pTerminalSupport,
                       ITTerminal ** ppTerminal
                      )
{
    HRESULT             hr = S_OK;
    BSTR                bstrTerminalClass;
    LPOLESTR            lpTerminalClass;


    //
    // need to pass in the terminal class
    // as a BSTR
    //
    StringFromIID(
                  CLSID_VideoWindowTerm,
                  &lpTerminalClass
                 );

    bstrTerminalClass = SysAllocString ( lpTerminalClass );

    CoTaskMemFree( lpTerminalClass );

    //
    // try to create the terminal
    //
    hr = pTerminalSupport->CreateTerminal(
                                          bstrTerminalClass,
                                          TAPIMEDIAMODE_VIDEO,
                                          TD_RENDER,
                                          ppTerminal
                                         );

    SysFreeString( bstrTerminalClass );

    return hr;

}

/////////////////////////////////////////////////////////////////
//
// CreateTerminals
//
// Create audioin and audioout terminals. Videoin and videoout
// terminals  are created only when the address supports them.
//
// This function assumes that ppTerminals has a size no less than
// four.
//
/////////////////////////////////////////////////////////////////
HRESULT
CreateTerminals(
                ITAddress * pAddress,
                ITTerminal ** ppTerminals,
                DWORD * pdwNumTerminals
               )
{
    DWORD                   dwCount = 0;
    HRESULT                 hr;
    ITTerminalSupport     * pTerminalSupport;
    ITMediaSupport        * pMediaSupport;
    VARIANT_BOOL            bSupport;
    TERMINAL_DIRECTION      td;


    //
    // get the terminal support interface of the
    // address object
    //
    hr = pAddress->QueryInterface(
                                  IID_ITTerminalSupport,
                                  (void **) &pTerminalSupport
                                 );

    if ( !SUCCEEDED(hr) )
    {
        return hr;
    }

    //
    // get the default audio render terminal
    //
    hr = pTerminalSupport->GetDefaultTerminal(
                                              TAPIMEDIAMODE_AUDIO,
                                              TD_RENDER,
                                              &(ppTerminals[dwCount])
                                             );

    if ( SUCCEEDED(hr) )
    {
        //
        // does the terminal actually support TD_BOTH?
        //
        (ppTerminals[dwCount])->get_Direction( &td );

        dwCount++;
    }
    
    //
    // if not, get the audio capture terminal also
    //
    if ( (SUCCEEDED(hr) && (TD_BOTH != td)) ||
         !SUCCEEDED(hr) )
    {
        hr = pTerminalSupport->GetDefaultTerminal(
            TAPIMEDIAMODE_AUDIO,
            TD_CAPTURE,
            &(ppTerminals[dwCount])
            );

        if ( SUCCEEDED(hr) )
        {
            dwCount++;
        }
    }

    //
    // Find out if the address supports video.
    //
    pAddress->QueryInterface(
                             IID_ITMediaSupport,
                             (void **)&pMediaSupport
                            );

    //
    // does it support VideoIn?
    //
    pMediaSupport->QueryMediaType(
                                  TAPIMEDIAMODE_VIDEO,
                                  &bSupport
                                 );

    pMediaSupport->Release();
    
    if (bSupport)
    {
        //
        // get the video render terminal
        //
        hr = GetVideoRenderTerminal(
                                    pTerminalSupport,
                                    &(ppTerminals[dwCount])
                                   );

        if ( SUCCEEDED(hr) )
        {
            dwCount++;
        }

        //
        // get the Terminal for Video capture
        //
        hr = pTerminalSupport->GetDefaultTerminal(
            TAPIMEDIAMODE_VIDEO,
            TD_CAPTURE,
            &(ppTerminals[dwCount])
            );

        if ( SUCCEEDED(hr) )
        {
            //
            // If we're using the Video capture terminal, also enable
            // the preview window
            //
            ITPreviewConfig         * pPreviewConfig;
            
            hr = (ppTerminals[dwCount])->QueryInterface(
                IID_ITPreviewConfig,
                (void**)&pPreviewConfig
                );

            if ( SUCCEEDED(hr) )
            {
                pPreviewConfig->put_EnablePreview(VARIANT_TRUE);
                pPreviewConfig->Release();
            }

            dwCount++;
        }
    }

    //
    // clean up
    //
    pTerminalSupport->Release();

    //
    // return # of terminals
    //
    *pdwNumTerminals = dwCount;

    return S_OK;
}

/////////////////////////////////////////////////////////////////
//
// ReleaseTerminals
//
/////////////////////////////////////////////////////////////////
void
ReleaseTerminals(
                 ITTerminal ** ppTerminals,
                 DWORD dwNumTerminals
                )
{
    DWORD       dwCount;
    
    for (dwCount = 0; dwCount < dwNumTerminals; dwCount++)
    {
        if (ppTerminals[dwCount])
        {
            ppTerminals[dwCount]->Release();
        }
    }
}

/////////////////////////////////////////////////////////////////////
//
// Answer the call
//
/////////////////////////////////////////////////////////////////////
HRESULT
AnswerTheCall()
{
    HRESULT                 hr;
    ITCallInfo *            pCallInfo;
    ITAddress *             pAddress;
    ITTerminal *            ppTerminals[MAXTERMINALS];
    DWORD                   dwNumTerminals;
    DWORD                   dwCount;


    
    if (NULL == gpCall)
    {
        return E_UNEXPECTED;
    }


    //
    // get the address object of this call
    //
    gpCall->QueryInterface( IID_ITCallInfo, (void**)&pCallInfo );
    pCallInfo->get_Address( &pAddress );
    pCallInfo->Release();


    //
    // create the media terminals for this call
    //
    hr = CreateTerminals( 
        pAddress, 
        ppTerminals, 
        &dwNumTerminals
        );


    //
    // release the address
    //
    pAddress->Release();

    
    if (S_OK != hr)
    {
        ReleaseTheCall();

        return hr;
    }

    for (dwCount = 0; dwCount < dwNumTerminals; dwCount++)
    {

        //
        // For each terminal, call SelectTerminal
        //
        hr = gpCall->SelectTerminal(
                                    ppTerminals[dwCount]
                                   );
    }
    
    ReleaseTerminals(ppTerminals, dwNumTerminals);

    if (S_OK != hr)
    {
        ReleaseTheCall();

        return hr;
    }

    //
    // answer the call
    //
    hr = gpCall->Answer();

    return hr;
}

//////////////////////////////////////////////////////////////////////
//
// DisconnectTheCall
//
// Disconnects the call
//
//////////////////////////////////////////////////////////////////////
HRESULT
DisconnectTheCall()
{
    HRESULT         hr = S_OK;

    if (NULL != gpCall)
    {
        hr = gpCall->Disconnect( DC_NORMAL );

        ReleaseTheCall();
        
        return hr;
    }

    return S_FALSE;
}

//////////////////////////////////////////////////////////////////////
//
// ReleaseTheCall
//
// Releases the call
//
//////////////////////////////////////////////////////////////////////
void
ReleaseTheCall()
{
    if (NULL != gpCall)
    {
        gpCall->Release();
        gpCall = NULL;
    }
}


///////////////////////////////////////////////////////////////////
//
// HELPER FUNCTIONS
//
///////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////
// DoMessage
///////////////////////////////////////////////////////////////////
void
DoMessage(
          LPWSTR pszMessage
         )
{
    MessageBox(
               ghDlg,
               pszMessage,
               gszTapi30,
               MB_OK
              );
}


//////////////////////////////////////////////////////////////////
// SetStatusMessage
//////////////////////////////////////////////////////////////////
void
SetStatusMessage(
                 LPWSTR pszMessage
                )
{
    SetDlgItemText(
                   ghDlg,
                   IDC_STATUS,
                   pszMessage
                  );
}

///////////////////////////////////////////////////////////////
// EnableButton
//
// Enable, make default, and setfocus to a button
///////////////////////////////////////////////////////////////
void
EnableButton(
             int ID
            )
{
    SendDlgItemMessage(
                       ghDlg,
                       ID,
                       BM_SETSTYLE,
                       BS_DEFPUSHBUTTON,
                       0
                      );
    EnableWindow(
                 GetDlgItem( ghDlg, ID ),
                 TRUE
                );
    SetFocus(
             GetDlgItem( ghDlg, ID )
            );
}

//////////////////////////////////////////////////////////////
// DisableButton
//
// Disable a button
//////////////////////////////////////////////////////////////
void
DisableButton(
              int ID
             )
{
    SendDlgItemMessage(
                       ghDlg,
                       ID,
                       BM_SETSTYLE,
                       BS_PUSHBUTTON,
                       0
                      );
    EnableWindow(
                 GetDlgItem( ghDlg, ID ),
                 FALSE
                );
}


//////////////////////////////////////////////////////////////
//
// ResizeRegistration
//
//////////////////////////////////////////////////////////////
HRESULT
ResizeRegistration()
{
    long * plTemp;

    plTemp = (long *)LocalAlloc(
                                LPTR,
                                sizeof(long) * gdwNumRegistrations * 2
                               );

    if ( NULL == plTemp )
    {
        return E_FAIL;
    }

    CopyMemory(
               plTemp,
               gplRegistrationInstances,
               sizeof(long) * gdwNumRegistrations
              );

    gdwNumRegistrations *= 2;

    LocalFree( gplRegistrationInstances );

    gplRegistrationInstances = plTemp;

    return S_OK;
}
    