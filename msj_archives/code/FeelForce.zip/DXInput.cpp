/******************************************************************************
FILE: DXInput.cpp
This module contains all of the Direct Input specific code.  This includes
initialization and uninitializatoin functions as well as functions to get
joystick and keyboard information, and a function to cause force feedback
events.

GLOBALS:
g_lpDInput -- A pointer to the direct input interface
g_lpDIDeviceKeyboard -- A pointer to a device interface for the system keyboard
g_lpDIDeviceJoystick -- A pointer to a device interface for the system joystick
g_lpdiEffectBumpingLeft -- A pointer to an effect interface for bumping left
g_lpdiEffectBumpingRight -- A pointer to an effect interface for bumping right
g_lpdiEffectBumpingUp -- A pointer to an effect interface for bumping up
g_lpdiEffectBumpingDown -- A pointer to an effect interface for bumping down
g_lpdiEffectWavy -- A pointer to an effect interface for the wavy effect
g_lpdiEffectRamp -- A pointer to an effect interface for the ramp effect
g_bForce -- Is a force feedback joystick on this system
******************************************************************************/
#include <windows.h>
#include <Dinput.h>

#include "DXInput.h"
#include "main.h"

LPDIRECTINPUT           g_lpDInput = NULL ;
LPDIRECTINPUTDEVICE     g_lpDIDeviceKeyboard = NULL ;
LPDIRECTINPUTDEVICE2    g_lpDIDeviceJoystick = NULL ;
LPDIRECTINPUTEFFECT     g_lpdiEffectBumpingLeft = NULL ;
LPDIRECTINPUTEFFECT     g_lpdiEffectBumpingRight = NULL ;
LPDIRECTINPUTEFFECT     g_lpdiEffectBumpingUp = NULL ;
LPDIRECTINPUTEFFECT     g_lpdiEffectBumpingDown = NULL ;
LPDIRECTINPUTEFFECT     g_lpdiEffectWavy = NULL ;
LPDIRECTINPUTEFFECT     g_lpdiEffectRamp = NULL ;
BOOL                    g_bForce = FALSE ;

BOOL CALLBACK EnumJoy(LPCDIDEVICEINSTANCE lpddi, LPVOID pvRef) ;
BOOL InitForceFeedback( void ) ;
BOOL InitWavyEffect( void ) ;
BOOL InitBumpEffects( void ) ;
BOOL InitRampEffect( void ) ;

/******************************************************************************
FUNCTION: InitDirectInput
This is where the actual COM initialization occurs.  Also, the devices are
created here.

PARAMETERS:
None

RETURNS:
Success or Failure
******************************************************************************/
BOOL InitDirectInput( void )
{

   // We use CoCreateInstance to create a DirectInput object and retrieve
   // it's IDirectInput interface.  This same thing could have been done using
   // the helper function provided by DirectInput called DirectInputCreate(),
   // however, CoCreateInstance provides higher flexibility (aggregation), and
   // it isn't a bad idea to get used to this function.
   if( FAILED(CoCreateInstance(CLSID_DirectInput, NULL, CLSCTX_INPROC_SERVER,
               IID_IDirectInput, (void **)&g_lpDInput)) )
      return FALSE ;

   // First thing we do is call the Initialize member of the IDirectInput
   // interface.  This would have been done for us if we had used the helper
   // function DirectInputCreate().
   if( FAILED(g_lpDInput->Initialize(g_hInstance,DIRECTINPUT_VERSION) ) )
      return FALSE ;

   // The CreateDevice() member of IDirectInput creates a DirectInputDevice
   // object, and returns an IDirectInputDevice interface.  DirectInput has
   // defined some GUID's to define which device you wish to create
   // (GUID_SysKeyboard is one of these).  If we did not have a predefined
   // GUID, we could still enumerate for devices.
   if( !FAILED(g_lpDInput->CreateDevice(GUID_SysKeyboard,
                                         &g_lpDIDeviceKeyboard, NULL)) )
   {
      // Once we have a device we still need to set it's data format.
      // DirectInput defines several structures that can be passed in to
      // this function.  c_dfDIKeyboard  is one of these.
      g_lpDIDeviceKeyboard->SetDataFormat(&c_dfDIKeyboard) ;

      // We are not allowed to have exclusive cooperation mode for the
      // system keyboard.  The reason for this being that the user should
      // maintain control of the system, which means they need the ability
      // to use alt+tab or some such key combination to switch away from
      // your application.
      g_lpDIDeviceKeyboard->SetCooperativeLevel(g_hMainWnd,
                                       DISCL_FOREGROUND | DISCL_NONEXCLUSIVE) ;
   }else
      g_lpDIDeviceKeyboard = NULL ;

   // We need to enumerate the joysticks to search for the desired GUID.
   // This requires a callback function (EnumJoy) which is where we do the
   // actual CreateDevice call for the joystick.
   // On our first attempt we try for a force-feedback capable device,
   // otherwise we give in and enumerate regular joysticks.
   g_lpDInput->EnumDevices( DIDEVTYPE_JOYSTICK, EnumJoy, (LPVOID)TRUE,
                             DIEDFL_FORCEFEEDBACK|DIEDFL_ATTACHEDONLY) ;
   if( !g_lpDIDeviceJoystick )
      g_lpDInput->EnumDevices( DIDEVTYPE_JOYSTICK, EnumJoy, (LPVOID)FALSE,
                                DIEDFL_ATTACHEDONLY) ;

   // Was the force with us?
   if( g_bForce )
      // If so then init force feedback
      g_bForce = InitForceFeedback() ;


   return TRUE ;
}

/******************************************************************************
FUNCTION: EnumJoy
This function is called by the EnumDevices function in the IDirectInput2
interface.  It is used to enumerate existing joysticks on the system.  This
function looks for a force feedback capable joystick, and then will settle for
any installed joystick.

PARAMETERS:
lpddi -- Device instance information
pvRef -- LPVOID passed into the call to EnumDevices... used here to indicate
         whether we are trying to find force feedback joysticks.

RETURNS:
DIENUM_STOP -- If we find a joystick
DIENUM_CONTINUE -- If we haven't yet
******************************************************************************/
BOOL CALLBACK EnumJoy(LPCDIDEVICEINSTANCE lpddi, LPVOID pvRef)
{
   BOOL                 bEnumForce ;
   DIPROPRANGE          dipRange ;
   DIPROPDWORD          dipDWORD ;
   LPDIRECTINPUTDEVICE  lpDIDeviceJoystickTemp ;
   HRESULT              hr ;

   // Are we enuming force feedback joysticks?
   bEnumForce = (BOOL) pvRef ;

   // Can we create the device that wased passed in the lpddi pointer
   if( FAILED(g_lpDInput->CreateDevice(lpddi->guidInstance,
               &lpDIDeviceJoystickTemp, NULL)))
   {
      // keep trying
      g_lpDIDeviceJoystick = NULL ;
      return DIENUM_CONTINUE ;
   }

   // We want an IDirectInputDevice2 interface for all the cool features...
   // unfortunately the CreateDevice function of the IDirectInput interface
   // only supplies IDirectInputDevice interfaces.  So we do the hokey-pokey
   // and get a new interface.
   hr = lpDIDeviceJoystickTemp->QueryInterface(IID_IDirectInputDevice2,
                                              (void **) &g_lpDIDeviceJoystick) ;
   lpDIDeviceJoystickTemp->Release() ;
   if( FAILED( hr ) )
   {
      g_lpDIDeviceJoystick = NULL ;
      return DIENUM_CONTINUE ;
   }

   // We are setting the data format for the device.  c_dfDIJoystick is a
   // predefined structure that should be used for joysticks.  It is defined
   // in dinput.lib
   g_lpDIDeviceJoystick->SetDataFormat(&c_dfDIJoystick) ;

   // We are setting the cooperative level to exclusive/foreground for this
   // object.  This means that as long as our app's window is in the
   // foreground, we have exclusive control of the device.  Consider using
   // exclusive background for debugging purposes.
   g_lpDIDeviceJoystick->SetCooperativeLevel(g_hMainWnd,
                                            DISCL_EXCLUSIVE|DISCL_BACKGROUND) ;

   // The SetProperty function of the IDirectInputDevice2 interface allows you
   // to set different settings for the device.  Here we are setting the min
   // and max ranges for the stick to -100 through 100 for the X and Y axes
   dipRange.diph.dwSize       = sizeof(dipRange) ;
   dipRange.diph.dwHeaderSize = sizeof(dipRange.diph) ;
   dipRange.diph.dwObj        = DIJOFS_X ;
   dipRange.diph.dwHow        = DIPH_BYOFFSET ;
   dipRange.lMin              = -100 ;
   dipRange.lMax              = +100 ;
   g_lpDIDeviceJoystick->SetProperty( DIPROP_RANGE, &dipRange.diph) ;

   dipRange.diph.dwSize       = sizeof(dipRange) ;
   dipRange.diph.dwHeaderSize = sizeof(dipRange.diph) ;
   dipRange.diph.dwObj        = DIJOFS_Y ;
   dipRange.diph.dwHow        = DIPH_BYOFFSET ;
   dipRange.lMin              = -100 ;
   dipRange.lMax              = +100 ;
   g_lpDIDeviceJoystick->SetProperty( DIPROP_RANGE, &dipRange.diph) ;

   // Here we are using SetProperty to set the deadzone to 1/5 of the joystick
   // range
   dipDWORD.diph.dwSize       = sizeof(dipDWORD) ;
   dipDWORD.diph.dwHeaderSize = sizeof(dipDWORD.diph) ;
   dipDWORD.diph.dwObj        = DIJOFS_Y ;
   dipDWORD.diph.dwHow        = DIPH_BYOFFSET ;
   dipDWORD.dwData            = 2000 ;
   g_lpDIDeviceJoystick->SetProperty( DIPROP_DEADZONE, &dipDWORD.diph) ;

   dipDWORD.diph.dwSize       = sizeof(dipDWORD) ;
   dipDWORD.diph.dwHeaderSize = sizeof(dipDWORD.diph) ;
   dipDWORD.diph.dwObj        = DIJOFS_X ;
   dipDWORD.diph.dwHow        = DIPH_BYOFFSET ;
   dipDWORD.dwData            = 2000 ;
   g_lpDIDeviceJoystick->SetProperty( DIPROP_DEADZONE, &dipDWORD.diph) ;

   // If we were enumerating a force object then we made it... set the global
   // variable as such.
   if(bEnumForce)
      g_bForce = TRUE ;

   return DIENUM_STOP ;
}

/******************************************************************************
FUNCTION: InitForceFeedback
This function is called by InitDirectInput if a force feedback joystick has
been detected.  This function turns off auto center, and then calls the
individual functions to create effects.

PARAMETERS:
None

RETURNS:
Success or Failure
******************************************************************************/
BOOL InitForceFeedback( void )
{
   DIPROPDWORD diPropAutoCenter ;

   // SetProperty can be used to set various options for a device.  One of
   // them being DIPROP_AUTOCENTER, which we are disabling.
   diPropAutoCenter.diph.dwSize = sizeof(diPropAutoCenter) ;
   diPropAutoCenter.diph.dwHeaderSize = sizeof(DIPROPHEADER) ;
   diPropAutoCenter.diph.dwObj = 0 ;
   diPropAutoCenter.diph.dwHow = DIPH_DEVICE ;
   diPropAutoCenter.dwData = DIPROPAUTOCENTER_OFF ;
   g_lpDIDeviceJoystick->SetProperty(DIPROP_AUTOCENTER,
                                      &diPropAutoCenter.diph) ;

   if( FAILED(g_lpDIDeviceJoystick->Acquire()) )
   {
	  g_bForce = FALSE ;
      return FALSE ;
   }

   if( !InitWavyEffect())
   {
      g_bForce = FALSE ;
      return FALSE ;
   }

   if( !InitBumpEffects())
   {
      g_bForce = FALSE ;
      return FALSE ;
   }

   if( !InitRampEffect())
   {
      g_bForce = FALSE ;
      return FALSE ;
   }


   return TRUE ;
}

/******************************************************************************
FUNCTION: InitWavyEffect
This function is called by InitForceFeedback to create the "wavy" effect.

PARAMETERS:
None

RETURNS:
Success or Failure
******************************************************************************/
BOOL InitWavyEffect( void )
{
   // What axes are we mapping for this effect to
   DWORD       dwAxes[1] = { DIJOFS_X } ;
   LONG        lDirection[1] = { 200 } ;

   HRESULT     hr ;

   DIPERIODIC  diPeriodic ;
   DIEFFECT    diEffect ;

   // Set up the "Wavy" effect.
   // This effect will be periodic, so we will use the DIPERIODIC

   // Set the magnitude to half of max.
   diPeriodic.dwMagnitude = 5000 ;

   // No offset or phase defined... we want it cycling around center
   // and we don't much care where it starts in the wave
   diPeriodic.lOffset = 0 ;
   diPeriodic.dwPhase = 0 ;

   // This effect takes 1 second to complete
   diPeriodic.dwPeriod = DI_SECONDS ;

   // This is the DIEFFECT structure necessary for all effects
   diEffect.dwSize = sizeof(DIEFFECT) ;

   // Cordinate types for direction.  Cartesian == X and Y style coords
   diEffect.dwFlags = DIEFF_CARTESIAN | DIEFF_OBJECTOFFSETS ;

   // Do this effect as long as the button is pressed
   diEffect.dwDuration = INFINITE ;

   // Use our default
   diEffect.dwSamplePeriod = 0 ;

   // Max gain
   diEffect.dwGain = DI_FFNOMINALMAX ;

   // Map this effect to be active when button 1 is pressed
   diEffect.dwTriggerButton =  DIJOFS_BUTTON1 ;

   // Since this effect is INFINTE there will never be a repeat
   diEffect.dwTriggerRepeatInterval = 0 ;

   // This effect runs only on the X axis
   diEffect.cAxes = 1 ;
   diEffect.rgdwAxes = dwAxes ;
   diEffect.rglDirection = &lDirection[0] ;
   diEffect.lpEnvelope = NULL ;
   diEffect.cbTypeSpecificParams = sizeof(diPeriodic) ;
   diEffect.lpvTypeSpecificParams = &diPeriodic ;

   // Create the effect and get an interface back in our pointer
   hr = g_lpDIDeviceJoystick->CreateEffect( GUID_Sine, &diEffect,
                                            &g_lpdiEffectWavy, NULL) ;
   if(FAILED(hr))
   {
      g_lpdiEffectWavy = NULL ;
      return FALSE ;
   }

   return TRUE ;
}

/******************************************************************************
FUNCTION: InitBumpEffects
This function is called by InitForceFeedback to create the "bump" effects.

PARAMETERS:
None

RETURNS:
Success or Failure
******************************************************************************/
BOOL InitBumpEffects( void )
{
   // Between the four effects here we will be using both axes, so lets just
   // use both for all of them
   DWORD            dwAxes[2] = { DIJOFS_X, DIJOFS_Y } ;
   LONG             lDirection[2] = { 200, 00 } ;

   // Constant force, full strength
   DICONSTANTFORCE  diCF = { -10000 } ;
   HRESULT          hr ;

   DIEFFECT         diEffect ;

   // Set up the bump right
    diEffect.dwSize = sizeof(DIEFFECT) ;

   // Using X/Y style coords
    diEffect.dwFlags = DIEFF_CARTESIAN | DIEFF_OBJECTOFFSETS ;

   // Duration here is a 10th of a second
    diEffect.dwDuration =  DI_SECONDS/10 ;

   // No period
    diEffect.dwSamplePeriod = 0 ;

   // Max gain
    diEffect.dwGain = DI_FFNOMINALMAX ;

   // This effect is not mapped to a trigger, and will have to
   // be played explicity using the Start() function
    diEffect.dwTriggerButton = DIEB_NOTRIGGER ;
    diEffect.dwTriggerRepeatInterval = 0 ;

   // Both Axis
    diEffect.cAxes = 2 ;
    diEffect.rgdwAxes = dwAxes ;
    diEffect.rglDirection = lDirection ;

   // No envelope
    diEffect.lpEnvelope = NULL ;
    diEffect.cbTypeSpecificParams = sizeof(DICONSTANTFORCE) ;
    diEffect.lpvTypeSpecificParams = &diCF ;

   // Get an interface to our new effect
    hr = g_lpDIDeviceJoystick->CreateEffect(GUID_ConstantForce,&diEffect,
                                             &g_lpdiEffectBumpingRight,NULL) ;
   if(FAILED(hr))
   {
      g_lpdiEffectBumpingRight = NULL ;
      return FALSE ;
   }

   // From here on out all we are doing is changing the direction, and then
   // creating another effect.
   lDirection[0] = -200 ;
   lDirection[1] = 0 ;

   hr = g_lpDIDeviceJoystick->CreateEffect(GUID_ConstantForce,&diEffect,
                                            &g_lpdiEffectBumpingLeft,NULL) ;
   if(FAILED(hr))
   {
      g_lpdiEffectBumpingLeft = NULL ;
      return FALSE ;
   }

   lDirection[0] = 0 ;
   lDirection[1] = 200 ;

   hr = g_lpDIDeviceJoystick->CreateEffect(GUID_ConstantForce,&diEffect,
                                            &g_lpdiEffectBumpingDown,NULL) ;
   if(FAILED(hr))
   {
      g_lpdiEffectBumpingDown = NULL ;
      return FALSE ;
   }

   lDirection[0] = 0 ;
   lDirection[1] = -200 ;

   hr = g_lpDIDeviceJoystick->CreateEffect(GUID_ConstantForce,&diEffect,
                                            &g_lpdiEffectBumpingUp,NULL) ;
   if(FAILED(hr))
   {
      g_lpdiEffectBumpingDown = NULL ;
      return FALSE ;
   }

   return TRUE ;
}

/******************************************************************************
FUNCTION: InitRampEffect
This function is called by InitForceFeedback to create the "ramp" effect.

PARAMETERS:
None

RETURNS:
Success or Failure
******************************************************************************/
BOOL InitRampEffect( void )
{
   // On Axis... Y
   DWORD        dwAxes[1] = { DIJOFS_Y } ;
   LONG         lDirection[1] = { 1000 } ;
   HRESULT      hr ;

   DIEFFECT     diEffect ;
   DIRAMPFORCE  diRampForce ;

   // The beginning and the end values for our ramp force
   diRampForce.lStart = 0 ;
   diRampForce.lEnd = -10000 ;


   diEffect.dwSize = sizeof(DIEFFECT) ;
   diEffect.dwFlags = DIEFF_CARTESIAN | DIEFF_OBJECTOFFSETS ;

   // How long?  Forever
   diEffect.dwDuration = INFINITE ;

   // But it takes 2 seconds to actually reach full tension
   diEffect.dwSamplePeriod = 2*DI_SECONDS ;

   // Max gain
   diEffect.dwGain = DI_FFNOMINALMAX ;

   // Mapped to button 0
   diEffect.dwTriggerButton =  DIJOFS_BUTTON0 ;

   // It is INFINITE, so it will never repeat
   diEffect.dwTriggerRepeatInterval = 0 ;

   // 1 Axis
   diEffect.cAxes = 1 ;
   diEffect.rgdwAxes = dwAxes ;
   diEffect.rglDirection = &lDirection[0] ;
   diEffect.lpEnvelope = NULL ;
   diEffect.cbTypeSpecificParams = sizeof(diRampForce) ;
   diEffect.lpvTypeSpecificParams = &diRampForce ;

   // Creating the object, and retrieving an interface
   hr = g_lpDIDeviceJoystick->CreateEffect( GUID_RampForce, &diEffect,
                                             &g_lpdiEffectRamp, NULL) ;
   if(FAILED(hr))
   {
      g_lpdiEffectRamp = NULL ;
      return FALSE ;
   }

   return TRUE ;
}

/******************************************************************************
FUNCTION: GetJoystickInput
This function is called from the actual demo logic.  It is used to get joystick
state information from the DirectInputDevice object for the enumerated joystick

PARAMETERS:
nX -- used to pass back a horizontal direction:  -100 through +100
nY -- used to pass back a vertical direction:  -100 through + 100
bButton -- used to pass back whether the "button" is pressed

RETURNS:
Success or Failure
******************************************************************************/
BOOL GetJoystickInput( int *nX, int *nY, BOOL *bButton )
{
   HRESULT     hr ;
   DIJOYSTATE  diJoyState ;

   // No device object?  Give up.
   if(!g_lpDIDeviceJoystick)
      return FALSE ;

   // Starting from scratch
   *nX = 0 ; *nY = 0 ; *bButton = FALSE ;

   // Poll, or retrieve information from the device
   hr = g_lpDIDeviceJoystick->Poll() ;
    if(hr== DIERR_INPUTLOST || hr== DIERR_NOTACQUIRED )
    {
      // If the poll failed, maybe we should acquire
      g_lpDIDeviceJoystick->Acquire() ;
      // When we lose control of the device we may need to re-download
      // the effects that are mapped to buttons, the other effects will
      // autodownload
      if(g_lpdiEffectWavy)
         g_lpdiEffectWavy->Download() ;
      if(g_lpdiEffectRamp)
         g_lpdiEffectRamp->Download() ;
      // Lets try the poll again
      hr = g_lpDIDeviceJoystick->Poll() ;
    }
   if( FAILED(hr) )
      return FALSE ;

   // Get the device state, and populate the DIJOYSTATE structure
   if( FAILED(g_lpDIDeviceJoystick->GetDeviceState( sizeof(DIJOYSTATE), &
                                                     diJoyState)) )
      return FALSE ;

   // Map information here to our return variables.  It would be a trivial
   // addition to retrieve information such as rudder, hat, and throttle from
   // this structure.
   *nX = diJoyState.lX ;
   *nY = diJoyState.lY ;
   *bButton = diJoyState.rgbButtons[0] ;

   return TRUE ;

}

/******************************************************************************
FUNCTION: GetKeyboardInput
This function is called from the actual demo logic.  It is used to get keyboard
state information from the DirectInputDevice object for the system keyboard.

PARAMETERS:
nX -- used to pass back a horizontal direction:  -1 == left, 1 == right, 0 == 0
nY -- used to pass back a vertical direction:  -1 == left, 1 == right, 0 == 0
bButton -- used to pass back whether the "button" is pressed

RETURNS:
Success or Failure
******************************************************************************/
BOOL GetKeyboardInput( int *nX, int *nY, BOOL *bButton )
{
   char     cBuffer[256] ;
   HRESULT  hr ;

   // If we don't have an object for this device, then we give up
   if(!g_lpDIDeviceKeyboard)
      return FALSE ;

   // Start from scratch
   *nX = 0 ; *nY = 0 ; *bButton = FALSE ;

   // Load the information we need into our buffer
   hr = g_lpDIDeviceKeyboard->GetDeviceState(sizeof(cBuffer),(LPVOID)cBuffer) ;
   if(hr== DIERR_INPUTLOST || hr== DIERR_NOTACQUIRED )
   {
      // If we fail, then we try to Acquire the device, and try again.
      g_lpDIDeviceKeyboard->Acquire() ;
      hr = g_lpDIDeviceKeyboard->GetDeviceState( sizeof(cBuffer),
                                                 (LPVOID)cBuffer) ;
   }

   if( FAILED(hr) )
      return FALSE ;

   // Was the right cursor key pressed?
   if(cBuffer[DIK_RIGHT]&0x80)
      (*nX)++ ;

   // How about the left?
   if(cBuffer[DIK_LEFT]&0x80)
      (*nX)-- ;

   // Up?  Hmmm?
   if(cBuffer[DIK_UP]&0x80)
      (*nY)-- ;

   // Maybe the down key.
   if(cBuffer[DIK_DOWN]&0x80)
      (*nY)++ ;

   // We are using the left control key as the "button"
   if(cBuffer[DIK_LCONTROL]&0x80)
      *bButton = TRUE ;

   return TRUE ;

}

/******************************************************************************
FUNCTION: ForceEffect
This function plays one of the already-loaded force effects on a force feedback
device.

PARAMETERS:
nEffect -- These are defined in the DXInput.h header
pvRef -- LPVOID passed into the call to EnumDevices... used here to indicate
         whether we are trying to find force feedback joysticks.

RETURNS:
Nothing
******************************************************************************/
void ForceEffect( int nEffect)
{
   if( !g_bForce )
	   return ;

   switch( nEffect )
   {
   case FEFFECT_BUMPUP:
      // The Start function of the IDirectInputEffect interface is used to
      // start an effect
      if(g_lpdiEffectBumpingUp)
         g_lpdiEffectBumpingUp->Start(1,0) ;
      break ;
   case FEFFECT_BUMPDOWN:
      if(g_lpdiEffectBumpingDown)
         g_lpdiEffectBumpingDown->Start(1,0) ;
      break ;
   case FEFFECT_BUMPLEFT:
      if(g_lpdiEffectBumpingLeft)
         g_lpdiEffectBumpingLeft->Start(1,0) ;
      break ;
   case FEFFECT_BUMPRIGHT:
      if(g_lpdiEffectBumpingRight)
         g_lpdiEffectBumpingRight->Start(1,0) ;
      break ;
   }
}

/******************************************************************************
FUNCTION: UnInitDirectInput
Un-initialize DirectInput stuff

PARAMETERS:
None

RETURNS:
None
******************************************************************************/
void UnInitDirectInput( void )
{
   //Basic rule of thumb:  If it exists... release it
   if(g_lpDIDeviceKeyboard)
   {
      g_lpDIDeviceKeyboard->Unacquire() ;
      g_lpDIDeviceKeyboard->Release() ;
   }

   if(g_lpdiEffectBumpingLeft)
   {
      g_lpdiEffectBumpingLeft->Release() ;
   }

   if(g_lpdiEffectBumpingDown)
   {
      g_lpdiEffectBumpingDown->Release() ;
   }

   if(g_lpdiEffectBumpingUp)
   {
      g_lpdiEffectBumpingUp->Release() ;
   }

   if(g_lpdiEffectBumpingRight)
   {
      g_lpdiEffectBumpingRight->Release() ;
   }

   if(g_lpdiEffectWavy)
   {
      g_lpdiEffectWavy->Release() ;
   }

   if(g_lpdiEffectRamp)
   {
      g_lpdiEffectRamp->Release() ;
   }

   if(g_lpDIDeviceJoystick)
   {
      g_lpDIDeviceJoystick->Unacquire() ;
      g_lpDIDeviceJoystick->Release() ;
   }

   if(g_lpDInput)
      g_lpDInput->Release() ;

   return ;
}
