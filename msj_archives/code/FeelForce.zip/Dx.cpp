/******************************************************************************
FILE: DX.cpp
This module contains funtions specific to DirectX and COM.  Each componant of
DirectX will have a module dedicated to it.
******************************************************************************/
#include <windows.h>
#include <Dinput.h>

#include "DX.h"
#include "DXInput.h"


/******************************************************************************
FUNCTION: InitDirectX
This function initializes com and then calls the application defined
initialization functions dedicated to the specific DirectX componants.

PARAMETERS:
None

RETURNS:
Failure or Success
******************************************************************************/
BOOL InitDirectX( void )
{
   // Initialize COM for this process
   if (FAILED(CoInitialize(NULL)))
      return FALSE ;

   // Initialize Direct Input -- DXInput.h
   if( !InitDirectInput() )
      return FALSE ;

   return TRUE ;
}


/******************************************************************************
FUNCTION: UnInitDirectX
This function handles uninitialization.

PARAMETERS:
None

RETURNS:
None
******************************************************************************/
void UnInitDirectX( void )
{
   // Uninitialize Direct Input -- DXInput.h
   UnInitDirectInput() ;

   // Uninitialize COM for this process
   CoUninitialize() ;
}
