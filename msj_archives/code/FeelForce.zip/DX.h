/******************************************************************************
FILE: DX.h
This header simply exposes the initialization functions from DX.cpp
******************************************************************************/

BOOL InitDirectX( void ) ;
void UnInitDirectX( void ) ;
