/******************************************************************************
FILE: Demo.h
This header file defines the DemoPeron structure, the max number of persons
(for a future networked version).
******************************************************************************/

#define MAXPERSON 4

// State data for a demo person
struct DemoPerson
{
    int    m_nX ; // Horizontal coordinate
    int    m_nY ; // Verticle coordinate
    int    m_nVX ; // Horizontal velocity
    int    m_nVY ; // Verticle velocity
    BOOL   m_bAction ; // State information for the trigger
    BOOL   m_bActionHistory ; // History state information for the trigger
} ;

extern DemoPerson * g_arrayPeople[MAXPERSON] ;

void DrawPerson( HDC hdc, DemoPerson * ) ;

BOOL InitDemo( void ) ;

void UnInitDemo( void ) ;


