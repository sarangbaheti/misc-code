/******************************************************************************
FILE: WndProc.cpp
******************************************************************************/
#include <windows.h>

#include "WndProc.h"
#include "Demo.h"


/******************************************************************************
FUNCTION: MainWndProc
The window procedure for our application.  This is mostly boilerplate code.
The only noteworthy code is the call to DrawPerson().

PARAMETERS:
None

RETURNS:
none
******************************************************************************/
LRESULT CALLBACK MainWndProc( HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
   PAINTSTRUCT ps ;
   HDC         hdc ;

   switch( uMsg )
   {
   case WM_CREATE:
      break ;
   case WM_PAINT:
      hdc = BeginPaint( hwnd, &ps ) ;
      DrawPerson( hdc, g_arrayPeople[0] ) ;     
      EndPaint( hwnd, &ps ) ;
      break ;
   case WM_CLOSE:
      DestroyWindow( hwnd ) ;
      break ;
   case WM_DESTROY:
      PostQuitMessage(0) ;
   }
   return DefWindowProc( hwnd, uMsg, wParam, lParam ) ;
}
