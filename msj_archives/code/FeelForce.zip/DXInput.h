/******************************************************************************
FILE: DXInput.h
******************************************************************************/

BOOL InitDirectInput( void ) ;
void UnInitDirectInput( void ) ;
BOOL GetKeyboardInput( int *nX, int *nY, BOOL *bButton ) ;
BOOL GetJoystickInput( int *nX, int *nY, BOOL *bButton ) ;

#define FEFFECT_BUMPUP 1
#define FEFFECT_BUMPDOWN 2
#define FEFFECT_BUMPLEFT 3
#define FEFFECT_BUMPRIGHT 4

void ForceEffect( int nEffect) ;
