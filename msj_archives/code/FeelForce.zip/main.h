/******************************************************************************
FILE: main.h
This header contains external declarations for the global variables found in 
main.cpp
******************************************************************************/

extern HINSTANCE  g_hInstance ;
extern HWND       g_hMainWnd ;
