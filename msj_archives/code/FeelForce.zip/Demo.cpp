/******************************************************************************
FILE: Demo.cpp
This module contains logic relating to the function of the demo, without
including any functionality specific to DirectX.  This module defines the
"reality" of the demo, including a data structure (DemoPerson) used to maintain
state data for the demo character.

GLOBALS:
g_arrayPeople -- This is an array of pointers to the DemoPerson structure
g_hDemoThread -- This thread constantly updates the game logic
g_hEndEvent -- This event is used to signal the shutdown of the demo thread
******************************************************************************/
#include <windows.h>

#include "resource.h"
#include "Demo.h"
#include "main.h"
#include "DXInput.h"

DemoPerson * g_arrayPeople[MAXPERSON] ;

HANDLE g_hDemoThread = NULL ;
HANDLE g_hEndEvent = NULL ;

DWORD WINAPI DemoThreadFunc( LPVOID ) ;

void InitDemoReality( void ) ;


/******************************************************************************
FUNCTION: InitDemo
This function creates the demo thread and the event which signals shutdown.  It
also initializes further demo state information by calling InitDemoReality().

PARAMETERS:
None

RETURNS:
Failure or Success
******************************************************************************/
BOOL InitDemo( void )
{
   DWORD dwID ;

   // Create the event used to signal the shutdown of the demo thread
   g_hEndEvent = CreateEvent( NULL, TRUE, FALSE, NULL ) ;
   if( !g_hEndEvent )
      return FALSE ;

   // Initialize demo state data
   InitDemoReality() ;

   // Create the thread used to maintain game logic, take input, etc.
   g_hDemoThread = CreateThread( NULL, 0, DemoThreadFunc, NULL, 0, &dwID) ;

   return g_hDemoThread != NULL ;
}


/******************************************************************************
FUNCTION: InitDemoReality
This function initializes state information for the demo.  This includes a
structure to maintain velocity and coordinates for the "person" etc.

PARAMETERS:
None

RETURNS:
None
******************************************************************************/
void InitDemoReality( void )
{
   int   nIndex ;
   RECT  rect ;

   // Clear the array of pointers to people.  This currently includes future
   // support for multiple persons for the networked version of the demo.
   for( nIndex = 0 ; nIndex < MAXPERSON ; nIndex++ )
   {
      g_arrayPeople[nIndex] = NULL ;
   }

   // Allocate a new demo structure
   g_arrayPeople[0] = new DemoPerson ;

   // Center person and set their velocity to 0
   GetClientRect(g_hMainWnd,&rect) ;

   g_arrayPeople[0]->m_nX = rect.right/2 ;
   g_arrayPeople[0]->m_nY = rect.bottom/2 ;
   g_arrayPeople[0]->m_nVX = 0 ;
   g_arrayPeople[0]->m_nVY = 0 ;
   g_arrayPeople[0]->m_bAction = FALSE ;
}


/******************************************************************************
FUNCTION: UnInitDemoReality
This function deletes DemoPerson structures

PARAMETERS:
None

RETURNS:
None
******************************************************************************/
void UnInitDemoReality( void )
{
   int  nIndex ;

   // Delete the DemoPerson structures that have been created
   for( nIndex = 0 ; nIndex < MAXPERSON ; nIndex++ )
   {
      if(g_arrayPeople[nIndex])
         delete g_arrayPeople[nIndex] ;
   }
}


/******************************************************************************
FUNCTION: TakeInput
This function calls functions in the DXInput.cpp module for retrieving
information about the current state of the joystick, and keyboard.  It then
applies this information to the veloccity portion of the demo person structure.
This function is called 32 times a second by the demo thread.

PARAMETERS:
None

RETURNS:
None
******************************************************************************/
void TakeInput( void )
{
   int   nX, nY ;
   BOOL  bButton ;

   // Save the history on the button, this is so that we can respond to
   // the trigger button being released
   g_arrayPeople[0]->m_bActionHistory = g_arrayPeople[0]->m_bAction ;

   // Get joystick information and update the velocity members of the
   // DemoPerson structure.  If this fails or the joystick state
   // is in the deadzone then move on, otherwise return.
   if( GetJoystickInput( &nX, &nY, &bButton ) ) // -- DXInput.h
   {
      g_arrayPeople[0]->m_nVX = (15*nX)/100 ;
      g_arrayPeople[0]->m_nVY = (15*nY)/100 ;
      g_arrayPeople[0]->m_bAction = bButton ;
      if( nX || nY || bButton )
         return ;
   }

   // Get keyboard information, if and only if the joystick was not
   // a success, or it was in a neutral state.
   if( GetKeyboardInput( &nX, &nY, &bButton ) ) // -- DXInput.h
   {
      g_arrayPeople[0]->m_nVX = 15*nX ;
      g_arrayPeople[0]->m_nVY = 15*nY ;
      g_arrayPeople[0]->m_bAction = bButton ;
   }
}


/******************************************************************************
FUNCTION: UpdateReality
After input has been taken, this function uses the velocity and button values
in the DemoPerson struct to update the coordinates of the person.  This
function is called 32 times a second by the demo thread.

PARAMETERS: 
None

RETURNS:
None
******************************************************************************/
void UpdateReality( void )
{
   RECT  rect ;

   // How big is our window... lets shrink the rect some to set up some borders
   GetClientRect( g_hMainWnd, &rect ) ;
   InflateRect( &rect, -16, -32 ) ;

   // If we hit the right or left wall, reverse velocity, and bump the force
   // feedback.
   if( g_arrayPeople[0]->m_nX <= rect.left && g_arrayPeople[0]->m_nVX < 0 )
   {
      // Play a force feedback effect -- DXInput.h
      ForceEffect(FEFFECT_BUMPRIGHT) ;
      g_arrayPeople[0]->m_nVX = -g_arrayPeople[0]->m_nVX*2 ;
   }else if (g_arrayPeople[0]->m_nX >= (rect.right-1)
              && g_arrayPeople[0]->m_nVX > 0)
   {
      // Play a force feedback effect -- DXInput.h
      ForceEffect(FEFFECT_BUMPLEFT) ;
      g_arrayPeople[0]->m_nVX = -g_arrayPeople[0]->m_nVX*2 ;
   }

   // If we hit the top or bottom wall, reverse velocity, and bump the force
   // feedback.
   if( g_arrayPeople[0]->m_nY <= rect.top && g_arrayPeople[0]->m_nVY < 0)
   {
      // Play a force feedback effect -- DXInput.h
      ForceEffect(FEFFECT_BUMPDOWN) ;
      g_arrayPeople[0]->m_nVY = -g_arrayPeople[0]->m_nVY*2 ;
   }else if (g_arrayPeople[0]->m_nY >= (rect.bottom-1)
              && g_arrayPeople[0]->m_nVY > 0)
   {
      // Play a force feedback effect -- DXInput.h
      ForceEffect(FEFFECT_BUMPUP) ;
      g_arrayPeople[0]->m_nVY = -g_arrayPeople[0]->m_nVY*2 ;
   }

   // If we have just let go of the trigger, then do the bump down effect.
   // This is an example of an effect that is using two force feedback effects
   // (this being the latter portion of the effect.
   if( g_arrayPeople[0]->m_bActionHistory != g_arrayPeople[0]->m_bAction
        && !g_arrayPeople[0]->m_bAction )
   {
      // Play a force feedback effect -- DXInput.h
      ForceEffect(FEFFECT_BUMPDOWN) ;
   }

   g_arrayPeople[0]->m_nX += g_arrayPeople[0]->m_nVX ;
   g_arrayPeople[0]->m_nY += g_arrayPeople[0]->m_nVY ;
}


/******************************************************************************
FUNCTION: UpdateVisuals
At this point this function simply invalidates the main window, and lets it
repaint itself at it's leasure.  This means that on a slow machine the update
can be less often than the demo actually takes input and updates itself.

PARAMETERS:
None

RETURNS:
None
******************************************************************************/
void UpdateVisuals( void )
{
   InvalidateRect( g_hMainWnd, NULL, TRUE ) ;
}


/******************************************************************************
FUNCTION: DemoThreadFunc
This is the guts of the logic in the demo.  32 times a second this thread
updates the input and states of the demo.

PARAMETERS:
None

RETURNS:
0
******************************************************************************/
DWORD WINAPI DemoThreadFunc( LPVOID )
{

   // Loop 32 times a second until the g_hEndEvent becomes signalled.
   while( WaitForSingleObject(g_hEndEvent, 1000/32) != WAIT_OBJECT_0 )
   {
      TakeInput() ;
      UpdateReality() ;
      UpdateVisuals() ;
   }
   return 0 ;
}


/******************************************************************************
FUNCTION: UnInitDemo
Signales the demo thread to end, waits for it, and then frees memory.

PARAMETERS:
None

RETURNS:
none
******************************************************************************/
void UnInitDemo( void )
{
   SetEvent(g_hEndEvent) ;
   WaitForSingleObject( g_hDemoThread, INFINITE ) ;
   CloseHandle( g_hEndEvent ) ;
   CloseHandle( g_hDemoThread ) ;
   UnInitDemoReality() ;
}


/******************************************************************************
FUNCTION: DrawPerson
Draws our person, plus the person info in the upper left corner of the window.
This is using sad GDI functions at this point, however it will be replaced
with more exciting DirectX drawing capabilities in a later article.

PARAMETERS:
None

RETURNS:
none
******************************************************************************/
void DrawPerson( HDC hdc, DemoPerson *pDP )
{
   char  szBuffer[256] ;
   RECT  rect ;

   if( !pDP )
      return ;

   GetClientRect( g_hMainWnd, &rect ) ;

   wsprintf(szBuffer,"X Coordinate:  %d\n"
               "Y Coordinate:  %d\n"
               "X Velocity:  %d\n"
               "Y Velocity:  %d\n"
               "Action (Button): %s"
      ,pDP->m_nX,pDP->m_nY,pDP->m_nVX,pDP->m_nVY,(pDP->m_bAction?"Yes":"No")) ;
   DrawText( hdc, szBuffer, -1, &rect, DT_LEFT|DT_NOCLIP) ;

   Ellipse( hdc, (pDP->m_nX)-15, (pDP->m_nY)-30, (pDP->m_nX)+15, (pDP->m_nY)-5 ) ;
   MoveToEx( hdc, (pDP->m_nX), (pDP->m_nY)-5, NULL ) ;
   LineTo( hdc, (pDP->m_nX), (pDP->m_nY)+15 ) ;
   LineTo( hdc, (pDP->m_nX)+15, (pDP->m_nY)+30 ) ;
   MoveToEx( hdc, (pDP->m_nX), (pDP->m_nY)+15, NULL ) ;
   LineTo( hdc, (pDP->m_nX)-15, (pDP->m_nY)+30 ) ;
   MoveToEx( hdc, (pDP->m_nX)+15, (pDP->m_nY), NULL ) ;
   LineTo( hdc, (pDP->m_nX)-16, (pDP->m_nY) ) ;

}
