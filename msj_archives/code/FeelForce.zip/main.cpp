/******************************************************************************
FILE: main.cpp
This module contains the application WinMain as well as the initialization 
function for the application window.  Globals for instance and window are 
stored here.  Extern declarations for these variables can be found in main.h 
and are used in several of the modules in this project.

GLOBALS:
g_hInstance -- Application Instance
g_hMainWnd -- Application main window handle
******************************************************************************/
#include <windows.h>
#include "resource.h"

#include "main.h"
#include "WndProc.h"
#include "DX.h"
#include "Demo.h"

// Non-DirectX related Globals
HINSTANCE  g_hInstance ;
HWND       g_hMainWnd ;

HWND InitWindow( void ) ;


/******************************************************************************
FUNCTION: WinMain
The entry point for the application, this function initializes the application
window, initializes DirectX, initializes the demo functionality and then enters
into the main message loop.

PARAMETERS: 
Standard

RETURNS: 
0
******************************************************************************/
int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, 
                    LPSTR lpCmdLine, int nCmdShow )
{
   MSG msg ;

   g_hInstance = hInstance ;

   g_hMainWnd = InitWindow() ;
   if( !g_hMainWnd )
      return 0 ;

   if( !InitDirectX() )
      return 0 ;

   if( !InitDemo() )
      return 0 ;

   while( GetMessage( &msg, NULL, 0, 0 ) )
   {
      TranslateMessage( &msg ) ;
      DispatchMessage( &msg ) ;
   }

   UnInitDemo() ;
   UnInitDirectX() ; 

   return 0 ;
}


/******************************************************************************
FUNCTION: InitWindow
This function registers the main window class.  It also creates and shows the
window.

PARAMETERS:
None

RETURNS:
The main window handle.
******************************************************************************/
HWND InitWindow( void )
{
   WNDCLASSEX  wndclass ;
   HWND        hwnd ;

   wndclass.cbSize = sizeof( wndclass ) ; 
   wndclass.style = CS_BYTEALIGNCLIENT ; 
   wndclass.lpfnWndProc = MainWndProc ; 
   wndclass.cbClsExtra = 0 ; 
   wndclass.cbWndExtra = 0 ; 
   wndclass.hInstance = g_hInstance ; 
   wndclass.hIcon = LoadIcon(g_hInstance,MAKEINTRESOURCE(IDI_APPICON)) ; 
   wndclass.hCursor = LoadCursor(NULL,IDC_ARROW) ; 
   wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH) ; 
   wndclass.lpszMenuName = NULL ; 
   wndclass.lpszClassName = "Demo Wnd Class" ; 
   wndclass.hIconSm = NULL ; 

   if( !RegisterClassEx( &wndclass ) )
   {
      return NULL ;
   }

   hwnd = CreateWindowEx( WS_EX_APPWINDOW, "Demo Wnd Class", 
                          "DirectX", WS_OVERLAPPEDWINDOW,
                          CW_USEDEFAULT, CW_USEDEFAULT,
                          CW_USEDEFAULT, CW_USEDEFAULT,
                          NULL, NULL, g_hInstance, NULL) ;

   if( !hwnd )
      return NULL ;

   UpdateWindow( hwnd ) ;
   ShowWindow( hwnd, SW_SHOW ) ;

   return hwnd ;
}
