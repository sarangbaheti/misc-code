/******************************************************************************
FILE: WndProc.h 
Header file for the module containing the window procedure for the 
application's main window.

MainWndProc -- Window procedure for the application's main window.
******************************************************************************/

LRESULT CALLBACK MainWndProc( HWND hwnd, UINT uMsg, WPARAM wParam, 
                              LPARAM lParam ) ;
