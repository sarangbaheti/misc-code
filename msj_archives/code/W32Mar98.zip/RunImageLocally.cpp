/******************************************************************************
Module name: RunImageLocally.cpp
Notices: Written 1998 by Jeffrey Richter
Description: Forces an executable image to be run from the paging file.
******************************************************************************/


#include <windows.h>


///////////////////////////////////////////////////////////////////////////////


void WINAPI RunImageLocally(HINSTANCE hinst) {
   DWORD cp= 0;
   static DWORD s_dwPageSize = 0;

   // Get the system's page size (do this only once)
   if (s_dwPageSize == 0) {
      SYSTEM_INFO si;
      GetSystemInfo(&si);
      s_dwPageSize = si.dwPageSize;
   }

   PBYTE pbAddr = (PBYTE) hinst;
   MEMORY_BASIC_INFORMATION mbi;
   VirtualQuery(pbAddr, &mbi, sizeof(mbi));

   // Perform this loop until we fiid a region beyond the end of the file.
   while (mbi.AllocationBase == hinst) {

      // We can only force committed pages into RAM.
      // We do not want to trigger guard pages and confuse the application.
      if ((mbi.State == MEM_COMMIT) && ((mbi.Protect & PAGE_GUARD) == 0)) {

         // Determine if the pages in this region are non-writable
         BOOL fNonWritableRgn = 
            (mbi.Protect == PAGE_NOACCESS) || 
            (mbi.Protect == PAGE_READONLY) || 
            (mbi.Protect == PAGE_EXECUTE)  || 
            (mbi.Protect == PAGE_EXECUTE_READ);

         DWORD dwOrigProtect = 0;
         if (fNonWritableRgn) {
            // Non-writable region, make it writable (with the least protection)
            VirtualProtect(mbi.BaseAddress, mbi.RegionSize, 
               PAGE_EXECUTE_READWRITE, &dwOrigProtect);
         } else {
            // This is a writable page, we can leave the protections alone.
         }

         // Write to every page in the region.
         // This forces the page to be in RAM and swapped to the paging file.
         for (DWORD cbRgn = 0; cbRgn < mbi.RegionSize; cbRgn += s_dwPageSize) {
            // Volatile so that the optimizer won't remove this code
            volatile PDWORD pdw = (PDWORD) &pbAddr[cbRgn];  
            *pdw = *pdw;
            cp++;
         }

         if (dwOrigProtect != 0) {
            // If we changed the protection, change it back
            VirtualProtect(mbi.BaseAddress, mbi.RegionSize, 
               dwOrigProtect, &dwOrigProtect);
         }
      }

      // Get next region
      VirtualQuery(pbAddr += mbi.RegionSize, &mbi, sizeof(mbi));
   }
   GetLastError();
}


///////////////////////////////////////////////////////////////////////////////


int WINAPI WinMain(HINSTANCE hinstExe, HINSTANCE hinstExePrev, 
   LPSTR lpCmdLine, int nCmdShow) {

   RunImageLocally(hinstExe);
   return(0);
}


///////////////////////////////// End Of File /////////////////////////////////
