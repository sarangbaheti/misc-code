/*************************************************************
Module name: EnableDebugPrivAndRun.cpp
Notices: Written 1998 by Jeffrey Richter
Description: Enables the Debug privilege before running an app
*************************************************************/


#define STRICT
#include <Windows.h>


//////////////////////////////////////////////////////////////


BOOL EnablePrivilege(HANDLE hToken, LPCTSTR szPrivName, 
   BOOL fEnable) {

   TOKEN_PRIVILEGES tp;
   tp.PrivilegeCount = 1;
   LookupPrivilegeValue(NULL, szPrivName, &tp.Privileges[0].Luid);
   tp.Privileges[0].Attributes = fEnable ? SE_PRIVILEGE_ENABLED : 0;
   AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(tp), NULL, NULL);
   return((GetLastError() == ERROR_SUCCESS));
}


//////////////////////////////////////////////////////////////


int WINAPI WinMain(HINSTANCE hinstExe, 
   HINSTANCE hinstExePrev, LPSTR pszCmdLine, int nCmdShow) {

   HANDLE hToken;
   if (OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES, &hToken)) {
      if (EnablePrivilege(hToken, SE_DEBUG_NAME, TRUE)) {

         if (ShellExecute(NULL, NULL, pszCmdLine, NULL, 
            NULL, SW_SHOWNORMAL) < (HINSTANCE) 32) {

            MessageBox(NULL, pszCmdLine, 
               __TEXT("EnableDebugPrivAndRun: Couldn't run"),
               MB_OK | MB_ICONINFORMATION);
         }
      }
      CloseHandle(hToken);
   }
   return(0);
}


//////////////////////// End Of File /////////////////////////
