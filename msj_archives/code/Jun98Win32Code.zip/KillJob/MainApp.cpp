/******************************************************************************
Module name: MainApp.cpp
Written by:  Jeffrey Richter
Purpose:     Runs a set of processes with the ability to kill them all.
******************************************************************************/


//#define UNICODE
//#define _UNICODE

#define STRICT
#include <Windows.h>
#include <process.h>
#include <tchar.h>
#include <stdio.h>


///////////////////////////////////////////////////////////////////////////////


// Event used to forcibly kill the spawned Process Group
HANDLE g_heventTerminateProcessGroup = NULL;


///////////////////////////////////////////////////////////////////////////////


unsigned int _stdcall StartProcessGroup(void* pv) {

   // Construct the path of our Spawn-helper application
   TCHAR szCmdLine[MAX_PATH];
   GetModuleFileName(NULL, szCmdLine, MAX_PATH);
   *(_tcsrchr(szCmdLine, __TEXT('\\')) + 1) = 0; // truncate EXE filename
   _stprintf(_tcschr(szCmdLine, 0), __TEXT("SmallApp.exe %d"), 
      g_heventTerminateProcessGroup);
   
   // Our command-line arguments indicate the process that we want to run
   for (int x = 1; x < __argc; x++) {
      _tcscat(szCmdLine, __TEXT(" ")); 
      _tcscat(szCmdLine, __targv[x]); 
   }

   STARTUPINFO si = { sizeof(si) };
	si.dwFlags     = STARTF_USESHOWWINDOW;
	si.wShowWindow = SW_HIDE;  // Processes in the Process Group are hidden

   PROCESS_INFORMATION pi;

   // Spawn the process (make sure it inherits our event handle)
	BOOL f = CreateProcess(NULL, szCmdLine, NULL, NULL, TRUE, 
      CREATE_NEW_CONSOLE, NULL, NULL, &si, &pi);

   DWORD dw = 0;  // Return value

   if (f) {
      // The process was sucessfully spawned, wait for it to terminate
      CloseHandle(pi.hThread);
      WaitForSingleObject(pi.hProcess, INFINITE);
      GetExitCodeProcess(pi.hProcess, &dw);  // It's exit code is ours
      CloseHandle(pi.hProcess);

      // If the message box is still visible, the process terminated normally
      // BEWARE: There is a potential thread synchronization problem here 
      // because the message box may not be visible yet. The possibility of 
      // this is so small that I've left the code as-is for this example.
      HWND hwnd = FindWindow(NULL, __TEXT("Terminate Process Group"));
      if (IsWindow(hwnd)) {
         // Force the message box to close
         EndDialog(hwnd, IDCANCEL);
      } else {
         // The message box is not up. the process group was forcible killed
      }
   } else {
      // Couldn't spawn the process group application
   }
   return(dw);
}


////////////////////////////////////////////////////////////////////////////////


extern "C" int WINAPI _tWinMain(HINSTANCE hinst, HINSTANCE hinstExePrev, 
   LPTSTR pszCmdLine, int nShowCmd) {

	DWORD dwThreadId;

   // Create an inheritable event handle to use as our IPC mechanism
   // to terminate the processes in the process group
   // NOTE: Keep this handle for the entire lifetime of this application
   g_heventTerminateProcessGroup = CreateEvent(NULL, TRUE, FALSE, NULL);
   SetHandleInformation(g_heventTerminateProcessGroup, 
      HANDLE_FLAG_INHERIT, HANDLE_FLAG_INHERIT);

   // Spawn the processes in the process group.
   ResetEvent(g_heventTerminateProcessGroup);   // Do this before each spawn
	HANDLE hThread = (HANDLE) _beginthreadex(NULL, 0, StartProcessGroup, 
      NULL, 0, (UINT*) &dwThreadId);

   // Put up a message box waiting for the process group to terminate
   // If the user clicks OK, we will terminate the process group
   int n = MessageBox(NULL, __TEXT("Press OK to kill the Process Group."),
      __TEXT("Terminate Process Group"), MB_OK);
   if (n == IDOK) {
	   // Set the event which will kill the Process Group.
	   SetEvent(g_heventTerminateProcessGroup);
	   WaitForSingleObject(hThread, INFINITE);
   } else {
      // The other thread killed the Process Group and forced the
      // message box to die with a return code of IDCANCEL
   }

	// The spawned processes have terminated, clean up
	CloseHandle(hThread);

   // When this application is terminating, close the event
	CloseHandle(g_heventTerminateProcessGroup);
	
	return(0);
}


//////////////////////////////// End of File //////////////////////////////////
