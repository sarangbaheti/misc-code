Microsoft 1998 Professional Developer's Conference
Session AS-10 Queued Components

Sample program installation instructions

Prerequisites:
Microsoft Windows NT 5 Beta 2 (or a subsequent version)
Install MSMQ (using Control Panel-Add/Remove Programs-Windows components)
Install COM+ from Technology Preview folder
Review the COM+ "Readme" topics.

Create applications:

Launch Component Services Explorer
Using left-hand "Tree View", navigate to Computers-My Computer-COM+ Applications
Click "Action" - New - Application to launch the COM+ Application Install Wizard

Choose "Create an Empty Application" and choose a name for the "Ship" application, perhaps "DemoShip".
Choose the defaults "Server Application" and for "Interactive user".  Click Finish.

Repeat these steps to create a new "DemoNotify" application.

On the "Advanced" property page, select the "Leave running when idle" option for Server Process
Shutdown.  You don't want the app to terminate during a demo.

Change the properties of each of these applications to "Queued". Right click on the application, 
select "Properties", the "Queuing" tab, and check "Queued".  You should be able to group-select
several Applications and change the "queued" property of all of them together.

On the DemoNotify application, check the "Listener" box.  Leave DemoShip's Listener checkbox
unchecked initially.

Install components:

Double click the DemoShip application, double click "components", and select "Action", "New",
"Components" to launch the COM+ Component Install Wizard.

Choose "Install new components", and add "VBNotifyProj.dll", and continue through the wizard,
taking defaults, to Finish.  The Notify component must run under the interactive user's identity
because it produces a message box that we want to see.

(COM+ Beta 2) Right-click the installed component, select the "queueing" property page tab and select 
the Queued checkbox. This will set all interfaces that have only IN parameters to "queued". 

(COM+ Post beta 2) Double-click the installed component, double click "Interfaces", right-click the
interface, and set its "queued" property.
 
Using the same techniques, add "VBShipProj.dll" to the "DemoShip" application and set the Ship
component's interface to Queued.

Start the DemoNotify application

Using the Component Services Explorer, navigate to the DemoNotify application, right click it,
and select "start".  In COM+ Beta 2, the App "start" button is on the queuing property page.

Demonstration:

Use the "Order" component (order.vbs) to create an order and send a message to the shipping queue.

Use the MSMQ Explorer (bring along MQXPLORE.EXE) to show the message in the shipping queue.

Using the Component Services explorer, navigate to the DemoShip application, check the "Listener"
box on the Application's queuing property page, and then start the application.  You may need to 
stop and restart the DemoShip application. Use the Task Manager to kill all instances of "dllhost.exe".

Problem solving:

Use the MSMQ Control Panel Applet security tab to delete and then "renew" your internal certificate.

Create queues under the userid that reads the queue, or use the MSMQ Explorer to allow other users
to read the queues.

Use the MSMQ Queue Explorer to look for messages on queues.

Stop (Task Manager - dllhost.exe) and restart (Component Services Explorer) the queued applications.

Delete and reinstall the applications.  Application delete does not delete the underlying queues.
If you want to delete the queues, use the MSMQ Explorer.  App delete and reinstall should find the
existing MSMQ queues from a prior app installation.












