/*
 *********************************************************************
 *
 *  WDMIRP.C
 *
 *
 *      Sample WDM IRP-handling code presented in MSJ Jan '99 issue.
 *
 *      Author:  Ervin Peretz
 *
 *      Permission is hereby granted to copy 
 *      and redistribute this sample code.
 *      No warranty is implied.
 *
 *********************************************************************
 */

#include <wdm.h>


// the queue and spinlock should be part of each device context
LIST_ENTRY	irpQueue;
KSPIN_LOCK 	irpQueueSpinLock;



VOID InitIrpQueue()
{
    InitializeListHead(&irpQueue);
    KeInitializeSpinLock(&irpQueueSpinLock);		
}


NTSTATUS EnqueueIrp(PIRP Irp)
{
    PDRIVER_CANCEL oldCancelRoutine;
    KIRQL oldIrql;	
    NTSTATUS status;

    KeAcquireSpinLock(&irpQueueSpinLock, &oldIrql);

    // must set a cancel routine before checking the Cancel flag
    oldCancelRoutine = IoSetCancelRoutine(Irp, IrpCancelRoutine);
    ASSERT(!oldCancelRoutine);

    if (Irp->Cancel){
        // This IRP has already been cancelled, so complete it now.
        // We must clear the cancel routine before completing the IRP.
        // We must release the spinlock before calling out of the driver.
        IoSetCancelRoutine(Irp, NULL);
        KeReleaseSpinLock(&irpQueueSpinLock, oldIrql);
        status = Irp->IoStatus.Status = STATUS_CANCELLED;
        IoCompleteRequest(Irp, IO_NO_INCREMENT);
    }
    else {
        // This macro sets a bit in the current stack location to indicate that
        // the IRP may complete on a different thread.
        IoMarkIrpPending(Irp);

        InsertTailList(&irpQueue, &Irp->Tail.Overlay.ListEntry);
        KeReleaseSpinLock(&irpQueueSpinLock, oldIrql);
        status = STATUS_SUCCESS;
    }

    return status;
}


PIRP DequeueIrp()
{
    KIRQL oldIrql;	
    PIRP nextIrp = NULL;

    KeAcquireSpinLock(&irpQueueSpinLock, &oldIrql);

    while (!nextIrp && !IsListEmpty(&irpQueue)){
        PLIST_ENTRY listEntry = RemoveHeadList(&irpQueue);

        nextIrp = CONTAINING_RECORD(listEntry, IRP, Tail.Overlay.ListEntry);

        // clear the cancel routine while holding the spinlock
        IoSetCancelRoutine(nextIrp, NULL);

        if (nextIrp->Cancel){
            // This IRP was just cancelled.
            // The cancel routine may or may not have been called,
            // but it doesn't matter because it will not find the IRP 
            // in the list.
            // Must release the spinlock when calling outside the driver 
            // to complete the IRP.
            KeReleaseSpinLock(&irpQueueSpinLock, oldIrql);
            nextIrp->IoStatus.Status = STATUS_CANCELLED;
            IoCompleteRequest(nextIrp, IO_NO_INCREMENT);
            KeAcquireSpinLock(&irpQueueSpinLock, &oldIrql);
            nextIrp = NULL;
        }
    }

    KeReleaseSpinLock(&irpQueueSpinLock, oldIrql);
    return nextIrp;
}



VOID IrpCancelRoutine(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp)
{
    KIRQL oldIrql;	
    PIRP firstIrp = NULL, irpToComplete = NULL;

    // In this implementation, I don't assume that the IRP being cancelled is in the queue;
    // I only complete the IRP if it IS in the queue.

    KeAcquireSpinLock(&irpQueueSpinLock, &oldIrql);

    while (!IsListEmpty(&irpQueue)){
        PLIST_ENTRY listEntry;
        PIRP thisIrp;

        listEntry = RemoveHeadList(&irpQueue);
        thisIrp = CONTAINING_RECORD(listEntry, IRP, Tail.Overlay.ListEntry);

        if (thisIrp == Irp){
            // This is the IRP being cancelled; we'll complete it after we release the spinlock
            ASSERT(thisIrp->Cancel);
            irpToComplete = thisIrp;

            // Keep looping so that order of the remaining IRPs is preserved.
            // (Don't drop the spinlock and complete the irp here because
            //  the structure of the list could change in the meantime;
            //  if the IRP pointed to by firstIrp were to be dequeued
            //  while we completed this IRP, for example, 
            //  we might loop forever).
        }
        else {
            // This is not the IRP being cancelled, so put it back
            if (thisIrp == firstIrp){
                // finished going through the list
                InsertHeadList(&irpQueue, listEntry);
                break;
            }
            else {
                InsertTailList(&irpQueue, listEntry);

                if (!firstIrp){
                    firstIrp = thisIrp;
                }
            }
        }
    }

    KeReleaseSpinLock(&irpQueueSpinLock, oldIrql);

    //  Finally, release the global cancel spinlock 
    //  whether or not we are completing this IRP.
    //  Do this after releasing the local spinlock so that
    //  we exit the cancel routine at IRQL equal to Irp->CancelIrql.
    IoReleaseCancelSpinLock(Irp->CancelIrql);	

    if (irpToComplete){
        // complete this cancelled IRP only if it was in the list
        irpToComplete->IoStatus.Status = STATUS_CANCELLED;
        IoCompleteRequest(irpToComplete, IO_NO_INCREMENT);
    }
}
