/////////////////////////////////////////////////////////////////////
//
// testlogon.cpp
//
// Usage: testlogon domain user password filename
//
// This program calls LogonUser to obtain a logon session for
// the specified account, and attempts to open the specified
// file for READ access. This is most interesting when used
// with UNC paths and can help you discover when you are using
// NULL credentials. Consider changing the type of logon from
// NETWORK to INTERACTIVE, BATCH, or SERVICE and see how this
// changes things.
//
#include <windows.h>
#include <stdio.h>

void ErrMsg( const char* pszFcn, DWORD nErr = GetLastError() )
{
    char szErr[256];
    if ( !FormatMessage( FORMAT_MESSAGE_FROM_SYSTEM, 0, nErr,
                         0, szErr, sizeof szErr / sizeof *szErr, 0 ) )
        wsprintf( szErr, "GetLastError returned 0x%08X", nErr );

    printf( "%s failed:\n%s\n", pszFcn, szErr );
}

void main( int argc, char* argv[] )
{
    if ( argc < 5 )
    {
        printf( "Usage: testlogon domain user password UNCFilename\n" );
        return;
    }

    // the following call will fail unless you've granted yourself
    // the "Act as part of the operating system" right and freshened
    // your token by logging off and logging back in again.
    // (only do this temporarily for testing purposes)
    HANDLE htok = 0;
    if ( !LogonUser( argv[2], argv[1], argv[3],
        LOGON32_LOGON_BATCH, LOGON32_PROVIDER_DEFAULT, &htok ) )
    {
        ErrMsg( "LogonUser" );
        return;
    }
    if ( ImpersonateLoggedOnUser( htok ) )
    {
        // attempt to open the requested file
        HANDLE hf = CreateFile( argv[4], GENERIC_READ, 0, 0,
                                OPEN_EXISTING, 0, 0 );
        if ( INVALID_HANDLE_VALUE != hf )
        {
            printf( "Successfully opened the file for READ access.\n" );
            CloseHandle( hf );
        }
        else ErrMsg( "CreateFile" );

        RevertToSelf();
    }
    else ErrMsg( "ImpersonateLoggedOnUser" );

    CloseHandle( htok );
}
