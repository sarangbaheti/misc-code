////////////////////////////////////////////////////////////////
// 1999 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "PalHook.h"
#include "FolderFrame.h"
#include "resource.h"

#ifdef _MDI
#define IDR_MAINFRAME IDR_MAINFRAMEMDI
#define CBaseFrameWnd CMDIFrameWnd
#define CDocFrameWnd  
#else
#define IDR_MAINFRAME IDR_MAINFRAMESDI
#define CBaseFrameWnd CFrameWnd
#define CDocFrameWnd  CMainFrame
#endif

////////////////
// Palette-handling main frame window
//
class CMainFrame : public CBaseFrameWnd {
public:
	CMainFrame();
	virtual ~CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)
protected:
	CPalMsgHandler		m_palMsgHandler;	// handles palette messages
	CStatusBar			m_wndStatusBar;	// status bar
	CToolBar				m_wndToolBar;		// tool (button) bar
#ifndef _MDI
	CFolderFrame		m_wndFolderFrame;
	virtual BOOL	OnCreateClient( LPCREATESTRUCT, CCreateContext* pcc);
#endif
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	DECLARE_MESSAGE_MAP()
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
};

#ifdef _MDI

class CMyMDIChildWnd : public CMDIChildWnd {
public:
	CMyMDIChildWnd();
	virtual ~CMyMDIChildWnd();
	DECLARE_DYNCREATE(CMyMDIChildWnd)
protected:
	CFolderFrame	m_wndFolderFrame;
	virtual BOOL	OnCreateClient( LPCREATESTRUCT, CCreateContext* pcc);
	DECLARE_MESSAGE_MAP()
};

#endif
