////////////////////////////////////////////////////////////////
// 1999 Microsoft Systems Journal
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "StdAfx.h"
#include "MainFrm.h"
#include "View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CMainFrame, CBaseFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CBaseFrameWnd)
	ON_WM_CREATE()
END_MESSAGE_MAP()

static UINT indicators[] = {
	ID_SEPARATOR				// status line indicator
};

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

////////////////
// Override flicker-free drawing with no CS_VREDRAW and CS_HREDRAW. This has
// nothing to do with coolbars, but it's a good thing to do.
//
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
   cs.lpszClass = AfxRegisterWndClass(
      0,											 // no redraw
      NULL,                             // no cursor (use default)
      NULL,                             // no background brush
      AfxGetApp()->LoadIcon(IDR_MAINFRAME)); // app icon
   ASSERT(cs.lpszClass);
	cs.style |= WS_CLIPCHILDREN;
   return CBaseFrameWnd::PreCreateWindow(cs);
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CBaseFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME)) {
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT))) {
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	DragAcceptFiles(TRUE);

	// Install palette handler.
	// Mainframe doesn't draw, only views--so palette is NULL.
	//
	m_palMsgHandler.Install(this, NULL);

	return 0;
}

#ifndef _MDI
////////////////
// For SDI app, create CFolderFrame in main frame
//
BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT, CCreateContext* pcc)
{
	return m_wndFolderFrame.Create(this,
		RUNTIME_CLASS(CDIBView),
		pcc,
		IDR_FOLDERTABS);
}

#else

//////////////////
// For MDI app, create CFolderFrame in MDI child frame
//
IMPLEMENT_DYNCREATE(CMyMDIChildWnd, CMDIChildWnd)
BEGIN_MESSAGE_MAP(CMyMDIChildWnd, CMDIChildWnd)
END_MESSAGE_MAP()

CMyMDIChildWnd::CMyMDIChildWnd()
{
}

CMyMDIChildWnd::~CMyMDIChildWnd()
{
}

BOOL CMyMDIChildWnd::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pcc)
{
	return m_wndFolderFrame.Create(this,
		RUNTIME_CLASS(CDIBView),
		pcc,
		IDR_FOLDERTABS);
}

#endif

