// lsa.cpp - Sample code for programming the LSAAPI
//           to set the RunAs password and privileges.
//           Error handling has been omitted for clarity.
//           Only administrators can execute this code
//           without being denied access to the LSA policy.
//
// Note that Michael Nelson has a tool called DCOMBRIDGE
// that will allow higher level languages like VB access
// to this functionality.
// (http://www.wam.umd.edu/~mikenel/dcom/dcomtool.htm)

#include <windows.h>
#include "ntsecapi.h"

// InitString is a helper function that initializes
// a UNICODE_STRING from a simple NULL terminated string.
void InitString( UNICODE_STRING& us, wchar_t* psz )
{
    USHORT cch = wcslen( psz );
    us.Length = cch * sizeof( wchar_t );
    us.MaximumLength = ( cch + 1 ) * sizeof( wchar_t );
    us.Buffer = psz;
}

// SetCOMRunAsPassword sets the corresponding password
// for the RunAs principal for a given AppID into the
// LSA as a secret. This allows the COM SCM to look it up
// and call LogonUser / CreateProcessAsUser to launch your
// COM server using the security principal of your choice.
void SetCOMRunAsPassword( const GUID& AppID, wchar_t* pszPassword )
{
    LSA_HANDLE hPolicy = 0;
    LSA_OBJECT_ATTRIBUTES oa = { sizeof oa };
    LsaOpenPolicy( 0, &oa, POLICY_CREATE_SECRET, &hPolicy );
    
    // create key formed from AppID in the following format:
    // "SCM:{00000000-0000-0000-0000-000000000000}"
    wchar_t szKey[84] = L"SCM:";
    StringFromGUID2( AppID, szKey + 4, 80 * sizeof *szKey );
    
    UNICODE_STRING usKey;   InitString( usKey,   szKey );
    UNICODE_STRING usValue; InitString( usValue, pszPassword );
    
    LsaStorePrivateData( hPolicy, &usKey, &usValue );

    LsaClose( hPolicy );
}

// This helper function demonstrates how to add a privilege
// to a user account. The privilege you will most likely
// be interested in is "SeBatchLogonRight".
void AddPrivilege( void* psid, wchar_t* pszPriv )
{
    LSA_HANDLE hPolicy = 0;
    LSA_OBJECT_ATTRIBUTES oa = { sizeof oa };
    LsaOpenPolicy( 0, &oa,
                   POLICY_LOOKUP_NAMES | POLICY_CREATE_ACCOUNT,
                   &hPolicy );

    UNICODE_STRING usPriv; InitString( usPriv, pszPriv );

    LsaAddAccountRights( hPolicy, psid, &usPriv, 1 );

    LsaClose( hPolicy );
}
