// SetBlanket.cpp - sample code for explicitly turning off authentication
//                  on various interfaces of a proxy.

// The following function uses QueryBlanket and SetBlanket to correctly
// drop the authentication level to NONE, without mucking up any other
// security settings.
HRESULT TurnOffAuthenticationOnThisInterface( IUnknown* pUnk )
{
    IClientSecurity* pcs;
    HRESULT hr = pUnk->QueryInterface( IID_IClientSecurity, (void**)&pcs );
    if ( FAILED( hr ) )
        return hr;

    // Use QueryBlanket to obtain all the other settings that
    // we want to leave the same (don't just call SetBlanket blindly!)
    // Also, since we are turning *off* authentication, we don't care about
    // the RPC_AUTH_IDENTITY_HANDLE parameter.
    DWORD dwAuthnSvc, dwAuthzSvc, dwImpLevel, grfCaps;
    OLECHAR* pszServerPrincipal;
    hr = pcs->QueryBlanket( pUnk, &dwAuthnSvc, &dwAuthzSvc,
                            &pszServerPrincipal,
                            0,
                            &dwImpLevel, 0, &grfCaps );

    // Important note: SetBlanket on the proxy manager (IUnknown) only
    //                 controls the settings for QueryInterface in NT4SP3.
    //                 In NT4SP4 and NT5, this will control Release as well.
    if ( SUCCEEDED( hr ) )
        hr = pcs->SetBlanket( pUnk, dwAuthnSvc, dwAuthzSvc,
                              pszServerPrincipal,
                              RPC_C_AUTHN_LEVEL_NONE,
                              dwImpLevel, 0, grfCaps );
    pcs->Release();

    return hr;
}

// The following code snippet demonstrates that you need to explicitly
// use SetBlanket on each interface you want to make calls through,
// since security settings are stored separately for individual
// interface proxies.
// After calling this function, we can use both IUnknown and IFoo to make
// unauthenticated calls. If you needed to also make calls via IBar,
// just repeat for that interface as well.
HRESULT TurnOffAuthenticationForMultipleInterfaces( IFoo* pFoo )
{
    // turn off authentication on the IFoo interface proxy
    HRESULT hr = TurnOffAuthenticationOnThisInterface( pFoo );
    
    // turn off authentication for IUnknown (on the proxy manager)
    IUnknown* pUnk;
    hr = pFoo->QueryInterface( IID_IUnknown, (void**)&pUnk );
    if ( SUCCEEDED( hr ) )
    {
        hr = TurnOffAuthenticationOnThisInterface( pUnk );
        pUnk->Release();
    }
    return hr;
}
