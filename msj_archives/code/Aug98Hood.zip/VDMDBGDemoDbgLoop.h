void VDMDebugThreadFunc( void * args );
