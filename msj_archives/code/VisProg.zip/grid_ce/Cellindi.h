// CELLINDI.H

/*****************************************************************
These source files represent significant changes to the original
WorldCom MFC library.  Therefore, these source files may not be
copied except by permission of the author, Joe Willcoxson.  These
source files may not be included in source or compiled form as any
part of a commercial distribution except by permission of the
author.  These files may be used freely for internal corporate use
such as software produced by an IS departement.  These files may
also may be used freely by students for educational purposes.

No warranty or guarrantee of fitness can be made to these files.
*****************************************************************/

#ifndef ccellindices_h
#define ccellindices_h

#include <afxtempl.h>
// CCellIndices is a utility class to help with CBaseGrid and CCellGrid.
// It provides operations to manage cell indices.

class  CCellIndices
{    
	public:
	int row; // range < 0 is not valid
	int col;
	CCellIndices(int aRow = -1, int aCol = -1) : row(aRow), col(aCol){}
	int IsValid() const {return (row != -1 && col != -1);}
	int operator==(const CCellIndices& rhs) {return (row == rhs.row && col == rhs.col);}
	int operator!=(const CCellIndices& rhs) {return !operator==(rhs);}
	int  IsDownRightOf(const CCellIndices& rhs);
	int  IsDownLeftOf(const CCellIndices& rhs);
	int  IsUpRightOf(const CCellIndices& rhs);
	int  IsUpLeftOf(const CCellIndices& rhs);
};

#ifdef WIN32
class  CPrintIndicesArray : public CArray<CCellIndices, CCellIndices>
{
public:
	CPrintIndicesArray();
};
#else

class CPrintIndicesArray
{                                     
public:
	CPrintIndicesArray();
	~CPrintIndicesArray();
	CCellIndices operator[](int index);
	int Add(const CCellIndices& ci);
	int GetSize() {return m_nSize;}
	void RemoveAll();
protected:
	CCellIndices* m_pArray;
	int m_nSize;
	int m_nTotalSize;
	int m_nStep;
private:
   CPrintIndicesArray(const CPrintIndicesArray&);
   CPrintIndicesArray& operator=(const CPrintIndicesArray&);
};

#endif


#endif

// Copyright (c) 1997 by Joe Willcoxson and WorldCom.  All rights reserved.
// E-mail:  chinajoe@aol.com
// URL:  http://users.aol.com/chinajoe
// For great long distance service see http://www.wcom.com

