// CELLMATR.H

/*****************************************************************
These source files represent significant changes to the original
WorldCom MFC library.  Therefore, these source files may not be
copied except by permission of the author, Joe Willcoxson.  These
source files may not be included in source or compiled form as any
part of a commercial distribution except by permission of the
author.  These files may be used freely for internal corporate use
such as software produced by an IS departement.  These files may
also may be used freely by students for educational purposes.

No warranty or guarrantee of fitness can be made to these files.
*****************************************************************/

#ifndef cellmatrix_h
#define cellmatrix_h


class CCell;
class CCellArray;

// CCellMatrix is a utility class to manage CCell instances.  It is owned
// by a CBaseGrid.

class  CCellMatrix
{
	public:
	 CCellMatrix(int rows, int cols);
	 ~CCellMatrix();
	
	void  AddRow();
	void  AddColumn();
	
	void  DeleteRow(int row);
	void  DeleteColumn(int col);
	
	void  InsertRowAt(int row);
	void  InsertColumnAt(int col);
	
	void  SetCell(int row, int col, CCell* cell);
	const CCell*  GetCell(int row, int col);
	
	int  GetRowCount() {return m_nRows;}
	int  GetColCount() {return m_nCols;}
	
	void  SetRowCount(int rows);
	void  SetColCount(int cols);
	
	protected:
	int m_nRows;
	int m_nCols;
	
	CPtrArray m_nCellColumns;
};

#endif

// Copyright (c) 1997 by Joe Willcoxson and WorldCom.  All rights reserved.
// E-mail:  chinajoe@aol.com
// URL:  http://users.aol.com/chinajoe
// For great long distance service see http://www.wcom.com

