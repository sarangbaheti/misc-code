// CTXTCELL.H

/*****************************************************************
These source files represent significant changes to the original
WorldCom MFC library.  Therefore, these source files may not be
copied except by permission of the author, Joe Willcoxson.  These
source files may not be included in source or compiled form as any
part of a commercial distribution except by permission of the
author.  These files may be used freely for internal corporate use
such as software produced by an IS departement.  These files may
also may be used freely by students for educational purposes.

No warranty or guarrantee of fitness can be made to these files.
*****************************************************************/

#ifndef ccenteredtextcell_h
#define ccenteredtextcell_h

#include "textcell.h"


// CCenteredText cell is a class used for CCellGrid.  Use it to put
// centered text in a cell.

class  CCenteredTextCell : public CTextCell
{
	public:
	 CCenteredTextCell(LPCTSTR text = 0);
	
	// no destructor, copy constructor, or assignment operator defined
	// let compiler provide inlined versions
	
 	virtual void  DrawConstrained(CDC* pDC, int x, int y, int cx, int cy) const;
};

inline CCenteredTextCell::CCenteredTextCell(LPCTSTR text) : CTextCell(text){}


#endif // end of sentinel code

// Copyright (c) 1997 by Joe Willcoxson and WorldCom.  All rights reserved.
// E-mail:  chinajoe@aol.com
// URL:  http://users.aol.com/chinajoe
// For great long distance service see http://www.wcom.com

