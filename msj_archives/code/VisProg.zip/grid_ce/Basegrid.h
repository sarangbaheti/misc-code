// Basegrid.h

/*****************************************************************
These source files represent significant changes to the original
WorldCom MFC library.  Therefore, these source files may not be
copied except by permission of the author, Joe Willcoxson.  These
source files may not be included in source or compiled form as any
part of a commercial distribution except by permission of the
author.  These files may be used freely for internal corporate use
such as software produced by an IS departement.  These files may
also may be used freely by students for educational purposes.

No warranty or guarrantee of fitness can be made to these files.
*****************************************************************/

#ifndef cbasegrid_h
#define cbasegrid_h

/////////////////////////////////////////////////////////////////////////////
// CBaseGrid window

#include "cellindi.h"
#include "cellrang.h"

//////  USAGE NOTES

/*
  	If using this class from within a CDialog/CFormView, please take note:
  	
  	1.  In your .RC file, layout a user-defined control with the name "WORLDCOMGRID".
  	2.  In your OnCreate() or OnInitDlg() handler, subclass the user defined control with
  			the grid control:
  				
  				m_grid.SubclassDlgItem(IDC_USER1, this);
	
	3.  You will have to customize the grid. Overload the virtual member functions DrawCell() 
		and GetCellExtent().
		
	4.  If you want to enable editting in your derived Grid, overload the GetEditText()
		and SetEditText() member functions, and also remember to call EnableEdit().

*/


#define GHT_DATA 0x0000
#define GHT_TOPLEFT 0x0001
#define GHT_COLHDR 0x0002
#define GHT_ROWHDR 0x0004
#define GHT_COLSIZER 0x0008
#define GHT_ROWSIZER 0x0010
#define GHT_LEFT 0x0020
#define GHT_RIGHT 0x0040
#define GHT_ABOVE 0x0080
#define GHT_BELOW 0x0100

class  CBaseGrid : public CWnd
{
// Construction
public:
	 CBaseGrid(int rows, int cols, int fixedRows = 1, int fixedCols = 1);
	
	BOOL  SubclassDlgItem(UINT nID, CWnd* parent); // use in Dialog/FormView 
	
	BOOL  Create(const RECT& rect, CWnd* parent, UINT nID, CCreateContext* pCC = 0, 
	   DWORD style = WS_CHILD | WS_BORDER | WS_TABSTOP | WS_VISIBLE);

	static void  RegisterClass();

// Attributes
public:
	int  HitTest(CPoint pt, int& xCell, int& yCell);
	void  GetClientPix(CRect* pRect);
	
	int  GetRowCount();
	int  GetColCount();
	
	long  GetVirtualWidth(); // in pixels
	long  GetVirtualHeight(); // in pixels
	
	enum MouseMode{Nothing, 
						SelectingCells, 
						SelectingRow, 
						SelectingCol, 
						SelectingAll, 
						SizingColumn, // not implemented .... yet
						SizingRow, // ditto
						Righty  // anticipation for right mouse button activity
						};
	
// Operations
public:
	void  SetRowCount(int rows);
	void  SetColCount(int cols);

	void  SetRowHeight(int row, int height);
	void  SetColWidth(int col, int width);

	int  GetRowHeight(int row);
	int  GetRowStartY(int row);
	int  GetColWidth(int col);
	int  GetColStartX(int col);

	int  GetFixedRowCount();
	int  GetFixedColCount();
	void  SetFixedRowCount(int fixedRows);
	void  SetFixedColCount(int fixedCols);
	
	int  GetFirstSelectedRow();
	int  GetLastSelectedRow();
	int  GetFirstSelectedCol();
	int  GetLastSelectedCol();
	
	// list mode selects cells as whole rows
	// individual cell selection is not possible
	void  SetListMode(BOOL bEnableListMode = TRUE);
	BOOL  IsListMode() {return m_bListMode;}
	
	const CCellRange&  GetSelectedRange();
	void  SetSelectedRange(const CCellRange& newSelectedRange, BOOL ForceRepaint = TRUE);
	CCellRange  GetVisibleNonFixedCellRange();

	void  AutoSize(); // sizes all rows and cols
	void  AutoSizeAllCols();
	void  AutoSizeAllRows();
	void  AutoSizeCol(int col);
	void  AutoSizeRow(int row);
	
	void  ExpandToFit(); // expands row heights and col widths to fit dead space

	BOOL  GetConstrainedFlag();
	void  SetConstrainedFlag(BOOL bConstrain = TRUE);

	void  GetFont(LOGFONT& logFont);
	void  SetFont(const LOGFONT& logFont);
	void  SetFont(const char* facename);
	
	COLORREF  GetTextColor();
	void  SetTextColor(COLORREF textColor);

	virtual void  Draw(CDC& dc, int rowOffset, int columnOffset);
	virtual int  HitTest(CPoint pt, CCellIndices& indices);

	int FillPrintIndices(CPrintIndicesArray& printIndices, const CSize& extent);

	int  PrepareForPrinting(CDC* pDC);
#ifdef LATER
	void  PrintPage(CDC* pDC, CPrintInfo* pInfo);
	void  PrintPage(CDC* pDC, int page);
#endif //LATER

// Implementation
public:
	virtual  ~CBaseGrid();

	protected:
	virtual void  DrawCell(int row, int col, CDC* pDC, int x, int y);
	virtual CSize  GetCellExtent(int row, int col, CDC* pDC);
	void  PrepareDC(CDC* pDC);
	void  ResetDC(CDC* pDC);
	void  ResetScrollBars();


	// Generated message map functions
protected:
	//{{AFX_MSG(CBaseGrid)
	afx_msg void OnPaint();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg UINT OnGetDlgCode();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnCaptureChanged(CWnd* pWnd);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	// Attributes
	int  GetFixedRowHeight();
	int  GetFixedColWidth();
	
	int  GetColStartX(int col, int colOffset);
	int  GetRowStartY(int row, int rowOffset);

	int  GetColStartXAbsolute(int col);
	int  GetRowStartYAbsolute(int row);

	int  IsTopLeftCell(const CCellIndices& cellIndices);
	int  IsTopFixedCell(const CCellIndices& cellIndices);
	int  IsLeftFixedCell(const CCellIndices& cellIndices);
	
	CCellRange  GetUnobstructedCellsInRect(CRect R);
	int  IsCellVisible(CCellIndices cell);
	int  IsSelectedCellVisible();
	
	int m_nDefCellHeight;
	int m_nDefCellWidth;
	
	int m_nFixedRows;
	int m_nFixedCols;
	
	int m_nRows;
	int m_nCols;
	
	int m_nVScrollMax;
	int m_nHScrollMax;
	
	CUIntArray m_auRowHeights;
	CUIntArray m_auColWidths;
	
	CCellRange m_SelectedCellRange;
	                   
	MouseMode m_MouseMode;	                   
	CCellIndices m_LeftClickDownCell;
	CCellIndices m_LeftClickUpCell;
	CCellIndices m_MouseMoveCell;
	CPoint m_LastMousePoint;
	
	BOOL m_bConstrained;

	int m_nTimerID;

	CFont m_Font;
	CFont* m_pOrigFont; // font before m_Font selected in
	COLORREF m_TextColor;
	COLORREF m_OrigTextColor; // color before m_TextColor selected in
	
	int m_nCellBorderThickness;
	
	BOOL m_bListMode;
	
	// in place editting stuff!
	BOOL m_bEditEnabled;
	BOOL m_bEditMode;
	
	CString m_strOldEditData; // stores old cell data 
	CString m_strCurrentEditData; // current edit cell data
	static ATOM m_atomClassName;

	CPrintIndicesArray m_PrintIndices;
	
	void  EnableEdit(BOOL bEnableEdit = TRUE); // can only call from base/derived class
	
	// called during StopEdit to return the editted text
	virtual BOOL  GetEditText(int row, int col, const CString& text);
	
	// called during StartEdit to set the edittable text
	virtual BOOL  SetEditText(int row, int col, CString& text);
	virtual void  DrawEditText();
	virtual BOOL  StartEdit(UINT nChar, UINT nFlags);
	virtual BOOL  StopEdit(int nChar = VK_RETURN);
	virtual BOOL  CancelEdit();
	virtual CEdit*  CreateEditWnd(const CRect& r, LPCTSTR lpszText, int nChar, int nFlags);

	friend class CGridEditWnd;
	CEdit*  GetEditControl();
	CEdit* m_pEdit;
	
	protected:
		void OnSelecting(const CCellIndices& currentCell);
		void OnSelectingCells(CCellIndices currentCell);
		void OnSelectingRows(CCellIndices currentCell);
		void OnSelectingCols(CCellIndices currentCell);

	CCellIndices  GetCellIndices(CPoint clickPoint);
	void  InvalidateCellRect(const CCellRange& cellRange);
	CRect  GetCellRangeRect(const CCellRange& cellRange);
	CRect  GetCellRangeRect(const CCellRange& cellRange, int rowOffset, int colOffset);
	CCellRange  GetCellRange();
	void  ResetSelectedRange();
	
	private:
	static LONG FAR PASCAL  DummyWndProc(HWND, UINT, WPARAM, LPARAM);
	virtual WNDPROC*  GetSuperWndProcAddr();
};

/////////////////////////////////////////////////////////////////////////////

#endif // end of sentinel code

// Copyright (c) 1997 by Joe Willcoxson and WorldCom.  All rights reserved.
// E-mail:  chinajoe@aol.com
// URL:  http://users.aol.com/chinajoe
// For great long distance service see http://www.wcom.com

