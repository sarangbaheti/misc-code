// CELLRANG.H

/*****************************************************************
These source files represent significant changes to the original
WorldCom MFC library.  Therefore, these source files may not be
copied except by permission of the author, Joe Willcoxson.  These
source files may not be included in source or compiled form as any
part of a commercial distribution except by permission of the
author.  These files may be used freely for internal corporate use
such as software produced by an IS departement.  These files may
also may be used freely by students for educational purposes.

No warranty or guarrantee of fitness can be made to these files.
*****************************************************************/

#ifndef ccellrange_h
#define ccellrange_h

#include "cellindi.h"

// CCellRange is a utility class to manage selections of grid cells.  It is owned
// by a CBaseGrid.

class  CCellRange
{ 
	public:
	CCellRange(int minRow = -1, int minCol = -1, int maxRow = -1, int maxCol = -1)
	: m_nMinRow(minRow), m_nMinCol(minCol), m_nMaxRow(maxRow), m_nMaxCol(maxCol)
	{}
	
	CCellRange(CCellIndices min, CCellIndices max)
	: m_nMinRow(min.row), m_nMinCol(min.col), m_nMaxRow(max.row), m_nMaxCol(max.col)
	{}
	
	void  Set(int minRow, int minCol, int maxRow, int maxCol);
	
	int  IsValid() const;
	int  InRange(int row, int col) const;
	int  InRange(const CCellIndices& cellIndices) const;
	int  IsSingleCell() const;
	
	CCellIndices  GetTopLeft() const;
	CCellRange  Intersect(const CCellRange& rhs) const;
	CCellRange  Union(const CCellRange& rhs) const;
	
	int GetMinRow() const {return m_nMinRow;}
	void SetMinRow(int minRow) {m_nMinRow = minRow;}
	
	int GetMinCol() const {return m_nMinCol;}
	void SetMinCol(int minCol) {m_nMinCol = minCol;}
	
	int GetMaxRow() const {return m_nMaxRow;}
	void SetMaxRow(int maxRow) {m_nMaxRow = maxRow;}
	
	int GetMaxCol() const {return m_nMaxCol;}
	void SetMaxCol(int maxCol) {m_nMaxCol = maxCol;}
	
	int  operator==(const CCellRange& rhs);
	int  operator!=(const CCellRange& rhs);
	
	protected:
	int m_nMinRow;
	int m_nMinCol;
	int m_nMaxRow;
	int m_nMaxCol;
};

inline void CCellRange::Set(int minRow, int minCol, int maxRow, int maxCol)
{
 	m_nMinRow = minRow;
 	m_nMinCol = minCol;
 	m_nMaxRow = maxRow;
 	m_nMaxCol = maxCol;
}

inline int CCellRange::IsValid() const
{
 	return (m_nMinRow != -1 && m_nMinCol != -1 && m_nMaxRow != -1 && m_nMaxCol != -1 &&
 				m_nMinRow <= m_nMaxRow && m_nMinCol <= m_nMaxCol);
}

inline int CCellRange::InRange(int row, int col) const
{
 	return (row >= m_nMinRow && row <= m_nMaxRow && col >= m_nMinCol && col <= m_nMaxCol);
}

inline int CCellRange::IsSingleCell() const
{
 	return (m_nMinRow == m_nMaxRow && m_nMinCol == m_nMaxCol && IsValid());
}

inline int CCellRange::InRange(const CCellIndices& cellIndices) const
{
 	return InRange(cellIndices.row, cellIndices.col);
}

inline CCellIndices CCellRange::GetTopLeft() const
{
 	return CCellIndices(m_nMinRow, m_nMinCol);
}

inline CCellRange CCellRange::Intersect(const CCellRange& rhs) const
{
 	return CCellRange(max(m_nMinRow,rhs.m_nMinRow), max(m_nMinCol,rhs.m_nMinCol),
 		min(m_nMaxRow,rhs.m_nMaxRow), min(m_nMaxCol,rhs.m_nMaxCol));
}


#endif

// Copyright (c) 1997 by Joe Willcoxson and WorldCom.  All rights reserved.
// E-mail:  chinajoe@aol.com
// URL:  http://users.aol.com/chinajoe
// For great long distance service see http://www.wcom.com

