// COLORPAG.H

/*****************************************************************
These source files represent significant changes to the original
WorldCom MFC library.  Therefore, these source files may not be
copied except by permission of the author, Joe Willcoxson.  These
source files may not be included in source or compiled form as any
part of a commercial distribution except by permission of the
author.  These files may be used freely for internal corporate use
such as software produced by an IS departement.  These files may
also may be used freely by students for educational purposes.

No warranty or guarrantee of fitness can be made to these files.
*****************************************************************/

#ifndef colorpag_h
#define colorpag_h

/////////////////////////////////////////////////////////////////////////////
// WCColorPage dialog

// WCColorPage is a property sheet that allows the selection of a color.
// WCMFCRES.RC must be included into the project resource file for any
// project that uses this class.

#include "colorbut.h"
#include "wcmfcres.h"


class  WCColorPage : public CPropertyPage
{
// Construction
public:
	 WCColorPage();	// standard constructor
	
	COLORREF m_Color; // the whole reason for this!

	static COLORREF m_ColorArray[];

// Dialog Data
	//{{AFX_DATA(WCColorPage)
	enum { IDD = IDD_COLORPAGE };
	CScrollBar	m_BlueBar;
	CScrollBar	m_GreenBar;
	CScrollBar	m_RedBar;
	CColorButton	m_SampleBtn;
	CColorButton	m_Btn9;
	CColorButton	m_Btn8;
	CColorButton	m_Btn7;
	CColorButton	m_Btn6;
	CColorButton	m_Btn5;
	CColorButton	m_Btn4;
	CColorButton	m_Btn3;
	CColorButton	m_Btn2;
	CColorButton	m_Btn16;
	CColorButton	m_Btn15;
	CColorButton	m_Btn14;
	CColorButton	m_Btn13;
	CColorButton	m_Btn12;
	CColorButton	m_Btn11;
	CColorButton	m_Btn10;
	CColorButton	m_Btn1;
	//}}AFX_DATA

// Implementation
protected:
	virtual void  DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	// Generated message map functions
	//{{AFX_MSG(WCColorPage)
	virtual BOOL  OnInitDialog();
	afx_msg void  OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG
	afx_msg void  SomeButtonClicked();
	DECLARE_MESSAGE_MAP()
};


#endif

// Copyright (c) 1997 by Joe Willcoxson and WorldCom.  All rights reserved.
// E-mail:  chinajoe@aol.com
// URL:  http://users.aol.com/chinajoe
// For great long distance service see http://www.wcom.com

