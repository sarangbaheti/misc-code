//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Wcmfcres.rc
//
#define IDC_FP_FONTLIST                 1000
#define IDC_FP_STYLELIST                1001
#define IDC_FP_SIZE                     1002
#define IDC_FP_STRIKEOUT                1003
#define IDC_FP_UNDERLINE                1004
#define IDC_FP_SAMPLE                   1005
#define IDD_COLORPAGE                   9000
#define IDD_WC_COLORPAGE                9000
#define IDC_BUTTON1                     9001
#define IDD_WC_FONTPAGE                 9001
#define IDC_BUTTON2                     9002
#define IDC_BUTTON3                     9003
#define IDC_BUTTON4                     9004
#define IDC_BUTTON5                     9005
#define IDC_BUTTON6                     9006
#define IDC_BUTTON7                     9007
#define IDC_BUTTON8                     9008
#define IDC_BUTTON9                     9009
#define IDC_BUTTON10                    9010
#define IDC_BUTTON11                    9011
#define IDC_BUTTON12                    9012
#define IDC_BUTTON13                    9013
#define IDC_BUTTON14                    9014
#define IDC_BUTTON15                    9015
#define IDC_BUTTON16                    9016
#define IDC_SAMPLE                      9017
#define IDC_REDBAR                      9018
#define IDC_GREENBAR                    9019
#define IDC_BLUEBAR                     9020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
