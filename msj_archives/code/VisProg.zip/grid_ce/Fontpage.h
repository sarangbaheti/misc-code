// FONTPAGE.H

/*****************************************************************
These source files represent significant changes to the original
WorldCom MFC library.  Therefore, these source files may not be
copied except by permission of the author, Joe Willcoxson.  These
source files may not be included in source or compiled form as any
part of a commercial distribution except by permission of the
author.  These files may be used freely for internal corporate use
such as software produced by an IS departement.  These files may
also may be used freely by students for educational purposes.

No warranty or guarrantee of fitness can be made to these files.
*****************************************************************/

#ifndef fontpage_h
#define fontpage_h

#ifndef wcmfcres_h
	#include "wcmfcres.h"
#endif


/////////////////////////////////////////////////////////////////////////////
// WCFontPage dialog

// WCFontPage is a property sheet that allows the selection of a font.
// WCMFCRES.RC must be included into the project resource file for any
// project that uses this class.

class  WCFontPage : public CPropertyPage
{
// Construction
public:
	 WCFontPage(const LOGFONT* plf = 0);	// standard constructor

// Dialog Data
	//{{AFX_DATA(WCFontPage)
	enum { IDD = IDD_WC_FONTPAGE };
	CStatic	m_SampleText;
	CComboBox	m_SizeList;
	CComboBox	m_StyleList;
	CComboBox	m_FontList;
	BOOL	m_StrikeOut;
	BOOL	m_Underline;
	CString	m_FaceName;
	//}}AFX_DATA
   LOGFONT m_lf;
   
// Implementation
protected:
	virtual void  DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	// Generated message map functions
	//{{AFX_MSG(WCFontPage)
	virtual BOOL  OnInitDialog();
	afx_msg void  OnEditChangeFontList();
	afx_msg void  OnSelchangeFpFontlist();
	afx_msg void  OnSelchangeFpStylelist();
	afx_msg void  OnFpStrikeout();
	afx_msg void  OnFpUnderline();
	afx_msg void  OnSelchangeFpSize();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	
	static int CALLBACK EXPORT FontNameEnumerator(LOGFONT FAR* lf, NEWTEXTMETRIC FAR* tm, 
		int FontType, WCFontPage* page);
	static int CALLBACK EXPORT FontStyleEnumerator(LOGFONT FAR* lf, NEWTEXTMETRIC FAR* tm, 
		int FontType, WCFontPage* page);
		
	void  LoadFontList();
	void  LoadStyleList();
	void  SetSampleFont();
	
	LOGFONT m_EnumFont;
   CFont m_DisplayFont;
};

#endif

// Copyright (c) 1997 by Joe Willcoxson and WorldCom.  All rights reserved.
// E-mail:  chinajoe@aol.com
// URL:  http://users.aol.com/chinajoe
// For great long distance service see http://www.wcom.com

