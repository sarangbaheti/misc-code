// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

/*-----------------------------------------------------------------------------
//
//      Disclaimer
//
//      You may freely copy, distribute and reuse this software and its
//      associated documentation. WorldCom Network Services, Inc.
//      disclaims any warranty of any kind, expressed or implied, as to its
//      fitness for any particular use, and cannot be held liable for any
//      damages as the result of its use.
//
-----------------------------------------------------------------------------*/

#define VC_EXTRALEAN

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions (including VB)

#define WCMFCLIB_CLASS
#define WCMFC_DEF


#include "colorpag.h"
#include "fontpage.h"
#include "cellgrid.h"