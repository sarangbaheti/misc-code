// gridtvw.cpp : implementation of the CGridtestView class
//

/*-----------------------------------------------------------------------------
//
//      Disclaimer
//
//      You may freely copy, distribute and reuse this software and its
//      associated documentation. WorldCom Network Services, Inc.
//      disclaims any warranty of any kind, expressed or implied, as to its
//      fitness for any particular use, and cannot be held liable for any
//      damages as the result of its use.
//
-----------------------------------------------------------------------------*/

#include "stdafx.h"
#include "gridtest.h"

#include "gridtdoc.h"
#include "gridtvw.h"

#include "dblgridd.h"
#include "gridprop.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGridtestView

IMPLEMENT_DYNCREATE(CGridtestView, CFormView)

BEGIN_MESSAGE_MAP(CGridtestView, CFormView)
	//{{AFX_MSG_MAP(CGridtestView)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGridtestView construction/destruction

CGridtestView::CGridtestView()
	: CFormView(CGridtestView::IDD), m_Grid(10, 4)
{
	//{{AFX_DATA_INIT(CGridtestView)
	m_strEdit = "";
	//}}AFX_DATA_INIT
	// TODO: add construction code here
}

CGridtestView::~CGridtestView()
{
}

void CGridtestView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGridtestView)
	DDX_Text(pDX, IDC_EDIT1, m_strEdit);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_GRID, m_Grid);
}

/////////////////////////////////////////////////////////////////////////////
// CGridtestView diagnostics

#ifdef _DEBUG
void CGridtestView::AssertValid() const
{
	CFormView::AssertValid();
}

void CGridtestView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CGridtestDoc* CGridtestView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGridtestDoc)));
	return (CGridtestDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGridtestView message handlers

void CGridtestView::OnButton1()
{
	CDblGridDlg dlg;
	dlg.DoModal();
}

void CGridtestView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
TCHAR s[20];
	for (int i = 1; i< 10; ++i)
	{
		wsprintf(s, _T("Row %i"), i);
		m_Grid.SetText(i, 0, s, FALSE);
	}
	for (i = 1; i < 4; ++i)
	{
		wsprintf(s, _T("Column %i"), i);
		m_Grid.SetCenteredText(0, i, s, FALSE);
	}
}
#ifdef LATER
void CGridtestView::OnButton2()
{
	LOGFONT lf;
	memset(&lf, 0, sizeof(lf));
	lf.lfHeight = 24;
#ifndef _WIN32_WCE
	strcpy(lf.lfFaceName, "Times New Roman");
	CPropertySheet sheet("Property Sheets Demo");
	WCFontPage fontPage(&lf);
	WCColorPage colorPage;
	CGridPropSheet gridProp;
	sheet.AddPage(&fontPage);
	sheet.AddPage(&colorPage);
	sheet.AddPage(&gridProp);
	
	sheet.DoModal();
#endif

}
#endif
