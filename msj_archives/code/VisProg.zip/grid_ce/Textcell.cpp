// TEXTCELL.CPP

/*****************************************************************
These source files represent significant changes to the original
WorldCom MFC library.  Therefore, these source files may not be
copied except by permission of the author, Joe Willcoxson.  These
source files may not be included in source or compiled form as any
part of a commercial distribution except by permission of the
author.  These files may be used freely for internal corporate use
such as software produced by an IS departement.  These files may
also may be used freely by students for educational purposes.

No warranty or guarrantee of fitness can be made to these files.
*****************************************************************/

#include "stdafx.h"
#include "textcell.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif

// CText cell is a class used for CCellGrid.  Use it to put
// left justified text in a cell. It is the base class for other text cells.

CTextCell::CTextCell(LPCTSTR text)
 : m_pszText(0)
{
 	if (text)
 	{
#ifndef _WIN32_WCE
 		m_pszText = new TCHAR[strlen(text) + 1];
 		strcpy(m_pszText, text);
#else
 		m_pszText = new TCHAR[wcslen(text) + 1];
 		wcscpy(m_pszText, text);
#endif

 	}
 	else
 	{
 	 	m_pszText = new TCHAR[1];
 	 	m_pszText[0] = '\0';
 	}
}

CTextCell::~CTextCell()
{
	delete [] m_pszText;
}

// copy constructor
CTextCell::CTextCell(const CTextCell& rhs)
 : CCell(rhs), m_pszText(0)
{
#ifndef _WIN32_WCE
 	m_pszText = new TCHAR[strlen(rhs.m_pszText) + 1];
 	strcpy(m_pszText, rhs.m_pszText);
#else
 	m_pszText = new TCHAR[wcslen(rhs.m_pszText) + 1];
 	wcscpy(m_pszText, rhs.m_pszText);
#endif

}
 
// assignment operator
const CTextCell& CTextCell::operator=(const CTextCell& rhs)
{
 	if (&rhs == this) return *this;
 	CCell::operator=(rhs);
 	delete m_pszText;
#ifndef _WIN32_WCE
 	m_pszText = new TCHAR[strlen(rhs.m_pszText) + 1];
 	strcpy(m_pszText, rhs.m_pszText);
#else
 	m_pszText = new TCHAR[wcslen(rhs.m_pszText) + 1];
 	wcscpy(m_pszText, rhs.m_pszText);
#endif

	return *this; 	
}
 
void CTextCell::DrawUnconstrained(CDC* pDC, int x, int y) const
{
#ifndef _WIN32_WCE
 	pDC->TextOut(x, y, m_pszText, strlen(m_pszText));
#endif
} 

void CTextCell::DrawConstrained(CDC* pDC, int x, int y, int cx, int cy) const
{
	CRect R(x, y, x + cx, y + cy);
#ifndef _WIN32_WCE
 	pDC->DrawText(m_pszText, strlen(m_pszText), &R, DT_LEFT);
#else
	pDC->DrawText(m_pszText, wcslen(m_pszText), &R, DT_LEFT);
#endif
}                                         

LPCTSTR CTextCell::GetText() const
{
 	return (LPCTSTR) m_pszText;
}

void CTextCell::SetText(LPCTSTR text)
{
 	delete m_pszText;
 	m_pszText = 0;
 	if (text)
 	{
#ifndef _WIN32_WCE
 		m_pszText = new TCHAR[strlen(text) + 1];
 		strcpy(m_pszText, text);
#else
 		m_pszText = new TCHAR[wcslen(text) + 1];
 		wcscpy(m_pszText, text);
#endif
 	}
 	else
 	{
 	 	m_pszText = new TCHAR[1];
 	 	m_pszText[0] = '\0';
 	}
}

CSize GetNewlineTextExtent(CDC* pDC, LPCTSTR str)
{
	CSize ret(0,0);
	ASSERT(str);
	LPCTSTR strstart = str;
 	LPCTSTR strpos = str;
#ifndef _WIN32_WCE
 	LPCTSTR strend = str + strlen(str);
#else
	LPCTSTR strend = str + wcslen(str);
#endif
 	while (strstart != 0)
 	{
 		CSize tempSize;
#ifndef _WIN32_WCE
 	 	strpos = strchr(strstart, '\n');
#else
 	 	strpos = wcschr(strstart, '\n');
#endif

 	 	if (strpos != 0)
 	 	{
 	 		tempSize = pDC->GetTextExtent(strstart, strpos - strstart);
 	 		strstart = strpos + 1;
 	 	}
 	 	else
 	 	{
 	 	 	tempSize = pDC->GetTextExtent(strstart, strend - strstart);
 	 	 	strstart = strpos;
 	 	}
 	 	ret.cx = max(ret.cx, tempSize.cx);
 	 	ret.cy += tempSize.cy;
 	}
 	return ret;
}

CSize CTextCell::GetExtent(CDC* pDC) const
{
 	return GetNewlineTextExtent(pDC, m_pszText);
}

// Copyright (c) 1997 by Joe Willcoxson and WorldCom.  All rights reserved.
// E-mail:  chinajoe@aol.com
// URL:  http://users.aol.com/chinajoe
// For great long distance service see http://www.wcom.com

