// TEXTCELL.H

/*****************************************************************
These source files represent significant changes to the original
WorldCom MFC library.  Therefore, these source files may not be
copied except by permission of the author, Joe Willcoxson.  These
source files may not be included in source or compiled form as any
part of a commercial distribution except by permission of the
author.  These files may be used freely for internal corporate use
such as software produced by an IS departement.  These files may
also may be used freely by students for educational purposes.

No warranty or guarrantee of fitness can be made to these files.
*****************************************************************/

#ifndef textcell_h
#define textcell_h

#include "cell.h"

// CText cell is a class used for CCellGrid.  Use it to put
// left justified text in a cell. It is the base class for other text cells.

class  CTextCell : public CCell
{
 	public:
 	 CTextCell(LPCTSTR someText = 0);
 	 ~CTextCell();
 	
 	 CTextCell(const CTextCell &rhs);
 	const CTextCell&  operator=(const CTextCell& rhs);
 	
 	virtual void  DrawUnconstrained(CDC* pDC, int x, int y) const;
 	virtual void  DrawConstrained(CDC* pDC, int x, int y, int cx, int cy) const;
 	
 	LPCTSTR  GetText() const;
 	void  SetText(LPCTSTR someText);
 	
 	CSize  GetExtent(CDC* pDC) const;
 	
 	protected:
 	LPTSTR m_pszText; // 
};


#endif

// Copyright (c) 1997 by Joe Willcoxson and WorldCom.  All rights reserved.
// E-mail:  chinajoe@aol.com
// URL:  http://users.aol.com/chinajoe
// For great long distance service see http://www.wcom.com

