// BMCELL.H

/*****************************************************************
These source files represent significant changes to the original
WorldCom MFC library.  Therefore, these source files may not be
copied except by permission of the author, Joe Willcoxson.  These
source files may not be included in source or compiled form as any
part of a commercial distribution except by permission of the
author.  These files may be used freely for internal corporate use
such as software produced by an IS departement.  These files may
also may be used freely by students for educational purposes.

No warranty or guarrantee of fitness can be made to these files.
*****************************************************************/

#ifndef cbitmapcell_h
#define cbitmapcell_h

#include "cell.h"

// CBitmapCell is a class which allows you to put a bitmap into a CCellGrid cell.

class  CBitmapCell : public CCell
{
  	public:
  	 CBitmapCell(UINT nIdResource);
  	 ~CBitmapCell();
   virtual void  DrawUnconstrained(CDC* pDC, int x, int y) const;
   virtual void  DrawConstrained(CDC* pDC, int x, int y, int cx, int cy) const;
   virtual CSize  GetExtent(CDC* pDC) const;
   
   protected:
   
   CBitmap m_Bitmap;
};

#endif

// Copyright (c) 1997 by Joe Willcoxson and WorldCom.  All rights reserved.
// E-mail:  chinajoe@aol.com
// URL:  http://users.aol.com/chinajoe
// For great long distance service see http://www.wcom.com

