//{{NO_DEPENDENCIES}}
// App Studio generated include file.
// Used by GRIDTEST.RC
//
#define IDR_MAINFRAME                   2
#define IDR_GRIDTETYPE                  3
#define IDR_GRIDVIEW                    4
#define IDD_ABOUTBOX                    100
#define IDD_GRIDTEST_FORM               101
#define IDD_DIALOG1                     102
#define IDD_DIALOG2                     103
#define IDC_EDIT1                       1000
#define IDC_GRID                        1001

#define IDC_BUTTON1                     1002
#define IDC_GRID1                       1003
#define IDC_GRID2                       1004
#define IDC_BUTTON2                     1006


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
