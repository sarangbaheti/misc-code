// CELLGRID.H

/*****************************************************************
These source files represent significant changes to the original
WorldCom MFC library.  Therefore, these source files may not be
copied except by permission of the author, Joe Willcoxson.  These
source files may not be included in source or compiled form as any
part of a commercial distribution except by permission of the
author.  These files may be used freely for internal corporate use
such as software produced by an IS departement.  These files may
also may be used freely by students for educational purposes.

No warranty or guarrantee of fitness can be made to these files.
*****************************************************************/

#ifndef ccellgrid_h
#define ccellgrid_h

#include "basegrid.h"
#include "cellmatr.h"
#include "cellindi.h"
#include "cellrang.h"

/////////////////////////////////////////////////////////////////////////////
// CCellGrid window

// CCellGrid is a grid derived from CBaseGrid which owns "cells".  These cells 
// are derived from CCell and have a defined interface.  If you derive your
// own classes from CCell, you can put many different types of objects into
// this grid.


//////  USAGE NOTES

/*
  	If using this class from within a CDialog/CFormView, please take note:
  	
  	1.  In your .RC file, layout a user-defined control with the name "WORLDCOMGRID".
  	2.  In your OnCreate() or OnInitDlg() handler, subclass the user defined control with
  			the grid control:
  				
  				m_grid.SubclassDlgItem(IDC_USER1, this);
	
	3.  If you want to customize the grid, overload the DrawCell() member function, or
			derive a new class from CCell and put those CCells in the grid.
	4.  If you want to enable editting in the cell, call EnableEdit(), however, be warned
			that you will GPF if you don't have all text cells in editable areas.
*/

class  CCellGrid : public CBaseGrid
{
// Construction
public:
	 CCellGrid(int rows, int cols, int fixedRows = 1, int fixedCols = 1);
	

// Operations
public:
	void  SetRowCount(int rows);
	void  SetColCount(int cols);
	
	void  EmptyDataCells(); // deletes data in non-control cells

	const CCell*  GetCell(int row, int col);
	
	void  SetCell(int row, int col, CCell* aCell, BOOL bRepaint = TRUE);
	void  SetText(int row, int col, LPCTSTR text, BOOL bRepaint = TRUE);
	void  SetRightText(int row, int col, LPCTSTR text, BOOL bRepaint = TRUE);
	void  SetCenteredText(int row, int col, LPCTSTR text, BOOL bRepaint = TRUE);
	
	void  EnableEdit(BOOL bEnable = TRUE);
	
// Implementation
public:
	virtual  ~CCellGrid();

	protected:
	virtual void  DrawCell(int row, int col, CDC* pDC, int x, int y);
	virtual CSize  GetCellExtent(int row, int col, CDC* pDC);


	// Generated message map functions
protected:
	//{{AFX_MSG(CCellGrid)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	// Edit functionality
	virtual BOOL  GetEditText(int row, int col, const CString& text);
	virtual BOOL  SetEditText(int row, int col, CString& text);

protected:
	// Attributes
	
	CCellMatrix m_CellMatrix;
};

/////////////////////////////////////////////////////////////////////////////


#endif // end of sentinel code

// Copyright (c) 1997 by Joe Willcoxson and WorldCom.  All rights reserved.
// E-mail:  chinajoe@aol.com
// URL:  http://users.aol.com/chinajoe
// For great long distance service see http://www.wcom.com

