// COLORBUT.H

/*****************************************************************
These source files represent significant changes to the original
WorldCom MFC library.  Therefore, these source files may not be
copied except by permission of the author, Joe Willcoxson.  These
source files may not be included in source or compiled form as any
part of a commercial distribution except by permission of the
author.  These files may be used freely for internal corporate use
such as software produced by an IS departement.  These files may
also may be used freely by students for educational purposes.

No warranty or guarrantee of fitness can be made to these files.
*****************************************************************/

#ifndef ccolorbutton_h
#define ccolorbutton_h

#ifdef LATER
#ifdef WIN32
	#define WCMFC_DEF
	#ifdef WCMFCLIB
	#define WCMFCLIB_CLASS AFX_CLASS_EXPORT
	#else
	#define WCMFCLIB_CLASS AFX_CLASS_IMPORT
	#endif
#else
	#define WCMFCLIB_CLASS
	#ifdef _WCMFC_DEF
	#define WCMFC_DEF EXPORT
	#else
	#define WCMFC_DEF
	#endif
#endif
#endif //LATER
#define WCMFCLIB_CLASS


/////////////////////////////////////////////////////////////////////////////
// CColorButton window
//
// CColorButton is an owner drawn button class that is used by the 
// WCColorPage class.  It simply fills its client area with a color.

class WCMFCLIB_CLASS CColorButton : public CButton
{
// Construction
public:                            
	DECLARE_DYNAMIC(CColorButton)
	WCMFC_DEF CColorButton(COLORREF color = 0);

// Attributes
public:

// Operations
public:
	COLORREF WCMFC_DEF GetColor();
	void WCMFC_DEF SetColor(COLORREF color);

// Implementation
public:
	virtual WCMFC_DEF ~CColorButton();

protected:

	virtual void WCMFC_DEF DrawItem(LPDRAWITEMSTRUCT lpDI);
	COLORREF m_Color;
};

/////////////////////////////////////////////////////////////////////////////

#undef WCMFC_DEF
#undef WCMFCLIB_CLASS

#endif

// Copyright (c) 1997 by Joe Willcoxson and WorldCom.  All rights reserved.
// E-mail:  chinajoe@aol.com
// URL:  http://users.aol.com/chinajoe
// For great long distance service see http://www.wcom.com

