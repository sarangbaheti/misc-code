/*
 *  ARM animates an articulating robot arm.
 */

#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>

LONG WINAPI WndProc (HWND, UINT, WPARAM, LPARAM);
void SetDCPixelFormat (HDC);
void InitializeRC (void);
void DrawBox (GLfloat, GLfloat, GLfloat, GLfloat, GLfloat, GLfloat);
void DrawScene (HDC, UINT);

HPALETTE hPalette = NULL;

/*
 *  Function WinMain.
 */

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    LPSTR lpszCmdLine, int nCmdShow)
{
    static char szAppName[] = "Robot Arm";
    WNDCLASS wc;
    HWND hwnd;
    MSG msg;

    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = (WNDPROC) WndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon (NULL, IDI_APPLICATION);
    wc.hCursor = LoadCursor (NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH) (COLOR_WINDOW + 1);
    wc.lpszMenuName = NULL;
    wc.lpszClassName = szAppName;

    RegisterClass (&wc);

    hwnd = CreateWindow (szAppName, szAppName,
        WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
        HWND_DESKTOP, NULL, hInstance, NULL);

    ShowWindow (hwnd, nCmdShow);
    UpdateWindow (hwnd);

    while (GetMessage (&msg, NULL, 0, 0)) {
        TranslateMessage (&msg);
        DispatchMessage (&msg);
    }
    return msg.wParam;
}

/*
 *  WndProc processes messages to the main window.
 */
 
LONG WINAPI WndProc (HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    static HDC hdc;
    static HGLRC hrc;
    PAINTSTRUCT ps;
    GLdouble gldAspect;
    GLsizei glnWidth, glnHeight;
    static BOOL bUp = TRUE;
    static UINT nAngle = 0;
    static UINT nTimer;
    int n;
                
    switch (msg) {
    
    case WM_CREATE:
        //
        // Create a rendering context and set a timer.
        //
        hdc = GetDC (hwnd);
        SetDCPixelFormat (hdc);
        hrc = wglCreateContext (hdc);
        wglMakeCurrent (hdc, hrc);
        InitializeRC ();
        nTimer = SetTimer (hwnd, 1, 50, NULL);
        return 0;
    
    case WM_SIZE:
        //
        // Redefine the viewing volume and viewport once when the program
        // starts and again any time the window size changes.
        //
        glnWidth = (GLsizei) LOWORD (lParam);
        glnHeight = (GLsizei) HIWORD (lParam);
        gldAspect = (GLdouble) glnWidth / (GLdouble) glnHeight;

        glMatrixMode (GL_PROJECTION);
        glLoadIdentity ();
        gluPerspective (30.0, gldAspect, 1.0, 100.0);

        glViewport (0, 0, glnWidth, glnHeight);
        return 0;

    case WM_PAINT:
        //
        // Draw the scene.
        //
        BeginPaint (hwnd, &ps);
        DrawScene (hdc, nAngle);
        EndPaint (hwnd, &ps);
        return 0;       

    case WM_TIMER:
        //
        // Update the rotation angle and force a repaint.
        //
        if (bUp) {
            nAngle += 2;
            if (nAngle == 90)
                bUp = FALSE;
        }
        else {
            nAngle -= 2;
            if (nAngle == 0)
                bUp = TRUE;
        }
        InvalidateRect (hwnd, NULL, FALSE);         
        return 0;

    case WM_QUERYNEWPALETTE:
        //
        // If the program is using a color palette, realize the palette
        // and update the client area when the window receives the input
        // focus.
        //
        if (hPalette != NULL) {
            if (n = RealizePalette (hdc))
                InvalidateRect (hwnd, NULL, FALSE);
            return n;
        }
        break;
        
    case WM_PALETTECHANGED:
        //
        // If the program is using a color palette, realize the palette
        // and update the colors in the client area when another program
        // realizes its palette.
        //
        if ((hPalette != NULL) && ((HWND) wParam != hwnd)) {
            if (RealizePalette (hdc))
                UpdateColors (hdc);
            return 0;
        }
        break;

    case WM_DESTROY:
        //
        // Clean up and terminate.
        //
        wglMakeCurrent (NULL, NULL);
        wglDeleteContext (hrc);
        ReleaseDC (hwnd, hdc);
        if (hPalette != NULL)
            DeleteObject (hPalette);
        KillTimer (hwnd, nTimer);
        PostQuitMessage (0);
        return 0;
    }
    return DefWindowProc (hwnd, msg, wParam, lParam);
}

/*
 *  SetDCPixelFormat sets the pixel format for a device context in
 *  preparation for creating a rendering context.
 *
 *  Input parameters:
 *    hdc = Device context handle
 *
 *  Returns:
 *    Nothing
 */
 
void SetDCPixelFormat (HDC hdc)
{
    HANDLE hHeap;
    int nColors, i;
    LPLOGPALETTE lpPalette;
    BYTE byRedMask, byGreenMask, byBlueMask;

    static PIXELFORMATDESCRIPTOR pfd = {
        sizeof (PIXELFORMATDESCRIPTOR),             // Size of this structure
        1,                                          // Version number
        PFD_DRAW_TO_WINDOW |                        // Flags
        PFD_SUPPORT_OPENGL |
        PFD_DOUBLEBUFFER,
        PFD_TYPE_RGBA,                              // RGBA pixel values
        24,                                         // 24-bit color
        0, 0, 0, 0, 0, 0,                           // Don't care about these
        0, 0,                                       // No alpha buffer
        0, 0, 0, 0, 0,                              // No accumulation buffer
        32,                                         // 32-bit depth buffer
        0,                                          // No stencil buffer
        0,                                          // No auxiliary buffers
        PFD_MAIN_PLANE,                             // Layer type
        0,                                          // Reserved (must be 0)
        0, 0, 0                                     // No layer masks
    };

    int nPixelFormat;
    
    nPixelFormat = ChoosePixelFormat (hdc, &pfd);
    SetPixelFormat (hdc, nPixelFormat, &pfd);

    DescribePixelFormat (hdc, nPixelFormat, sizeof (PIXELFORMATDESCRIPTOR),
        &pfd);

    if (pfd.dwFlags & PFD_NEED_PALETTE) {
        nColors = 1 << pfd.cColorBits;
        hHeap = GetProcessHeap ();

        (LPLOGPALETTE) lpPalette = HeapAlloc (hHeap, 0,
            sizeof (LOGPALETTE) + (nColors * sizeof (PALETTEENTRY)));
            
        lpPalette->palVersion = 0x300;
        lpPalette->palNumEntries = nColors;

        byRedMask = (1 << pfd.cRedBits) - 1;
        byGreenMask = (1 << pfd.cGreenBits) - 1;
        byBlueMask = (1 << pfd.cBlueBits) - 1;

        for (i=0; i<nColors; i++) {
            lpPalette->palPalEntry[i].peRed =
                (((i >> pfd.cRedShift) & byRedMask) * 255) / byRedMask;
            lpPalette->palPalEntry[i].peGreen =
                (((i >> pfd.cGreenShift) & byGreenMask) * 255) / byGreenMask;
            lpPalette->palPalEntry[i].peBlue =
                (((i >> pfd.cBlueShift) & byBlueMask) * 255) / byBlueMask;
            lpPalette->palPalEntry[i].peFlags = 0;
        }

        hPalette = CreatePalette (lpPalette);
        HeapFree (hHeap, 0, lpPalette);

        if (hPalette != NULL) {
            SelectPalette (hdc, hPalette, FALSE);
            RealizePalette (hdc);
        }
    }
}

/*
 *  InitializeRC initializes the current rendering context.
 *
 *  Input parameters:
 *    None
 *
 *  Returns:
 *    Nothing
 */

void InitializeRC (void)
{
    GLfloat glfLightAmbient[] = { 0.1f, 0.1f, 0.1f, 1.0f };
    GLfloat glfLightDiffuse[] = { 0.7f, 0.7f, 0.7f, 1.0f };
    GLfloat glfLightSpecular[] = { 0.0f, 0.0f, 0.0f, 1.0f };

    //
    // Initialize state variables.
    //
    glFrontFace (GL_CCW);
    glCullFace (GL_BACK);
    glEnable (GL_CULL_FACE);

    glDepthFunc (GL_LEQUAL);
    glEnable (GL_DEPTH_TEST);
    glClearColor (0.0f, 0.0f, 0.0f, 0.0f);

    //
    // Add a light to the scene.
    //
    glLightfv (GL_LIGHT0, GL_AMBIENT, glfLightAmbient);
    glLightfv (GL_LIGHT0, GL_DIFFUSE, glfLightDiffuse);
    glLightfv (GL_LIGHT0, GL_SPECULAR, glfLightSpecular);
    glEnable (GL_LIGHTING);
    glEnable (GL_LIGHT0);
}

/*
 *  DrawBox draws a solid box at the specified coordinates.
 *
 *  Input parameters:
 *    x1, y1, z1 = Coordinates of one corner
 *    x2, y2, z2 = Coordinates of corner diagonally opposite
 *
 *  Returns:
 *    Nothing
 *
 *  Note:
 *    x1, y1, and z1 must be less than x2, y2, and z2 to ensure faces
 *    are drawn correctly.
 */

void DrawBox (GLfloat x1, GLfloat x2, GLfloat y1, GLfloat y2,
              GLfloat z1, GLfloat z2) 
{
    glBegin (GL_POLYGON); // Front
        glNormal3f (0.0f, 0.0f, 1.0f);
        glVertex3f (x1, y1, z2);
        glVertex3f (x2, y1, z2);            
        glVertex3f (x2, y2, z2);           
        glVertex3f (x1, y2, z2);            
    glEnd ();

    glBegin (GL_POLYGON); // Back
        glNormal3f (0.0f, 0.0f, -1.0f);
        glVertex3f (x2, y1, z1);
        glVertex3f (x1, y1, z1);           
        glVertex3f (x1, y2, z1);          
        glVertex3f (x2, y2, z1);           
    glEnd ();

    glBegin (GL_POLYGON); // Left
        glNormal3f (-1.0f, 0.0f, 0.0f);
        glVertex3f (x1, y1, z1);
        glVertex3f (x1, y1, z2);            
        glVertex3f (x1, y2, z2);           
        glVertex3f (x1, y2, z1);            
    glEnd ();

    glBegin (GL_POLYGON); // Right
        glNormal3f (1.0f, 0.0f, 0.0f);
        glVertex3f (x2, y1, z2);
        glVertex3f (x2, y1, z1);            
        glVertex3f (x2, y2, z1);           
        glVertex3f (x2, y2, z2);            
    glEnd ();

    glBegin (GL_POLYGON); // Top
        glNormal3f (0.0f, 1.0f, 0.0f);
        glVertex3f (x1, y2, z2);
        glVertex3f (x2, y2, z2);            
        glVertex3f (x2, y2, z1);             
        glVertex3f (x1, y2, z1);            
    glEnd ();

    glBegin (GL_POLYGON); // Bottom
        glNormal3f (0.0f, 1.0f, 0.0f);
        glVertex3f (x2, y1, z2);
        glVertex3f (x1, y1, z2);            
        glVertex3f (x1, y1, z1);             
        glVertex3f (x2, y1, z1);            
    glEnd ();
}

/*
 *  DrawScene uses OpenGL commands to draw a cube.
 *
 *  Input parameters:
 *    hdc = Device context handle
 *    nAngle = Angle of rotation for cube
 *
 *  Returns:
 *    Nothing
 */

void DrawScene (HDC hdc, UINT nAngle)
{
    GLfloat glfBlue[] = { 0.0f, 0.0f, 1.0f, 1.0f };
    GLfloat glfYellow[] = { 1.0f, 1.0f, 0.0f, 1.0f };

    //
    // Clear the color and depth buffers.
    //
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    //
    // Position the model relative to the viewpoint.
    //
    glMatrixMode (GL_MODELVIEW);
    glLoadIdentity ();
    glTranslatef (0.0f, 0.0f, -64.0f);
    glRotatef (30.0f, 1.0f, 0.0f, 0.0f);
    glRotatef (30.0f, 0.0f, 1.0f, 0.0f);

    //
    // Draw the two blocks anchoring the arm.
    //
    glMaterialfv (GL_FRONT, GL_AMBIENT_AND_DIFFUSE, glfYellow);
    DrawBox (1.0f, 3.0f, -2.0f, 2.0f, -2.0f, 2.0f);
    DrawBox (-3.0f, -1.0f, -2.0f, 2.0f, -2.0f, 2.0f);

    //
    // Rotate the coordinate system and draw the arm's base member.
    //
    glMaterialfv (GL_FRONT, GL_AMBIENT_AND_DIFFUSE, glfBlue);
    glRotatef ((GLfloat) nAngle, 1.0f, 0.0f, 0.0f);
    DrawBox (-1.0f, 1.0f, -1.0f, 1.0f, -5.0f, 5.0f);

    //
    // Translate the coordinate system to the end of the base member,
    // rotate it, and draw the second member.
    //
    glTranslatef (0.0f, 0.0f, -5.0f);
    glRotatef (-((GLfloat) nAngle) / 2, 1.0f, 0.0f, 0.0f);
    DrawBox (-1.0f, 1.0f, -1.0f, 1.0f, -10.0f, 0.0f);

    //
    // Translate and rotate the coordinate system again and draw the
    // arm's third and final member.
    //
    glTranslatef (0.0f, 0.0f, -10.0f);
    glRotatef (-((GLfloat) nAngle) / 2, 1.0f, 0.0f, 0.0f);
    DrawBox (-1.0f, 1.0f, -1.0f, 1.0f, -10.0f, 0.0f);

    //
    // Render the scene in the pixel buffer.
    //
    SwapBuffers (hdc);
}
