////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// CClock represents any object that can handle menu commands.
// CClock handles two commands, Clock | Set Time and Clock | Check Time
//
#include "StdAfx.h"
#include "Resource.h"
#include "Clock.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CClock, CCmdTarget)

BEGIN_MESSAGE_MAP(CClock, CCmdTarget)
	ON_COMMAND(ID_CLOCK_SET,	OnSetTime)
	ON_COMMAND(ID_CLOCK_CHECK, OnCheckTime)
END_MESSAGE_MAP()

CClock::CClock()
{
}

CClock::~CClock()
{
}

////////////////
// Handle commands, Clock | Set Time
//
void CClock::OnSetTime()
{
	NotImplemented();
}

////////////////
// Handle commands, Clock | Check Time
//
void CClock::OnCheckTime()
{
	NotImplemented();
}

void CClock::NotImplemented()
{
	AfxMessageBox(_T("So sorry, I don't know how to do that.\n"));
}
