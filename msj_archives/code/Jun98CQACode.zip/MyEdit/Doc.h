class CMyDoc : public CDocument {
public:
	virtual ~CMyDoc();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnNewDocument();
protected:
	CMyDoc();
	DECLARE_DYNCREATE(CMyDoc)
	DECLARE_MESSAGE_MAP()
};
