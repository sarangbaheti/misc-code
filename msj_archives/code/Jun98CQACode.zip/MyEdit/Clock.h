////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.

//////////////////
// Clock object is a command target that implements its own menu commands.
//
class CClock : public CCmdTarget {
public:
	CClock();
	virtual ~CClock();

protected:
	CMyDoc();
	void NotImplemented();

	DECLARE_DYNAMIC(CClock)
	DECLARE_MESSAGE_MAP()
	void afx_msg OnSetTime();
	void afx_msg OnCheckTime();
};
