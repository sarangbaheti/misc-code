#include "Clock.h"

class CMainFrame : public CFrameWnd {
public:
	CMainFrame();
	virtual ~CMainFrame();

protected:
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
	CClock		m_clock; // clock object

	// command router
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra,
		AFX_CMDHANDLERINFO* pHandlerInfo);

	DECLARE_DYNCREATE(CMainFrame)

	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);

	DECLARE_MESSAGE_MAP()
};
