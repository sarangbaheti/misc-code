////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// To compile, type:
//   cl Animal.cpp
//
// Illustrates need for virtual destructor
// 

#include <iostream.h>

class Animal {
public:
	Animal()  { }
	// remove comments around "virtual" to fix the program
	~Animal() { cout << "bye-bye Animal\n"; }
//	virtual ~Animal() { cout << "bye-bye Animal\n"; }
};

class MadCow : public Animal {
public:
	MadCow()  { }
	~MadCow() { cout << "bye-bye MadCow\n"; }
};

void main()
{
	Animal* pa = new MadCow;
	delete pa; // MadCow destructor isn't called unles its virtual
}
