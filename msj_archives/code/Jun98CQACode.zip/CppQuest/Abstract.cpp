////////////////////////////////////////////////////////////////
// 1998 Microsoft Systems Journal. 
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// To compile, type:
//
//   cl Abstract.cpp
//
// Illustrates pure virtual destructor
// 

#include <iostream.h>

class Animal {
public:
	Animal()  { }
	// pur virtual destructor
	virtual ~Animal() = 0;
};

//////////////////
// This function is called even though it's pure!
//
Animal::~Animal()
{
	cout << "bye-bye Animal";
}

class MadCow : public Animal {
public:
	MadCow()  { }
	~MadCow() { cout << "bye-bye MadCow\n"; }
};

void main()
{
	Animal* pa = new MadCow;
	delete pa;
}

