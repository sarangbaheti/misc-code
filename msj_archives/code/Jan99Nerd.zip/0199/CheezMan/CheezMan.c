/*
    CheezMan.c - (c) 1998, Microsoft Corporation. All Rights Reserved.
    
    1998 James M. Finnegan - Microsoft Systems Journal

    Cheezy Process (and 16-bit task) manager for Windows NT, to demonstrate
    the use of PSAPI and VDMDBG in a manner that is similar to TASKMAN.EXE
*/
#include <windows.h>
#include <vdmdbg.h>
#include "psapi.h"
#include "resource.h"

VOID CenterWindow(HWND hWnd);
BOOL CALLBACK DlgProc(HWND hWnd,UINT uMessage,WPARAM wParam,LPARAM lParam);
void EnumerateProcesses();


HWND ghWnd;


int PASCAL WinMain(HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpszCmdLine,
           int nCmdShow)
{
    static char szAppName[]="CheezMan";


    DialogBox(hInstance,szAppName,0,DlgProc); 

    return 0;
}


VOID CenterWindow(HWND hWnd)
{
    RECT rect;
    WORD wWidth,
         wHeight;
         
         
    GetWindowRect(hWnd,&rect);

    wWidth =GetSystemMetrics(SM_CXSCREEN);
    wHeight=GetSystemMetrics(SM_CYSCREEN);

    MoveWindow(hWnd,(wWidth/2)   - ((rect.right -  rect.left)/2),
                    (wHeight/2)  - ((rect.bottom - rect.top) /2),
                     rect.right  -   rect.left,
			         rect.bottom -   rect.top, 
			         FALSE);
}


BOOL CALLBACK DlgProc(HWND hWnd,UINT uMessage,WPARAM wParam,LPARAM lParam)
{
    static WORD wTimer;

    switch(uMessage)
    {
        case WM_INITDIALOG:
            ghWnd = hWnd;

            // Create a timer to refresh the dialog's contents every
            // 1000 milliseconds.
            wTimer = SetTimer(hWnd, 1, 1000, NULL); 
            CenterWindow(hWnd);
            PostMessage(hWnd,WM_TIMER, 0, 0L);
            return FALSE;
            break;

        case WM_COMMAND:
            switch(wParam)
            {
                case IDB_CLOSE:
                    PostMessage(hWnd,WM_CLOSE,0,0L);
                    break;
            }
            break;

        case WM_TIMER:
            // Clear the listbox
            SendDlgItemMessage(hWnd,IDC_LIST1,LB_RESETCONTENT,0,0L);
            // Refresh the process list
            EnumerateProcesses();
            break;
            
        case WM_CLOSE:
            KillTimer(hWnd,wTimer);
            EndDialog(hWnd, FALSE);
            break;

        default:
            return FALSE;
    }
    
    return TRUE;
}


/*
EnumerateWin16Processes - This is a callback function (referenced by 
                          VDMEnumTaskWOWEx below) that is called in turn
                          for each 16-bit Windows task that is executing in 
                          an NT VDM.
*/
BOOL WINAPI EnumerateWin16Processes(DWORD dwThreadId, WORD hMod16, WORD hTask16,
                PSZ pszModName, PSZ pszFileName, LPARAM lpUserDefined)
{
    char szTemp[80];

    // Indent the task name, to visually show that it is a "child" of the
    // process listed above it
    wsprintf(szTemp,"    %s",pszModName);
    SendDlgItemMessage(ghWnd,IDC_LIST1,LB_ADDSTRING,0,(LONG)(LPSTR)szTemp);

    // Return FALSE to continue enumeration
    return FALSE;
}


void PrintProcessName(DWORD processID)
{
    char szProcessName[MAX_PATH] = "unknown";
    char szTemp[80];


    // Get a handle to the passed-in process ID
    HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ,
                                                       FALSE, processID );

    // Get the process name
    if(hProcess)
    {
        HMODULE hMod;
        DWORD   cbNeeded;

        if(EnumProcessModules(hProcess, &hMod, sizeof(hMod), &cbNeeded))
        {
            GetModuleBaseName(hProcess, hMod, szProcessName, 
                                                    sizeof(szProcessName));
        }
    }

    // Print the process name and ID
    wsprintf(szTemp, "%s   (PID: %u)", szProcessName, processID );
    SendDlgItemMessage(ghWnd,IDC_LIST1,LB_ADDSTRING,0,(LONG)(LPSTR)szTemp);

    // If the process name is NTVDM.EXE, try walking it to see if it is
    // a WOW box.  The callback will not be called if NTVDM is not WOW
    if(!stricmp(szProcessName,"ntvdm.exe"))
    {
        // VDMEnumTaskWOWEx() is NOT documented in the VDMDBG.HLP
        // file -- but it is in VDMDBG.H.  Explanations there make its use
        // clear (and documented!)  Basically, you need modname and filename
        // as additional parameters in the callback.
        VDMEnumTaskWOWEx(processID, EnumerateWin16Processes, 0);
    }

    CloseHandle(hProcess);
}


/*
EnumerateProcesses - Enumerates all process IDs currently running within
                     a system.  The print function (above) will deal with 16-bit 
                     apps.
*/
void EnumerateProcesses()
{
    DWORD        aProcesses[1024],  // Array of process IDs
                 cbNeeded,          // Byte count returned...
                 cProcesses;        // The number of 'em obtained
    unsigned int i;


    // Get a list of all current PIDs running
    if(!EnumProcesses( aProcesses, sizeof(aProcesses), &cbNeeded))
        return;

    // Get the count of PIDs in the array
    cProcesses = cbNeeded / sizeof(DWORD);

    // Print the name and process identifier for each process
    for(i = 0; i < cProcesses; i++)
        PrintProcessName(aProcesses[i]);
}
