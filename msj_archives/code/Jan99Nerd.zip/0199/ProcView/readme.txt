ProcView README - Microsoft Systems Journal, January 1999
November, 1998 - James M. Finnegan

Since ProcView.sys cannot dynamically unload (due to the Process
Structure callbacks), there is no point in dynaloading the driver
with the SCM as was demonstrated in my March, 1998 article.  Therefore, 
you must add ProcView.sys to the registry so you can start it prior to
running ProcView.exe.  In:

HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services

add a key called

ProcView

Under this key, add three values:

ErrorControl: REG_DWORD: 0x1
Start: REG_DWORD: 0x3
Type: REG_DWORD: 0x1

You can alter the Start value, as outlined in figure 14 of the March, 1998 
article.  If you add it as 3 (SERVICE_DEMAND_START), you can manually start
ProcView.sys by typing the following at the command prompt:

net start procview

Ensure that ProcView.sys is located in the %SystemRoot%\system32\drivers
directory.  Once the driver is started, you can then successfully run 
ProcView.exe.



-END-
