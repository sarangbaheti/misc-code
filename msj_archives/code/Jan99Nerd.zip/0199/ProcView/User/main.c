/*
    main.c - (c) 1998, Microsoft Corporation. All Rights Reserved.
    
    1998 James M. Finnegan - Microsoft Systems Journal

    This is the main module for the ProcView Win32 console app.
    This app simply fields triggered events from kernel-mode and 
    retrieves the results that are collected in ProcView.sys.
*/
#include <windows.h>
#include <winioctl.h>
#include <process.h>
#include <stdio.h>
#include <conio.h>
#include "psapi.h"


#define FILE_DEVICE_UNKNOWN             0x00000022
#define IOCTL_UNKNOWN_BASE              FILE_DEVICE_UNKNOWN

#define IOCTL_PROCVIEW_GET_PROCINFO     CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0800, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
#define IOCTL_PROCVIEW_GET_THREADINFO   CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0801, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
#define IOCTL_PROCVIEW_GET_IMAGEINFO    CTL_CODE(IOCTL_UNKNOWN_BASE, 0x0802, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)


// KM Image information structure
typedef struct _IMAGE_INFO 
{
    union 
    {
        ULONG Properties;
        struct 
        {
            ULONG ImageAddressingMode  : 8;  // code addressing mode
            ULONG SystemModeImage      : 1;  // system mode image
            ULONG ImageMappedToAllPids : 1;  // image mapped into all processes
            ULONG Reserved             : 22;
        };
    };
    PVOID       ImageBase;
    ULONG       ImageSelector;
    size_t      ImageSize;
    ULONG       ImageSectionNumber;
} IMAGE_INFO, *PIMAGE_INFO;

// Structure for Process callback information
typedef struct _CallbackInfo
{
    HANDLE  ParentId;
    HANDLE  ProcessId;
    BOOLEAN Create;
}CALLBACK_INFO, *PCALLBACK_INFO;

// Structure for Thread callback information
typedef struct _CallbackThreadInfo
{
    HANDLE  ProcessId;
    HANDLE  ThreadId;
    BOOLEAN Create;
}CALLBACK_THREAD_INFO, *PCALLBACK_THREAD_INFO;

// Structure for image loading information
typedef struct _CallbackImageInfo
{
    UCHAR      ImageNameA[255];
    HANDLE     IProcessId;
    IMAGE_INFO ImageInfo;
}CALLBACK_IMAGE_INFO, *PCALLBACK_IMAGE_INFO;


// Function to return the module name of the passed in PID...
char *PrintProcessName(HANDLE processID);

static HANDLE hDriver = INVALID_HANDLE_VALUE;


void ProcessRoutine()
{
    HANDLE ProcessEvent;
    DWORD dwBytesReturned;
    BOOL  bReturnCode = FALSE;
    OVERLAPPED ov={0};
    CALLBACK_INFO CallbackInfo, CallbackTemp;


    // Attach to KM-created event handle
    ProcessEvent = OpenEvent(SYNCHRONIZE, FALSE, "ProcViewProcessEvent");

    while(1)
    {
        WaitForSingleObject(ProcessEvent,INFINITE);

        // Create an event handle for async notification
        // from our driver
        ov.hEvent = CreateEvent(NULL,  // Default security
                                TRUE,  // Manual reset
                                FALSE, // non-signaled state
                                NULL); // No name

        // Get the process info....
        bReturnCode = DeviceIoControl(hDriver,
                                  IOCTL_PROCVIEW_GET_PROCINFO,
                                  0, 0,
                                  &CallbackInfo, sizeof(CallbackInfo),
                                  &dwBytesReturned,
                                  &ov);
        
        // Wait here for the event handle to be set, indicating
        // that the IOCTL processing is complete.
        bReturnCode = GetOverlappedResult(hDriver, &ov,
                                          &dwBytesReturned, TRUE);

        CloseHandle(ov.hEvent);

        // Our ability to retrieve data from KM may exceed the driver's ability
        // to clear the event.  This will result in us getting the same data
        // multiple times.  Since we can't clear a KM event from user mode,
        // we'll need to save the previously returned results and compare
        // them here.  If we already have this data, we throw it away...
        if((CallbackTemp.ParentId  != CallbackInfo.ParentId) ||
           (CallbackTemp.ProcessId != CallbackInfo.ProcessId) ||
           (CallbackTemp.Create    != CallbackInfo.Create))
        {
            if(CallbackInfo.Create)
                printf("Process creation notification: PID: %lx (%s)\n", CallbackInfo.ProcessId, PrintProcessName(CallbackInfo.ProcessId));
            else
                printf("Process termination notification: PID: %lx\n", CallbackInfo.ProcessId);
        }

        // Save this data for comparison on the next pass...
        CallbackTemp = CallbackInfo;
    }
}


void ThreadRoutine()
{
    HANDLE ThreadEvent;
    CALLBACK_THREAD_INFO CallbackInfo, CallbackTemp;
    DWORD dwBytesReturned;
    BOOL  bReturnCode = FALSE;
    OVERLAPPED ov={0};


    // Attach to KM-created event handle
    ThreadEvent = OpenEvent(SYNCHRONIZE, FALSE, "ProcViewThreadEvent");

    while(1)
    {
        WaitForSingleObject(ThreadEvent,INFINITE);

        // Create an event handle for async notification
        // from our driver
        ov.hEvent = CreateEvent(NULL,  // Default security
                                TRUE,  // Manual reset
                                FALSE, // non-signaled state
                                NULL); // No name

        // Get the thread info....
        bReturnCode = DeviceIoControl(hDriver,
                          IOCTL_PROCVIEW_GET_THREADINFO,
                          0, 0,
                          &CallbackInfo, sizeof(CallbackInfo),
                          &dwBytesReturned,
                          &ov);
        
        // Wait here for the event handle to be set, indicating
        // that the IOCTL processing is complete.
        bReturnCode = GetOverlappedResult(hDriver, &ov,
                                              &dwBytesReturned, TRUE);

        CloseHandle(ov.hEvent);
                    
        // Our ability to retrieve data from KM may exceed the driver's ability
        // to clear the event.  This will result in us getting the same data
        // multiple times.  Since we can't clear a KM event from user mode,
        // we'll need to save the previously returned results and compare
        // them here.  If we already have this data, we throw it away...
        if((CallbackTemp.ProcessId != CallbackInfo.ProcessId) ||
           (CallbackTemp.ThreadId  != CallbackInfo.ThreadId) ||
           (CallbackTemp.Create    != CallbackInfo.Create))
        {
            if(CallbackInfo.Create)
                printf("Thread creation notification: PID: %lx (%s) TID: %lx\n",CallbackInfo.ProcessId, PrintProcessName(CallbackInfo.ProcessId), CallbackInfo.ThreadId);
            else
                printf("Thread termination notification: PID: %lx (%s) TID: %lx\n",CallbackInfo.ProcessId, PrintProcessName(CallbackInfo.ProcessId), CallbackInfo.ThreadId);
        }

        // Save this data for comparison on the next pass...
        CallbackTemp = CallbackInfo;
    }
}


void ImageRoutine()
{
    HANDLE ImageEvent;
    CALLBACK_IMAGE_INFO CallbackImageInfo, CallbackImageTemp;
    DWORD dwBytesReturned;
    BOOL  bReturnCode = FALSE;
    OVERLAPPED ov={0};


    // Attach to KM-created event handle
    ImageEvent = OpenEvent(SYNCHRONIZE, FALSE, "ProcViewImageEvent");

    while(1)
    {
        WaitForSingleObject(ImageEvent,INFINITE);

        // Create an event handle for async notification
        // from our driver
        ov.hEvent = CreateEvent(NULL,  // Default security
                                TRUE,  // Manual reset
                                FALSE, // non-signaled state
                                NULL); // No name

        // Get the image info....
        bReturnCode = DeviceIoControl(hDriver,
                          IOCTL_PROCVIEW_GET_IMAGEINFO,
                          0, 0,
                          &CallbackImageInfo, sizeof(CallbackImageInfo),
                          &dwBytesReturned,
                          &ov);
        
        // Wait here for the event handle to be set, indicating
        // that the IOCTL processing is complete.
        bReturnCode = GetOverlappedResult(hDriver, &ov,
                                              &dwBytesReturned, TRUE);

        CloseHandle(ov.hEvent);

        // Our ability to retrieve data from KM may exceed the driver's ability
        // to clear the event.  This will result in us getting the same data
        // multiple times.  Since we can't clear a KM event from user mode,
        // we'll need to save the previously returned results and compare
        // them here.  If we already have this data, we throw it away...
        if((CallbackImageTemp.IProcessId          != CallbackImageInfo.IProcessId) ||
           (CallbackImageTemp.ImageInfo.ImageBase != CallbackImageInfo.ImageInfo.ImageBase))
        {
            printf("Image callback: PID: %lx (%s)  Base: 0x%lx\n",CallbackImageInfo.IProcessId,
                                                              PrintProcessName(CallbackImageInfo.IProcessId),
                                                              CallbackImageInfo.ImageInfo.ImageBase);
            printf("  Image name: %s\n", CallbackImageInfo.ImageNameA);
        }

        // Save this data for comparison on the next pass...
        CallbackImageTemp = CallbackImageInfo;
    }
}


void main()
{
    static OSVERSIONINFO os={0};


    printf("Windows 2000(R) Kernel-Mode Process Viewer - James M. Finnegan, 1998\n");
    printf("Copyright (c)1998 Microsoft Corporation.  All Rights Reserved.\n\n");

    os.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
    GetVersionEx(&os);

    // If we're under NT...
    if(os.dwPlatformId == VER_PLATFORM_WIN32_NT)
    {
        // Try opening the device driver (in case it's static).  We'll
        // Deal with a failure in a moment...
        hDriver = CreateFile("\\\\.\\ProcView",
                             GENERIC_READ | GENERIC_WRITE, 
                             FILE_SHARE_READ | FILE_SHARE_WRITE,
                             0,                     // Default security
                             OPEN_EXISTING,
                             FILE_FLAG_OVERLAPPED,  // Perform asynchronous I/O
                             0);                    // No template
        
        // If the device driver wasn't started, let's dynamically load it
        // here...
        if(hDriver == INVALID_HANDLE_VALUE)
        {
            printf("PROCVIEW.SYS is not loaded or is not functioning properly.  Please reinstall\n");
            printf("and start PROCVIEW.SYS to execute this application.  Terminating.\n\n");

            return;
        }
    }
    else
    {
        printf("This is not Windows NT or Windows 2000!  Terminating...\n\n");
    }

    printf("Press any key to terminate logging...\n\n");

    // Kick off our threads and wait forever...
    _beginthread((void *)&ProcessRoutine,0,0);
    _beginthread((void *)&ThreadRoutine,0,0);
    _beginthread((void *)&ImageRoutine,0,0);
    
    
    while(!kbhit())
    {
    }

    getch();

    CloseHandle(hDriver);
}


char *PrintProcessName(HANDLE processID)
{
    static char szProcessName[MAX_PATH];
    HANDLE hProcess;

    HMODULE hMod = 0;
    DWORD   cbNeeded = 0;


    strcpy(szProcessName, "unknown");
    
    // Get a handle to the passed-in process ID
    hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ,
                                                       FALSE, (ULONG)processID );

    if(hProcess)
    {
        // AET - make it count :-) Get the first mod handle...
        if(EnumProcessModules(hProcess, &hMod, sizeof(hMod), &cbNeeded))
        {
            // Get the module's name
            GetModuleBaseName(hProcess, hMod, szProcessName, 
                                                    sizeof(szProcessName));
        }
    }

    CloseHandle(hProcess);

    return szProcessName;
}
