//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Polygon.rc
//
#define IDS_PROJNAME                    100
#define IDR_PolyCtl                     101
#define IDS_TITLEPolyProp               102
#define IDS_HELPFILEPolyProp            103
#define IDS_DOCSTRINGPolyProp           104
#define IDR_PolyProp                    105
#define IDS_ERROR                       105
#define IDD_PolyProp                    106
#define IDC_SIDES                       201

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        205
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
