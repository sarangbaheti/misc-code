// Factory.cpp: implementation of the CCookieFactory class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Cookie.h"
#include "FortuneCookie.h"
#include "Factory.h"

STDMETHODIMP CCookieFactory::QueryInterface(const IID& iid, void** ppv)
{    
	if ((iid == IID_IUnknown) || (iid == IID_IClassFactory))
	{
		*ppv = static_cast<IClassFactory*>(this); 
	}
	else
	{
		*ppv = NULL;
		return E_NOINTERFACE;
	}
	reinterpret_cast<IUnknown*>(*ppv)->AddRef();
	return S_OK ;
}

STDMETHODIMP_(ULONG) CCookieFactory::AddRef()
{
	LockModule();
	return 2;
}

STDMETHODIMP_(ULONG) CCookieFactory::Release() 
{
	UnlockModule();
	return 1;
}

STDMETHODIMP CCookieFactory::CreateInstance(
	LPUNKNOWN pUnknownOuter, REFIID iid, void** ppv) 
{
	if (pUnknownOuter != NULL)
		return CLASS_E_NOAGGREGATION;

	CFortuneCookie* pObject = new CFortuneCookie;
	if (pObject == NULL)
		return E_OUTOFMEMORY;

	pObject->AddRef();
	HRESULT hr = pObject->QueryInterface(iid, ppv);
	pObject->Release();

	return hr;
}

STDMETHODIMP CCookieFactory::LockServer(BOOL bLock) 
{
	if (bLock)
		LockModule();
	else
		UnlockModule();

	return S_OK;
}

