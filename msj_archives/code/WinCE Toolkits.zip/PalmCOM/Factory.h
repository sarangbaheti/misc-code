// Factory.h: interface for the CCookieFactory class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

class CCookieFactory : public IClassFactory
{
public:
	// IUnknown
	STDMETHODIMP QueryInterface(REFIID riid, void ** ppvObject);
	STDMETHODIMP_(ULONG) AddRef();
	STDMETHODIMP_(ULONG) Release();
	
	// IClassFactory
	STDMETHODIMP CreateInstance(LPUNKNOWN pUnkOuter,
		REFIID riid, void** ppvObj);
	STDMETHODIMP LockServer(BOOL fLock);
};
