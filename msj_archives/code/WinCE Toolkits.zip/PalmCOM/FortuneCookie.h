// FortuneCookie.h: interface for the FortuneCookie class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

class CFortuneCookie : public IFortuneCookie
{
	static WCHAR* gFortunes[];
	WCHAR sLastFortune[_MAX_PATH];
	long m_lRefCount;

public:
	CFortuneCookie();
	~CFortuneCookie();

	STDMETHODIMP QueryInterface(REFIID riid, void** ppv);
	STDMETHODIMP_(ULONG) AddRef(void);
	STDMETHODIMP_(ULONG) Release(void);

	STDMETHODIMP SetSeed(int nSeed);
	STDMETHODIMP GetFortune(BSTR* pbstr);
};
