// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#pragma once
#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxcmn.h>			// MFC support for Windows Common Controls
#include <ole2.h>

// The following lines are a hack to account for the fact that
// we actually do not have an updated version of <rpcndr.h>

#define __RPCNDR_H_VERSION__
#define MIDL_INTERFACE(x)   struct __declspec(uuid(x)) __declspec(novtable)

// These lines include the necessary COM libraries

#pragma comment(lib, "corelibc.lib")
#if defined(_WIN32_WCE_EMULATION) && (_WIN32_WCE < 210) 
	#pragma comment(lib, "ole32m.lib")
	#pragma comment(lib, "oleautm.lib")
#else
	#pragma comment(lib, "ole32.lib")
	#pragma comment(lib, "oleaut32.lib")
#endif // _WIN32_WCE_EMULATION

// This is a hack for Windows CE 2.01, which defines BSTR in wtypes.h
// yet does not support the SysXXXString functions.

#if !defined( _OLEAUTO_H_ )
inline BSTR SysAllocString(const OLECHAR* pText)
{
	BSTR bstrText = (BSTR) malloc(lstrlen(pText) * sizeof(OLECHAR) + 1);
	lstrcpy(bstrText, pText);
	return bstrText;
}
inline HRESULT SysFreeString(BSTR bstrText)
{
	free(bstrText);
	return S_OK;
}
#endif
