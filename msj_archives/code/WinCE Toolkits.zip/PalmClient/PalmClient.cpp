// PalmClient.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "PalmClient.h"
#include "PalmClientDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPalmClientApp

BEGIN_MESSAGE_MAP(CPalmClientApp, CWinApp)
	//{{AFX_MSG_MAP(CPalmClientApp)
	//}}AFX_MSG
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPalmClientApp construction

CPalmClientApp::CPalmClientApp()
	: CWinApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CPalmClientApp object

CPalmClientApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CPalmClientApp initialization

BOOL CPalmClientApp::InitInstance()
{
	HRESULT hr = ::CoInitializeEx(NULL, COINIT_MULTITHREADED);

	// Standard initialization

	CPalmClientDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
