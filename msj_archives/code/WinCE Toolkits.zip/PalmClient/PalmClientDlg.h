// PalmClientDlg.h : header file
//

#pragma once
interface IFortuneCookie;

/////////////////////////////////////////////////////////////////////////////
// CPalmClientDlg dialog

class CPalmClientDlg : public CDialog
{

public:
	CPalmClientDlg(CWnd* pParent = NULL);	// standard constructor
	~CPalmClientDlg();

protected:
	IFortuneCookie* m_pCookie;
	HICON m_hIcon;

	//{{AFX_DATA(CPalmClientDlg)
	enum { IDD = IDD_PALMCLIENT_DIALOG };
	//}}AFX_DATA
	//{{AFX_VIRTUAL(CPalmClientDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL
	//{{AFX_MSG(CPalmClientDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnNextFortune();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
