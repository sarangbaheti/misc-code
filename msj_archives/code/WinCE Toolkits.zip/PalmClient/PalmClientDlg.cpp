// PalmClientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PalmClient.h"
#include "PalmClientDlg.h"

#include "Cookie.h"
#include "Cookie_i.c"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPalmClientDlg dialog

CPalmClientDlg::CPalmClientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPalmClientDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPalmClientDlg)
	//}}AFX_DATA_INIT

	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pCookie = NULL;
}


CPalmClientDlg::~CPalmClientDlg()
{
	if (m_pCookie)
		m_pCookie->Release();
}

void CPalmClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPalmClientDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPalmClientDlg, CDialog)
	//{{AFX_MSG_MAP(CPalmClientDlg)
	ON_BN_CLICKED(IDC_NEXT, OnNextFortune)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPalmClientDlg message handlers

BOOL CPalmClientDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	CenterWindow(GetDesktopWindow());	// center to the hpc screen

	HRESULT hr = ::CoCreateInstance(CLSID_FortuneCookie, NULL,
		CLSCTX_INPROC_SERVER, IID_IFortuneCookie, (LPVOID*) &m_pCookie);
	GetDlgItem(IDC_NEXT)->EnableWindow(SUCCEEDED(hr));
	if (SUCCEEDED(hr))
		OnNextFortune();

	return TRUE;
}

void CPalmClientDlg::OnNextFortune() 
{
	BSTR bstrText;
	HRESULT hr = m_pCookie->GetFortune(&bstrText);
	SetDlgItemText(IDC_FORTUNE, bstrText);
	SysFreeString(bstrText);
}
