// DataView.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "RegKey.h"
#include "DataView.h"
#include "RegView.h"
#include "EditValue.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDataView

IMPLEMENT_DYNCREATE(CDataView, CListView)
BEGIN_MESSAGE_MAP(CDataView, CListView)
	//{{AFX_MSG_MAP(CDataView)
	ON_WM_DESTROY()
	ON_WM_LBUTTONDOWN()
	ON_WM_KEYDOWN()
	ON_COMMAND(ID_EDIT_MODIFY, OnModify)
	ON_COMMAND(ID_EDIT_RENAME, OnRename)
	ON_COMMAND(ID_EDIT_DELETE, OnDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_MODIFY, OnUpdateModify)
	ON_UPDATE_COMMAND_UI(ID_EDIT_RENAME, OnUpdateRename)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, OnUpdateDelete)
	ON_NOTIFY_REFLECT(LVN_ENDLABELEDIT, OnEndLabelEdit)
	ON_COMMAND(ID_NEW_DWORD, OnNewDWORD)
	ON_COMMAND(ID_NEW_STRING, OnNewString)
	ON_NOTIFY_REFLECT(NM_DBLCLK, OnDoubleClick)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CDataView::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style |= LVS_REPORT|LVS_EDITLABELS;
	return CListView::PreCreateWindow(cs);
}

void CDataView::OnInitialUpdate() 
{
	CListView::OnInitialUpdate();

	// Set default column widths

	m_colWidths.SetSize(2);
	m_colWidths[0] = 100;
	m_colWidths[1] = 250;

	// Update column widths from registry

	PersistColumnWidths(FALSE);

	// Create the columns

	CListCtrl& list = GetListCtrl();
	list.InsertColumn(0, L"Name", LVCFMT_LEFT, m_colWidths[0]);
	list.InsertColumn(1, L"Data", LVCFMT_LEFT, m_colWidths[1]);
}

void CDataView::OnDestroy() 
{
	PersistColumnWidths(TRUE);
	CListView::OnDestroy();
}

void CDataView::PersistColumnWidths(BOOL bStore)
{
	CWinApp* pApp = AfxGetApp();
	for (int nLoop = 0; nLoop < m_colWidths.GetSize(); nLoop++)
	{
		CString strEntry;
		strEntry.Format(L"ColWidth%d", nLoop);
		if (bStore)
		{
			pApp->WriteProfileInt(L"DataView", strEntry,
				GetListCtrl().GetColumnWidth(nLoop));
		}
		else
		{
			m_colWidths[nLoop] = pApp->GetProfileInt(L"DataView",
				strEntry, m_colWidths[nLoop]);
		}
	}
}

CString CDataView::FormatValue(CRegKey& key, CString strName, DWORD dwType)
{
	CString strValue;

	switch(dwType)
	{
		case REG_DWORD:
		{
			DWORD dwValue;
			key.QueryValue(strName, dwValue);
			strValue.Format(L"0x%.8x (%d)", dwValue, dwValue);
			return strValue;
		}
		case REG_EXPAND_SZ:
		case REG_MULTI_SZ:
		case REG_SZ:
		{
			CString strTemp;
			key.QueryValue(strName, strTemp);
			strValue.Format(L"\"%s\"\0", strTemp);
			return strValue;
		}
		case REG_BINARY:
		{
			DWORD dwCount = _MAX_PATH;
			BYTE data[_MAX_PATH];
			key.QueryValue(strName, data, dwCount);
			for (DWORD dwLoop = 0; dwLoop < dwCount; dwLoop++)
				strValue.Format(L"%s %.2hx", strValue, data[dwLoop]);
			return strValue;
		}
	}

	return L"Unknown data format";
}

BOOL CDataView::DisplayOnMatch(CRegKey& key, TFINDDATA& findData)
{
	DWORD dwIndex = 0, dwType;
	CString strName, strValue;
	while (key.EnumValue(dwIndex, strName, &dwType) == ERROR_SUCCESS)
	{
		if (findData.m_bMatchValues)
		{
			if (IsMatchingString(strName,
				findData.m_strText,
				findData.m_bMatchExact))
			{
				DisplayKey(key);
				return TRUE;
			}
		}

		CString strValue(FormatValue(key, strName, dwType));

		if (findData.m_bMatchData)
		{
			if (IsMatchingString(strValue,
				findData.m_strText,
				findData.m_bMatchExact))
			{
				DisplayKey(key);
				return TRUE;
			}
		}
	}

	return FALSE;
}

void CDataView::DisplayKey(CRegKey& key)
{
	CListCtrl& list = GetListCtrl();
	list.DeleteAllItems();

	DWORD dwType, dwIndex = 0;
	CString strName, strValue;
	while (key.EnumValue(dwIndex, strName, &dwType) == ERROR_SUCCESS)
	{
		CString strValue = FormatValue(key, strName, dwType);
		int nCount = list.GetItemCount();
		list.InsertItem(nCount, strName);
		list.SetItemText(nCount, 1, strValue);
	}

	list.SetItemState(0, LVIS_FOCUSED, LVIS_FOCUSED);
	list.SetItemState(0, LVIS_SELECTED, LVIS_SELECTED);
}

CRegView* CDataView::GetRegView()
{
	CSplitterWnd *pWnd = (CSplitterWnd *) GetParent();
	return (CRegView*) pWnd->GetPane(0, 0);
}

void CDataView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CSplitterWnd *pWnd = (CSplitterWnd *) GetParent();
#ifdef _WIN32_WCE_PSPC
	pWnd->SetActivePane(1, 0);
#else
	pWnd->SetActivePane(0, 1);
#endif

	CListView::OnLButtonDown(nFlags, point);
}

void CDataView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	switch(nChar)
	{
		case VK_TAB:
		{
			CSplitterWnd *pWnd = (CSplitterWnd *) GetParent();
			pWnd->SetActivePane(0, 0);
			break;
		}
	}

	CListView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CDataView::OnModify() 
{
	CListCtrl& list = GetListCtrl();
	int nItem = list.GetNextItem(-1, LVNI_SELECTED);

	CRegKey key;
	DWORD dwType;
	VERIFY( GetRegView()->GetKeyFromActiveItem(key) );
	VERIFY( key.QueryType(list.GetItemText(nItem, 0), &dwType) );	

	CString strValue;
	CString strName(list.GetItemText(nItem, 0));

	switch(dwType)
	{
		case REG_DWORD:
			key.QueryValue(strName, dwType);
			strValue.Format(L"%d", dwType);
			break;

		case REG_EXPAND_SZ:
		case REG_MULTI_SZ:
		case REG_SZ:
			key.QueryValue(strName, strValue);
			break;

		case REG_BINARY:
		default:
			AfxMessageBox(L"Cannot modify binary data.");
			return;
	}

	CEditValueDlg dlg(this, strName, strValue, FALSE);
	if (dlg.DoModal() == IDCANCEL)
		return;

	strValue = dlg.m_strData;
	switch(dwType)
	{
		case REG_DWORD:
			key.SetValue(strName, _wtoi(strValue));
			break;

		case REG_EXPAND_SZ:
		case REG_MULTI_SZ:
		case REG_SZ:
			key.SetValue(strName, strValue);
			break;
	}

	list.SetItemText(nItem, 1, FormatValue(key, strName, dwType));
}

void CDataView::OnRename() 
{
	SetFocus();

	CListCtrl& list = GetListCtrl();
	list.EditLabel(list.GetNextItem(-1, LVNI_SELECTED));
}

void CDataView::OnDelete() 
{
	CListCtrl& list = GetListCtrl();
	int nItem = list.GetNextItem(-1, LVNI_SELECTED);

	CRegKey key;
	VERIFY( GetRegView()->GetKeyFromActiveItem(key) );
	key.DeleteValue(list.GetItemText(nItem, 0));
	list.DeleteItem(nItem);

	nItem = max(nItem, list.GetItemCount() - 1);
	list.SetItemState(nItem, LVIS_FOCUSED, LVIS_FOCUSED);
	list.SetItemState(nItem, LVIS_SELECTED, LVIS_SELECTED);
}

void CDataView::OnNewDWORD() 
{
	CEditValueDlg dlg(this, L"NewValue", L"0", TRUE);
	if (dlg.DoModal() == IDCANCEL)
		return;

	CRegKey key;
	VERIFY( GetRegView()->GetKeyFromActiveItem(key) );
	key.SetValue(dlg.m_strName, ::_wtoi(dlg.m_strData));	

	DisplayKey(key);
}

void CDataView::OnNewString() 
{
	CEditValueDlg dlg(this, L"NewValue", L"NewData", TRUE);
	if (dlg.DoModal() == IDCANCEL)
		return;

	CRegKey key;
	VERIFY( GetRegView()->GetKeyFromActiveItem(key) );
	key.SetValue(dlg.m_strName, dlg.m_strData);	

	DisplayKey(key);
}

void CDataView::OnEndLabelEdit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CListCtrl& list = GetListCtrl();
	LV_DISPINFO* info = (LV_DISPINFO*)pNMHDR;
	LPCTSTR lpNewText = info->item.pszText;
	int nItem = info->item.iItem;
	*pResult = FALSE;

	CRegKey key;
	VERIFY( GetRegView()->GetKeyFromActiveItem(key) );
	if (lpNewText == NULL)
	{
		if (key == NULL)
			list.DeleteItem(nItem);

		return;
	}

	if (key.RenameValue(list.GetItemText(nItem, 0), lpNewText))
		*pResult = TRUE;
	else
	{
		::AfxMessageBox(L"Could not rename key.",
			MB_OK|MB_ICONINFORMATION);
	}
}

void CDataView::OnUpdateRename(CCmdUI* pCmdUI) 
{
	CListCtrl& list = GetListCtrl();
	int nItem = list.GetNextItem(-1, LVNI_SELECTED);
	pCmdUI->Enable(nItem != -1);	
}

void CDataView::OnUpdateDelete(CCmdUI* pCmdUI) 
{
	CListCtrl& list = GetListCtrl();
	int nItem = list.GetNextItem(-1, LVNI_SELECTED);
	pCmdUI->Enable(nItem != -1);	
}

void CDataView::OnUpdateModify(CCmdUI* pCmdUI) 
{
	CListCtrl& list = GetListCtrl();
	int nItem = list.GetNextItem(-1, LVNI_SELECTED);
	pCmdUI->Enable(nItem != -1);	
}

void CDataView::OnDoubleClick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CListCtrl& list = GetListCtrl();
	int nItem = list.GetNextItem(-1, LVNI_SELECTED);
	if (nItem != -1)
		OnModify();	
}
