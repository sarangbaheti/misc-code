// EditValue.h : header file
//

#pragma once

/////////////////////////////////////////////////////////////////////////////
// CEditValueDlg dialog

class CEditValueDlg : public CDialog
{
public:
	CEditValueDlg(CWnd*, CString, CString, BOOL bEditName);
	//{{AFX_DATA(CEditValueDlg)
	enum { IDD = IDD_EDIT_VALUE };
	CString	m_strData;
	CString	m_strName;
	//}}AFX_DATA

protected:
	BOOL m_bEditName;

	//{{AFX_VIRTUAL(CEditValueDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL
	//{{AFX_MSG(CEditValueDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
