// FindDialog.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "FindDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFindDialog dialog

CFindDialog::CFindDialog(TFINDDATA& data, CWnd* pParent)
: CDialog(CFindDialog::IDD, pParent), m_data(data)
{
	CWinApp* pApp = AfxGetApp();
	m_data.m_strText = pApp->GetProfileString(L"FindXYZZY", L"FindText", L"");
	m_data.m_bMatchKeys = pApp->GetProfileInt(L"FindXYZZY", L"Keys", TRUE);
	m_data.m_bMatchValues = pApp->GetProfileInt(L"FindXYZZY", L"Values", TRUE);
	m_data.m_bMatchData = pApp->GetProfileInt(L"FindXYZZY", L"Data", TRUE);
	m_data.m_bMatchExact = pApp->GetProfileInt(L"FindXYZZY", L"Exact", FALSE);

	//{{AFX_DATA_INIT(CFindDialog)
	//}}AFX_DATA_INIT
}

CFindDialog::~CFindDialog()
{
	CWinApp* pApp = AfxGetApp();
	pApp->WriteProfileString(L"FindXYZZY", L"FindText", m_data.m_strText);
	pApp->WriteProfileInt(L"FindXYZZY", L"Keys", m_data.m_bMatchKeys);
	pApp->WriteProfileInt(L"FindXYZZY", L"Values", m_data.m_bMatchValues);
	pApp->WriteProfileInt(L"FindXYZZY", L"Data", m_data.m_bMatchData);
	pApp->WriteProfileInt(L"FindXYZZY", L"Exact", m_data.m_bMatchExact);
}

BEGIN_MESSAGE_MAP(CFindDialog, CDialog)
	//{{AFX_MSG_MAP(CFindDialog)
	ON_EN_CHANGE(IDC_EDIT_FIND, OnChangeEditFind)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CFindDialog::DoDataExchange(CDataExchange* pDX) 
{
	CDialog::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_EDIT_FIND, m_data.m_strText);
	DDX_Check(pDX, IDC_MATCH_KEYS, m_data.m_bMatchKeys);
	DDX_Check(pDX, IDC_MATCH_VALUES, m_data.m_bMatchValues);
	DDX_Check(pDX, IDC_MATCH_DATA, m_data.m_bMatchData);
	DDX_Check(pDX, IDC_MATCH_EXACT, m_data.m_bMatchExact);

	//{{AFX_DATA_MAP(CFindDialog)
	//}}AFX_DATA_MAP
}

BOOL CFindDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	GetDlgItem(IDOK)->EnableWindow(m_data.m_strText.GetLength());
	return TRUE;
}

void CFindDialog::OnChangeEditFind() 
{
	CString strText;
	GetDlgItemText(IDC_EDIT_FIND, strText);
	GetDlgItem(IDOK)->EnableWindow(strText.GetLength());
}
