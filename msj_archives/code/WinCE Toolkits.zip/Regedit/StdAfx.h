// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#pragma once
#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxcview.h>
#include <afxcmn.h>			// MFC support for Windows Common Controls
#include <afxtempl.h>

struct TFINDDATA
{
	TFINDDATA(): m_nLastItem(0) {}

	CString	m_strText;
	BOOL	m_bMatchKeys;
	BOOL	m_bMatchValues;
	BOOL	m_bMatchData;
	BOOL	m_bMatchExact;
	UINT	m_nLastItem;
};

inline BOOL IsMatchingString(CString strText, CString strSub, BOOL bExact)
{
	strText.MakeLower();
	strSub.MakeLower();

	if (bExact)
		return (strText == strSub);

	return (strText.Find(strSub) != -1);
}
