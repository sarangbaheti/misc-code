// DataView.h : header file
//

#pragma once

class CRegView;

class CDataView : public CListView
{
	CArray<int, int> m_colWidths;

public:
	void DisplayKey(CRegKey& key);
	BOOL DisplayOnMatch(CRegKey& key, TFINDDATA& findData);

protected:
	CRegView* GetRegView();
	void PersistColumnWidths(BOOL bStore);
	CString FormatValue(CRegKey& key, CString strName, DWORD dwType);

	DECLARE_DYNCREATE(CDataView)
	DECLARE_MESSAGE_MAP()

	//{{AFX_VIRTUAL(CDataView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL
	//{{AFX_MSG(CDataView)
	afx_msg void OnDestroy();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnModify();
	afx_msg void OnRename();
	afx_msg void OnDelete();
	afx_msg void OnUpdateModify(CCmdUI* pCmdUI);
	afx_msg void OnUpdateRename(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDelete(CCmdUI* pCmdUI);
	afx_msg void OnEndLabelEdit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnNewDWORD();
	afx_msg void OnNewString();
	afx_msg void OnDoubleClick(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
};
