// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#pragma once

class CMainFrame : public CFrameWnd
{
protected:
	CSplitterWnd m_wndSplitter;

	DECLARE_DYNCREATE(CMainFrame)
	DECLARE_MESSAGE_MAP()

	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	//}}AFX_VIRTUAL
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	afx_msg void OnRegViewItem(UINT nMsg);
	afx_msg void OnDataViewItem(UINT nMsg);
	//}}AFX_MSG
};
