//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Regedit.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDB_IMAGES                      130
#define IDD_FIND_PALM                   131
#define IDD_FIND                        132
#define IDD_EDIT_VALUE                  133
#define IDC_EDIT_FIND                   1000
#define IDC_MATCH_KEYS                  1001
#define IDC_MATCH_VALUES                1002
#define IDC_MATCH_EXACT                 1003
#define IDC_MATCH_DATA                  1004
#define IDC_EDIT_NAME                   1005
#define IDC_EDIT_DATA                   1006
#define ID_VIEW_REFRESH                 32771
#define ID_EDIT_MODIFY                  32772
#define ID_NEW_KEY                      32773
#define ID_NEW_STRING                   32774
#define ID_NEW_DWORD                    32775
#define ID_EDIT_DELETE                  32776
#define ID_EDIT_FINDNEXT                32777
#define ID_VIEW_ICONS                   32783
#define ID_EDIT_RENAME                  32784

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
