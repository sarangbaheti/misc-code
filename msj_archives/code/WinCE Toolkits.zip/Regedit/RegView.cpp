// RegView.cpp : implementation of the CRegView class
//

#include "stdafx.h"
#include "resource.h"
#include "RegKey.h"
#include "RegView.h"

#include "FindDialog.h"
#include "DataView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRegView

IMPLEMENT_DYNCREATE(CRegView, CTreeView)
BEGIN_MESSAGE_MAP(CRegView, CTreeView)
	//{{AFX_MSG_MAP(CRegView)
	ON_WM_DESTROY()
	ON_NOTIFY_REFLECT(TVN_SELCHANGED, OnSelChanged)
	ON_NOTIFY_REFLECT(TVN_ENDLABELEDIT, OnEndLabelEdit)
	ON_NOTIFY_REFLECT(TVN_BEGINLABELEDIT, OnBeginLabelEdit)
	ON_UPDATE_COMMAND_UI(ID_NEW_KEY, OnUpdateMenuItem)
	ON_UPDATE_COMMAND_UI(ID_VIEW_ICONS, OnUpdateViewIcons)
	ON_COMMAND(ID_NEW_KEY, OnNewKey)
	ON_COMMAND(ID_EDIT_DELETE, OnDelete)
	ON_COMMAND(ID_EDIT_RENAME, OnRename)
	ON_COMMAND(ID_EDIT_FIND, OnFind)
	ON_COMMAND(ID_EDIT_FINDNEXT, OnFindNext)
	ON_COMMAND(ID_VIEW_ICONS, OnViewIcons)
	ON_COMMAND(ID_VIEW_REFRESH, OnViewRefresh)
	ON_WM_LBUTTONDOWN()
	ON_WM_KEYDOWN()
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, OnUpdateMenuItem)
	ON_UPDATE_COMMAND_UI(ID_EDIT_RENAME, OnUpdateMenuItem)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRegView construction/destruction

BOOL CRegView::PreCreateWindow(CREATESTRUCT& cs)
{
	m_imageList.Create(IDB_IMAGES, 16, 1, RGB(255, 255, 255));
	cs.style |= TVS_HASLINES|TVS_LINESATROOT|TVS_HASBUTTONS|TVS_EDITLABELS;
	return CTreeView::PreCreateWindow(cs);
}

void CRegView::OnDestroy() 
{
	AfxGetApp()->WriteProfileInt(L"RegView", L"ShowIcons", m_bShowIcons);
	CTreeView::OnDestroy();
}

void CRegView::OnInitialUpdate()
{
	CTreeView::OnInitialUpdate();
	CWaitCursor wait;

#ifdef _WIN32_WCE_PSPC
	m_bShowIcons = AfxGetApp()->GetProfileInt(
			L"RegView", L"ShowIcons", FALSE);
#else
	m_bShowIcons = AfxGetApp()->GetProfileInt(
			L"RegView", L"ShowIcons", TRUE);
#endif
	
	CTreeCtrl& tree = GetTreeCtrl();
	tree.SetImageList(m_bShowIcons ? &m_imageList : NULL, TVSIL_NORMAL);

	tree.DeleteAllItems();
	HTREEITEM hRoot = tree.InsertItem(L"My Device", 2, 2);
	tree.SetItemData(hRoot, -1);

	// Fill each of the four hives

	VERIFY( m_pDataView = GetDataView() );
	
	HTREEITEM hHKCR = tree.InsertItem(L"HKEY_CLASSES_ROOT", 0, 1, hRoot);
	tree.SetItemData(hHKCR, (DWORD) HKEY_CLASSES_ROOT);

	HTREEITEM hHKCU = tree.InsertItem(L"HKEY_CURRENT_USER", 0, 1, hRoot);
	tree.SetItemData(hHKCU, (DWORD) HKEY_CURRENT_USER);

	HTREEITEM hHKLM = tree.InsertItem(L"HKEY_LOCAL_MACHINE", 0, 1, hRoot);
	tree.SetItemData(hHKLM, (DWORD) HKEY_LOCAL_MACHINE);

	HTREEITEM hHKUS = tree.InsertItem(L"HKEY_USERS", hRoot);
	tree.SetItemData(hHKUS, (DWORD) HKEY_USERS);

	AddAllChildren(hHKCR, HKEY_CLASSES_ROOT);
	AddAllChildren(hHKCU, HKEY_CURRENT_USER);
	AddAllChildren(hHKLM, HKEY_LOCAL_MACHINE);
	AddAllChildren(hHKUS, HKEY_USERS);

	tree.Expand(hRoot, TVE_EXPAND);
	tree.UpdateWindow();

	FillItemList(hRoot);
}

void CRegView::FillItemList(HTREEITEM hItem)
{
	if (hItem == NULL)
		return;

	CTreeCtrl& tree = GetTreeCtrl();
	if (hItem == tree.GetRootItem())
		m_itemList.RemoveAll();

	m_itemList.Add(hItem);
	FillItemList(tree.GetChildItem(hItem));
	FillItemList(tree.GetNextSiblingItem(hItem));
}

void CRegView::AddAllChildren(HTREEITEM hParent, HKEY hKey)
{
	CRegKey keyParent;
	CString strName;
	DWORD dwIndex = 0;
	keyParent.Open(hKey, L"");
	while (keyParent.EnumKey(dwIndex, strName) == ERROR_SUCCESS)
	{
		CRegKey keyChild;
		keyChild.Open(keyParent, strName);
		HTREEITEM hChild = GetTreeCtrl().InsertItem(
			strName, 0, 1, hParent, TVI_SORT);
		GetTreeCtrl().SetItemData(hChild, NULL);
		AddAllChildren(hChild, keyChild);
	}
}

CDataView* CRegView::GetDataView()
{
	CDocument* pDoc = GetDocument();
	POSITION pos = pDoc->GetFirstViewPosition();
	CView *pView;

	do
	{
		pView = pDoc->GetNextView(pos);
		if (!pView)
			break;

		if (pView->IsKindOf(RUNTIME_CLASS(CDataView)))
			return (CDataView*)pView;
	} while (pos != NULL);

	return NULL;
}

BOOL CRegView::GetKeyFromActiveItem(CRegKey& key)
{
	HTREEITEM hItem = GetTreeCtrl().GetSelectedItem();
	if (hItem == NULL)
		return FALSE;

	return GetKeyFromTreeItem(hItem, key);
}

BOOL CRegView::GetKeyFromTreeItem(HTREEITEM hItem, CRegKey& key)
{
	CTreeCtrl& tree = GetTreeCtrl();
	CString strKey = tree.GetItemText(hItem);
	
	HKEY hKey = (HKEY) tree.GetItemData(hItem);
	if (hKey != NULL)
	{
		key.Open(hKey, L"");
		return TRUE;
	}

	HTREEITEM hParent = tree.GetParentItem(hItem);
	while (hParent && tree.GetItemData(hParent) == NULL)
	{
		hItem = hParent;
		strKey = tree.GetItemText(hItem) + L"\\" +	strKey;
		hParent = tree.GetParentItem(hItem);
	}

	if (hParent == NULL)
		return FALSE;

	hKey = (HKEY) tree.GetItemData(hParent);
	return key.Open(hKey, strKey) == ERROR_SUCCESS;
}

/////////////////////////////////////////////////////////////////////////////
// CRegView control message handlers

void CRegView::OnSelChanged(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CRegKey key;
	if (GetKeyFromActiveItem(key))
		m_pDataView->DisplayKey(key);
}

void CRegView::OnBeginLabelEdit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CTreeCtrl& tree = GetTreeCtrl();
	TV_DISPINFO* info = (TV_DISPINFO*)pNMHDR;
	HTREEITEM hItem = info->item.hItem;
	*pResult = tree.GetItemData(hItem) != NULL;
}

void CRegView::OnEndLabelEdit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CTreeCtrl& tree = GetTreeCtrl();
	TV_DISPINFO* info = (TV_DISPINFO*)pNMHDR;
	LPCTSTR lpNewText = info->item.pszText;

	CRegKey keyItem;
	HTREEITEM hItem = info->item.hItem;
	GetKeyFromTreeItem(hItem, keyItem);
	if (lpNewText == NULL)
	{
		if (keyItem == NULL)
			tree.DeleteItem(hItem);

		return;
	}

	CRegKey keyParent;
	GetKeyFromTreeItem(tree.GetParentItem(hItem), keyParent);
	if (keyItem == NULL)
	{
		keyItem.Create(keyParent, lpNewText);
		tree.SetItemText(hItem, lpNewText);
	}
	else
	{
		keyItem.Close();
		CString strOld = tree.GetItemText(hItem);
		if (keyParent.RenameChild(strOld, lpNewText))
		{
			tree.SetItemText(hItem, lpNewText);
			FillItemList(tree.GetRootItem());
		}
		else
		{
			::AfxMessageBox(L"Could not rename key.",
				MB_OK|MB_ICONINFORMATION);
		}
	}
}

// CRegView menu message handlers

void CRegView::OnViewIcons() 
{
	m_bShowIcons = !m_bShowIcons;	
	CTreeCtrl& tree = GetTreeCtrl();
	tree.SetImageList(m_bShowIcons ? &m_imageList : NULL, TVSIL_NORMAL);
}

void CRegView::OnViewRefresh() 
{
	OnInitialUpdate();
}

void CRegView::OnFind() 
{
	CFindDialog dlg(m_findData);
	if (dlg.DoModal() != IDOK)
		return;

	m_findData.m_nLastItem = 0;
	OnFindNext();
}

void CRegView::OnFindNext() 
{
	CTreeCtrl& tree = GetTreeCtrl();

	UINT nSize = m_itemList.GetSize();
	UINT& nLoop = m_findData.m_nLastItem;
	for (; nLoop < nSize; nLoop++)
	{
		HTREEITEM hItem = (HTREEITEM) m_itemList[nLoop];
		if (tree.GetItemData(hItem) != NULL)
			continue;

		if (m_findData.m_bMatchKeys)
		{
			CString strText(tree.GetItemText(hItem));
			if (strText != "FindXYZZY" &&
				IsMatchingString(strText,
				m_findData.m_strText,
				m_findData.m_bMatchExact))
			{
				tree.SelectItem(hItem);
				tree.Expand(hItem, TVE_EXPAND);
				m_findData.m_nLastItem++;
				return;
			}
		}

		if (m_findData.m_bMatchValues || m_findData.m_bMatchData)
		{
			CRegKey key;
			GetKeyFromTreeItem(hItem, key);
			if (m_pDataView->DisplayOnMatch(key, m_findData))
			{
				tree.SelectItem(hItem);
				tree.Expand(hItem, TVE_EXPAND);
				m_findData.m_nLastItem++;
				return;
			}
		}
	}

	m_findData.m_nLastItem = 0;
	AfxMessageBox(
		L"Finished searching through the registry",
		IDOK|MB_ICONINFORMATION);
}

void CRegView::OnDelete() 
{
	CTreeCtrl& tree = GetTreeCtrl();
	HTREEITEM hItem = tree.GetSelectedItem();
	if (tree.GetItemData(hItem) != NULL)
		return;

	int nResult = AfxMessageBox(
		L"Are you sure you want to delete this key?",
		MB_YESNO|MB_ICONEXCLAMATION);

	if (nResult == IDYES)
	{
		CRegKey key;
		GetKeyFromTreeItem(tree.GetParentItem(hItem), key);
		key.RecurseDeleteKey(tree.GetItemText(hItem));
		tree.DeleteItem(hItem);
		FillItemList(tree.GetRootItem());
	}
}

void CRegView::OnNewKey() 
{
	CTreeCtrl& tree = GetTreeCtrl();
	HTREEITEM hParent = tree.GetSelectedItem();
	ASSERT(tree.GetItemData(hParent) == NULL);

	HTREEITEM hItem = tree.InsertItem(L"ChangeMe", hParent);
	tree.SetItemData(hItem, NULL);
	tree.SelectItem(hItem);
	OnRename();
}

void CRegView::OnRename() 
{
	SetFocus();

	CTreeCtrl& tree = GetTreeCtrl();
	VERIFY( tree.EditLabel(tree.GetSelectedItem()) );
}

void CRegView::OnUpdateViewIcons(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bShowIcons);	
}

void CRegView::OnUpdateMenuItem(CCmdUI* pCmdUI) 
{
	CTreeCtrl& tree = GetTreeCtrl();
	HTREEITEM hItem = tree.GetSelectedItem();
	DWORD dwKey = hItem ? tree.GetItemData(hItem) : NULL;	
	pCmdUI->Enable(dwKey == NULL);	
}

void CRegView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CSplitterWnd *pWnd = (CSplitterWnd *) GetParent();
	pWnd->SetActivePane(0, 0);

	CTreeView::OnLButtonDown(nFlags, point);
}

void CRegView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	switch(nChar)
	{
		case VK_TAB:
		{
			CSplitterWnd *pWnd = (CSplitterWnd *) GetParent();
#ifdef _WIN32_WCE_PSPC
			CListView* pView = (CListView*)pWnd->GetPane(1, 0);
			if (pView->GetListCtrl().GetItemCount() != 0)
				pWnd->SetActivePane(1, 0);
#else
			CListView* pView = (CListView*)pWnd->GetPane(0, 1);
			if (pView->GetListCtrl().GetItemCount() != 0)
				pWnd->SetActivePane(0, 1);
#endif
			break;
		}
	}
	
	CTreeView::OnKeyDown(nChar, nRepCnt, nFlags);
}
