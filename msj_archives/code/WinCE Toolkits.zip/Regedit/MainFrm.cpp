// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "resource.h"
#include "MainFrm.h"
#include "RegKey.h"
#include "RegView.h"
#include "DataView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static TBBUTTON tbButtons[] = {
#ifdef _WIN32_WCE_PSPC
	{0, 0,					TBSTATE_ENABLED, TBSTYLE_SEP,    0, 0, 0, -1},
#endif
	{0,	ID_VIEW_REFRESH,	TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0, 0, -1},
	{1, ID_EDIT_DELETE,		TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0, 0, -1},
	{0, 0,					TBSTATE_ENABLED, TBSTYLE_SEP,    0, 0, 0, -1},
	{2, ID_EDIT_FIND,		TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0, 0, -1},
	{3, ID_EDIT_FINDNEXT,	TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0, 0, -1}
};
const int nNumButtons = sizeof(tbButtons)/sizeof(TBBUTTON);
const int nNumImages = 4;
#ifdef _WIN32_WCE_PSPC
const DWORD dwAdornmentFlags = 0;
#else
const DWORD dwAdornmentFlags = CMDBAR_HELP;
#endif
/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_HELPINFO()
	ON_COMMAND_RANGE(ID_EDIT_FIND, ID_EDIT_FIND, OnRegViewItem)
	ON_COMMAND_RANGE(ID_EDIT_FINDNEXT, ID_EDIT_FINDNEXT, OnRegViewItem)
	ON_COMMAND_RANGE(ID_VIEW_REFRESH, ID_VIEW_REFRESH, OnRegViewItem)
	ON_COMMAND_RANGE(ID_VIEW_ICONS, ID_VIEW_ICONS, OnRegViewItem)
	ON_COMMAND_RANGE(ID_NEW_STRING, ID_NEW_STRING, OnDataViewItem)
	ON_COMMAND_RANGE(ID_NEW_DWORD, ID_NEW_DWORD, OnDataViewItem)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rSize;
	GetWindowRect(rSize);

	if (!InsertButtons(tbButtons, nNumButtons, IDR_MAINFRAME, nNumImages) ||
		!AddAdornments(dwAdornmentFlags))
	{
		TRACE0("Failed to add toolbar buttons\n");
		return -1;
	}

	return 0;
}

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT,	CCreateContext* pContext)
{
	CRect rSize;
	GetWindowRect(&rSize);

	if (rSize.Height() > rSize.Width())
	{
		CSize start_size(0, AfxGetApp()->GetProfileInt(
			L"RegView", L"TreeHeight", rSize.Height() * 2 / 3));

		VERIFY( m_wndSplitter.CreateStatic(this, 2, 1));
		VERIFY( m_wndSplitter.CreateView(1, 0, RUNTIME_CLASS(CDataView),
			start_size, pContext) );
		VERIFY( m_wndSplitter.CreateView(0, 0, RUNTIME_CLASS(CRegView),
			start_size, pContext) );
	}
	else
	{
		CSize start_size(AfxGetApp()->GetProfileInt(
			L"RegView", L"TreeWidth", rSize.Width() / 3), 0);

		VERIFY( m_wndSplitter.CreateStatic(this, 1, 2));
		VERIFY( m_wndSplitter.CreateView(0, 1, RUNTIME_CLASS(CDataView),
			start_size, pContext) );
		VERIFY( m_wndSplitter.CreateView(0, 0, RUNTIME_CLASS(CRegView),
			start_size, pContext) );
	}

	return TRUE;
}

void CMainFrame::OnDestroy() 
{
	int nCur, nMin;
	m_wndSplitter.GetColumnInfo(0, nCur, nMin);
	AfxGetApp()->WriteProfileInt(L"RegView", L"TreeWidth", nCur);
	m_wndSplitter.GetRowInfo(0, nCur, nMin);
	AfxGetApp()->WriteProfileInt(L"RegView", L"TreeHeight", nCur);

	CFrameWnd::OnDestroy();
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg() : CDialog(IDD) {}

protected:
	DECLARE_MESSAGE_MAP()

	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA
	//{{AFX_VIRTUAL(CAboutDlg)
	//}}AFX_VIRTUAL
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();		// Added for WCE apps
	//}}AFX_MSG
};

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CenterWindow();
	return TRUE;
}

BOOL CMainFrame::OnHelpInfo(HELPINFO*) 
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
	return TRUE;
}

void CMainFrame::OnRegViewItem(UINT nMsg) 
{
	m_wndSplitter.GetPane(0, 0)->SendMessage(
		WM_COMMAND, nMsg, 0);
}

void CMainFrame::OnDataViewItem(UINT nMsg) 
{
	CRect rSize;
	GetWindowRect(&rSize);

	if (rSize.Height() > rSize.Width())
	{
		m_wndSplitter.GetPane(1, 0)->SendMessage(
			WM_COMMAND, nMsg, 0);
	}
	else
	{
		m_wndSplitter.GetPane(0, 1)->SendMessage(
		WM_COMMAND, nMsg, 0);
	}
}
