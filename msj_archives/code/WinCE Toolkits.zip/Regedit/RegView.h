// RegView.h : interface of the CRegView class
//
/////////////////////////////////////////////////////////////////////////////

#pragma once

class CDataView;

class CRegView : public CTreeView
{
	CArray<LPVOID, LPVOID> m_itemList;
	CImageList m_imageList;
	BOOL m_bShowIcons;
	TFINDDATA m_findData;
	CDataView* m_pDataView;

public:
	BOOL GetKeyFromActiveItem(CRegKey& key);

protected:
	CDataView* GetDataView();
	void AddAllChildren(HTREEITEM hParent, HKEY hKey);
	BOOL GetKeyFromTreeItem(HTREEITEM hItem, CRegKey& key);
	void FillItemList(HTREEITEM hItem);

	DECLARE_DYNCREATE(CRegView)
	DECLARE_MESSAGE_MAP()

	//{{AFX_VIRTUAL(CRegView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate();
	//}}AFX_VIRTUAL
	//{{AFX_MSG(CRegView)
	afx_msg void OnDestroy();
	afx_msg void OnSelChanged(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEndLabelEdit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBeginLabelEdit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnUpdateMenuItem(CCmdUI* pCmdUI);
	afx_msg void OnUpdateViewIcons(CCmdUI* pCmdUI);
	afx_msg void OnNewKey();
	afx_msg void OnDelete();
	afx_msg void OnRename();
	afx_msg void OnFind();
	afx_msg void OnFindNext();
	afx_msg void OnViewIcons();
	afx_msg void OnViewRefresh();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
};
