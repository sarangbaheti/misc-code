// EditValue.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "EditValue.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditValueDlg dialog


CEditValueDlg::CEditValueDlg(CWnd* pParent, CString strName, CString strData, BOOL bEditName)
: CDialog(CEditValueDlg::IDD, pParent), m_bEditName(bEditName)
{
	//{{AFX_DATA_INIT(CEditValueDlg)
	m_strName = strName;
	m_strData = strData;
	//}}AFX_DATA_INIT
}


void CEditValueDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEditValueDlg)
	DDX_Text(pDX, IDC_EDIT_DATA, m_strData);
	DDX_Text(pDX, IDC_EDIT_NAME, m_strName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEditValueDlg, CDialog)
	//{{AFX_MSG_MAP(CEditValueDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditValueDlg message handlers

BOOL CEditValueDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CenterWindow();
	return TRUE;
}
