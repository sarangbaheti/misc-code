// Regedit.h : main header file for the REGEDIT application
//

#pragma once

class CDummyDoc : public CDocument
{
protected:
	DECLARE_DYNCREATE(CDummyDoc)
};

class CRegApp : public CWinApp
{
protected:
	void UpdateMenuItems(CMenu* pMenu);
	DECLARE_MESSAGE_MAP()

	//{{AFX_VIRTUAL(CRegApp)
	public:
	virtual BOOL InitInstance();
	virtual BOOL OnIdle(LONG lCount);
	//}}AFX_VIRTUAL
	//{{AFX_MSG(CRegApp)
	//}}AFX_MSG
};
