// FindDialog.h : header file
//

#pragma once

class CFindDialog : public CDialog
{
	TFINDDATA& m_data;
public:
	CFindDialog(TFINDDATA& data, CWnd* pParent = NULL);
	virtual ~CFindDialog();

	//{{AFX_DATA(CFindDialog)
#ifdef _WIN32_WCE_PSPC
	enum { IDD = IDD_FIND_PALM };
#else
	enum { IDD = IDD_FIND };
#endif
	//}}AFX_DATA
	//{{AFX_VIRTUAL(CFindDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL
	//{{AFX_MSG(CFindDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeEditFind();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};
