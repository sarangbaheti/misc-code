// RegKey.h: interface for the CRegKey class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

/////////////////////////////////////////////////////////////////////////////
// CRegKey

class CRegKey
{
public:
	CRegKey();
	~CRegKey();

// Attributes
public:
	operator HKEY() const;
	HKEY m_hKey;

// Operations
public:
	LONG Open(HKEY hKeyParent, LPCTSTR lpszKeyName,
		REGSAM samDesired = KEY_ALL_ACCESS);
	LONG Close();
	LONG EnumKey(DWORD& dwIndex, CString& strName);
	LONG EnumValue(DWORD& dwIndex, CString& strName, DWORD* dwType);
	BOOL QueryType(CString strValue, DWORD* dwType);
	LONG QueryValue(CString strName, DWORD& dwValue);
	LONG QueryValue(CString strName, CString& strValue);
	LONG QueryValue(CString strName, LPBYTE buffer, DWORD& dwCount);
	LONG SetValue(CString strName, DWORD dwValue);
	LONG SetValue(CString strName, CString lpszValue);
	LONG SetValue(CString strName, LPBYTE buffer, DWORD dwCount);
	LONG RecurseDeleteKey(LPCTSTR lpszKey);
	BOOL RenameChild(CString strOld, CString strNew);
	BOOL RenameValue(CString strOld, CString strNew);
	BOOL Duplicate(CRegKey& keyDest);

	LONG Create(HKEY hKeyParent, LPCTSTR lpszKeyName,
		LPTSTR lpszClass = REG_NONE, DWORD dwOptions = REG_OPTION_NON_VOLATILE,
		REGSAM samDesired = KEY_ALL_ACCESS,
		LPSECURITY_ATTRIBUTES lpSecAttr = NULL,
		LPDWORD lpdwDisposition = NULL);
	HKEY Detach();
	void Attach(HKEY hKey);
	LONG DeleteSubKey(LPCTSTR lpszSubKey);
	LONG DeleteValue(LPCTSTR lpszValue);
};

inline CRegKey::CRegKey()
{m_hKey = NULL;}

inline CRegKey::~CRegKey()
{Close();}

inline CRegKey::operator HKEY() const
{return m_hKey;}

inline LONG CRegKey::Close()
{
	LONG lRes = ERROR_SUCCESS;
	if (m_hKey != NULL)
	{
		lRes = RegCloseKey(m_hKey);
		m_hKey = NULL;
	}
	return lRes;
}

inline LONG CRegKey::Open(HKEY hKeyParent, LPCTSTR lpszKeyName, REGSAM samDesired)
{
	ASSERT(hKeyParent != NULL);
	HKEY hKey = NULL;
	LONG lRes = RegOpenKeyEx(hKeyParent, lpszKeyName, 0, samDesired, &hKey);
	if (lRes == ERROR_SUCCESS)
	{
		lRes = Close();
		ASSERT(lRes == ERROR_SUCCESS);
		m_hKey = hKey;
	}
	return lRes;
}

inline LONG CRegKey::EnumKey(DWORD& dwIndex, CString& strName)
{
	DWORD dwCount = _MAX_PATH;
	LPWSTR lpwKey = strName.GetBuffer(dwCount);
	LONG lResult = ::RegEnumKeyEx(m_hKey, dwIndex++,
		lpwKey, &dwCount, NULL, NULL, NULL, NULL);
	strName.ReleaseBuffer();

	return lResult;
}

inline LONG CRegKey::EnumValue(DWORD& dwIndex, CString& strName, DWORD* dwType)
{
	DWORD dwCount = _MAX_PATH;
	LPWSTR lpwKey = strName.GetBuffer(dwCount);
	LONG lRes = ::RegEnumValue(m_hKey, dwIndex++, lpwKey,
		&dwCount, NULL, dwType, NULL, NULL);

	ASSERT(dwCount <= _MAX_PATH);
	strName.ReleaseBuffer();
	return lRes;
}

inline LONG CRegKey::QueryValue(CString strName, DWORD& dwValue)
{
	DWORD dwType = NULL;
	DWORD dwCount = sizeof(DWORD);
	LONG lRes = RegQueryValueEx(m_hKey, strName, NULL, &dwType,
		(LPBYTE)&dwValue, &dwCount);
	ASSERT((lRes!=ERROR_SUCCESS) || (dwType == REG_DWORD));
	ASSERT((lRes!=ERROR_SUCCESS) || (dwCount == sizeof(DWORD)));
	return lRes;
}

inline LONG CRegKey::QueryValue(CString strName, CString& strValue)
{
	DWORD dwType = NULL, dwCount = _MAX_PATH;
	LPBYTE pData = (LPBYTE) strValue.GetBuffer(dwCount);
	LONG lRes = RegQueryValueEx(m_hKey, strName, NULL, &dwType,
		(LPBYTE) pData, &dwCount);
	strValue.ReleaseBuffer();

	ASSERT(dwCount <= _MAX_PATH);
	ASSERT((lRes!=ERROR_SUCCESS) || (dwType == REG_SZ) ||
			 (dwType == REG_MULTI_SZ) || (dwType == REG_EXPAND_SZ));
	return lRes;
}

inline LONG CRegKey::QueryValue(CString strName, LPBYTE buffer, DWORD& dwCount)
{
	DWORD dwType = NULL, dwOrgCount = dwCount;
	LONG lRes = RegQueryValueEx(m_hKey, strName, NULL,
		&dwType, buffer, &dwCount);

	ASSERT(dwCount <= dwOrgCount);
	ASSERT(lRes != ERROR_SUCCESS || dwType == REG_BINARY);
	return lRes;
}

inline BOOL CRegKey::RenameChild(CString strOld, CString strNew)
{
	ASSERT(m_hKey != NULL);

	CRegKey keyOld, keyNew;
	VERIFY( keyOld.Open(m_hKey, strOld) == ERROR_SUCCESS );
	if (keyNew.Create(m_hKey, strNew) != ERROR_SUCCESS)
		return FALSE;

	if (keyOld.Duplicate(keyNew))
	{
		keyOld.Close();
		RecurseDeleteKey(strOld);
		return TRUE;
	}
	else
	{
		keyNew.Close();
		RecurseDeleteKey(strNew);
		return FALSE;
	}
}

inline BOOL CRegKey::QueryType(CString strValue, DWORD* dwType)
{
	return ::RegQueryValueEx(m_hKey, strValue, NULL,
			dwType, NULL, NULL) == ERROR_SUCCESS;
}

inline BOOL CRegKey::RenameValue(CString strOld, CString strNew)
{
	if (strOld == strNew)
		return TRUE;

	if (::RegQueryValueEx(m_hKey, strNew, NULL,
			NULL, NULL, NULL) == ERROR_SUCCESS)
	{
		return FALSE;
	}

	DWORD dwValType, dwCount = _MAX_PATH;
	LPBYTE lpData = new BYTE[dwCount];
	if (::RegQueryValueEx(m_hKey, strOld, NULL,
		&dwValType, lpData, &dwCount) != ERROR_SUCCESS)
	{
		delete [] lpData;
		return FALSE;
	}

	if (::RegSetValueEx(m_hKey, strNew, NULL,
		dwValType, lpData, dwCount) != ERROR_SUCCESS)
	{
		delete [] lpData;
		return FALSE;
	}

	DeleteValue(strOld);
	return TRUE;
}

inline BOOL CRegKey::Duplicate(CRegKey& keyDest)
{
	DWORD dwIndex = 0;
	CString strName;
	while (EnumKey(dwIndex, strName) == ERROR_SUCCESS)
	{
		CRegKey keySubSrc, keySubDest;
		if (keySubSrc.Open(m_hKey, strName) != ERROR_SUCCESS)
			return FALSE;

		keySubDest.Create(keyDest, strName);
		if (!keySubSrc.Duplicate(keySubDest))
			return FALSE;
	}

	DWORD dwKeyType, dwNameLen = _MAX_PATH;
	LPTSTR lpValueName = new TCHAR[dwNameLen];
	dwIndex = 0;

	while (::RegEnumValue(m_hKey, dwIndex++, lpValueName,
		&dwNameLen, NULL, &dwKeyType, NULL, NULL) == ERROR_SUCCESS)
	{
		DWORD dwValType, dwCount = _MAX_PATH;
		LPBYTE lpData = new BYTE[dwCount];
		if (::RegQueryValueEx(m_hKey, lpValueName, NULL,
			&dwValType, lpData, &dwCount) != ERROR_SUCCESS)
		{
			delete [] lpData;
			return FALSE;
		}

		if (::RegSetValueEx(keyDest, lpValueName, NULL,
			dwValType, lpData, dwCount) != ERROR_SUCCESS)
		{
			delete [] lpData;
			return FALSE;
		}

		dwNameLen = _MAX_PATH;
		delete [] lpData;
	}

	delete [] lpValueName;
	return TRUE;
}

inline HKEY CRegKey::Detach()
{
	HKEY hKey = m_hKey;
	m_hKey = NULL;
	return hKey;
}

inline void CRegKey::Attach(HKEY hKey)
{
	ASSERT(m_hKey == NULL);
	m_hKey = hKey;
}

inline LONG CRegKey::DeleteSubKey(LPCTSTR lpszSubKey)
{
	ASSERT(m_hKey != NULL);
	return RegDeleteKey(m_hKey, lpszSubKey);
}

inline LONG CRegKey::DeleteValue(LPCTSTR lpszValue)
{
	ASSERT(m_hKey != NULL);
	return RegDeleteValue(m_hKey, (LPTSTR)lpszValue);
}

inline LONG CRegKey::Create(HKEY hKeyParent, LPCTSTR lpszKeyName,
	LPTSTR lpszClass, DWORD dwOptions, REGSAM samDesired,
	LPSECURITY_ATTRIBUTES lpSecAttr, LPDWORD lpdwDisposition)
{
	ASSERT(hKeyParent != NULL);
	DWORD dw;
	HKEY hKey = NULL;
	LONG lRes = RegCreateKeyEx(hKeyParent, lpszKeyName, 0,
		lpszClass, dwOptions, samDesired, lpSecAttr, &hKey, &dw);
	if (lpdwDisposition != NULL)
		*lpdwDisposition = dw;
	if (lRes == ERROR_SUCCESS)
	{
		lRes = Close();
		m_hKey = hKey;
	}
	return lRes;
}

inline LONG CRegKey::SetValue(CString strName, DWORD dwValue)
{
	ASSERT(m_hKey != NULL);
	return RegSetValueEx(m_hKey, strName, NULL, REG_DWORD,
		(BYTE * const)&dwValue, sizeof(DWORD));
}

inline LONG CRegKey::SetValue(CString strName, CString strValue)
{
	ASSERT(m_hKey != NULL);
	LONG lRes = RegSetValueEx(m_hKey, strName, NULL, REG_SZ,
		(LPBYTE) strValue.LockBuffer(),
		(strValue.GetLength() + 1) * sizeof(TCHAR));

	strValue.UnlockBuffer();
	return lRes;
}

inline LONG CRegKey::SetValue(CString strName, LPBYTE lpBuffer, DWORD dwCount)
{
	ASSERT(m_hKey != NULL);
	ASSERT(lpBuffer != NULL);
	return RegSetValueEx(m_hKey, strName, NULL, REG_BINARY,
		lpBuffer, dwCount);
}

inline LONG CRegKey::RecurseDeleteKey(LPCTSTR lpszKey)
{
	CRegKey key;
	LONG lRes = key.Open(m_hKey, lpszKey, KEY_READ | KEY_WRITE);
	if (lRes != ERROR_SUCCESS)
		return lRes;
	FILETIME time;
	DWORD dwSize = 256;
	TCHAR szBuffer[256];
	while (RegEnumKeyEx(key.m_hKey, 0, szBuffer, &dwSize, NULL, NULL, NULL,
		&time)==ERROR_SUCCESS)
	{
		lRes = key.RecurseDeleteKey(szBuffer);
		if (lRes != ERROR_SUCCESS)
			return lRes;
		dwSize = 256;
	}
	key.Close();
	return DeleteSubKey(lpszKey);
}
