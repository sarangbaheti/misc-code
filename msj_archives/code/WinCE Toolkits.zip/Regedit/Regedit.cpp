// Regedit.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "resource.h"
#include "Regedit.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRegApp

IMPLEMENT_DYNCREATE(CDummyDoc, CDocument)
BEGIN_MESSAGE_MAP(CRegApp, CWinApp)
	//{{AFX_MSG_MAP(CRegApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// The one and only CRegApp object

CRegApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CRegApp initialization

BOOL CRegApp::InitInstance()
{
	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("CodeMarine"));
	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register document templates

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CDummyDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CView));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();

	return TRUE;
}

BOOL CRegApp::OnIdle(LONG lCount) 
{
	CMenu* pMenu = m_pMainWnd->GetMenu();
	UpdateMenuItems(pMenu);
	return CWinApp::OnIdle(lCount);
}

void CRegApp::UpdateMenuItems(CMenu* pMenu)
{

	// This funky code is required for MFCCE Version 2.0
	// because there's no support for graying out the
	// toolbar buttons when a menu item is disabled!!
	// The problem does not exist in version 2.01 and later

#if (_WIN32_WCE <= 200)

	ASSERT(pMenu != NULL);
	UINT nItems = pMenu->GetMenuItemCount();
	for (UINT nLoop = 0; nLoop < nItems; nLoop++)
	{
		MENUITEMINFO info;
		info.cbSize = sizeof(info);
		info.dwTypeData = NULL;
		info.fMask = MIIM_SUBMENU|MIIM_ID;
		GetMenuItemInfo(pMenu->GetSafeHmenu(), nLoop, TRUE, &info);
		if (info.hSubMenu)
		{
			CMenu subMenu;
			subMenu.Attach(info.hSubMenu);
			UpdateMenuItems(&subMenu);
			subMenu.Detach();
			continue;
		}

		if (info.wID == 0)		// Separator
			continue;

		CCmdUI state;
		state.m_nID = info.wID;
		state.m_pMenu = pMenu;
		state.m_nIndex = nLoop;
		state.m_nIndexMax = nItems;
		state.DoUpdate(m_pMainWnd, FALSE);

		UINT nState = pMenu->EnableMenuItem(nLoop,
			MF_BYPOSITION | MF_ENABLED);

		CFrameWnd* pFrame = DYNAMIC_DOWNCAST(CFrameWnd, m_pMainWnd);
		ASSERT(pFrame);

		HWND hWnd = pFrame->m_hCommandBar;
		DWORD dwState = nState & MF_GRAYED ?
			TBSTATE_INDETERMINATE : TBSTATE_ENABLED;

		::SendMessage(hWnd, TB_SETSTATE, state.m_nID, dwState);
	}

#endif

}
