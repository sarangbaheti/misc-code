#define UNICODE
#include <windows.h>
#include <stdio.h>

void Quit( const wchar_t* pszMsg, int nExitCode = 1 )
{
    wprintf( L"%s\n", pszMsg );
    exit( nExitCode );
}

// brain-dead error routine that dumps the last error and exits
void Err( const wchar_t* pszFcn, DWORD nErr = GetLastError() )
{
    wchar_t szErr[256];
    wchar_t szMsg[512];
    if ( FormatMessage( FORMAT_MESSAGE_FROM_SYSTEM, 0, nErr, 0,
                        szErr, sizeof szErr / sizeof *szErr, 0 ) )
         swprintf( szMsg, L"%s failed: %s", pszFcn, szErr );
    else swprintf( szMsg, L"%s failed: 0x%08X", nErr );
    Quit( szMsg );
}

// Useful helper function for enabling a single privilege
bool EnablePrivilege( HANDLE htok,
                      const wchar_t* pszPriv,
                      TOKEN_PRIVILEGES& tpOld )
{
    TOKEN_PRIVILEGES tp;
    tp.PrivilegeCount = 1;
    tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
    if ( !LookupPrivilegeValue( 0, pszPriv, &tp.Privileges[0].Luid ) )
        Err( L"LookupPrivilegeValue" );

    // htok must have been opened with the following permissions:
    // TOKEN_QUERY (to get the old priv setting)
    // TOKEN_ADJUST_PRIVILEGES (to adjust the priv)
    DWORD cbOld = sizeof tpOld;
    if ( !AdjustTokenPrivileges( htok, FALSE, &tp,
                                 cbOld, &tpOld, &cbOld ) )
        Err( L"AdjustTokenPrivileges" );

    // Note that AdjustTokenPrivileges may succeed, and yet
    // some privileges weren't actually adjusted.
    // You've got to check GetLastError() to be sure!
    return ( ERROR_NOT_ALL_ASSIGNED != GetLastError() );
}

// Corresponding restoration helper function
void RestorePrivilege( HANDLE htok, const TOKEN_PRIVILEGES& tpOld )
{
    if ( !AdjustTokenPrivileges( htok, FALSE,
                                 const_cast<TOKEN_PRIVILEGES*>(&tpOld),
                                 0, 0, 0 ) )
        Err( L"AdjustTokenPrivileges" );
}

// Brain-dead print routine for brevity
void PrintFile( HANDLE h )
{
    DWORD cb = GetFileSize( h, 0 );
    void* psz = malloc( cb );
    ReadFile( h, psz, cb, &cb, 0 );
    WriteFile( GetStdHandle( STD_OUTPUT_HANDLE ), psz, cb, &cb, 0 );
    free( psz );
}

void wmain( int argc, wchar_t* argv[] )
{
    if ( 2 != argc )
        Quit( L"Usage: backupfile filename" );

    // Enable the backup privilege
    HANDLE htok = 0;
    if ( !OpenProcessToken( GetCurrentProcess(),
                            TOKEN_QUERY | TOKEN_ADJUST_PRIVILEGES,
                            &htok ) )
        Err( L"OpenProcessToken" );
    TOKEN_PRIVILEGES tpOld;
    if ( !EnablePrivilege( htok, SE_BACKUP_NAME, tpOld ) )
        Quit( L"Sorry, you don't have the backup privilege..." );

    // Open the requested file, exercising the backup privilege
    HANDLE hfile = CreateFile(  argv[1], GENERIC_READ, 0, 0,
                                OPEN_EXISTING,
                                FILE_FLAG_BACKUP_SEMANTICS, 0 );
    if ( INVALID_HANDLE_VALUE == hfile )
        Err( L"CreateFile" );

    // Now restore the privilege back to its prior state.
    // This is not strictly necessary, since we're going
    // to terminate the process anyway, and the token we've
    // adjusted will be destroyed, but in real life you might
    // have processes that do a little more than this :-)
    RestorePrivilege( htok, tpOld );
    
    // Note that once we've got the file handle opened, we can
    // use the permissions we were granted via CreateFile.
    // There are no further access checks performed.
    PrintFile( hfile );

    CloseHandle( hfile );
    CloseHandle( htok );
}
