////////////////////////////////////////////////////////////
//
// MBVDelegator.h - Copyright 1999, DevelopMentor
//
// Implementation of MBVDelegator
//
// If this code works, it was written by Don Box.
// If it doesn't, it was written by Paul DiLascia
//
//


#ifndef __MBVDELEGATOR_H_
#define __MBVDELEGATOR_H_

#include "resource.h"       // main symbols

#include "blinddel.h"

/////////////////////////////////////////////////////////////////////////////
// CMBVDelegator
class ATL_NO_VTABLE CMBVDelegator : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CMBVDelegator, &CLSID_MBVDelegator>,
	public IMarshal
{
public:
    CComPtr<IPersistStream>     m_ppsDelegatee;
    CComPtr<IUnknown>		m_pUnkFTM;
    CComPtr<IStream>            m_pStmCachedRead;
    DWORD                       m_cbMax;

    CMBVDelegator() : m_cbMax(0) {  }

// called from internalQI to tear off a new blind delegator
    static HRESULT WINAPI _BlindDelegate(void* pvThis, REFIID riid, void** ppv, DWORD dw)
    {
        CMBVDelegator *pThis = reinterpret_cast<CMBVDelegator*>(pvThis);
        return BlindDelegator::CreateDelegator(static_cast<IMarshal*>(pThis), pThis->m_ppsDelegatee, riid, ppv);
    }


DECLARE_REGISTRY_RESOURCEID(IDR_MBVDELEGATOR)

DECLARE_PROTECT_FINAL_CONSTRUCT()
DECLARE_GET_CONTROLLING_UNKNOWN()

BEGIN_COM_MAP(CMBVDelegator)
    COM_INTERFACE_ENTRY(IMarshal)
    COM_INTERFACE_ENTRY_FUNC_BLIND(0, _BlindDelegate)
END_COM_MAP()

// IMarshal
public:
    STDMETHODIMP GetUnmarshalClass(REFIID riid, void *pv, DWORD dwDestContext,
                                   void *pvDestContext, DWORD mshlflags, CLSID *pCid);
    
    STDMETHODIMP GetMarshalSizeMax(REFIID riid, void *pv, DWORD dwDestContext,
                                   void *pvDestContext, DWORD mshlflags, DWORD *pSize);
    
    STDMETHODIMP MarshalInterface(IStream *pStm, REFIID riid, void *pv,
                                  DWORD dwDestContext, void *pvDestContext, DWORD mshlflags);
    
    STDMETHODIMP UnmarshalInterface(IStream *pStm, REFIID riid, void **ppv);
    
    STDMETHODIMP ReleaseMarshalData(IStream *pStm);
    
    STDMETHODIMP DisconnectObject(DWORD dwReserved);

};

#endif //__MBVDELEGATOR_H_
