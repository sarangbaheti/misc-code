//==================================================
// MemDiff - Matt Pietrek 1999
// Microsoft Systems Journal, December 1999
// FILE: MemDiff.h
//==================================================
extern "C"
{

//
// Call this function twice, once at the beginning of the
// desired code sequence, and again afterwards.  Save
// the handles for later.
//
HANDLE __stdcall  MDTakeSnapshot( HANDLE hProcess );

//
// Compares two snapshot handles.  The third param (hOutputFile)
// can be any valid Win32 file handle (e.g., stdout, a file, a pipe, etc...)
//
BOOL __stdcall MDCompareSnapshot(   HANDLE hSnapshot1,
                                    HANDLE hSnapshot2,
                                    HANDLE hOutputFile,
                                    bool fVerbose = false );

//
// When done with the snapshots, call this function to release them
//
BOOL __stdcall MDFreeSnapshot( HANDLE hSnapshot );

}