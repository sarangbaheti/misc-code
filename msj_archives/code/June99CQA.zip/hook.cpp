////////////////////////////////////////////////////////////////
// MFC generic window creation hook function.
// Comments are mine--Paul DiLascia
//

void AFXAPI AfxHookWindowCreate(CWnd* pWnd)
{
   // MFC sets a trhead-global m_pWndInit, which points
   // to the window being created. This is the only way
   // CWnd::CreateEx and AfxHookWindowCreate can communicate
   // with the hook function, SetWindowsHookEx does not let
   // you pass an argument for the hook function.
   //
   _AFX_THREAD_STATE* pThreadState = 
      _afxThreadState.GetData();

   // If this window is already hooked for creation, ignore.
   // In theory, this should not happen.
   if (pThreadState->m_pWndInit == pWnd)
      return;

   if (pThreadState->m_hHookOldCbtFilter == NULL) {
      // Create the hook:
      pThreadState->m_hHookOldCbtFilter = ::SetWindowsHookEx(WH_CBT,
         _AfxCbtFilterHook, NULL, ::GetCurrentThreadId());
      if (pThreadState->m_hHookOldCbtFilter == NULL)
         AfxThrowMemoryException();
   }

   // Below are sanity checks
   ASSERT(pThreadState->m_hHookOldCbtFilter != NULL);
   ASSERT(pWnd != NULL);
   ASSERT(pWnd->m_hWnd == NULL);   // only do once

   ASSERT(pThreadState->m_pWndInit == NULL);   // hook not already in progress
   pThreadState->m_pWndInit = pWnd;            // set the m_pWndInit global !!
}
