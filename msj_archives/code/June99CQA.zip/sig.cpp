////////////////////////////////////////////////////////////////
// MFC signature codes, from afxmsg_.h.
//

enum AfxSig
{
   AfxSig_end = 0,     // [marks end of message map]

   AfxSig_bD,      // BOOL (CDC*)
   AfxSig_bb,      // BOOL (BOOL)
   AfxSig_bWww,    // BOOL (CWnd*, UINT, UINT)
   AfxSig_hDWw,    // HBRUSH (CDC*, CWnd*, UINT)
   AfxSig_hDw,     // HBRUSH (CDC*, UINT)
   AfxSig_iwWw,    // int (UINT, CWnd*, UINT)
   AfxSig_iww,     // int (UINT, UINT)
   AfxSig_iWww,    // int (CWnd*, UINT, UINT)
   AfxSig_is,      // int (LPTSTR)
   AfxSig_lwl,     // LRESULT (WPARAM, LPARAM)
   AfxSig_lwwM,    // LRESULT (UINT, UINT, CMenu*)
   AfxSig_vv,      // void (void)

   AfxSig_vw,      // void (UINT)
   AfxSig_vww,     // void (UINT, UINT)
   AfxSig_vvii,    // void (int, int) // wParam is ignored
   AfxSig_vwww,    // void (UINT, UINT, UINT)
   AfxSig_vwii,    // void (UINT, int, int)
   AfxSig_vwl,     // void (UINT, LPARAM)
   AfxSig_vbWW,    // void (BOOL, CWnd*, CWnd*)
   AfxSig_vD,      // void (CDC*)
   AfxSig_vM,      // void (CMenu*)
   AfxSig_vMwb,    // void (CMenu*, UINT, BOOL)

   AfxSig_vW,      // void (CWnd*)
   AfxSig_vWww,    // void (CWnd*, UINT, UINT)
   AfxSig_vWp,     // void (CWnd*, CPoint)
   AfxSig_vWh,     // void (CWnd*, HANDLE)
   AfxSig_vwW,     // void (UINT, CWnd*)
   AfxSig_vwWb,    // void (UINT, CWnd*, BOOL)
   AfxSig_vwwW,    // void (UINT, UINT, CWnd*)
   AfxSig_vwwx,    // void (UINT, UINT)
   AfxSig_vs,      // void (LPTSTR)
   AfxSig_vOWNER,  // void (int, LPTSTR), force return TRUE
   AfxSig_iis,     // int (int, LPTSTR)
   AfxSig_wp,      // UINT (CPoint)
   AfxSig_wv,      // UINT (void)
   AfxSig_vPOS,    // void (WINDOWPOS*)
   AfxSig_vCALC,   // void (BOOL, NCCALCSIZE_PARAMS*)
   AfxSig_vNMHDRpl,    // void (NMHDR*, LRESULT*)
   AfxSig_bNMHDRpl,    // BOOL (NMHDR*, LRESULT*)
   AfxSig_vwNMHDRpl,   // void (UINT, NMHDR*, LRESULT*)
   AfxSig_bwNMHDRpl,   // BOOL (UINT, NMHDR*, LRESULT*)
   AfxSig_bHELPINFO,   // BOOL (HELPINFO*)
   AfxSig_vwSIZING,    // void (UINT, LPRECT) -- return TRUE

   // signatures specific to CCmdTarget
   AfxSig_cmdui,   // void (CCmdUI*)
   AfxSig_cmduiw,  // void (CCmdUI*, UINT)
   AfxSig_vpv,     // void (void*)
   AfxSig_bpv,     // BOOL (void*)

   // Other aliases (based on implementation)
   AfxSig_vwwh,                // void (UINT, UINT, HANDLE)
   AfxSig_vwp,                 // void (UINT, CPoint)
   AfxSig_bw = AfxSig_bb,      // BOOL (UINT)
   AfxSig_bh = AfxSig_bb,      // BOOL (HANDLE)
   AfxSig_iw = AfxSig_bb,      // int (UINT)
   AfxSig_ww = AfxSig_bb,      // UINT (UINT)
   AfxSig_bv = AfxSig_wv,      // BOOL (void)
   AfxSig_hv = AfxSig_wv,      // HANDLE (void)
   AfxSig_vb = AfxSig_vw,      // void (BOOL)
   AfxSig_vbh = AfxSig_vww,    // void (BOOL, HANDLE)
   AfxSig_vbw = AfxSig_vww,    // void (BOOL, UINT)
   AfxSig_vhh = AfxSig_vww,    // void (HANDLE, HANDLE)
   AfxSig_vh = AfxSig_vw,      // void (HANDLE)
   AfxSig_viSS = AfxSig_vwl,   // void (int, STYLESTRUCT*)
   AfxSig_bwl = AfxSig_lwl,
   AfxSig_vwMOVING = AfxSig_vwSIZING,  // void (UINT, LPRECT) -- return TRUE

   AfxSig_vW2,                 // void (CWnd*) (CWnd* comes from lParam)
   AfxSig_bWCDS,               // BOOL (CWnd*, COPYDATASTRUCT*)
   AfxSig_bwsp,                // BOOL (UINT, short, CPoint)
   AfxSig_vws,
};
