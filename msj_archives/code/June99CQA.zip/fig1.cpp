////////////////////////////////////////////////////////////////
// AfxEndDeferRegisterClass -- This is where MFC registers
// various window classes for views, frames, control bars and
// so on. This is NOT where MFC sets the window proc to AfxWndProc.
// Here, MFC sets the window proc to the Windows default proc,
// DefWindowProc.
//
// -PD
//

BOOL AFXAPI AfxEndDeferRegisterClass(short fClass)
{
   BOOL bResult = FALSE;

   // common initialization
   WNDCLASS wndcls;
   memset(&wndcls, 0, sizeof(WNDCLASS));   // start with NULL defaults
   wndcls.lpfnWndProc = DefWindowProc;     // <<*** default window proc
   wndcls.hInstance = AfxGetInstanceHandle();
   wndcls.hCursor = afxData.hcurArrow;

   AFX_MODULE_STATE* pModuleState = AfxGetModuleState();
   if (fClass & AFX_WND_REG)
   {
      // Child windows - no brush, no icon, safest default class styles
      wndcls.style = CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW;
      wndcls.lpszClassName = _afxWnd;
      bResult =  AfxRegisterClass(&wndcls);
      if (bResult)
         pModuleState->m_fRegisteredClasses |= AFX_WND_REG;
   }
   else if (fClass & AFX_WNDOLECONTROL_REG)
   {
      // OLE Control windows - use parent DC for speed
      wndcls.style |= CS_PARENTDC | CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW;
      wndcls.lpszClassName = _afxWndOleControl;
      bResult =  AfxRegisterClass(&wndcls);
      if (bResult)
         pModuleState->m_fRegisteredClasses |= AFX_WNDOLECONTROL_REG;
   }
   else if (fClass & AFX_WNDCONTROLBAR_REG)
   {
      // Control bar windows
      wndcls.style = 0;   // control bars don't handle double click
      wndcls.lpszClassName = _afxWndControlBar;
      wndcls.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
      bResult =  AfxRegisterClass(&wndcls);
      if (bResult)
         pModuleState->m_fRegisteredClasses |= AFX_WNDCONTROLBAR_REG;
   }
   else if (fClass & AFX_WNDMDIFRAME_REG)
   {
      // MDI Frame window (also used for splitter window)
      wndcls.style = CS_DBLCLKS;
      wndcls.hbrBackground = NULL;
      bResult = RegisterWithIcon(&wndcls, _afxWndMDIFrame, AFX_IDI_STD_MDIFRAME);
      if (bResult)
         pModuleState->m_fRegisteredClasses |= AFX_WNDMDIFRAME_REG;
   }
   else if (fClass & AFX_WNDFRAMEORVIEW_REG)
   {
      // SDI Frame or MDI Child windows or views - normal colors
      wndcls.style = CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW;
      wndcls.hbrBackground = (HBRUSH) (COLOR_WINDOW + 1);
      bResult = RegisterWithIcon(&wndcls, _afxWndFrameOrView, AFX_IDI_STD_FRAME);
      if (bResult)
         pModuleState->m_fRegisteredClasses |= AFX_WNDFRAMEORVIEW_REG;
   }
   else if (fClass & AFX_WNDCOMMCTLS_REG)
   {
      InitCommonControls();
      bResult = TRUE;
      pModuleState->m_fRegisteredClasses |= AFX_WNDCOMMCTLS_REG;
   }

   return bResult;
}
