////////////////////////////////////////////////////////////////
// OPENDLG 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "StdAfx.h"
#include "MyDlg.h"
#include "Resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// IDs of controls in Explorer-style dialog, from Spy
#define ID_FILESOFTYPE		0x0441
#define ID_FILENAME			0x0442
#define ID_LOOKIN				0x0443

////////////////////////////////////////////////////////////////
// CMyOpenFileDlg
//
IMPLEMENT_DYNAMIC(CMyOpenDlg, CFileDialog)
BEGIN_MESSAGE_MAP(CMyOpenDlg, CFileDialog)
	ON_COMMAND(ID_PRESS_ME, OnPressMe)
END_MESSAGE_MAP()

CMyOpenDlg::CMyOpenDlg() : CFileDialog(TRUE,
	NULL,											  // no default extension
	NULL,											  // ..or file name
	OFN_HIDEREADONLY,							  // no read only checkbox
	_T("Text Files (*.txt)|*.txt|All Files (*.*)|*.*||"))
{
	// custom title
	m_ofn.lpstrTitle = _T("Like, pick a file, dude");
}

//////////////////
// Helper adds text to an edit control that I've added to the open dialog
//
void CMyOpenDlg::AddText(LPCTSTR lpText)
{
	if (m_edit) {
		// Convert \n to \n\r for Windows brain-damaged edit control
		// It's 1997, and I'm still writing code like this!
		//
		LPCTSTR src = lpText;

		TCHAR buf[1024];
		TCHAR* dst = buf;
		TCHAR* endbuf = buf + sizeof(buf) - 1;

		while (*src && dst < endbuf) {
			if (*src == '\n')
				*dst++ = '\r';
			*dst++ = *src++;
		}
		*dst = 0;

		m_edit.SetSel(-1, -1);					// end of edit text
		m_edit.ReplaceSel(buf);					// append string..
		m_edit.SendMessage(EM_SCROLLCARET);	// ..and show caret

	} else {
		TRACE(lpText);
	}
}

//////////////////
// Initialize dialog.
// For Explorer, this is actually a child of the main dialog.
//
BOOL CMyOpenDlg::OnInitDialog()
{
	if (m_ofn.Flags & OFN_EXPLORER) {
		SetControlText(IDOK,				_T("Do it, Man!"));
		SetControlText(IDCANCEL,		_T("Not!"));
		SetControlText(ID_LOOKIN,		_T("Lookey here:"));
		SetControlText(ID_FILENAME,	_T("Which file:"));
		SetControlText(ID_FILESOFTYPE,_T("Pick a type:"));
		m_edit.SubclassDlgItem(IDC_MYDLGINFO, this);
		AddText(_T("Look here as you use the controls\n"));
	} else {
		SetDlgItemText(IDOK,				_T("Do it, Man!"));
		SetDlgItemText(IDCANCEL,		_T("Not!"));
	}
	return CFileDialog::OnInitDialog();
}

//////////////////
// 
int CMyOpenDlg::DoModal()
{
	if (m_ofn.Flags & OFN_EXPLORER) {
		// Add my custom dialog to bottom
		m_ofn.lpTemplateName = MAKEINTRESOURCE(IDD_MYOPENDLG);
		m_ofn.Flags |= OFN_ENABLETEMPLATE;
	}
	return CFileDialog::DoModal();
}

//////////////////
// Silly button handler
//
void CMyOpenDlg::OnPressMe()
{
	MessageBox(_T("Why?"), _T("OpenDlg"), MB_OK);
}

////////////////////////////////////////////////////////////////
// Below are handlers for the Explorer-style CDN_ notifications.
// MFC converts these to virtual functions, NOT message handlers!
//
// My overrides just add a message to the info window
//

// For both Explorer-style and old-style dialogs: User wants to open file
//
BOOL CMyOpenDlg::OnFileNameOK()
{
	CString s;
	s.Format(_T("CMyOpenDlg::OnFileNameOK(%s)\n"), (LPCTSTR)GetPathName());
	AddText(s);
	return 0; // let Explorer do it.
}

// For old-style dialogs: User changed one of the list boxes
//
void CMyOpenDlg::OnLBSelChangedNotify(UINT nIDBox, UINT iCurSel, UINT nCode)
{
	CString s;
	s.Format(_T("OnLBSelChangedNotify(nIDBox=%d, iCurSel=%d, nCode=%d)\n"),
		nIDBox, iCurSel, nCode);
	AddText(s);
}

// For Explorer-style dialogs: initialization is done
//
void CMyOpenDlg::OnInitDone()
{
	AddText(_T("OnInitDone\n"));
}

// For Explorer-style dialogs: user selected a new file
//
void CMyOpenDlg::OnFileNameChange()
{
	CString s;
	s.Format(_T("OnFileNameChange: %s\n"), (LPCTSTR)GetFileName());
	AddText(s);
}

// For Explorer-style dialogs: user selected a new folder
//
void CMyOpenDlg::OnFolderChange()
{
	CString s;
	s.Format(_T("OnFolderChange: %s\n"), (LPCTSTR)GetFolderPath());
	AddText(s);
}

// For Explorer-style dialogs: user selected a new file type (from drop-down)
//
void CMyOpenDlg::OnTypeChange()
{
	CString s;
	s.Format(_T("OnTypeChange: nFilterIndex = %d\n"), m_ofn.nFilterIndex);
	AddText(s);
}

