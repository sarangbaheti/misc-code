////////////////////////////////////////////////////////////////
// 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//

//////////////////
// My open dialog
//
class CMyOpenDlg : public CFileDialog {
protected:
	CEdit	m_edit;								 // edit control to display info
	void AddText(LPCTSTR lpText);			 // helper adds text to edit control

public:
	DECLARE_DYNAMIC(CMyOpenDlg)
	CMyOpenDlg();
	virtual BOOL OnInitDialog();
	virtual int  DoModal();

	// called for both Explorer and old-style open dialogs
	virtual BOOL OnFileNameOK();
	virtual void OnLBSelChangedNotify(UINT nIDBox, UINT iCurSel, UINT nCode);

	// only called if OFN_EXPLORER is set
	virtual void OnInitDone();
	virtual void OnFileNameChange();
	virtual void OnFolderChange();
	virtual void OnTypeChange();

	DECLARE_MESSAGE_MAP()
	afx_msg void OnPressMe();
};
