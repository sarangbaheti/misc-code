//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OpenDlg.rc
//
#define IDR_MAINFRAME                   2
#define IDR_MSJCOM                      3
#define IDD_ABOUTBOX                    100
#define IDD_MYOPENDLG                   102
#define IDB_BITMAP1                     103
#define ID_PRESS_ME                     1001
#define IDC_MYDLGINFO                   1002
#define IDC_URLMSJ                      1003
#define IDC_URLPD                       1004
#define ID_VIEW_OLDDLG                  32771
#define ID_VIEW_EXPLORER                32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
