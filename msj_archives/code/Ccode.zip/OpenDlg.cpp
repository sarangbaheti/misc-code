////////////////////////////////////////////////////////////////
// OPENDLG Copyright 1996 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// OPENDLG shows how to customize the MFC CFileDialog in Windows 95
// Compiles with Visual C++ 5.0 or greater.
//
#include "StdAfx.h"
#include "OpenDlg.h"
#include "MyDlg.h"
#include "MainFrm.h"
#include "PixieDlg.h"
#include "TraceWin.h" // TraceWin TRACE output

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CApp NEAR theApp;

BEGIN_MESSAGE_MAP(CApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_VIEW_EXPLORER, OnViewExplorer)
	ON_UPDATE_COMMAND_UI(ID_VIEW_EXPLORER, OnUpdateViewExplorer)
	ON_COMMAND(ID_VIEW_OLDDLG, OnViewOlddlg)
	ON_UPDATE_COMMAND_UI(ID_VIEW_OLDDLG, OnUpdateViewOlddlg)
END_MESSAGE_MAP()

CApp::CApp()
{
	// default: use Explorer-style opendialog
	m_bExplorerStyleOpenDialog = TRUE;
}

BOOL CApp::InitInstance()
{
   // Create main frame window (don't use doc/view stuff)
   // 
   CMainFrame* pMainFrame = new CMainFrame;
   if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
      return FALSE;
   pMainFrame->ShowWindow(m_nCmdShow);
   pMainFrame->UpdateWindow();
   m_pMainWnd = pMainFrame;

	return TRUE;
}

////////////////
// Run special File Open dialog
//
void CApp::OnFileOpen()
{
	CMyOpenDlg dlg;

	// do Explorer-style or old style depending on m_bExplorerStyleOpenDialog
	if (!m_bExplorerStyleOpenDialog)
		dlg.m_ofn.Flags &= ~OFN_EXPLORER;

	dlg.DoModal();
}

void CApp::OnAppAbout()
{
	static DLGLINK links[] = {
		{ IDC_URLPD,  NULL },
		{ IDC_URLMSJ, _T("http://www.microsoft.com/msj") }
	};
	const NUMLINKS = sizeof(links)/sizeof(links[0]);

	CPixieDlg(IDD_ABOUTBOX, links, NUMLINKS).DoModal();
}

//////////////////
// Use Explorer-style open dialog
//
void CApp::OnViewExplorer() 
{
	m_bExplorerStyleOpenDialog = TRUE;
}
void CApp::OnUpdateViewExplorer(CCmdUI* pCmdUI) 
{
	pCmdUI->SetRadio(m_bExplorerStyleOpenDialog);
}

//////////////////
// Use old-style open dialog
//
void CApp::OnViewOlddlg() 
{
	m_bExplorerStyleOpenDialog = FALSE;
}
void CApp::OnUpdateViewOlddlg(CCmdUI* pCmdUI) 
{
	pCmdUI->SetRadio(!m_bExplorerStyleOpenDialog);
}
