////////////////////////////////////////////////////////////////
// 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// See OPENDLG.CPP for description of program.
// 
#include "resource.h"

class CApp : public CWinApp {
	BOOL	m_bExplorerStyleOpenDialog;
public:
	CApp();
	virtual BOOL InitInstance();
	afx_msg void OnAppAbout();
	afx_msg void OnFileOpen();
	afx_msg void OnViewExplorer();
	afx_msg void OnUpdateViewExplorer(CCmdUI* pCmdUI);
	afx_msg void OnViewOlddlg();
	afx_msg void OnUpdateViewOlddlg(CCmdUI* pCmdUI);
	DECLARE_MESSAGE_MAP()
};

