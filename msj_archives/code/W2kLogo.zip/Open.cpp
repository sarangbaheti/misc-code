/*****************************************************************
*
*  Project.....:  Windows 2000 Open File Dialog
*  Application.:  OPEN.exe
*  Module......:  OPEN.cpp
*  Description.:  Application main module
*  Compiler....:  MS Visual C++ 
*  Written by..:  D. Esposito
*  Environment.:  Windows 9x/NT
*
******************************************************************/

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "comdlg32.lib")


/*---------------------------------------------------------------*/
//                        INCLUDE section
/*---------------------------------------------------------------*/
#include "Open.h"
#include <commctrl.h>
#include <commdlg.h>
#include <shlobj.h>
#include "ofnex.h"



/*---------------------------------------------------------------*/
//                        GLOBAL section
/*---------------------------------------------------------------*/
// Data
static HICON g_hIconLarge;
static HICON g_hIconSmall;


// Functions
static void OnInitDialog(HWND);
static void OnOK(HWND);
static void RunOpenFileDialog(HWND);


// Callbacks
BOOL CALLBACK APP_DlgProc(HWND, UINT, WPARAM, LPARAM);
UINT CALLBACK OFNHookProc(HWND, UINT, WPARAM, LPARAM);



/*---------------------------------------------------------------*/
// Procedure....: WinMain()
// Description..: Entry point in any Windows program
// Input........: HINSTANCE, HINSTANCE, LPSTR, int
// Output.......: INT
/*---------------------------------------------------------------*/
int APIENTRY WinMain(
   HINSTANCE hInstance, HINSTANCE hPrevious, LPSTR lpsz, int iCmd)
{
   // Save global data
   g_hIconLarge = static_cast<HICON>(LoadImage(hInstance, _T("APP_ICON"), 
	   IMAGE_ICON, GetSystemMetrics(SM_CXICON), 
	   GetSystemMetrics(SM_CXICON), 0));
   g_hIconSmall = static_cast<HICON>(LoadImage(hInstance, _T("APP_ICON"), 
	   IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), 
	   GetSystemMetrics(SM_CXSMICON), 0));

   // Enable common controls
   INITCOMMONCONTROLSEX iccex;
   iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
   iccex.dwICC = ICC_WIN95_CLASSES;
   InitCommonControlsEx(&iccex);

   // Run main dialog
   BOOL b = DialogBox(hInstance, _T("DLG_MAIN"), NULL, APP_DlgProc);

   // Exit
   DestroyIcon(g_hIconLarge);
   DestroyIcon(g_hIconSmall);
   return b;
}


/*---------------------------------------------------------------*/
// Procedure....: APP_DlgProc()
// Description..: Responds to all messages sent to the dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: BOOL
/*---------------------------------------------------------------*/
BOOL CALLBACK APP_DlgProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
   switch(uiMsg)
   {
   case WM_INITDIALOG:
      OnInitDialog(hDlg);
      break;

   case WM_COMMAND:
      switch(wParam)
      {
      case IDOK:
         OnOK(hDlg);
         return FALSE;

      case IDCANCEL:
         EndDialog(hDlg, FALSE);
         return FALSE;
      }
      break;
   }

   return FALSE;
}


/*---------------------------------------------------------------*/
// Procedure....: OFNHookProc()
// Description..: Hook messages for the File dialog
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: UINT
/*---------------------------------------------------------------*/
UINT CALLBACK OFNHookProc(HWND hDlg, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
	LPOFNOTIFYEX lpon = reinterpret_cast<LPOFNOTIFYEX>(lParam);

	switch(uiMsg)
	{
		case WM_DESTROY:	
			SetNoDeleteMode(FALSE);
			break;
			
		case WM_NOTIFY:
			switch(lpon->hdr.code)
			{
				case CDN_INITDONE:
					SetNoDeleteMode(TRUE);
					break;

				case CDN_FOLDERCHANGE:
					AdjustListViewStyle(hDlg);
					GrayRenameDeleteMenuItems(hDlg);
					break;
			}

			return FALSE;
	}
	
	return 0;  // allow the default proc to go
}


/*---------------------------------------------------------------*/
// Procedure...: OnOK()
// Description.: Run the Open File Dialog
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnOK(HWND hDlg)
{
	RunOpenFileDialog(hDlg);
	return;
}


/*---------------------------------------------------------------*/
// Procedure...: OnInitDialog()
// Description.: Initialize the dialog
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void OnInitDialog(HWND hDlg)
{
   // Set the icons (T/F as to Large/Small icon)
   SendMessage(hDlg, WM_SETICON, FALSE, 
	   reinterpret_cast<LPARAM>(g_hIconSmall));
   SendMessage(hDlg, WM_SETICON, TRUE, 
	   reinterpret_cast<LPARAM>(g_hIconLarge));
}



/*---------------------------------------------------------------*/
// Procedure...: RunOpenFileDialog()
// Description.: Demonstrates some new features of the Open dlg
// INPUT.......: HWND
// OUTPUT......: void
/*---------------------------------------------------------------*/
void RunOpenFileDialog(HWND hDlg)
{
	OPENFILENAME ofn;
	ZeroMemory(&ofn, sizeof(OPENFILENAME));
	
	TCHAR szInitialDir[MAX_PATH];
	TCHAR szFile[MAX_PATH];
	ZeroMemory(szFile, MAX_PATH);
	ZeroMemory(szInitialDir, MAX_PATH);

	// Fill out the structure
	SHGetSpecialFolderPath(NULL, szInitialDir, CSIDL_DESKTOP,0);
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.lpstrFilter = _T("All Files\0*.*");
	ofn.lpstrFile = szFile;
	ofn.nMaxFile = MAX_PATH;
	ofn.lpstrInitialDir = reinterpret_cast<LPSTR>(szInitialDir);
	ofn.Flags = OFN_ENABLEHOOK|OFN_EXPLORER;
	ofn.lpfnHook = reinterpret_cast<LPOFNHOOKPROC>(OFNHookProc);
	
	// Call the dialog
	if (GetOpenFileName(&ofn))
		MessageBox(hDlg, ofn.lpstrFile, NULL, NULL);
	return;
}





/*  End of file: Open.cpp  */
