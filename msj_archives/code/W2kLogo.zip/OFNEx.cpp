// OFNEx.cpp : Defines the extensions for the Open File Dialog
//

#include "ofnex.h"

// Handle of the keyboard hook
static HHOOK g_hHook=NULL;
static WNDPROC g_fnDlg=NULL;

// New wndproc for the Shell DefView window
LRESULT CALLBACK DVHandler(HWND, UINT, WPARAM, LPARAM);


// Context Menu Item IDs
#define CMD_SHORTCUT	30736	// Create Shortcut
#define CMD_DELETE		30737	// Delete
#define CMD_RENAME		30738	// Rename
#define CMD_PROPERTIES	30739	// Properties




/*---------------------------------------------------------------*/
// Procedure....: AdjustListViewStyle()
// Description..: Change some styles in the file listview
// Input........: HWND
// Output.......: void
/*---------------------------------------------------------------*/
void APIENTRY AdjustListViewStyle(HWND hDlg)
{
	// Get the Listview handle
	HWND hwndLV = GetListViewHandle(hDlg);

	// Remove the label edit style
	DWORD dwStyle = GetWindowStyle(hwndLV);
	SetWindowLong(hwndLV, GWL_STYLE, dwStyle & ~LVS_EDITLABELS);

	// Set some extended styles
	ListView_SetExtendedListViewStyle(hwndLV, 
		LVS_EX_FULLROWSELECT|LVS_EX_TRACKSELECT|LVS_EX_GRIDLINES);
	return;
}



/*---------------------------------------------------------------*/
// Procedure....: GrayRenameDeleteMenuItems()
// Description..: Turn some file object attributes off 
// Input........: HWND 
// Output.......: void
/*---------------------------------------------------------------*/
void APIENTRY GrayRenameDeleteMenuItems(HWND hDlg)
{
	// Get the Shell DefView handle (the listview's parent)
	HWND hwnd = GetParent(hDlg);
	HWND hwndDV = FindWindowEx(hwnd, NULL, 
		_T("SHELLDLL_DefView"), NULL);
	
	// Subclass the window to hook on context menu handle
	g_fnDlg = SubclassWindow(hwndDV, 
		reinterpret_cast<WNDPROC>(DVHandler));
}




/*---------------------------------------------------------------*/
// Procedure....: SetNoDeleteMode()
// Description..: Set/Reset the keyboard hook for file deletion
// Input........: BOOL
// Output.......: void
/*---------------------------------------------------------------*/
void APIENTRY SetNoDeleteMode(BOOL fSet)
{
	if (fSet)
		g_hHook = SetWindowsHookEx(WH_KEYBOARD, 
			reinterpret_cast<HOOKPROC>(KeybProc), 
			NULL, GetCurrentThreadId());
	else 
		UnhookWindowsHookEx(g_hHook);
}


/*---------------------------------------------------------------*/
// Procedure....: KeybProc()
// Description..: Handle keyboard activity
// Input........: int, WPARAM, LPARAM
// Output.......: UINT
/*---------------------------------------------------------------*/
UINT CALLBACK KeybProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	if (nCode <0)
		return CallNextHookEx(g_hHook, nCode, wParam, lParam);

	// Do not call CallNextHookEx to prevent the system to delete
	if (wParam==VK_DELETE)
		return 1;

	return CallNextHookEx(g_hHook, nCode, wParam, lParam);
}



/*---------------------------------------------------------------*/
// Procedure....: DVHandler()
// Description..: New listview window procedure
// Input........: HWND, UINT, WPARAM, LPARAM
// Output.......: LRESULT
/*---------------------------------------------------------------*/
LRESULT CALLBACK DVHandler(HWND hwnd, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uiMsg)
	{
		case WM_INITMENUPOPUP:	
			{
				HMENU hmenu = reinterpret_cast<HMENU>(wParam);
				int iNumItems = GetMenuItemCount(hmenu);
				int iItemID;

				// Rename is last but 2. 0-based index needed.  
				iItemID = GetMenuItemID(hmenu, (iNumItems-2)-1);
				if (iItemID == CMD_RENAME) {
					EnableMenuItem(hmenu, iItemID,
						MF_BYCOMMAND|MF_GRAYED);
				}
				
				// Delete is last but 3. 0-based index needed.
				iItemID = GetMenuItemID(hmenu,(iNumItems-3)-1);
				if (iItemID == CMD_DELETE) {
					EnableMenuItem(hmenu, iItemID,
						MF_BYCOMMAND|MF_GRAYED);
				}
			}
			break;
	}

	return CallWindowProc(g_fnDlg, hwnd, uiMsg, wParam, lParam);
}




/*---------------------------------------------------------------*/
// Procedure....: GetListViewHandle()
// Description..: Returns the handle of the listview
// Input........: HWND
// Output.......: HWND
/*---------------------------------------------------------------*/
HWND GetListViewHandle(HWND hDlg)
{
	HWND hwnd = GetParent(hDlg);
	HWND hwndDV = FindWindowEx(hwnd, NULL, 
		_T("SHELLDLL_DefView"), NULL);
	HWND hwndLV = FindWindowEx(hwndDV, NULL, 
		_T("SysListView32"), NULL);
	
	return hwndLV;
}


/*  End of file: OFNex.cpp  */