//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AWETest.rc
//
#define IDD_AWETEST                     105
#define IDC_WINDOW0TEXT                 1006
#define IDC_WINDOW0STORAGE              1007
#define IDC_WINDOW1STORAGE              1008
#define IDC_WINDOW1TEXT                 1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
