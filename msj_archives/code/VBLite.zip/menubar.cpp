//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "stdafx.H"
#include "menubar.H"

//-----------------------------------------------------------------------------------------------------------------
CToolPanel::CToolPanel()
{
	m_hFont	= ::CreateFont(
								8, 0, 0, 0, FW_NORMAL,
								FALSE,FALSE,FALSE,ANSI_CHARSET,
								OUT_DEFAULT_PRECIS,
								CLIP_DEFAULT_PRECIS,
								DEFAULT_QUALITY,DEFAULT_PITCH,
								_T("Ms Sans Serif")
						  );

}

//-----------------------------------------------------------------------------------------------------------------
CToolPanel::~CToolPanel()
{
	if(m_hFont)
	{
		::DeleteObject(m_hFont);
		m_hFont = NULL;
	}
}
//-----------------------------------------------------------------------------------------------------------------
LRESULT CToolPanel::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	DefWindowProc();
	
	RECT rc = {0,0,0,0};
	
	//toolbar
	m_wndToolbar.Create(this,1,m_hWnd,&rc);

	//Set the Font 
	SendMessage(WM_SETFONT,(WPARAM)m_hFont, MAKELPARAM(TRUE,0));
	
	InitRebar();

	bHandled = TRUE;
	return 0L;
}
//---------------------------------------------------------------------------------------------------------------------
LRESULT CToolPanel::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return 0L;
}

//---------------------------------------------------------------------------------------------------------------------
void CToolPanel::InitRebar()
{

	REBARINFO     rbi;
	rbi.cbSize = sizeof(REBARINFO); 
	SetBarInfo(&rbi);

	REBARBANDINFO rbInfo;
		
	rbInfo.cbSize = sizeof(REBARBANDINFO);
	rbInfo.fMask = RBBIM_STYLE | RBBIM_CHILD | RBBIM_CHILDSIZE ;
	rbInfo.fStyle = RBBS_CHILDEDGE | RBBS_GRIPPERALWAYS|RBBS_VARIABLEHEIGHT ;
	rbInfo.lpText = _T("");

	
	int cxTB = ::GetSystemMetrics(SM_CXFULLSCREEN);//GetToolbarLength();
	rbInfo.hwndChild = m_wndToolbar.m_hWnd;
	rbInfo.cxMinChild = cxTB;
	rbInfo.cyMinChild = 224;
	rbInfo.cx = cxTB;
	
	rbInfo.cxIdeal = cxTB;
	
	rbInfo.cyChild = rbInfo.cyMinChild;

	InsertBand(-1,&rbInfo);
}
//-----------------------------------------------------------------------------------------------------------------
LRESULT CToolPanel::OnToolbarCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	TBBUTTON tbButtons[] = 
	{
		{ 0,	ID_FILE_OPEN,						TBSTATE_ENABLED				,TBSTYLE_BUTTON, 0L, 0},
		{ 1,	ID_FILE_SAVE,						TBSTATE_ENABLED				,TBSTYLE_BUTTON, 0L, 0},

		{ -1,	-1,									TBSTATE_ENABLED				,TBSTYLE_SEP, 0L, 0},
		
		{ 2,	ID_OLE_INSERT_NEW,					TBSTATE_ENABLED				,TBSTYLE_BUTTON, 0L, 0},
		{ -1,	-1,									TBSTATE_ENABLED				,TBSTYLE_SEP, 0L, 0},
		
		{ 3,	ID_VIEW_SCRIPTER,					TBSTATE_ENABLED				,TBSTYLE_BUTTON, 0L, 0},
		{ -1,	-1,									TBSTATE_ENABLED				,TBSTYLE_SEP, 0L, 0},
		
		{ 4,	ID_RUN,								TBSTATE_ENABLED				,TBSTYLE_BUTTON, 0L, 0},
		{ 5,	ID_STOP,							0							,TBSTYLE_BUTTON, 0L, 0},
		
		{ -1,	-1,									TBSTATE_ENABLED				,TBSTYLE_SEP, 0L, 0},
		
		{ 6,	ID_APP_ABOUT,						TBSTATE_ENABLED				,TBSTYLE_BUTTON, 0L, 0}
	};

	m_wndToolbar.SetButtonStructSize(sizeof(TBBUTTON));
	m_wndToolbar.AddBitmap(11,IDR_MAINFRAME);
	m_wndToolbar.AddButtons(11,tbButtons);
	m_wndToolbar.AutoSize();

	bHandled = TRUE;
	return 0L;
}
//-----------------------------------------------------------------------------------------------------------------------------
LRESULT CToolPanel::OnRelayToolTip(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
{
	LPTOOLTIPTEXT lpTTText = (LPTOOLTIPTEXT)pnmh;
	int nStringIDs[]={
						IDS_FILE_OPEN,
						IDS_FILE_SAVE,
						-1,
						IDS_OLE_INSERT_NEW,
						-1,
						IDS_VIEW_SCRIPTER,
						-1,
						IDS_RUN,
						IDS_STOP,
						-1,
						IDS_APP_ABOUT
					};
	
	int nIndex = m_wndToolbar.CommandToIndex(lpTTText->hdr.idFrom);
	if (nIndex >=0 && nIndex <sizeof(nStringIDs)/sizeof(nStringIDs[0]))
	{
		lpTTText->hinst	   = _Module.GetModuleInstance();
		lpTTText->lpszText = MAKEINTRESOURCE(nStringIDs[nIndex]);
	}
	return 0L;
}
//-----------------------------------------------------------------------------------------------------------------------------
