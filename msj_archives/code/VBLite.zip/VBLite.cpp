//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

// DCon.cpp : Implementation of WinMain
#include "stdafx.h"
#include <initguid.h>
#include "VBLite.h"
#include "VBLite_i.c"
#include "Form.h"
#include "ContainerFrame.H"
#include "CommCtrl.H"
#include "GeneralPage.h"
#include "ExtendedDispatch.h"


#pragma comment(lib, "comctl32.lib")


//--------------------------------------------------------------------------------------------------------------------

CComModule _Module;

//--------------------------------------------------------------------------------------------------------------------

BEGIN_OBJECT_MAP(ObjectMap)
	OBJECT_ENTRY_NON_CREATEABLE(CForm)
	OBJECT_ENTRY(CLSID_GeneralPage, CGeneralPage)
	OBJECT_ENTRY_NON_CREATEABLE(CExtendedDispatch)
END_OBJECT_MAP()

//--------------------------------------------------------------------------------------------------------------------
LPCTSTR FindOneOf(LPCTSTR p1, LPCTSTR p2)
{
    while (p1 != NULL && *p1 != NULL)
    {
        LPCTSTR p = p2;
        while (p != NULL && *p != NULL)
        {
            if (*p1 == *p)
                return CharNext(p1);
            p = CharNext(p);
        }
        p1 = CharNext(p1);
    }
    return NULL;
}

//--------------------------------------------------------------------------------------------------------------------

extern "C" int WINAPI _tWinMain(HINSTANCE hInstance,HINSTANCE, LPTSTR lpCmdLine, int nCmdShow)
{
	// Track memory leaks
  _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

    lpCmdLine = GetCommandLine(); //this line necessary for _ATL_MIN_CRT

    ::OleInitialize(0);
	_Module.Init(ObjectMap, hInstance, &LIBID_VBLiteLib);

	AtlAxWinInit();
    TCHAR szTokens[] = _T("-/");

    int nRet = 0;
	BOOL bRun = TRUE;
    LPCTSTR lpszToken = FindOneOf(lpCmdLine, szTokens);

    while (lpszToken != NULL)
    {
        if (lstrcmpi(lpszToken, _T("UnregServer"))==0)
        {
            _Module.UpdateRegistryFromResource(IDR_FORM, FALSE);
            nRet = _Module.UnregisterServer(TRUE);
            bRun = FALSE;
            break;
        }
        if (lstrcmpi(lpszToken, _T("RegServer"))==0)
        {
            _Module.UpdateRegistryFromResource(IDR_FORM, TRUE);
            nRet = _Module.RegisterServer(TRUE);
            bRun = FALSE;
            break;
        }
        lpszToken = FindOneOf(lpszToken, szTokens);
    }

	if(bRun)
	{
		//Initialize Common controls that we may use 
		INITCOMMONCONTROLSEX iccx;
		iccx.dwSize = sizeof(iccx);
		iccx.dwICC =  ICC_WIN95_CLASSES  |ICC_COOL_CLASSES | ICC_BAR_CLASSES | ICC_TAB_CLASSES |ICC_PROGRESS_CLASS | ICC_UPDOWN_CLASS | ICC_TREEVIEW_CLASSES   ;	
		::InitCommonControlsEx(&iccx);
		
		HRESULT hr = _Module.RegisterClassObjects(CLSCTX_LOCAL_SERVER,REGCLS_MULTIPLEUSE);
		HMENU hMenu = LoadMenu(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_CONTRTYPE));

		//create the container app-frame
		CContainerFrame wndFrame;
		
		wndFrame.GetWndClassInfo().m_wc.hIcon = ::LoadIcon(_Module.GetResourceInstance(),MAKEINTRESOURCE(IDI_FORM));
		wndFrame.GetWndClassInfo().m_wc.hbrBackground = (HBRUSH)(COLOR_APPWORKSPACE+1);
		wndFrame.Create(GetDesktopWindow(), CWindow::rcDefault, _T("Yet Another Control Container [Design]"), 0, 0, (UINT)hMenu);
		wndFrame.ShowWindow(SW_SHOWMAXIMIZED);
		wndFrame.UpdateWindow();
		wndFrame.GetEnvelopeForSite()->SetActiveWindow();
		wndFrame.GetEnvelopeForSite()->SetFocus();
		
		MSG msg;
		while (::GetMessage(&msg, 0, 0, 0))
		{
			if( !wndFrame.IsModeless()  && wndFrame.PreTranslateAccelerator(&msg,hr) ){ continue; }

			::TranslateMessage(&msg);
			::DispatchMessage(&msg);
		}

		_Module.RevokeClassObjects();
	}
	
	_Module.Term();
    
	::OleUninitialize();
    
	return 0;
}

//--------------------------------------------------------------------------------------------------------------------
