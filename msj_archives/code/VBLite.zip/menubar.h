//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#pragma once
#ifndef __MENUBAR_H_
#define __MENUBAR_H_

#include "resource.H"
#include "Base_Include\ATLControls.H"
using namespace ATLControls;

#define ID_RUN			2000
#define ID_STOP			3000	
		
typedef CWindowImplBaseT<CReBarCtrl, CWinTraits<WS_CHILD | WS_VISIBLE| WS_CLIPSIBLINGS | WS_CLIPCHILDREN |CCS_NODIVIDER | CCS_NOPARENTALIGN | RBS_BANDBORDERS | RBS_VARHEIGHT | RBS_AUTOSIZE> > CWindowImplRebar;

//------------------------------------------------------------------------------------------------------------

class CToolPanel: public CWindowImplRebar
{
private:
	
public:
	CToolPanel();
	virtual ~CToolPanel();
	
BEGIN_MSG_MAP(CToolPanel)
	MESSAGE_HANDLER(WM_CREATE, OnCreate)
	MESSAGE_HANDLER(WM_SIZE, OnSize)
	NOTIFY_CODE_HANDLER(RBN_BEGINDRAG, OnRebarDrag)

ALT_MSG_MAP(1)
		MESSAGE_HANDLER(WM_CREATE, OnToolbarCreate)
ALT_MSG_MAP(2000)
		NOTIFY_CODE_HANDLER(TTN_NEEDTEXT, OnRelayToolTip)
END_MSG_MAP()
		
public:
	LRESULT OnRebarDrag(int idCtrl, LPNMHDR pnmh, BOOL& bHandled){	return 1;}

	LRESULT OnRelayToolTip(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);
	
	
	LRESULT OnToolbarCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled) { DefWindowProc(); return 0L; }

	void EnableToolBtn(UINT nCmdID, BOOL b)
	{
		m_wndToolbar.EnableButton(nCmdID,b);
	}
		
public:
	
	DECLARE_WND_SUPERCLASS(_T("menu_bar"),GetWndClassName());
	
	HWND Create(HWND hWndParent, RECT& rcPos, LPCTSTR szWindowName = NULL,
			DWORD dwStyle = 0, DWORD dwExStyle = 0,
			UINT nID = 0, LPVOID lpCreateParam = NULL)
	{
		if (GetWndClassInfo().m_lpszOrigName == NULL)
			GetWndClassInfo().m_lpszOrigName = GetWndClassName();
		ATOM atom = GetWndClassInfo().Register(&m_pfnSuperWindowProc);
		
		dwStyle =	WS_CHILD | WS_BORDER|WS_VISIBLE| WS_CLIPSIBLINGS | WS_CLIPCHILDREN |
					CCS_TOP |CCS_NOMOVEY |CCS_NORESIZE|
					RBS_BANDBORDERS | RBS_VARHEIGHT | RBS_AUTOSIZE;

		dwExStyle = WS_EX_LEFT | WS_EX_LTRREADING | 
					WS_EX_RIGHTSCROLLBAR | WS_EX_TOOLWINDOW;

		return CWindowImplRebar::Create(hWndParent, rcPos, szWindowName,dwStyle, dwExStyle, nID, atom, lpCreateParam);
	}

	int GetToolbarLength()	
	{
		int nWidth = 0;
		RECT rc;

		int nCount = SendMessage(m_wndToolbar.m_hWnd, TB_BUTTONCOUNT, 0, 0);
		for( int i = 0; i < nCount; i++ )
		{
			SendMessage(m_wndToolbar.m_hWnd, TB_GETITEMRECT, i, (LPARAM)&rc);
			nWidth += rc.right - rc.left;
		}

		return nWidth;
	}

private:
	void InitRebar();
	
	
private:
	HFONT							m_hFont;
	CContainedWindowT<CToolBarCtrl, CWinTraits<	WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|
												CCS_NODIVIDER|CCS_NORESIZE|CCS_NOPARENTALIGN|CCS_TOP|
												TBSTYLE_LIST|TBSTYLE_TOOLTIPS|TBSTYLE_FLAT> > m_wndToolbar;


};




#endif