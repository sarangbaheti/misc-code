//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#pragma once
#ifndef _PERSISTBAG_H_
#define _PERSISTBAG_H_

#include <vector>
#include <string>
#include "Reader.H"
#include "Writer.H"
using namespace std;

//---------------------------------------------------------------------------------------------------------------------
//quick & dirty implementation of a propertybag
//---------------------------------------------------------------------------------------------------------------------
typedef std::vector<MainPropertyBag>::iterator	itPropertyBag;
typedef std::vector<SubPropBag>::iterator		itSubPropertyBag;

class ATL_NO_VTABLE CPropertyBag : public CComObjectRoot, public IPropertyBag
{
public:
	CPropertyBag():	m_bFirstInit(true),
					m_bIsCurrentObjControl(true),
					m_nLastControl(0)
	{}

	~CPropertyBag(){}
	DECLARE_PROTECT_FINAL_CONSTRUCT()

	BEGIN_COM_MAP(CPropertyBag)
		COM_INTERFACE_ENTRY(IPropertyBag)
	END_COM_MAP()	


public:

	STDMETHOD(Read)(LPCOLESTR pszPropName,VARIANT* pVar,IErrorLog* pErrorLog);
	STDMETHOD(Write)(LPCOLESTR pszPropName,VARIANT* pVar);
	HRESULT ReadProperty(LPCOLESTR pszPropName,VARIANT* pVar,IErrorLog* pErrorLog);
	HRESULT ReadObject(LPCOLESTR pszPropName,VARIANT* pVar,IErrorLog* pErrorLog);

public:
	void TheObjectIsAControl()
	{
		m_bIsCurrentObjControl = true;
		m_nLastControl++;
	}

	CReader& GetReader(){ return m_Reader; }
	CWriter& GetWriter(){ return m_Writer; }
	
	void ResetPropertyBag() { m_bFirstInit = true; }

private:
	bool			m_bFirstInit;
	bool			m_bIsCurrentObjControl;
	long			m_nLastControl;
	CWriter			m_Writer;
	CReader			m_Reader;
};

//---------------------------------------------------------------------------------------------------------------------

#endif