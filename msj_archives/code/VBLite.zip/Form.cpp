//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "stdafx.h"
#include "VBLite.h"
#include "Form.h"
#include "Base_Include\context.H"
#include "oledlg.H"
#include "PersistBag.H"
#include "ContainerFrame.H"
#include "browsetab.h"
#include "ScriptSite.H"
#include "algorithm"

//------------------------------------------------------------------------------------------------------------------	
struct IsEmptySite  
{
	bool operator()(CAxWindowHandle *pSiteWindow) const
	{  
		if((pSiteWindow) && (pSiteWindow->m_hWnd == NULL) ) 
		{
			return true;
		}
		return false;
	}   
};
//------------------------------------------------------------------------------------------------------------------	
//Enumeration support for IOleContainer
//
//
struct _CopyIUnknownFromCAxWindowHandle
{
	static HRESULT copy(IUnknown** ppUnk, CAxWindowHandle** ppAxWindow) 
	{
		if(!ppAxWindow || !ppUnk || !(*ppAxWindow)){ return E_POINTER; }

		*ppUnk = 0;
		return  (*ppAxWindow)->QueryControl(ppUnk);
	}
	
	static void init(IUnknown** ppUnk){}
	static void destroy(IUnknown** ppUnk) 
	{
		if(*ppUnk) 
			(*ppUnk)->Release(); 
	}
};

//------------------------------------------------------------------------------------------------------------------	
HWND CForm::GetSimpleFrameControlHWND(const POINT& pt)
{
	for(itAxWindowImpl it = m_listSites.begin(); it != m_listSites.end();it++)
	{	
		if( (*it) && (*it)->m_pExtendedDispatchObj)
		{
			long nWidth = 0;long nHeight = 0;RECT rc;
			(*it)->m_pExtendedDispatchObj->get_PositionX(&rc.left);
			(*it)->m_pExtendedDispatchObj->get_PositionY(&rc.top);
			(*it)->m_pExtendedDispatchObj->get_SizeX(&nWidth);
			(*it)->m_pExtendedDispatchObj->get_SizeY(&nHeight);
			rc.right = rc.left + nWidth;
			rc.bottom = rc.top + nHeight;
			(*it)->MapWindowPoints(m_hWnd,const_cast<POINT*>(&pt),1);
			if( ::PtInRect(&rc,pt) && (*it)->IsSimpleFrame())
			{
				HWND hWnd = (*it)->GetWindow(GW_CHILD);
				if(::IsWindow(hWnd))
				{
					return hWnd;
				}
				else
				{
					return (*it)->m_hWnd;
				}
			}
		}
	}
	return 0;
}
//------------------------------------------------------------------------------------------------------------------	
LRESULT CForm::OnCreate(UINT , WPARAM , LPARAM , BOOL& )
{
	InPlaceActivate(OLEIVERB_UIACTIVATE);
	SetActiveWindow();
	SetFocus();

	ACCEL ac = { 0,0,0 };
	HACCEL hac = CreateAcceleratorTable(&ac, 1);
	m_FrameInfo.cb = sizeof(OLEINPLACEFRAMEINFO);
	m_FrameInfo.fMDIApp = FALSE;
	m_FrameInfo.hwndFrame = GetParent();
	m_FrameInfo.haccel = hac;
	m_FrameInfo.cAccelEntries = 1;
	
	return 0L;
}
//------------------------------------------------------------------------------------------------------------------	
CAxWindowHandle* CForm::CreateAndEmbedControlOnForm(const POINT &pt, bool bUninit,bool bBinary)
{
	CAxWindowHandle *pSiteNode = new CAxWindowHandle(m_pData);
	if(!pSiteNode){ return 0; }
	
	RECT rc = {pt.x,pt.y,300,300};
	USES_CONVERSION;						  
		
	DWORD dwStatus = 0;
	CLSID clsid ;
	::CLSIDFromString(m_bstrCLSID,&clsid);
	::OleRegGetMiscStatus(clsid, DVASPECT_CONTENT, &dwStatus);
	if(dwStatus & OLEMISC_SIMPLEFRAME)
	{
		pSiteNode->SetSimpleFrame(true);
	}
	if(dwStatus & OLEMISC_INVISIBLEATRUNTIME)
	{
		pSiteNode->SetInvisAtRunTime(true);
	}

	HWND h = m_hWnd;
	if(!bUninit)
	{
		HWND hWndSimpleFrame = GetSimpleFrameControlHWND(pt);
		if(hWndSimpleFrame)
		{
			h = hWndSimpleFrame;
		}
	}
	
	if(!bBinary)
	{
		pSiteNode->Create(h, rc, OLE2T(m_bstrCLSID), WS_CHILD |WS_VISIBLE | 
																 WS_TABSTOP|WS_BORDER|
																 WS_CLIPCHILDREN |
																 WS_CLIPSIBLINGS |WS_THICKFRAME,
																 0);
	}
	else
	{
		pSiteNode->Create(h, rc, _T(NULL), WS_CHILD | WS_OVERLAPPED|WS_VISIBLE | WS_CLIPCHILDREN |WS_CLIPSIBLINGS |WS_BORDER|WS_THICKFRAME|WS_TABSTOP,0);
		pSiteNode->CreateControlEx(m_bstrCLSID, m_spStream,0,0);

	}
	
	CComPtr<IUnknown> spUnk;
	HRESULT hr = pSiteNode->QueryControl(&spUnk);

	if(FAILED(hr))
	{
		pSiteNode->DestroyWindow();
		pSiteNode->m_hWnd =0;
		delete pSiteNode; pSiteNode = 0;
		return 0L;
	}
		
	pSiteNode->SubclassControl();
	m_listSites.push_back(pSiteNode);


	if(pSiteNode->IsInvisAtRunTime())
	{
		CComPtr<IOleObject> spObj;
		if(SUCCEEDED( pSiteNode->QueryControl(&spObj) ))
		{
			SIZEL sz;
			spObj->GetExtent(DVASPECT_CONTENT,&sz);    
			AtlHiMetricToPixel(&sz,&sz);
			pSiteNode->SetWindowPos(0,pt.x,pt.y,sz.cx,sz.cy,SWP_NOZORDER);
		}
	}
	
	if(!bUninit)
	{
		InitScriptingForControl(pSiteNode);
	}

	pSiteNode->RedrawWindow();
	pSiteNode->SetFocus();
			
	return pSiteNode;
}
//----------------------------------------------------------------------------------------------------------
HRESULT CForm::InitScriptingForControl(CAxWindowHandle *pSiteNode)
{		
	if(!pSiteNode){ return E_POINTER; }

	CComPtr<IDispatch> spDisp;
	HRESULT hr = pSiteNode->QueryControl(&spDisp);
	if(FAILED(hr)) return hr;
	
	CComPtr<IOleControlSite> spControlSite;
	hr = pSiteNode->QueryHost(&spControlSite);
	if(FAILED(hr)) return hr;
		
	CComPtr<IDispatch> spExtDisp;
	hr = spControlSite->GetExtendedControl(&spExtDisp);
	if(FAILED(hr)) return hr;

	CComQIPtr<IExtendedDispatch> spRealExtDisp(spExtDisp);
	if(spRealExtDisp)
	{
		CComBSTR strNewName;
		hr = spRealExtDisp->get_Name(&strNewName);
		if(FAILED(hr)) return hr;

		hr = SetScriptNameValuePair(spDisp,strNewName);
		if(FAILED(hr)) return hr;
	}
	
	//Set the advisory connection
	CComPtr<IUnknown> spUnkCtl;
	hr = pSiteNode->QueryControl(&spUnkCtl);
	pSiteNode->InitializeEventMap(spUnkCtl);
	
	return hr;
}
//------------------------------------------------------------------------------------------------------------------	
HRESULT CForm::SetScriptNameValuePair(IDispatch *pDisp, CComBSTR& strNewName, CComBSTR strOldName)
{
	if(!pDisp){ return E_POINTER; }

	return m_pScripterObj->UpdateItem(pDisp,strNewName,strOldName);
}
//------------------------------------------------------------------------------------------------------------------	
LRESULT CForm::OnLButtonDown(UINT, WPARAM , LPARAM lParam, BOOL& )
{
	if(m_bSelected)
	{
		m_bSelected = FALSE;
		ReleaseMouse();
		POINT pt = {LOWORD(lParam),HIWORD(lParam)};
		
		CreateAndEmbedControlOnForm(pt);
	}
	
	if(m_pData)
	{
		CBrowseTabContainer* pBC = 	m_pData->GetBrowserContainer()	;
		pBC->ClearListViews();
				
		//ambient dispatch
		CComPtr<IUnknown> spUnk;
		m_pData->GetEnvelopeForSite()->QueryHost(&spUnk);
		CComQIPtr<IDispatch> spDispAmbient(spUnk);
		pBC->GetBrowseTab().GetAmbientBrowser().put_Dispatch(spDispAmbient);
		
		//native properties
		CComQIPtr<IDispatch> spDisp(GetUnknown());
		pBC->GetBrowseTab().GetNativeBrowser().put_Dispatch(spDisp);

		//extended properties
		CComPtr<IDispatch> spExtDisp;
		m_pData->GetEnvelopeForSite()->m_pExtendedDispatchObj->QueryInterface(&spExtDisp);
		pBC->GetBrowseTab().GetExtendedBrowser().put_Dispatch(spExtDisp);
		
		//finaly fill the control enumeration combo
		UpdateControlEnumeration();
	}
	return 0L;
}
//------------------------------------------------------------------------------------------------------------------	
LRESULT CForm::OnShowScriptWindow(UINT, WPARAM, LPARAM , BOOL&)
{
	BOOL bUserMode = TRUE;
	GetAmbientUserMode(bUserMode);
	if(bUserMode) //RunMode
		return 0L;

	if(m_pScripterObj && m_pData && m_pData->m_hWnd)
	{
		m_pScripterObj->Create(m_pData->m_hWnd);
		
		if(m_pScripterObj->m_hWnd)
		{
			m_pScripterObj->ShowWindow(SW_SHOW);
		}
	}
	return 0L;
}
//------------------------------------------------------------------------------------------------------------------	
LRESULT CForm::OnDialogColor(UINT, WPARAM , LPARAM, BOOL&)
{
	ClearTheListOfDeletedSites();

	BOOL bUserMode = TRUE;
	GetAmbientUserMode(bUserMode);
		
	if(bUserMode) //RunMode
		return (LRESULT)m_hBrRunMode;
	else //DesignMode
		return (LRESULT)m_hBrGrid;
}
//------------------------------------------------------------------------------------------------------------------	
//This gets called in OnIdle processing or explicitly at times
bool CForm::ClearTheListOfDeletedSites()
{
	if(!m_bDeleted) { return false; }

	itAxWindowImpl itSiteWindow = m_listSites.begin();
	while (itSiteWindow!= m_listSites.end())
	{
		itSiteWindow = find_if(m_listSites.begin(),m_listSites.end(),IsEmptySite());
		if(itSiteWindow!= m_listSites.end() )
		{
			delete (*itSiteWindow);
			(*itSiteWindow) = NULL;
			m_listSites.erase(itSiteWindow);
		}
	}
	return m_bDeleted = true;
}
//------------------------------------------------------------------------------------------------------------------	
LRESULT CForm::OnSetFocus(UINT, WPARAM , LPARAM , BOOL& )
{
	UpdateControlEnumeration();
	return 0L;
}
//------------------------------------------------------------------------------------------------------------------	
LRESULT CForm::OnKillFocus(UINT, WPARAM, LPARAM , BOOL& )
{
	ReleaseInPlaceActiveObject();
	
	return 0L;
}
//------------------------------------------------------------------------------------------------------------------	
LRESULT CForm::OnDestroy(UINT, WPARAM , LPARAM , BOOL& )
{
	Close();//Now delete all the sites and embeddings

	return 0L;
}

//------------------------------------------------------------------------------------------------------------------	
STDMETHODIMP CForm::OnAmbientPropertyChange(DISPID dispid)
{
	if (dispid == DISPID_AMBIENT_BACKCOLOR)
	{
		SetBackgroundColorFromAmbient();
		FireViewChange();
	}
	return IOleControlImpl<CForm>::OnAmbientPropertyChange(dispid);
}
//------------------------------------------------------------------------------------------------------------------	
// ISupportsErrorInfo
STDMETHODIMP CForm::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IForm,
	};
	for (int i=0; i<sizeof(arr)/sizeof(arr[0]); i++)
	{
		if (::InlineIsEqualGUID(*arr[i], riid))
			return S_OK;
	}
	return S_FALSE;
}
//------------------------------------------------------------------------------------------------------------------		
// IOleWindow
STDMETHODIMP CForm::GetWindow(HWND* phwnd)
{
	if(!phwnd){ return E_POINTER; }

	if(!m_hWnd) 
	{ 
		return E_FAIL; 
	}
	
	*phwnd = m_hWnd;
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------	
STDMETHODIMP CForm::ContextSensitiveHelp(BOOL /*fEnterMode*/)
{
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------	
// IOleInPlaceUIWindow
STDMETHODIMP CForm::GetBorder(LPRECT /*lprectBorder*/)
{
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------	
STDMETHODIMP CForm::RequestBorderSpace(LPCBORDERWIDTHS /*pborderwidths*/)
{
	return INPLACE_E_NOTOOLSPACE;
}
//------------------------------------------------------------------------------------------------------------------	
STDMETHODIMP CForm::SetBorderSpace(LPCBORDERWIDTHS /*pborderwidths*/)
{
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------	
STDMETHODIMP CForm::SetActiveObject(IOleInPlaceActiveObject* pActiveObject, LPCOLESTR pszObjName)
{
	ReleaseInPlaceActiveObject();
	m_spInPlaceActiveObj = pActiveObject;
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------	
// IOleInPlaceFrameWindow
STDMETHODIMP CForm::InsertMenus(HMENU /*hmenuShared*/, LPOLEMENUGROUPWIDTHS /*lpMenuWidths*/)
{
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------	
STDMETHODIMP CForm::SetMenu(HMENU /*hmenuShared*/, HOLEMENU /*holemenu*/, HWND /*hwndActiveObject*/)
{
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------	
STDMETHODIMP CForm::RemoveMenus(HMENU /*hmenuShared*/)
{
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------	
//We display control's events here:-)
STDMETHODIMP CForm::SetStatusText(LPCOLESTR pszStatusText)
{
	if(m_pData)
	{
		USES_CONVERSION;
		m_pData->GetStatusBar().SetText(0, OLE2T(pszStatusText), 0);  
	}
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------	
STDMETHODIMP CForm::EnableModeless(BOOL fEnable)
{
	//we take care of the scripter window
	if(m_pScripterObj && m_pScripterObj->m_hWnd)
		m_pScripterObj->EnableWindow(fEnable);
	
	//and let frame take care of all its owned popups
	if(m_pData)
		m_pData->EnableOrDisableOwnedPopups(fEnable);
	
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------	
STDMETHODIMP CForm::TranslateAccelerator(LPMSG lpMsg, WORD wID)
{
	return S_FALSE;
}

//------------------------------------------------------------------------------------------------------------------	
STDMETHODIMP CForm::get_ControlBox(VARIANT_BOOL *pVal)
{
	if(!pVal) {return E_POINTER;}

	*pVal = m_bControlBox;
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------
STDMETHODIMP CForm::put_ControlBox(VARIANT_BOOL newVal)
{
	m_bControlBox = newVal;
	
	CWindow wndFomSite;
	wndFomSite.Attach(GetParent());
	if(m_bControlBox == VARIANT_TRUE)
	{
		wndFomSite.ModifyStyle(wndFomSite.GetStyle(), WS_OVERLAPPEDWINDOW|WS_VISIBLE| 
													 WS_CLIPSIBLINGS |WS_CLIPCHILDREN |
													 WS_OVERLAPPED);
			
		
		wndFomSite.ModifyStyleEx(wndFomSite.GetExStyle(),WS_EX_LEFT|WS_EX_LTRREADING|
														WS_EX_RIGHTSCROLLBAR|
														WS_EX_APPWINDOW|WS_EX_WINDOWEDGE);

		
		::SetClassLong(wndFomSite.m_hWnd,GCL_STYLE,CS_NOCLOSE);
	}
	else
	{
		wndFomSite.ModifyStyle(wndFomSite.GetStyle(),WS_CAPTION|WS_VISIBLE| 
												WS_OVERLAPPED | WS_CLIPSIBLINGS |
												WS_CLIPCHILDREN |WS_MINIMIZEBOX|
												WS_MAXIMIZEBOX |WS_THICKFRAME);
		
		wndFomSite.ModifyStyleEx(wndFomSite.GetExStyle(),WS_EX_LEFT|WS_EX_LTRREADING|
														WS_EX_RIGHTSCROLLBAR|
														WS_EX_APPWINDOW|WS_EX_WINDOWEDGE);
	}
		
	wndFomSite.SetActiveWindow();
	
	m_bRequiresSave = TRUE;
	SetDirty(TRUE);
	FireOnChanged(1); 
	FireViewChange();

	wndFomSite.Detach();
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------
HRESULT CForm::PutSelectionInfo(CComBSTR& strclsid)
{
	m_bstrCLSID = strclsid;
	m_bSelected = TRUE;
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------
HRESULT CForm::StartScriptingEngine()
{
	HRESULT hr = m_pScripterObj->CreateInstanceWithData(&m_pScripterObj,this);
	if(FAILED(hr)) return hr;

	ULONG l = m_pScripterObj->AddRef();
	CComBSTR strName = L"Form1"; //Note that we hard code this as we know this is the extended name(ideally we should get it from the extended disaptch)
	CComPtr<IDispatch> spDisp;
	GetUnknown()->QueryInterface(&spDisp);
	SetScriptNameValuePair(spDisp,strName);
	
	return hr;
}
//------------------------------------------------------------------------------------------------------------------
HRESULT CForm::ShutDownScriptingEngine()
{
	if(m_pScripterObj && m_pScripterObj->m_hWnd)
	{
		m_pScripterObj->ShowWindow(SW_HIDE);
		m_pScripterObj->DestroyWindow();
	}
	if(m_pScripterObj)
	{
		m_pScripterObj->FinalRelease();
		m_pScripterObj->Release();
		m_pScripterObj = 0;
	}
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------
HRESULT CForm::FinalConstruct()
{
	StartScriptingEngine();
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------
void CForm::FinalRelease()
{
	Close();
}
//------------------------------------------------------------------------------------------------------------------
HRESULT CForm::WriteControlHeaders()
{
	CComPtr<IPropertyBag> spBag;
	HRESULT hr = m_pData->m_pPropBagObj->QueryInterface(&spBag);
	if(FAILED(hr))  return hr; 
	
	for(itAxWindowImpl it = m_listSites.begin(); it != m_listSites.end();it++)
	{	
		if(*it)
		{
			CComPtr<IPersistPropertyBag> spPersistPropBag;
			hr = (*it)->QueryControl(&spPersistPropBag);
			
			if(SUCCEEDED(hr))
			{
				CLSID clsid;
				spPersistPropBag->GetClassID(&clsid);
				m_pData->m_pPropBagObj->GetWriter().WriteHeader(clsid); 
				spPersistPropBag.Release();
			}
		}
	}

	return hr;
}
//------------------------------------------------------------------------------------------------------------------
//No error checking done !
//
HRESULT CForm::SaveText()
{
	CComPtr<IPropertyBag> spBag;
	HRESULT hr = m_pData->m_pPropBagObj->QueryInterface(&spBag);
	if(FAILED(hr))  return hr; 

	for(itAxWindowImpl it = m_listSites.begin(); it != m_listSites.end();it++)
	{	
		if(*it)
		{
			CComPtr<IPersistPropertyBag> spPersistPropBag;
			
			hr = (*it)->QueryControl(&spPersistPropBag);
			
			if(SUCCEEDED(hr))
			{
				CLSID clsid;
				spPersistPropBag->GetClassID(&clsid);

				//Extended Properties
				CComPtr<IPersistPropertyBag> spExtendedPPB;
				if((*it)->m_pExtendedDispatchObj)
				{
					hr = (*it)->m_pExtendedDispatchObj->QueryInterface(&spExtendedPPB);
				}

				//write the header for each control first
				m_pData->m_pPropBagObj->GetWriter().WriteControlHeader(clsid);			
				

				//Save Extended Properties
				if(spExtendedPPB)
				{
					hr = spExtendedPPB->Save(spBag,TRUE,TRUE);
				}
				
				//now, save the control's native properties
				hr = spPersistPropBag->Save(spBag,TRUE,TRUE);
				
				//write the footer for each control first
				m_pData->m_pPropBagObj->GetWriter().WriteControlFooter();				
				
				spPersistPropBag.Release();
			}
		}
	}
	
	return hr;
}
//------------------------------------------------------------------------------------------------------------------
//No error checking done !
//
HRESULT CForm::OpenText()
{
	CComPtr<IPropertyBag> spBag;
	HRESULT hr = m_pData->m_pPropBagObj->QueryInterface(&spBag);
	if(FAILED(hr)) { return 0L; }

	if(!m_listSites.empty()) //if controls exist delete 'em
	{
		DeleteAllEmbeddings();//Close();
	}
	
	for(UINT n=1; n< m_pData->m_pPropBagObj->GetReader().m_ReaderInfo.m_nControls ;n++)
	{
		LPOLESTR pszCLSID = 0;
		::StringFromCLSID(m_pData->m_pPropBagObj->GetReader().m_ReaderInfo.m_pCLSID[n],&pszCLSID);
		m_bstrCLSID = pszCLSID;

		if(m_pData)
		{
			m_pData->GetToolWindow().LoadToolBoxBmp(pszCLSID);
		}
		

		POINT pt = {0,0};
		CAxWindowHandle *pSiteNode = CreateAndEmbedControlOnForm(pt,true);

		if(pszCLSID) { CoTaskMemFree(pszCLSID);pszCLSID = 0;}
				
		//Load all the persisted properties
		CComPtr<IPersistPropertyBag> spPersistPropBag;
		hr = pSiteNode->QueryControl(&spPersistPropBag);
				
		m_pData->m_pPropBagObj->TheObjectIsAControl(); // set the current clsid of the bag for the control
		

		//Extended Properties
		CComPtr<IPersistPropertyBag> spExtendedPPB;
				
		if(pSiteNode->m_pExtendedDispatchObj)
		{
			hr = pSiteNode->m_pExtendedDispatchObj->QueryInterface(&spExtendedPPB);

			if(SUCCEEDED(hr)) //Load EPs
			{	
				hr = spExtendedPPB->InitNew();
				hr = spExtendedPPB->Load(spBag,NULL);
				//ok. now get the extended properties for the window rect
				if(SUCCEEDED(hr))
				{
					long nWidth = 0;long nHeight = 0;RECT rc;
					pSiteNode->m_pExtendedDispatchObj->get_PositionX(&rc.left);
					pSiteNode->m_pExtendedDispatchObj->get_PositionY(&rc.top);
					pSiteNode->m_pExtendedDispatchObj->get_SizeX(&nWidth);
					pSiteNode->m_pExtendedDispatchObj->get_SizeY(&nHeight);
					pSiteNode->SetWindowPos(HWND_TOP,rc.left,rc.top,nWidth,nHeight,SWP_NOZORDER);	
					
					
					//Re-Resize Invis-at runtime controls
					DWORD dwStatus = 0;
					::OleRegGetMiscStatus(m_pData->m_pPropBagObj->GetReader().m_ReaderInfo.m_pCLSID[n], DVASPECT_CONTENT, &dwStatus);
					if(dwStatus & OLEMISC_INVISIBLEATRUNTIME)
					{
						pSiteNode->SetInvisAtRunTime(true);
						CComPtr<IOleObject> spObj;
						if(SUCCEEDED( pSiteNode->QueryControl(&spObj) ))
						{
							SIZEL sz;
							spObj->GetExtent(DVASPECT_CONTENT,&sz);    
							AtlHiMetricToPixel(&sz,&sz);
							pSiteNode->SetWindowPos(0,rc.left,rc.top,sz.cx,sz.cy,SWP_NOZORDER);
						}
					}

					//Reparent if this was within a simpleframe control
					POINT pt;
					pt.x = rc.left;
					pt.y = rc.top;
					HWND hWndSimpleFrame = GetSimpleFrameControlHWND(pt);
					if(hWndSimpleFrame && hWndSimpleFrame != m_hWnd)
					{
						pSiteNode->SetParent(hWndSimpleFrame); 
					}

				}
				spExtendedPPB.Release();
			}
		}

		//native properties
		hr = spPersistPropBag->InitNew();
		hr = spPersistPropBag->Load(spBag,NULL);
		
		/*if(FAILED(hr))
		{	
			MessageBox(_T("One or more controls failed to load") );
			Close(); 
			return E_FAIL; 
		}*/

		InitScriptingForControl(pSiteNode);
	}

	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------
//
#ifdef __DOMEnabled_
HRESULT CForm::SaveXML(IXMLDOMDocument *pDoc)
{
	for(itAxWindowImpl it = m_listSites.begin(); it != m_listSites.end();it++)
	{	
		if(*it)
		{
			CComPtr<IXMLDOMElement> pRoot;
			HRESULT hr = pDoc->get_documentElement(&pRoot);
			if (FAILED(hr)) return hr;
			
			CComPtr<IXMLDOMNode> pNode;
			hr = pDoc->createNode(CComVariant(1),CComBSTR("Control"), CComBSTR(""), &pNode);
			if (FAILED(hr)) return hr;
						
			hr = pRoot->appendChild(pNode.p, 0);
			if (FAILED(hr)) return hr;

			CComPtr<IPersistPropertyBag> spPersistPropBag;
			hr = (*it)->QueryControl(&spPersistPropBag);
			if (FAILED(hr)) return hr;
			
			hr = spPersistPropBag->InitNew();
			if (FAILED(hr)) return hr;

			CComPtr<IPersistPropertyBag> spExtendedPPB;
			if((*it)->m_pExtendedDispatchObj)
			{
				hr = (*it)->m_pExtendedDispatchObj->QueryInterface(&spExtendedPPB);
				if (FAILED(hr)) return hr;
			}
			
			CComQIPtr<IXMLDOMElement> pElem(pNode);
			if(!pElem) return E_NOINTERFACE;
			
			//Save Extended Properties
			hr = SaveToXML(pDoc, pElem.p, spExtendedPPB, TRUE, TRUE);
			if (FAILED(hr)) return hr;

			//Save Native Properties
			hr = SaveToXML(pDoc, pElem.p, spPersistPropBag, TRUE, TRUE);
			if (FAILED(hr)) return hr;
		}
	}
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------
//No error checking done !
//
HRESULT CForm::OpenXML(IXMLDOMDocument *pDoc,IXMLDOMNodeList *pNodeList)
{
	if(!pNodeList) return E_POINTER;

	long cNodes = 0;
	HRESULT hr = pNodeList->get_length(&cNodes);
	if (FAILED(hr)) return hr;
	

	if(!m_listSites.empty()) //if controls exist delete 'em
	{
		DeleteAllEmbeddings();//Close();
	}
	
	for(UINT n=1; n< cNodes + 1 ;n++)
	{
		CComPtr<IXMLDOMNode> pNode;
		hr = pNodeList->nextNode(&pNode);
		if (FAILED(hr)) return hr;

		CComQIPtr<IXMLDOMElement> pElement(pNode);
		if(!pElement) return E_NOINTERFACE;

		CComVariant varCLSID;
		pElement->getAttribute(CComBSTR(L"clsid"), &varCLSID);
		if (FAILED(hr) || varCLSID.vt != VT_BSTR) return hr;

		m_bstrCLSID = varCLSID.bstrVal;

		if(m_pData)
		{
			m_pData->GetToolWindow().LoadToolBoxBmp(varCLSID.bstrVal);
		}
		
		POINT pt = {0,0};
		CAxWindowHandle *pSiteNode = CreateAndEmbedControlOnForm(pt,true);
				
		//Extended Properties
		CComPtr<IPersistPropertyBag> spExtendedPPB;
				
		if(pSiteNode->m_pExtendedDispatchObj)
		{
			hr = pSiteNode->m_pExtendedDispatchObj->QueryInterface(&spExtendedPPB);
			if (FAILED(hr)) return hr;
			
			CComPtr<IPropertyBag> pPropBag;
			hr = GetPropertyBagFromXML(pDoc, pElement, &pPropBag);
			if (FAILED(hr)) return hr;

			hr = spExtendedPPB->Load(pPropBag, NULL);
			if (FAILED(hr)) return hr;
			
			long nWidth = 0;long nHeight = 0;RECT rc;
			pSiteNode->m_pExtendedDispatchObj->get_PositionX(&rc.left);
			pSiteNode->m_pExtendedDispatchObj->get_PositionY(&rc.top);
			pSiteNode->m_pExtendedDispatchObj->get_SizeX(&nWidth);
			pSiteNode->m_pExtendedDispatchObj->get_SizeY(&nHeight);
			pSiteNode->SetWindowPos(HWND_TOP,rc.left,rc.top,nWidth,nHeight,SWP_NOZORDER);	
						
			//Re-Resize Invis-at runtime controls
			DWORD dwStatus = 0;
			CLSID clsid;
            hr = CLSIDFromString(varCLSID.bstrVal, &clsid);
            if (FAILED(hr)) return hr;

			::OleRegGetMiscStatus(clsid, DVASPECT_CONTENT, &dwStatus);
			if(dwStatus & OLEMISC_INVISIBLEATRUNTIME)
			{
				pSiteNode->SetInvisAtRunTime(true);
				CComPtr<IOleObject> spObj;
				if(SUCCEEDED( pSiteNode->QueryControl(&spObj) ))
				{
					SIZEL sz;
					spObj->GetExtent(DVASPECT_CONTENT,&sz);    
					AtlHiMetricToPixel(&sz,&sz);
					pSiteNode->SetWindowPos(0,rc.left,rc.top,sz.cx,sz.cy,SWP_NOZORDER);
				}
			}

			//Reparent if this was within a simpleframe control
			POINT pt;
			pt.x = rc.left;
			pt.y = rc.top;
			HWND hWndSimpleFrame = GetSimpleFrameControlHWND(pt);
			if(hWndSimpleFrame && hWndSimpleFrame != m_hWnd)
			{
				pSiteNode->SetParent(hWndSimpleFrame); 
			}
		}

		//native properties
		//Load all the persisted properties
		CComPtr<IPersistPropertyBag> spPersistPropBag;
		hr = pSiteNode->QueryControl(&spPersistPropBag);

		CComPtr<IPropertyBag> pPropBag;
		hr = GetPropertyBagFromXML(pDoc, pElement, &pPropBag);
		if (FAILED(hr)) return hr;

		hr = spPersistPropBag->InitNew();
		if (FAILED(hr)) return hr;
		
		hr = spPersistPropBag->Load(pPropBag,NULL);
		if (FAILED(hr)) return hr;
		
		hr = InitScriptingForControl(pSiteNode);
		if (FAILED(hr)) return hr;
	}

	return hr;
}
#endif
//------------------------------------------------------------------------------------------------------------------
HRESULT CForm::DeleteAllEmbeddings()
{
	for(itAxWindowImpl it = m_listSites.begin(); it != m_listSites.end();it++)
	{	
		if((*it))
		{
			if((*it)->GetChildControlHwnd())
			{
				(*it)->UnsubclassControl();
			}
			if((*it)->m_hWnd)
			{
				(*it)->DestroyWindow();
				(*it)->m_hWnd = 0;
			}
			delete *it;	*it = 0;
		}
	}
	m_listSites.clear();
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------
HRESULT CForm::Close()
{
	ShutDownScriptingEngine();

	ReleaseInPlaceActiveObject();

	if(m_pData && m_pData->GetBrowserContainer())
	{
		m_pData->GetBrowserContainer()->ClearListViews();
	}
	
	DeleteAllEmbeddings();
	
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------
//This is called from CAxWindowHandle and so its not ready to be deleted yet
HRESULT CForm::DeleteFromList(HWND hWnd)
{
	for(itAxWindowImpl it = m_listSites.begin(); it != m_listSites.end();it++)
	{	
		if((*it) && (*it)->m_hWnd == hWnd)
		{
			if( (*it)->IsSimpleFrame() )//if the guy being deleted is a simpleframe then delete all its children
			{
				for(itAxWindowImpl itChild = m_listSites.begin(); itChild != m_listSites.end();itChild++)
				{	
					if((*itChild) && (*itChild)->m_hWnd == ::GetWindow(::GetWindow(hWnd,GW_CHILD),GW_CHILD) )
					{
						(*itChild)->DestroyWindow();
						(*itChild)->m_hWnd = 0;
					}
				}
			}
			(*it)->DestroyWindow();
			(*it)->m_hWnd = 0;
			m_bDeleted = true;
			return S_OK;
		}
	}
	return E_FAIL;
}
//------------------------------------------------------------------------------------------------------------------
STDMETHODIMP CForm::ParseDisplayName(IBindCtx* /*pbc*/, LPOLESTR /*pszDisplayName*/, ULONG* /*pchEaten*/, IMoniker** /*ppmkOut*/)
{
	return E_NOTIMPL;
}
//------------------------------------------------------------------------------------------------------------------
//We dont support the Form itself as a part of enumeration but you get the idea..
STDMETHODIMP CForm::EnumObjects(DWORD /*grfFlags*/, IEnumUnknown** ppenum)
{
	if (!ppenum){ return E_POINTER; }

	*ppenum = NULL;
	
	HRESULT hr = E_FAIL;

	typedef CComEnumOnSTL<IEnumUnknown, &IID_IEnumUnknown, IUnknown*,
                        _CopyIUnknownFromCAxWindowHandle, list<CAxWindowHandle*> >
          CComEnumUnknownOnList;

	CComObject<CComEnumUnknownOnList>* pe = 0;
	hr = pe->CreateInstance(&pe);
	if(FAILED(hr)) return hr;

	pe->AddRef();

	hr = pe->Init(this->GetUnknown(), m_listSites);
		
	if( SUCCEEDED(hr) ) 
	{
		hr = pe->QueryInterface(ppenum);
	}
	
	pe->Release();
	
	return hr;
}
//------------------------------------------------------------------------------------------------------------------
STDMETHODIMP CForm::LockContainer(BOOL fLock)
{
	//lock all the controls
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------
HRESULT CForm::UpdateControlEnumeration(CComBSTR bstr)
{
	ClearTheListOfDeletedSites();
	HRESULT hr = E_FAIL;
	CComQIPtr<IOleContainer> spContainer(GetUnknown());
	
	if(m_pData && spContainer)
	{
		hr = m_pData->GetBrowserContainer()->EnumerateControlsAndFillCombo(spContainer.p,&bstr);
	}

	//special hack for Form object as its not a part of control enum
	//update the control combo (although form object is not a part of control enumeration
	//but we fake this so that the UI is consistent
	CComBSTR strName;
	m_pData->GetEnvelopeForSite()->m_pExtendedDispatchObj->get_Name(&strName);
	CBrowseTabContainer* pBC = 	m_pData->GetBrowserContainer()	;
	if( (!*bstr) ||  ( CComBSTR(*bstr) != strName )  )
	  
	{
		USES_CONVERSION;		
		pBC->GetControlCombo().AddString(OLE2T(strName.m_str));
		
		if((!bstr) || (hr == S_FALSE))
			pBC->GetControlCombo().SelectString(0,OLE2T(strName.m_str));
	}
	
	m_pData->GetBrowserContainer()->UpdateWindow();
	return hr;
	
}
//------------------------------------------------------------------------------------------------------------------
//stripped down ATL's PTA, to do circular tabbing
//TODO: More intricate kbd handling with IOleControl::GetControlInfo, OnMnemonic et al,
//OLE_OPTEXCLUSIVE, OLE_TRISTATE and so on...
//
BOOL CForm::PreTranslateAccelerator(LPMSG pMsg, HRESULT& hRet)
{
	hRet = S_OK;
	if ((pMsg->message < WM_KEYFIRST || pMsg->message > WM_KEYLAST) &&
	   (pMsg->message < WM_MOUSEFIRST || pMsg->message > WM_MOUSELAST))
		return FALSE;

	// find a direct child of the dialog from the window that has focus
	HWND hWndCtl = ::GetFocus();
	if (IsChild(hWndCtl) && ::GetParent(hWndCtl) != m_hWnd)
	{
		do
		{
			hWndCtl = ::GetParent(hWndCtl);
		}
		while (::GetParent(hWndCtl) != m_hWnd);
	}
	// give controls a chance to translate this message
	if (::SendMessage(hWndCtl, WM_FORWARDMSG, 0, (LPARAM)pMsg) == 1)
		return TRUE;

	// special handling for keyboard messages
	switch(pMsg->message)
	{
	case WM_CHAR:
		if(::SendMessage(pMsg->hwnd, WM_GETDLGCODE, 0, 0L) == 0)	// no dlgcode, possibly an ActiveX control
			return FALSE;	// let the container process this
		break;
	case WM_KEYDOWN:
		switch(LOWORD(pMsg->wParam))
		{
		case VK_EXECUTE:
		case VK_RETURN:
		case VK_ESCAPE:
		case VK_CANCEL:
			// we don't want to handle these, let the container do it
			return FALSE;
		}
		break;
	}

	return IsDialogMessage(pMsg);
}
//------------------------------------------------------------------------------------------------------------------
HRESULT CForm::UpdateUserModesofHostedControls(VARIANT_BOOL bUserMode)
{
	for(itAxWindowImpl it = m_listSites.begin(); it != m_listSites.end();it++)
	{	
		if((*it))
		{
			(*it)->OnUserModeChanged(bUserMode);
		}
	}
	InvalidateRect(0);
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------
HRESULT CForm::DoBinarySave()
{
	m_nMaxControls = 0;
	HRESULT hr = E_UNEXPECTED;
	if(!m_spStream)
	{
		hr = CreateStream();
		if(FAILED(hr))  return hr; 
	}
	else
	{
		LARGE_INTEGER l = {0,0};
		m_spStream->Seek(l, STREAM_SEEK_SET, NULL);
	}

	
	//Save all the properties of all the embeddings
	for(itAxWindowImpl it = m_listSites.begin(); it != m_listSites.end();it++)
	{	
		if(*it)
		{
			CComPtr<IPersistStreamInit> spPersistStreamInit;
			hr = (*it)->QueryControl(&spPersistStreamInit);
			
			CLSID clsid ;
			spPersistStreamInit->GetClassID(&clsid);
			//write the header for each control first
			m_spStream->Write(&clsid, sizeof(CLSID), 0);

			m_nMaxControls++;

			if(SUCCEEDED(hr))
			{
				//now, save the control's native properties
				hr = spPersistStreamInit->Save(m_spStream,TRUE);

				//Extended Properties
				CComPtr<IPersistStreamInit> spExtendedPSI;
				if((*it)->m_pSiteObject && (*it)->m_pExtendedDispatchObj)
				{
					hr = (*it)->m_pExtendedDispatchObj->QueryInterface(&spExtendedPSI);
				}
				//Save Extended Properties
				if(spExtendedPSI)
				{
					hr = spExtendedPSI->Save(m_spStream,TRUE);
				}
				spPersistStreamInit.Release();
			}
		}
	}
	
	//This will Free all the embeddings
	Close();

	return hr;
}
//------------------------------------------------------------------------------------------------------------------
HRESULT CForm::DoBinaryLoad()
{
	HRESULT hr  = E_UNEXPECTED;
	if(!m_listSites.empty()) //if controls exist delete 'em
	{
		Close();
	}
	
	if(!m_spStream) return hr; 

	//seek the stream
	LARGE_INTEGER l = {0,0};
	m_spStream->Seek(l, STREAM_SEEK_SET, NULL);

	for(UINT n=0 ; n < m_nMaxControls; n++)
	{
		LPOLESTR pszCLSID = 0;
		CLSID clsid;
		hr = m_spStream->Read(&clsid, sizeof(CLSID), 0);
		::StringFromCLSID(clsid,&pszCLSID);
		m_bstrCLSID = pszCLSID;

		POINT pt = {0,0};
		CAxWindowHandle *pSiteNode = CreateAndEmbedControlOnForm(pt,true,true);

		if(pszCLSID) { CoTaskMemFree(pszCLSID);pszCLSID = 0;}
		if(!pSiteNode)
		{
			::MessageBox(GetActiveWindow(), _T("Error During Binary Load"),_T("Error"),MB_OK);
			return E_FAIL;
		}
		
		//Extended Properties
		CComPtr<IPersistStreamInit> spExtendedPSI;
				
		if(pSiteNode->m_pExtendedDispatchObj)
		{
			hr = pSiteNode->m_pExtendedDispatchObj->QueryInterface(&spExtendedPSI);

			if(SUCCEEDED(hr)) //Load EPs
			{	
				hr = spExtendedPSI->InitNew();
				hr = spExtendedPSI->Load(m_spStream);
				//ok. now get the extended properties for the window rect
				if(SUCCEEDED(hr))
				{
					long nWidth = 0;long nHeight = 0;RECT rc;
					pSiteNode->m_pExtendedDispatchObj->get_PositionX(&rc.left);
					pSiteNode->m_pExtendedDispatchObj->get_PositionY(&rc.top);
					pSiteNode->m_pExtendedDispatchObj->get_SizeX(&nWidth);
					pSiteNode->m_pExtendedDispatchObj->get_SizeY(&nHeight);
					pSiteNode->SetWindowPos(HWND_TOP,rc.left,rc.top,nWidth,nHeight,SWP_NOZORDER);	

					//Re-Resize Invis-at runtime controls
					DWORD dwStatus = 0;
					::OleRegGetMiscStatus(clsid, DVASPECT_CONTENT, &dwStatus);
					if(dwStatus & OLEMISC_INVISIBLEATRUNTIME)
					{
						pSiteNode->SetInvisAtRunTime(true);
						CComPtr<IOleObject> spObj;
						if(SUCCEEDED( pSiteNode->QueryControl(&spObj) ))
						{
							SIZEL sz;
							spObj->GetExtent(DVASPECT_CONTENT,&sz);    
							AtlHiMetricToPixel(&sz,&sz);
							pSiteNode->SetWindowPos(0,rc.left,rc.top,sz.cx,sz.cy,SWP_NOZORDER);
						}
					}
					
					//Reparent if this was within a simpleframe control
					POINT pt;
					pt.x = rc.left;
					pt.y = rc.top;
					HWND hWndSimpleFrame = GetSimpleFrameControlHWND(pt);
					if(hWndSimpleFrame && hWndSimpleFrame != m_hWnd)
					{
						pSiteNode->SetParent(hWndSimpleFrame); 
					}
				}
			}
		}
		InitScriptingForControl(pSiteNode);		
	}
		
	return hr;
}
//------------------------------------------------------------------------------------------------------------------
HRESULT CForm::FreeStream()
{
	if(m_spStream)
	{
		m_spStream.Release();
		m_spStream = 0;
	}
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------
HRESULT CForm::CreateStream()
{
	FreeStream();
	return CreateStreamOnHGlobal(0,TRUE,&m_spStream);	
}
//------------------------------------------------------------------------------------------------------------------
UINT CForm::GetControlSeqNumber(CLSID *pCLSID)
{
	if(!pCLSID){ return -1; }

	UINT nCount = 1;
	for(itAxWindowImpl it = m_listSites.begin(); it != m_listSites.end();it++)
	{	
		if(*it)
		{
			CComPtr<IPersistStreamInit> spPersistStreamInit;
			if(SUCCEEDED((*it)->QueryControl(&spPersistStreamInit)))
			{
				CLSID clsid ;
				spPersistStreamInit->GetClassID(&clsid);
				if( memcmp (&clsid,pCLSID,sizeof(CLSID) ) == 0 )
				{
					nCount++;
				}
			}
		}
	}
	return nCount;
}
//------------------------------------------------------------------------------------------------------------------
