//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#pragma once
#ifndef _COMOBJ_H_
#define _COMOBJ_H_
//--------------------------------------------------------------------------------------------------------------------
//This is for that little internal CComObject that needs init data
//The data is always non-ref counted(in case its a COM object) to avoid circular references
//
//--------------------------------------------------------------------------------------------------------------------
template <typename InitData>
struct DataHolder
{
	DataHolder():m_pData(0){}

	InitData	*m_pData;
};


//Modified version of ATL's CComObject
template <typename Base, typename InitData>
class CInternalComObjectWithData : public Base
{
public:
	CInternalComObjectWithData(InitData* p)
	{
		ATLASSERT(p != NULL);
		m_pData = p ;
		_Module.Lock();
	}

public:
	typedef Base		_BaseClass;
	typedef InitData	_InitDataClass;
	
	// Set refcount to 1 to protect destruction
	~CInternalComObjectWithData()
	{
		m_dwRef = 1L;
		FinalRelease();
#ifdef _ATL_DEBUG_INTERFACES
		_Module.DeleteNonAddRefThunk(_GetRawUnknown());
#endif
		_Module.Unlock();
	}
	//If InternalAddRef or InternalRelease is undefined then your class
	//doesn't derive from CInternalComObjectWithDataRoot
	STDMETHOD_(ULONG, AddRef)() {return InternalAddRef();}
	STDMETHOD_(ULONG, Release)()
	{
		ULONG l = InternalRelease();
		if (l == 0)
			delete this;
		return l;
	}
	//if _InternalQueryInterface is undefined then you forgot BEGIN_COM_MAP
	STDMETHOD(QueryInterface)(REFIID iid, void ** ppvObject)
	{return _InternalQueryInterface(iid, ppvObject);}
	
	template <class Q>
	HRESULT STDMETHODCALLTYPE QueryInterface(Q** pp)
	{
		return QueryInterface(__uuidof(Q), (void**)pp);
	}

	static HRESULT WINAPI CreateInstanceWithData(CInternalComObjectWithData<Base,InitData>** pp, InitData *pData)
	{
		if(!pp || !pData){ return E_POINTER; }

		HRESULT hRes = E_OUTOFMEMORY;
		CInternalComObjectWithData<Base,InitData>* p = NULL;
		p = new CInternalComObjectWithData<Base,InitData>(pData);
		if (p != NULL)
		{
			p->SetVoid(NULL);
			p->InternalFinalConstructAddRef();
			hRes = p->FinalConstruct();
			p->InternalFinalConstructRelease();
			if (hRes != S_OK)
			{
				delete p;
				p = NULL;
			}
		}
		*pp = p;
		return hRes;
	}
};

//--------------------------------------------------------------------------------------------------------------------

#endif