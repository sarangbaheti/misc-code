//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

// GeneralPage.h : Declaration of the CGeneralPage

#ifndef __GENERALPAGE_H_
#define __GENERALPAGE_H_

#include "resource.h"       // main symbols

EXTERN_C const CLSID CLSID_GeneralPage;

/////////////////////////////////////////////////////////////////////////////
// CGeneralPage
class ATL_NO_VTABLE CGeneralPage :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CGeneralPage, &CLSID_GeneralPage>,
	public IPropertyPageImpl<CGeneralPage>,
	public CDialogImpl<CGeneralPage>
{
public:
	CGeneralPage() 
	{
		m_dwTitleID = IDS_TITLEGeneralPage;
		m_dwHelpFileID = IDS_HELPFILEGeneralPage;
		m_dwDocStringID = IDS_DOCSTRINGGeneralPage;
	}

	enum {IDD = IDD_GENERALPAGE};

DECLARE_REGISTRY_RESOURCEID(IDR_GENERALPAGE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CGeneralPage) 
	COM_INTERFACE_ENTRY(IPropertyPage)
END_COM_MAP()

BEGIN_MSG_MAP(CGeneralPage)
	MESSAGE_HANDLER(WM_INITDIALOG,OnInitDialog)
	MESSAGE_HANDLER(WM_DESTROY,OnDestroy)
	COMMAND_CODE_HANDLER(EN_CHANGE,OnEditChange)
	CHAIN_MSG_MAP(IPropertyPageImpl<CGeneralPage>)
END_MSG_MAP()
// Handler prototypes:
	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnEditChange(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	HRESULT GetExtendedDispatch(IUnknown* pUnk, IExtendedDispatch **ppExtDisp);
	HRESULT GetInPlaceSite(IUnknown* pUnk, IOleInPlaceSite **ppInPlaceSite);

	STDMETHOD(Apply)(void);
	LRESULT InitWnd();

private:
	CWindow m_WndName;
	CWindow m_WndPosX;
	CWindow m_WndPosY;
	CWindow m_WndSizeX;
	CWindow m_WndSizeY;

};

#endif //__GENERALPAGE_H_
