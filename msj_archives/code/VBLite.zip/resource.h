//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VBLite.rc
//
#define IDS_PROJNAME                    100
#define IDR_DCon                        100
#define IDB_FORM                        101
#define IDR_FORM                        102
#define IDD_FORM                        103
#define IDS_TITLEGeneralPage            104
#define IDS_HELPFILEGeneralPage         105
#define IDS_DOCSTRINGGeneralPage        106
#define IDR_GENERALPAGE                 107
#define IDD_GENERALPAGE                 108
#define IDR_EXTENDEDDISPATCH            109
#define IDD_EVENTDIALOG                 110
#define IDD_SCRIPTER                    111
#define IDD_ABOUTBOX                    112
#define IDR_MAINFRAME                   128
#define IDR_CONTRTYPE                   129
#define IDR_MENU_FILE                   201
#define BMP_ARROW                       202
#define IDC_EVENTNAMES_LIST             202
#define IDB_MENUBAR                     203
#define IDR_MENU1                       204
#define IDR_TOOLMENU                    204
#define IDC_EDIT_NAME                   204
#define IDC_EDIT_SIZEY                  205
#define IDC_EDIT_SCRIPT                 205
#define IDC_EDIT_SIZEX                  206
#define IDC_BUTTON_EXECUTE              206
#define IDC_EDIT_POSX                   207
#define IDC_EDIT_POSY                   208
#define IDC_CHRIS_PAGE                  209
#define IDB_EVENT                       210
#define IDC_MY_PAGE                     210
#define IDB_GRID                        212
#define IDI_FORM                        213
#define ID_MENU_FILE                    32768
#define ID_FILE_OPEN                    32769
#define ID_FILE_EXIT                    32770
#define ID_CONTROLDIALOG                32771
#define ID_HELLO_HELLOWORLD             32772
#define ID_OPTIONS_FREEZEEVENTS         32776
#define ID_OPTIONS_DESIGNMODE           32779
#define ID_HELLO_HELLOCOM               32786
#define ID_HELLO_HELLOATL               32787
#define ID_BUTTON32790                  32790
#define ID_VIEW_EVENTS_DLG              32791
#define ID_COM_CONTROLDIALOG            32792
#define IDS_FILE_OPEN                   32792
#define IDS_FILE_SAVE                   32793
#define IDS_OLE_INSERT_NEW              32794
#define IDS_EDIT_DELETE                 32795
#define IDS_VIEW_SCRIPTER               32796
#define VIEW_CONTROL_EVENTS             32797
#define IDS_RUN                         32798
#define IDS_STOP                        32799
#define IDS_APP_ABOUT                   32800
#define ID_CONTROL_INVOKEMETHODS        32815
#define ID_CONTAINER_AMBIENTPROPERTIES  32817
#define ID_EDIT_PROPERTIES              32848
#define ID_TOOLS_MACROS                 32853
#define ID_FILE_NEW                     0xE100
#define ID_FILE_CLOSE                   0xE102
#define ID_FILE_SAVE                    0xE103
#define ID_FILE_SAVE_AS                 0xE104
#define ID_FILE_PRINT_SETUP             0xE106
#define ID_FILE_PRINT                   0xE107
#define ID_FILE_PRINT_PREVIEW           0xE109
#define ID_FILE_MRU_FILE1               0xE110
#define ID_EDIT_CLEAR                   0xE120
#define ID_EDIT_DELETE                  0xE120
#define ID_EDIT_COPY                    0xE122
#define ID_EDIT_CUT                     0xE123
#define ID_EDIT_PASTE                   0xE125
#define ID_EDIT_PASTE_SPECIAL           0xE127
#define ID_EDIT_UNDO                    0xE12B
#define ID_WINDOW_NEW                   0xE130
#define ID_WINDOW_ARRANGE               0xE131
#define ID_WINDOW_CASCADE               0xE132
#define ID_WINDOW_TILE_HORZ             0xE133
#define ID_APP_ABOUT                    0xE140
#define ID_OLE_INSERT_NEW               0xE200
#define ID_OLE_EDIT_LINKS               0xE201
#define ID_OLE_VERB_FIRST               0xE210
#define ID_VIEW_TOOLBAR                 0xE800
#define ID_VIEW_SCRIPTER                0xE800
#define ID_VIEW_STATUS_BAR              0xE801
#define ID_VIEW_CONTROL_EVENTS          0xE801

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        216
#define _APS_NEXT_COMMAND_VALUE         32793
#define _APS_NEXT_CONTROL_VALUE         211
#define _APS_NEXT_SYMED_VALUE           113
#endif
#endif
