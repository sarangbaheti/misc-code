//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "stdafx.H"
#include "AxWindowHandle.H"
#include "browsetab.h"
#include "Base_Include\context.H"
#include "oledlg.H"
#include "ContainerFrame.H"
#include "ExtendedDispatch.H"

//------------------------------------------------------------------------------------------------------------------	
HRESULT	CAxWindowHandle::InitializeSite()
{
	HRESULT hr = E_FAIL;
	CContainerFrame *pFrame = GetContainerFrame();
	if(!pFrame) return hr;
	
	//Set the Frame
	m_pSiteObject->m_pContainerFrame = pFrame;
	
	//Fill the Proppage CAUUID
	m_pSiteObject->m_ContainerPages.cElems = 1;
	m_pSiteObject->m_ContainerPages.pElems = (GUID *)::CoTaskMemAlloc(m_pSiteObject->m_ContainerPages.cElems * sizeof(CLSID));
	m_pSiteObject->m_ContainerPages.pElems[0] = CLSID_GeneralPage;
			
	//Set the nested member IPs with the right objects of the container object model
	if(pFrame && pFrame->m_pFormObj)
	{
		 hr = pFrame->m_pFormObj->QueryInterface(&m_pSiteObject->m_spOleContainer);
		 if(FAILED(hr)) return hr;

		 hr = pFrame->m_pFormObj->QueryInterface(&m_pSiteObject->m_spInPlaceFrame);
		 if(FAILED(hr)) return hr;

		 hr = pFrame->m_pFormObj->QueryInterface(&m_pSiteObject->m_spInPlaceUIWindow);
		 if(FAILED(hr)) return hr;

		 hr = m_pExtendedDispatchObj->QueryInterface(&m_pSiteObject->m_spExtendedDispatch);
		 if(FAILED(hr)) return hr;
	}
	return hr;
}
//------------------------------------------------------------------------------------------------------------------	
LRESULT CAxWindowHandle::OnCreate(UINT,WPARAM,LPARAM,BOOL& bHandled)
{
	HRESULT hr = m_pExtendedDispatchObj->CreateInstanceWithData(&m_pExtendedDispatchObj,this);
			
	if(SUCCEEDED(hr))
	{
		m_pExtendedDispatchObj->AddRef();
	}

	bHandled = FALSE;
	return 0L;
}
//------------------------------------------------------------------------------------------------------------------	
BOOL CAxWindowHandle::SubclassControl()
{
	if(m_bSubClassed) return TRUE;
	HWND hWndChildControl = ::GetWindow(m_hWnd,GW_CHILD);
	
	if(::IsWindow(hWndChildControl) )//windowed control
	{
		m_bSubClassed = true;
		return m_wndControl.SubclassWindow(hWndChildControl);
	}
	return FALSE;
}

//------------------------------------------------------------------------------------------------------------------	
BOOL CAxWindowHandle::ShowEventDialog()
{
	if(m_pFrame)//pop up event dialog
	{
		m_pFrame->GetEventDialog().SetEventMap( m_pEventMap ) ;
		m_pFrame->GetEventDialog().DoModal();
		return TRUE;
	}
	return FALSE;
}
//------------------------------------------------------------------------------------------------------------------	
LRESULT CAxWindowHandle::OnCommand(UINT , WPARAM wParam, LPARAM , BOOL& bHandled)
{
	if(m_pFrame && IDR_TOOLMENU+1 == LOWORD(wParam))//Delete the control
	{
		m_pFrame->m_pFormObj->ReleaseInPlaceActiveObject();

		if(m_wndControl.m_hWnd) { UnsubclassControl(); } // get rid of the child control
		
		m_pFrame->m_pFormObj->DeleteFromList(m_hWnd);//will call DestroyWindow() for me
		m_hWnd = NULL;
		//Here's a catch 22.
	}
	if(IDR_TOOLMENU+2 == LOWORD(wParam))//pop up event dialog
	{
		ShowEventDialog();
	}
	return 0L;
}
//------------------------------------------------------------------------------------------------------------------	
HRESULT CAxWindowHandle::AxCreateControl2(LPCOLESTR lpszName, HWND hWnd, IStream* pStream, IUnknown** ppUnkContainer, IUnknown** ppUnkControl, REFIID iidSink, IUnknown* punkSink)
{
	AtlAxWinInit();
	HRESULT hr;
	CComPtr<IUnknown> spUnkContainer;
	CComPtr<IUnknown> spUnkControl;

	hr = m_pSiteObject->CreateInstance(&m_pSiteObject);
	m_pSiteObject->AddRef();
	
	hr = m_pSiteObject->QueryInterface(IID_IUnknown, (void**)&spUnkContainer);
	if(FAILED(hr)) return hr;

	CComPtr<IAxWinHostWindow> pAxWindow;
	spUnkContainer->QueryInterface(&pAxWindow);
	CComBSTR bstrName(lpszName);
	InitializeSite();
	m_pSiteObject->m_bReleaseAll = 1;
	hr = pAxWindow->CreateControlEx(bstrName, hWnd, pStream, &spUnkControl, iidSink, punkSink);
	
	SubclassControl();
		
	InitializeEventMap(spUnkControl.p);
	m_pSiteObject->m_bReleaseAll = 0;
	//Setting the extended properties now !
	CComPtr<IPersistStreamInit> spPersist;
	hr = QueryControl(&spPersist);
	
	if(SUCCEEDED(hr) && m_pExtendedDispatchObj) 
	{
		CLSID clsid;
		spPersist->GetClassID(&clsid);
		
		LPOLESTR pszCLSID = 0;
		::StringFromCLSID(clsid,&pszCLSID);
		m_pExtendedDispatchObj->SetCLSIDOfControl(CComBSTR(pszCLSID));
		
		CoTaskMemFree(pszCLSID);pszCLSID = 0;
	}
	hr = S_OK;
	

	if (ppUnkContainer != NULL)
	{
		if (SUCCEEDED(hr))
		{
			*ppUnkContainer = spUnkContainer.p;
			spUnkContainer.p = NULL;
		}
		else
			*ppUnkContainer = NULL;
	}
	if (ppUnkControl != NULL)
	{
		if (SUCCEEDED(hr))
		{
			*ppUnkControl = SUCCEEDED(hr) ? spUnkControl.p : NULL;
			spUnkControl.p = NULL;
		}
		else
			*ppUnkControl = NULL;
	}
	return hr;
}
//------------------------------------------------------------------------------------------------------------------	
LRESULT CAxWindowHandle::OnSize(UINT , WPARAM , LPARAM , BOOL& bHandled)
{
	if(m_pFrame && m_pSiteObject && m_pExtendedDispatchObj)
	{
		CBrowseTabContainer *pBC = m_pFrame->GetBrowserContainer();
		
		if(pBC && pBC->GetBrowseTab().GetExtendedBrowser().IsDirty() )
		{
			pBC->GetBrowseTab().GetExtendedBrowser().SetDirty(false);
			bHandled = FALSE;
			return 0L;
		}

		RECT rc;
		GetWindowRect(&rc);
		::MapWindowPoints(HWND_DESKTOP,GetParent(),(LPPOINT)&rc,2);
		
		m_pExtendedDispatchObj->SetDirty(VARIANT_FALSE);
		
		m_pExtendedDispatchObj->put_PositionX(rc.left);
		m_pExtendedDispatchObj->put_PositionY(rc.top);
		m_pExtendedDispatchObj->put_SizeX(rc.right - rc.left);
		m_pExtendedDispatchObj->put_SizeY(rc.bottom - rc.top);
		
		m_pExtendedDispatchObj->SetDirty(VARIANT_TRUE);
		

		//do browser update
		UpdateBrowsers(true);//bOnlyExtended == true		
	}
	return 0L;
}
//------------------------------------------------------------------------------------------------------------------		
HRESULT CAxWindowHandle::UpdateBrowsers(bool bOnlyExtended)
{
	if(m_pFrame)
	{
		CBrowseTabContainer* pBC = 	m_pFrame->GetBrowserContainer()	;
		
		if(!pBC) { return E_FAIL; }

		int nCurSel = pBC->GetBrowseTab().GetCurSel();
		if(nCurSel != 2 && bOnlyExtended){ return S_FALSE;	}
		
		//clear everything first
		pBC->ClearListViews();

		//native properties
		CComPtr<IDispatch> spDisp;
		QueryControl(&spDisp);
		pBC->GetBrowseTab().GetNativeBrowser().put_Dispatch(spDisp);

		//ambient dispatch
		CComPtr<IUnknown> spUnk;
		QueryHost(&spUnk);
		CComQIPtr<IDispatch> spDispAmbient(spUnk);
		pBC->GetBrowseTab().GetAmbientBrowser().put_Dispatch(spDispAmbient);
		
		//extended properties
		CComPtr<IDispatch> spExtDisp;
		m_pExtendedDispatchObj->QueryInterface(&spExtDisp);
		pBC->GetBrowseTab().GetExtendedBrowser().put_Dispatch(spExtDisp);

		//update the control combo 
		CComBSTR strName;
		m_pExtendedDispatchObj->get_Name(&strName);

		USES_CONVERSION;		
		pBC->GetControlCombo().SelectString(0,OLE2T(strName.m_str));
		
		pBC->Invalidate();
		pBC->UpdateWindow();

		bool b = false;
		AmIASiteForTheForm(b);
		m_pFrame->GetBrowserContainer()->EnableAmbientTab(b);
	}
	return S_OK;

}
//------------------------------------------------------------------------------------------------------------------		

LRESULT CAxWindowHandle::OnLButtonDown(UINT , WPARAM , LPARAM , BOOL& bHandled)
{
	UpdateBrowsers();
	bHandled = FALSE;
	return 0L;
}
//------------------------------------------------------------------------------------------------------------------	
LRESULT CAxWindowHandle::OnContextMenu(UINT , WPARAM , LPARAM lParam, BOOL& )
{
	if(m_pSiteObject->m_bUserMode)//RunTime
	{
		return 0L;
	}

	CComPtr<IOleObject> spObj;
	QueryControl(&spObj);
			
	CContextMenu cm,cmVerb;
	cm.Load(_Module.GetModuleInstance(),IDR_TOOLMENU);	
	
	HMENU hMenu = NULL;
	if(spObj)
	{
		BOOL b = ::OleUIAddVerbMenu(spObj.p,
									NULL,
									cm.GetMenu(),
									0,
									ID_MIN_VERB,
									ID_MAX_VERB,           
									TRUE,
									ID_CONVERT,
									&hMenu);
		
		
		if(b && hMenu)
		{
			cmVerb = hMenu;
			cmVerb.Delete(ID_CONVERT);
			cmVerb.Delete(cmVerb.ItemCount()-1,MF_BYPOSITION);
			
			cmVerb.Insert(cmVerb.ItemCount(),IDR_TOOLMENU+1,_T("Delete Control"));
			cmVerb.Insert(cmVerb.ItemCount(),IDR_TOOLMENU+2,_T("View Events"));
			POINT pt;
			pt.x = LOWORD(lParam);
			pt.y = HIWORD(lParam);
			
			if(m_pSiteObject->m_bUserMode)//RunTime
			{
				::ClientToScreen(m_hWnd,&pt);
			}

			SetFocus();//this will keep the focus
			b = cmVerb.Track(pt.x+80,pt.y,m_hWnd);
			
			cmVerb.Destroy();
		}
	}	
	cm.Destroy();
	return 0L;
}
//--------------------------------------------------------------------------------------------------------------------------	
LRESULT CAxWindowHandle::OnVerb(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	CComPtr<IOleObject>		spObj;
	CComPtr<IOleClientSite> spClientSite;

	QueryControl(&spObj);
	QueryHost(&spClientSite);

	MSG msg;
	RECT rc;
	::GetClientRect(m_hWnd,&rc);
	HRESULT hr = E_FAIL;
	if(spObj.p && spClientSite.p)
	{
		hr = spObj->DoVerb(wID - ID_MIN_VERB,&msg,spClientSite,0,m_hWnd,&rc);
	}
	
	return 0L;
}
//--------------------------------------------------------------------------------------------------------------------------	
		
LRESULT CAxWindowHandle::OnSetFocus(UINT,WPARAM,LPARAM, BOOL& bHandled)
{
	if(m_pFrame && m_pFrame->m_pFormObj)
	{
		CComPtr<IOleInPlaceActiveObject> spInPlaceActive;
		HRESULT hr = QueryControl(&spInPlaceActive);
		m_pFrame->m_pFormObj->SetActiveObject(spInPlaceActive,0);
	}
	UpdateBrowsers();
	bHandled = FALSE;
	return 0L;
}
//--------------------------------------------------------------------------------------------------------------------------	
LRESULT CAxWindowHandle::OnLButtonDBlClk(UINT , WPARAM , LPARAM , BOOL& bHandled)
{
	if(m_pSiteObject->m_bUserMode)//RunTime
	{
		bHandled = FALSE; 
		return 0L;
	}
	UpdateBrowsers();
	return 0L;
}
//--------------------------------------------------------------------------------------------------------------------------	
LRESULT CAxWindowHandle::OnNCHitTest(UINT , WPARAM , LPARAM lParam, BOOL& bHandled)
{
	if(m_pSiteObject->m_bUserMode)//RunTime
	{
		bool b = false;
		if(SUCCEEDED( AmIASiteForTheForm(b) ) && b)
		{
			bHandled = FALSE;
			return 0L;
		}
		else
		{
			bHandled = TRUE;
			return HTCLIENT;
		}
	}

	RECT rc;GetWindowRect(&rc);rc.left += 5;rc.top  += 5;rc.right -= 5;rc.bottom -= 5;

	POINT pt;pt.x = LOWORD(lParam);  pt.y = HIWORD(lParam);  
	
	if( ::PtInRect(&rc,pt) )
	{
		bHandled = TRUE;
		return HTCAPTION;
	}
	
	if( IsInvisAtRunTime() )
	{
		return HTCLIENT;
	}
	
	bHandled = FALSE;
	return 0L;
}
//--------------------------------------------------------------------------------------------------------------------------	

LRESULT CAxWindowHandle::OnNCDestroy(UINT , WPARAM , LPARAM , BOOL& bHandled)
{
	if(m_wndControl.m_hWnd) { UnsubclassControl(); }
	if(m_pEventMap)
	{
		m_pEventMap->UnAdvise();
		m_pEventMap->Release();
		m_pEventMap = 0;
	}

	if(m_pExtendedDispatchObj)
	{
		m_pExtendedDispatchObj->Release();
		m_pExtendedDispatchObj = 0;
	}

	if(m_pSiteObject && m_pSiteObject->m_ContainerPages.pElems)
	{
		CoTaskMemFree(m_pSiteObject->m_ContainerPages.pElems);
		m_pSiteObject->m_ContainerPages.pElems = 0;
	}

	if(m_pSiteObject) 
	{ 
		m_pSiteObject->Release(); m_pSiteObject = 0; 
	}

	IAxWinHostWindow* pAxWindow = (IAxWinHostWindow*)::GetWindowLong(m_hWnd, GWL_USERDATA);
	if(pAxWindow != NULL)
		pAxWindow->Release();
	OleUninitialize();
	m_hWnd = 0;
	bHandled = TRUE;
	return 0L;
}
//--------------------------------------------------------------------------------------------------------------------------	
LRESULT CAxWindowHandle::OnNCHitTestCtl(UINT , WPARAM , LPARAM , BOOL& bHandled)
{
	if(m_pSiteObject->m_bUserMode)//RunTime
	{
		bHandled = FALSE;
		return 0L;
	}
	bHandled = TRUE;
	return HTTRANSPARENT;
}
//--------------------------------------------------------------------------------------------------------------------------	
LRESULT CAxWindowHandle::OnKeyDown(UINT , WPARAM wParam, LPARAM , BOOL& bHandled)
{
	if( ( wParam == VK_DELETE)  && (!m_pSiteObject->m_bUserMode) )
	{
		m_pFrame->m_pFormObj->ReleaseInPlaceActiveObject();

		if(m_wndControl.m_hWnd) { UnsubclassControl(); } // get rid of the child control
		
		m_pFrame->m_pFormObj->DeleteFromList(m_hWnd);//will call DestroyWindow() for me
		m_hWnd = NULL;
		bHandled = TRUE;
		return 0L;
	}
	bHandled = FALSE;
	return 0L;
}
//--------------------------------------------------------------------------------------------------------------------------	
HRESULT CAxWindowHandle::AmIASiteForTheForm(bool &b)
{
	b = false;
	if( !GetContainerFrame() || (!GetContainerFrame()->m_pFormObj) )
	{
		return E_POINTER;
	}

	CComPtr<IUnknown> spUnkControl;
	HRESULT hr = QueryControl(&spUnkControl);
	
	LPUNKNOWN pUnkForm = GetContainerFrame()->m_pFormObj->GetUnknown();
	
	if( SUCCEEDED(hr) && ( pUnkForm == spUnkControl) )
		b = true;

	return hr;
}
//---------------------------------------------------------------------------------------------------------------------
HRESULT CAxWindowHandle::OnUserModeChanged(VARIANT_BOOL bUserMode)
{
	bool b = false;
	if( SUCCEEDED(AmIASiteForTheForm(b)) && b )
	{
		m_pSiteObject->m_bUserMode = bUserMode;
		if(GetContainerFrame() && GetContainerFrame()->m_pFormObj )
		{
			//update the user modes of all the controls here
			GetContainerFrame()->m_pFormObj->UpdateUserModesofHostedControls(bUserMode);
			if(!bUserMode)
				GetContainerFrame()->m_pFormObj->SetStatusText(L"Ready!");

			if(bUserMode)
			{
				GetContainerFrame()->SwitchToUserMode();//We should not call the other routine here as that would be a little disastrous :-)
			}
		}
	}
	else
	{
		m_pSiteObject->m_bUserMode = GetContainerUserMode();
		CComPtr<IOleControl> spControl;
		QueryControl(&spControl);
		if(m_pSiteObject->m_bUserMode)//RunMode
		{
			spControl->FreezeEvents(FALSE);
		}
		else
		{
			spControl->FreezeEvents(TRUE);
		}
	}

	m_pSiteObject->FireAmbientPropertyChange(DISPID_AMBIENT_USERMODE);
	
	if( IsInvisAtRunTime() )
	{
		if(!m_pSiteObject->m_bUserMode)
			ShowWindow(SW_SHOW);
		else
			ShowWindow(SW_HIDE);
	}
	
	UpdateBrowsers();

	return S_OK;
}
//---------------------------------------------------------------------------------------------------------------------
HRESULT CAxWindowHandle::GetSiteForTheForm(LPUNKNOWN *ppUnkFormSite)
{
	*ppUnkFormSite = 0;
	if( (!ppUnkFormSite) || !GetContainerFrame() )
	{
		return E_POINTER;
	}
	
	return GetContainerFrame()->GetEnvelopeForSite()->QueryHost(ppUnkFormSite);
}
//--------------------------------------------------------------------------------------------------------------------
VARIANT_BOOL CAxWindowHandle::GetContainerUserMode(void)
{
	VARIANT_BOOL b = VARIANT_FALSE;
	CComPtr<IUnknown> spUnk;
	if( SUCCEEDED( GetSiteForTheForm(&spUnk) ) && spUnk )
	{
		CComPtr<IAxWinAmbientDispatch> spAmbDispatch;
		if( SUCCEEDED( spUnk->QueryInterface(&spAmbDispatch) ) && spAmbDispatch)
		{
			spAmbDispatch->get_UserMode(&b);
		}
	}

	return b;
}
//--------------------------------------------------------------------------------------------------------------------
