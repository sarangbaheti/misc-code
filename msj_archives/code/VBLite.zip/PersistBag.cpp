//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "stdafx.H"
#include "PersistBag.H"

//-------------------------------------------------------------------------------------------------------------
HRESULT CPropertyBag::ReadProperty(LPCOLESTR pszPropName,VARIANT* pVar,IErrorLog* pErrorLog)
{
	if(!pVar || !pszPropName)    { return E_POINTER; }

	TCHAR pszT[1024];USES_CONVERSION;lstrcpy(pszT,OLE2T(pszPropName));
	
	VARTYPE vt = VT_EMPTY;
	vt = pVar->vt;
	::VariantClear(pVar);
	
	if(m_bIsCurrentObjControl)
	{
		itPropertyBag it = &m_Reader.m_VecBag[m_nLastControl];

		for(itNameValue itSub = it->m_map_Name_Val.begin();
		itSub != it->m_map_Name_Val.end();
		itSub++)
		{
			if((itSub) && (itSub->strName == pszT) )
			{
				if(SUCCEEDED(itSub->varValue.ChangeType(vt)) && pVar)
				{
					::VariantCopy(pVar,	&(itSub->varValue));
					return S_OK;
				}
				return E_UNEXPECTED;					
			}
		}
	}
	else
	{
		for(int i = 0; i < m_Reader.m_VecBag[m_nLastControl].m_SubObject.size(); i++)
		{
			itSubPropertyBag it = &m_Reader.m_VecBag[m_nLastControl].m_SubObject[i];

			for(itNameValue itSub = it->m_map_Name_Val.begin();
			itSub != it->m_map_Name_Val.end();
			itSub++)
			{
				if((itSub) &&  (itSub->strName == pszT) )
				{
					if(SUCCEEDED(itSub->varValue.ChangeType(vt)) && pVar)
					{
						::VariantCopy(pVar,&(itSub->varValue));
						return S_OK;
					}
					return E_UNEXPECTED;					
				}
			}
		}
	}
	return E_UNEXPECTED;
}
//-------------------------------------------------------------------------------------------------------------
HRESULT CPropertyBag::ReadObject(LPCOLESTR pszPropName,VARIANT* pVar,IErrorLog* pErrorLog)
{
	if(!pVar || !pszPropName)    { return E_POINTER; }
	if(  (pVar->vt != VT_UNKNOWN) && (pVar->vt == VT_DISPATCH) ){ return E_INVALIDARG;}

	IUnknown* pUnk = (pVar->vt == VT_UNKNOWN) ? pVar->punkVal : pVar->pdispVal;
	if(!pUnk) { return E_POINTER; }

	HRESULT hr = E_UNEXPECTED;

	CComPtr<IPersistPropertyBag> spBag;
	if(SUCCEEDED(pUnk->QueryInterface(&spBag)))
	{
		hr = spBag->InitNew();
		hr = spBag->Load(static_cast<IPropertyBag*>(this),NULL);
							
		spBag.Release();
		return hr;
	}
	else //IPPB2 or IPSI
	{
		::MessageBox(GetActiveWindow(),_T("Object does not support IPersistPropertyBag ???"),_T("Error!!"),MB_OK);
		return hr;
	}
	
	return hr;
}
//------------------------------------------------------------------------------------------------------------------------------------
STDMETHODIMP CPropertyBag::Read(LPCOLESTR pszPropName,VARIANT* pVar,IErrorLog* pErrorLog)
{
	if(m_Reader.m_VecBag.empty()) { return E_FAIL; }
	if(!pVar || !pszPropName)    { return E_POINTER; }
		
	TCHAR pszT[1024];
	USES_CONVERSION;
	lstrcpy(pszT,OLE2T(pszPropName));
	HRESULT hr = E_UNEXPECTED;

	if(m_bFirstInit)
	{
		m_nLastControl = 0;
		m_bFirstInit = false;
	}

	if(pVar->vt == VT_DISPATCH || pVar->vt == VT_UNKNOWN)
	{
		m_bIsCurrentObjControl = false;
		hr = ReadObject(pszPropName,pVar,pErrorLog);
		m_bIsCurrentObjControl = true;
	}
	else
	{
		hr = ReadProperty(pszPropName,pVar,pErrorLog);
	}
	return hr;
}
//-------------------------------------------------------------------------------------------------------------------------------
STDMETHODIMP CPropertyBag::Write(LPCOLESTR pszPropName,VARIANT* pVar)
{
	if(!m_Writer.GetFileHandle()) { return E_FAIL; }
	if(!pVar)    { return E_POINTER; }
	
	TCHAR psz[1024];
	bool bSkipWrite = false;

	//Do a variant changetype of pVar to BSTR
	CComVariant var;
	HRESULT hr = var.ChangeType(VT_BSTR,pVar);
	
	USES_CONVERSION;
	if(SUCCEEDED(hr))
	{
		CComBSTR bstrVal(var.bstrVal);
		wsprintf(psz,_T("\t %s %s %s \n"),OLE2T(pszPropName),_T(" ="),OLE2T(bstrVal.m_str));
	}
	else if( (pVar->vt == VT_UNKNOWN) || (pVar->vt == VT_DISPATCH) )
	{
		IUnknown* pUnk = (pVar->vt == VT_UNKNOWN) ? pVar->punkVal : pVar->pdispVal;
		if(!pUnk) { return E_POINTER; }

		//recursive cases follow
		CComPtr<IPersistPropertyBag> spBag;
		if(SUCCEEDED(pUnk->QueryInterface(&spBag)))
		{
			CLSID clsid = CLSID_NULL;
			hr = spBag->GetClassID(&clsid);
			
			m_Writer.WriteControlHeader(clsid,pszPropName,true); //header for the subobject

			spBag->Save(static_cast<IPropertyBag*>(this),TRUE,TRUE);
			
			m_Writer.WriteControlFooter(true); //footer for the subobject
			bSkipWrite = true;
		}
		else //IPPB2 or IPSI
		{
			::MessageBox(GetActiveWindow(),_T("Object does not support IPersistPropertyBag ???"),_T("Error!!"),MB_OK);
		}
	}

	if(bSkipWrite) { return S_OK; }

	//finally, write the thing !
	return m_Writer.WriteFile(psz);
}

//-------------------------------------------------------------------------------------------------------------------------------------
