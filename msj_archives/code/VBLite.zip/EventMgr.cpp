//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "stdafx.H"
#include "EventMgr.H"

//--------------------------------------------------------------------------------------------------------------

HRESULT CEventMap::GetEventTypeInfo(LPTYPEINFO *ppTypeInfo)
{
	if(!m_spObjUnk || !ppTypeInfo){ return E_POINTER; }

	//This gets the LIBID, IIDSrc,and version
	HRESULT hr = AtlGetObjectSourceInterface(m_spObjUnk.p,&m_libID, &m_iidSrc, &m_dwMajor, &m_dwMinor);
	if(FAILED(hr)) return hr;
	
	CComPtr<IDispatch> spDispatch;
	hr = m_spObjUnk->QueryInterface(&spDispatch);
	if(FAILED(hr)) return hr;

	
	CComPtr<ITypeInfo> spTypeInfo;
	hr = spDispatch->GetTypeInfo(0, 0, &spTypeInfo);
	if(FAILED(hr)) return hr;
	
	CComPtr<ITypeLib> spTypeLib;
	hr = spTypeInfo->GetContainingTypeLib(&spTypeLib, 0);
	if(FAILED(hr)) return hr;

	return spTypeLib->GetTypeInfoOfGuid(m_iidSrc, ppTypeInfo);
}

//--------------------------------------------------------------------------------------------------------------

HRESULT CEventMap::Init()
{
	if(!m_spObjUnk){ return E_POINTER; }
	if(m_spTypeInfo){ return S_FALSE; }

	HRESULT hr = GetEventTypeInfo(&m_spTypeInfo);
	if(FAILED(hr)) return hr; 
	
	LPTYPEATTR	 pTA = 0;
	hr = m_spTypeInfo->GetTypeAttr(&pTA);
	if(FAILED(hr)){ m_spTypeInfo.Release(); return hr; }
	
	//Set the no of event functions
	m_nEvents = pTA->cFuncs;
	m_spTypeInfo->ReleaseTypeAttr(pTA);

	m_pEventInfo = new EventInfo[m_nEvents];
	if(!m_pEventInfo) { m_nEvents = 0; m_spTypeInfo.Release(); return E_OUTOFMEMORY; }

	for(UINT n = 0; n < m_nEvents; n++)
	{
		LPFUNCDESC pFD = 0;
		m_pEventInfo[n].m_dispID = 0;
				
		hr = m_spTypeInfo->GetFuncDesc(n,&pFD);
		if(FAILED(hr)) continue;
		
		m_pEventInfo[n].m_dispID = pFD->memid;
		UINT cNames = 0;
		m_spTypeInfo->GetNames(pFD->memid,&m_pEventInfo[n].m_strEventName,1,&cNames);
		m_spTypeInfo->ReleaseFuncDesc(pFD);
	}

	return hr;	
}
//--------------------------------------------------------------------------------------------------------------
//Will set the text of the statusbar of the Framewnd with the event name
STDMETHODIMP CEventMap::Invoke(DISPID dispidMember, REFIID riid,LCID lcid, WORD wFlags, DISPPARAMS* pdispparams, VARIANT* pvarResult,EXCEPINFO* pexcepinfo, UINT* puArgErr)
{
	if (riid != IID_NULL){ return DISP_E_UNKNOWNINTERFACE;}
	if(!pdispparams) { return E_POINTER; }
	
	for(UINT n=0; n < m_nEvents; n++)
	{
		if(dispidMember == m_pEventInfo[n].m_dispID)
		{
			//get the IOleContainer
			CComPtr<IOleObject> spObj;
			HRESULT hr = m_spObjUnk->QueryInterface(&spObj);
			if(FAILED(hr)) return hr;
			
			CComPtr<IOleClientSite> spClientSite;
			hr = spObj->GetClientSite(&spClientSite);
			if(FAILED(hr)) return hr;
			
			CComPtr<IOleContainer> spContainer;
			hr = spClientSite->GetContainer(&spContainer);
			if(FAILED(hr)) return hr;

			CComPtr<IOleInPlaceFrame> spFrame;
			hr = spContainer->QueryInterface(&spFrame);
			if(FAILED(hr)) return hr;

			CComBSTR str(L"Event : ");
			str +=m_pEventInfo[n].m_strEventName;

			return spFrame->SetStatusText(str);
		}
	}

	return S_OK;
}
//--------------------------------------------------------------------------------------------------------------
