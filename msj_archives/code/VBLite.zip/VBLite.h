/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sun Sep 19 20:24:57 1999
 */
/* Compiler settings for C:\Dharma's container zone\containerex\VBLite.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __VBLite_h__
#define __VBLite_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IForm_FWD_DEFINED__
#define __IForm_FWD_DEFINED__
typedef interface IForm IForm;
#endif 	/* __IForm_FWD_DEFINED__ */


#ifndef __IExtendedDispatch_FWD_DEFINED__
#define __IExtendedDispatch_FWD_DEFINED__
typedef interface IExtendedDispatch IExtendedDispatch;
#endif 	/* __IExtendedDispatch_FWD_DEFINED__ */


#ifndef ___IFormEvents_FWD_DEFINED__
#define ___IFormEvents_FWD_DEFINED__
typedef interface _IFormEvents _IFormEvents;
#endif 	/* ___IFormEvents_FWD_DEFINED__ */


#ifndef __Form_FWD_DEFINED__
#define __Form_FWD_DEFINED__

#ifdef __cplusplus
typedef class Form Form;
#else
typedef struct Form Form;
#endif /* __cplusplus */

#endif 	/* __Form_FWD_DEFINED__ */


#ifndef __GeneralPage_FWD_DEFINED__
#define __GeneralPage_FWD_DEFINED__

#ifdef __cplusplus
typedef class GeneralPage GeneralPage;
#else
typedef struct GeneralPage GeneralPage;
#endif /* __cplusplus */

#endif 	/* __GeneralPage_FWD_DEFINED__ */


#ifndef __ExtendedDispatch_FWD_DEFINED__
#define __ExtendedDispatch_FWD_DEFINED__

#ifdef __cplusplus
typedef class ExtendedDispatch ExtendedDispatch;
#else
typedef struct ExtendedDispatch ExtendedDispatch;
#endif /* __cplusplus */

#endif 	/* __ExtendedDispatch_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IForm_INTERFACE_DEFINED__
#define __IForm_INTERFACE_DEFINED__

/* interface IForm */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IForm;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("AECB25D5-4581-11D2-8A38-00C04FA3FB82")
    IForm : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ControlBox( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ControlBox( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IFormVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IForm __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IForm __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IForm __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IForm __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IForm __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IForm __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IForm __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ControlBox )( 
            IForm __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ControlBox )( 
            IForm __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        END_INTERFACE
    } IFormVtbl;

    interface IForm
    {
        CONST_VTBL struct IFormVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IForm_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IForm_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IForm_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IForm_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IForm_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IForm_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IForm_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IForm_get_ControlBox(This,pVal)	\
    (This)->lpVtbl -> get_ControlBox(This,pVal)

#define IForm_put_ControlBox(This,newVal)	\
    (This)->lpVtbl -> put_ControlBox(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IForm_get_ControlBox_Proxy( 
    IForm __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB IForm_get_ControlBox_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IForm_put_ControlBox_Proxy( 
    IForm __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB IForm_put_ControlBox_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IForm_INTERFACE_DEFINED__ */


#ifndef __IExtendedDispatch_INTERFACE_DEFINED__
#define __IExtendedDispatch_INTERFACE_DEFINED__

/* interface IExtendedDispatch */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IExtendedDispatch;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("6BF5B59F-C506-11D2-B382-00C04F72D6C1")
    IExtendedDispatch : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Name( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Name( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_PositionX( 
            /* [in] */ long x) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_PositionX( 
            /* [retval][out] */ long __RPC_FAR *px) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_PositionY( 
            /* [in] */ long y) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_PositionY( 
            /* [retval][out] */ long __RPC_FAR *py) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SizeX( 
            /* [in] */ long x) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SizeX( 
            /* [retval][out] */ long __RPC_FAR *px) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SizeY( 
            /* [in] */ long y) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SizeY( 
            /* [retval][out] */ long __RPC_FAR *py) = 0;
        
        virtual /* [restricted][hidden][helpstring][id] */ HRESULT STDMETHODCALLTYPE SetDirty( 
            /* [in] */ VARIANT_BOOL bDirty) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IExtendedDispatchVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IExtendedDispatch __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IExtendedDispatch __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IExtendedDispatch __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IExtendedDispatch __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IExtendedDispatch __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IExtendedDispatch __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IExtendedDispatch __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Name )( 
            IExtendedDispatch __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Name )( 
            IExtendedDispatch __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_PositionX )( 
            IExtendedDispatch __RPC_FAR * This,
            /* [in] */ long x);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_PositionX )( 
            IExtendedDispatch __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *px);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_PositionY )( 
            IExtendedDispatch __RPC_FAR * This,
            /* [in] */ long y);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_PositionY )( 
            IExtendedDispatch __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *py);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SizeX )( 
            IExtendedDispatch __RPC_FAR * This,
            /* [in] */ long x);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SizeX )( 
            IExtendedDispatch __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *px);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SizeY )( 
            IExtendedDispatch __RPC_FAR * This,
            /* [in] */ long y);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SizeY )( 
            IExtendedDispatch __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *py);
        
        /* [restricted][hidden][helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetDirty )( 
            IExtendedDispatch __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL bDirty);
        
        END_INTERFACE
    } IExtendedDispatchVtbl;

    interface IExtendedDispatch
    {
        CONST_VTBL struct IExtendedDispatchVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IExtendedDispatch_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IExtendedDispatch_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IExtendedDispatch_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IExtendedDispatch_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IExtendedDispatch_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IExtendedDispatch_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IExtendedDispatch_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IExtendedDispatch_get_Name(This,pVal)	\
    (This)->lpVtbl -> get_Name(This,pVal)

#define IExtendedDispatch_put_Name(This,newVal)	\
    (This)->lpVtbl -> put_Name(This,newVal)

#define IExtendedDispatch_put_PositionX(This,x)	\
    (This)->lpVtbl -> put_PositionX(This,x)

#define IExtendedDispatch_get_PositionX(This,px)	\
    (This)->lpVtbl -> get_PositionX(This,px)

#define IExtendedDispatch_put_PositionY(This,y)	\
    (This)->lpVtbl -> put_PositionY(This,y)

#define IExtendedDispatch_get_PositionY(This,py)	\
    (This)->lpVtbl -> get_PositionY(This,py)

#define IExtendedDispatch_put_SizeX(This,x)	\
    (This)->lpVtbl -> put_SizeX(This,x)

#define IExtendedDispatch_get_SizeX(This,px)	\
    (This)->lpVtbl -> get_SizeX(This,px)

#define IExtendedDispatch_put_SizeY(This,y)	\
    (This)->lpVtbl -> put_SizeY(This,y)

#define IExtendedDispatch_get_SizeY(This,py)	\
    (This)->lpVtbl -> get_SizeY(This,py)

#define IExtendedDispatch_SetDirty(This,bDirty)	\
    (This)->lpVtbl -> SetDirty(This,bDirty)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IExtendedDispatch_get_Name_Proxy( 
    IExtendedDispatch __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IExtendedDispatch_get_Name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IExtendedDispatch_put_Name_Proxy( 
    IExtendedDispatch __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IExtendedDispatch_put_Name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IExtendedDispatch_put_PositionX_Proxy( 
    IExtendedDispatch __RPC_FAR * This,
    /* [in] */ long x);


void __RPC_STUB IExtendedDispatch_put_PositionX_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IExtendedDispatch_get_PositionX_Proxy( 
    IExtendedDispatch __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *px);


void __RPC_STUB IExtendedDispatch_get_PositionX_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IExtendedDispatch_put_PositionY_Proxy( 
    IExtendedDispatch __RPC_FAR * This,
    /* [in] */ long y);


void __RPC_STUB IExtendedDispatch_put_PositionY_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IExtendedDispatch_get_PositionY_Proxy( 
    IExtendedDispatch __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *py);


void __RPC_STUB IExtendedDispatch_get_PositionY_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IExtendedDispatch_put_SizeX_Proxy( 
    IExtendedDispatch __RPC_FAR * This,
    /* [in] */ long x);


void __RPC_STUB IExtendedDispatch_put_SizeX_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IExtendedDispatch_get_SizeX_Proxy( 
    IExtendedDispatch __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *px);


void __RPC_STUB IExtendedDispatch_get_SizeX_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IExtendedDispatch_put_SizeY_Proxy( 
    IExtendedDispatch __RPC_FAR * This,
    /* [in] */ long y);


void __RPC_STUB IExtendedDispatch_put_SizeY_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IExtendedDispatch_get_SizeY_Proxy( 
    IExtendedDispatch __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *py);


void __RPC_STUB IExtendedDispatch_get_SizeY_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [restricted][hidden][helpstring][id] */ HRESULT STDMETHODCALLTYPE IExtendedDispatch_SetDirty_Proxy( 
    IExtendedDispatch __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL bDirty);


void __RPC_STUB IExtendedDispatch_SetDirty_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IExtendedDispatch_INTERFACE_DEFINED__ */



#ifndef __VBLiteLib_LIBRARY_DEFINED__
#define __VBLiteLib_LIBRARY_DEFINED__

/* library VBLiteLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_VBLiteLib;

#ifndef ___IFormEvents_DISPINTERFACE_DEFINED__
#define ___IFormEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IFormEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IFormEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("AECB25D7-4581-11D2-8A38-00C04FA3FB82")
    _IFormEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IFormEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _IFormEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _IFormEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _IFormEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _IFormEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _IFormEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _IFormEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _IFormEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _IFormEventsVtbl;

    interface _IFormEvents
    {
        CONST_VTBL struct _IFormEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IFormEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IFormEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IFormEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IFormEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IFormEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IFormEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IFormEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IFormEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_Form;

#ifdef __cplusplus

class DECLSPEC_UUID("AECB25D6-4581-11D2-8A38-00C04FA3FB82")
Form;
#endif

EXTERN_C const CLSID CLSID_GeneralPage;

#ifdef __cplusplus

class DECLSPEC_UUID("6BF5B593-C506-11D2-B382-00C04F72D6C1")
GeneralPage;
#endif

EXTERN_C const CLSID CLSID_ExtendedDispatch;

#ifdef __cplusplus

class DECLSPEC_UUID("6BF5B5A0-C506-11D2-B382-00C04F72D6C1")
ExtendedDispatch;
#endif
#endif /* __VBLiteLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
