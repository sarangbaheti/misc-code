//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//So use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

// AboutBox.h : Declaration of the CAboutBox

#ifndef __ABOUTBOX_H_
#define __ABOUTBOX_H_

#include "resource.h"       // main symbols
#include <atlhost.h>

// CAboutBox
class CAboutBox : public CAxDialogImpl<CAboutBox>
{
public:
	CAboutBox(){}
	~CAboutBox(){}
	enum { IDD = IDD_ABOUTBOX };

BEGIN_MSG_MAP(CAboutBox)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_ID_HANDLER(IDOK, OnOK)
	COMMAND_ID_HANDLER(IDC_CHRIS_PAGE, OnChrisPage)
	COMMAND_ID_HANDLER(IDC_MY_PAGE, OnMyPage)
END_MSG_MAP()

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		CenterWindow();		
		RECT rc = { 10,10,370,200 };
		m_wndBrowser.Create(m_hWnd,rc,_T("http://members.tripod.com/IUnknwn"),
							WS_CHILD | WS_VISIBLE|WS_BORDER|WS_VSCROLL|WS_HSCROLL,0);
		return 1;  // Let the system set the focus
	}

	LRESULT OnOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		EndDialog(wID);
		return 0;
	}
	
	LRESULT OnChrisPage(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		CComPtr<IWebBrowser2> spBrowser;
		HRESULT hr = m_wndBrowser.QueryControl(&spBrowser);
		if(SUCCEEDED(hr))
			spBrowser->Navigate(L"http://www.sellsbrothers.com",0,0,0,0);
		
		return 0;
	}
	LRESULT OnMyPage(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		CComPtr<IWebBrowser2> spBrowser;
		HRESULT hr = m_wndBrowser.QueryControl(&spBrowser);
		if(SUCCEEDED(hr))
			spBrowser->Navigate(L"http://members.tripod.com/IUnknwn",0,0,0,0);
		
		return 0;
	}

private:
	CAxWindow m_wndBrowser;
};

#endif //__ABOUTBOX_H_
