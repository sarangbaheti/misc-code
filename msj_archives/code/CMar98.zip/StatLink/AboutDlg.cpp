////////////////////////////////////////////////////////////////
// ABOUTDLG Copyright 1996 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// ABOUTDLG illustrates how to use CStaticLink to implement an About
// dialog with a web links in it.

#include "StdAfx.h"
#include "Resource.h"
#include "StatLink.h"
#include <afxpriv.h> // for WM_KICKIDLE

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////
// Standard main frame class
//
class CMainFrame : public CFrameWnd {
protected:
	DECLARE_DYNAMIC(CMainFrame)
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	DECLARE_MESSAGE_MAP()
};

/////////////////
// Standard app class
//
class CMyApp : public CWinApp {
public:
	CMyApp();
protected:
	DECLARE_DYNAMIC(CMyApp)
	virtual BOOL InitInstance();
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

////////////////////////////////////////////////////////////////
// CMyApp implementation
//
CMyApp theApp;

IMPLEMENT_DYNAMIC(CMyApp, CWinApp)

BEGIN_MESSAGE_MAP(CMyApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
END_MESSAGE_MAP()

CMyApp::CMyApp()
{
}

//////////////////
// Standard InitInstance
//
BOOL CMyApp::InitInstance()
{
   // Create main frame window (don't use doc/view stuff)
   // 
   CMainFrame* pMainFrame = new CMainFrame;
   if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
      return FALSE;
   pMainFrame->ShowWindow(m_nCmdShow);
   pMainFrame->UpdateWindow();
   m_pMainWnd = pMainFrame;

	return TRUE;
}

//////////////////
// Custom about dialog uses CStaticLink for hyperlinks.
//    * for text control, URL is specified as text in dialog editor
//    * for icon control, URL is specified by setting m_iconLink.m_link
//
class CAboutDialog : public CDialog {
protected:
	// static controls with hyperlinks
	CStaticLink	m_wndLink1;
	CStaticLink	m_wndLink2;
	CStaticLink	m_wndLink3;

public:
	CAboutDialog();
	~CAboutDialog();
	virtual BOOL OnInitDialog();

	afx_msg LRESULT OnKickIdle(WPARAM wp, LPARAM lp);

	DECLARE_MESSAGE_MAP()
};

////////////////////////////////////////////////////////////////
// CAboutDialog
//
BEGIN_MESSAGE_MAP(CAboutDialog, CDialog)
	ON_MESSAGE(WM_KICKIDLE, OnKickIdle)
END_MESSAGE_MAP()

CAboutDialog::CAboutDialog() : CDialog(IDD_ABOUTBOX)
{
}

CAboutDialog::~CAboutDialog()
{
}

/////////////////
// Initialize dialog: subclass static text/icon controls
//
BOOL CAboutDialog::OnInitDialog()
{
	// subclass static controls. URL is static text as given in RC file.
	m_wndLink1.SubclassDlgItem(IDC_TEXTPD,  this);
	m_wndLink2.SubclassDlgItem(IDC_TEXTMSJ, this);
	m_wndLink3.SubclassDlgItem(IDC_ICONMSJ, this);

	// if URL different from text, need to set
	m_wndLink2.m_link = _T("http://www.microsoft.com/msj");

	// for static icon, need to explicitly set the URL
	m_wndLink3.m_link = _T("http://www.microsoft.com/msj");

	return CDialog::OnInitDialog();
}

//////////////////
// Handle idle message: update dialog controls. This is required to make
// the idle update command UI mechanism work for a dialog. Not needed for
// this app, but it's a good habit to do for all dialogs.
//
LRESULT CAboutDialog::OnKickIdle(WPARAM wp, LPARAM lCount)
{
	UpdateDialogControls(this, TRUE);
	return 0;
}

//////////////////
// Handle Help | About : run the About dialog
//
void CMyApp::OnAppAbout()
{
	static CAboutDialog dlg;
	dlg.DoModal();
}

////////////////////////////////////////////////////////////////
// CMainFrame implementation
//
IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
END_MESSAGE_MAP()

static UINT BASED_CODE indicators[] = {
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT))) {
		TRACE("Failed to create status bar\n");
		return -1;      // fail to create
	}

	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	return 0;
}
