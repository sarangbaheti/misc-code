//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AboutDlg.rc
//
#define IDR_MAINFRAME                   2
#define IDD_ABOUTBOX                    100
#define IDI_ICONMSJ                     102
#define IDC_URLTEXT                     1001
#define IDC_TEXTPD                      1001
#define IDC_URLICON                     1002
#define IDC_ICONMSJ                     1002
#define IDC_TEXTMSJ                     1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
