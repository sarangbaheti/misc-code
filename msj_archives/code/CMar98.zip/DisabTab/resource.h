//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TabApp.rc
//
#define IDR_MAINFRAME                   2
#define IDD_ABOUTBOX                    100
#define IDD_MYPAGE1                     102
#define IDD_MYPAGE2                     103
#define IDD_MYPAGE3                     104
#define IDD_MYPAGE4                     105
#define IDD_MYPAGE5                     106
#define IDC_CHECK1                      1000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
