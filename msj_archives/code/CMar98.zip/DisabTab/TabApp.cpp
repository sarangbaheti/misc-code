////////////////////////////////////////////////////////////////
// TabApp Copyright 1998 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// TabApp illustrates how to use CTabCtrlWithDisable to
// implement a tab control with disabled tabs.

#include "stdafx.h"
#include "TabApp.h"
#include "DisabTab.h"
#include "TraceWin.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////
// My tab control: page 3 is disabled
class CMyTabCtrl : public CTabCtrlWithDisable {
public:
	virtual BOOL IsTabEnabled(int iTab) {
		return iTab!=2; // Only tab 3 is disabled
	}
};

////////////////////////////////////////////////////////////////
// My Property Sheet. Overrides to use CMyTabCtrl
//
class CMyPropSheet : public CPropertySheet {
public:
	CMyPropSheet() : CPropertySheet("My Property Sheet") { }
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
protected:
	CMyTabCtrl m_tabCtrl;
};

//////////////////
// Initialize propery sheet: subclass the tab control
//
BOOL CMyPropSheet::OnInitDialog()
{
	BOOL bRet = CPropertySheet::OnInitDialog();

	// get HWND of tab control and subclass it
	HWND hWndTab = (HWND)SendMessage(PSM_GETTABCONTROL);
	m_tabCtrl.SubclassDlgItem(::GetDlgCtrlID(hWndTab), this);

	return bRet;
}

//////////////////
// PreTranslateMessage: call special tab control fn to maybe translate
//
BOOL CMyPropSheet::PreTranslateMessage(MSG* pMsg)
{
	return m_tabCtrl.TranslatePropSheetMsg(pMsg) ? TRUE :
		CPropertySheet::PreTranslateMessage(pMsg);
}

CApp theApp;

CApp::CApp()
{
}

BOOL CApp::InitInstance()
{
//	SetRegistryKey(_T("MSJ"));		// Save settings in registry "MSJ", not INI file
//	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	CPropertyPage p1(IDD_MYPAGE1);
	CPropertyPage p2(IDD_MYPAGE2);
	CPropertyPage p3(IDD_MYPAGE3);
	CPropertyPage p4(IDD_MYPAGE4);
	CPropertyPage p5(IDD_MYPAGE5);

	CMyPropSheet ps;
	ps.AddPage(&p1);
	ps.AddPage(&p2);
	ps.AddPage(&p3);
	ps.AddPage(&p4);
	ps.AddPage(&p5);

	ps.DoModal();

	// Since the dialog has been closed, return FALSE to exit the app
	// 
	return FALSE;
}
