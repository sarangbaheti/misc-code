#include "simpldll.h"

int main()
{
	return FunctionInADLL() + 2;
}
