//==================================
// LOADPROF32 - Matt Pietrek 1995
// FILE: LODPRF32.C
//==================================
#include <windows.h>
#include <commdlg.h>
#include <mmsystem.h>   // For timeGetTime()
#include <stdarg.h>
#include <process.h>
#include <string.h>
#include <malloc.h>
#pragma hdrstop
#include "lodprf32.h"

// Helper functions
void Handle_WM_COMMAND(HWND hWndDlg, WPARAM wParam, LPARAM lParam);
void Handle_WM_INITDIALOG(HWND hWndDlg);
void Handle_WM_SIZE(HWND hWndDlg, WPARAM wParam, LPARAM lParam );
void Handle_WM_GETMINMAXINFO(HWND hWndDlg, LPARAM lParam );
void Handle_Browse( HWND hWndDlg );
void Handle_Go( HWND hWndDlg );
BOOL CALLBACK LoadProf32DlgProc(HWND, UINT, WPARAM, LPARAM);
void lbprintf(HWND hWnd, char * format, ...);
void DebugEventThreadProc( void *pv );
BOOL LoadTheProcess( PSTR pszCmdLine );
DWORD HandleDebugEvent( DEBUG_EVENT * event );
BOOL ReadProcessMemoryEx( HANDLE hProcess, LPCVOID lpBaseAddress,
                          LPVOID lpBuffer, DWORD  cbRead );
BOOL GetModuleHeader( HANDLE hProcess, LPCVOID hModule,
                      PIMAGE_NT_HEADERS pNTHdr );
BOOL GetModuleNameInProcess(HANDLE hProcess, HMODULE hModule,
                            PSTR pszModName, unsigned cbModName );
PVOID GetPreferredLoadAddress( HANDLE hProcess, LPCVOID hModule );
PVOID AddEntryPointBreakpoint( HANDLE hProcess, LPVOID lpBaseAddress );
BOOL  IsEntryBreakpoint( HANDLE hProcess, HANDLE hThread,
                         PVOID exceptionAddress, PVOID *lpBaseAddress );
void ClearBreakpointList( void );

// ====================== Global Variables =============================

HWND HWndLB;
HWND HWndDlg;

PROCESS_INFORMATION ProcessInformation;
PVOID ExeEntryPoint;
BOOL fFirstBreakpoint;
DWORD InitStartTime, InitEndTime;   // DLL init time in milliseconds
BOOL fProfiling = TRUE;

// Registry key names and values used to save info across runs
char gszRegistryKey[] = "Software\\WheatyProductions\\LodPrf32";
char gszLastProgram[] = "LastProgram";
char gszProfilingState[] = "Profiling";

// ======================= Start of code ===============================

int PASCAL WinMain( HANDLE hInstance, HANDLE hPrevInstance,
                    LPSTR lpszCmdLine, int nCmdShow )
{
    WNDCLASS wndclass;

    // Kludge-0-Rama to make the dialog box use our own icon
    if ( !GetClassInfo( 0, MAKEINTRESOURCE(32770), &wndclass ) )
        return 0;
    wndclass.hInstance = hInstance;
    wndclass.hIcon = LoadIcon(hInstance,"LodPrf32Icon");
    wndclass.lpszClassName = "LODPRF32DLG";
    if ( !RegisterClass(&wndclass) )
        return 0;

    // The user interface is a modal dialog box
    DialogBox(hInstance, "LoadProf32Dlg", 0, (DLGPROC)LoadProf32DlgProc);
    return 0;
}

// =================== Start of Debugger code ===========================

BOOL LoadTheProcess( PSTR pszCmdLine )
{
    STARTUPINFO startupInfo;

    memset(&startupInfo, 0, sizeof(startupInfo));
    startupInfo.cb = sizeof(startupInfo);

    return CreateProcess(
                0,                          // lpszImageName
                pszCmdLine,                 // lpszCommandLine
                0, 0,                       // lpsaProcess and lpszThread
                FALSE,                      // fInheritHandles
                DEBUG_ONLY_THIS_PROCESS,    // fdwCreate
                0, 0,                       // lpvEnvironment and lpszCurDir
                &startupInfo,               // lpsiStartupInfo
                &ProcessInformation );      // lppiProcInfo
}

void DebugEventThreadProc( void *pv )
{
    DEBUG_EVENT event;
    DWORD continueStatus;
    PSTR pszCmdLine = pv;

    ClearBreakpointList();      // Clear out states in preparation for
    ExeEntryPoint = 0;          // the new process.
    fFirstBreakpoint = TRUE;

    if ( !LoadTheProcess( pszCmdLine ) )
    {
        MessageBox( HWndDlg, "Unable to start program", 0, MB_ICONSTOP );
        return;
    }

    EnableWindow( GetDlgItem(HWndDlg, IDC_BT_GO), FALSE );  // disable "Go"
                                                            // button

    // The main debug event loop. Loop until we see an EXIT_PROCESS_DEBUG_EVENT
    while ( WaitForDebugEvent(&event, INFINITE) )
    {
        continueStatus = HandleDebugEvent( &event );

        if ( event.dwDebugEventCode == EXIT_PROCESS_DEBUG_EVENT )
        {
            // New 1.1 code to close these handles, as we don't need'em anymore
            CloseHandle( ProcessInformation.hProcess );
            CloseHandle( ProcessInformation.hThread );
            break;
        }

        ContinueDebugEvent(event.dwProcessId,event.dwThreadId,continueStatus);
    }

    EnableWindow( GetDlgItem(HWndDlg, IDC_BT_GO), TRUE );   // Enable Go button
}

DWORD Handle_LOAD_DLL_DEBUG_EVENT( DEBUG_EVENT * event )
{
    char szDllName[64];
    LPVOID preferredLoadAddr;

    GetModuleNameInProcess( ProcessInformation.hProcess,
                            (HMODULE)event->u.LoadDll.lpBaseOfDll,
                            szDllName, sizeof(szDllName) );
    lbprintf( HWndLB, "DLL Load: %s at address %08X", szDllName,
                event->u.LoadDll.lpBaseOfDll );

    // Check if the actual load address matched the preferred load address
    preferredLoadAddr
        = GetPreferredLoadAddress( ProcessInformation.hProcess,
                                    event->u.LoadDll.lpBaseOfDll );
    if ( preferredLoadAddr != event->u.LoadDll.lpBaseOfDll )
    {
        lbprintf( HWndLB, "  *** %s would prefer to be loaded at %08X ***",
                  szDllName, preferredLoadAddr );
    }

    AddEntryPointBreakpoint( ProcessInformation.hProcess,
                            event->u.LoadDll.lpBaseOfDll );
    return DBG_CONTINUE;
}

DWORD Handle_EXCEPTION_DEBUG_EVENT( DEBUG_EVENT * event )
{
    LPVOID lpModuleBase;
    PVOID exceptionAddress;

    exceptionAddress = event->u.Exception.ExceptionRecord.ExceptionAddress;

    // If it's a breakpoint, check to see if it's one of the breakpoints we
    // set, and if so, deal with it accordingly.
    if ( STATUS_BREAKPOINT==event->u.Exception.ExceptionRecord.ExceptionCode )
    {
        if ( IsEntryBreakpoint( ProcessInformation.hProcess,
                                ProcessInformation.hThread,
                                exceptionAddress, &lpModuleBase) )
        {
            char szDllName[260];

            // Is it the breakpoint we set on the EXE's entry point
            if ( exceptionAddress == ExeEntryPoint )
            {
                InitEndTime = timeGetTime();
                SendMessage( HWndLB, WM_SETREDRAW, TRUE, 0 );   // redraws on
                lbprintf( HWndLB, "EXE entry point hit - %u ms initializing ",
                            InitEndTime - InitStartTime );
                return DBG_CONTINUE;
            }

            // If we get here, it's a breakpoint we set on a DLL entry point
            GetModuleNameInProcess( ProcessInformation.hProcess,
                                    (HMODULE)lpModuleBase,
                                    szDllName, sizeof(szDllName) );
            lbprintf( HWndLB, "DLL Init: %s", szDllName );
            return DBG_CONTINUE;
        }
        else if ( fFirstBreakpoint )    // First breakpoint comes automatically
        {                               // from a loader call to DebugBreak
            fFirstBreakpoint = FALSE;
            if ( fProfiling )
            {
                lbprintf( HWndLB, "DebugBreak breakpoint hit" );
                SendMessage( HWndLB, WM_SETREDRAW, FALSE, 0 );  // no LB update
                InitStartTime = timeGetTime();
            }
            return DBG_CONTINUE;
        }
        goto handle_exception_other;    // Display as a regular exception
    }
    else    // Not a breakpoint exception.  Display information about it.
    {
        handle_exception_other:
        lbprintf( HWndLB, "Exception: %08X (%s chance) at %08X",
            event->u.Exception.ExceptionRecord.ExceptionCode,
            event->u.Exception.dwFirstChance ? "First" : "Second",
            event->u.Exception.ExceptionRecord.ExceptionAddress );
        lbprintf( HWndLB, "See WINNT.H for exception codes (STATUS_xxx)" );

        return DBG_EXCEPTION_NOT_HANDLED;
    }
}

DWORD Handle_OUTPUT_DEBUG_STRING_EVENT( DEBUG_EVENT * event )
{
    char szODS[4096];
    unsigned readLen;
    BOOL fOK;

    if ( event->u.DebugString.fUnicode )
    {
        lbprintf( HWndLB, "OutputDebugString not unicodified" );
        return DBG_CONTINUE;
    }

    // We have to read the string from the address space of the debuggee
    readLen = min( sizeof(szODS)-1, event->u.DebugString.nDebugStringLength );
    fOK = ReadProcessMemoryEx( ProcessInformation.hProcess,
                    event->u.DebugString.lpDebugStringData, szODS, readLen );
    if ( fOK )
    {
        PSTR pszTok;
        szODS[ readLen ] = 0;
        pszTok = strtok( szODS, "\r\n" );   // use strtok to split apart
        do                                  // strings separated by \r\n
        {
            lbprintf( HWndLB, "OutDbgStr: %s", pszTok );
        } while ( pszTok = strtok(0, "\r\n") );
    }

    return DBG_CONTINUE;
 }

PSTR SzDebugEventTypes[] = {
    "", "EXCEPTION", "CREATE_THREAD", "CREATE_PROCESS", "EXIT_THREAD",
    "EXIT_PROCESS", "LOAD_DLL", "UNLOAD_DLL", "OUTPUT_DEBUG_STRING", "RIP" };


DWORD HandleDebugEvent( DEBUG_EVENT * event )
{
    switch ( event->dwDebugEventCode )
    {
        case CREATE_PROCESS_DEBUG_EVENT:
        {
            PVOID processBase = event->u.CreateProcessInfo.lpBaseOfImage;
            if ( fProfiling )
            {
                ExeEntryPoint = AddEntryPointBreakpoint(
                                    ProcessInformation.hProcess,processBase);
                lbprintf( HWndLB, "Process loaded at: %08X", processBase );
            }
            // New 1.1 code to close the file handle, since we don't need it
            if ( event->u.CreateProcessInfo.hFile )
                CloseHandle( event->u.CreateProcessInfo.hFile );
            // New 1.1 code to close these handle, since we don't need'em
            if ( event->u.CreateProcessInfo.hProcess )
                CloseHandle( event->u.CreateProcessInfo.hProcess );
            if ( event->u.CreateProcessInfo.hThread )
                CloseHandle( event->u.CreateProcessInfo.hThread );
            break;
        }

        case LOAD_DLL_DEBUG_EVENT:
                if ( fProfiling )
                    Handle_LOAD_DLL_DEBUG_EVENT( event );
                // New 1.1 code to close DLL file handle.  We don't need it
                if ( event->u.LoadDll.hFile )
                    CloseHandle( event->u.LoadDll.hFile );
                break;
        case EXCEPTION_DEBUG_EVENT:
                return Handle_EXCEPTION_DEBUG_EVENT( event );

        case OUTPUT_DEBUG_STRING_EVENT:
                return Handle_OUTPUT_DEBUG_STRING_EVENT( event );

        // New 1.1 code to close the thread handle, since we don't need it
        case CREATE_THREAD_DEBUG_EVENT:
            if ( event->u.CreateThread.hThread )
                CloseHandle( event->u.CreateThread.hThread );
            break;

        default:
            if ( fProfiling )
                lbprintf( HWndLB, SzDebugEventTypes[event->dwDebugEventCode] );
    }

    return DBG_CONTINUE;
}

// MakePtr is a macro that allows you to easily add to values (including
// pointers) together without dealing with C's pointer arithmetic.  It
// essentially treats the last two parameters as DWORDs.  The first
// parameter is used to typecast the result to the appropriate pointer type.
#define MakePtr( cast, ptr, addValue ) (cast)( (DWORD)(ptr) + (DWORD)(addValue))

// Fills in an IMAGE_NT_HEADERS structure for the specified HMODULE

BOOL GetModuleHeader( HANDLE hProcess, LPCVOID hModule,
                      PIMAGE_NT_HEADERS pNTHdr )
{
    IMAGE_DOS_HEADER dosHdr;

    if ( !ReadProcessMemoryEx(hProcess, hModule, &dosHdr, sizeof(dosHdr)) )
        return FALSE;

    if ( !ReadProcessMemoryEx(  hProcess,
                                MakePtr( PVOID, hModule, dosHdr.e_lfanew ),
                                pNTHdr, sizeof(*pNTHdr)) )
        return FALSE;

    return TRUE;
}

// Gets the name of the specified DLL in the debuggee process

BOOL GetModuleNameInProcess( HANDLE hProcess, HMODULE hModule,
                             PSTR pszModName, unsigned cbModName )
{
    IMAGE_NT_HEADERS ntHdr;
    IMAGE_EXPORT_DIRECTORY exportDir;
    DWORD exportsRVA;

    strcpy( pszModName, "<unknown>" );  // In case something goes wrong

    if ( !GetModuleHeader( hProcess, hModule, &ntHdr ) )
        return FALSE;

    exportsRVA =
        ntHdr.OptionalHeader.
                DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;

    if ( !exportsRVA )
        return FALSE;

    if ( !ReadProcessMemoryEx(  hProcess,
                                MakePtr(PVOID, hModule, exportsRVA ),
                                &exportDir, sizeof(exportDir)) )
        return FALSE;

    if ( !ReadProcessMemoryEx(  hProcess,
                                MakePtr(PVOID, hModule, exportDir.Name),
                                pszModName, cbModName) )
        return FALSE;

    return TRUE;
}

PVOID GetPreferredLoadAddress( HANDLE hProcess, LPCVOID hModule )
{
    IMAGE_NT_HEADERS ntHdr;

    if ( !GetModuleHeader( hProcess, hModule, &ntHdr ) )
        return FALSE;

    return (LPVOID)ntHdr.OptionalHeader.ImageBase;
}

// A wrapper around ReadProcessMemory to make it easier to use

BOOL ReadProcessMemoryEx( HANDLE hProcess, LPCVOID lpBaseAddress,
                          LPVOID lpBuffer, DWORD cbRead )
{
    DWORD nBytesRead;
    if ( !ReadProcessMemory( hProcess, lpBaseAddress, lpBuffer, cbRead,
                             &nBytesRead ) )
        return FALSE;
    return nBytesRead == cbRead;
}

// =================== Start of Breakpoint code ===========================

typedef struct tagENTRY_POINT_BP
{
    struct tagENTRY_POINT_BP * pNext;
    LPVOID  lpBaseAddress;
    LPVOID  entryPointAddress;
    BYTE    originalOpcode;
} ENTRY_POINT_BP, *PENTRY_POINT_BP;

PENTRY_POINT_BP pHeadBreakpoint = 0;

PVOID AddEntryPointBreakpoint( HANDLE hProcess, LPVOID lpBaseAddress )
{
    PENTRY_POINT_BP pBP;
    BYTE bpOpcode = 0xCC;
    LPVOID entryPoint;
    IMAGE_NT_HEADERS ntHdr;
    BYTE originalOpcode;

    if ( !GetModuleHeader( hProcess, lpBaseAddress, &ntHdr ) )
        return 0;

    if ( !ntHdr.OptionalHeader.AddressOfEntryPoint )
        return 0;

    entryPoint
     = MakePtr(LPVOID,lpBaseAddress,ntHdr.OptionalHeader.AddressOfEntryPoint);

    if ( !ReadProcessMemoryEx( hProcess, entryPoint, &originalOpcode, 1 ) )
        return 0;

    if ( !WriteProcessMemory( hProcess, entryPoint, &bpOpcode, 1, 0) )
        return 0;

    if ( !(pBP = malloc(sizeof(ENTRY_POINT_BP))) )
        return 0;

    pBP->pNext = pHeadBreakpoint;
    pBP->lpBaseAddress = lpBaseAddress;
    pBP->entryPointAddress = entryPoint;
    pBP->originalOpcode = originalOpcode;
    pHeadBreakpoint = pBP;
    return entryPoint;
}

BOOL IsEntryBreakpoint( HANDLE hProcess, HANDLE hThread,
                        PVOID exceptionAddress, PVOID *lplpBaseAddress )
{
    PENTRY_POINT_BP pBP, pBPprev = 0;
    CONTEXT ctx;

    pBP = pHeadBreakpoint;
    while ( pBP )
    {
        if ( pBP->entryPointAddress == exceptionAddress )
            break;

        pBPprev = pBP;      // Save pointer to previous node
        pBP = pBP->pNext;   // advance to next node
    }

    if ( !pBP )             // if not found, return FALSE;
        return FALSE;

    if ( pBPprev )                      // If there was a preceding node,
        pBPprev->pNext = pBP->pNext;    // hook it to the next node
    else
        pHeadBreakpoint = pHeadBreakpoint->pNext;   // Thanks to Dave Austin
                                                    // for catching this

    *lplpBaseAddress = pBP->lpBaseAddress;  // Fill in the module base address

    WriteProcessMemory( hProcess, pBP->entryPointAddress,
                        &pBP->originalOpcode, 1, 0 );

    ctx.ContextFlags = CONTEXT_CONTROL;
    GetThreadContext( hThread, &ctx );
    ctx.Eip--;
    SetThreadContext( hThread, &ctx );

    free( pBP );                        // Free the BP node

    return TRUE;
}

void ClearBreakpointList( void )
{
    PENTRY_POINT_BP pBP, pBP2;

    pBP = pHeadBreakpoint;
    while ( pBP )
    {
        pBP2 = pBP->pNext;
        free( pBP );
        pBP = pBP2;
    }
    pHeadBreakpoint = 0;
}

// ================= Start of user interface code ========================

//
// Dialog proc for the main dialog
//
BOOL CALLBACK LoadProf32DlgProc(HWND hWndDlg, UINT msg,
                              WPARAM wParam, LPARAM lParam )
{
    switch ( msg )
    {
        case WM_COMMAND:
            Handle_WM_COMMAND(hWndDlg, wParam, lParam); return TRUE;
        case WM_INITDIALOG:
            Handle_WM_INITDIALOG(hWndDlg); return TRUE;
        case WM_CLOSE:
            EndDialog(hWndDlg, 0); return FALSE;
        case WM_SIZE:
            Handle_WM_SIZE( hWndDlg, wParam, lParam ); return FALSE;
        case WM_GETMINMAXINFO:
            Handle_WM_GETMINMAXINFO( hWndDlg, lParam ); return FALSE;
    }
    return FALSE;
}

//
// Handle the dialog's WM_COMMAND messages
//
void Handle_WM_COMMAND(HWND hWndDlg, WPARAM wParam, LPARAM lParam)
{
    switch ( LOWORD(wParam) )
    {
        case IDC_BT_GO: Handle_Go( hWndDlg ); break;
        case IDC_BT_BROWSE: Handle_Browse( hWndDlg ); break;
    }
    return;
}

void Handle_WM_INITDIALOG(HWND hWndDlg)
{
    HKEY hKey;
    char szCmdLine[512];
    LONG err;

    HWndDlg = hWndDlg;
    HWndLB = GetDlgItem(hWndDlg, IDC_LB_OUTPUT);

    err =RegOpenKeyEx(HKEY_CURRENT_USER,gszRegistryKey,0,KEY_ALL_ACCESS,&hKey);
    if ( ERROR_SUCCESS == err )
    {
        DWORD dwType, dwValueSize = sizeof(szCmdLine);

        err = RegQueryValueEx( hKey, gszLastProgram, 0, &dwType,
                              (LPBYTE)szCmdLine, &dwValueSize );
        if ( ERROR_SUCCESS == err )
            SetDlgItemText( hWndDlg, IDC_EDIT_CMDLINE, szCmdLine );

        RegQueryValueEx( hKey, gszProfilingState, 0, &dwType,
                          (PBYTE)&fProfiling, &dwValueSize );
    }

    CheckRadioButton( hWndDlg, IDC_RB_PROFILE, IDC_RB_ODS,
                        fProfiling ? IDC_RB_PROFILE : IDC_RB_ODS );
}

void Handle_WM_SIZE(HWND hWndDlg, WPARAM wParam, LPARAM lParam )
{
    RECT dlgRect, lbRect;
    POINT pt;
    int horizBorder, topBorder;

    GetClientRect( hWndDlg, &dlgRect );
    GetWindowRect( HWndLB, &lbRect );
    pt.x = lbRect.left;
    pt.y = lbRect.top;
    ScreenToClient( hWndDlg, &pt );
    horizBorder = pt.x;
    topBorder = pt.y;

    if ( HIWORD(lParam) <= topBorder )
        return;

    MoveWindow( HWndLB, horizBorder, topBorder,
                dlgRect.right - dlgRect.left - (2*horizBorder),
                dlgRect.bottom - topBorder,
                TRUE );
}

void Handle_WM_GETMINMAXINFO(HWND hWndDlg, LPARAM lParam )
{
    RECT dlgRect, lbRect;
    LPMINMAXINFO lpmmi = (LPMINMAXINFO)lParam;
    static int minWidth = 0;

    GetWindowRect( hWndDlg, &dlgRect );
    GetWindowRect( HWndLB, &lbRect );

    if ( !minWidth )
        minWidth = dlgRect.right - dlgRect.left;

    lpmmi->ptMinTrackSize.x = minWidth;
    lpmmi->ptMinTrackSize.y = lbRect.top - dlgRect.top;
}

void Handle_Go( HWND hWndDlg )
{
    char szCmdLine[512];
    HKEY hKey;
    DWORD disposition;
    LONG err;

    GetDlgItemText( hWndDlg, IDC_EDIT_CMDLINE, szCmdLine, sizeof(szCmdLine) );
    fProfiling = IsDlgButtonChecked( HWndDlg, IDC_RB_PROFILE );

    SendMessage( HWndLB, LB_RESETCONTENT, 0, 0 );

    _beginthread( DebugEventThreadProc, 0, (PVOID)szCmdLine );

    err = RegCreateKeyEx( HKEY_CURRENT_USER, gszRegistryKey, 0, 0,
                         REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS,
                         0, &hKey, &disposition );
    if ( ERROR_SUCCESS == err )
    {
        RegSetValueEx( hKey, gszLastProgram, 0, REG_SZ,
                       (PBYTE)szCmdLine, lstrlen(szCmdLine)+1 );
        RegSetValueEx( hKey, gszProfilingState, 0, REG_DWORD,
                       (PBYTE)&fProfiling, sizeof(fProfiling) );
    }
}

void Handle_Browse( HWND hWndDlg )
{
    OPENFILENAME ofn;
    char szFilename[512] = "";
    static char szFilter1[] = "Programs (*.EXE)\0*.EXE\0";

    memset(&ofn, 0, sizeof(OPENFILENAME));

    ofn.lStructSize = sizeof(OPENFILENAME);
    ofn.hwndOwner = hWndDlg;
    ofn.lpstrFilter = szFilter1;
    ofn.nFilterIndex = 1;
    ofn.lpstrFile = szFilename;
    ofn.nMaxFile = sizeof(szFilename);
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

    if ( GetOpenFileName(&ofn) )
        SetDlgItemText( hWndDlg, IDC_EDIT_CMDLINE, szFilename );
}

void lbprintf(HWND hWnd, char * format, ...)
{
    char szBuffer[4096];
    va_list argptr;

    va_start(argptr, format);
    wvsprintf(szBuffer, format, argptr);
    va_end(argptr);

    SendMessage( hWnd, LB_ADDSTRING, 0, (LPARAM)szBuffer );
}

