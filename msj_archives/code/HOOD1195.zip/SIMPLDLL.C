#include "simpldll.h"

//SIMPLEDLLAPI int __stdcall FunctionInADLL(void)
int __stdcall FunctionInADLL(void)
{
	return 42;
}

