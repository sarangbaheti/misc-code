//
//  MODULE: UI.c
//
//  PURPOSE: Parsing Command line parameter and setting flags.
//
#include	<stdio.h>

#define TAPI_CURRENT_VERSION 0x00020000
#include	<tapi.h>

void ShowHelp();
BOOL ParseCommandLine(int ac, char * av[]);

extern BOOL	g_bIncoming;
extern BOOL	g_bForce;
extern BOOL	g_bTranslateDialog;
extern BOOL	g_bTranslate;
extern BOOL	g_bQuit;
extern DWORD	g_dwMediaMode;
extern BOOL	g_bTerminate;
extern DWORD	g_dwDevId;
extern CHAR	strAddress[];

BOOL ParseCommandLine(int ac, char * av[])
{
int i;
	g_dwMediaMode = 0;
	g_dwDevId = 0;
	g_bForce = FALSE;
	g_bTranslate = TRUE;
	g_bTranslateDialog = FALSE;
	lstrcpy(strAddress, "9, 206 515-6000");

	for(i = 1 ; i < ac ; ++i)
	{
		if(strstr(av[i], "/ANSWER") == av[i]) g_bIncoming = TRUE;
		if(strstr(av[i], "/NOTRANS") == av[i]) g_bTranslate = FALSE;
		if(strstr(av[i], "/DIALOG") == av[i]) g_bTranslateDialog = TRUE;
		if(strstr(av[i], "/FORCE:") == av[i]) 
			{
			g_bForce = TRUE;
			g_dwDevId = (DWORD)atoi(av[i]+7);
			}
		if(strstr(av[i], "/CALL:") == av[i]) 
		{
//			g_bTranslate = TRUE;
			strcpy(strAddress, av[i]+6);
		}
		if(strstr(av[i], "/UNKNOWN") == av[i]) g_dwMediaMode |= LINEMEDIAMODE_UNKNOWN;
		if(strstr(av[i], "/INTERACTIVEVOICE") == av[i]) g_dwMediaMode |= LINEMEDIAMODE_INTERACTIVEVOICE;
		if(strstr(av[i], "/AUTOMATEDVOICE") == av[i]) g_dwMediaMode |= LINEMEDIAMODE_AUTOMATEDVOICE;
		if(strstr(av[i], "/DATAMODEM") == av[i]) g_dwMediaMode |= LINEMEDIAMODE_DATAMODEM;
		if(strstr(av[i], "/G3FAX") == av[i]) g_dwMediaMode |= LINEMEDIAMODE_G3FAX;
		if(strstr(av[i], "/TDD") == av[i]) g_dwMediaMode |= LINEMEDIAMODE_TDD;
		if(strstr(av[i], "/G4FAX") == av[i]) g_dwMediaMode |= LINEMEDIAMODE_G4FAX;
		if(strstr(av[i], "/DIGITALDATA") == av[i]) g_dwMediaMode |= LINEMEDIAMODE_DIGITALDATA;
		if(strstr(av[i], "/TELETEX") == av[i]) g_dwMediaMode |= LINEMEDIAMODE_TELETEX;
		if(strstr(av[i], "/VIDEOTEX") == av[i]) g_dwMediaMode |= LINEMEDIAMODE_VIDEOTEX;
		if(strstr(av[i], "/TELEX") == av[i]) g_dwMediaMode |= LINEMEDIAMODE_TELEX;
		if(strstr(av[i], "/MIXED") == av[i]) g_dwMediaMode |= LINEMEDIAMODE_MIXED;
		if(strstr(av[i], "/ADSI") == av[i]) g_dwMediaMode |= LINEMEDIAMODE_ADSI;
		if(strstr(av[i], "/VOICEVIEW") == av[i]) g_dwMediaMode |= LINEMEDIAMODE_VOICEVIEW;
		if(strstr(av[i], "/?") == av[i])	ShowHelp();
	}
	if(g_dwMediaMode == 0) g_dwMediaMode = LINEMEDIAMODE_DATAMODEM;
	return TRUE;
}

void ShowHelp()
{
	printf("USAGE: SimpleTAPI <options>\r\n"); 
	printf("\r\nSupported Options\r\n");
	printf("/ANSWER				Answer mode.\r\n");
	printf("/NOTRANS			No translation.\r\n");
	printf("/FORCE:<Dev ID>		Force line device.\r\n");
	printf("/CALL:<Address>		Call an address.\r\n");
	printf("\r\n Supported Media Modes\r\n");
	printf("	/UNKNOWN\r\n");
	printf("	/INTERACTIVEVOICE\r\n");
	printf("	/AUTOMATEDVOICE\r\n");
	printf("	/DATAMODEM\r\n");
	printf("	/G3FAX\r\n");
	printf("	/TDD\r\n");
	printf("	/G4FAX\r\n");
	printf("	/DIGITALDATA\r\n");
	printf("	/TELETEX\r\n");
	printf("	/VIDEOTEX\r\n");
	printf("	/TELEX\r\n");
	printf("	/MIXED\r\n");
	printf("	/ADSI\r\n");
	printf("	/VOICEVIEW\r\n");
	ExitProcess(0);
}
