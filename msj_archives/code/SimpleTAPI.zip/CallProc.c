//
//  MODULE: CallProc.c
//
//  PURPOSE: Demonstrates basic TAPI programming model
//

#include	<stdio.h>
#define TAPI_CURRENT_VERSION 0x00020000
#include	<tapi.h>

#include "TapiInfo.h"

extern HLINEAPP	g_hLineApp;
extern CHAR	strAddress[512];
extern CHAR	strText[512], strText2[512];
extern BOOL bQuit_A;
extern BOOL g_bTerminate;
extern HANDLE g_hTAPI;
extern HANDLE g_hTAPIEvent;
extern HCALL g_hCall;

extern DWORD g_dwTAPIMsg;
extern HANDLE g_hEvReply;		// Used for Asynch Reply

DWORD WINAPI zTapiEventThread (LPVOID lpThreadParam)
{
LONG			lRes = 0;
LINECALLINFO	*lpCallInfo;

	while (TRUE)
	{
		DWORD dwStatus;
		if (g_bTerminate)
			{	// Someone told me I should kill myself...
			fprintf(stderr, "\nTerminating message thread...\r\n");
			return (0);
			}

		// Get a TAPI event if available, wait for 10ms just enough to give up quontum
		dwStatus = WaitForSingleObject(g_hTAPIEvent, 10);

		if (dwStatus == WAIT_OBJECT_0)
			{
			LINEMESSAGE lm;
			//TAPI's got something to tell us...
			if ((lRes = lineGetMessage(g_hLineApp, &lm, 0)) != 0)
				{
				FormatLineError(lRes, strText);
				printf("TAPI Error: %s on lineGetMessage.\r\n", strText);
				return(lRes);
				}

			FormatLineCallback(strText,
				(DWORD)lm.hDevice, lm.dwMessageID, lm.dwCallbackInstance, 
				lm.dwParam1, lm.dwParam2, lm.dwParam3);
			printf("TAPI Message: %s.\r\n", strText);

			// Process message
			switch (lm.dwMessageID)
				{
				case LINE_REPLY: // Sent after lineMakeCall or lineDrop
					{
					break;
					}

				case LINE_CALLSTATE:  // Sent after change of call state
					{
					switch (lm.dwParam1)
						{
						case LINECALLSTATE_OFFERING:	//Incoming call is offering.
							{
							//  Get the call handle
							g_hCall = (HCALL)lm.hDevice;
							printf("Signaling Event. \r\n");
							g_dwTAPIMsg = LINECALLSTATE_OFFERING;
							SetEvent(g_hEvReply);
							break;
							}
						case LINECALLSTATE_IDLE:
							{
							printf("Droping call.\r\n");
							lineDrop(g_hCall, NULL, 0);
							g_hCall = NULL;
							printf("Terminating event thread.\r\n");
							return 0;
							break;
							}
						case LINECALLSTATE_CONNECTED:
							{
							if(lm.dwCallbackInstance == 1)
								{
								g_dwTAPIMsg = LINECALLSTATE_CONNECTED;
								SetEvent(g_hEvReply);
								}
							break;
							}
						case LINECALLSTATE_DISCONNECTED:
							{
							// We got disconnected, so drop the call
							lineDrop((HCALL) lm.hDevice, NULL, 0);
							break;
							}
						default:
							break;
						}
					break;
					}
				case LINE_CALLINFO: //  Call Info is available
					{
					if(lm.dwParam1 == LINECALLINFOSTATE_CALLID)
						{  //Caller ID became available.
						lpCallInfo = (LINECALLINFO *)malloc(sizeof(LINECALLINFO)+1000);
						memset(lpCallInfo, 0, sizeof(LINECALLINFO)+1000);
						lpCallInfo->dwTotalSize = sizeof(LINECALLINFO)+1000;
						while (1)
							{
							lineGetCallInfo(g_hCall, lpCallInfo);
							if (lpCallInfo->dwTotalSize < lpCallInfo->dwNeededSize)
								lpCallInfo = (LINECALLINFO *)realloc(lpCallInfo, lpCallInfo->dwNeededSize);
							else break;
							} 
						printf("Caller is %s : %s\r\n", 
							(LPSTR)((DWORD)lpCallInfo+(DWORD)lpCallInfo->dwCallerIDOffset), 
							(LPSTR)((DWORD)lpCallInfo+(DWORD)lpCallInfo->dwCallerIDNameOffset));
						}
					break;
					}

				default:
					break;
				}
			}
		else if (dwStatus == WAIT_TIMEOUT)
			{	//  WaitForSingleObject timed out.  So go back and wait again!
			continue;
			}
		else
			{	//	Something else strange happened!!
			return(GetLastError());
			}
		}
	return (lRes);
} 

