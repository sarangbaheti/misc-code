#ifdef _MDIAPP
#define CBaseFrameWnd CMDIFrameWnd
#else
#define CBaseFrameWnd CFrameWnd
#endif

class CMainFrame : public CBaseFrameWnd {
public:
	CMainFrame();
	virtual ~CMainFrame();
protected:
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
	DECLARE_DYNCREATE(CMainFrame)

	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnFoo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
