////////////////////////////////////////////////////////////////
// MyEdit 1999 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// MyEdit is a simple text editor that illustrates how to maintain
// multiple recent file lists. See MruMgr[.h,.cpp]
// Compiles with VC++ 6.0 or later

#include "StdAfx.h"
#include "MyEdit.h"
#include "MainFrm.h"
#include "View.h"
#include "TraceWin.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const NMAXMRU = 8;

BEGIN_MESSAGE_MAP(CMyApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

// Don't complaing of "this" ptr passed to member object constructor
#pragma warning(disable: 4355)

CMyApp::CMyApp() : m_mruFileMgr(this) // <=== warning 4355
{
}

CMyApp theApp;

//////////////////
// Test if filename ends with suffix
//
static BOOL CompareFilenameSuffix(LPCTSTR lpszPathName, LPCTSTR lpszSuffix)
{
	int len = strlen(lpszPathName);
	int suflen = strlen(lpszSuffix);
	return (suflen>0 && len>suflen &&
		strcmpi(&lpszPathName[len-suflen], lpszSuffix)==0);	
}

/////////////////
// Test for .h file
//
static BOOL CALLBACK HFileFunc(LPCTSTR lpszPathName)
{
	return CompareFilenameSuffix(lpszPathName, _T(".h"));
}

//////////////////
// Test for .cpp file
//
static BOOL CALLBACK CFileFunc(LPCTSTR lpszPathName)
{
	return CompareFilenameSuffix(lpszPathName, _T(".cpp"));
}

BOOL CMyApp::InitInstance()
{
	SetRegistryKey("MSJ");				// Save settings in registry, not INI file
	LoadStdProfileSettings(NMAXMRU); // Load INI file options (including MRU)

	// Add recent file category for .cpp files
	m_mruFileMgr.Add(ID_MY_RECENT_CFILE1,	// base command ID
		_T("Recent .cpp Files"),				// szSection = registry key name 
		_T("File%d"),								// szFileEntry = registry value name
		CFileFunc,									// test for .h file
		NMAXMRU);									// max number list/menu entries

	// Add recent file category for .h files
	m_mruFileMgr.Add(ID_MY_RECENT_HFILE1,	// base command ID
		_T("Recent .h Files"),					// szSection = registry key name 
		_T("File%d"),								// szFileEntry = registry value name
		HFileFunc,									// test for .h file
		NMAXMRU);									// max number list/menu entries

#ifdef _MDIAPP
	AddDocTemplate(new CMultiDocTemplate(IDR_MYDOCTYPE,
		RUNTIME_CLASS(CMyDoc),
		RUNTIME_CLASS(CMDIChildWnd),
		RUNTIME_CLASS(CMyView)));
#else
	AddDocTemplate(new CSingleDocTemplate(IDR_MAINFRAME,
		RUNTIME_CLASS(CMyDoc),
		RUNTIME_CLASS(CMainFrame),
		RUNTIME_CLASS(CMyView)));
#endif
	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

#ifdef _MDIAPP
	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The main window has been initialized, so show and update it.
	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();

#else // SDI app
	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;
#endif
	return TRUE;
}

/////////////////
// Override message routing to pass to MRU file manager
//
BOOL CMyApp::OnCmdMsg(UINT nID, int nCode, void* pExtra,
	AFX_CMDHANDLERINFO* pHandlerInfo)
{
	if (m_mruFileMgr.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;
	return CWinApp::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

//////////////////
// When adding file to recent file list, let MRU manager have 1st
// crack, otherwise do default thing
//
void CMyApp::AddToRecentFileList(LPCTSTR lpszPathName)
{
	if (m_mruFileMgr.AddToRecentFileList(lpszPathName))
		return;

	// Only call if you want standard MFC recent file list too
	CWinApp::AddToRecentFileList(lpszPathName);
}

#include "StatLink.h"

//////////////////
// Custom dialog uses CStaticLink for hyperlinks.
// Same dialog class works for both applets (resource ID determines dialog)
//
class CAboutDialog : public CDialog {
protected:
	CStaticLink	m_wndLink1;
	CStaticLink	m_wndLink2;
	virtual BOOL OnInitDialog() {
		// subclass static controls. URL is static text or 3rd arg
		m_wndLink1.SubclassDlgItem(IDC_MSJURL, this,
			_T("http://www.microsoft.com/msj"));
		m_wndLink2.SubclassDlgItem(IDC_PDURL,  this,
			_T("http://pobox.com/~askpd"));
		return CDialog::OnInitDialog();
	}
public:
	CAboutDialog() : CDialog(IDD_ABOUTBOX, NULL) { }
};

void CMyApp::OnAppAbout()
{
	static CAboutDialog dlg; // static to remember state of hyperlinks
	dlg.DoModal();				 // run it
}
