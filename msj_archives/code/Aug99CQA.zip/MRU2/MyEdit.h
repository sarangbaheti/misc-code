////////////////////////////////////////////////////////////////
// EDIT 1999 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// See MyEdit.cpp
// 
#include "resource.h"       // main symbols
#include "MruMgr.h"

#ifdef _MDIAPP
#define IDR_MAINFRAME IDR_MAINFRAMEMDI
#else
#define IDR_MAINFRAME IDR_MAINFRAMESDI
#endif

class CMyApp : public CWinApp {
public:
	CMyApp();
	virtual BOOL InitInstance();
protected:
	CMruFileManager m_mruFileMgr;
	afx_msg void OnAppAbout();

	virtual void AddToRecentFileList(LPCTSTR lpszPathName);  // add to MRU
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra,
		AFX_CMDHANDLERINFO* pHandlerInfo);

	DECLARE_MESSAGE_MAP()
};
