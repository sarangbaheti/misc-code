//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MyEdit.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAMESDI                128
#define IDR_MAINFRAMEMDI                129
#define IDR_MYDOCTYPE                   130
#define ID_MY_RECENT_HFILE1             131
#define ID_MY_RECENT_HFILE2             132
#define ID_MY_RECENT_HFILE3             133
#define ID_MY_RECENT_HFILE4             134
#define ID_MY_RECENT_HFILE5             135
#define ID_MY_RECENT_HFILE6             136
#define ID_MY_RECENT_HFILE7             137
#define ID_MY_RECENT_HFILE8             138
#define ID_MY_RECENT_CFILE1             141
#define ID_MY_RECENT_CFILE2             142
#define ID_MY_RECENT_CFILE3             143
#define ID_MY_RECENT_CFILE4             144
#define ID_MY_RECENT_CFILE5             145
#define ID_MY_RECENT_CFILE6             146
#define ID_MY_RECENT_CFILE7             147
#define ID_MY_RECENT_CFILE8             148
#define IDC_MSJURL                      1000
#define IDC_PDURL                       1001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        149
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
