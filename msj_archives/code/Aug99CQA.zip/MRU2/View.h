#include "Doc.h"

class CMyView : public CEditView {
public:
	virtual ~CMyView();
	CMyDoc* GetDocument() { return (CMyDoc*)m_pDocument; }
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
protected:
	DECLARE_DYNCREATE(CMyView)
	CMyView();
	DECLARE_MESSAGE_MAP()
};
