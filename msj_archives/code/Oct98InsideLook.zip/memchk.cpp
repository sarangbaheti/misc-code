#include <stdlib.h>
#include <memory.h>
#include <time.h>
#include <iostream>

using namespace std;

// Purpose: Exercises small block heap
//
// Command line options: None
//
// Release Build switches: 
// /nologo /ML /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "_MBCS" /Fo"Release/" /Fd"Release/" /FD /c 

#define	MAXALLOC	64000
#define MAXBLOCK	1020

char * cp[MAXALLOC];	// 64000 * 1020 =~ 64K;

void churn1()
{ 
	unsigned i, n;
	unsigned sbSize;

	for (n = 5; n > 1; n--)
	{
		cout << "churn1: main loop " << n << endl;

		// free a bunch of memory
		for (i = 0; i < MAXALLOC; i+=(n+1))
		{
			free(cp[i]);
			cp[i] = NULL;
		}
		cout << "churn1: loop 1, i = " << i << endl;

		sbSize = MAXBLOCK/n;
		for (i = 0; i < MAXALLOC; i++)
		{
			if (cp[i] == NULL && i % 2) 
			{
				cp[i] = (char *)malloc(sizeof(char) * sbSize);
				if (cp[i] == NULL)
					cout << "churn1: memory allocation failure in loop 2." << endl;
			}
		}
		cout << "churn1: loop 2, i = " << i << endl;

		sbSize /= 3;
		for (i = 0; i < MAXALLOC; i++)
		{
			if (cp[i] == NULL)
			{
				cp[i] = (char *)malloc(sizeof(char) * sbSize);
				if (cp[i] == NULL)
					cout << "churn1: memory allocation failure in loop 3." << endl;
			}
		}
		cout << "churn1: loop 3, i = " << i << endl;

	}
} 


void churn2()
{
	unsigned i, n;
	unsigned sbSize;

	for (n = 1; n < 5; n++)
	{
		cout << "churn2: main loop " << n << endl;

		// free a bunch of memory
		for (i = 0; i < MAXALLOC; i+=(n+1))
		{
			free(cp[i]);
			cp[i] = NULL;
		}
		cout << "churn2: loop 1, i = " << i << endl;

		for (i = 0, sbSize = 20; i < MAXALLOC && sbSize < MAXBLOCK; i++, sbSize += 5)
		{
			if (cp[i] == NULL)
			{
				cp[i] = (char *)malloc(sizeof(char) * sbSize);
				if (cp[i] == NULL)
					cout << "churn2: memory allocation failure in loop 2." << endl;
			}
		}
		cout << "churn2: loop 2, i = " << i << endl;

		for (i = 0; i < MAXALLOC ; i+=(n+2))
		{
			free(cp[i]);
			cp[i] = NULL;
		}
		cout << "churn2: loop 3, i = " << i << endl;
	
		sbSize = MAXBLOCK/2;
		for (i = 0; i < MAXALLOC; i++)
		{
			if (cp[i] == NULL)
			{
				cp[i] = (char *)malloc(sizeof(char) * sbSize);
				if (cp[i] == NULL)
					cout << "churn2: memory allocation failure in loop 4." << endl;
			}
		}
		cout << "churn2: loop 4, i = " << i << endl;
	}
}


void main(int argc, char **argv)
{
	time_t start, stop;

	time(&start);

	for (unsigned i = 0; i < MAXALLOC; i++)
		cp[i] = (char *)malloc(sizeof(char) * 100);

	churn1();
	churn2();
	churn1();

	time(&stop);

	cout << "Elapsed time = " << stop - start << " seconds." << endl;
}