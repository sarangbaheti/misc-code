/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 3.01.75 */
/* at Mon Apr 13 19:04:21 1998
 */
/* Compiler settings for HttpObjectServer.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IHttpRequest = {0x10BE7FE8,0x9CC7,0x11D1,{0x99,0x12,0x00,0x40,0x33,0xD0,0x6B,0x6E}};


const IID LIBID_HTTPOBJECTSERVERLib = {0x10BE7FDB,0x9CC7,0x11D1,{0x99,0x12,0x00,0x40,0x33,0xD0,0x6B,0x6E}};


const CLSID CLSID_HttpRequest = {0x10BE7FE9,0x9CC7,0x11D1,{0x99,0x12,0x00,0x40,0x33,0xD0,0x6B,0x6E}};


#ifdef __cplusplus
}
#endif

