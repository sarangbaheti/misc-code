// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//
// HttpRequest.h : Declaration of the CHttpRequest
//

#ifndef __HTTPREQUEST_H_
#define __HTTPREQUEST_H_

#include "resource.h"       // main symbols
#include "..\QuoteProviders\QuoteProviders.h"

/////////////////////////////////////////////////////////////////////////////
// CHttpRequest
class ATL_NO_VTABLE CHttpRequest : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CHttpRequest, &CLSID_HttpRequest>,
	public IHttpRequest
{
public:
	CHttpRequest()
	{
		m_pQuoteProvider = NULL;
	}
	~CHttpRequest()
	{
		//release the IQuoteProvider interface
		if (m_pQuoteProvider)
			m_pQuoteProvider->Release();
	}

	//pointer to current quote provider interface
	IQuoteProvider* m_pQuoteProvider;

	//main application HWND
	HWND m_hwndMain;

DECLARE_REGISTRY_RESOURCEID(IDR_HTTPREQUEST)

BEGIN_COM_MAP(CHttpRequest)
	COM_INTERFACE_ENTRY(IHttpRequest)
END_COM_MAP()

// IHttpRequest
public:
	STDMETHOD(GetProviderInterface)(IUnknown** ppUnk);
	STDMETHOD(ProcessRequest)(IUnknown* pQuoteProvider, long lMainHwnd);
};


#endif //__HTTPREQUEST_H_

