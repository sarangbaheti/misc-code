
//////////////////////////////////////////////////////////////////////////////
// CProxyIHttpEvent
template <class T>
class CProxyIHttpEvent : public IConnectionPointImpl<T, &IID_IHttpEvent, CComDynamicUnkArray>
{
public:

//IHttpEvent : IUnknown
public:
	HRESULT Fire_FireHttpEvent(
		long nID)
	{
		T* pT = (T*)this;
		pT->Lock();
		HRESULT ret;
		IUnknown** pp = m_vec.begin();
		while (pp < m_vec.end())
		{
			if (*pp != NULL)
			{
				IHttpEvent* pIHttpEvent = reinterpret_cast<IHttpEvent*>(*pp);
				ret = pIHttpEvent->FireHttpEvent(nID);
			}
			pp++;
		}
		pT->Unlock();
		return ret;
	}
};

