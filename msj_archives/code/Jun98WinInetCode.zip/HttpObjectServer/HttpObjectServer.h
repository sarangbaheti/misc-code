/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 3.01.75 */
/* at Mon Apr 13 19:04:21 1998
 */
/* Compiler settings for HttpObjectServer.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#include "rpc.h"
#include "rpcndr.h"
#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __HttpObjectServer_h__
#define __HttpObjectServer_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IHttpRequest_FWD_DEFINED__
#define __IHttpRequest_FWD_DEFINED__
typedef interface IHttpRequest IHttpRequest;
#endif 	/* __IHttpRequest_FWD_DEFINED__ */


#ifndef __HttpRequest_FWD_DEFINED__
#define __HttpRequest_FWD_DEFINED__

#ifdef __cplusplus
typedef class HttpRequest HttpRequest;
#else
typedef struct HttpRequest HttpRequest;
#endif /* __cplusplus */

#endif 	/* __HttpRequest_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IHttpRequest_INTERFACE_DEFINED__
#define __IHttpRequest_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: IHttpRequest
 * at Mon Apr 13 19:04:21 1998
 * using MIDL 3.01.75
 ****************************************/
/* [object][unique][helpstring][uuid] */ 



EXTERN_C const IID IID_IHttpRequest;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("10BE7FE8-9CC7-11D1-9912-004033D06B6E")
    IHttpRequest : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE ProcessRequest( 
            IUnknown __RPC_FAR *pQuoteProvider,
            long lMainHwnd) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE GetProviderInterface( 
            IUnknown __RPC_FAR *__RPC_FAR *ppUnk) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IHttpRequestVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IHttpRequest __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IHttpRequest __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IHttpRequest __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ProcessRequest )( 
            IHttpRequest __RPC_FAR * This,
            IUnknown __RPC_FAR *pQuoteProvider,
            long lMainHwnd);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetProviderInterface )( 
            IHttpRequest __RPC_FAR * This,
            IUnknown __RPC_FAR *__RPC_FAR *ppUnk);
        
        END_INTERFACE
    } IHttpRequestVtbl;

    interface IHttpRequest
    {
        CONST_VTBL struct IHttpRequestVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHttpRequest_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IHttpRequest_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IHttpRequest_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IHttpRequest_ProcessRequest(This,pQuoteProvider,lMainHwnd)	\
    (This)->lpVtbl -> ProcessRequest(This,pQuoteProvider,lMainHwnd)

#define IHttpRequest_GetProviderInterface(This,ppUnk)	\
    (This)->lpVtbl -> GetProviderInterface(This,ppUnk)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE IHttpRequest_ProcessRequest_Proxy( 
    IHttpRequest __RPC_FAR * This,
    IUnknown __RPC_FAR *pQuoteProvider,
    long lMainHwnd);


void __RPC_STUB IHttpRequest_ProcessRequest_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IHttpRequest_GetProviderInterface_Proxy( 
    IHttpRequest __RPC_FAR * This,
    IUnknown __RPC_FAR *__RPC_FAR *ppUnk);


void __RPC_STUB IHttpRequest_GetProviderInterface_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IHttpRequest_INTERFACE_DEFINED__ */



#ifndef __HTTPOBJECTSERVERLib_LIBRARY_DEFINED__
#define __HTTPOBJECTSERVERLib_LIBRARY_DEFINED__

/****************************************
 * Generated header for library: HTTPOBJECTSERVERLib
 * at Mon Apr 13 19:04:21 1998
 * using MIDL 3.01.75
 ****************************************/
/* [helpstring][version][uuid] */ 



EXTERN_C const IID LIBID_HTTPOBJECTSERVERLib;

#ifdef __cplusplus
EXTERN_C const CLSID CLSID_HttpRequest;

class DECLSPEC_UUID("10BE7FE9-9CC7-11D1-9912-004033D06B6E")
HttpRequest;
#endif
#endif /* __HTTPOBJECTSERVERLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
