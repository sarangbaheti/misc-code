// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//
// HttpRequest.cpp : Implementation of CHttpRequest
//

#include "stdafx.h"
#include "HttpObjectServer.h"
#include "HttpRequest.h"
#include "MyInternetSession.h"
#include "LoginDlg.h"
#include "profile.h"
#include "..\QuoteProviders\QuoteProviders.h"
#include "..\Stock Watcher\globals.h"

#define HTTPFILE_BUFFLEN	4096
#define BUFFLEN 			255

extern CRITICAL_SECTION g_CS;

UINT HttpWorkerThread(LPVOID lpVoid);

/////////////////////////////////////////////////////////////////////////////
// CMyInternetSession

void CMyInternetSession::OnStatusCallback(DWORD dwContext, DWORD dwInternetStatus, LPVOID lpvStatusInformation, DWORD dwStatusInformationLength )
{
	if (m_pRequest)
	{
		if (m_pRequest->m_hwndMain)
			::PostMessage(m_pRequest->m_hwndMain, WM_HTTP_THREAD_MESSAGE, UPDATE_STATUS, dwInternetStatus);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CHttpRequest

STDMETHODIMP CHttpRequest::ProcessRequest(IUnknown* pQuoteProvider, long lMainHwnd)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	m_pQuoteProvider = static_cast<IQuoteProvider*>(pQuoteProvider);
	m_pQuoteProvider->AddRef();
	m_hwndMain = reinterpret_cast<HWND>(lMainHwnd);
	AfxBeginThread(HttpWorkerThread, this);
	return S_OK;
}

STDMETHODIMP CHttpRequest::GetProviderInterface(IUnknown * * ppUnk)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	*ppUnk = m_pQuoteProvider;
	return S_OK;
}

/////////////////////////////////////////////////////////////////////////////
// HttpWorkerThread

UINT HttpWorkerThread(LPVOID lpVoid)
{
	CHttpRequest* pRequest = reinterpret_cast<CHttpRequest*>(lpVoid);
	IQuoteProvider* pProvider = pRequest->m_pQuoteProvider;
	CHttpConnection* pHttpConnection = NULL;
	CHttpFile* pHttpFile = NULL;
	LPVOID lpvoid = NULL;
	char lpszHost[BUFFLEN], lpszUserName[BUFFLEN], lpszPassword[BUFFLEN], lpszMethod[BUFFLEN];
	char lpszURL[BUFFLEN], lpszAcceptTypes[BUFFLEN], lpszHttpVersion[BUFFLEN], lpszHeaders[BUFFLEN];
	char lpszData[BUFFLEN];
	DWORD dwFlags;
	LPCTSTR pstrAcceptTypes[2];
	INTERNET_PORT nPort;
	BOOL bResult;

	//declare CMyInternetSession object
	CMyInternetSession InternetSession(NULL, 1, INTERNET_OPEN_TYPE_PRECONFIG);

	try
	{
		//enable the status callback
		InternetSession.EnableStatusCallback(TRUE);
		InternetSession.m_pRequest = pRequest;
	
		//get connection information
		pProvider->GetHost(lpszHost, BUFFLEN);
		pProvider->GetPort(&nPort);
		pProvider->LoginIsRequired(&bResult);
		if (bResult)
		{
			CString strUserName = GetMyProfileString("Settings", "username", "");
			CString strPassword = GetMyProfileString("Settings", "password", "");
			if (strUserName.IsEmpty() || strPassword.IsEmpty())
			{
				// get user name & password information
				CLoginDlg dlg;
				if (IDCANCEL == dlg.DoModal())
					return 0;
				WriteMyProfileString("Settings", "username", dlg.m_strUserName);
				WriteMyProfileString("Settings", "password", dlg.m_strPassword);
				strcpy(lpszUserName, dlg.m_strUserName);
				strcpy(lpszPassword, dlg.m_strPassword);
			}
			else
			{
				strcpy(lpszUserName, strUserName);
				strcpy(lpszPassword, strPassword);
			}
		}

		//establish the HTTP connection
		pHttpConnection = InternetSession.GetHttpConnection( lpszHost, nPort, lpszUserName, lpszPassword);

		//get request specific information
		pProvider->GetMethod(lpszMethod, BUFFLEN);
		pProvider->GetURL(lpszURL, BUFFLEN);
		pProvider->GetAcceptTypes(lpszAcceptTypes, BUFFLEN);
		pstrAcceptTypes[0] = lpszAcceptTypes;
		pstrAcceptTypes[1] = NULL;
		pProvider->GetHttpVersion(lpszHttpVersion, BUFFLEN);
		pProvider->GetFlags(&dwFlags);	

		//open the HTTP request
		pHttpFile = pHttpConnection->OpenRequest(lpszMethod, lpszURL, "", 1, pstrAcceptTypes, lpszHttpVersion, dwFlags);

		//get the request data
		pProvider->GetHeaders(lpszHeaders, BUFFLEN);
		pProvider->GetData(lpszData, BUFFLEN);

		if (pHttpFile->SendRequest(lpszHeaders, strlen(lpszHeaders), static_cast<void*>(lpszData), strlen(lpszData)))
		{
			DWORD dwRet;
			//query the HTTP status code
			pHttpFile->QueryInfoStatusCode(dwRet);

			//authentication techniques
			while (dwRet == HTTP_STATUS_DENIED)
			{
				CLoginDlg dlg;
				dlg.m_strUserName = GetMyProfileString("Settings", "username", "");
				dlg.m_strPassword = GetMyProfileString("Settings", "password", "");
				if (IDCANCEL == dlg.DoModal())
				{
					if (pHttpConnection)
					{
						pHttpConnection->Close();
						delete pHttpConnection;
					}
					if (pHttpFile)
					{
						pHttpFile->Close();
						delete pHttpFile;
					}
					return 0;
				}
				WriteMyProfileString("Settings", "username", dlg.m_strUserName);
				WriteMyProfileString("Settings", "password", dlg.m_strPassword);
				strcpy(lpszUserName, dlg.m_strUserName);
				strcpy(lpszPassword, dlg.m_strPassword);
				InternetSetOption((HINTERNET)(*pHttpFile), INTERNET_OPTION_USERNAME, 
								  lpszUserName, strlen(lpszUserName));
				InternetSetOption((HINTERNET)(*pHttpFile), INTERNET_OPTION_PASSWORD, 
								  lpszPassword, strlen(lpszPassword));	
				pHttpFile->SendRequest(lpszHeaders, strlen(lpszHeaders), static_cast<void*>(lpszData), strlen(lpszData));
				pHttpFile->QueryInfoStatusCode(dwRet);
			}
			
			if (dwRet == HTTP_STATUS_OK)
			{
				CString strContentLen;
				LPSTR lpszResult=NULL;
				UINT nRead=0, nTotalRead=0;

				lpvoid = malloc(HTTPFILE_BUFFLEN);
				//memory error
				if (!lpvoid)
					return 0;

				//read the HTTP response
				nRead = pHttpFile->Read(lpvoid, HTTPFILE_BUFFLEN);

				nTotalRead += nRead;
				while (nRead == HTTPFILE_BUFFLEN)
				{
					lpvoid = realloc(lpvoid, nTotalRead+HTTPFILE_BUFFLEN);
					nRead = pHttpFile->Read((byte*)lpvoid+nTotalRead, HTTPFILE_BUFFLEN);
					nTotalRead += nRead;
				}

				lpszResult = (LPSTR)lpvoid;
				*(lpszResult + nTotalRead) = NULL;
				
				CFile f1;
				if( f1.Open( "c:\\temp\\sw.html", CFile::modeCreate | CFile::modeWrite ) ) 
				{				
					f1.Write(lpszResult, strlen(lpszResult));
					f1.Close();
				}
					
				//parse the HTTP response
				EnterCriticalSection(&g_CS);
				HRESULT hr = pProvider->ParseResult(lpszResult);
				if (FAILED(hr))
					::MessageBox(pRequest->m_hwndMain, "Error parsing quote format", "ParseResult Error", MB_ICONEXCLAMATION | MB_OK);
				LeaveCriticalSection(&g_CS);

				//notify the main application window
				if (pRequest->m_hwndMain)
					::PostMessage(pRequest->m_hwndMain, WM_HTTP_THREAD_MESSAGE, UPDATE_ALL_VIEWS, 0);
				
			}
		}
	}
	catch(CInternetException *e)
	{
		e->ReportError();
		e->Delete();
	}

	// cleanup
	if (lpvoid)
		free(lpvoid);

	if (pHttpFile)
	{
		pHttpFile->Close();
		delete pHttpFile;
	}
	if (pHttpConnection)
	{
		pHttpConnection->Close();
		delete pHttpConnection;
	}
	return 0;
}

