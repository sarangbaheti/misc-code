#ifndef __PROFILE_H__
#define __PROFILE_H__

void WriteMyProfileString(LPCSTR lpSection,LPCSTR lpEntry,LPCSTR lpValue);
CString GetMyProfileString(LPCSTR lpSection,LPCSTR lpEntry,LPCSTR lpDefault);

#endif