/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 3.01.75 */
/* at Mon Apr 13 19:03:57 1998
 */
/* Compiler settings for QuoteProviders.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#include "rpc.h"
#include "rpcndr.h"
#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __QuoteProviders_h__
#define __QuoteProviders_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IQuoteProvider_FWD_DEFINED__
#define __IQuoteProvider_FWD_DEFINED__
typedef interface IQuoteProvider IQuoteProvider;
#endif 	/* __IQuoteProvider_FWD_DEFINED__ */


#ifndef __IQuoteProviderEvent_FWD_DEFINED__
#define __IQuoteProviderEvent_FWD_DEFINED__
typedef interface IQuoteProviderEvent IQuoteProviderEvent;
#endif 	/* __IQuoteProviderEvent_FWD_DEFINED__ */


#ifndef __ProviderYahoo_FWD_DEFINED__
#define __ProviderYahoo_FWD_DEFINED__

#ifdef __cplusplus
typedef class ProviderYahoo ProviderYahoo;
#else
typedef struct ProviderYahoo ProviderYahoo;
#endif /* __cplusplus */

#endif 	/* __ProviderYahoo_FWD_DEFINED__ */


#ifndef __ProviderFastQuote_FWD_DEFINED__
#define __ProviderFastQuote_FWD_DEFINED__

#ifdef __cplusplus
typedef class ProviderFastQuote ProviderFastQuote;
#else
typedef struct ProviderFastQuote ProviderFastQuote;
#endif /* __cplusplus */

#endif 	/* __ProviderFastQuote_FWD_DEFINED__ */


#ifndef __ProviderDatek_FWD_DEFINED__
#define __ProviderDatek_FWD_DEFINED__

#ifdef __cplusplus
typedef class ProviderDatek ProviderDatek;
#else
typedef struct ProviderDatek ProviderDatek;
#endif /* __cplusplus */

#endif 	/* __ProviderDatek_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IQuoteProvider_INTERFACE_DEFINED__
#define __IQuoteProvider_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: IQuoteProvider
 * at Mon Apr 13 19:03:57 1998
 * using MIDL 3.01.75
 ****************************************/
/* [object][unique][helpstring][uuid] */ 



EXTERN_C const IID IID_IQuoteProvider;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("F02EAD3F-9F0C-11D1-B2B2-006008ACADF7")
    IQuoteProvider : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE GetHost( 
            LPSTR lpszHost,
            DWORD dwLen) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE GetPort( 
            USHORT __RPC_FAR *pnPort) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE LoginIsRequired( 
            BOOL __RPC_FAR *pbResult) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE GetMethod( 
            LPSTR lpszMethod,
            DWORD dwLen) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE GetURL( 
            LPSTR lpszURL,
            DWORD dwLen) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE GetAcceptTypes( 
            LPSTR lpszAcceptTypes,
            DWORD dwLen) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE GetHttpVersion( 
            LPSTR lpszHttpVersion,
            DWORD dwLen) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE GetFlags( 
            DWORD __RPC_FAR *pdwFlags) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE GetHeaders( 
            LPSTR lpszHeaders,
            DWORD dwLen) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE GetData( 
            LPSTR lpszData,
            DWORD dwLen) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE ParseResult( 
            LPSTR lpszResult) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE InitializeData( 
            LPSTR lpszData) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IQuoteProviderVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IQuoteProvider __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IQuoteProvider __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IQuoteProvider __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetHost )( 
            IQuoteProvider __RPC_FAR * This,
            LPSTR lpszHost,
            DWORD dwLen);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetPort )( 
            IQuoteProvider __RPC_FAR * This,
            USHORT __RPC_FAR *pnPort);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LoginIsRequired )( 
            IQuoteProvider __RPC_FAR * This,
            BOOL __RPC_FAR *pbResult);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetMethod )( 
            IQuoteProvider __RPC_FAR * This,
            LPSTR lpszMethod,
            DWORD dwLen);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetURL )( 
            IQuoteProvider __RPC_FAR * This,
            LPSTR lpszURL,
            DWORD dwLen);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetAcceptTypes )( 
            IQuoteProvider __RPC_FAR * This,
            LPSTR lpszAcceptTypes,
            DWORD dwLen);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetHttpVersion )( 
            IQuoteProvider __RPC_FAR * This,
            LPSTR lpszHttpVersion,
            DWORD dwLen);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetFlags )( 
            IQuoteProvider __RPC_FAR * This,
            DWORD __RPC_FAR *pdwFlags);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetHeaders )( 
            IQuoteProvider __RPC_FAR * This,
            LPSTR lpszHeaders,
            DWORD dwLen);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetData )( 
            IQuoteProvider __RPC_FAR * This,
            LPSTR lpszData,
            DWORD dwLen);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ParseResult )( 
            IQuoteProvider __RPC_FAR * This,
            LPSTR lpszResult);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *InitializeData )( 
            IQuoteProvider __RPC_FAR * This,
            LPSTR lpszData);
        
        END_INTERFACE
    } IQuoteProviderVtbl;

    interface IQuoteProvider
    {
        CONST_VTBL struct IQuoteProviderVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IQuoteProvider_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IQuoteProvider_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IQuoteProvider_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IQuoteProvider_GetHost(This,lpszHost,dwLen)	\
    (This)->lpVtbl -> GetHost(This,lpszHost,dwLen)

#define IQuoteProvider_GetPort(This,pnPort)	\
    (This)->lpVtbl -> GetPort(This,pnPort)

#define IQuoteProvider_LoginIsRequired(This,pbResult)	\
    (This)->lpVtbl -> LoginIsRequired(This,pbResult)

#define IQuoteProvider_GetMethod(This,lpszMethod,dwLen)	\
    (This)->lpVtbl -> GetMethod(This,lpszMethod,dwLen)

#define IQuoteProvider_GetURL(This,lpszURL,dwLen)	\
    (This)->lpVtbl -> GetURL(This,lpszURL,dwLen)

#define IQuoteProvider_GetAcceptTypes(This,lpszAcceptTypes,dwLen)	\
    (This)->lpVtbl -> GetAcceptTypes(This,lpszAcceptTypes,dwLen)

#define IQuoteProvider_GetHttpVersion(This,lpszHttpVersion,dwLen)	\
    (This)->lpVtbl -> GetHttpVersion(This,lpszHttpVersion,dwLen)

#define IQuoteProvider_GetFlags(This,pdwFlags)	\
    (This)->lpVtbl -> GetFlags(This,pdwFlags)

#define IQuoteProvider_GetHeaders(This,lpszHeaders,dwLen)	\
    (This)->lpVtbl -> GetHeaders(This,lpszHeaders,dwLen)

#define IQuoteProvider_GetData(This,lpszData,dwLen)	\
    (This)->lpVtbl -> GetData(This,lpszData,dwLen)

#define IQuoteProvider_ParseResult(This,lpszResult)	\
    (This)->lpVtbl -> ParseResult(This,lpszResult)

#define IQuoteProvider_InitializeData(This,lpszData)	\
    (This)->lpVtbl -> InitializeData(This,lpszData)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE IQuoteProvider_GetHost_Proxy( 
    IQuoteProvider __RPC_FAR * This,
    LPSTR lpszHost,
    DWORD dwLen);


void __RPC_STUB IQuoteProvider_GetHost_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IQuoteProvider_GetPort_Proxy( 
    IQuoteProvider __RPC_FAR * This,
    USHORT __RPC_FAR *pnPort);


void __RPC_STUB IQuoteProvider_GetPort_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IQuoteProvider_LoginIsRequired_Proxy( 
    IQuoteProvider __RPC_FAR * This,
    BOOL __RPC_FAR *pbResult);


void __RPC_STUB IQuoteProvider_LoginIsRequired_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IQuoteProvider_GetMethod_Proxy( 
    IQuoteProvider __RPC_FAR * This,
    LPSTR lpszMethod,
    DWORD dwLen);


void __RPC_STUB IQuoteProvider_GetMethod_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IQuoteProvider_GetURL_Proxy( 
    IQuoteProvider __RPC_FAR * This,
    LPSTR lpszURL,
    DWORD dwLen);


void __RPC_STUB IQuoteProvider_GetURL_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IQuoteProvider_GetAcceptTypes_Proxy( 
    IQuoteProvider __RPC_FAR * This,
    LPSTR lpszAcceptTypes,
    DWORD dwLen);


void __RPC_STUB IQuoteProvider_GetAcceptTypes_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IQuoteProvider_GetHttpVersion_Proxy( 
    IQuoteProvider __RPC_FAR * This,
    LPSTR lpszHttpVersion,
    DWORD dwLen);


void __RPC_STUB IQuoteProvider_GetHttpVersion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IQuoteProvider_GetFlags_Proxy( 
    IQuoteProvider __RPC_FAR * This,
    DWORD __RPC_FAR *pdwFlags);


void __RPC_STUB IQuoteProvider_GetFlags_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IQuoteProvider_GetHeaders_Proxy( 
    IQuoteProvider __RPC_FAR * This,
    LPSTR lpszHeaders,
    DWORD dwLen);


void __RPC_STUB IQuoteProvider_GetHeaders_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IQuoteProvider_GetData_Proxy( 
    IQuoteProvider __RPC_FAR * This,
    LPSTR lpszData,
    DWORD dwLen);


void __RPC_STUB IQuoteProvider_GetData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IQuoteProvider_ParseResult_Proxy( 
    IQuoteProvider __RPC_FAR * This,
    LPSTR lpszResult);


void __RPC_STUB IQuoteProvider_ParseResult_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE IQuoteProvider_InitializeData_Proxy( 
    IQuoteProvider __RPC_FAR * This,
    LPSTR lpszData);


void __RPC_STUB IQuoteProvider_InitializeData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IQuoteProvider_INTERFACE_DEFINED__ */


#ifndef __IQuoteProviderEvent_INTERFACE_DEFINED__
#define __IQuoteProviderEvent_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: IQuoteProviderEvent
 * at Mon Apr 13 19:03:57 1998
 * using MIDL 3.01.75
 ****************************************/
/* [object][unique][helpstring][uuid] */ 



EXTERN_C const IID IID_IQuoteProviderEvent;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("BFD86BC0-A004-11d1-9912-004033D06B6E")
    IQuoteProviderEvent : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE UpdateSymbol( 
            LPCTSTR lpszSymbol,
            LPCTSTR lpszPrice,
            LPCTSTR lpszChange,
            LPCTSTR lpszOpen,
            LPCTSTR lpszVolume) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IQuoteProviderEventVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IQuoteProviderEvent __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IQuoteProviderEvent __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IQuoteProviderEvent __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *UpdateSymbol )( 
            IQuoteProviderEvent __RPC_FAR * This,
            LPCTSTR lpszSymbol,
            LPCTSTR lpszPrice,
            LPCTSTR lpszChange,
            LPCTSTR lpszOpen,
            LPCTSTR lpszVolume);
        
        END_INTERFACE
    } IQuoteProviderEventVtbl;

    interface IQuoteProviderEvent
    {
        CONST_VTBL struct IQuoteProviderEventVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IQuoteProviderEvent_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IQuoteProviderEvent_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IQuoteProviderEvent_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IQuoteProviderEvent_UpdateSymbol(This,lpszSymbol,lpszPrice,lpszChange,lpszOpen,lpszVolume)	\
    (This)->lpVtbl -> UpdateSymbol(This,lpszSymbol,lpszPrice,lpszChange,lpszOpen,lpszVolume)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IQuoteProviderEvent_UpdateSymbol_Proxy( 
    IQuoteProviderEvent __RPC_FAR * This,
    LPCTSTR lpszSymbol,
    LPCTSTR lpszPrice,
    LPCTSTR lpszChange,
    LPCTSTR lpszOpen,
    LPCTSTR lpszVolume);


void __RPC_STUB IQuoteProviderEvent_UpdateSymbol_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IQuoteProviderEvent_INTERFACE_DEFINED__ */



#ifndef __QUOTEPROVIDERSLib_LIBRARY_DEFINED__
#define __QUOTEPROVIDERSLib_LIBRARY_DEFINED__

/****************************************
 * Generated header for library: QUOTEPROVIDERSLib
 * at Mon Apr 13 19:03:57 1998
 * using MIDL 3.01.75
 ****************************************/
/* [helpstring][version][uuid] */ 



EXTERN_C const IID LIBID_QUOTEPROVIDERSLib;

#ifdef __cplusplus
EXTERN_C const CLSID CLSID_ProviderYahoo;

class DECLSPEC_UUID("F02EAD40-9F0C-11D1-B2B2-006008ACADF7")
ProviderYahoo;
#endif

#ifdef __cplusplus
EXTERN_C const CLSID CLSID_ProviderFastQuote;

class DECLSPEC_UUID("32FBDA43-A002-11D1-9912-004033D06B6E")
ProviderFastQuote;
#endif

#ifdef __cplusplus
EXTERN_C const CLSID CLSID_ProviderDatek;

class DECLSPEC_UUID("E271AF00-CD1A-11d1-9912-004033D06B6E")
ProviderDatek;
#endif
#endif /* __QUOTEPROVIDERSLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
