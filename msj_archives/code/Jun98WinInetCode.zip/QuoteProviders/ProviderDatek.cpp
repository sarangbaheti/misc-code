// ProviderDatek.cpp : Implementation of CProviderDatek
#include "stdafx.h"
#include "QuoteProviders.h"
#include "ProviderDatek.h"
#include "QPGlobal.h"


/////////////////////////////////////////////////////////////////////////////
// CProviderDatek

#define PROVIDER_HOST				"orders8.datek.com" 
#define PROVIDER_PORT				443	//default SSL port
#define PROVIDER_LOGIN_REQUIRED		TRUE
#define PROVIDER_METHOD				"POST" 
#define PROVIDER_URL				"/cgi-bin/trading/datekonline.exe" 
#define PROVIDER_ACCEPT_TYPES		""
#define PROVIDER_HTTP_VERSION		"HTTP/1.0"
#define PROVIDER_FLAGS				INTERNET_FLAG_SECURE  
#define PROVIDER_HEADERS			"Content-type: application/html-form-urlencoded\r\n"
#define TAG_COL_BEGIN				"<TD"
#define SYMBOL_FORMAT				">%s"
#define DATA_FORMAT_BEGIN			"getsym&getquote=Get+Quote&qsymbol="


STDMETHODIMP CProviderDatek::GetHost(LPSTR lpszHost, DWORD dwLen)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if (strlen(PROVIDER_HOST) >= dwLen)
		return E_FAIL;
	strcpy(lpszHost, PROVIDER_HOST);
	return S_OK;
}

STDMETHODIMP CProviderDatek::GetPort(USHORT* pnPort)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	*pnPort = PROVIDER_PORT;
	return S_OK;
}

STDMETHODIMP CProviderDatek::LoginIsRequired(BOOL * pbResult)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	*pbResult = PROVIDER_LOGIN_REQUIRED;
	return S_OK;
}

STDMETHODIMP CProviderDatek::GetMethod(LPSTR lpszMethod, DWORD dwLen)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if (strlen(PROVIDER_METHOD) >= dwLen)
		return E_FAIL;
	strcpy(lpszMethod, PROVIDER_METHOD);
	return S_OK;
}

STDMETHODIMP CProviderDatek::GetURL(LPSTR lpszURL, DWORD dwLen)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if (strlen(PROVIDER_URL) >= dwLen)
		return E_FAIL;
	strcpy(lpszURL, PROVIDER_URL);
	return S_OK;
}

STDMETHODIMP CProviderDatek::GetAcceptTypes(LPSTR lpszAcceptTypes, DWORD dwLen)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if (strlen(PROVIDER_ACCEPT_TYPES) >= dwLen)
		return E_FAIL;
	strcpy(lpszAcceptTypes, PROVIDER_ACCEPT_TYPES);
	return S_OK;
}

STDMETHODIMP CProviderDatek::GetHttpVersion(LPSTR lpszHttpVersion, DWORD dwLen)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if (strlen(PROVIDER_HTTP_VERSION) >= dwLen)
		return E_FAIL;
	strcpy(lpszHttpVersion, PROVIDER_HTTP_VERSION);
	return S_OK;
}

STDMETHODIMP CProviderDatek::GetFlags(DWORD * pdwFlags)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	*pdwFlags = PROVIDER_FLAGS;
	return S_OK;
}

STDMETHODIMP CProviderDatek::GetHeaders(LPSTR lpszHeaders, DWORD dwLen)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if (strlen(PROVIDER_HEADERS) >= dwLen)
		return E_FAIL;
	strcpy(lpszHeaders, PROVIDER_HEADERS);
	return S_OK;
}

STDMETHODIMP CProviderDatek::GetData(LPSTR lpszData, DWORD dwLen)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if (strlen(m_strDataLine) >= dwLen)
		return E_FAIL;
	strcpy(lpszData, m_strDataLine);
	return S_OK;
}

STDMETHODIMP CProviderDatek::InitializeData(LPSTR lpszData)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	LPSTR lpsz1, lpsz2;
	CString strSymbol, strSymbolFormat(SYMBOL_FORMAT);

	m_strDataLine = DATA_FORMAT_BEGIN;
	lpsz1 = lpszData;
	while (lpsz2 = strchr(lpsz1, ' '))
	{
		*lpsz2=0;
		m_strDataLine += lpsz1;
		m_arrSymbols.Add(lpsz1);
		m_strDataLine += ",";
		strSymbol.Format(strSymbolFormat, lpsz1);
		m_arrSearchKeys.Add(strSymbol);
		*lpsz2= ' ';
		lpsz2++;
		lpsz1 = lpsz2;
	}
	m_strDataLine += lpsz1;
	m_arrSymbols.Add(lpsz1);
	strSymbol.Format(strSymbolFormat, lpsz1);
	m_arrSearchKeys.Add(strSymbol);
	return S_OK;
}

STDMETHODIMP CProviderDatek::ParseResult(LPSTR lpszResult)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	
	HRESULT hr;
	long lNumSymbols = m_arrSearchKeys.GetSize(), i;
	for (i=0; i<lNumSymbols; i++)
	{
		hr = ParseSymbol(i, lpszResult);
		if (FAILED(hr))
			return hr;
	}

	return S_OK;
}

HRESULT CProviderDatek::ParseSymbol(long lIndex, LPSTR lpszResult)
{
	LPSTR lpszBegin=NULL, lpszEnd=NULL;
	CString strPrice, strChange, strVolume, strOpen, strFraction;
	HRESULT hr;
	LPCTSTR lpszSymbol = m_arrSearchKeys.GetAt(lIndex);

	//find table row for symbol
	lpszBegin = strstr(lpszResult, lpszSymbol);
	CHECK_POINTER(lpszBegin);
	
	//pass
	lpszEnd = strstr(lpszBegin, TAG_COL_BEGIN);
	CHECK_POINTER(lpszEnd);
	lpszBegin = strstr(lpszEnd+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszBegin);
	lpszEnd = strstr(lpszBegin+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszEnd);
	lpszBegin = strstr(lpszEnd+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszBegin);

	//price column
	lpszEnd = lpszBegin;
	lpszBegin = strstr(lpszEnd+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszBegin);
	lpszEnd = strstr(lpszBegin+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszEnd);
	hr = ParseData(strPrice, lpszBegin, lpszEnd);
	if (FAILED(hr))
		return hr;
	//price fraction column
	lpszBegin = lpszEnd;
	CHECK_POINTER(lpszBegin);
	lpszEnd = strstr(lpszBegin+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszEnd);
	hr = ParseData(strFraction, lpszBegin, lpszEnd);
	if (FAILED(hr))
		return hr;
	strPrice += strFraction;

	//change
	lpszBegin = lpszEnd;
	CHECK_POINTER(lpszBegin);
	lpszEnd = strstr(lpszBegin+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszEnd);
	hr = ParseData(strChange, lpszBegin, lpszEnd);
	if (FAILED(hr))
		return hr;

	//pass
	lpszBegin = strstr(lpszEnd+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszBegin);
	lpszEnd = strstr(lpszBegin+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszEnd);
	lpszBegin = strstr(lpszEnd+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszBegin);

	//volume
	lpszEnd = lpszBegin;
	lpszBegin = strstr(lpszEnd+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszBegin);
	lpszEnd = strstr(lpszBegin+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszEnd);
	hr = ParseData(strVolume, lpszBegin, lpszEnd);
	if (FAILED(hr))
		return hr;

	//notify mainframe to update
	Fire_UpdateSymbol(m_arrSymbols.GetAt(lIndex), strPrice, strChange, strOpen, strVolume);

	return S_OK;
}

