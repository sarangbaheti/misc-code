// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//

#include "stdafx.h"
#include <objbase.h>
#include <initguid.h>
#include "CategoryGuid.h"