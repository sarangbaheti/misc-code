// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//
// ProviderFastQuote.h : Declaration of the CProviderFastQuote
//

#ifndef __PROVIDERFASTQUOTE_H_
#define __PROVIDERFASTQUOTE_H_

#include "resource.h"       // main symbols
#include "CPQuoteProviders.h"

/////////////////////////////////////////////////////////////////////////////
// CProviderFastQuote
class ATL_NO_VTABLE CProviderFastQuote : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CProviderFastQuote, &CLSID_ProviderFastQuote>,
	public IConnectionPointContainerImpl<CProviderFastQuote>,
	public CProxyIQuoteProviderEvent<CProviderFastQuote>,
	public IQuoteProvider
{
public:
	CProviderFastQuote()
	{
	}
	CStringArray m_arrSymbols;
	CStringArray m_arrSearchKeys;
	CString m_strDataLine;
	CString m_strURL;

DECLARE_REGISTRY_RESOURCEID(IDR_PROVIDERFASTQUOTE)

BEGIN_COM_MAP(CProviderFastQuote)
	COM_INTERFACE_ENTRY(IQuoteProvider)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
END_COM_MAP()

BEGIN_CONNECTION_POINT_MAP(CProviderFastQuote)
    CONNECTION_POINT_ENTRY(IID_IQuoteProviderEvent)
END_CONNECTION_POINT_MAP()


// IProviderFastQuote
public:
	STDMETHOD(InitializeData)(LPSTR lpszData);
	STDMETHOD(ParseResult)(LPSTR lpszResult);
	STDMETHOD(GetData)(LPSTR lpszData, DWORD dwLen);
	STDMETHOD(GetHeaders)(LPSTR lpszHeaders, DWORD dwLen);
	STDMETHOD(GetFlags)(DWORD* pdwFlags);
	STDMETHOD(GetHttpVersion)(LPSTR lpszHttpVersion, DWORD dwLen);
	STDMETHOD(GetAcceptTypes)(LPSTR lpszAcceptTypes, DWORD dwLen);
	STDMETHOD(GetURL)(LPSTR lpszURL, DWORD dwLen);
	STDMETHOD(GetMethod)(LPSTR lpszMethod, DWORD dwLen);
	STDMETHOD(LoginIsRequired)(BOOL* pbResult);
	STDMETHOD(GetPort)(USHORT* pnPort);
	STDMETHOD(GetHost)(LPSTR lpszHost, DWORD dwLen);
protected:
	HRESULT ParseSymbol(long lIndex, LPSTR lpszResult);
};

#endif //__PROVIDERFASTQUOTE_H_
