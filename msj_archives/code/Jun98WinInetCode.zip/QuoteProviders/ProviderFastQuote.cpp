// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//
// ProviderFastQuote.cpp : Implementation of CProviderFastQuote
//

#include "stdafx.h"
#include "QuoteProviders.h"
#include "ProviderFastQuote.h"
#include "QPGlobal.h"

#define PROVIDER_HOST				"fast.quote.com"
#define PROVIDER_PORT				80
#define PROVIDER_LOGIN_REQUIRED		FALSE
#define PROVIDER_METHOD				"GET"
#define PROVIDER_URL				"/fq/quotecom/quote?symbols="
#define PROVIDER_ACCEPT_TYPES		""
#define PROVIDER_HTTP_VERSION		"HTTP/1.0"
#define PROVIDER_FLAGS				0
#define PROVIDER_HEADERS			""
#define TAG_COL_BEGIN				"<TD"
#define SYMBOL_FORMAT				">%s<"

/////////////////////////////////////////////////////////////////////////////
// CProviderFastQuote

STDMETHODIMP CProviderFastQuote::GetHost(LPSTR lpszHost, DWORD dwLen)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if (strlen(PROVIDER_HOST) >= dwLen)
		return E_FAIL;
	strcpy(lpszHost, PROVIDER_HOST);
	return S_OK;
}


STDMETHODIMP CProviderFastQuote::GetPort(USHORT* pnPort)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	*pnPort = PROVIDER_PORT;
	return S_OK;
}

STDMETHODIMP CProviderFastQuote::LoginIsRequired(BOOL * pbResult)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	*pbResult = PROVIDER_LOGIN_REQUIRED;
	return S_OK;
}

STDMETHODIMP CProviderFastQuote::GetMethod(LPSTR lpszMethod, DWORD dwLen)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if (strlen(PROVIDER_METHOD) >= dwLen)
		return E_FAIL;
	strcpy(lpszMethod, PROVIDER_METHOD);
	return S_OK;
}

STDMETHODIMP CProviderFastQuote::GetURL(LPSTR lpszURL, DWORD dwLen)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if (strlen(m_strURL) >= dwLen)
		return E_FAIL;
	strcpy(lpszURL, m_strURL);
	return S_OK;
}

STDMETHODIMP CProviderFastQuote::GetAcceptTypes(LPSTR lpszAcceptTypes, DWORD dwLen)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if (strlen(PROVIDER_ACCEPT_TYPES) >= dwLen)
		return E_FAIL;
	strcpy(lpszAcceptTypes, PROVIDER_ACCEPT_TYPES);
	return S_OK;
}

STDMETHODIMP CProviderFastQuote::GetHttpVersion(LPSTR lpszHttpVersion, DWORD dwLen)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if (strlen(PROVIDER_HTTP_VERSION) >= dwLen)
		return E_FAIL;
	strcpy(lpszHttpVersion, PROVIDER_HTTP_VERSION);
	return S_OK;
}

STDMETHODIMP CProviderFastQuote::GetFlags(DWORD * pdwFlags)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	*pdwFlags = PROVIDER_FLAGS;
	return S_OK;
}

STDMETHODIMP CProviderFastQuote::GetHeaders(LPSTR lpszHeaders, DWORD dwLen)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if (strlen(PROVIDER_HEADERS) >= dwLen)
		return E_FAIL;
	strcpy(lpszHeaders, PROVIDER_HEADERS);
	return S_OK;
}

STDMETHODIMP CProviderFastQuote::GetData(LPSTR lpszData, DWORD dwLen)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if (strlen(m_strDataLine) >= dwLen)
		return E_FAIL;
	strcpy(lpszData, m_strDataLine);
	return S_OK;
}

STDMETHODIMP CProviderFastQuote::InitializeData(LPSTR lpszData)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	LPSTR lpsz1, lpsz2;
	CString strSymbol, strSymbolFormat(SYMBOL_FORMAT);

	m_strURL = PROVIDER_URL;
	lpsz1 = lpszData;
	while (lpsz2 = strchr(lpsz1, ' '))
	{
		*lpsz2=0;
		m_strURL += lpsz1;
		m_arrSymbols.Add(lpsz1);
		m_strURL += "+";
		strSymbol.Format(strSymbolFormat, lpsz1);
		m_arrSearchKeys.Add(strSymbol);
		*lpsz2= ' ';
		lpsz2++;
		lpsz1 = lpsz2;
	}
	m_strURL += lpsz1;
	m_arrSymbols.Add(lpsz1);
	strSymbol.Format(strSymbolFormat, lpsz1);
	m_arrSearchKeys.Add(strSymbol);
	return S_OK;
}

STDMETHODIMP CProviderFastQuote::ParseResult(LPSTR lpszResult)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	
	HRESULT hr;
	long lNumSymbols = m_arrSearchKeys.GetSize(), i;
	for (i=0; i<lNumSymbols; i++)
	{
		hr = ParseSymbol(i, lpszResult);
		if (FAILED(hr))
			return hr;
	}

	return S_OK;
}

HRESULT CProviderFastQuote::ParseSymbol(long lIndex, LPSTR lpszResult)
{
	LPSTR lpszBegin=NULL, lpszEnd=NULL;
	CString strPrice, strChange, strVolume, strOpen;
	HRESULT hr;
	LPCTSTR lpszSymbol = m_arrSearchKeys.GetAt(lIndex);

	//find table row for symbol
	lpszBegin = strstr(lpszResult, lpszSymbol);
	CHECK_POINTER(lpszBegin);
	
	//pass date and time columns
	lpszEnd = strstr(lpszBegin, TAG_COL_BEGIN);
	CHECK_POINTER(lpszEnd);
	lpszBegin = strstr(lpszEnd+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszBegin);
	lpszEnd = strstr(lpszBegin+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszEnd);

	//open column
	lpszBegin = lpszEnd;
	lpszEnd = strstr(lpszBegin+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszEnd);
	hr = ParseData(strOpen, lpszBegin, lpszEnd);
	if (FAILED(hr))
		return hr;

	//pass high and low columns
	lpszBegin = strstr(lpszEnd+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszBegin);
	lpszEnd = strstr(lpszBegin+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszEnd);

	//last
	lpszBegin = lpszEnd;
	CHECK_POINTER(lpszBegin);
	lpszEnd = strstr(lpszBegin+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszEnd);
	hr = ParseData(strPrice, lpszBegin, lpszEnd);
	if (FAILED(hr))
		return hr;

	//change
	lpszBegin = lpszEnd;
	CHECK_POINTER(lpszBegin);
	lpszEnd = strstr(lpszBegin+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszEnd);
	hr = ParseData(strChange, lpszBegin, lpszEnd);
	if (FAILED(hr))
		return hr;

	//volume
	lpszBegin = lpszEnd;
	CHECK_POINTER(lpszBegin);
	lpszEnd = strstr(lpszBegin+1, TAG_COL_BEGIN);
	CHECK_POINTER(lpszEnd);
	hr = ParseData(strVolume, lpszBegin, lpszEnd);
	if (FAILED(hr))
		return hr;

	//notify mainframe to update
	Fire_UpdateSymbol(m_arrSymbols.GetAt(lIndex), strPrice, strChange, strOpen, strVolume);

	return S_OK;
}

