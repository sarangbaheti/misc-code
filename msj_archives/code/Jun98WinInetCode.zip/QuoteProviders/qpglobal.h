// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//
#ifndef __QPGLOBALS_H__
#define __QPGLOBALS_H__

HRESULT RemoveHtmlTags(CString& strNewValue, char* lpszValue);
HRESULT ParseData(CString&strData, char* lpszBegin, char* lpszEnd);

#define CHECK_POINTER(p) if (!p) return E_FAIL;

#endif