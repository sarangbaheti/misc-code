// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//
// {32014981-9CD4-11d1-9912-004033D06B6E}

DEFINE_GUID(CATID_QuoteProviders, 
0x32014981, 0x9cd4, 0x11d1, 0x99, 0x12, 0x0, 0x40, 0x33, 0xd0, 0x6b, 0x6e);
