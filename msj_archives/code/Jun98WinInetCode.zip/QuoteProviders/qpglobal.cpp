#include "stdafx.h"
#include "qpglobal.h"

#define NBSP "&nbsp"

HRESULT RemoveHtmlTags(CString& strNewValue, char* lpszValue)
{
	char* lpsz1 = lpszValue;
	while (*lpsz1)
	{
		switch(*lpsz1)
		{
		case '<':
			lpsz1 = strchr(lpsz1, '>');
			CHECK_POINTER(lpsz1);
			break;
		case '&':
			lpsz1+=(strlen(NBSP)-1);
			break;
		case '\x0A':
			break;
		case '\x09':
			break;
		default:
			strNewValue += *lpsz1;
		}
		lpsz1++;
	}
	return S_OK;
}

HRESULT ParseData(CString&strData, char* lpszBegin, char* lpszEnd)
{
	char chSave = *lpszEnd;
	*lpszEnd = 0;
	RemoveHtmlTags(strData, lpszBegin);
	*lpszEnd = chSave; 	
	return S_OK;
}
