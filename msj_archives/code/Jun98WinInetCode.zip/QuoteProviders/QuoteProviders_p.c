/* this ALWAYS GENERATED file contains the proxy stub code */


/* File created by MIDL compiler version 3.01.75 */
/* at Mon Apr 13 19:03:57 1998
 */
/* Compiler settings for QuoteProviders.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )

#define USE_STUBLESS_PROXY

#include "rpcproxy.h"
#include "QuoteProviders.h"

#define TYPE_FORMAT_STRING_SIZE   17                                
#define PROC_FORMAT_STRING_SIZE   379                               

typedef struct _MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } MIDL_TYPE_FORMAT_STRING;

typedef struct _MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } MIDL_PROC_FORMAT_STRING;


extern const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString;
extern const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString;


/* Object interface: IUnknown, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: IQuoteProvider, ver. 0.0,
   GUID={0xF02EAD3F,0x9F0C,0x11D1,{0xB2,0xB2,0x00,0x60,0x08,0xAC,0xAD,0xF7}} */


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO IQuoteProvider_ServerInfo;

#pragma code_seg(".orpc")
static const unsigned short IQuoteProvider_FormatStringOffsetTable[] = 
    {
    0,
    30,
    54,
    78,
    108,
    138,
    168,
    198,
    222,
    252,
    282,
    306
    };

static const MIDL_SERVER_INFO IQuoteProvider_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &IQuoteProvider_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0
    };

static const MIDL_STUBLESS_PROXY_INFO IQuoteProvider_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &IQuoteProvider_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };

CINTERFACE_PROXY_VTABLE(15) _IQuoteProviderProxyVtbl = 
{
    &IQuoteProvider_ProxyInfo,
    &IID_IQuoteProvider,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    (void *)-1 /* IQuoteProvider::GetHost */ ,
    (void *)-1 /* IQuoteProvider::GetPort */ ,
    (void *)-1 /* IQuoteProvider::LoginIsRequired */ ,
    (void *)-1 /* IQuoteProvider::GetMethod */ ,
    (void *)-1 /* IQuoteProvider::GetURL */ ,
    (void *)-1 /* IQuoteProvider::GetAcceptTypes */ ,
    (void *)-1 /* IQuoteProvider::GetHttpVersion */ ,
    (void *)-1 /* IQuoteProvider::GetFlags */ ,
    (void *)-1 /* IQuoteProvider::GetHeaders */ ,
    (void *)-1 /* IQuoteProvider::GetData */ ,
    (void *)-1 /* IQuoteProvider::ParseResult */ ,
    (void *)-1 /* IQuoteProvider::InitializeData */
};

const CInterfaceStubVtbl _IQuoteProviderStubVtbl =
{
    &IID_IQuoteProvider,
    &IQuoteProvider_ServerInfo,
    15,
    0, /* pure interpreted */
    CStdStubBuffer_METHODS
};


/* Object interface: IQuoteProviderEvent, ver. 0.0,
   GUID={0xBFD86BC0,0xA004,0x11d1,{0x99,0x12,0x00,0x40,0x33,0xD0,0x6B,0x6E}} */


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO IQuoteProviderEvent_ServerInfo;

#pragma code_seg(".orpc")

static const MIDL_STUB_DESC Object_StubDesc = 
    {
    0,
    NdrOleAllocate,
    NdrOleFree,
    0,
    0,
    0,
    0,
    0,
    __MIDL_TypeFormatString.Format,
    0, /* -error bounds_check flag */
    0x20000, /* Ndr library version */
    0,
    0x301004b, /* MIDL Version 3.1.75 */
    0,
    0,
    0,  /* Reserved1 */
    0,  /* Reserved2 */
    0,  /* Reserved3 */
    0,  /* Reserved4 */
    0   /* Reserved5 */
    };

static const unsigned short IQuoteProviderEvent_FormatStringOffsetTable[] = 
    {
    330
    };

static const MIDL_SERVER_INFO IQuoteProviderEvent_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &IQuoteProviderEvent_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0
    };

static const MIDL_STUBLESS_PROXY_INFO IQuoteProviderEvent_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &IQuoteProviderEvent_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };

CINTERFACE_PROXY_VTABLE(4) _IQuoteProviderEventProxyVtbl = 
{
    &IQuoteProviderEvent_ProxyInfo,
    &IID_IQuoteProviderEvent,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    (void *)-1 /* IQuoteProviderEvent::UpdateSymbol */
};

const CInterfaceStubVtbl _IQuoteProviderEventStubVtbl =
{
    &IID_IQuoteProviderEvent,
    &IQuoteProviderEvent_ServerInfo,
    4,
    0, /* pure interpreted */
    CStdStubBuffer_METHODS
};

#pragma data_seg(".rdata")

#if !defined(__RPC_WIN32__)
#error  Invalid build platform for this stub.
#endif

#if !(TARGET_IS_NT40_OR_LATER)
#error You need a Windows NT 4.0 or later to run this stub because it uses these features:
#error   -Oif or -Oicf.
#error However, your C/C++ compilation flags indicate you intend to run this app on earlier systems.
#error This app will die there with the RPC_X_WRONG_STUB_VERSION error.
#endif


static const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString =
    {
        0,
        {

	/* Procedure GetHost */

			0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/*  2 */	NdrFcShort( 0x3 ),	/* 3 */
#ifndef _ALPHA_
/*  4 */	NdrFcShort( 0x10 ),	/* x86, MIPS, PPC Stack size/offset = 16 */
#else
			NdrFcShort( 0x20 ),	/* Alpha Stack size/offset = 32 */
#endif
/*  6 */	NdrFcShort( 0x8 ),	/* 8 */
/*  8 */	NdrFcShort( 0x8 ),	/* 8 */
/* 10 */	0x6,		/* 6 */
			0x3,		/* 3 */

	/* Parameter lpszHost */

/* 12 */	NdrFcShort( 0x10b ),	/* 267 */
#ifndef _ALPHA_
/* 14 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 16 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter dwLen */

/* 18 */	NdrFcShort( 0x48 ),	/* 72 */
#ifndef _ALPHA_
/* 20 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 22 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 24 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
/* 26 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 28 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure GetPort */

/* 30 */	0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/* 32 */	NdrFcShort( 0x4 ),	/* 4 */
#ifndef _ALPHA_
/* 34 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 36 */	NdrFcShort( 0x6 ),	/* 6 */
/* 38 */	NdrFcShort( 0x8 ),	/* 8 */
/* 40 */	0x4,		/* 4 */
			0x2,		/* 2 */

	/* Parameter pnPort */

/* 42 */	NdrFcShort( 0x148 ),	/* 328 */
#ifndef _ALPHA_
/* 44 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 46 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 48 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
/* 50 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 52 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure LoginIsRequired */

/* 54 */	0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/* 56 */	NdrFcShort( 0x5 ),	/* 5 */
#ifndef _ALPHA_
/* 58 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 60 */	NdrFcShort( 0x8 ),	/* 8 */
/* 62 */	NdrFcShort( 0x8 ),	/* 8 */
/* 64 */	0x4,		/* 4 */
			0x2,		/* 2 */

	/* Parameter pbResult */

/* 66 */	NdrFcShort( 0x148 ),	/* 328 */
#ifndef _ALPHA_
/* 68 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 70 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 72 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
/* 74 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 76 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure GetMethod */

/* 78 */	0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/* 80 */	NdrFcShort( 0x6 ),	/* 6 */
#ifndef _ALPHA_
/* 82 */	NdrFcShort( 0x10 ),	/* x86, MIPS, PPC Stack size/offset = 16 */
#else
			NdrFcShort( 0x20 ),	/* Alpha Stack size/offset = 32 */
#endif
/* 84 */	NdrFcShort( 0x8 ),	/* 8 */
/* 86 */	NdrFcShort( 0x8 ),	/* 8 */
/* 88 */	0x6,		/* 6 */
			0x3,		/* 3 */

	/* Parameter lpszMethod */

/* 90 */	NdrFcShort( 0x10b ),	/* 267 */
#ifndef _ALPHA_
/* 92 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 94 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter dwLen */

/* 96 */	NdrFcShort( 0x48 ),	/* 72 */
#ifndef _ALPHA_
/* 98 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 100 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 102 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
/* 104 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 106 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure GetURL */

/* 108 */	0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/* 110 */	NdrFcShort( 0x7 ),	/* 7 */
#ifndef _ALPHA_
/* 112 */	NdrFcShort( 0x10 ),	/* x86, MIPS, PPC Stack size/offset = 16 */
#else
			NdrFcShort( 0x20 ),	/* Alpha Stack size/offset = 32 */
#endif
/* 114 */	NdrFcShort( 0x8 ),	/* 8 */
/* 116 */	NdrFcShort( 0x8 ),	/* 8 */
/* 118 */	0x6,		/* 6 */
			0x3,		/* 3 */

	/* Parameter lpszURL */

/* 120 */	NdrFcShort( 0x10b ),	/* 267 */
#ifndef _ALPHA_
/* 122 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 124 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter dwLen */

/* 126 */	NdrFcShort( 0x48 ),	/* 72 */
#ifndef _ALPHA_
/* 128 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 130 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 132 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
/* 134 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 136 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure GetAcceptTypes */

/* 138 */	0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/* 140 */	NdrFcShort( 0x8 ),	/* 8 */
#ifndef _ALPHA_
/* 142 */	NdrFcShort( 0x10 ),	/* x86, MIPS, PPC Stack size/offset = 16 */
#else
			NdrFcShort( 0x20 ),	/* Alpha Stack size/offset = 32 */
#endif
/* 144 */	NdrFcShort( 0x8 ),	/* 8 */
/* 146 */	NdrFcShort( 0x8 ),	/* 8 */
/* 148 */	0x6,		/* 6 */
			0x3,		/* 3 */

	/* Parameter lpszAcceptTypes */

/* 150 */	NdrFcShort( 0x10b ),	/* 267 */
#ifndef _ALPHA_
/* 152 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 154 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter dwLen */

/* 156 */	NdrFcShort( 0x48 ),	/* 72 */
#ifndef _ALPHA_
/* 158 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 160 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 162 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
/* 164 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 166 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure GetHttpVersion */

/* 168 */	0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/* 170 */	NdrFcShort( 0x9 ),	/* 9 */
#ifndef _ALPHA_
/* 172 */	NdrFcShort( 0x10 ),	/* x86, MIPS, PPC Stack size/offset = 16 */
#else
			NdrFcShort( 0x20 ),	/* Alpha Stack size/offset = 32 */
#endif
/* 174 */	NdrFcShort( 0x8 ),	/* 8 */
/* 176 */	NdrFcShort( 0x8 ),	/* 8 */
/* 178 */	0x6,		/* 6 */
			0x3,		/* 3 */

	/* Parameter lpszHttpVersion */

/* 180 */	NdrFcShort( 0x10b ),	/* 267 */
#ifndef _ALPHA_
/* 182 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 184 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter dwLen */

/* 186 */	NdrFcShort( 0x48 ),	/* 72 */
#ifndef _ALPHA_
/* 188 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 190 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 192 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
/* 194 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 196 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure GetFlags */

/* 198 */	0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/* 200 */	NdrFcShort( 0xa ),	/* 10 */
#ifndef _ALPHA_
/* 202 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 204 */	NdrFcShort( 0x8 ),	/* 8 */
/* 206 */	NdrFcShort( 0x8 ),	/* 8 */
/* 208 */	0x4,		/* 4 */
			0x2,		/* 2 */

	/* Parameter pdwFlags */

/* 210 */	NdrFcShort( 0x148 ),	/* 328 */
#ifndef _ALPHA_
/* 212 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 214 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 216 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
/* 218 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 220 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure GetHeaders */

/* 222 */	0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/* 224 */	NdrFcShort( 0xb ),	/* 11 */
#ifndef _ALPHA_
/* 226 */	NdrFcShort( 0x10 ),	/* x86, MIPS, PPC Stack size/offset = 16 */
#else
			NdrFcShort( 0x20 ),	/* Alpha Stack size/offset = 32 */
#endif
/* 228 */	NdrFcShort( 0x8 ),	/* 8 */
/* 230 */	NdrFcShort( 0x8 ),	/* 8 */
/* 232 */	0x6,		/* 6 */
			0x3,		/* 3 */

	/* Parameter lpszHeaders */

/* 234 */	NdrFcShort( 0x10b ),	/* 267 */
#ifndef _ALPHA_
/* 236 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 238 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter dwLen */

/* 240 */	NdrFcShort( 0x48 ),	/* 72 */
#ifndef _ALPHA_
/* 242 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 244 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 246 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
/* 248 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 250 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure GetData */

/* 252 */	0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/* 254 */	NdrFcShort( 0xc ),	/* 12 */
#ifndef _ALPHA_
/* 256 */	NdrFcShort( 0x10 ),	/* x86, MIPS, PPC Stack size/offset = 16 */
#else
			NdrFcShort( 0x20 ),	/* Alpha Stack size/offset = 32 */
#endif
/* 258 */	NdrFcShort( 0x8 ),	/* 8 */
/* 260 */	NdrFcShort( 0x8 ),	/* 8 */
/* 262 */	0x6,		/* 6 */
			0x3,		/* 3 */

	/* Parameter lpszData */

/* 264 */	NdrFcShort( 0x10b ),	/* 267 */
#ifndef _ALPHA_
/* 266 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 268 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Parameter dwLen */

/* 270 */	NdrFcShort( 0x48 ),	/* 72 */
#ifndef _ALPHA_
/* 272 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 274 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 276 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
/* 278 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 280 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure ParseResult */

/* 282 */	0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/* 284 */	NdrFcShort( 0xd ),	/* 13 */
#ifndef _ALPHA_
/* 286 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 288 */	NdrFcShort( 0x0 ),	/* 0 */
/* 290 */	NdrFcShort( 0x8 ),	/* 8 */
/* 292 */	0x6,		/* 6 */
			0x2,		/* 2 */

	/* Parameter lpszResult */

/* 294 */	NdrFcShort( 0x10b ),	/* 267 */
#ifndef _ALPHA_
/* 296 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 298 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Return value */

/* 300 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
/* 302 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 304 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure InitializeData */

/* 306 */	0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/* 308 */	NdrFcShort( 0xe ),	/* 14 */
#ifndef _ALPHA_
/* 310 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 312 */	NdrFcShort( 0x0 ),	/* 0 */
/* 314 */	NdrFcShort( 0x8 ),	/* 8 */
/* 316 */	0x6,		/* 6 */
			0x2,		/* 2 */

	/* Parameter lpszData */

/* 318 */	NdrFcShort( 0x10b ),	/* 267 */
#ifndef _ALPHA_
/* 320 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 322 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */

	/* Return value */

/* 324 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
/* 326 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 328 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure UpdateSymbol */

/* 330 */	0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/* 332 */	NdrFcShort( 0x3 ),	/* 3 */
#ifndef _ALPHA_
/* 334 */	NdrFcShort( 0x1c ),	/* x86, MIPS, PPC Stack size/offset = 28 */
#else
			NdrFcShort( 0x38 ),	/* Alpha Stack size/offset = 56 */
#endif
/* 336 */	NdrFcShort( 0x0 ),	/* 0 */
/* 338 */	NdrFcShort( 0x8 ),	/* 8 */
/* 340 */	0x6,		/* 6 */
			0x6,		/* 6 */

	/* Parameter lpszSymbol */

/* 342 */	NdrFcShort( 0x10b ),	/* 267 */
#ifndef _ALPHA_
/* 344 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 346 */	NdrFcShort( 0xe ),	/* Type Offset=14 */

	/* Parameter lpszPrice */

/* 348 */	NdrFcShort( 0x10b ),	/* 267 */
#ifndef _ALPHA_
/* 350 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 352 */	NdrFcShort( 0xe ),	/* Type Offset=14 */

	/* Parameter lpszChange */

/* 354 */	NdrFcShort( 0x10b ),	/* 267 */
#ifndef _ALPHA_
/* 356 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 358 */	NdrFcShort( 0xe ),	/* Type Offset=14 */

	/* Parameter lpszOpen */

/* 360 */	NdrFcShort( 0x10b ),	/* 267 */
#ifndef _ALPHA_
/* 362 */	NdrFcShort( 0x10 ),	/* x86, MIPS, PPC Stack size/offset = 16 */
#else
			NdrFcShort( 0x20 ),	/* Alpha Stack size/offset = 32 */
#endif
/* 364 */	NdrFcShort( 0xe ),	/* Type Offset=14 */

	/* Parameter lpszVolume */

/* 366 */	NdrFcShort( 0x10b ),	/* 267 */
#ifndef _ALPHA_
/* 368 */	NdrFcShort( 0x14 ),	/* x86, MIPS, PPC Stack size/offset = 20 */
#else
			NdrFcShort( 0x28 ),	/* Alpha Stack size/offset = 40 */
#endif
/* 370 */	NdrFcShort( 0xe ),	/* Type Offset=14 */

	/* Return value */

/* 372 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
/* 374 */	NdrFcShort( 0x18 ),	/* x86, MIPS, PPC Stack size/offset = 24 */
#else
			NdrFcShort( 0x30 ),	/* Alpha Stack size/offset = 48 */
#endif
/* 376 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

			0x0
        }
    };

static const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString =
    {
        0,
        {
			0x11, 0x8,	/* FC_RP [simple_pointer] */
/*  2 */	
			0x22,		/* FC_C_CSTRING */
			0x5c,		/* FC_PAD */
/*  4 */	
			0x11, 0x8,	/* FC_RP [simple_pointer] */
/*  6 */	0x6,		/* FC_SHORT */
			0x5c,		/* FC_PAD */
/*  8 */	
			0x11, 0x8,	/* FC_RP [simple_pointer] */
/* 10 */	0x8,		/* FC_LONG */
			0x5c,		/* FC_PAD */
/* 12 */	
			0x11, 0x8,	/* FC_RP [simple_pointer] */
/* 14 */	
			0x25,		/* FC_C_WSTRING */
			0x5c,		/* FC_PAD */

			0x0
        }
    };

const CInterfaceProxyVtbl * _QuoteProviders_ProxyVtblList[] = 
{
    ( CInterfaceProxyVtbl *) &_IQuoteProviderProxyVtbl,
    ( CInterfaceProxyVtbl *) &_IQuoteProviderEventProxyVtbl,
    0
};

const CInterfaceStubVtbl * _QuoteProviders_StubVtblList[] = 
{
    ( CInterfaceStubVtbl *) &_IQuoteProviderStubVtbl,
    ( CInterfaceStubVtbl *) &_IQuoteProviderEventStubVtbl,
    0
};

PCInterfaceName const _QuoteProviders_InterfaceNamesList[] = 
{
    "IQuoteProvider",
    "IQuoteProviderEvent",
    0
};


#define _QuoteProviders_CHECK_IID(n)	IID_GENERIC_CHECK_IID( _QuoteProviders, pIID, n)

int __stdcall _QuoteProviders_IID_Lookup( const IID * pIID, int * pIndex )
{
    IID_BS_LOOKUP_SETUP

    IID_BS_LOOKUP_INITIAL_TEST( _QuoteProviders, 2, 1 )
    IID_BS_LOOKUP_RETURN_RESULT( _QuoteProviders, 2, *pIndex )
    
}

const ExtendedProxyFileInfo QuoteProviders_ProxyFileInfo = 
{
    (PCInterfaceProxyVtblList *) & _QuoteProviders_ProxyVtblList,
    (PCInterfaceStubVtblList *) & _QuoteProviders_StubVtblList,
    (const PCInterfaceName * ) & _QuoteProviders_InterfaceNamesList,
    0, // no delegation
    & _QuoteProviders_IID_Lookup, 
    2,
    2
};
