/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 3.01.75 */
/* at Mon Apr 13 19:03:57 1998
 */
/* Compiler settings for QuoteProviders.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IQuoteProvider = {0xF02EAD3F,0x9F0C,0x11D1,{0xB2,0xB2,0x00,0x60,0x08,0xAC,0xAD,0xF7}};


const IID IID_IQuoteProviderEvent = {0xBFD86BC0,0xA004,0x11d1,{0x99,0x12,0x00,0x40,0x33,0xD0,0x6B,0x6E}};


const IID LIBID_QUOTEPROVIDERSLib = {0xF02EAD31,0x9F0C,0x11D1,{0xB2,0xB2,0x00,0x60,0x08,0xAC,0xAD,0xF7}};


const CLSID CLSID_ProviderYahoo = {0xF02EAD40,0x9F0C,0x11D1,{0xB2,0xB2,0x00,0x60,0x08,0xAC,0xAD,0xF7}};


const CLSID CLSID_ProviderFastQuote = {0x32FBDA43,0xA002,0x11D1,{0x99,0x12,0x00,0x40,0x33,0xD0,0x6B,0x6E}};


const CLSID CLSID_ProviderDatek = {0xE271AF00,0xCD1A,0x11d1,{0x99,0x12,0x00,0x40,0x33,0xD0,0x6B,0x6E}};


#ifdef __cplusplus
}
#endif

