// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//
// ProviderYahoo.h : Declaration of the CProviderYahoo
//

#ifndef __PROVIDERYAHOO_H_
#define __PROVIDERYAHOO_H_

#include "resource.h"       // main symbols
#include "CPQuoteProviders.h"

/////////////////////////////////////////////////////////////////////////////
// CProviderYahoo
class ATL_NO_VTABLE CProviderYahoo : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CProviderYahoo, &CLSID_ProviderYahoo>,
	public IConnectionPointContainerImpl<CProviderYahoo>,
	public CProxyIQuoteProviderEvent<CProviderYahoo>,
	public IQuoteProvider
{
public:
	CProviderYahoo()
	{
	}
	~CProviderYahoo()
	{
	}
	CStringArray m_arrSymbols;
	CStringArray m_arrSearchKeys;
	CString m_strDataLine;
	CString m_strURL;

DECLARE_REGISTRY_RESOURCEID(IDR_PROVIDERYAHOO)

BEGIN_COM_MAP(CProviderYahoo)
	COM_INTERFACE_ENTRY(IQuoteProvider)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
END_COM_MAP()

BEGIN_CONNECTION_POINT_MAP(CProviderYahoo)
    CONNECTION_POINT_ENTRY(IID_IQuoteProviderEvent)
END_CONNECTION_POINT_MAP()


// IProviderYahoo
public:
	STDMETHOD(InitializeData)(LPSTR lpszData);
	STDMETHOD(ParseResult)(LPSTR lpszResult);
	STDMETHOD(GetData)(LPSTR lpszData, DWORD dwLen);
	STDMETHOD(GetHeaders)(LPSTR lpszHeaders, DWORD dwLen);
	STDMETHOD(GetFlags)(DWORD* pdwFlags);
	STDMETHOD(GetHttpVersion)(LPSTR lpszHttpVersion, DWORD dwLen);
	STDMETHOD(GetAcceptTypes)(LPSTR lpszAcceptTypes, DWORD dwLen);
	STDMETHOD(GetURL)(LPSTR lpszURL, DWORD dwLen);
	STDMETHOD(GetMethod)(LPSTR lpszMethod, DWORD dwLen);
	STDMETHOD(LoginIsRequired)(BOOL* pbResult);
	STDMETHOD(GetPort)(USHORT* pnPort);
	STDMETHOD(GetHost)(LPSTR lpszHost, DWORD dwLen);
protected:
	HRESULT ParseFraction(CString& strPrice, LPSTR lpszPriceBegin, LPSTR lpszPriceEnd);
	HRESULT ParseSymbol(long lIndex, LPSTR lpszResult);
};

#endif //__PROVIDERYAHOO_H_
