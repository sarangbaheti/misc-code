// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//

#ifndef __CPROXYIQUOTEPROVIDEREVENT_H__
#define __CPROXYIQUOTEPROVIDEREVENT_H__

//////////////////////////////////////////////////////////////////////////////
// CProxyIQuoteProviderEvent
template <class T>
class CProxyIQuoteProviderEvent : public IConnectionPointImpl<T, &IID_IQuoteProviderEvent, CComDynamicUnkArray>
{
public:

//IQuoteProviderEvent : IUnknown
public:
	HRESULT Fire_UpdateSymbol(
		LPCTSTR lpszSymbol,
		LPCTSTR lpszPrice,
		LPCTSTR lpszChange,
		LPCTSTR lpszOpen,
		LPCTSTR lpszVolume)
	{
		T* pT = (T*)this;
		pT->Lock();
		HRESULT ret;
		IUnknown** pp = m_vec.begin();
		while (pp < m_vec.end())
		{
			if (*pp != NULL)
			{
				IQuoteProviderEvent* pIQuoteProviderEvent = reinterpret_cast<IQuoteProviderEvent*>(*pp);
				ret = pIQuoteProviderEvent->UpdateSymbol(lpszSymbol, lpszPrice, lpszChange, lpszOpen, lpszVolume);
			}
			pp++;
		}
		pT->Unlock();
		return ret;
	}
};

#endif