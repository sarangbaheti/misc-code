#include "stdafx.h"
#include "profile.h"

void WriteMyProfileString(LPCSTR lpSection,LPCSTR lpEntry,LPCSTR lpValue)
{
	HKEY hKey;
	DWORD dwResult;
	char szKey[255];
	DWORD dwLen=sizeof(szKey);
	CString cs;
	char *lpSoftware = "Software\\%s\\%s\\%s";

	wsprintf(szKey,lpSoftware,"Aaron Skonnard's MSJ StockWatcher","Stock Watcher",lpSection);
	RegCreateKeyEx(HKEY_CURRENT_USER,szKey,0,"",REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,&dwResult);
	RegSetValueEx(hKey,lpEntry,0L,REG_SZ,(CONST BYTE *)lpValue,lstrlen(lpValue)+1);
	RegCloseKey(hKey);
}

CString GetMyProfileString(LPCSTR lpSection,LPCSTR lpEntry,LPCSTR lpDefault)
{
	HKEY hKey;
	char szKey[255];
	DWORD dwLen=sizeof(szKey);
	CString cs;
	char *lpSoftware = "Software\\%s\\%s\\%s";

	if (lpDefault!=NULL)
		cs=lpDefault;
	wsprintf(szKey,lpSoftware,"Aaron Skonnard's MSJ StockWatcher","Stock Watcher",lpSection);

	if (RegOpenKeyEx(HKEY_CURRENT_USER,szKey,0,KEY_ALL_ACCESS,&hKey)==ERROR_SUCCESS)
	{
		if (RegQueryValueEx(hKey,lpEntry,NULL,NULL,(LPBYTE)szKey,&dwLen)==ERROR_SUCCESS) 
		{
			cs=szKey;
		}
		RegCloseKey(hKey);
	}
	return(cs);
}

