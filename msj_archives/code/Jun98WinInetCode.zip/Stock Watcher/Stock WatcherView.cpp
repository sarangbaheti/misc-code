// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//
// Stock WatcherView.cpp : implementation of the CStockWatcherView class
//

#include "stdafx.h"
#include "Stock Watcher.h"
#include "Stock WatcherDoc.h"
#include "Stock WatcherView.h"
#include "SymbolObj.h"
#include <commctrl.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStockWatcherView

IMPLEMENT_DYNCREATE(CStockWatcherView, CView)

BEGIN_MESSAGE_MAP(CStockWatcherView, CView)
	//{{AFX_MSG_MAP(CStockWatcherView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStockWatcherView construction/destruction

CStockWatcherView::CStockWatcherView()
{
}

CStockWatcherView::~CStockWatcherView()
{
}

BOOL CStockWatcherView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CStockWatcherView drawing

void CStockWatcherView::OnDraw(CDC* pDC)
{
	CStockWatcherDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	m_ListCtrl.Invalidate();
}

/////////////////////////////////////////////////////////////////////////////
// CStockWatcherView printing

BOOL CStockWatcherView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CStockWatcherView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

void CStockWatcherView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

/////////////////////////////////////////////////////////////////////////////
// CStockWatcherView diagnostics

#ifdef _DEBUG
void CStockWatcherView::AssertValid() const
{
	CView::AssertValid();
}

void CStockWatcherView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CStockWatcherDoc* CStockWatcherView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CStockWatcherDoc)));
	return (CStockWatcherDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CStockWatcherView message handlers

int CStockWatcherView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	CRect rect;
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	if (!m_ListCtrl.Create(WS_VISIBLE|WS_CHILD|LVS_REPORT, rect, this, ID_LIST_CONTROL))
		return -1;
	if (!m_ImageList.Create(IDB_SYMBOL_IMAGES, 15, 0, RGB(255,255,255)))
		return -1;
	ListView_SetExtendedListViewStyle(m_ListCtrl.GetSafeHwnd(),
		LVS_EX_FULLROWSELECT | 
		LVS_EX_GRIDLINES | 
		LVS_EX_HEADERDRAGDROP 
		);
	m_ListCtrl.SetImageList(&m_ImageList, LVSIL_SMALL);
	m_ListCtrl.InsertColumn(0, "Symbol", LVCFMT_LEFT, 100);
	m_ListCtrl.InsertColumn(1, "Price", LVCFMT_LEFT, 100);
	m_ListCtrl.InsertColumn(2, "Change", LVCFMT_LEFT, 100);
	m_ListCtrl.InsertColumn(3, "Open", LVCFMT_LEFT, 100);
	m_ListCtrl.InsertColumn(4, "Volume", LVCFMT_LEFT, 100);
	m_ListCtrl.InsertColumn(5, "Last Update", LVCFMT_LEFT, 100);
	return 0;
}

void CStockWatcherView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	RECT rect;
	GetClientRect(&rect);
	m_ListCtrl.MoveWindow(&rect);
}

void CStockWatcherView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
}

void CStockWatcherView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	m_ListCtrl.DeleteAllItems();	
	long lSize = GetDocument()->m_Objects.GetSize(), i;
	CStockSymbol* pSymbol;

	for (i=0; i<lSize; i++)
	{
		pSymbol = static_cast<CStockSymbol*>(GetDocument()->m_Objects.GetAt(i));

		LV_ITEM item;
		item.mask = LVIF_TEXT | LVIF_IMAGE;
		item.iItem = i;
		item.iSubItem = 0;
		item.cchTextMax = 255;
		item.pszText = pSymbol->m_strSymbol.GetBuffer(255);

		if (pSymbol->m_strChange.IsEmpty())
			item.iImage = 2;
		else if (pSymbol->m_strChange[0] == '-')
			item.iImage = 1;
		else 
			item.iImage = 0;

		// insert item in list ctrl & set column text info
		m_ListCtrl.InsertItem(&item);
		m_ListCtrl.SetItemText(item.iItem, 1, pSymbol->m_strPrice.GetBuffer(255));
		m_ListCtrl.SetItemText(item.iItem, 2, pSymbol->m_strChange.GetBuffer(255));
		m_ListCtrl.SetItemText(item.iItem, 3, pSymbol->m_strOpen.GetBuffer(255));
		m_ListCtrl.SetItemText(item.iItem, 4, pSymbol->m_strVolume.GetBuffer(255));

		if (pSymbol->m_dtLastUpdate.m_dt != 0)
			m_ListCtrl.SetItemText(item.iItem, 5, pSymbol->m_dtLastUpdate.Format("%c").GetBuffer(255));

		m_ListCtrl.EnsureVisible( item.iItem, TRUE );
	}
}

