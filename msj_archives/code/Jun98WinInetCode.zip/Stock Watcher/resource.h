//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Stock Watcher.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_STOCKWTYPE                  129
#define IDD_NEW_SYMBOL                  131
#define IDB_SYMBOL_IMAGES               132
#define IDD_DIALOG_PROVIDERS            133
#define IDC_EDIT_SYMBOL                 1001
#define IDC_COMBO_PROVIDERS             1005
#define ID_SYMBOL_NEW                   32771
#define ID_REFRESH_ALL_SYMBOLS          32772
#define ID_QUOTE_PROVIDER               32773
#define ID_SYMBOL_DELETE                32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
