// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//
// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Stock Watcher.h"
#include "Stock WatcherDoc.h"
#include "globals.h"
#include <wininet.h>
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_MESSAGE(WM_HTTP_THREAD_MESSAGE, OnHttpThreadMessage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	int cx, cy, x, y;
	
	CWinApp* pApp = AfxGetApp();

	cx = pApp->GetProfileInt(REG_KEY_SETTINGS, "cx", 300);
	cy = pApp->GetProfileInt(REG_KEY_SETTINGS, "cy", 150);
	x = pApp->GetProfileInt(REG_KEY_SETTINGS, "x", 50);
	y = pApp->GetProfileInt(REG_KEY_SETTINGS, "y", 50);
	
	MoveWindow(x, y, cx, cy);

	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	m_wndToolBar.ModifyStyle(0, TBSTYLE_FLAT);

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Remove this if you don't want tool tips or a resizeable toolbar
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::OnDestroy() 
{
	int cx, cy, x, y;
	RECT rect;

	GetWindowRect(&rect);
	cx = rect.right-rect.left;
	cy = rect.bottom-rect.top;

	CWinApp* pApp = AfxGetApp();
	cx = pApp->WriteProfileInt(REG_KEY_SETTINGS, "cx", cx);
	cy = pApp->WriteProfileInt(REG_KEY_SETTINGS, "cy", cy);
	x = pApp->WriteProfileInt(REG_KEY_SETTINGS, "x", rect.left);
	y = pApp->WriteProfileInt(REG_KEY_SETTINGS, "y", rect.top);

	CFrameWnd::OnDestroy();	
}

void CMainFrame::UpdateStatus(long lStatus)
{
	CString strStatus;

	switch (lStatus)
	{
	case INTERNET_STATUS_RESOLVING_NAME:
		strStatus = "resolving name...";
		break;

	case INTERNET_STATUS_NAME_RESOLVED:
		strStatus = "resolved name...";
		break;

	case INTERNET_STATUS_HANDLE_CREATED:
		strStatus = "handle created";
		break;

	case INTERNET_STATUS_CONNECTING_TO_SERVER:
		strStatus = "connecting to socket...";
		break;

	case INTERNET_STATUS_REQUEST_SENT:
		strStatus = "request sent!";
		break;

	case INTERNET_STATUS_SENDING_REQUEST:
		strStatus = "sending request...";
		break;

	case INTERNET_STATUS_CONNECTED_TO_SERVER:
		strStatus = "connected to socket address!";
		break;

	case INTERNET_STATUS_RECEIVING_RESPONSE:
		strStatus = "receiving response...";
		break;

	case INTERNET_STATUS_RESPONSE_RECEIVED:
		strStatus = "response received!";
		break;

	case INTERNET_STATUS_CLOSING_CONNECTION:
		strStatus = "closing connection...";
		break;

	case INTERNET_STATUS_CONNECTION_CLOSED:
		strStatus = "connection closed!";
		break;

	case INTERNET_STATUS_HANDLE_CLOSING:
		strStatus = "handle closed!";
		break;

	case INTERNET_STATUS_REQUEST_COMPLETE:
		strStatus = "request complete!";

	case INTERNET_STATUS_CTL_RESPONSE_RECEIVED:
	case INTERNET_STATUS_REDIRECT:
	default:
		strStatus = "Unknown status";
		break;
	}

	m_wndStatusBar.SetPaneText(0, strStatus);
}

LRESULT CMainFrame::OnHttpThreadMessage(WPARAM uID, LPARAM lEvent)
{
	switch(uID)
	{
	case UPDATE_ALL_VIEWS:
		GetActiveDocument()->UpdateAllViews(NULL);
		break;
	case UPDATE_STATUS:
		UpdateStatus(lEvent);
		break;
	}
	return 0;
}


