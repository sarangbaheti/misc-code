// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//

#if !defined(AFX_ADDSYMBOLDLG_H__06A29A12_9E47_11D1_B2AF_006008ACADF7__INCLUDED_)
#define AFX_ADDSYMBOLDLG_H__06A29A12_9E47_11D1_B2AF_006008ACADF7__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// AddSymbolDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAddSymbolDlg dialog

class CAddSymbolDlg : public CDialog
{
// Construction
public:
	CAddSymbolDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAddSymbolDlg)
	enum { IDD = IDD_NEW_SYMBOL };
	CString	m_strSymbol;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAddSymbolDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAddSymbolDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDSYMBOLDLG_H__06A29A12_9E47_11D1_B2AF_006008ACADF7__INCLUDED_)
