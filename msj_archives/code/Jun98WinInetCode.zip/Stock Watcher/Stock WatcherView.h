// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//
// Stock WatcherView.h : interface of the CStockWatcherView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_STOCKWATCHERVIEW_H__10BE7FCC_9CC7_11D1_9912_004033D06B6E__INCLUDED_)
#define AFX_STOCKWATCHERVIEW_H__10BE7FCC_9CC7_11D1_9912_004033D06B6E__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CStockWatcherView : public CView
{
protected: // create from serialization only
	CStockWatcherView();
	DECLARE_DYNCREATE(CStockWatcherView)

// Attributes
public:
	CStockWatcherDoc* GetDocument();
	CListCtrl m_ListCtrl;
	CImageList m_ImageList;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStockWatcherView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CStockWatcherView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CStockWatcherView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in Stock WatcherView.cpp
inline CStockWatcherDoc* CStockWatcherView::GetDocument()
   { return (CStockWatcherDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STOCKWATCHERVIEW_H__10BE7FCC_9CC7_11D1_9912_004033D06B6E__INCLUDED_)
