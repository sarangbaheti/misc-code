// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//

#if !defined(AFX_QUOTEPROVIDERDLG_H__60F8A4E3_9E82_11D1_9912_004033D06B6E__INCLUDED_)
#define AFX_QUOTEPROVIDERDLG_H__60F8A4E3_9E82_11D1_9912_004033D06B6E__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// QuoteProviderDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CQuoteProviderDlg dialog

class CQuoteProviderDlg : public CDialog
{
// Construction
public:
	CQuoteProviderDlg(CWnd* pParent = NULL);   // standard constructor
	HRESULT EnumQuoteProviders(CComboBox* pBox);
	CStringArray m_CLSIDs;

// Dialog Data
	//{{AFX_DATA(CQuoteProviderDlg)
	enum { IDD = IDD_DIALOG_PROVIDERS };
	CComboBox	m_cbQuoteProviders;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQuoteProviderDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CQuoteProviderDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_QUOTEPROVIDERDLG_H__60F8A4E3_9E82_11D1_9912_004033D06B6E__INCLUDED_)
