// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//
// Stock WatcherDoc.h : interface of the CStockWatcherDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_STOCKWATCHERDOC_H__10BE7FCA_9CC7_11D1_9912_004033D06B6E__INCLUDED_)
#define AFX_STOCKWATCHERDOC_H__10BE7FCA_9CC7_11D1_9912_004033D06B6E__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "..\HttpObjectServer\HttpObjectServer.h"
#include "..\QuoteProviders\QuoteProviders.h"
#include "SymbolObj.h"


class CStockWatcherDoc;

class CQuoteProviderEventSink : 
	public CComObjectRoot,
	public IQuoteProviderEvent
{
public:
	CQuoteProviderEventSink() {}
BEGIN_COM_MAP(CQuoteProviderEventSink)
	COM_INTERFACE_ENTRY(IQuoteProviderEvent)
END_COM_MAP()

	CStockWatcherDoc* m_pDoc;

// IHttpEvent
	STDMETHOD(UpdateSymbol)(LPCTSTR lpszSymbol, LPCTSTR lpszPrice, LPCTSTR lpszChange, LPCTSTR lpszOpen, LPCTSTR lpszVolume);
};

class CStockWatcherDoc : public CDocument
{
protected: // create from serialization only
	CStockWatcherDoc();
	DECLARE_DYNCREATE(CStockWatcherDoc)
	
	CComObject<CQuoteProviderEventSink>* m_pQuoteProviderEventSink;

	CPtrArray m_arrIHttpRequests;
	CDWordArray m_arrConnections;

	void EmptySymbolList();
	CStockSymbol* FindObjectBySymbol(LPCTSTR lpszSymbol);

// Attributes
public:
	CObArray m_Objects;
	
	void UpdateSymbol(LPCTSTR lpszSymbol, LPCTSTR lpszPrice="", LPCTSTR lpszChange="", 
			LPCTSTR lpszOpen="", LPCTSTR lpszVolume="");

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStockWatcherDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CStockWatcherDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CStockWatcherDoc)
	afx_msg void OnSymbolNew();
	afx_msg void OnRefreshAllSymbols();
	afx_msg void OnQuoteProvider();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STOCKWATCHERDOC_H__10BE7FCA_9CC7_11D1_9912_004033D06B6E__INCLUDED_)
