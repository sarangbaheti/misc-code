// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//
// AddSymbolDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Stock Watcher.h"
#include "AddSymbolDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddSymbolDlg dialog


CAddSymbolDlg::CAddSymbolDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAddSymbolDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAddSymbolDlg)
	m_strSymbol = _T("");
	//}}AFX_DATA_INIT
}


void CAddSymbolDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddSymbolDlg)
	DDX_Text(pDX, IDC_EDIT_SYMBOL, m_strSymbol);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddSymbolDlg, CDialog)
	//{{AFX_MSG_MAP(CAddSymbolDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddSymbolDlg message handlers
