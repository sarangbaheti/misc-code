// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//
// Stock Watcher.h : main header file for the STOCK WATCHER application
//

#if !defined(AFX_STOCKWATCHER_H__10BE7FC4_9CC7_11D1_9912_004033D06B6E__INCLUDED_)
#define AFX_STOCKWATCHER_H__10BE7FC4_9CC7_11D1_9912_004033D06B6E__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

#define ID_LIST_CONTROL 1000


/////////////////////////////////////////////////////////////////////////////
// CStockWatcherApp:
// See Stock Watcher.cpp for the implementation of this class
//

class CStockWatcherApp : public CWinApp
{
public:
	CStockWatcherApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStockWatcherApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CStockWatcherApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STOCKWATCHER_H__10BE7FC4_9CC7_11D1_9912_004033D06B6E__INCLUDED_)
