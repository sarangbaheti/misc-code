// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//

#ifndef __SYMBOLOBJ_H__
#define __SYMBOLOBJ_H__

class CStockSymbol : public CObject
{
public:
	DECLARE_SERIAL(CStockSymbol);
	CStockSymbol() {};
	~CStockSymbol() {};

	CString m_strSymbol;
	CString m_strPrice;
	CString m_strChange;
	CString m_strOpen;
	CString m_strVolume;
	COleDateTime m_dtLastUpdate;

	void Serialize( CArchive& ar ) 
	{ 
		CObject::Serialize( ar );
		if( ar.IsStoring() )
			ar << m_strSymbol << m_strPrice << m_strChange << m_strOpen << m_strVolume << m_dtLastUpdate;   
		else     
			ar >> m_strSymbol >> m_strPrice >> m_strChange >> m_strOpen >> m_strVolume >> m_dtLastUpdate;   
	}
};

#endif