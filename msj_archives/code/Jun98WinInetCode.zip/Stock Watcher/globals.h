// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//

#define REG_KEY_SETTINGS		"Settings"
#define WM_HTTP_THREAD_MESSAGE	WM_USER+1
#define UPDATE_ALL_VIEWS		0
#define UPDATE_STATUS			1

