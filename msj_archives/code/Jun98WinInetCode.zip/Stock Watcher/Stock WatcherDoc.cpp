// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//
// Stock WatcherDoc.cpp : implementation of the CStockWatcherDoc class
//

#include "stdafx.h"
#include "Stock Watcher.h"
#include "Stock WatcherDoc.h"
#include "Mainfrm.h"
#include "AddSymbolDlg.h"
#include "QuoteProviderDlg.h"
#include "..\QuoteProviders\QuoteProviders.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CStockSymbol, CObject, 1);

/////////////////////////////////////////////////////////////////////////////
// CStockWatcherDoc

IMPLEMENT_DYNCREATE(CStockWatcherDoc, CDocument)

BEGIN_MESSAGE_MAP(CStockWatcherDoc, CDocument)
	//{{AFX_MSG_MAP(CStockWatcherDoc)
	ON_COMMAND(ID_SYMBOL_NEW, OnSymbolNew)
	ON_COMMAND(ID_REFRESH_ALL_SYMBOLS, OnRefreshAllSymbols)
	ON_COMMAND(ID_QUOTE_PROVIDER, OnQuoteProvider)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStockWatcherDoc construction/destruction

CStockWatcherDoc::CStockWatcherDoc()
{
	//create and initialized the CQuoteProviderEventSink object
	CComObject<CQuoteProviderEventSink>::CreateInstance(&m_pQuoteProviderEventSink);
	m_pQuoteProviderEventSink->AddRef();
	m_pQuoteProviderEventSink->m_pDoc = this;
}

CStockWatcherDoc::~CStockWatcherDoc()
{
	EmptySymbolList();

	//release all IHttpRequest interfaces
	long lSize = m_arrConnections.GetSize(), i;
	for (i=0; i<lSize; i++)
	{
		IHttpRequest* pRequest = static_cast<IHttpRequest*>(m_arrIHttpRequests.GetAt(i));
		IQuoteProvider* pProvider = NULL;
		pRequest->GetProviderInterface(reinterpret_cast<IUnknown**>(&pProvider));
		if (pProvider)
			AtlUnadvise(pProvider, IID_IQuoteProviderEvent, m_arrConnections.GetAt(i));
		pRequest->Release();
	}
	//release the CQuoteProviderEventSink
	m_pQuoteProviderEventSink->Release();
}

void CStockWatcherDoc::EmptySymbolList()
{
	while (m_Objects.GetSize())
	{
		CStockSymbol* pSymbol = static_cast<CStockSymbol*>(m_Objects.GetAt(0));
		if (pSymbol) 
			delete pSymbol;
		m_Objects.RemoveAt(0);
	}
}

BOOL CStockWatcherDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	EmptySymbolList();

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CStockWatcherDoc serialization

void CStockWatcherDoc::Serialize(CArchive& ar)
{
	m_Objects.Serialize(ar);

	if (ar.IsStoring())
	{
	}
	else
	{
	}
}

/////////////////////////////////////////////////////////////////////////////
// CStockWatcherDoc diagnostics

#ifdef _DEBUG
void CStockWatcherDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CStockWatcherDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CStockWatcherDoc commands

void CStockWatcherDoc::OnSymbolNew() 
{
	CAddSymbolDlg dlg;
	if (IDOK==dlg.DoModal())
	{
		if (dlg.m_strSymbol.IsEmpty())
			return;

		CStockSymbol *pSymbol = new CStockSymbol;
		pSymbol->m_strSymbol = dlg.m_strSymbol;
		pSymbol->m_strSymbol.MakeUpper();
		m_Objects.Add(pSymbol);
		SetModifiedFlag();
		UpdateAllViews(NULL);
	}	
}


BOOL CStockWatcherDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	EmptySymbolList();

	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;
	
	return TRUE;
}


void CStockWatcherDoc::OnRefreshAllSymbols() 
{
	long lSize = m_Objects.GetSize(), i;
	CStockSymbol* pSymbol;
	CString strSymbols, strCLSID;
	DWORD dwConnection;

	if (lSize == 0)
		return;

	//get the currently selected quote provider's CLSID
	strCLSID = AfxGetApp()->GetProfileString("Settings", "ProviderCLSID", "");
	if (strCLSID.IsEmpty())
		return;
	
	LPOLESTR lpszCLSID;
	USES_CONVERSION;
	lpszCLSID = A2W(strCLSID.GetBuffer(255));
	CLSID clsid;

	//convert from string to CLSID
	CLSIDFromString(lpszCLSID, &clsid);

	for (i=0; i<lSize; i++)
	{
		pSymbol = static_cast<CStockSymbol*>(m_Objects.GetAt(i));
		if (i == 0)
			strSymbols += pSymbol->m_strSymbol;	
		else strSymbols += ' ' + pSymbol->m_strSymbol;
	}

	//create the IHttpRequest component
	IHttpRequest* pRequest = NULL;
	CoCreateInstance(CLSID_HttpRequest, NULL, CLSCTX_ALL, IID_IHttpRequest, (void**)&pRequest);
	_ASSERTE(pRequest != NULL);
	m_arrIHttpRequests.Add(pRequest);

	//create the IQuoteProvider component
	IQuoteProvider *pQuoteProvider = NULL;
	CoCreateInstance(clsid, NULL, CLSCTX_ALL, IID_IQuoteProvider, (void**)&pQuoteProvider);
	_ASSERTE(pQuoteProvider != NULL);

	//establish the connection point
	AtlAdvise(pQuoteProvider, m_pQuoteProviderEventSink->GetUnknown(), IID_IQuoteProviderEvent, &dwConnection);
	m_arrConnections.Add(dwConnection);

	//initialize the data (strSymbols)
	pQuoteProvider->InitializeData(strSymbols.GetBuffer(255));

	//call ProcessRequest
	pRequest->ProcessRequest(pQuoteProvider, reinterpret_cast<long>(AfxGetMainWnd()->GetSafeHwnd()));
	
	//release IQuoteProvider, let the IHttpRequest object manage lifetime
	pQuoteProvider->Release();
}

void CStockWatcherDoc::UpdateSymbol(LPCTSTR lpszSymbol, LPCTSTR lpszPrice, LPCTSTR lpszChange,
		LPCTSTR lpszOpen, LPCTSTR lpszVolume)
{
	CStockSymbol* pSymbol = FindObjectBySymbol(lpszSymbol);
	pSymbol->m_strPrice = lpszPrice;
	pSymbol->m_strChange = lpszChange;
	pSymbol->m_strOpen = lpszOpen;
	pSymbol->m_strVolume = lpszVolume;
	pSymbol->m_dtLastUpdate = COleDateTime::GetCurrentTime();
	SetModifiedFlag();
}

CStockSymbol* CStockWatcherDoc::FindObjectBySymbol(LPCTSTR lpszSymbol)
{
	long lSize = m_Objects.GetSize(), i;
	CStockSymbol* pSymbol=NULL;

	for (i=0; i<lSize; i++)
	{
		pSymbol = static_cast<CStockSymbol*>(m_Objects.GetAt(i));
		if (pSymbol->m_strSymbol.CompareNoCase(lpszSymbol) == 0)
			return pSymbol;
	}
	return pSymbol;
}

void CStockWatcherDoc::OnQuoteProvider() 
{
	CQuoteProviderDlg dlg;
	dlg.DoModal();
}

STDMETHODIMP CQuoteProviderEventSink::UpdateSymbol(LPCTSTR lpszSymbol, LPCTSTR lpszPrice, LPCTSTR lpszChange, LPCTSTR lpszOpen, LPCTSTR lpszVolume)
{
	m_pDoc->UpdateSymbol(lpszSymbol, lpszPrice, lpszChange, lpszOpen, lpszVolume);
	return S_OK;
}

