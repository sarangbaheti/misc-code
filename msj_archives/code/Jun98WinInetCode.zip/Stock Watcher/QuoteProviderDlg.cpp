// Copyright (c) 1998, Microsoft Systems Journal
// Author: Aaron Skonnard
//
// QuoteProviderDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Stock Watcher.h"
#include "QuoteProviderDlg.h"
#include <comcat.h>
#include "..\QuoteProviders\CategoryGuid.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CQuoteProviderDlg dialog


CQuoteProviderDlg::CQuoteProviderDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CQuoteProviderDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CQuoteProviderDlg)
	//}}AFX_DATA_INIT
}


void CQuoteProviderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CQuoteProviderDlg)
	DDX_Control(pDX, IDC_COMBO_PROVIDERS, m_cbQuoteProviders);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CQuoteProviderDlg, CDialog)
	//{{AFX_MSG_MAP(CQuoteProviderDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CQuoteProviderDlg message handlers

BOOL CQuoteProviderDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	HRESULT hr = EnumQuoteProviders(&m_cbQuoteProviders);
	if (FAILED(hr))
		AfxMessageBox("Error enumerating component category");

	CString strCLSID = AfxGetApp()->GetProfileString("Settings", "ProviderCLSID", "");
	if (!strCLSID.IsEmpty())
	{
		long lCount = m_cbQuoteProviders.GetCount();
		for (long i=0; i<lCount; i++)
		{
			if ( (m_CLSIDs.GetAt(i)) == strCLSID )
				break;
		}
		if (i == lCount) i = 0;
		m_cbQuoteProviders.SetCurSel(i);
	}
	else m_cbQuoteProviders.SetCurSel(0);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


HRESULT CQuoteProviderDlg::EnumQuoteProviders(CComboBox* pBox)
{
    ICatInformation* pci = NULL ;
    HRESULT hr = S_OK ;

    hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr, 
            NULL, CLSCTX_INPROC_SERVER, IID_ICatInformation, (void**)&pci);
    if (FAILED(hr))
        return hr;

	CATID arrCATID[1];
	arrCATID[0] = CATID_QuoteProviders;

	IEnumCLSID* penumCLSID = NULL;
	pci->EnumClassesOfCategories(1, arrCATID, 0, 0, &penumCLSID);
	if (FAILED(hr))
	{
		pci->Release();
		return hr;
	}

	ULONG lItems=1, lIndex=0;
	hr = penumCLSID->Next(1, arrCATID, NULL);
	while (S_OK == hr)
	{
		USES_CONVERSION;
		LPOLESTR lpszDisplay, lpszCLSIDString;
		char* lpszAnsiDisplay, *lpszAnsiClassString;
		CString strGUID;

		OleRegGetUserType(arrCATID[0], USERCLASSTYPE_FULL, &lpszDisplay);
		lpszAnsiDisplay = W2A(lpszDisplay);
		pBox->AddString(lpszAnsiDisplay);
		StringFromCLSID(arrCATID[0], &lpszCLSIDString);
		lpszAnsiClassString = W2A(lpszCLSIDString);
		m_CLSIDs.Add(lpszAnsiClassString);
		hr = penumCLSID->Next(1, arrCATID, NULL);
		lIndex++;
	}

	pci->Release();
	penumCLSID->Release();

    return S_OK;
}

void CQuoteProviderDlg::OnOK() 
{
	long lCurSel = m_cbQuoteProviders.GetCurSel();
	if (CB_ERR == lCurSel)
		return;
	ASSERT( (lCurSel >= 0) && (lCurSel <= m_CLSIDs.GetUpperBound()) );
	CString strCLSID = AfxGetApp()->GetProfileString("Settings", "ProviderCLSID", "");
	if (strCLSID != m_CLSIDs.GetAt(lCurSel))
	{
		AfxGetApp()->WriteProfileString("Settings", "username", "");
		AfxGetApp()->WriteProfileString("Settings", "password", "");
	}
	AfxGetApp()->WriteProfileString("Settings", "ProviderCLSID", m_CLSIDs.GetAt(lCurSel));
	CDialog::OnOK();
}
