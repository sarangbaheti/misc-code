////////////////////////////////////////////////////////////////
// ROPView 1997 Microsoft Systems Journal
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "CoolMenu.h"

/////////////////
// Main frame window has menu manager, cool bar, status bar
//
class CMainFrame : public CFrameWnd {
public:
	CMainFrame();
	~CMainFrame();

protected:
	DECLARE_DYNCREATE(CMainFrame)
	CCoolMenuManager	   m_menuManager;	 // manages button menus
	CMenu						m_contextMenu;	 // right-click menu
	CStatusBar				m_wndStatusBar; // standard status bar
	CToolBar					m_wndToolBar;	 // toolbar

	// overrides
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	// message handlers
	DECLARE_MESSAGE_MAP()
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint pos);

	// command handlers
	afx_msg void OnColorDisabled();
	afx_msg void OnUpdateColorDisabled(CCmdUI* pCmdUI);
	afx_msg void OnViewMenuButtons();
	afx_msg void OnUpdateViewMenuButtons(CCmdUI* pCmdUI);
	afx_msg void OnViewWhich(UINT nID);
	afx_msg void OnUpdateViewWhich(CCmdUI* pCmdUI);
};
