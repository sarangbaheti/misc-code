////////////////////////////////////////////////////////////////
// RopView 1997 Microsoft Systems Journal
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "StdAfx.h"
#include "MainFrm.h"
#include "View.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define ID_VIEW_WHICHLAST ID_VIEW_WHICH4

////////////////////////////////////////////////////////////////
// CMainFrame
//
IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_COMMAND(ID_COLOR_DISABLE,				 OnColorDisabled)
	ON_UPDATE_COMMAND_UI(ID_COLOR_DISABLE,  OnUpdateColorDisabled)

	ON_COMMAND(ID_VIEW_MENU_BUTTONS,				 OnViewMenuButtons)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MENU_BUTTONS, OnUpdateViewMenuButtons)

	ON_COMMAND_RANGE(ID_VIEW_WHICH0, ID_VIEW_WHICHLAST,	OnViewWhich)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VIEW_WHICH0,ID_VIEW_WHICHLAST,
		OnUpdateViewWhich)

	ON_WM_CREATE()
	ON_WM_CONTEXTMENU()
END_MESSAGE_MAP()

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

////////////////
// Override flicker-free drawing with no CS_VREDRAW and CS_HREDRAW. This has
// nothing to do with ToolBars, but I it's a good thing to do.
//
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
   cs.lpszClass = AfxRegisterWndClass(
      0,											 // no redraw
      NULL,                             // no cursor (use default)
      NULL,                             // no background brush
      AfxGetApp()->LoadIcon(IDR_MAINFRAME)); // app icon
	cs.style &= ~FWS_ADDTOTITLE;
   ASSERT(cs.lpszClass);
   return CFrameWnd::PreCreateWindow(cs);
}

//////////////////
// Create handler creates control bars
//
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	VERIFY(CFrameWnd::OnCreate(lpCreateStruct) == 0);

	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	// Create status bar
	static UINT indicators[] = {
		ID_SEPARATOR, ID_INDICATOR_CAPS, ID_INDICATOR_NUM, ID_INDICATOR_SCRL };

	VERIFY(m_wndStatusBar.Create(this));
	VERIFY(m_wndStatusBar.SetIndicators(indicators,
		sizeof(indicators)/sizeof(indicators[0])));
		
	// install/load cool menus
	m_menuManager.Install(this);
	m_menuManager.LoadToolbar(IDR_MAINFRAME);

	return 0;
}

//////////////////
// User right-clicked: display a context menu.
//
void CMainFrame::OnContextMenu(CWnd* pWnd, CPoint p)
{
	if (!m_contextMenu) {
		// one-time load: context menu is 1st submenu in resource menu
		CMenu menu;
		VERIFY(menu.LoadMenu(IDR_MYCONTEXTMENU));
		m_contextMenu.Attach(::GetSubMenu(menu, 0));
		menu.Detach(); // otherwise destructor will destroy my menu!
	}
	ASSERT_VALID(&m_contextMenu);
	m_contextMenu.TrackPopupMenu(0, p.x, p.y, this);
}

//////////////////
// Command handlers for View | Hide/Show Menu Buttons
//
void CMainFrame::OnViewMenuButtons()
{
	m_menuManager.m_bShowButtons = !m_menuManager.m_bShowButtons;
}
void CMainFrame::OnUpdateViewMenuButtons(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_menuManager.m_bShowButtons);
	pCmdUI->SetText(m_menuManager.m_bShowButtons ?
		_T("Hide &Menu Buttons") : _T("Show &Menu Buttons"));
}

//////////////////
// Command handlers for View | All, Image List, etc.
//
void CMainFrame::OnViewWhich(UINT nID)
{
	CMyView* pView = (CMyView*)GetActiveView();
	ASSERT_KINDOF(CMyView, pView);
	UINT nWhich = pView->SetWhichView(nID-ID_VIEW_WHICH0);
}
void CMainFrame::OnUpdateViewWhich(CCmdUI* pCmdUI)
{
	CMyView* pView = (CMyView*)GetActiveView();
	ASSERT_KINDOF(CMyView, pView);
	pCmdUI->SetRadio(pView->GetWhichView() == pCmdUI->m_nID - ID_VIEW_WHICH0);
}

////////////////
// Toggle whether to draw disabled buttons in color
//
void CMainFrame::OnColorDisabled()
{
	m_menuManager.m_bDrawDisabledButtonsInColor =
		!m_menuManager.m_bDrawDisabledButtonsInColor;
}
void CMainFrame::OnUpdateColorDisabled(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_menuManager.m_bDrawDisabledButtonsInColor);
}
