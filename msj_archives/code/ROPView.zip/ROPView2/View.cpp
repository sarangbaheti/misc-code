////////////////////////////////////////////////////////////////
// 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "StdAfx.h"
#include "Resource.h"
#include "MainFrm.h"
#include "View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define ID_VCOLOR_FIRST ID_VIEW_WINDOW
#define ID_VCOLOR_LAST  ID_VIEW_BLUE

////////////////////////////////////////////////////////////////
// CMyView
//
IMPLEMENT_DYNCREATE(CMyView, CView)

BEGIN_MESSAGE_MAP(CMyView, CView)
	ON_COMMAND(ID_VIEW_BGCOLOR,										 OnViewCustomColor)
	ON_COMMAND_RANGE(ID_VCOLOR_FIRST,ID_VCOLOR_LAST,			 OnViewColor)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VCOLOR_FIRST,ID_VCOLOR_LAST,OnUpdateViewColor)
END_MESSAGE_MAP()

int CXBUTTON = 16; // width..
int CYBUTTON = 15; // ..and height of button bitmap

// These are the different colors used
static COLORREF colors[5] = {
	0, // window color, filled in at runtime
	0,	// 3d face color, filled in at runtime
	RGB(255,0,0), // red
	RGB(0,255,0), // green
	RGB(0,0,255), // blue
};

CMyView::CMyView()
{
	m_nWhichView = DISP_ALL; // show all displays to start
	m_colorBG = -1;			 // set bg color invalid
	colors[0] = GetSysColor(COLOR_WINDOW);
	colors[1] = GetSysColor(COLOR_3DFACE);
	m_colorBG = colors[0];	 // default bg color = window color
}

//////////////////
// Set which view to view. Values define by the enum for m_nWhichView
// 
UINT CMyView::SetWhichView(UINT nWhichView)
{
	ASSERT(0 <= nWhichView && nWhichView < DISP_LAST);
	(UINT&)m_nWhichView = nWhichView; // (cast to get rid of enum)
	Invalidate();							 // repaint
	return m_nWhichView;
}

////////////////
// Override for flicker-free drawing with no CS_VREDRAW and CS_HREDRAW.
// This has nothing to do with CoolUI, it's just a good thing to do.
//
BOOL CMyView::PreCreateWindow(CREATESTRUCT& cs)
{
   cs.lpszClass = AfxRegisterWndClass(
		CS_DBLCLKS,								 // no redraw
      LoadCursor(NULL, IDC_ARROW),		 // arrow cursor
		NULL,										 // no background brush
		NULL);									 // no icon
   ASSERT(cs.lpszClass);
   return CView::PreCreateWindow(cs);
}

//////////////////
// Command handler: run color dialog to set arbitrary background color
//
void CMyView::OnViewCustomColor()
{
	CColorDialog dlg;
	if (dlg.DoModal() != IDCANCEL) {
		m_colorBG = dlg.GetColor();
		Invalidate();
	}
}

//////////////////
// Command and UI update handler: set predefined background color
//
void CMyView::OnViewColor(UINT nID)
{
	m_colorBG = colors[nID - ID_VCOLOR_FIRST];
	Invalidate();
}
void CMyView::OnUpdateViewColor(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_colorBG == colors[pCmdUI->m_nID - ID_VCOLOR_FIRST]);
}

#define countof(x)	(sizeof(x)/sizeof(x[0]))

//////////////////
// Main drawing function draws the images in an image list with different
// styles depending on which view is selected (m_nWhichView)
//
void CMyView::OnDraw(CDC* pDC)
{
	CBitmap& bmToolbar = m_bmToolbar;	 // so I don't have to type so much
	CImageList& il = m_ilToolbar;			 // ditto

	if (!(HBITMAP)bmToolbar) {
		// one-time initialization: load the bitmap.
		// use same color depth as screen to get full effect of ILD_BLENDxx.
		int nBitsPixel = pDC->GetDeviceCaps(BITSPIXEL);
		bmToolbar.Attach(PxLib::LoadSysColorBitmap(IDR_MAINFRAME));
		VERIFY(il.Create(CXBUTTON, CYBUTTON, ILC_MASK | nBitsPixel, 0, 10));
		il.Add(&bmToolbar, GetSysColor(COLOR_3DFACE));
	}

	// First, set up the dc
	CDC& dc = *pDC;
	CRect rcc;
	GetClientRect(&rcc);						 // client rect to draw in
	CBrush brush(m_colorBG);				 // background brush
	CBrush *pOldBrush = dc.SelectObject(&brush);
	dc.PatBlt(0, 0, rcc.Width(), rcc.Height(), PATCOPY);  // fill bg
	dc.SetBkMode(TRANSPARENT);				 // draw text transparently text
	CPoint p = (0,0);							 // point to draw at

	// create brushes
	CBrush brFace(GetSysColor(COLOR_3DFACE));
	CBrush brShadow(GetSysColor(COLOR_3DSHADOW));
	CBrush brHilite(GetSysColor(COLOR_3DHILIGHT));

	struct {
		HBRUSH br;							 // brush to use
		LPCTSTR name;						 // name of brush
	} btable[] = {
		{ brFace,   _T("3D face") },
		{ brShadow, _T("3D shadow") },
		{ brHilite, _T("3D hilite") },
		{ (HBRUSH)GetStockObject(BLACK_BRUSH),_T("Black") }
	};

	if (m_nWhichView==DISP_DRAWSTATEICON || m_nWhichView==DISP_ALL) {
		// use DrawState, with icons
		dc.TextOut(0, p.y, CString(_T("DrawState/Icons:")));
		p.y += CYBUTTON;
		for (int i=0; i < countof(btable); i++)
			ShowDSStyles(dc, il, p, btable[i].br, btable[i].name, TRUE);
	}

	if (m_nWhichView==DISP_DRAWSTATEBITMAP || m_nWhichView==DISP_ALL) {
		// use DrawState, with bitmaps
		dc.TextOut(0, p.y, CString(_T("DrawState/Bitmaps:")));
		p.y += CYBUTTON;
		for (int i=0; i < countof(btable); i++)
			ShowDSStyles(dc, il, p, btable[i].br, btable[i].name, FALSE);
	}

	if (m_nWhichView==DISP_IMGLIST || m_nWhichView==DISP_ALL) {
		// use ImageList_Draw
		dc.TextOut(0, p.y, CString(_T("ImageList_Draw:")));
		p.y += CYBUTTON;

		// Names of all the ILD_xxx flags
		static struct {
			UINT		code;
			LPCTSTR  name;
		} styles []= {
			{ ILD_IMAGE,		_T("ILD_IMAGE") },
			{ ILD_MASK,			_T("ILD_MASK") },
			{ ILD_NORMAL,		_T("ILD_NORMAL") },
			{ ILD_TRANSPARENT,_T("ILD_TRANSPARENT") },
			{ ILD_BLEND25,		_T("ILD_BLEND25") },
			{ ILD_BLEND50,		_T("ILD_BLEND50") },
		};

		int nImage = il.GetImageCount();
		for (int i=0; i < countof(styles); i++) {		// for each ILD_ style:
			p.x = 0;												//  start at left
			for (int j=0; j<nImage; j++) {				//  for each image:
				il.Draw(&dc, j, p, styles[i].code);		//   draw image with style
				p.x += CXBUTTON;								//   move left one image
			}														// 
			dc.TextOut(p.x, p.y, styles[i].name);		//  .. of ILD_ style
			p.y+=CYBUTTON;										//  next row/style
		}
	}

	if (m_nWhichView==DISP_ROP || m_nWhichView==DISP_ALL) {
		// draw the ROP view
		dc.TextOut(0, p.y, _T("Manual BitBlt ROPs to get embossed look:"));
		p.y += CYBUTTON;

		// create memory device context
		static CDC memdc;
		if (!memdc)
			memdc.CreateCompatibleDC(&dc);

		// create monochrome bitmap size of one button
		static CBitmap bmMono;
		if (!(HBITMAP)bmMono)
			bmMono.CreateBitmap(CXBUTTON, CYBUTTON, 1, 1, NULL);

		memdc.SelectObject(&bmMono); // never de-selected!

		int nImage = il.GetImageCount();
		int yTop = p.y;
		p.x = 0;

		for (int i=0; i<nImage; i++) {
			// 0. draw normal image
			il.Draw(&dc, i, p, ILD_NORMAL);
			p.y += CYBUTTON;

			// 1. convert to mono with white background
			memdc.PatBlt(0, 0,CXBUTTON, CYBUTTON, WHITENESS);
			il.Draw(&memdc, i, CPoint(0,0), ILD_TRANSPARENT);
			dc.BitBlt(p.x, p.y,CXBUTTON, CYBUTTON, &memdc, 0, 0, SRCCOPY);
			p.y += CYBUTTON;

			// 2. map black->hilite, white->transparent with magic ROP 0xb8074a
			dc.SelectObject(&brHilite);
			dc.BitBlt(p.x, p.y, CXBUTTON, CYBUTTON, &memdc, 0, 0, 0xb8074a);
			p.y += CYBUTTON;

			// 3. map black->shadow, white->transparent with magic ROP 0xb8074a
			dc.SelectObject(&brShadow);
			dc.BitBlt(p.x, p.y, CXBUTTON, CYBUTTON, &memdc, 0, 0, 0xb8074a);
			p.y += CYBUTTON;

			// 4. combine 2 & 3, with #2 offset by one pixel
			dc.SelectObject(&brHilite);
			dc.BitBlt(p.x+1, p.y+1, CXBUTTON, CYBUTTON, &memdc, 0, 0, 0xb8074a);
			dc.SelectObject(&brShadow);
			dc.BitBlt(p.x, p.y, CXBUTTON, CYBUTTON, &memdc, 0, 0, 0xb8074a);
//			PxLib::DrawEmbossed(dc, il, i, p);
			p.y += CYBUTTON;

			// 5. use library function to do color
			PxLib::DrawEmbossed(dc, il, i, p, TRUE);

			p.x += CXBUTTON; // next button
			p.y = yTop;		  // back to top
		}
		// display message strings
		LPCTSTR strings[] = {
			_T("0. original bitmap."),
			_T("1. convert to monochrome."),
			_T("2. convert to hilite with ROP 0xb8074a"),
			_T("3. convert to shadow with ROP 0xb8074a"),
			_T("4. combine hilite/shadow ==> embossed!"),
			_T("5. color embossed.")
		};
		for (i=0; i < countof(strings); i++) {
			dc.TextOut(p.x, p.y, strings[i]);
			p.y += CYBUTTON;
		}
	}
	dc.SelectObject(pOldBrush);
}

//////////////////
// Helper to draw images using DrawState with different
// DSS_ styles and a given brush.
//
void CMyView::ShowDSStyles(CDC& dc, // dc to draw in
	CImageList& il,						// list of images
	CPoint& p,								// point to draw at (updated)
	HBRUSH hbr,								// handle of brush to use
	LPCTSTR lpBrushName,					// name of brush for text message
	BOOL bIcon)								// TRUE for icon, FALSE for bitmap
{
	// static array of DSS_ styles and names
	static struct {
		DWORD		code;
		LPCTSTR	name;
	} dssStyles [] =	{
		{ DSS_NORMAL,	_T("DSS_NORMAL")},
		{ DSS_UNION,	_T("DSS_UNION") },
		{ DSS_DISABLED,_T("DSS_DISABLED") },
		{ DSS_MONO,		_T("DSS_MONO") }
	};

	int nImage = il.GetImageCount();						//  number of images
	for (int i=0; i < countof(dssStyles); i++) {		// for each DSS_ style:
		p.x = 0;													// start at left
		if (bIcon) {
			// draw using icons
			for (int j=0; j<nImage; j++) {	//  for each image:
				HICON hIcon=il.ExtractIcon(j);//   extract as icon and draw
				ASSERT(hIcon);
				// use overloaded CDC::DrawState for icons
				dc.DrawState(p, CSize(0,0), hIcon, dssStyles[i].code, hbr);
				DestroyIcon(hIcon);
				p.x += CXBUTTON;					//   next image/column
			}
		} else {
			// draw using bitmaps
			dc.DrawState(p, CSize(0,0), m_bmToolbar, dssStyles[i].code, hbr);
			p.x += CXBUTTON * nImage;			// width = nIage * width of each
		}
		CString s;
		s.Format(_T("%s / %s"), dssStyles[i].name, lpBrushName);
		dc.TextOut(p.x, p.y, s);
		p.y += CYBUTTON;
	}
}
