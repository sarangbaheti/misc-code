/////////////////
// Standard MFC view class for the image viewer. There are four different
// "views" that can be displayed, defined by the enum below--or a fifth
// view that displays them all.
//
class CMyView : public CView {
private:
	CBitmap		m_bmToolbar;		// toolbar bitmap
	CImageList	m_ilToolbar;		// same, as image list
	enum {
		DISP_ALL,						// show all vies
		DISP_IMGLIST,					// draw with image list
		DISP_DRAWSTATEICON,			// draw with DrawState/icons
		DISP_DRAWSTATEBITMAP,		// draw with DrawState/bitmap
		DISP_ROP,						// draw with custom ROP for embossed look
		DISP_LAST } m_nWhichView;	// what to view (one of above enum)
	COLORREF m_colorBG;				// background color

	// OnDraw helper
	void ShowDSStyles(CDC& dc, CImageList& il, CPoint& p, HBRUSH hbr,
		LPCTSTR lpBrushName, BOOL bIcon);

public:
	DECLARE_DYNCREATE(CMyView)
	CMyView();

	// Functions called from CMainFrame to control the view
	UINT SetWhichView(UINT iWhichView);
	UINT GetWhichView() { return m_nWhichView; }

	// overrides
	virtual void OnDraw(CDC* pDC);
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	// command handlers
	DECLARE_MESSAGE_MAP()
	afx_msg void OnViewCustomColor();
	afx_msg void OnViewColor(UINT nID);
	afx_msg void OnUpdateViewColor(CCmdUI* pCmdUI);
};

