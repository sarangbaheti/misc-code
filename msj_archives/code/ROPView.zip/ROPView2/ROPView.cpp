////////////////////////////////////////////////////////////////
// ROPView 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "StdAfx.h"
#include "ROPView.h"
#include "MainFrm.h"
#include "Doc.h"
#include "View.h"
#include "TraceWin.h"
#include "PixieDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////
// CMyApp
//
BEGIN_MESSAGE_MAP(CMyApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT,	OnAppAbout)
	ON_COMMAND(ID_DUMMY_NEW,	OnDummy)
	ON_COMMAND(ID_DUMMY_OPEN,	OnDummy)
	ON_COMMAND(ID_DUMMY_SAVE,	OnDummy)
END_MESSAGE_MAP()

IMPLEMENT_DYNAMIC(CMyApp, CWinApp)

CMyApp theApp;

BOOL CMyApp::InitInstance()
{
	// Create standard doc/frame/view
	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CMyDoc),
		RUNTIME_CLASS(CMainFrame),
		RUNTIME_CLASS(CMyView));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	return ProcessShellCommand(cmdInfo);
}

void CMyApp::OnDummy()
{
	AfxMessageBox(_T("This command is only here to show how menu buttons look for New, Open, Save."));
}

//////////////////
// Custom about dialog.
//
void CMyApp::OnAppAbout()
{
	static DLGLINK links[] = {
		{ IDC_STATICURLPD,  NULL },
		{ IDC_STATICURLMSJ,  _T("http://www.microsoft.com/msj") },
		{ IDR_MSJLINK,       _T("http://www.microsoft.com/msj") }
	};
	const NUMLINKS = sizeof(links)/sizeof(links[0]);

	CPixieDlg(IDD_ABOUTBOX, links, NUMLINKS).DoModal();
}
