Enclosed is TraceWin.exe, to see MFC TRACE output. If you want to use
it in other apps, you must #include TraceWin.h.

