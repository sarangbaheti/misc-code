////////////////////////////////////////////////////////////////
// RopView 1997 Microsoft Systems Journal
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "StdAfx.h"
#include "MainFrm.h"
#include "View.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define ID_VIEW_WHICHLAST ID_VIEW_WHICH4

// ID and minimum size of combo box in coolbar band
const UINT	IDCOMBO = 1001;
const CSize COMBO_MINSIZE(150,25);

////////////////////////////////////////////////////////////////
// CMainFrame
//
IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_COMMAND(ID_USE_TOOLBAR,				 OnUseToolbar)
	ON_UPDATE_COMMAND_UI(ID_USE_TOOLBAR, OnUpdateUseToolbar)

	ON_COMMAND(ID_COLOR_DISABLE,				 OnColorDisabled)
	ON_UPDATE_COMMAND_UI(ID_COLOR_DISABLE,  OnUpdateColorDisabled)

	ON_COMMAND(ID_VIEW_MENU_BUTTONS,				 OnViewMenuButtons)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MENU_BUTTONS, OnUpdateViewMenuButtons)

	ON_COMMAND(ID_VIEW_FLAT,			  OnFlatTB)
	ON_UPDATE_COMMAND_UI(ID_VIEW_FLAT, OnUpdateFlatTB)

	ON_COMMAND(ID_VIEW_CBBITMAP,			   OnHideShowCoolBarBitmap)
	ON_UPDATE_COMMAND_UI(ID_VIEW_CBBITMAP, OnUpdateHideShowCoolbarBitmap)

	ON_COMMAND_RANGE(ID_VIEW_WHICH0, ID_VIEW_WHICHLAST,	OnViewWhich)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VIEW_WHICH0,ID_VIEW_WHICHLAST,
		OnUpdateViewWhich)

	ON_CBN_SELCHANGE(IDCOMBO, OnComboChange)

	ON_WM_CREATE()
	ON_WM_CONTEXTMENU()
	ON_WM_SYSCOLORCHANGE()
END_MESSAGE_MAP()

CMainFrame::CMainFrame()
{
	m_pCoolBar = NULL;
	m_pToolBar = NULL;
}

CMainFrame::~CMainFrame()
{
	// one of these will be NULL, but OK to delete NULL
	delete m_pCoolBar;
	delete m_pToolBar;
}

////////////////
// Override flicker-free drawing with no CS_VREDRAW and CS_HREDRAW. This has
// nothing to do with coolbars, but I it's a good thing to do.
//
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
   cs.lpszClass = AfxRegisterWndClass(
      0,											 // no redraw
      NULL,                             // no cursor (use default)
      NULL,                             // no background brush
      AfxGetApp()->LoadIcon(IDR_MAINFRAME)); // app icon
	cs.style &= ~FWS_ADDTOTITLE;
   ASSERT(cs.lpszClass);
   return CFrameWnd::PreCreateWindow(cs);
}

//////////////////
// Create handler creates control bars
//
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	VERIFY(CFrameWnd::OnCreate(lpCreateStruct) == 0);
	VERIFY(CreateCoolBar());
	ShowCoolbarBitmap(TRUE);

	// Create status bar
	static UINT indicators[] = {
		ID_SEPARATOR, ID_INDICATOR_CAPS, ID_INDICATOR_NUM, ID_INDICATOR_SCRL };

	VERIFY(m_wndStatusBar.Create(this));
	VERIFY(m_wndStatusBar.SetIndicators(indicators,
		sizeof(indicators)/sizeof(indicators[0])));
		
	// install/load cool menus
	m_menuManager.Install(this);
	m_menuManager.LoadToolbar(IDR_MAINFRAME);

	return 0;
}

BOOL CMainFrame::CreateCoolBar()
{
	ASSERT(m_pCoolBar==NULL);
	m_pCoolBar = new CMyCoolBar;
	ASSERT(m_pCoolBar);
	CMyCoolBar& m_wndCoolBar = *m_pCoolBar;

	VERIFY(m_wndCoolBar.Create(this,
		WS_CHILD|WS_VISIBLE|WS_BORDER|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|
			RBS_TOOLTIPS|RBS_BANDBORDERS|RBS_VARHEIGHT));

	m_wndCoolBar.SetColors(GetSysColor(COLOR_BTNTEXT),
		GetSysColor(COLOR_3DFACE));

	m_wndCoolBar.SetBackgroundBitmap(&m_bmCoolBar);
	m_wndCoolBar.Invalidate();

	return TRUE;
}

BOOL CMainFrame::CreateToolBar()
{
	ASSERT(m_pToolBar==NULL);
	m_pToolBar = new CFlatToolBar;
	ASSERT(m_pToolBar);
	CFlatToolBar& m_wndToolBar = *m_pToolBar;

	VERIFY(m_wndToolBar.Create(this));
	VERIFY(m_wndToolBar.LoadToolBar(IDR_MAINFRAME));

	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);
	m_wndToolBar.SetWindowText(_T("CoolUI"));
	return TRUE;
}

//////////////////
// User changed system colors: update view, coolbar, menu manager
//
void CMainFrame::OnSysColorChange()
{
	CFrameWnd::OnSysColorChange();

	CMyView* pView = (CMyView*)GetActiveView();
	ASSERT_KINDOF(CMyView, pView);
	pView->OnSysColorChange();				 // tell view too

	if (m_pCoolBar) {
		// Set fg/bg color of coolbar to new values
		m_pCoolBar->SetColors(GetSysColor(COLOR_BTNTEXT),
			GetSysColor(COLOR_3DFACE));

		// If using coolbar bitmap, refresh
		if (m_bmCoolBar.GetSafeHandle()) {
			ShowCoolbarBitmap(FALSE);		 // hide
			ShowCoolbarBitmap(TRUE);		 // show
		}
	}
	GetToolBar()->Invalidate(); // repaint 
}

//////////////////
// User right-clicked: display a context menu.
//
void CMainFrame::OnContextMenu(CWnd* pWnd, CPoint p)
{
	if (!m_contextMenu) {
		// one-time load: context menu is 1st submenu in resource menu
		CMenu menu;
		VERIFY(menu.LoadMenu(IDR_MYCONTEXTMENU));
		m_contextMenu.Attach(::GetSubMenu(menu, 0));
		menu.Detach(); // otherwise destructor will destroy my menu!
	}
	ASSERT_VALID(&m_contextMenu);
	m_contextMenu.TrackPopupMenu(0, p.x, p.y, this);
}

//////////////////
// Command handlers for View | Hide/Show Menu Buttons
//
void CMainFrame::OnViewMenuButtons()
{
	m_menuManager.m_bShowButtons = !m_menuManager.m_bShowButtons;
}
void CMainFrame::OnUpdateViewMenuButtons(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_menuManager.m_bShowButtons);
	pCmdUI->SetText(m_menuManager.m_bShowButtons ?
		_T("Hide &Menu Buttons") : _T("Show &Menu Buttons"));
}

//////////////////
// Command handlers for View | Flat Toolbar
//
void CMainFrame::OnFlatTB()
{
	CFlatToolBar &tb = *GetToolBar();
	tb.SetFlatStyle(!tb.GetFlatStyle());
	tb.Invalidate();
}
void CMainFrame::OnUpdateFlatTB(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(GetToolBar()->GetFlatStyle());
}

//////////////////
// Toggle coolbar Bitmap
//
void CMainFrame::OnHideShowCoolBarBitmap()
{
	ShowCoolbarBitmap(m_bmCoolBar.GetSafeHandle() ? FALSE : TRUE);
}

void CMainFrame::OnUpdateHideShowCoolbarBitmap(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_pCoolBar != NULL);
	pCmdUI->SetText(m_bmCoolBar.GetSafeHandle() ?
		_T("Hide Coolbar &Bitmap") : _T("Show Coolbar &Bitmap"));
}

void CMainFrame::ShowCoolbarBitmap(BOOL bShow)
{
	if (bShow) {
		// show bitmap: load if needed
		if (!m_bmCoolBar.GetSafeHandle()) {

			// load bitmap
			HBITMAP hbm = (HBITMAP)::LoadImage(AfxGetResourceHandle(),
				MAKEINTRESOURCE(IDB_COOLBARBG),
				IMAGE_BITMAP,
				0, 0,
				LR_LOADMAP3DCOLORS|LR_LOADTRANSPARENT);
			ASSERT(hbm);
			m_bmCoolBar.Attach(hbm);
		}
	} else {
		// hide bitmap: delete if needed
		if (m_bmCoolBar.GetSafeHandle()) {
			m_bmCoolBar.DeleteObject();		 // delete bitmap
		}
	}
	if (m_pCoolBar) {
		m_pCoolBar->SetBackgroundBitmap(&m_bmCoolBar);
		m_pCoolBar->Invalidate();
	}
}

//////////////////
// Command handler for combo box select
//
void CMainFrame::OnComboChange()
{
	ASSERT(m_pCoolBar);
	OnViewWhich(m_pCoolBar->m_wndCombo.GetCurSel() + ID_VIEW_WHICH0);
}

//////////////////
// Command handlers for View | All, Image List, etc.
//
void CMainFrame::OnViewWhich(UINT nID)
{
	CMyView* pView = (CMyView*)GetActiveView();
	ASSERT_KINDOF(CMyView, pView);
	UINT nWhich = pView->SetWhichView(nID-ID_VIEW_WHICH0);
	if (m_pCoolBar)
		m_pCoolBar->m_wndCombo.SetCurSel(nWhich);
}
void CMainFrame::OnUpdateViewWhich(CCmdUI* pCmdUI)
{
	CMyView* pView = (CMyView*)GetActiveView();
	ASSERT_KINDOF(CMyView, pView);
	pCmdUI->SetRadio(pView->GetWhichView() == pCmdUI->m_nID - ID_VIEW_WHICH0);
}

//////////////////
// Flip between coolbar and toolbar
//
void CMainFrame::OnUseToolbar()
{
	if (m_pCoolBar) {
		delete m_pCoolBar;
		m_pCoolBar = NULL;
		CreateToolBar();
	} else {
		delete m_pToolBar;
		m_pToolBar = NULL;
		CreateCoolBar();		
	}
}
void CMainFrame::OnUpdateUseToolbar(CCmdUI* pCmdUI)
{
	pCmdUI->SetText(m_pCoolBar ? _T("&Use Toolbar") : _T("&Use Coolbar"));
}

////////////////
// Toggle whether to draw disabled buttons in color
//
void CMainFrame::OnColorDisabled()
{
	CFlatToolBar& tb = *GetToolBar();
	BOOL b = !tb.m_bDrawDisabledButtonsInColor;
	tb.m_bDrawDisabledButtonsInColor = b;
	m_menuManager.m_bDrawDisabledButtonsInColor = b;
	tb.Invalidate();
}
void CMainFrame::OnUpdateColorDisabled(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(GetToolBar()->m_bDrawDisabledButtonsInColor);
}


////////////////////////////////////////////////////////////////
// CMyCoolBar
//
IMPLEMENT_DYNAMIC(CMyCoolBar, CCoolBar)

////////////////
// This is the virtual function you have to override to add bands
//
BOOL CMyCoolBar::OnCreateBands()
{
	// Create tool bar
	CCoolToolBar& tb = m_wndToolBar;
	if (!tb.Create(this,
		WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|
			CBRS_TOOLTIPS|CBRS_SIZE_DYNAMIC|CBRS_FLYBY) ||
		 !tb.LoadToolBar(IDR_MAINFRAME)) {
		TRACE0(_T("Failed to create toolbar\n"));
		return FALSE; // failed to create
	}

	// Create combo box
	CRect rc(0,0,0,0);
	m_wndCombo.Create(WS_VISIBLE|WS_CHILD|WS_VSCROLL|CBS_DROPDOWNLIST|
		WS_CLIPCHILDREN|WS_CLIPSIBLINGS, rc, this, IDCOMBO);
	static LPCTSTR views[] = { _T("All"),_T("ImageList_Draw"),
		_T("DrawState/Icon"),_T("DrawState/Bitmap"),_T("ROPs"),NULL	};
	for (LPCTSTR *p=views; *p; p++)
		m_wndCombo.AddString(*p);
	m_wndCombo.SetCurSel(0);

	// Get minimum size of toolbar, which is basically size of one button
	CSize szHorz = tb.CalcDynamicLayout(-1, 0);	      // get min horz size
	CSize szVert = tb.CalcDynamicLayout(-1, LM_HORZ);	// get min vert size
	CSize szMin( szHorz.cx, szVert.cy );
	if (!InsertBand(&m_wndToolBar, szMin))
		return FALSE;

	if (!InsertBand(&m_wndCombo, COMBO_MINSIZE, _T("Which view:")))
		return FALSE;

	return TRUE; // OK
}

////////////////////////////////////////////////////////////////
// CMyComboBox
//
IMPLEMENT_DYNAMIC(CMyComboBox, CComboBox)

BEGIN_MESSAGE_MAP(CMyComboBox, CComboBox)
	ON_CONTROL_REFLECT(CBN_DROPDOWN, OnDropDown)
END_MESSAGE_MAP()

//////////////////
// Must resize the combo when I get CBN_DROPDOWN
//		
void CMyComboBox::OnDropDown()
{
	CRect rc;
	GetWindowRect(&rc);
	SetWindowPos(NULL,0,0,rc.Width(),200, // use same width but taller height
		SWP_NOMOVE|SWP_NOACTIVATE);
}
