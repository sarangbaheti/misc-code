Enclosed is TraceWin.exe, to see MFC TRACE output. If you want to use
it in other apps, you must #include TraceWin.h.

NOTE: portions of the code for this app use the PixieLib(TM) library,
a binary version of which is included for linking. The complete
PixieLib library, with source coded, is available for a nominal fee
at

http://pobox.com/~dilascia

Sorry, but I spend far too much time writing this stuff to give everything
away for free. PixieLib includes, among other things, enhanced versions of my
recent CCoolBar and CFlatToolBar classes that fix several bugs, work
in NT and do highlighting/shading of checked buttons correctly.

Thank you
Paul DiLascia
1 October 1997
