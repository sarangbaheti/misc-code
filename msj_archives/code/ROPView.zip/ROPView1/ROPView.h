////////////////////////////////////////////////////////////////
// 1997 Microsoft Systems Journal. 
// If this program works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// 
#include "resource.h"

//////////////////
// Standard application class
//
class CMyApp : public CWinApp {
public:
	DECLARE_DYNAMIC(CMyApp)
	virtual BOOL InitInstance();
protected:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnAppAbout();
	afx_msg void OnDummy();
};
