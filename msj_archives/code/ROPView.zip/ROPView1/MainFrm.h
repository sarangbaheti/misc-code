////////////////////////////////////////////////////////////////
// ROPView 1997 Microsoft Systems Journal
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "CoolBar.h"
#include "CoolMenu.h"

////////////////
// Special combo box in cool bar used to select which views are displayed
//
class CMyComboBox : public CComboBox {
protected:
	DECLARE_DYNAMIC(CMyComboBox)
	DECLARE_MESSAGE_MAP()
	afx_msg void OnDropDown();
};

/////////////////
// My cool bar. Contains a toolbar and a combo box
//
class CMyCoolBar : public CCoolBar {
protected:
	DECLARE_DYNAMIC(CMyCoolBar)
	CCoolToolBar	m_wndToolBar;			 // toolbar
	CMyComboBox		m_wndCombo;				 // combo box
	virtual BOOL   OnCreateBands();		 // fn to create the bands
};

/////////////////
// Main frame window has menu manager, cool bar, status bar
//
class CMainFrame : public CFrameWnd {
public:
	CMainFrame();
	~CMainFrame();

protected:
	DECLARE_DYNCREATE(CMainFrame)
	CCoolMenuManager	   m_menuManager;	 // manages button menus
	CMenu						m_contextMenu;	 // right-click menu
	CStatusBar				m_wndStatusBar; // standard status bar

	// Note: because this particular app can use two kinds of toolbars
	// (CFlatToolBar or CMyCoolBar), the objects are allocated rather than
	// stored as members. In a normal app, you would simply instantiate
	// one or the other as m_wndToolBar or m_wndCoolBar, and throughout the code
	// replace m_pToolBar->foo with m_wndToolBar.foo, etc.
	//
	CFlatToolBar*			m_pToolBar;		 // if using toolbar
	CMyCoolBar*				m_pCoolBar;		 // if using coolbar
	CBitmap				   m_bmCoolBar;	 // coolbar bitmap

	// helpers
	BOOL CreateCoolBar();
	BOOL CreateToolBar();
	void ShowCoolbarBitmap(BOOL bShow);
	CFlatToolBar* GetToolBar() {
		return m_pCoolBar ? &m_pCoolBar->m_wndToolBar : m_pToolBar;
	}

	// overrides
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	// message handlers
	DECLARE_MESSAGE_MAP()
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint pos);
	afx_msg void OnSysColorChange();

	// command handlers
	afx_msg void OnUseToolbar();
	afx_msg void OnUpdateUseToolbar(CCmdUI* pCmdUI);
	afx_msg void OnColorDisabled();
	afx_msg void OnUpdateColorDisabled(CCmdUI* pCmdUI);
	afx_msg void OnViewMenuButtons();
	afx_msg void OnUpdateViewMenuButtons(CCmdUI* pCmdUI);
	afx_msg void OnFlatTB();
	afx_msg void OnUpdateFlatTB(CCmdUI* pCmdUI);
	afx_msg void OnHideShowCoolBarBitmap();
	afx_msg void OnUpdateHideShowCoolbarBitmap(CCmdUI* pCmdUI);
	afx_msg void OnViewWhich(UINT nID);
	afx_msg void OnUpdateViewWhich(CCmdUI* pCmdUI);
	afx_msg void OnComboChange();
};
