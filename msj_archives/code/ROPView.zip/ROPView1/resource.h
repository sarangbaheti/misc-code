//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ROPView.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MYCONTEXTMENU               129
#define IDR_MSJLINK                     129
#define IDB_COOLBARBG                   130
#define IDB_BITMAP2                     131
#define ID_BUTTONTEST                   132
#define IDC_STATICURLPD                 1000
#define IDC_STATICURLMSJ                1001
#define ID_VIEW_MENU_BUTTONS            32772
#define ID_DISABLED                     32773
#define ID_VIEW_WINDOW                  32774
#define ID_VIEW_3DFACE                  32775
#define ID_VIEW_RED                     32776
#define ID_VIEW_GREEN                   32777
#define ID_VIEW_BLUE                    32778
#define ID_VIEW_BGCOLOR                 32790
#define ID_VIEW_WHICH0                  32800
#define ID_VIEW_WHICH1                  32801
#define ID_VIEW_WHICH2                  32802
#define ID_VIEW_WHICH3                  32803
#define ID_VIEW_WHICH4                  32804
#define ID_VIEW_FLAT                    32810
#define ID_VIEW_CBBITMAP                32811
#define ID_DUMMY_NEW                    32812
#define ID_DUMMY_OPEN                   32813
#define ID_DUMMY_SAVE                   32814
#define ID_DUMMY_SAVE_AS                32815
#define ID_USE_TOOLBAR                  32817
#define ID_COLOR_DISABLE                32818

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32819
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
