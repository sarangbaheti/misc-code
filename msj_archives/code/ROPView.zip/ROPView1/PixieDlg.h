////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
// CPixieDLg provides an quick way to create a dialog with hyperlinks
// to web pages or any file on the desktop. To use it:
//
//   CPixieDLg dlg(IDD_DIALOG, links, n);
//   dlg.DoModal();
//
// where "links" is an array of DLGLINK structs (below) and n is how many.
//
//   - IDs must be IDs of static control
//   - if link text==NULL, code will use window text
//
// CPixieDlg also lets you have one bitmap in the dialog that's a DIB,
// and it will handle all the palette stuff for you.
//
// See About dialog in DIBVIEW sample for more details how to use
//
#ifndef _PIXIEDLG_H
#define _PIXIEDLG_H

// one of these for each hyperlink in the dialog
struct DLGLINK {
	UINT		nID;		// control ID
	LPCTSTR	text;		// link text (NULL to use window text)
};

//////////////////
// Pixie dialog supports special features.
//
//  * One static DIB bitmap allowed, with a hyperlink
//    CPixieDlg will handle palette correctly.
//    Note that ID of bitmap and static control must be the same!
//  * You can have any number of hyperlinks (eg. URLS)
//
// See sample program DIBVIEW for example how to use.
//
class CPixieDlg : public CDialog {
protected:
	DLGLINK*			m_arLinks;			// array of DLGLINKS (hyperlinks)
	UINT				m_nLinks;			// size of array
	virtual BOOL	OnInitDialog();

public:
	DECLARE_DYNAMIC(CPixieDlg)
	CPixieDlg(UINT nID, DLGLINK* arLinks=NULL, UINT nLink=0);
	virtual ~CPixieDlg();
};

#endif
