/////////////////
// Standard do-nothing doc
//
class CMyDoc : public CDocument {
public:
	DECLARE_DYNCREATE(CMyDoc)
	virtual void Serialize(CArchive& ar);
};
