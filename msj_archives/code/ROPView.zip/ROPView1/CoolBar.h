////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#ifndef __COOLUI_H
#define __COOLUI_H

#include "subclass.h"

//////////////////
// CFlatToolbar is a drop-in replacement for CToolBar that has "flat"
// style buttons an "gripper" handles. Use instead of CToolBar in your
// CMainFrame. You can set public members to control whether to draw
// grippers and/or separators. CFlatToolBar also handles correct
// "hot" state of checked items and overcomes various MFC bugs.
//
class CFlatToolBar : public CToolBar {
public:
	DECLARE_DYNAMIC(CFlatToolBar)
	CFlatToolBar();

	// You must call one of these to get teh flat look; if not, you must
	// set TBSTYLE_FLAT yourself.
	BOOL LoadToolBar(LPCTSTR lpszResourceName);
	BOOL LoadToolBar(UINT nIDResource)
		{ return LoadToolBar(MAKEINTRESOURCE(nIDResource)); }

	// set these before creation:
	BOOL m_bDrawSeparators;						// draw separators (dflt = TRUE)
	BOOL m_bDrawGrippers;						// draw grippers   (dflt = TRUE)
	BOOL m_bDrawDisabledButtonsInColor;		// draw disabled buttons in color

	static BOOL bTRACE;							// to see TRACE diagnostics

	// Use these to get/set the flat style. By default, LoadToolBar calls
	// SetFlatStyle(TRUE); if you create some other way, you must call it
	// yourself.
	BOOL SetFlatStyle(BOOL bFlat) {
		return ModifyStyle(bFlat ? 0 : TBSTYLE_FLAT, bFlat ? TBSTYLE_FLAT : 0);
	}
	BOOL GetFlatStyle() {
		return (GetStyle() & TBSTYLE_FLAT)!=0;
	}

	// MFC overrides.
	virtual CSize CalcFixedLayout(BOOL bStretch, BOOL bHorz);
	virtual CSize CalcDynamicLayout(int nLength, DWORD nMode);

protected:
	CRect			m_rcOldPos;		// used when toolbar is moved
	CBitmap		m_bmChecked;	// background bitmap for checked buttons
	CByteArray	m_bWasChecked;	// remembers which buttons were checked

	// helpers
	virtual CSize AdjustSize(CSize sz, BOOL bHorz);
	virtual BOOL  DrawItem(CDC& dc, const NMCUSTOMDRAW& cd);
	virtual void  DrawSeparators(CDC& dc);
	virtual void  InvalidateOldPos(const CRect& rcInvalid);

	DECLARE_MESSAGE_MAP()
	afx_msg void OnCustomDraw(NMHDR* pNMHDR, LRESULT* pRes);
	afx_msg void OnWindowPosChanging(LPWINDOWPOS lpWndPos);
	afx_msg void OnWindowPosChanged(LPWINDOWPOS lpWndPos);
	afx_msg void OnNcPaint();
	afx_msg void OnNcCalcSize(BOOL bCalc, NCCALCSIZE_PARAMS*	pncp );
};

//////////////////
// CCoolBar encapsulates IE common coolbar (rebar) for MFC. To use it,
//
//		* derive your own CMyCoolBar from CCoolBar
//		* implement OnCreateBands to create whatever bands you want
//		* instantiate CMyCoolBar in your frame window as you would a toolbar
//		* create and load it, etc from CMainFrame::OnCreate
//
// See TCOOLBAR for example of how to use.
//
class CCoolBar : public CControlBar {
public:
	DECLARE_DYNAMIC(CCoolBar)
	CCoolBar();
	virtual ~CCoolBar();

	BOOL Create(CWnd* pParentWnd, DWORD dwStyle,
		DWORD dwAfxBarStyle = CBRS_ALIGN_TOP,
		UINT nID = AFX_IDW_TOOLBAR);

	// message wrappers
	BOOL GetBarInfo(LPREBARINFO lp)
		{ ASSERT(::IsWindow(m_hWnd));
		  return (BOOL)SendMessage(RB_GETBARINFO, 0, (LPARAM)lp); }

	BOOL SetBarInfo(LPREBARINFO lp)
		{ ASSERT(::IsWindow(m_hWnd));
		  return (BOOL)SendMessage(RB_SETBARINFO, 0, (LPARAM)lp); }

	BOOL GetBandInfo(int iBand, LPREBARBANDINFO lp)
		{ ASSERT(::IsWindow(m_hWnd));
		  return (BOOL)SendMessage(RB_GETBANDINFO, iBand, (LPARAM)lp); }

	BOOL SetBandInfo(int iBand, LPREBARBANDINFO lp)
		{ ASSERT(::IsWindow(m_hWnd));
		  return (BOOL)SendMessage(RB_SETBANDINFO, iBand, (LPARAM)lp); }

	BOOL InsertBand(int iWhere, LPREBARBANDINFO lp)
		{ ASSERT(::IsWindow(m_hWnd));
		  return (BOOL)SendMessage(RB_INSERTBAND, (WPARAM)iWhere, (LPARAM)lp); }

	BOOL DeleteBand(int nWhich)
		{ ASSERT(::IsWindow(m_hWnd));
		  return (BOOL)SendMessage(RB_DELETEBAND, (WPARAM)nWhich); }

	int GetBandCount()
		{ ASSERT(::IsWindow(m_hWnd));
		  return (int)SendMessage(RB_GETBANDCOUNT); }

	int GetRowCount()
		{ ASSERT(::IsWindow(m_hWnd));
	     return (int)SendMessage(RB_GETROWCOUNT); }

	int GetRowHeight(int nWhich)
		{ ASSERT(::IsWindow(m_hWnd));
	     return (int)SendMessage(RB_GETROWHEIGHT, (WPARAM)nWhich); }

	// Call these handy functions from your OnCreateBands to do stuff
	// more easily than the Windows way.
	//
	BOOL InsertBand(CWnd* pWnd,CSize szMin,LPCTSTR lpText=NULL,int iWhere=-1);
	void SetColors(COLORREF clrFG, COLORREF clrBG);
	void SetBackgroundBitmap(CBitmap* pBitmap);
	void Invalidate(BOOL bErase = TRUE); // invalidates children too

	static BOOL bTRACE;	// Set TRUE to see extra diagnostics in DEBUG code

protected:
	// YOU MUST OVERRIDE THIS in your derived class to create bands.
	virtual BOOL OnCreateBands() = 0; // return -1 if failed

	// Virtual fn called when the coolbar height changes as a result of moving
	// bands around. Override only if you want to do something different.
	virtual void OnHeightChange(const CRect& rcNew);

	// overrides to fix problems w/MFC. No need to override yourself.
	virtual CSize CalcFixedLayout(BOOL bStretch, BOOL bHorz);
	virtual CSize CalcDynamicLayout(int nLength, DWORD nMode);
	virtual void  OnUpdateCmdUI(CFrameWnd* pTarget, BOOL bDisableIfNoHndler);

	// message handlers
	DECLARE_MESSAGE_MAP()
	afx_msg int  OnCreate(LPCREATESTRUCT lpcs);
	afx_msg void OnPaint();
	afx_msg void OnHeightChange(NMHDR* pNMHDR, LRESULT* pRes);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
};

//////////////////
// Specialized tool bar class fixes display problems in MFC.
// If you want to use a toolbar inside a cool bar, use this class.
//
class CCoolToolBar : public CFlatToolBar {
public:
	DECLARE_DYNAMIC(CCoolToolBar)
	CCoolToolBar();
	virtual ~CCoolToolBar();

	BOOL Create(CWnd* pParentWnd,
		DWORD dwStyle = WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_ORIENT_HORZ,
		UINT nID = AFX_IDW_TOOLBAR);

protected:
	virtual void OnUpdateCmdUI(CFrameWnd* pTarget, BOOL bDisableIfNoHndler);
	DECLARE_MESSAGE_MAP()
	afx_msg BOOL OnNcCreate(LPCREATESTRUCT lpcs);
	afx_msg void OnNcPaint();
	afx_msg void OnPaint();
	afx_msg void OnNcCalcSize(BOOL, NCCALCSIZE_PARAMS*);
};

//////////////////
// Programmer-friendly REBARINFO initializes itself.
//
class CRebarInfo : public REBARINFO {
public:
	CRebarInfo() {
		memset(this, 0, sizeof(REBARINFO));
		cbSize = sizeof(REBARINFO);
	}
};

//////////////////
// Programmer-friendly REBARBANDINFO initializes itself.
//
class CRebarBandInfo : public REBARBANDINFO {
public:
	CRebarBandInfo() {
		memset(this, 0, sizeof(REBARBANDINFO));
		cbSize = sizeof(REBARBANDINFO);
	}
};

#endif
