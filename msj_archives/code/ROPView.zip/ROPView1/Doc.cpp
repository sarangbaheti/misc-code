#include "StdAfx.h"
#include "Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////
// CMyDoc
//
IMPLEMENT_DYNCREATE(CMyDoc, CDocument)

void CMyDoc::Serialize(CArchive& ar)
{
	ASSERT(FALSE);
}
