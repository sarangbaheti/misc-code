NOTE:

ROPView1 contains the original ROPView program as described in the
January 1998 issue of MSJ.  This version contains some additional
features not described in the article. The source for these features
is NOT provided, only the binary (debug) code in the library
PXLD.LIB; you must link with PXLD.LIB to build ROPView1. The extra
features demonstrate some of the other cool UI stuff in my commerical
PixieLib library on the web site below.

ROPView2 is a lightweight version of ROPView with the extra cool UI features
removed. You do not need PXLD.LIB to compile ROPView2.

This does not affect the cool menus features. Both ROPView1 and ROPView2 use
cool menus and provide ALL source code required to implement cool menus in
any app. There is no difference between ROPView1 and ROPView2 as far as cool
menus are concerned.

Enjoy!

Paul DiLascia
http://pobox.com/~askpd
