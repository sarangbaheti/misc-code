//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MFCaptureToFile.rc
//
#define IDD_DIALOG1                     101
#define IDC_DEVICE_LIST                 1001
#define IDC_CAPTURE                     1002
#define IDC_OUTPUT_FILE                 1003
#define IDC_CAPTURE_MP4                 1004
#define IDC_RADIO2                      1005
#define IDC_CAPTURE_WMV                 1005
#define IDC_STATIC                      -1

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
