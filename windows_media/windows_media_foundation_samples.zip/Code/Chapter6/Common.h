#pragma once

enum SourceState
{
    SourceStateUninitialized,
    SourceStateOpening,
    SourceStateStopped,
    SourceStatePaused,
    SourceStateStarted,
    SourceStateShutdown
};
