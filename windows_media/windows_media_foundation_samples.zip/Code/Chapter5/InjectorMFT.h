#pragma once
class CInjectorMFT
{
public:
    CInjectorMFT(void);
    ~CInjectorMFT(void);
};

