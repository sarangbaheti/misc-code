#include "StdAfx.h"
#include "InjectorMFT.h"


CInjectorMFT::CInjectorMFT(void)
{
}


CInjectorMFT::~CInjectorMFT(void)
{
}
