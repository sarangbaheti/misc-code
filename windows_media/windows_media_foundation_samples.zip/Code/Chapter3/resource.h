//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BasicPlayback.rc
//
#define IDD_MFPLAYBACK_DIALOG           102
#define IDC_POINTER                     104
#define ID_FILE_EXIT                    105
#define IDI_MFPLAYBACK                  107
#define IDC_FILEMENU                    109
#define IDR_MAINFRAME                   128
#define ID_FILE_OPENFILE                32771
#define ID_CONTROL_PLAY                 32774
#define ID_CONTROL_PAUSE                32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
