class DialogInterface
{
public:
	static bool GetSaveFilename(String &Result, const String &Title);
	static bool GetOpenFilename(String &Result, const String &Title);
};