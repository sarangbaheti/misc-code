/*
Ray3D.cpp
Written by Matthew Fisher

a 3D ray represented by an origin point and a direction vector.
*/