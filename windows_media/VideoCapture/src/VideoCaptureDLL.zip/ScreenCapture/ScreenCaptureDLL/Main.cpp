/*
Main.cpp
Written by Matthew Fisher

Source file for precompiled header.
*/
#define INITGUID

#include "Main.h"